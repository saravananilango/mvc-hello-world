package com.nn.sova.dryrun;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nn.sova.core.CacheManager;
import com.nn.sova.entity.RedisEnvInfo;

import redis.clients.jedis.HostAndPort;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CacheCommandsSecondEnvBtInstanceTest {

    static RedisEnvInfo redisEnvInfo;

    static Map<Object, Object> dataMap = new HashMap<>();

    @BeforeClass
    public static void setUp() throws Exception {
        System.out.println("Before Test");
        redisEnvInfo = new RedisEnvInfo();
        Set<HostAndPort> nodes = new HashSet<>();
//        nodes.add(new HostAndPort("localhost", 6379));
        nodes.add(new HostAndPort("fwdev.g10xv9.clustercfg.aps1.cache.amazonaws.com", 6379));
        redisEnvInfo.setRedisNodes(nodes);
        dataMap.put("testKey1", "testVal1");
        dataMap.put("testKey2", "testVal2");
        dataMap.put("testKey3", "testVal3");
    }

    @Test
    public void _1_checkSetGetAsObject() {
        CacheManager.getInstance().saveAsObjectWithEnvInfo("testEnvkey1", "testEnvValue1", redisEnvInfo);
        CacheManager.getInstance().saveAsObjectWithEnvInfo("testEnvkey2", "testEnvValue2", redisEnvInfo);
        CacheManager.getInstance().saveAsObjectWithEnvInfo("testEnvkey3", "testEnvValue3", redisEnvInfo);
        assertEquals("testEnvValue1", CacheManager.getInstance().getWithObject("testEnvkey1", redisEnvInfo));
        assertEquals("testEnvValue2", CacheManager.getInstance().getWithObject("testEnvkey2", redisEnvInfo));
        assertEquals("testEnvValue3", CacheManager.getInstance().getWithObject("testEnvkey3", redisEnvInfo));
    }

    @Test
    public void _2_checkSetGetAsBulkObject() {
        CacheManager.getInstance().saveAsBulkDataWithEnvInfo("testEnvBulkkey1", dataMap, redisEnvInfo);
        assertEquals("testVal1", CacheManager.getInstance().getWithObject("testEnvBulkkey1testKey1", redisEnvInfo));
    }

    @Test
    public void _3_checkDeleteAsString() {
        CacheManager.getInstance().deleteKeyWithEnvInfo("testEnvkey1", redisEnvInfo);
        assertEquals(null, CacheManager.getInstance().getWithObject("testEnvkey1", redisEnvInfo));
    }

    @Test
    public void _4_checkDeleteAsObject() {
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(new String[] { "testEnvkey2", "testEnvkey3" },
                redisEnvInfo);
        assertEquals(null, CacheManager.getInstance().getWithObject("testEnvkey2", redisEnvInfo));
        assertEquals(null, CacheManager.getInstance().getWithObject("testEnvkey3", redisEnvInfo));
    }
}
