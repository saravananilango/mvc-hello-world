package com.nn.sova.dryrun;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nn.sova.core.CacheManager;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CacheCommandsFunctionalBtInstanceTest {

    static Set<String> testScanKeys = new HashSet<>();

    @BeforeClass
    public static void setUp() throws Exception {
        System.out.println("Before Test ");
        for (int index = 10; index < 30; index++) {
            CacheManager.getInstance().set("testkey" + index, "testvalue" + index);
            testScanKeys.add("testkey" + index);
        }
    }

    @Test
    public void _01_checkSetExGetAsString() {
        CacheManager.getInstance().saveWithExpiration("testkey17", "testvalue17", 1000);
        assertEquals("testvalue17", CacheManager.getInstance().getWithObject("testkey17"));
    }

    @Test
    public void _02_checkSetGetAsString() {
        CacheManager.getInstance().set("ztestkey", "testvalue");
        assertEquals("testvalue", CacheManager.getInstance().get("ztestkey"));
    }

    @Test
    public void _03_checkSetGetAsMap() {
        Map<Object, Object> dataMap = new HashMap<>();
        for (int i = 0; i < 1000000; i++) {
            dataMap.put("ztestkey" + String.valueOf(i), String.valueOf(i));
        }
        CacheManager.getInstance().saveAsBulkData(dataMap);
        assertEquals("1", CacheManager.getInstance().getWithObject("ztestkey1"));
    }

    @Test
    public void _04_checkSetGetAsObject() {

        CacheManager.getInstance().saveAsObject("testObjkey", "testObjvalue");
        assertEquals("testObjvalue", CacheManager.getInstance().getWithObject("testObjkey"));
    }

    @Test
    public void _05_checkScannedKeys() {
        System.out.println(testScanKeys);
        System.out.println(CacheManager.getInstance().findPrefixRedisKeys("testkey"));
        assertEquals(testScanKeys, CacheManager.getInstance().findPrefixRedisKeys("testkey"));
    }

    @Test
    public void _06_checkDeleteSingleKeysAsString() {
        CacheManager.getInstance().deleteKey("testkey10");
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey10"));
    }

    @Test
    public void _07_checkDeleteMultipleKeysAsString() {
        CacheManager.getInstance().del(new String[] { "testkey11", "testkey12" });
        CacheManager.getInstance().deleteMultipleKeys(new String[] { "testkey13", "testkey14" });
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey11"));
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey12"));
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey13"));
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey14"));
    }

    @Test
    public void _08_checkDeleteKeyAsByte() {
        CacheManager.getInstance().del("testkey15".getBytes());
        CacheManager.getInstance().deleteKey("testkey16".getBytes());
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey15"));
        assertEquals(null, CacheManager.getInstance().getWithObject("testkey16"));
    }

    @Test
    public void _09_checkIfKeyExists() {
        assertEquals(true, CacheManager.getInstance().isKeyExists("testkey17"));
        assertEquals(false, CacheManager.getInstance().isKeyExists("testkeysfdfdfd"));
    }

    @Test
    public void _010_checkSetExGetAsParallelStream() {
        IntStream s = IntStream.range(0, 200);
        s.parallel().forEach(i -> {
            try {
                assertEquals("testObjvalue", CacheManager.getInstance().getWithObject("testObjkey"));
            } catch (Exception ignore) {
            }
        });
    }
}
