package com.nn.sova.cache;

import java.util.Arrays;
import java.util.List;

import com.nn.sova.core.CacheManager;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.application.ApplicationConfigurationCacheService;
import com.nn.sova.service.locale.LocaleCacheService;
import com.nn.sova.service.message.MessageDefinitionCacheService;
import com.nn.sova.service.role.RoleConfigurationService;
import com.nn.sova.service.screen.ScreenDefinitionCacheService;
import com.nn.sova.service.table.TableConfigurationCacheService;
import com.nn.sova.service.text.TextDefinitionCacheService;


/**
 * *** For Development Only ***
 * 
 * Use this class to clear caches in dev-redis
 *
 * @author praveen_kumar_nr
 */
public class ClearCacheService {

	public static void main(String[] args) throws QueryException {
		System.out.println("******** Running - ClearCacheService ******** ");
		System.out.println("clear codes provided : " + Arrays.toString(args));
		if (args != null && args.length > 0) {
			for (String clearCode : args) {
				clearByCode(clearCode);
			}
			return;
		}
		String tableName = "a_test";
		removeServerSideValidation(tableName);
//		removeArchiveSearchSetting();
		
		System.out.println("******** Completed - ClearCacheService ******** ");

	}

	private static void clearByCode(String clearCode) {
		System.out.println("clearing for code : " + clearCode);
		CacheManager.getInstance().deleteKey(clearCode);
	}
	
	  /**
     * Remove environment properties from cache.
     */
    public static void removeEnvironmentPropertiesFromCache() {
        String cacheKey = CacheKeyHelper.getEnvironmentPropertiesKey();
        ApplicationConfigurationCacheService.getInstance().removeEnvironmentPropertiesFromCache(cacheKey);
    }

    /**
     * Remove environment properties from cache.
     *
     * @param envInfo the env info
     */
    public static void removeEnvironmentPropertiesFromCache(EnvironmentDetailsEntity envInfo) {
        String cacheKey = CacheKeyHelper.getEnvironmentPropertiesKey();
        ApplicationConfigurationCacheService.getInstance().removeEnvironmentPropertiesFromCache(cacheKey, envInfo);
    }

    /**
     * Remove archive search setting.
     */
    public static void removeArchiveSearchSetting() {
        String cacheKey = CacheKeyHelper.getArchiveSearchSettingKey();
        ApplicationConfigurationCacheService.getInstance().removeArchiveSearchSetting(cacheKey);
    }

    /**
     * Remove auto numbering.
     */
    public static void removeAutoNumbering() throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getAutoNumberingPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeAutoNumbering(cachePrefixKey);
    }

    /**
     * Remove auto numbering.
     *
     * @param keyList the key list
     */
    public static void removeAutoNumbering(List<String> keyList) {
        String cachePrefixKey = CacheKeyHelper.getAutoNumberingPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeAutoNumbering(cachePrefixKey, keyList);
    }

    /**
     * Remove auto numbering.
     *
     * @param keyList the key list
     * @param entity  the entity
     */
    public static void removeAutoNumbering(List<String> keyList, EnvironmentDetailsEntity entity) {
        String cachePrefixKey = CacheKeyHelper.getAutoNumberingPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeAutoNumbering(cachePrefixKey, keyList, entity);
    }

    /**
     * Remove class configuration.
     *
     * @param id     the id
     * @param entity the entity
     */
    public static void removeClassConfiguration(String id, EnvironmentDetailsEntity entity) {
        String cachePrefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeClassConfiguration(cachePrefixKey, id, entity);
    }

    /**
     * Remove class configuration.
     *
     * @param idList the id list
     * @param entity the entity
     */
    public static void removeClassConfiguration(List<Object> idList, EnvironmentDetailsEntity entity) {
        String cachePrefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeClassConfiguration(cachePrefixKey, idList, entity);
    }

    /**
     * Remove landscape system definition.
     */
    public static void removeLandscapeSystemDefinition() {
        String cacheKey = CacheKeyHelper.getLandscapeSystemDefinitionKey();
        ApplicationConfigurationCacheService.getInstance().removeLandscapeSystemDefinition(cacheKey);
    }

    /**
     * Remove countries phone prefix info key.
     */
    public static void removeCountriesPhonePrefixInfoKey() {
        String cacheKey = CacheKeyHelper.getCountriesPhonePrefixInfoKey();
        ApplicationConfigurationCacheService.getInstance().removePhoneDetails(cacheKey);
    }

    /**
     * Remove drive file user space.
     */
    public static void removeDriveFileUserSpace() {
        String cacheKey = CacheKeyHelper.getDriveUserSpaceInfoKey();
        ApplicationConfigurationCacheService.getInstance().removeDriveFileUserSpace(cacheKey);
    }

    /**
     * Remove system setting.
     */
    public static void removeSystemSetting() {
        String cacheKey = CacheKeyHelper.getSystemSettingsKey();
        ApplicationConfigurationCacheService.getInstance().removeSystemSetting(cacheKey);
    }

    /**
     * Remove repo config details.
     */
    public static void removeRepoConfigDetails() {
        String cacheKey = CacheKeyHelper.getRepoConfigurationKey();
        ApplicationConfigurationCacheService.getInstance().removeRepoConfigDetails(cacheKey);
    }

    /**
     * Remove holidays.
     */
    public static void removeHolidays() {
        ApplicationConfigurationCacheService.getInstance().removeHolidays();
    }

    /**
     * Remove data element.
     *
     * @param serviceId the service id
     */
    public static void removeDataElement(String serviceId) {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, serviceId);
    }

    /**
     * Remove data element.
     *
     * @param serviceIdList the service id list
     */
    public static void removeDataElement(List<String> serviceIdList) {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, serviceIdList);
    }

    /**
     * Remove data element.
     *
     * @param serviceIdList the service id list
     * @param envInfo       the env info
     */
    public static void removeDataElement(List<Object> serviceIdList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, serviceIdList, envInfo);
    }

    /**
     * Remove data element.
     *
     * @param elementIdList            the element id list
     * @param dataFormatList            the data class list
     * @param charsetList              the charset list
     * @param masterList               the master list
     * @param environmentDetailsEntity the environment details entity
     */
    public static void removeDataElement(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                  EnvironmentDetailsEntity environmentDetailsEntity) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, elementIdList, dataFormatList, charsetList, masterList, environmentDetailsEntity);
    }

    /**
     * Remove data element.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     */
    public static void removeDataElement(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList,
                                  List<Object> masterList) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, elementIdList, dataFormatList, charsetList, masterList);
    }

    /**
     * Remove encryption details.
     *
     * @param tableName the table name
     */
    public static void removeEncryptionDetails(String tableName) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableName);
    }

    /**
     * Remove encryption details.
     *
     * @param tableNameList the table name list
     */
    public static void removeEncryptionDetails(List<String> tableNameList) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableNameList);
    }

    /**
     * Remove encryption details.
     *
     * @param tableName the table name
     * @param envInfo   the env info
     */
    public static void removeEncryptionDetails(String tableName, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableName, envInfo);
    }

    /**
     * Remove encryption details.
     *
     * @param tableNameList the table name list
     * @param envInfo       the env info
     */
    public static void removeEncryptionDetails(List<Object> tableNameList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableNameList, envInfo);
    }

    /**
     * Remove table config.
     *
     * @param tableList the table list
     * @param envInfo   the env info
     */
    public static void removeTableConfig(List<Object> tableList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeTableConfig(cachePrefixKey, tableList, envInfo);
    }

    /**
     * Remove table config.
     *
     * @param tableList the table list
     */
    public static void removeTableConfig(List<String> tableList) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeTableConfig(cachePrefixKey, tableList);
    }

    /**
     * Remove view config.
     *
     * @param viewList the view list
     */
    public static void removeViewConfig(List<String> viewList) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeViewConfig(cachePrefixKey, viewList);
    }

    /**
     * Remove view config.
     *
     * @param viewList the view list
     * @param envInfo  the env info
     */
    public static void removeViewConfig(List<String> viewList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeViewConfig(cachePrefixKey, viewList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param tableName the table name
     */
    public static void removeServerSideValidation(String tableName) {
       CacheService.getInstance().removeServerSideValidation(tableName);
    }

    /**
     * Remove server side validation.
     *
     * @param tableNameList the table name list
     */
    public static void removeServerSideValidation(List<String> tableNameList) {
    	CacheService.getInstance().removeServerSideValidation(tableNameList);
    }

    /**
     * Remove server side validation.
     *
     * @param tableNameList the table name list
     * @param envInfo       the env info
     */
    public static void removeServerSideValidation(List<String> tableNameList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, tableNameList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param dataElementList the data element list
     * @param dataFormatList   the data class list
     * @param charsetList     the charset list
     * @param masterList      the master list
     * @param envInfo         the env info
     */
    public static void removeServerSideValidation(List<Object> dataElementList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                           EnvironmentDetailsEntity envInfo) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, dataElementList, dataFormatList, charsetList, masterList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @param envInfo       the env info
     */
    public static void removeServerSideValidation(List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                           EnvironmentDetailsEntity envInfo) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, dataFormatList, charsetList, masterList, envInfo);
    }

    /**
     * Remove server side validation with service id.
     *
     * @param serviceId the service id
     */
    public static void removeServerSideValidationWithServiceId(String serviceId) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidationWithServiceId(cachePrefixKey, serviceId);
    }

    /**
     * Remove database handler details.
     *
     * @param productCodeList the product code list
     */
    public static void removeDatabaseHandlerDetails(List<String> productCodeList) {
        String cachePrefixKey = CacheKeyHelper.getDatabaseHandlerPrefixKey();
        TableConfigurationCacheService.getInstance().removeDatabaseHandlerDetails(cachePrefixKey, productCodeList);
    }

    /**
     * Remove database handler details.
     *
     * @param productCodeList the product code list
     * @param envInfo         the env info
     */
    public static void removeDatabaseHandlerDetails(List<String> productCodeList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getDatabaseHandlerPrefixKey();
        TableConfigurationCacheService.getInstance().removeDatabaseHandlerDetails(cachePrefixKey, productCodeList, envInfo);
    }

    /**
     * Remove authorized screens by tenant id.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     */
    public static void removeAuthorizedScreensByTenantId(String roleId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getAuthorizedScreensPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeAuthorizedScreensByTenantId(cachePrefixKey, tenantId, roleId);
    }

    /**
     * Remove authorized screens.
     *
     * @param roleIdList the role id list
     */
    public static void removeAuthorizedScreens(List<Object> roleIdList) {
        String cachePrefixKey = CacheKeyHelper.getAuthorizedScreensPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeTenantAuthorityService(cachePrefixKey, roleIdList);
    }

    /**
     * Remove screen role link.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     */
    public static void removeTenantScreenRoleLink(String roleId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getScreenRoleLinkPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeTenantScreenRoleLink(cachePrefixKey, tenantId, roleId);
    }

    /**
     * Remove screen component focus.
     */
    public static void removeScreenComponentFocus() {
        String cacheKey = CacheKeyHelper.getScreenComponentFocusDataKey();
        ScreenDefinitionCacheService.getInstance().removeScreenComponentFocus(cacheKey);
    }

    /**
     * Remove screen link.
     *
     * @param screenId the screen id
     */
    public static void removeScreenLink(String screenId) {
        String cachePrefixKey = CacheKeyHelper.getLinkedScreensDefinitionPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeScreenLink(cachePrefixKey, screenId);
    }

    /**
     * Remove screen link with screen id list.
     *
     * @param screenIdList the screen id list
     * @param envInfo      the env info
     */
    public static void removeScreenLinkWithScreenIdList(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getLinkedScreensDefinitionPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeScreenLinkWithScreenIdList(cachePrefixKey, screenIdList, envInfo);
    }

    /**
     * Remove screens with def id.
     *
     * @param serviceDefIdList the service def id list
     * @param envInfo          the env info
     */
    public static void removeScreensWithDefId(List<Object> serviceDefIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
        ScreenDefinitionCacheService.getInstance().removeScreensWithDefId(serviceDefIdList, envInfo);
    }

    /**
     * Remove service.
     *
     * @param screenId the screen id
     */
    public static void removeScreensWithScreenId(String screenId) {
        ScreenDefinitionCacheService.getInstance().removeScreensWithScreenId(screenId);
    }

    /**
     * Remove service.
     *
     * @param screenIdList the screen id list
     * @param envInfo      the env info
     */
    public static void removeScreensWithScreenId(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) {
        ScreenDefinitionCacheService.getInstance().removeScreensWithScreenId(screenIdList, envInfo);
    }

    /**
     * Remove application text def.
     */
    public static void removeApplicationTextDef() {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef();
    }

    /**
     * Remove application text def.
     *
     * @param productCode the product code
     */
    public static void removeApplicationTextDef(String productCode) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(productCode);
    }

    /**
     * Remove application text def.
     *
     * @param productCodeList the product code list
     */
    public static void removeApplicationTextDef(List<String> productCodeList) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(productCodeList);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo the env info
     */
    public static void removeApplicationTextDef(EnvironmentDetailsEntity envInfo) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(envInfo);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo     the env info
     * @param productCode the product code
     */
    public static void removeApplicationTextDef(EnvironmentDetailsEntity envInfo, String productCode) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(envInfo, productCode);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo         the env info
     * @param productCodeList the product code list
     */
    public static void removeApplicationTextDef(EnvironmentDetailsEntity envInfo, List<String> productCodeList) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(envInfo, productCodeList);
    }

    /**
     * Remove framework text def.
     */
    public static void removeFrameworkTextDef() {
        TextDefinitionCacheService.getInstance().removeFrameworkTextDef();
    }

    /**
     * Remove framework text def.
     *
     * @param envInfo the env info
     */
    public static void removeFrameworkTextDef(EnvironmentDetailsEntity envInfo) {
        TextDefinitionCacheService.getInstance().removeFrameworkTextDef(envInfo);
    }

    /**
     * Remove tenant role data.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     */
    public static void removeTenantRoleData(String roleId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getRoleConfigurationPrefixKey();
        RoleConfigurationService.getInstance().removeTenantRoleData(cachePrefixKey, tenantId, roleId);
    }

    /**
     * Remove tenant role link data.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     */
    public static void removeTenantRoleLinkData(String userId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getRolesLinkedWithUserIdPrefixKey();
        RoleConfigurationService.getInstance().removeTenantRoleLinkData(cachePrefixKey, tenantId, userId);
    }

    /**
     * Remove role links.
     *
     * @param userIdList the user id list
     */
    public static void removeRoleLinks(List<Object> userIdList) {
        String cachePrefixKey = CacheKeyHelper.getRolesLinkedWithUserIdPrefixKey();
        RoleConfigurationService.getInstance().removeRoleLinks(cachePrefixKey, userIdList);
    }

    /**
     * Remove tenant users.
     *
     * @param userIdList the user id list
     */
    public static void removeTenantUsers(List<Object> userIdList) {
        String cachePrefixKey = CacheKeyHelper.getTenantUserPrefixKey();
        RoleConfigurationService.getInstance().removeTenantUsers(cachePrefixKey, userIdList);
    }

    /**
     * Remove tenant role links.
     *
     * @param userIdList the user id list
     */
    public static void removeTenantRoleLinks(List<Object> userIdList) {
        String cachePrefixKey = CacheKeyHelper.getTenantRolesLinkedWithUserIdPrefixKey();
        RoleConfigurationService.getInstance().removeTenantRoleLinks(cachePrefixKey, userIdList);
    }

    /**
     * Remove message def.
     */
    public static void removeMessageDefinition() {
        MessageDefinitionCacheService.getInstance().removeMessageDefinition();
    }

    /**
     * Remove message def.
     *
     * @param keyList the key list
     */
    public static void removeMessageDefinition(List<String> keyList) {
        MessageDefinitionCacheService.getInstance().removeMessageDefinition(keyList);
    }

    /**
     * Remove message def.
     *
     * @param keyList the key list
     * @param envInfo the env info
     */
    public static void removeMessageDefinition(List<String> keyList, EnvironmentDetailsEntity envInfo) {
        MessageDefinitionCacheService.getInstance().removeMessageDefinition(keyList, envInfo);
    }

    /**
     * Remove tenant user data.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     */
    public static void removeTenantUserData(String userId, String tenantId) {
        ApplicationConfigurationCacheService.getInstance().removeTenantUserData(userId, tenantId);
    }

    /**
     * Remove product tenant config.
     *
     * @param productCode the product code
     */
    public static void removeProductTenantConfig(String productCode) {
        ApplicationConfigurationCacheService.getInstance().removeProductTenantConfig(productCode);
    }

    /**
     * Remove users.
     *
     * @param userIdList the user id list
     */
    public static void removeUsers(List<Object> userIdList) {
        ApplicationConfigurationCacheService.getInstance().removeUsers(userIdList);
    }

    /**
     * Remove locale.
     */
    public static void removeLocale() {
        LocaleCacheService.getInstance().removeLocale();
    }


}
