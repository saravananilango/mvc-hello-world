package com.nn.sova.dryrun;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nn.sova.core.CacheManager;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CacheCommandsFunctionalProductInstanceTest {

    static Set<String> testScanKeys = new HashSet<>();

    @BeforeClass
    public static void setUp() throws Exception {
//        CacheUtil.getInstance().getProductRedisInfo();
//        Update the below lines
//      Map<String, Object> configList = dao.getRedisDetails(EnvironmentReader.getSystemId(),
//      EnvironmentReader.getProductCode());
//      redisNodes.add(new HostAndPort(Objects.toString((configList.get("ip_address"))),
//      Integer.parseInt(Objects.toString((configList.get("port"))))));
        System.out.println("Before Test");
        for (int index = 10; index < 30; index++) {
            CacheManager.getProductInstance().set("testkey" + index, "testvalue" + index);
            testScanKeys.add("testkey" + index);
        }
    }

    @Test
    public void _1_checkSetExGetAsString() {
        CacheManager.getProductInstance().saveWithExpiration("testkey17", "testvalue17", 1000);
        assertEquals("testvalue17", CacheManager.getProductInstance().getWithObject("testkey17"));
    }

    @Test
    public void _2_checkSetGetAsString() {
        CacheManager.getProductInstance().set("ztestkey", "testvalue");
        assertEquals("testvalue", CacheManager.getProductInstance().get("ztestkey"));
    }

    @Test
    public void _3_checkSetGetAsMap() {
        Map<Object, Object> dataMap = new HashMap<>();
        dataMap.put("ztestkey1", "1");
        dataMap.put("ztestkey2", "2");
        dataMap.put("ztestkey3", "3");
        CacheManager.getProductInstance().saveAsBulkData(dataMap);
        assertEquals("1", CacheManager.getProductInstance().getWithObject("ztestkey1"));
    }

    @Test
    public void _4_checkSetGetAsObject() {
        CacheManager.getProductInstance().saveAsObject("testObjkey", "testObjvalue");
        assertEquals("testObjvalue", CacheManager.getProductInstance().getWithObject("testObjkey"));
    }

    @Test
    public void _5_checkScannedKeys() {
        System.out.println(testScanKeys);
        System.out.println(CacheManager.getProductInstance().findPrefixRedisKeys("testkey"));
        assertEquals(testScanKeys, CacheManager.getProductInstance().findPrefixRedisKeys("testkey"));
    }

    @Test
    public void _6_checkDeleteSingleKeysAsString() {
        CacheManager.getProductInstance().deleteKey("testkey10");
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey10"));
    }

    @Test
    public void _7_checkDeleteMultipleKeysAsString() {
        CacheManager.getProductInstance().del(new String[] { "testkey11", "testkey12" });
        CacheManager.getProductInstance().deleteMultipleKeys(new String[] { "testkey13", "testkey14" });
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey11"));
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey12"));
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey13"));
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey14"));
    }

    @Test
    public void _8_checkDeleteKeyAsByte() {
        CacheManager.getProductInstance().del("testkey15".getBytes());
        CacheManager.getProductInstance().deleteKey("testkey16".getBytes());
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey15"));
        assertEquals(null, CacheManager.getProductInstance().getWithObject("testkey16"));
    }

    @Test
    public void _9_checkIfKeyExists() {
        assertEquals(true, CacheManager.getProductInstance().isKeyExists("testkey17"));
        assertEquals(false, CacheManager.getProductInstance().isKeyExists("testkeysfdfdfd"));
    }

}
