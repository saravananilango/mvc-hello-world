package com.nn.sova.entity;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;


class BatchUserDataTest {

	@Test
	void testBatchUserData() throws Exception {

		assertNotNull(BatchUserData.getDefaultValue("sova"));

	}

}
