package com.nn.sova.constants;

/**
 * The type Message definition constants.
 *
 * @author Anand Kumar
 */
public class MessageDefinitionConstants {
    /**
     * Instantiates a new Message definition constants.
     */
    MessageDefinitionConstants(){

    }
    /**
     * The constant MESSAGE_ID.
     */
    public static final String MESSAGE_ID = "message_id";
    /**
     * The constant LANG_CD.
     */
    public static final String LANG_CD = "lang_cd";
    /**
     * The constant MESSAGE_TYPE.
     */
    public static final String MESSAGE_TYPE = "message_type";
    /**
     * The constant TEXT_CONTENT.
     */
    public static final String TEXT_CONTENT = "text_content";
    /**
     * The constant TITLE.
     */
    public static final String TITLE = "title";
    
    /** The Constant OK_TEXT. */
    public static final String OK_TEXT = "ok_text";
    
    /** The Constant CANCEL_TEXT. */
    public static final String CANCEL_TEXT = "cancel_text";
    
    /** The Constant SCREEN_DEFINITION_ID. */
    public static final String SCREEN_DEFINITION_ID = "screen_definition_id";
}
