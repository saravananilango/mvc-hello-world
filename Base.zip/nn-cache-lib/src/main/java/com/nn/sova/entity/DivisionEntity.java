package com.nn.sova.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * DivisionEntity is used to access the division table fields
 *
 * @author Anand Kumar
 */
@Data
public class DivisionEntity implements Serializable {
    /**
     * The constant serialVersionUID.
     */
    private static final long serialVersionUID = -2448009927494701731L;
    /**
     * The Domain name.
     */
    private String dataFormat;
    /**
     * The Value.
     */
    private String value;
    /**
     * The Label.
     */
    private String label;
    /**
     * The Is default.
     */
    private String isDefault;
    /**
     * The Lang cd.
     */
    private String langCd;
    /**
     * The Division text value.
     */
    private String divisionTextValue;
    /**
     * The Display order.
     */
    private Integer displayOrder;
}
