package com.nn.sova.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;

import com.nn.sova.constants.TableConfigurationColumnConstants;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.constants.TextDefinitionConstants;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utiil.TypeConversionHelper;

/**
 * The type Table config dao.
 *
 * @author Anand Kumar
 */
public class TableConfigurationDao {
    /**
     * The constant instance.
     */
    private static TableConfigurationDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static TableConfigurationDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new TableConfigurationDao();
        }
        return instance;
    }

    /**
     * Gets input data elements.
     *
     * @return the input data elements
     */
    private static List<Map<String, Object>> getInputDataElements() throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.CACHE_INPUT_COMPONENT_INFO_VIEW)
                .build(false).execute();
    }
    
    /**
     * Gets input data elements.
     *
     * @return the input data elements
     */
    private static List<Map<String, Object>> getComponentAdditionalAttribute() throws QueryException {
    	return new QueryBuilder().btSchema().select().skipTenantId(true)
    			.from("cache_component_additional_attribute_view")
    			.build(false).execute();
    }
    
    /**
     * Gets input data elements.
     * @param serviceDefinitionList the service definition list key list
     * 
     * @return the input data elements
     */
    private static List<Map<String, Object>> getComponentAdditionalAttribute(List<Object> serviceDefinitionList) throws QueryException {
    	return new QueryBuilder().btSchema().select().skipTenantId(true)
    			.from("cache_component_additional_attribute_view")
    			.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.SCREEN_DEFINITION_ID, serviceDefinitionList))
    			.build(false).execute();
    }

    /**
     * Gets division data.
     *
     * @return the division data
     */
    private static List<Map<String, Object>> getDivisionData() throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_DIVISION_VALIDATION_VIEW)
                .build(false).execute();
    }
    
    /**
     * Gets division data.
     * @param dataFormatList the data class key list
     *
     * @return the division data
     */
    private static List<Map<String, Object>> getDivisionData(List<Object> dataFormatList) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_DIVISION_VALIDATION_VIEW)
                .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList))
                .build(false).execute();
    }

    /**
     * Gets division data.
     *
     * @param envInfo the env info
     * @return the division data
     * @throws QueryException the query exception
     */
    private static List<Map<String, Object>> getDivisionData(EnvironmentDetailsEntity envInfo) throws QueryException {
        return new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_DIVISION_VALIDATION_VIEW)
                .build(false).execute();
    }

    /**
     * Gets input data elements.
     *
     * @param screenIdKeyList the screen id key list
     * @param envInfo         the env info
     * @return the input data elements
     * @throws QueryException the query exception
     */
    private static List<Map<String, Object>> getInputDataElements(List<Object> screenIdKeyList, EnvironmentDetailsEntity envInfo) throws QueryException {
        return new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.CACHE_INPUT_COMPONENT_INFO_VIEW)
                .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.SCREEN_ID, screenIdKeyList))
                .build(false).execute();
    }

    /**
     * Gets input data elements by screen id.
     *
     * @param screenIdKeyList the screen id key list
     * @return the input data elements by screen id
     */
    private static List<Map<String, Object>> getInputDataElementsByScreenId(List<Object> screenIdKeyList) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.CACHE_INPUT_COMPONENT_INFO_VIEW)
                .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.SCREEN_ID, screenIdKeyList))
                .build(false).execute();
    }
    
    /**
     * Gets input data elements by Screen Definition Type.
     *
     * @param screenDefType the screen definition type
     * @param screenKey        the screen key for identification
     * 
     * @return                 the input data elements by screen id
     */
    private static List<Map<String, Object>> getInputDataElementsByScreenDefType(String screenDefType, String screenKey) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.CACHE_INPUT_COMPONENT_INFO_VIEW)
                .where(ConditionBuilder.instance()
                		.eq(TableConfigurationColumnConstants.SCREEN_DEFINITION_ID, screenKey)
                		.and()
                		.eq(TableConfigurationColumnConstants.SCREEN_DEF_TYPE, screenDefType))
                .build(false).execute();
    }

    /**
     * Get text content by screen def id
     *
     * @param screenDefId        the screen Definition Id
     * 
     * @return                 the screen text value elements by Screen Def Id
     */
    private static List<Map<String, Object>> getTextDefinitionByScreenId(String screenDefId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
				.getWithAliasName(TextDefinitionConstants.TEXT_DEFINITION_ID, "component_id")
				.getWithAliasName(TextDefinitionConstants.TEXT_CONTENT, "text")
				.get(TextDefinitionConstants.LOCALE)
				.get(TableConfigurationColumnConstants.SCREEN_DEFINITION_ID)
                .from(TableViewsConstants.CACHE_TEXT_DEF_APPLICATION_VIEW)
                .where(ConditionBuilder.instance()
                		.eq(TableConfigurationColumnConstants.SCREEN_DEFINITION_ID, screenDefId))
                .build(false).execute();
    }
    
    /**
     * Gets screen by comp data.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @param envInfo       the env info
     * @return the screen by comp data
     */
    public static List<Object> getScreenByCompData(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList, EnvironmentDetailsEntity envInfo) throws QueryException {
        List<Map<String, Object>> screenIdList;
        List<Object> screenList;
        ConditionBuilder conditionMapBuilder = ConditionBuilder.instance();
        AtomicInteger looper = new AtomicInteger(0);
        Map<String, Object> conditionMap = new HashMap<>();
        if(CollectionUtils.isNotEmpty(elementIdList)) {
            conditionMap.put(TableConfigurationColumnConstants.ELEMENT_ID, elementIdList);
        }
        if(CollectionUtils.isNotEmpty(dataFormatList)) {
            conditionMap.put(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList);
        }
        if(CollectionUtils.isNotEmpty(charsetList)) {
            conditionMap.put(TableConfigurationColumnConstants.CHARSET, charsetList);
        }
        if(CollectionUtils.isNotEmpty(masterList)) {
            conditionMap.put(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList);
        }
        SelectQueryBuilder screenIdQueryBuilder;
        screenIdQueryBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema()
                .select().get(TableConfigurationColumnConstants.SCREEN_ID).skipTenantId(true)
                .distinct().from(TableViewsConstants.CACHE_INPUT_COMPONENT_INFO_VIEW);
        conditionMap.entrySet().stream().forEach(action -> {
            if(looper.get() > 0) {
                conditionMapBuilder.or();
            }
            conditionMapBuilder.inWithList(action.getKey(), (List<Object>) action.getValue());
            looper.getAndIncrement();
        });
        screenIdList = screenIdQueryBuilder.where(conditionMapBuilder).build(false).execute();
        screenList = screenIdList.stream().map(mapper -> mapper.get(TableConfigurationColumnConstants.SCREEN_ID).toString())
                .collect(Collectors.toList());
        return screenList;
    }

    /**
     * Gets screen by comp data.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @return the screen by comp data
     */
    public static List<Object> getScreenByCompData(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList) throws QueryException {
        List<Map<String, Object>> screenIdList;
        List<Object> screenList;
        ConditionBuilder conditionMapBuilder = ConditionBuilder.instance();
        AtomicInteger looper = new AtomicInteger(0);
        Map<String, Object> conditionMap = new HashMap<>();
        if(CollectionUtils.isNotEmpty(elementIdList)) {
            conditionMap.put(TableConfigurationColumnConstants.ELEMENT_ID, elementIdList);
        }
        if(CollectionUtils.isNotEmpty(dataFormatList)) {
            conditionMap.put(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList);
        }
        if(CollectionUtils.isNotEmpty(charsetList)) {
            conditionMap.put(TableConfigurationColumnConstants.CHARSET, charsetList);
        }
        if(CollectionUtils.isNotEmpty(masterList)) {
            conditionMap.put(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList);
        }
        SelectQueryBuilder screenIdQueryBuilder;
        screenIdQueryBuilder = new QueryBuilder().btSchema().select().get(TableConfigurationColumnConstants.SCREEN_ID).skipTenantId(true)
                .distinct().from(TableViewsConstants.CACHE_INPUT_COMPONENT_INFO_VIEW);
        conditionMap.entrySet().stream().forEach(action -> {
            if(looper.get() > 0) {
                conditionMapBuilder.or();
            }
            conditionMapBuilder.inWithList(action.getKey(), (List<Object>) action.getValue());
            looper.getAndIncrement();
        });
        screenIdList = screenIdQueryBuilder.where(conditionMapBuilder).build(false).execute();
        screenList = screenIdList.stream().map(mapper -> mapper.get(TableConfigurationColumnConstants.SCREEN_ID).toString())
                .collect(Collectors.toList());
        return screenList;
    }

    /**
     * Gets all data elements by env info.
     *
     * @param envInfo         the env info
     * @param screenIdKeyList the screen id key list
     * @return the all data elements by env info
     */
    public static Map<String, Map<String, List<Map<String, Object>>>> getAllDataElementsByEnvInfo(EnvironmentDetailsEntity envInfo, List<Object> screenIdKeyList) throws QueryException {
        List<Map<String, Object>> inputDataElementList = getInputDataElements(screenIdKeyList, envInfo);
        if(CollectionUtils.isNotEmpty(inputDataElementList)) {
            List<Map<String, Object>> divisionEntityList = getDivisionData(envInfo);
            List<Map<String, Object>> componentAdditionalAttributeList = getComponentAdditionalAttribute(screenIdKeyList);
            return TypeConversionHelper.groupByScreenIdAndLocale(divisionEntityList, inputDataElementList,componentAdditionalAttributeList);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets server side validation.
     *
     * @param asList the as list
     * @return the server side validation
     */
    public static List<List<Map<String, Object>>> getServerSideValidation(List<Object> tableNameList) throws QueryException {
        List<Map<String, Object>> resultList;
        List<Map<String, Object>> tableConfigList;
        SelectQueryBuilder selectBuilder = new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.REDIS_BACKEND_VALIDATION_VIEW);
        SelectQueryBuilder tableConfigBuilder = new QueryBuilder().btSchema().select().get(TableConfigurationColumnConstants.TABLE_NAME, "column_name", "data_encryption_flag as data_encryption")
        		.skipTenantId(true).from(TableNamesConstants.TABLE_CONFIG_COLUMN_DETAILS);
        if(CollectionUtils.isEmpty(tableNameList)) {
            resultList = selectBuilder.build(false).execute();
            tableConfigList = tableConfigBuilder.build(false).execute();
        } else {
            resultList = selectBuilder.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.TABLE_NAME, tableNameList)).build(false).execute();
            tableConfigList = tableConfigBuilder.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.TABLE_NAME, tableNameList)).build(false).execute();
        }
        List<Map<String, Object>> divisionList = new QueryBuilder().btSchema().select()
                .from(TableViewsConstants.REDIS_DIVISION_VALIDATION_VIEW)
                .build(false).execute();
        List<List<Map<String, Object>>> returnList = new ArrayList<>();
        returnList.add(resultList);
        returnList.add(divisionList);
        returnList.add(tableConfigList);
        return returnList;
    }

    /**
     * Gets server side validation.
     *
     * @param tableList the table list
     * @param envInfo   the env info
     * @return the server side validation
     */
    public static List<List<Map<String, Object>>> getServerSideValidation(List<Object> tableNameList, EnvironmentDetailsEntity envInfo) throws QueryException {
        List<Map<String, Object>> resultList;
        List<Map<String, Object>> tableConfigList;
        SelectQueryBuilder selectBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select().skipTenantId(true).from(TableViewsConstants.REDIS_BACKEND_VALIDATION_VIEW);
        SelectQueryBuilder tableConfigBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select().get(TableConfigurationColumnConstants.TABLE_NAME, "column_name", "data_encryption")
        		.skipTenantId(true).from(TableNamesConstants.TABLE_CONFIG_COLUMN_DETAILS);
        if(CollectionUtils.isEmpty(tableNameList)) {
            resultList = selectBuilder.build(false).execute();
            tableConfigList = tableConfigBuilder.build(false).execute();
        } else {
            resultList = selectBuilder.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.TABLE_NAME, tableNameList)).build(false).execute();
            tableConfigList = tableConfigBuilder.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.TABLE_NAME, tableNameList)).build(false).execute();
        }
        List<Map<String, Object>> divisionList = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select()
                .from(TableViewsConstants.REDIS_DIVISION_VALIDATION_VIEW)
                .build(false).execute();
        List<List<Map<String, Object>>> returnList = new ArrayList<>();
        returnList.add(resultList);
        returnList.add(divisionList);
        returnList.add(tableConfigList);
        return returnList;
    }

    /**
     * Gets app gen data elements.
     *
     * @return the app gen data elements
     */
    private List<Map<String, Object>> getAppGenDataElements() throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_APP_GEN_DATA_ELEMENT_VIEW)
                .build(false).execute();
    }

    /**
     * Gets all data elements.
     *
     * @return the all data elements
     */
    public Map<String, Map<String, List<Map<String, Object>>>> getAllDataElements() throws QueryException {
        List<Map<String, Object>> inputDataElementList = getInputDataElements();
        if(CollectionUtils.isNotEmpty(inputDataElementList)) {
            List<Map<String, Object>> divisionEntityList = getDivisionData();
            List<Map<String, Object>> componentAdditionalAttributeList = getComponentAdditionalAttribute();
            return TypeConversionHelper.groupByScreenIdAndLocale(divisionEntityList, inputDataElementList ,componentAdditionalAttributeList);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets data element by screen info.
     *
     * @param screenIdKeyList the screen id key list
     * @return the data element by screen info
     */
    public Map<String, Map<String, List<Map<String, Object>>>> getDataElementByScreenInfo(List<Object> screenIdKeyList) throws QueryException {
        List<Map<String, Object>> inputDataElementList = getInputDataElementsByScreenId(screenIdKeyList);
        if(CollectionUtils.isNotEmpty(inputDataElementList)) {
        	List<Object> dataFormatList = inputDataElementList.stream().distinct()
        			.filter(predicate -> Objects.nonNull(predicate.get(TableConfigurationColumnConstants.DATA_FORMAT)))
        			.map(mapper -> mapper.get(TableConfigurationColumnConstants.DATA_FORMAT))
        			.collect(Collectors.toList());
        	     List<Object> serviceDefinitionList = inputDataElementList.stream().distinct()
        			.map(mapper -> mapper.get(TableConfigurationColumnConstants.SCREEN_DEFINITION_ID))
        			.collect(Collectors.toList());
            List<Map<String, Object>> divisionEntityList = getDivisionData(dataFormatList);
            List<Map<String, Object>> componentAdditionalAttributeList = getComponentAdditionalAttribute(serviceDefinitionList);
            return TypeConversionHelper.groupByScreenIdAndLocale(divisionEntityList, inputDataElementList,componentAdditionalAttributeList);
        }
        return Collections.emptyMap();
    }
    
    /**
     * Gets data element by screen info.
     *
     * @param screenDefType the screen definition type
     * @param screenKey        the screen key for identification
     * @return                 the data element by component definition type
     */
    public Map<String, Map<String, List<Map<String, Object>>>> getDataElementByScreenDefType(String screenDefType, String screenKey) throws QueryException {
        List<Map<String, Object>> inputDataElementList = getInputDataElementsByScreenDefType(screenDefType, screenKey);
        List<Map<String, Object>> applicationTextList = getTextDefinitionByScreenId(screenKey);
        inputDataElementList.addAll(applicationTextList);
        if(CollectionUtils.isNotEmpty(inputDataElementList)) {
        	List<Object> dataFormatList = inputDataElementList.stream().distinct()
    			.filter(predicate -> Objects.nonNull(predicate.get(TableConfigurationColumnConstants.DATA_FORMAT)))
    			.map(mapper -> mapper.get(TableConfigurationColumnConstants.DATA_FORMAT))
    			.collect(Collectors.toList());
    	     List<Object> serviceDefinitionList = inputDataElementList.stream().distinct()
    			.map(mapper -> mapper.get(TableConfigurationColumnConstants.SCREEN_DEFINITION_ID))
    			.collect(Collectors.toList());
             List<Map<String, Object>> divisionEntityList = getDivisionData(dataFormatList);
             List<Map<String, Object>> componentAdditionalAttributeList = getComponentAdditionalAttribute(serviceDefinitionList);
             return TypeConversionHelper.groupByCompKeyAndLocale(divisionEntityList, inputDataElementList,componentAdditionalAttributeList);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets data element for app generator.
     *
     * @return the data element for app generator
     */
    public Map<Object, Map<Object, List<Map<String, Object>>>> getDataElementForAppGenerator() throws QueryException {
        List<Map<String, Object>> dataElementList = getAppGenDataElements();
        if(CollectionUtils.isNotEmpty(dataElementList)) {
            List<Map<String, Object>> divisionEntityList = getDivisionData();
            return TypeConversionHelper.groupByElementIdAndLocale(divisionEntityList, dataElementList);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets data element by screen info.
     *
     * @return the data element by screen info
     */
    public Map<String, Map<String, List<Map<String, Object>>>> getDataElementByScreenInfo() throws QueryException {
        List<Map<String, Object>> inputDataElementList = getInputDataElements();
        if(CollectionUtils.isNotEmpty(inputDataElementList)) {
            List<Map<String, Object>> divisionEntityList = getDivisionData();
            List<Map<String, Object>> componentAdditionalAttributeList = getComponentAdditionalAttribute();
            return TypeConversionHelper.groupByScreenIdAndLocale(divisionEntityList, inputDataElementList,componentAdditionalAttributeList);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets table list from component def.
     *
     * @param screenId the screen id
     * @return the table list from component def
     */
    public List<String> getTableNameList(String screenId) throws QueryException {
        List<String> tableDetailList = new ArrayList<>();
        List<Map<String, Object>> tableList = new QueryBuilder().btSchema().select().skipTenantId(true)
                .get(TableConfigurationColumnConstants.COMPONENT_DEF_TABLE_NAME)
                .from(TableNamesConstants.COMPONENT_DEFINITION, "component_def")
                .join(TableNamesConstants.SCREEN_COMPONENT_CONFIGURATION, "screenCfg",
                        ConditionBuilder.instance()
                                .eq("component_def.screen_def_id", "screenCfg.screen_def_id", true).and()
                                .eq("screenCfg.screen_id", screenId).and()
                                .isNotNull(TableConfigurationColumnConstants.COMPONENT_DEF_TABLE_NAME).and()
                                .notEq(TableConfigurationColumnConstants.COMPONENT_DEF_TABLE_NAME, ""))
                .build(false).execute();
        if(CollectionUtils.isNotEmpty(tableList)) {
            tableDetailList = tableList.stream().map(mapper ->
                    String.valueOf(mapper.get(TableConfigurationColumnConstants.TABLE_NAME)))
                    .collect(Collectors.toList());
        }
        return tableDetailList;
    }

    /**
     * Gets bt table name list.
     *
     * @param dataElementList the data element list
     * @param dataFormatList   the data class list
     * @param charsetList     the charset list
     * @param masterList      the master list
     * @param envInfo         the env info
     * @return the bt table name list
     */
    public List<Object> getTableNameList(List<Object> dataElementList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList, EnvironmentDetailsEntity envInfo) throws QueryException {
        List<Map<String, Object>> resultList;
        SelectQueryBuilder selectBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema())
                .select().distinct().skipTenantId(true).from(TableViewsConstants.REDIS_BACKEND_VALIDATION_VIEW);
        ConditionBuilder conditionMapBuilder = ConditionBuilder.instance();
        AtomicInteger looper = new AtomicInteger(0);
        Map<String, Object> conditionMap = new HashMap<>();
        if(CollectionUtils.isNotEmpty(dataElementList)) {
            conditionMap.put(TableConfigurationColumnConstants.ELEMENT_ID, dataElementList);
        }
        if(CollectionUtils.isNotEmpty(dataFormatList)) {
            conditionMap.put(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList);
        }
        if(CollectionUtils.isNotEmpty(charsetList)) {
            conditionMap.put(TableConfigurationColumnConstants.CHARSET, charsetList);
        }
        if(CollectionUtils.isNotEmpty(masterList)) {
            conditionMap.put(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList);
        }
        conditionMap.entrySet().stream().forEach(action -> {
            if(looper.get() > 0) {
                conditionMapBuilder.or();
            }
            conditionMapBuilder.inWithList(action.getKey(), (List<Object>) action.getValue());
            looper.getAndIncrement();
        });
        resultList = selectBuilder.where(conditionMapBuilder).build(false).execute();
        Set<Object> dataSet = resultList.stream().map(mapper -> mapper.get(TableConfigurationColumnConstants.TABLE_NAME).toString())
                .collect(Collectors.toSet());
        return new ArrayList<>(dataSet);
    }

    /**
     * Gets bt table name list.
     *
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @param envInfo       the env info
     * @return the bt table name list
     */
    public List<Object> getTableNameList(List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList, EnvironmentDetailsEntity envInfo) throws QueryException {
        List<Map<String, Object>> resultList = new ArrayList<>();
        SelectQueryBuilder selectBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema())
                .select().distinct().skipTenantId(true).from(TableViewsConstants.REDIS_BACKEND_VALIDATION_VIEW);
        if(CollectionUtils.isNotEmpty(dataFormatList) && CollectionUtils.isNotEmpty(charsetList)
                && CollectionUtils.isNotEmpty(masterList)) {
            resultList = selectBuilder.where(ConditionBuilder.instance()
                    .inWithList(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList).or()
                    .inWithList(TableConfigurationColumnConstants.CHARSET, charsetList).or().inWithList(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList))
                    .build(false).execute();
        } else if(CollectionUtils.isNotEmpty(dataFormatList) && CollectionUtils.isNotEmpty(charsetList)) {
            resultList = selectBuilder
                    .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList)
                            .or().inWithList(TableConfigurationColumnConstants.CHARSET, charsetList))
                    .build(false).execute();
        } else if(CollectionUtils.isNotEmpty(charsetList) && CollectionUtils.isNotEmpty(masterList)) {
            resultList = selectBuilder.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList)
                    .or().inWithList(TableConfigurationColumnConstants.CHARSET, charsetList)).build(false).execute();
        } else if(CollectionUtils.isNotEmpty(masterList) && CollectionUtils.isNotEmpty(dataFormatList)) {
            resultList = selectBuilder
                    .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList)
                            .or().inWithList(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList))
                    .build(false).execute();
        } else if(CollectionUtils.isNotEmpty(dataFormatList)) {
            resultList = selectBuilder
                    .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.DATA_FORMAT, dataFormatList))
                    .build(false).execute();
        } else if(CollectionUtils.isNotEmpty(charsetList)) {
            resultList = selectBuilder.where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.CHARSET, charsetList))
                    .build(false).execute();
        } else if(CollectionUtils.isNotEmpty(masterList)) {
            resultList = selectBuilder
                    .where(ConditionBuilder.instance().inWithList(TableConfigurationColumnConstants.MASTER_SEARCH_IDS, masterList)).build(false)
                    .execute();
        }
        Set<Object> dataSet = resultList.stream().map(mapper -> mapper.get(TableConfigurationColumnConstants.TABLE_NAME).toString())
                .collect(Collectors.toSet());
        return new ArrayList<>(dataSet);
    }
    
    /**
     * Gets bt tenant definition details.
     *
     * @return the tenant list
     */
	public List<Map<String, Object>> getTenantDefinitionDetails() throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableNamesConstants.TENANT_INFO).build(false).execute();
	}
}