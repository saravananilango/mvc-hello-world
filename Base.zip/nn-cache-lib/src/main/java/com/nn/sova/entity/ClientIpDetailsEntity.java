package com.nn.sova.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * Instantiates a new client ip details entity.
 */
@Data
public class ClientIpDetailsEntity implements Serializable{

	/** The nn client id. */
	private String clientId;
	
	/** The nn user id. */
	private String userId;
	
	/** The ip address. */
	private String ipAddress;
}
