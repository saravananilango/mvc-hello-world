package com.nn.sova.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;

import com.nn.sova.constants.ClassConfigurationConstants;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.constants.UserAccountColumnConstants;
import com.nn.sova.entity.ClientDetailsEntity;
import com.nn.sova.entity.ClientIpDetailsEntity;
import com.nn.sova.entity.ClientUrlDetailsEntity;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.UserIpDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.config.EnvironmentReader;

/**
 * The type Application configuration dao.
 *
 * @author Anand Kumar
 */
public class ApplicationConfigurationDao {
    /**
     * The constant instance.
     */
    private static ApplicationConfigurationDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static ApplicationConfigurationDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new ApplicationConfigurationDao();
        }
        return instance;
    }

    /**
     * Gets class configuration data.
     *
     * @return the class configuration data
     */
    public static List<Map<String, Object>> getClassConfigurationData() throws QueryException {
        SelectQueryBuilder selectBuilder = new QueryBuilder().btSchema().select();
        return selectBuilder.from(TableNamesConstants.CLASS_CONFIGURATION).skipTenantId(true)
                .build(false).execute();
    }

    /**
     * Gets class configuration data.
     *
     * @param classIdList the class id list
     * @param entity      the entity
     * @return the class configuration data
     */
    public static List<Map<String, Object>> getClassConfigurationData(List<Object> classIdList, EnvironmentDetailsEntity entity) throws QueryException {
        SelectQueryBuilder selectBuilder = new QueryBuilder(entity.getUrl(), entity.getUser(), entity.getPassword(), entity.getSchema()).select();
        return selectBuilder.from(TableNamesConstants.CLASS_CONFIGURATION).skipTenantId(true)
                .where(ConditionBuilder.instance().inWithList(ClassConfigurationConstants.ID, classIdList)).build(false)
                .execute();
    }

    /**
     * Gets product tenant configuration list.
     *
     * @param productCode the product code
     * @return the product tenant configuration list
     */
    public static List<Map<String, Object>> getProductTenantConfigurationList(String productCode) throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableViewsConstants.REDIS_PRODUCT_TENANT_CONFIG).skipTenantId(true)
                .where(ConditionBuilder.instance().eq("product_code", productCode)).build(false).execute();
    }

    /**
     * Gets repo configuration data.
     *
     * @return the repo configuration data
     */
    public static List<Map<String, Object>> getRepoConfigurationData() throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableNamesConstants.REPO_CONFIG).build(false).execute();
    }

    /**
     * Gets tenant configuration data.
     *
     * @return the tenant configuration data
     */
    public static List<Map<String, Object>> getTenantConfigurationData() throws QueryException {
        return new QueryBuilder().btSchema().select().get("tenant_id", "tenant_name", "tenant_default_flag", "number_of_users","client_id","client_secret","independent_tenant_flag","client_code")
                .from(TableNamesConstants.TENANT_INFO).where(ConditionBuilder.instance().eq("delete_flag", false)).build(false).execute();
    }

    /**
     * Gets tenant user data.
     *
     * @param tenantId the tenant id
     * @param userId   the user id
     * @return the tenant user data
     */
    public static List<Map<String, Object>> getTenantUserData(List<Object> userIdList, String tenantId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_TENANT_USER_DETAILS_VIEW)
                .where(ConditionBuilder.instance()
                        .inWithList(UserAccountColumnConstants.USER_ID, userIdList).and()
                        .eq(UserAccountColumnConstants.TENANT_ID, tenantId))
                .build(false).execute();
    }

    /**
     * Gets tenant user data.
     *
     * @return the tenant user data
     */
    public static List<Map<String, Object>> getTenantUserData() throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableViewsConstants.REDIS_TENANT_USER_DETAILS_VIEW).build(false).execute();
    }

    /**
     * Gets landscape system definition data.
     *
     * @return the landscape system definition data
     */
    public static List<Map<String, Object>> getLandscapeSystemDefinitionData() throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableNamesConstants.LNS_SYSTEM_DEFINITION)
                .build(false).execute();
    }

    /**
     * Gets environment properties data.
     *
     * @return the environment properties data
     */
    public static List<Map<String, Object>> getEnvironmentPropertiesData() throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableNamesConstants.ENVIRONMENT_CONFIGURATION).build(false).execute();
    }

    /**
     * Gets system settings data.
     *
     * @return the system settings data
     */
    public static List<Map<String, Object>> getSystemSettingsData() throws QueryException {
        QueryBuilder queryBuilder = new QueryBuilder().btSchema();
        return queryBuilder.select().distinct()
                .get("systemSetting.system_calendar", "systemSetting.default_location",
                        "countryDefinition.date_format", "countryDefinition.time_format",
                        "countryTimeZone.timezone_id", "countryTimeZone.timezone", "country.currency_name")
                .from(TableNamesConstants.SYSTEM_SETTINGS, "systemSetting")
                .where(ConditionBuilder.instance().eq("systemSetting.system_id", "default"))
                .leftJoin(TableNamesConstants.USER_COUNTRY_DEFINITION, "countryDefinition", ConditionBuilder.instance()
                        .eq("countryDefinition.country_code", "systemSetting.default_location", true))
                .leftJoin(TableNamesConstants.COUNTRY_TIMEZONE, "countryTimeZone", ConditionBuilder.instance()
                        .eq("countryDefinition.timezone_id", "countryTimeZone.timezone_id", true))
                .leftJoin(TableNamesConstants.COUNTRY, "country", ConditionBuilder.instance()
                        .eq("countryDefinition.currency_code", "country.currency_code", true))
                .build(false).execute();
    }

    /**
     * Gets drive user space info.
     *
     * @return the drive user space info
     */
    public static List<Map<String, Object>> getDriveUserSpaceInfo() throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true).from(TableNamesConstants.DRIVE_FILE_USER_SPACE_DATA).build(false).execute();
    }

    /**
     * Gets festival holidays.
     *
     * @return the festival holidays
     */
    public static List<Map<String, Object>> getFestivalHolidays() throws QueryException {
        QueryBuilder queryBuilder = new QueryBuilder();
        return queryBuilder.btSchema().select().get("calendar_data.holiday_date").from(TableNamesConstants.HOLIDAY_CALENDAR, "calendar_data")
                .join(TableNamesConstants.USER_CALENDAR, "calandar",
                        ConditionBuilder.instance().eq("calendar_data.calendar_id", "calandar.calendar_id", true)
                                .and().eq("calandar.default_flag", true).and().eq("calendar_data.product_code", "calandar.product_code", true))
                .where(ConditionBuilder.instance().eq("calendar_data.product_code", EnvironmentReader.getProductCode())).build(false).execute();
    }

    /**
     * Gets holiday dates.
     *
     * @return the holiday dates
     */
    public static List<Map<String, Object>> getHolidayDates() throws QueryException {
        QueryBuilder queryBuilder = new QueryBuilder();
        return queryBuilder.btSchema().select()
                .from(TableNamesConstants.USER_CALENDAR, "calendar").where(ConditionBuilder.instance().eq("calendar.default_flag", true).and().eq("calendar.product_code", EnvironmentReader.getProductCode()))
                .build(false).execute();
    }

    /**
     * Gets countries phone prefix info.
     *
     * @return the countries phone prefix info
     */
    public static Map<String, Object> getCountriesPhonePrefixInfo() throws QueryException {
        Map<String, Object> dataMap = new HashMap<>();
        List<Map<String, Object>> phoneDetailList = new QueryBuilder().btSchema().select().from(TableNamesConstants.COUNTRY).orderBy("country_name", SortType.ASC).lang(true).build(false).execute();
        Map<String, Object> countryMap = new HashMap<>();
        List<Map<String, Object>> singleSelectList = new ArrayList<>();
        phoneDetailList.stream().forEach(action -> {
            Map<String, Object> detailsMap = new HashMap<>();
            Map<String, Object> singleSelectMap = new HashMap<>();
            detailsMap.put("countryLength", Objects.toString(action.get("country_number_len"), ""));
            detailsMap.put("countryPrefix", Objects.toString(action.get("country_number_prefix"), ""));
            singleSelectMap.put("label", Objects.toString(action.get("country_name"), ""));
            singleSelectMap.put("value", Objects.toString(action.get("country_code"), ""));
            singleSelectMap.put("numberPrefix", Objects.toString(action.get("country_number_prefix"), ""));
            countryMap.put(Objects.toString(action.get("country_code"), ""), detailsMap);
            singleSelectList.add(singleSelectMap);
        });
        dataMap.put("countryDetails", countryMap);
        dataMap.put("countrySelect", singleSelectList);
        return dataMap;
    }

    /**
     * Gets auto numbering data.
     *
     * @return the auto numbering data
     */
    public List<Map<String, Object>> getAutoNumberingdata() throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true).from(TableNamesConstants.AUTONUMBER_MASTER).build(false).execute();
    }
    
    /**
	 * Update client info details.
     * @param clientId 
	 *
	 * @return the list
	 * @throws QueryException the query exception
	 */
	public static List<ClientDetailsEntity> updateClientInfoDetails(String clientId) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String, Object>> clientInfo = selectQueryBuilder.from("user_client_details_view").where(ConditionBuilder.instance().eq("client_id", clientId)).build(false).execute();
		List<ClientDetailsEntity> clientDetailsList =  new ArrayList<>();
		clientInfo.stream().forEach(action->{
			ClientDetailsEntity clientDetailsEntity = new ClientDetailsEntity();
			clientDetailsEntity.setClientId(String.valueOf(action.get("client_id")));
			clientDetailsEntity.setUserId(String.valueOf(action.get("user_id")));
			clientDetailsEntity.setApiEntityName(String.valueOf(action.get("client_id")));
			clientDetailsEntity.setApiRoleName(String.valueOf(action.get("api_role_name")));
			clientDetailsEntity.setPatchMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("batch_method_access"))));
			clientDetailsEntity.setDeleteMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("delete_method_access"))));
			clientDetailsEntity.setGetMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("get_method_access"))));
			clientDetailsEntity.setPostMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("post_method_access"))));
			clientDetailsEntity.setPutMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("put_method_access"))));
			clientDetailsEntity.setApiEntityName(String.valueOf(action.get("api_entity_name")).trim());
			clientDetailsEntity.setMaxLimitPerDay(Integer.parseInt(String.valueOf(action.get("max_limit_per_day"))));
			clientDetailsEntity.setMaxLimitPerHour(Integer.parseInt(String.valueOf(action.get("max_limit_per_hour"))));
			clientDetailsEntity.setMaxLimitPerMin(Integer.parseInt(String.valueOf(action.get("max_limit_per_min"))));
			clientDetailsEntity.setMaxLimitPerSec(Integer.parseInt(String.valueOf(action.get("max_limit_per_sec"))));
			clientDetailsEntity.setMethodUrl(String.valueOf(action.get("method_url")).trim());
			clientDetailsEntity.setProductCode(String.valueOf(action.get("product_code")));
			clientDetailsEntity.setSubProductName(String.valueOf(action.get("sub_product_name")));
			clientDetailsEntity.setTenantId(String.valueOf(action.get("tenant_id")));
			clientDetailsList.add(clientDetailsEntity);
		});
		return clientDetailsList;
	}

	/**
	 * Update client ip details.
	 *
	 * @return the list
	 * @throws QueryException the query exception
	 */
	public static List<ClientIpDetailsEntity> updateClientIpDetails() throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String,Object>> clientIpDetails = selectQueryBuilder.from("client_ip_details").build(false).execute();
		List<ClientIpDetailsEntity> ipDetailsList = new ArrayList<>();
		clientIpDetails.stream().forEach(rowDataMap->{
			ClientIpDetailsEntity clientIpDetailsEntity = new ClientIpDetailsEntity();
			clientIpDetailsEntity.setClientId(String.valueOf(rowDataMap.get("client_id")));
			clientIpDetailsEntity.setUserId(String.valueOf(rowDataMap.get("user_id")));
			clientIpDetailsEntity.setIpAddress(String.valueOf(rowDataMap.get("client_ip")));
			ipDetailsList.add(clientIpDetailsEntity);
		});
		return ipDetailsList;
	}

	public static List<Map<String, Object>> getAutoumberTenantConfigurationData() throws QueryException {
		return new QueryBuilder().btSchema().select().from("autonumber_tenant_definition").skipTenantId(true).build(false).execute();
	}

	/**
	 * Update user client ip details.
	 * @param roleData 
	 *
	 * @return the list
	 * @throws QueryException the query exception
	 */
	public static List<UserIpDetailsEntity> updateUserClientIpDetails(String roleData) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String,Object>> userIpDetails = selectQueryBuilder.from("ip_range_definition_view").where(
				ConditionBuilder.instance().eq("allowed_roles", roleData)).build(false).execute();
		List<UserIpDetailsEntity> ipDetailsList = new ArrayList<>();
		userIpDetails.stream().forEach(action->{
			UserIpDetailsEntity userIpDetailsEntity = new UserIpDetailsEntity();
			userIpDetailsEntity.setTenantId(String.valueOf(action.get("tenant_id")));
			userIpDetailsEntity.setIpType(String.valueOf(action.get("ip_type")));
			userIpDetailsEntity.setIpRangeDefinition(String.valueOf(action.get("ip_range_definition")));
			userIpDetailsEntity.setAllowedRoles(String.valueOf(action.get("allowed_roles")));
			userIpDetailsEntity.setAllowedUsers(String.valueOf(action.get("allowed_users")));
			userIpDetailsEntity.setIpExclude(String.valueOf(action.get("ip_exclude")));
			userIpDetailsEntity.setIpRangePrefix(String.valueOf(action.get("ip_range_prefix")));
			userIpDetailsEntity.setIpRangeStart(String.valueOf(action.get("ip_range_start")));
			userIpDetailsEntity.setIpRangeEnd(String.valueOf(action.get("ip_range_end")));
			ipDetailsList.add(userIpDetailsEntity);
		});
		return ipDetailsList;
	}

	/**
	 * Update client ip access limit.
	 *
	 * @param clientId the client id
	 * @return the list
	 * @throws QueryException the query exception
	 */
	public static List<Map<String, Object>> updateClientIpAccessLimit(String clientId) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		return selectQueryBuilder.from("client_ip_access_limit").where(ConditionBuilder.instance().eq("client_id", clientId)).
				build(false).execute();
	}
	
	/**
	 * Update client URL access limit.
	 *
	 * @param clientId the client id
	 * @return the list
	 * @throws QueryException the query exception
	 */
	public static List<ClientUrlDetailsEntity> updateClientURLAccessLimit(String clientId) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String,Object>> urlAccessData = selectQueryBuilder.from("client_url_access_limit").where(ConditionBuilder.instance().eq("client_id", clientId)).
				build(false).execute();
		List<ClientUrlDetailsEntity> entityList = new ArrayList<ClientUrlDetailsEntity>();
		if(CollectionUtils.isNotEmpty(urlAccessData)) {
			urlAccessData.stream().forEach(action->{
				ClientUrlDetailsEntity clientUrlDetailsEntity = new ClientUrlDetailsEntity();
				clientUrlDetailsEntity.setTenantId(String.valueOf(action.get("tenant_id")));
				clientUrlDetailsEntity.setClientId(String.valueOf(action.get("client_id")));
				clientUrlDetailsEntity.setMethodUrl(String.valueOf(action.get("request_url")));
				clientUrlDetailsEntity.setMethodType(String.valueOf(action.get("method_type")));
				clientUrlDetailsEntity.setMaxLimitPerDay(Long.parseLong(String.valueOf(action.get("max_limit_per_day"))));
				clientUrlDetailsEntity.setMaxLimitPerHour(Long.parseLong(String.valueOf(action.get("max_limit_per_hour"))));
				clientUrlDetailsEntity.setMaxLimitPerMin(Long.parseLong(String.valueOf(action.get("max_limit_per_min"))));
				clientUrlDetailsEntity.setMaxLimitPerSec(Long.parseLong(String.valueOf(action.get("max_limit_per_sec"))));
				entityList.add(clientUrlDetailsEntity);
			});
		}
		return entityList;
	}
	
	/**
	 * Gets the current autonumber data.
	 *
	 * @param autonumberDefId the autonumber def id
	 * @param tableName 
	 * @param productCode 
	 * @return the current autonumber data
	 * @throws QueryException the query exception
	 */
	public static Map<String, List<Map<String, Object>>> getCurrentAutonumberData (String autonumberDefId, String productCode, String tableName) throws QueryException {
		SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema()
				.select().from("autonumber").skipTenantId(true)
				.where(ConditionBuilder.instance().eq("autonumber_def_id", autonumberDefId).and().eq("product_code", productCode).
						and().eq("table_name",tableName));
		List<Map<String, Object>> resultList = selectQueryBuilder.build(false).execute();
		if (CollectionUtils.isEmpty(resultList)) {
			return new HashMap<>();
		}
		Map<String, List<Map<String, Object>>> dataMap = resultList.stream().collect(Collectors.groupingBy(classifier-> String.valueOf(classifier.get("tenant_id"))));
		return dataMap;
	}
}
