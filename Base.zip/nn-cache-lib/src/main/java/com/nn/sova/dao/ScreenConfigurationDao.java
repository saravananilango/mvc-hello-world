package com.nn.sova.dao;

import com.nn.sova.constants.ScreenConfigurationConstants;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The type Screen configuration dao.
 *
 * @author Anand Kumar
 */
public class ScreenConfigurationDao {
	
	public static final List<String> API_DETAILS_OBJECT_COLUMNS = Arrays.asList(
            "CONCAT_WS(' ',sova_core_program_detail.mapping_url,sova_core_api_detail.method_url) as combined_url",
            "sova_core_program_detail.program_name");
	
    /**
     * Instantiates a new Screen configuration dao.
     */
    ScreenConfigurationDao(){

    }
    /**
     * The constant instance.
     */
    private static ScreenConfigurationDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static ScreenConfigurationDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new ScreenConfigurationDao();
        }
        return instance;
    }

    /**
     * Gets screen configuration data by screen map.
     *
     * @param screenIdList the screen id list
     * @return the screen configuration data by screen map
     */
    public static List<Map<String, Object>> getScreenConfigurationDataByScreen(List<Object> screenIdList) throws QueryException {
        List<Map<String, Object>> screenDefList = new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_SCREEN_AUTHENTICATE_DETAILS)
                .where(ConditionBuilder.instance()
                        .inWithList(ScreenConfigurationConstants.SCREEN_ID, screenIdList))
                .build(false).execute();
        return createScreenList(screenDefList);
    }

    /**
     * Gets screen configuration data by screen.
     *
     * @param screenIdList the screen id list
     * @param envInfo      the env info
     * @return the screen configuration data by screen
     */
    public static Object getScreenConfigurationDataByScreen(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
        List<Map<String, Object>> screenDefList = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select()
        		.skipTenantId(true)
                .from(TableViewsConstants.REDIS_SCREEN_AUTHENTICATE_DETAILS)
                .where(ConditionBuilder.instance()
                        .inWithList(ScreenConfigurationConstants.SCREEN_ID, screenIdList))
                .build(false).execute();
        return createScreenList(screenDefList);
    }

    /**
     * Gets screen component data.
     *
     * @return the screen component data
     */
    public static List<Map<String, Object>> getScreenComponentData() throws QueryException {
        return componentDefQuery().build(true).execute();
    }

    /**
     * Gets screen component definition data.
     *
     * @param screenIdList the screen id list
     * @return the screen component definition data
     */
    public static List<Map<String, Object>> getScreenComponentData(List<String> screenIdList) throws QueryException {
        return componentDefQuery().where(ConditionBuilder.instance().inWithList(ScreenConfigurationConstants.DB_COL_SCREEN_ID, Collections.singletonList(screenIdList))).build(true).execute();
    }

    /**
     * Gets screen component focus data.
     *
     * @return the screen component focus data
     */
    public static Object getScreenComponentFocusData() throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableNamesConstants.SCREEN_COMPONENT_FOCUS).build(false).execute();
    }

    /**
     * Component def query select query builder.
     *
     * @return the select query builder
     */
    private static SelectQueryBuilder componentDefQuery() {
        List<String> componentDefColumns = Arrays.asList("component_definition.screen_def_id",
                "component_definition.component_id", "component_definition.data_element",
                "component_definition.create_user", "component_definition.create_date",
                "component_definition.update_user", "component_definition.update_date",
                "component_definition.db_column", "component_definition.enabled",
                "component_definition.method_name", "component_definition.has_method_authority",
                "component_definition.table_name", "component_definition.column_name",
                ScreenConfigurationConstants.SCREEN_ID, ScreenConfigurationConstants.DB_COL_IS_DISPLAYED, ScreenConfigurationConstants.DB_COL_IS_DISUSE,
                ScreenConfigurationConstants.DB_COL_IS_READONLY
        );
        return new QueryBuilder().btSchema().select().distinct().getWithList(componentDefColumns).skipTenantId(true).from(TableNamesConstants.SCREEN_DEFINITION, "def")
                .join(TableNamesConstants.SCREEN_CONFIGURATION, "cfg",
                        ConditionBuilder.instance().eq(ScreenConfigurationConstants.DB_COL_SCREEN_DEF_ID, ScreenConfigurationConstants.DB_COL_SCREEN_DEF_ID, true))
                .join(TableNamesConstants.COMPONENT_DEFINITION, "component_definition",
                        ConditionBuilder.instance().eq("component_definition.screen_def_id",
                                ScreenConfigurationConstants.DB_COL_SCREEN_DEF_ID, true))
                .join(TableNamesConstants.SCREEN_COMPONENT_CONFIGURATION, ScreenConfigurationConstants.SCREEN_CONFIG_ALIAS_NAME,
                        ConditionBuilder.instance().eq(ScreenConfigurationConstants.DB_COL_SCREEN_ID, ScreenConfigurationConstants.DB_COL_SCREEN_ID, true).and()
                                .eq("component_definition.component_id", ScreenConfigurationConstants.DB_COL_COMPONENT_ID, true));
    }

    /**
     * Create screen list list.
     *
     * @param screenDefList the screen def list
     * @return the list
     */
    private static List<Map<String, Object>> createScreenList(List<Map<String, Object>> screenDefList) {
        return screenDefList.stream().map(value -> {
            Map<String, Object> dataMap = new HashMap<>();
            dataMap.put("screenConfiguration.screenDefId", convertData(value.get("screen_def_id")));
            dataMap.put("screenConfiguration.screenId", convertData(value.get(ScreenConfigurationConstants.SCREEN_ID)));
            dataMap.put("screenConfiguration.screenOrder", convertData(value.get("screen_order")));
            dataMap.put("screenConfigurationText.screenName", convertData(value.get("text_content")));
            dataMap.put("screenConfigurationText.locale", convertData(value.get("lang_cd")));
            dataMap.put("screenConfiguration.screenUrl", convertData(value.get("screen_url")));
            dataMap.put("screenConfiguration.applicationCode", convertData(value.get("application_code")));
            dataMap.put("screenConfiguration.isAdmin", convertData(value.get("is_admin")));
            dataMap.put("screenConfiguration.productCode", convertData(value.get("product_code")));
            dataMap.put("screenConfiguration.repoName", convertData(value.get("repo_name")));
            dataMap.put("screenConfiguration.programName", convertData(value.get("program_name")));
            dataMap.put("screenConfiguration.screenContextPath", convertData(value.get("screen_context_path")));
            return dataMap;
        }).collect(Collectors.toList());
    }

    /**
     * Convert data string.
     *
     * @param obj the obj
     * @return the string
     */
    private static String convertData(Object obj) {
        Optional<Object> optionalValue = Optional.ofNullable(obj);
        String convertedValue = StringUtils.EMPTY;
        if(optionalValue.isPresent()) {
            convertedValue = String.valueOf(optionalValue.get());
        }
        return convertedValue;
    }
    
    public static String getProgramNameByApiUrl(String apiUrl, String productCode, String subProductCode) throws QueryException {
		if(StringUtils.isNotEmpty(apiUrl) && StringUtils.isNotEmpty(productCode) && StringUtils.isNotEmpty(subProductCode)) {
		List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().getWithList(API_DETAILS_OBJECT_COLUMNS)
				.from("sova_core_program_detail", "sova_core_program_detail")
				.leftJoin("sova_core_api_detail", "sova_core_api_detail", 
				ConditionBuilder.instance().eq("sova_core_program_detail.program_id", "sova_core_api_detail.program_id", true))
				.where(ConditionBuilder.instance().isNotNull("sova_core_program_detail.mapping_url")
						.and()
						.eq("CONCAT_WS(' ',sova_core_program_detail.mapping_url,sova_core_api_detail.method_url)", apiUrl)
						.and()
						.eq("sova_core_program_detail.product_code", productCode)
						.and()
						.eq("sova_core_program_detail.sub_product_code", subProductCode)
				).build(false).execute();
			if(!dataList.isEmpty()) {
				return dataList.get(0).get("program_name").toString();
			}
		}
		return StringUtils.EMPTY;
	}
}
