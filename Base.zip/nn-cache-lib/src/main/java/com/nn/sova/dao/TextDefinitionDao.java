package com.nn.sova.dao;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * The type Text definition dao.
 *
 * @author Anand Kumar
 */
public class TextDefinitionDao {
    /**
     * Instantiates a new Text definition dao.
     */
    TextDefinitionDao(){

    }
    /**
     * The constant instance.
     */
    private static TextDefinitionDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static TextDefinitionDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new TextDefinitionDao();
        }
        return instance;
    }

    /**
     * Gets text definition data.
     *
     * @param locale  the locale
     * @param purpose the purpose
     * @return the text definition data
     */
    public static List<Map<String, Object>> getFrameworkTextDefinitionData() throws QueryException {
    	List<Map<String, Object>> textDefList;
    	textDefList = new QueryBuilder().btSchema().select().skipTenantId(true).
    			from(TableViewsConstants.CACHE_TEXT_DEF_FREMEWORK_VIEW)
    			.build(false).execute();
    	return textDefList;
    }
    /**
     * Gets text definition data.
     * @param productCode 
     *
     * @param locale  the locale
     * @param purpose the purpose
     * @return the text definition data
     */
    public static List<Map<String, Object>> getApplicationTextDefinitionData(String screenDefId) throws QueryException {
    	List<Map<String, Object>> textDefList;
    	textDefList = new QueryBuilder().btSchema().select().skipTenantId(true).
    			from(TableViewsConstants.CACHE_TEXT_DEF_APPLICATION_VIEW)
    			.where(ConditionBuilder.instance().eq("screen_definition_id",screenDefId))
    			.build(false).execute();
    	return textDefList;
    }

}
