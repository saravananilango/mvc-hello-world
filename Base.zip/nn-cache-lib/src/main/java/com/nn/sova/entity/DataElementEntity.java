package com.nn.sova.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * DataElementEntity is used to access the data element table fields
 *
 * @author Anand Kumar
 */
@Data
public class DataElementEntity implements Serializable {
    /**
     * The constant serialVersionUID.
     */
    private static final long serialVersionUID = 312792211447234521L;
    /**
     * The Id.
     */
    private String id;
    /**
     * The Data element.
     */
    private String dataElement;
    /**
     * The Domain name.
     */
    private String dataFormat;
    /**
     * The Min length.
     */
    private String minLength;
    /**
     * The Max length.
     */
    private String maxLength;
    /**
     * The Data type.
     */
    private String dataType;
    /**
     * The Element type.
     */
    private String elementType;
    /**
     * The Min val.
     */
    private String minVal;
    /**
     * The Max val.
     */
    private String maxVal;
    /**
     * The Max decimal.
     */
    private String maxDecimal;
    /**
     * The Min date.
     */
    private String minDate;
    /**
     * The Max date.
     */
    private String maxDate;
    /**
     * The Lang cd.
     */
    private String langCd;
    /**
     * The Text id.
     */
    private String textId;
    /**
     * The screen id.
     */
    private String screenId;
    /**
     * The Label.
     */
    private String label;
    /**
     * The Hint label.
     */
    private String hintLabel;
    /**
     * The Required.
     */
    private String required;
    /**
     * The Place label.
     */
    private String placeLabel;
    /**
     * The Division entity.
     */
    private List<DivisionEntity> divisionEntity;
    /**
     * The Enable chars.
     */
    private String enableChars;
    /**
     * The Disable chars.
     */
    private String disableChars;
    /**
     * The Table name.
     */
    private String tableName;
    /**
     * The Set column name.
     */
    private String setColumnName;
    /**
     * The Show column names.
     */
    private String showColumnNames;
    /**
     * The Max matches.
     */
    private String maxMatches;
    /**
     * The Master id.
     */
    private String masterId;
    /**
     * The Charset.
     */
    private List<String> charset;
    /**
     * The Db column.
     */
    private String dbcolumn;
    /**
     * The Display.
     */
    private String display;
    /**
     * The Short text.
     */
    private String shortText;
    /**
     * The Long text.
     */
    private String longText;
    /**
     * The Medium text.
     */
    private String mediumText;
    /**
     * The Disuse.
     */
    private String disuse;
    /**
     * The Readonly.
     */
    private String readonly;
    /**
     * The Initial focus.
     */
    private String initialFocus;
    /**
     * The Is underlined.
     */
    private boolean isUnderlined;
    /**
     * The Font style.
     */
    private String fontStyle;
    /**
     * The Label color.
     */
    private String labelColor;
    /**
     * The Font size.
     */
    private String fontSize;
    /**
     * The Label align.
     */
    private String labelAlign;
    /**
     * The Text color.
     */
    private String textColor;
    /**
     * The Input padding.
     */
    private String inputPadding;
    /**
     * The Label width.
     */
    private String labelWidth;
    /**
     * The Border radius.
     */
    private String borderRadius;
    /**
     * The Border color.
     */
    private String borderColor;
    /**
     * The Pattern.
     */
    private String pattern;
    /**
     * The Shortcut key.
     */
    private String shortcutKey;
    /**
     * The Disabled.
     */
    private Boolean disabled;
    /**
     * The Left border color.
     */
    private String leftBorderColor;
    /**
     * The Right border color.
     */
    private String rightBorderColor;
    /**
     * The Top border color.
     */
    private String topBorderColor;
    /**
     * The Bottom border color.
     */
    private String bottomBorderColor;
    /**
     * The Text type.
     */
    private String textType;
    /**
     * The Json data.
     */
    private String jsonData;
}
