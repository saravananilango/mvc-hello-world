package com.nn.sova.dao;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * 
 * @author georgepr
 *
 */
public enum LmsSystemDefCacheDao {
	
	INSTANCE;
	
	private static final String TABLE_NAME = "lms_system_definition";
	
	private static final String LMS_SYSTEM_ID = "lms_system_id";
	private static final String LMS_DOMAIN_NAME = "lms_domain_name";
	private static final String LMS_DEFAULT_SYSTEM = "lms_default_system";
	private static final String LMS_EXTERNAL_SYSTEM = "lms_external_system";
	private static final String SSL_FLAG = "ssl_flag";
	private static final String LMS_SYSTEM_TYPE_ID = "lms_system_type_id";
	private static final String LMS_CLOUD_PROVIDER = "lms_cloud_provider";
	private static final String LMS_REGION = "lms_region";
	private static final String LMS_SCRIPT_VERSION = "lms_script_version";
	
	public Map<String, Object> getLmsSystemDef(String systemId) throws QueryException {
		
		List<Map<String, Object>> resultList = new QueryBuilder().select()
		.get(LMS_DOMAIN_NAME)
		.get(LMS_DEFAULT_SYSTEM)
		.get(LMS_EXTERNAL_SYSTEM)
		.getWithAliasName(SSL_FLAG, "lms_" + SSL_FLAG)
		.get(LMS_SYSTEM_TYPE_ID)
		.get(LMS_CLOUD_PROVIDER)
		.get(LMS_REGION)
		.get(LMS_SCRIPT_VERSION)
		.from(TABLE_NAME)
		.where(ConditionBuilder.instance().eq(LMS_SYSTEM_ID, systemId))
		.build(false)
		.execute();
		
		return CollectionUtils.isNotEmpty(resultList) ? resultList.get(0) : Collections.emptyMap();
		
	}
}
