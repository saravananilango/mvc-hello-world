package com.nn.sova.entity;

import com.nn.sova.constants.MessageDefinitionConstants;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Map;
import java.util.Objects;

/**
 * The type Message definition entity.
 *
 * @author Anand Kumar
 */
@Data
public class MessageDefinitionEntity implements Serializable {
    /**
     * The constant serialVersionUID.
     */
    private static final long serialVersionUID = -8601236549696694737L;
    /**
     * The Message id.
     */
    private String messageId;
    /**
     * The Label id.
     */
    private String labelId;
    /**
     * The Message type.
     */
    private String messageType;
    /**
     * The Text content.
     */
    private String textContent;
    /**
     * The Lang cd.
     */
    private String langCode;
    /**
     * The Title.
     */
    private String title;
    
    /** The ok text. */
    private String okText;
    
    /** The cancel text. */
    private String cancelText;

    /**
     * Get message entity message definition entity.
     *
     * @param dataMap the data map
     * @return the message definition entity
     */
    public static MessageDefinitionEntity getMessageEntity(Map<String, Object> dataMap) {
        MessageDefinitionEntity entity = new MessageDefinitionEntity();
        entity.setLabelId(dataMap.containsKey(MessageDefinitionConstants.MESSAGE_ID) && Objects.nonNull(MessageDefinitionConstants.MESSAGE_ID) ? dataMap.get(MessageDefinitionConstants.MESSAGE_ID).toString() : StringUtils.EMPTY);
        entity.setMessageId(dataMap.containsKey(MessageDefinitionConstants.MESSAGE_ID) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.MESSAGE_ID)) ? dataMap.get(MessageDefinitionConstants.MESSAGE_ID).toString() : StringUtils.EMPTY);
        entity.setLangCode(dataMap.containsKey(MessageDefinitionConstants.LANG_CD) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.LANG_CD)) ? dataMap.get(MessageDefinitionConstants.LANG_CD).toString() : StringUtils.EMPTY);
        entity.setMessageType(dataMap.containsKey(MessageDefinitionConstants.MESSAGE_TYPE) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.MESSAGE_TYPE)) ? dataMap.get(MessageDefinitionConstants.MESSAGE_TYPE).toString() : StringUtils.EMPTY);
        entity.setTextContent(dataMap.containsKey(MessageDefinitionConstants.TEXT_CONTENT) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.TEXT_CONTENT)) ? dataMap.get(MessageDefinitionConstants.TEXT_CONTENT).toString() : StringUtils.EMPTY);
        entity.setTitle(dataMap.containsKey(MessageDefinitionConstants.TITLE) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.TITLE)) ? dataMap.get(MessageDefinitionConstants.TITLE).toString() : StringUtils.EMPTY);
        entity.setOkText(dataMap.containsKey(MessageDefinitionConstants.OK_TEXT) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.OK_TEXT)) ? dataMap.get(MessageDefinitionConstants.OK_TEXT).toString() : StringUtils.EMPTY);
        entity.setCancelText(dataMap.containsKey(MessageDefinitionConstants.CANCEL_TEXT) && Objects.nonNull(dataMap.get(MessageDefinitionConstants.CANCEL_TEXT)) ? dataMap.get(MessageDefinitionConstants.CANCEL_TEXT).toString() : StringUtils.EMPTY);
        return entity;
    }
}
