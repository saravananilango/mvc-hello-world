package com.nn.sova.constants;

/**
 * The type Text definition constants.
 *
 * @author Anand Kumar
 */
public class TextDefinitionConstants {
    /**
     * Instantiates a new Text definition constants.
     */
    TextDefinitionConstants(){

    }

    /**
     * The constant APPLICATION.
     */
    public static final String APPLICATION = "application";
    /**
     * The constant FRAMEWORK.
     */
    public static final String FRAMEWORK = "framework";
    /**
     * The constant TEXT_ID.
     */
    public static final String TEXT_ID = "text_id";
    /**
     * The constant LANG_CD.
     */
    public static final String LANG_CD = "lang_cd";
    /**
     * The constant TEXT_CONTENT.
     */
    public static final String TEXT_CONTENT = "text_content";
    /**
     * The constant TEXT.
     */
    public static final String TEXT = "text";
    /**
     * The constant PURPOSE.
     */
    public static final String PURPOSE = "purpose";
    /**
     * The constant PRODUCT_CODE.
     */
    public static final String PRODUCT_CODE = "product_code";
    /**
     * The constant TEXT_DEFINITION_ID.
     */
    public static final String TEXT_DEFINITION_ID = "text_definition_id";
    /**
     * The constant COMPONENT_ID.
     */
    public static final String COMPONENT_ID = "component_id";
    /**
     * The constant LOCALE.
     */
    public static final String LOCALE = "locale";

}
