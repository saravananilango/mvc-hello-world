package com.nn.sova.dao;

import com.nn.sova.constants.RoleConfigurationConstants;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * The type Role configuration dao.
 *
 * @author Anand Kumar
 */
public class RoleConfigurationDao {
    /**
     * Instantiates a new Role configuration dao.
     */
    RoleConfigurationDao(){

    }
    /**
     * The constant instance.
     */
    private static RoleConfigurationDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static RoleConfigurationDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new RoleConfigurationDao();
        }
        return instance;
    }

    /**
     * Gets role data by tenant id.
     *
     * @param tenantId the tenant id
     * @param roleId   the role id
     * @return the role data by tenant id
     */
    public static List<Map<String, Object>> getRoleDataByTenantId(String tenantId, String roleId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.REDIS_TENANT_ROLE_SETTING_VIEW)
                .where(ConditionBuilder.instance().eq("\"roleSetting.roleId\"", roleId).and().eq("\"roleSetting.tenantId\"", tenantId)).build(false).execute();
    }

    /**
     * Gets role data by tenant id.
     *
     * @return the role data by tenant id
     * @throws QueryException the query exception
     */
    public static List<Map<String, Object>> getRoleDataByTenantId() throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableViewsConstants.REDIS_TENANT_ROLE_SETTING_VIEW).build(false).execute();
    }

    /**
     * Gets authorized screens by role id.
     *
     * @param roleId the role id
     * @return the authorized screens by role id
     */
    public static List<Map<String, Object>> getAuthorizedScreensByRoleId(String roleId) throws QueryException {
        return new QueryBuilder().btSchema().select().from(TableViewsConstants.REDIS_TENANT_AUTHORITY_SCREEN_VIEW)
                .where(ConditionBuilder.instance().eq("role_id", roleId))
                .build(false).execute();
    }

    /**
     * Gets screen role link data.
     *
     * @param tenantId the tenant id
     * @param roleId   the role id
     * @return the screen role link data
     */
    public static List<Map<String, Object>> getTenantScreenRoleLinkData(String tenantId, String roleId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_TENANT_SCREEN_ROLE_LINK_SETTING_VIEW)
                .where(ConditionBuilder.instance().eq("\"screenRoleSetting.roleId\"", roleId).and().eq("\"screenRoleSetting.tenantId\"", tenantId))
                .build(false).execute();
    }

    /**
     * Gets screen role link data.
     *
     * @param roleId the role id
     * @return the screen role link data
     */
    public static List<Map<String, Object>> getScreenRoleLinkData(String roleId) throws QueryException {
        return createScreenRoleLinkSelectStatementQuery()
                .where(ConditionBuilder.instance().eq(RoleConfigurationConstants.SCREEN_ROLE_SETTING_ROLE_ID, roleId))
                .build(true).execute();
    }

    /**
     * Create screen role link select statement query select query builder.
     *
     * @return the select query builder
     */
    private static SelectQueryBuilder createScreenRoleLinkSelectStatementQuery() {
        return new QueryBuilder().btSchema().select().distinct()
                .get("security_object.order", "screen_role_setting.screen_id",
                        RoleConfigurationConstants.SCREEN_ROLE_SETTING_ROLE_ID, RoleConfigurationConstants.SECURITY_CODE,
                        "screen_role_setting.created_user")
                .from(TableNamesConstants.SCREEN_ROLE_SETTING, "screen_role_setting")
                .leftJoin(TableNamesConstants.SECURITY_OBJECT, "security_object", ConditionBuilder.instance()
                        .eq(RoleConfigurationConstants.SECURITY_CODE, "security_object.security_code", true));
    }

    /**
     * Gets all tenant screen role link.
     *
     * @return the all tenant screen role link
     * @throws QueryException the query exception
     */
    public static List<Map<String, Object>> getAllTenantScreenRoleLink() throws QueryException {
        return new QueryBuilder().btSchema().select()
                .from(TableViewsConstants.REDIS_TENANT_SCREEN_ROLE_LINK_SETTING_VIEW)
                .build(false).execute();
    }

    /**
     * Gets roles linked with user id.
     *
     * @param userId the user id
     * @return the roles linked with user id
     */
    public static List<Map<String, Object>> getRolesLinkedWithUserId(String userId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .get(RoleConfigurationConstants.USER_ID,
                        RoleConfigurationConstants.ROLE_ID)
                .from(TableNamesConstants.ROLE_LINK_SETTING)
                .where(ConditionBuilder.instance().eq(RoleConfigurationConstants.USER_ID, userId))
                .build(true).execute();
    }

    /**
     * Gets roles linked with user id.
     *
     * @param tenantId the tenant id
     * @param userId   the user id
     * @return the roles linked with user id
     */
    public static List<Map<String, Object>> getRolesLinkedWithUserId(String tenantId, List<Object> userId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true)
                .from(TableViewsConstants.REDIS_TENANT_ROLE_LINK_SETTING_VIEW)
                .where(ConditionBuilder.instance().eq("\"roleLinkSetting.userId\"", userId.get(0)).and()
                        .eq("\"roleLinkSetting.tenantId\"", tenantId))
                .build(false).execute();
    }

    /**
     * Gets all roles linked with user id.
     *
     * @return the all roles linked with user id
     * @throws QueryException the query exception
     */
    public static List<Map<String, Object>> getAllRolesLinkedWithUserId() throws QueryException {
        return new QueryBuilder().btSchema().select()
                .from(TableViewsConstants.REDIS_TENANT_ROLE_LINK_SETTING_VIEW)
                .build(false).execute();
    }
}