package com.nn.sova.service.application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.constants.ClassConfigurationConstants;
import com.nn.sova.constants.CommonConstants;
import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.constants.UserAccountColumnConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.ApplicationConfigurationDao;
import com.nn.sova.dao.PaymentGatewayDao;
import com.nn.sova.dao.TableConfigurationDao;
import com.nn.sova.entity.ClientDetailsEntity;
import com.nn.sova.entity.ClientIpDetailsEntity;
import com.nn.sova.entity.ClientUrlDetailsEntity;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.entity.UserIpDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Application configuration cache service.
 *
 * @author Anand Kumar
 */
public class ApplicationConfigurationCacheService {
	/**
	 * The constant logger.
	 */
	private static final ApplicationLogger logger = ApplicationLogger.create(ApplicationConfigurationCacheService.class);
	
	/** MAP_TYPE_MAP_REFERENCE. */
	private static final TypeReference<Map<String, Map<String, Object>>> MAP_TYPE_MAP_REFERENCE = new TypeReference<Map<String, Map<String, Object>>>() {
	};
	/**
	 * The constant instance.
	 */
	private static ApplicationConfigurationCacheService instance = null;
	
	private static final String USER_IP_RANGE_DETAILS = "_user_ip_range_def_details_";

	/**
	 * Instantiates a new Locale cache service.
	 */
	private ApplicationConfigurationCacheService() {
	}

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static ApplicationConfigurationCacheService getInstance() {
		if(Objects.isNull(instance)) {
			instance = new ApplicationConfigurationCacheService();
		}
		return instance;
	}

	/**
	 * Update class configuration data.
	 */
	public void updateClassConfigurationData() throws QueryException {
		List<Map<String, Object>> classDataList = ApplicationConfigurationDao.getClassConfigurationData();
		if(CollectionUtils.isNotEmpty(classDataList)) {
			String prefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
			classDataList.stream().forEach(value ->
			CacheManager.getInstance().saveAsObject(
					prefixKey.concat(value.get(ClassConfigurationConstants.ID).toString()),
					value.get(ClassConfigurationConstants.CLASSPATH).toString())
					);
		}else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND + "[All Class Configuration data]");
		}
	}

	/**
	 * Update class configuration data.
	 *
	 * @param classIdList the class id list
	 * @param entity      the entity
	 */
	public void updateClassConfigurationData(List<Object> classIdList, EnvironmentDetailsEntity entity) throws QueryException {
		List<Map<String, Object>> classDataList = ApplicationConfigurationDao.getClassConfigurationData(classIdList, entity);
		RedisEnvInfo envInfo = TypeConversionHelper.getRedisNode(entity);
		if(CollectionUtils.isNotEmpty(classDataList)) {
			String prefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
			classDataList.stream().forEach(value ->
			CacheManager.getInstance().saveAsObjectWithEnvInfo(
					prefixKey.concat(value.get(ClassConfigurationConstants.ID).toString()),
					value.get(ClassConfigurationConstants.CLASSPATH).toString(),
					envInfo)
					);
		}else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND + "[Class Configuration data by classIdList and entity]");
		}
	}

	/**
	 * Gets product by user id.
	 *
	 * @param userId the user id
	 * @return the product by user id
	 */
	public String getProductByUserId(String userId) {
		String value = (String) CacheManager.getInstance().getWithObject(userId);
		if(StringUtils.isNotEmpty(value)) return value;
		return "";
	}

	/**
	 * Update product by user id.
	 *
	 * @param cacheKey    the cache key
	 * @param productCode the product code
	 */
	public void updateProductByUserId(String cacheKey, String productCode) {
		CacheManager.getInstance().saveAsObject(cacheKey, productCode);
	}

	/**
	 * Gets product tenant configuration details.
	 *
	 * @param cacheKey    the cache key
	 * @param productCode the product code
	 * @return the product tenant configuration details
	 */
	@SuppressWarnings("unchecked")
	public List<String> getProductTenantConfigurationDetails(String cacheKey, String productCode) throws QueryException {
		List<String> productTenantConfigurationList = (List<String>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(productTenantConfigurationList)) {
			return productTenantConfigurationList;
		}
		return updateProductTenantConfigurationDetails(productCode);
	}

	/**
	 * Update product tenant configuration details.
	 *
	 * @param productCode the product code
	 * @return 
	 */
	private static List<String> updateProductTenantConfigurationDetails(String productCode) throws QueryException {
		String cacheKey = CacheKeyHelper.getProductTenantConfigurationPrefixKey().concat(productCode);
		List<Map<String, Object>> productTenantConfigurationList = ApplicationConfigurationDao.getProductTenantConfigurationList(productCode);
		if(CollectionUtils.isNotEmpty(productTenantConfigurationList)) {
			List<String> productList = TypeConversionHelper.remapProductConfigurationData(productTenantConfigurationList);
			CacheManager.getInstance().saveAsObject(cacheKey, productList);
			return productList;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * Gets repo configuration data.
	 *
	 * @param cacheKey the cache key
	 * @return the repo configuration data
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getRepoConfigurationData(String cacheKey) throws QueryException {
		List<Map<String, Object>> repoConfigurationList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(repoConfigurationList)) {
			return repoConfigurationList;
		}
		return updateRepoConfigurationData();
	}

	/**
	 * Update repo configuration data.
	 * @return 
	 */
	private static List<Map<String, Object>> updateRepoConfigurationData() throws QueryException {
		String cacheKey = CacheKeyHelper.getRepoConfigurationKey();
		List<Map<String, Object>> repoConfigurationList = ApplicationConfigurationDao.getRepoConfigurationData();
		if(CollectionUtils.isNotEmpty(repoConfigurationList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, repoConfigurationList);
			return repoConfigurationList;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * Gets tenant configuration data.
	 *
	 * @param cacheKey the cache key
	 * @return the tenant configuration data
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getTenantConfigurationData(String cacheKey) throws QueryException {
		List<Map<String, Object>> tenantConfigurationList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(tenantConfigurationList)) {
			return tenantConfigurationList;
		}
		return updateTenantConfigurationData();
	}

	/**
	 * Update tenant configuration data.
	 * @return 
	 */
	private static List<Map<String, Object>> updateTenantConfigurationData() throws QueryException {
		String cacheKey = CacheKeyHelper.getTenantConfigurationDataKey();
		List<Map<String, Object>> tenantConfigurationList = ApplicationConfigurationDao.getTenantConfigurationData();
		if(CollectionUtils.isNotEmpty(tenantConfigurationList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, tenantConfigurationList);
			return tenantConfigurationList;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * Gets tenant user data.
	 *
	 * @param cacheKey the cache key
	 * @param tenantId the tenant id
	 * @param userId   the user id
	 * @return the tenant user data
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getTenantUserData(String cacheKey, String tenantId, String userId) throws QueryException {
		Map<String, Object> tenantUserDataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(tenantUserDataMap)) {
			return tenantUserDataMap;
		}
		return updateTenantUserData(userId, tenantId);
	}

	/**
	 * Update tenant user data.
	 *
	 * @param tenantId the tenant id
	 * @param userId   the user id
	 * @return 
	 */
	private static Map<String, Object> updateTenantUserData(String userId, String tenantId) throws QueryException {
		String prefixKey = CacheKeyHelper.getTenantUserPrefixKey();
		String cacheKey = prefixKey.concat(tenantId).concat(CacheKeyHelper.DELIMITER).concat(userId);
		List<Map<String, Object>> userDataList = ApplicationConfigurationDao.getTenantUserData(Collections.singletonList(userId), tenantId);
		if(CollectionUtils.isNotEmpty(userDataList)) {
			List<Map<String, Object>> userList = TypeConversionHelper.remapUserData(userDataList);
			CacheManager.getInstance().saveAsObject(cacheKey, userList.get(0));
			CacheService.getInstance().saveToCache(CacheKeyHelper.getUserPreferenceRandomKey(tenantId, userId), UUID.randomUUID());
			return userList.get(0);
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}

	/**
	 * Gets landscape system definition data.
	 *
	 * @param cacheKey the cache key
	 * @return the landscape system definition data
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getLandscapeSystemDefinitionData(String cacheKey) throws QueryException {
		List<Map<String, Object>> systemDefinitionDataList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(systemDefinitionDataList)) {
			return systemDefinitionDataList;
		}
		return updateLandscapeSystemDefinitionData();
	}

	/**
	 * Update landscape system definition data.
	 * @return 
	 */
	private static List<Map<String, Object>> updateLandscapeSystemDefinitionData() throws QueryException {
		List<Map<String, Object>> systemDefinitionDataList = ApplicationConfigurationDao.getLandscapeSystemDefinitionData();
		String cacheKey = CacheKeyHelper.getLandscapeSystemDefinitionKey();
		if(CollectionUtils.isNotEmpty(systemDefinitionDataList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, systemDefinitionDataList);
			return systemDefinitionDataList;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * Gets environment properties.
	 *
	 * @param cacheKey the cache key
	 * @return the environment properties
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getEnvironmentProperties(String cacheKey) throws QueryException {
		Map<String, Object> environmentPropertiesMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(environmentPropertiesMap)) {
			return environmentPropertiesMap;
		}
		return updateEnvironmentProperties();
	}

	/**
	 * Update environment properties.
	 * @return 
	 */
	private static Map<String, Object> updateEnvironmentProperties() throws QueryException {
		List<Map<String, Object>> environmentPropertiesList = ApplicationConfigurationDao.getEnvironmentPropertiesData();
		String cacheKey = CacheKeyHelper.getEnvironmentPropertiesKey();
		if(CollectionUtils.isNotEmpty(environmentPropertiesList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, environmentPropertiesList.get(0));
			return environmentPropertiesList.get(0);
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}

	/**
	 * Gets system settings data.
	 *
	 * @param cacheKey the cache key
	 * @return the system settings data
	 */
	public Object getSystemSettingsData(String cacheKey) throws QueryException {
		Object systemSettings = CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(systemSettings)) {
			return systemSettings;
		}
		return updateSystemSettingsData();
	}

	/**
	 * Update system settings data.
	 * @return 
	 */
	private static Object updateSystemSettingsData() throws QueryException {
		List<Map<String, Object>> systemSettingsList = ApplicationConfigurationDao.getSystemSettingsData();
		String cacheKey = CacheKeyHelper.getSystemSettingsKey();
		if(CollectionUtils.isNotEmpty(systemSettingsList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, systemSettingsList.get(0));
			return systemSettingsList.get(0);
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}

	/**
	 * Gets drive user space info.
	 *
	 * @param cacheKey the cache key
	 * @return the drive user space info
	 */
	public Object getDriveUserSpaceInfo(String cacheKey) throws QueryException {
		Object driveInfo = CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(driveInfo)) {
			return driveInfo;
		}
		return updateDriveUserSpaceInfo();
	}

	/**
	 * Update drive user space info.
	 * @return 
	 */
	private static Object updateDriveUserSpaceInfo() throws QueryException {
		String cacheKey = CacheKeyHelper.getSystemSettingsKey();
		List<Map<String, Object>> driveInfoList = ApplicationConfigurationDao.getDriveUserSpaceInfo();
		if(CollectionUtils.isNotEmpty(driveInfoList)) {
			Map<String, List<Map<String, Object>>> dataMap = driveInfoList.stream().collect(Collectors.groupingBy(c -> String.valueOf(c.get(CommonConstants.TENANT_ID))));
			CacheManager.getInstance().saveAsObject(cacheKey, dataMap);
			return dataMap;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}

	/**
	 * Gets festival holidays.
	 *
	 * @param cacheKey the cache key
	 * @return the festival holidays
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getFestivalHolidays(String cacheKey) throws QueryException {
		List<Map<String, Object>> festivalHolidays = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(festivalHolidays)) {
			return festivalHolidays;
		}
		return updateFestivalHolidays();
	}

	/**
	 * Update festival holidays.
	 * @return 
	 */
	private static List<Map<String, Object>> updateFestivalHolidays() throws QueryException {
		List<Map<String, Object>> festivalHolidayList = ApplicationConfigurationDao.getFestivalHolidays();
		String cacheKey = CacheKeyHelper.getFestivalHolidaysKey();
		if(CollectionUtils.isNotEmpty(festivalHolidayList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, festivalHolidayList);
			return festivalHolidayList;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * Gets holiday dates.
	 *
	 * @param cacheKey the cache key
	 * @return the holiday dates
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getHolidayDates(String cacheKey) throws QueryException {
		List<Map<String, Object>> holidayDates = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(holidayDates)) {
			return holidayDates;
		}
		return updateHolidayDates();
	}

	/**
	 * Update holiday dates.
	 * @return 
	 */
	private static List<Map<String, Object>> updateHolidayDates() throws QueryException {
		String cacheKey = CacheKeyHelper.getHolidayDatesKey();
		List<Map<String, Object>> holidaysList = ApplicationConfigurationDao.getHolidayDates();
		if(CollectionUtils.isNotEmpty(holidaysList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, holidaysList);
			return holidaysList;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * Gets countries phone prefix info.
	 *
	 * @param cacheKey the cache key
	 * @return the countries phone prefix info
	 */
	public Object getCountriesPhonePrefixInfo(String cacheKey) throws QueryException {
		Object countryPhonePrefixObj = CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(countryPhonePrefixObj)) {
			return countryPhonePrefixObj;
		}
		return updateCountriesPhonePrefixInfo();
	}

	/**
	 * Update countries phone prefix info.
	 * @return 
	 */
	private static Object updateCountriesPhonePrefixInfo() throws QueryException {
		String cacheKey = CacheKeyHelper.getCountriesPhonePrefixInfoKey();
		Map<String, Object> countryPhonePrefixMap = ApplicationConfigurationDao.getCountriesPhonePrefixInfo();
		if(MapUtils.isNotEmpty(countryPhonePrefixMap)) {
			CacheManager.getInstance().saveAsObject(cacheKey, countryPhonePrefixMap);
			return countryPhonePrefixMap;
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}

	/**
	 * Gets user image path.
	 *
	 * @param userDataMap the user data map
	 * @param userId      the user id
	 * @return the user image path
	 */
	public String getUserImagePath(Map<String, Object> userDataMap, String userId) {
		if(MapUtils.isNotEmpty(userDataMap) && Objects.nonNull(userDataMap.get(CommonConstants.PICTURE_PATH))
				&& StringUtils.isNotEmpty(userDataMap.get(CommonConstants.PICTURE_PATH).toString())) {
			return userDataMap.get(CommonConstants.PICTURE_PATH).toString();
		} else {
			return "/img/".concat(userId).concat(".JPG");
		}
	}

	/**
	 * Update tenant user data.
	 */
	public void updateTenantUserData() throws QueryException {
		String prefixKey = CacheKeyHelper.getTenantUserPrefixKey();
		List<Map<String, Object>> userDataList = ApplicationConfigurationDao.getTenantUserData();
		if(CollectionUtils.isNotEmpty(userDataList)) {
			List<Map<String, Object>> userList = TypeConversionHelper.remapUserData(userDataList);
			userList.stream().forEach(mapper ->
			CacheManager.getInstance().saveAsObject(prefixKey
					.concat(mapper.get(UserAccountColumnConstants.TENANT_ID).toString())
					.concat(CacheKeyHelper.DELIMITER)
					.concat(mapper.get(UserAccountColumnConstants.USER_ID).toString()), mapper)
					);
		}else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND + ": Tenant User Data");
		}
	}

	/**
	 * Update tenant user data.
	 *
	 * @param userIdList the user id list
	 * @param tenantId   the tenant id
	 */
	public void updateTenantUserData(List<Object> userIdList, String tenantId) throws QueryException {
		List<Map<String, Object>> userDataList = ApplicationConfigurationDao.getTenantUserData(userIdList, tenantId);
		if(CollectionUtils.isNotEmpty(userDataList)) {
			String prefixKey = CacheKeyHelper.getTenantUserPrefixKey();
			List<Map<String, Object>> userList = TypeConversionHelper.remapUserData(userDataList);
			userList.stream().forEach(mapper ->
			CacheManager.getInstance().saveAsObject(prefixKey
					.concat(mapper.get(UserAccountColumnConstants.TENANT_ID).toString())
					.concat(CacheKeyHelper.DELIMITER)
					.concat(mapper.get(UserAccountColumnConstants.USER_ID).toString()), mapper)
					);
		}else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND + ": Tenant User Data ");
		}
	}

	/**
	 * Update tenant user data.
	 *
	 * @param userId   the user id
	 * @param tenantId the tenant id
	 * @param userMap  the user map
	 */
	public void updateTenantUserData(String userId, String tenantId, Map<String, Object> userMap) {
		String prefixKey = CacheKeyHelper.getTenantUserPrefixKey();
		String cacheKey = prefixKey
				.concat(tenantId)
				.concat(CacheKeyHelper.DELIMITER)
				.concat(userId);
		if(MapUtils.isNotEmpty(userMap)) {
			CacheManager.getInstance().saveAsObject(cacheKey, userMap);
		}else{
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * Update tenant user data.
	 *
	 * @param userIdList the user id list
	 */
	public void updateTenantUserData(List<Object> userIdList) throws QueryException {
		List<Map<String, Object>> userDataList = ApplicationConfigurationDao.getTenantUserData(userIdList, null);
		if(CollectionUtils.isNotEmpty(userDataList)) {
			String prefixKey = CacheKeyHelper.getTenantUserPrefixKey();
			List<Map<String, Object>> userList = TypeConversionHelper.remapUserData(userDataList);
			userList.stream().forEach(mapper ->
			CacheManager.getInstance().saveAsObject(prefixKey
					.concat(mapper.get(UserAccountColumnConstants.TENANT_ID).toString())
					.concat(CacheKeyHelper.DELIMITER)
					.concat(mapper.get(UserAccountColumnConstants.USER_ID).toString()), mapper)
					);
		}else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND + ": Tenant User data");
		}
	}

	/**
	 * Update tenant user data.
	 *
	 * @param userId the user id
	 */
	public void updateTenantUserData(String userId) throws QueryException {
		List<Map<String, Object>> userDataList = ApplicationConfigurationDao.getTenantUserData(Collections.singletonList(userId), null);
		if(CollectionUtils.isNotEmpty(userDataList)) {
			String prefixKey = CacheKeyHelper.getTenantUserPrefixKey();
			List<Map<String, Object>> userList = TypeConversionHelper.remapUserData(userDataList);
			userList.stream().forEach(mapper ->
			CacheManager.getInstance().saveAsObject(
					prefixKey
					.concat(mapper.get(UserAccountColumnConstants.TENANT_ID).toString())
					.concat(CacheKeyHelper.DELIMITER)
					.concat(mapper.get(UserAccountColumnConstants.USER_ID).toString()),
					mapper)
					);
		}else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND + ": Tenant User Data by user Id");
		}
	}

	/**
	 * Remove environment properties from cache.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeEnvironmentPropertiesFromCache(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove environment properties from cache.
	 *
	 * @param cacheKey the cache key
	 * @param envInfo  the env info
	 */
	public void removeEnvironmentPropertiesFromCache(String cacheKey, EnvironmentDetailsEntity envInfo) {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
		CacheManager.getInstance().deleteKeyWithEnvInfo(cacheKey, redisInfo);
	}

	/**
	 * Remove archive search setting.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeArchiveSearchSetting(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove auto numbering.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeAutoNumbering(String cacheKey) throws QueryException {
		List<Map<String, Object>> dataList = ApplicationConfigurationDao.getInstance().getAutoNumberingdata();
		List<String> keysList = dataList.stream().map(mapper -> Objects.toString(mapper.get("autonumber_def_id"))).collect(Collectors.toList());
		keysList.replaceAll(cacheKey::concat);
		CacheManager.getInstance().del(keysList.toArray(new String[keysList.size()]));
	}

	/**
	 * Remove auto numbering.
	 *
	 * @param cacheKey the cache key
	 * @param keyList  the key list
	 */
	public void removeAutoNumbering(String cacheKey, List<String> keyList) {
		List<String> autoNumberList = new ArrayList<>(keyList);
		autoNumberList.replaceAll(cacheKey::concat);
		CacheManager.getInstance().del(autoNumberList.toArray(new String[autoNumberList.size()]));
	}

	/**
	 * Remove auto numbering.
	 *
	 * @param cacheKey the cache key
	 * @param keyList  the key list
	 * @param entity   the entity
	 */
	public void removeAutoNumbering(String cacheKey, List<String> keyList, EnvironmentDetailsEntity entity) {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(entity);
		List<String> autoNumberList = new ArrayList<>(keyList);
		autoNumberList.replaceAll(cacheKey::concat);
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(autoNumberList.toArray(new String[autoNumberList.size()]), redisInfo);
	}
	
	/**
	 * Remove class configuration.
	 *
	 * @param cacheKey the cache key
	 * @param id       the id
	 */
	public void removeClassConfiguration(String cacheKey, String id) {
		CacheManager.getInstance().deleteKey(cacheKey.concat(id));
	}
	
	/**
	 * Remove class configuration.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param idList         the id list
	 */
	public void removeClassConfiguration(String cachePrefixKey, List<Object> idList) {
		List<Object> classIdList = new ArrayList<>(idList);
		classIdList.replaceAll(id -> cachePrefixKey.concat(String.valueOf(id)));
		CacheManager.getInstance().del(classIdList.toArray(new String[classIdList.size()]));
	}	

	/**
	 * Remove class configuration.
	 *
	 * @param cacheKey the cache key
	 * @param id       the id
	 * @param entity   the entity
	 */
	public void removeClassConfiguration(String cacheKey, String id, EnvironmentDetailsEntity entity) {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(entity);
		CacheManager.getInstance().deleteKeyWithEnvInfo(cacheKey.concat(id), redisInfo);
	}

	/**
	 * Remove class configuration.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param idList         the id list
	 * @param entity         the entity
	 */
	public void removeClassConfiguration(String cachePrefixKey, List<Object> idList, EnvironmentDetailsEntity entity) {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(entity);
		List<Object> classIdList = new ArrayList<>(idList);
		classIdList.replaceAll(id -> cachePrefixKey.concat(String.valueOf(id)));
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(classIdList.toArray(new String[classIdList.size()]), redisInfo);
	}

	/**
	 * Remove landscape system definition.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeLandscapeSystemDefinition(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove phone details.
	 *
	 * @param cacheKey the cache key
	 */
	public void removePhoneDetails(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove drive file user space.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeDriveFileUserSpace(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove system setting.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeSystemSetting(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove repo config details.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeRepoConfigDetails(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove holidays.
	 */
	public void removeHolidays() {
		CacheManager.getInstance().deleteKey(CacheKeyHelper.getFestivalHolidaysKey());
		CacheManager.getInstance().deleteKey(CacheKeyHelper.getHolidayDatesKey());
	}

	/**
	 * Remove tenant user data.
	 *
	 * @param userId   the user id
	 * @param tenantId the tenant id
	 */
	public void removeTenantUserData(String userId, String tenantId) {
		String prefixCacheKey = CacheKeyHelper.getTenantUserPrefixKey();
		CacheManager.getInstance().deleteKey(prefixCacheKey.concat(tenantId).concat(CacheKeyHelper.DELIMITER).concat(userId.toLowerCase()));
	}

	/**
	 * Remove product tenant config.
	 *
	 * @param productCode the product code
	 */
	public void removeProductTenantConfig(String productCode) {
		String prefixCacheKey = CacheKeyHelper.getProductTenantConfigurationPrefixKey();
		CacheManager.getInstance().deleteKey(prefixCacheKey.concat(productCode));
	}

	/**
	 * Remove users.
	 *
	 * @param userIdList the user id list
	 */
	public void removeUsers(List<Object> userIdList) {
		String prefixCacheKey = CacheKeyHelper.getUserAccountPrefixKey();
		userIdList.replaceAll(user -> prefixCacheKey.concat(user.toString().toLowerCase()));
		CacheManager.getInstance().del(userIdList.toArray(new String[userIdList.size()]));
	}

	/**
	 * Gets the client info details.
	 *
	 * @param cacheKey the cache key
	 * @return the client info details
	 * @throws QueryException the query exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getClientInfoDetails(String clientId) throws QueryException {
		
		String cacheKey = ContextBean.getTenantId().concat("_").concat(clientId)+"_client_details_info";
		logger.info("Cache Key :" + cacheKey);
		Map<String, Object> clientDetails = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(clientDetails)) {
			logger.info("Client Details from cache :" + clientDetails);
			return clientDetails;
		}
		return updateClientInfoDetails(clientId);
	}

	/**
	 * Update client info details.
	 * @return 
	 *
	 * @throws QueryException the query exception
	 */
	private Map<String, Object> updateClientInfoDetails(String clientId) throws QueryException {
		List<ClientDetailsEntity> clientDetailsList = ApplicationConfigurationDao.updateClientInfoDetails(clientId);
		logger.info("Client Info List :" + clientDetailsList);
		Map<String, List<ClientDetailsEntity>> clientGroup = clientDetailsList.stream().collect(Collectors.groupingBy(ClientDetailsEntity::getClientId));
		logger.info("Client Group :" + clientGroup);
		Map<String,Object> cacheClientMap = new HashMap<>();
		clientGroup.entrySet().forEach(clientGroupMap->{
			Map<String,Object> individualClientDataMap = new HashMap<>();
			Map<String,List<ClientDetailsEntity>> roleGroupMap = clientGroupMap.getValue().stream().collect(Collectors.groupingBy(ClientDetailsEntity::getApiRoleName));
			Set<String> apiRoleList = new HashSet<>();
			roleGroupMap.entrySet().forEach(action->{
				apiRoleList.add(action.getKey());
			});
			individualClientDataMap.put("api_role_list", apiRoleList);

			Map<String,List<ClientDetailsEntity>> methodUrlMap = clientGroupMap.getValue().stream().collect(Collectors.groupingBy(ClientDetailsEntity::getMethodUrl));
			logger.info("Method URL Map :"+ methodUrlMap);
			Map<String,Set<String>> methodUrlMapData = new HashMap<>();
			methodUrlMap.entrySet().forEach(action->{
				Map<String,List<ClientDetailsEntity>> entityGroup = action.getValue().stream().collect(Collectors.groupingBy(ClientDetailsEntity::getApiEntityName));
				logger.info("Entity group :" + entityGroup);
				Set<String> accessGroupList =  new HashSet<>();
				entityGroup.entrySet().forEach(entity->{
					entity.getValue().stream().forEach(data->{
						if(data.isGetMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_READ");
						}
						if(data.isPostMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_POST");
						}
						if(data.isPutMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_PUT");
						}
						if(data.isDeleteMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_DELETE");
						}
						if(data.isPatchMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_PATCH");
						}
					});
				});
				methodUrlMapData.put(action.getKey().toLowerCase().trim(), accessGroupList);	
			});
			individualClientDataMap.put("entity_access_list", methodUrlMapData);
			individualClientDataMap.put(clientGroupMap.getKey(),clientGroupMap.getValue().get(0));
			cacheClientMap.put(clientGroupMap.getKey().toString(), individualClientDataMap);
		});
		logger.info("Client Details Info :" + cacheClientMap);
		if(MapUtils.isNotEmpty(cacheClientMap)) {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId().concat("_").concat(clientId)+"_client_details_info", cacheClientMap);
			return cacheClientMap;
		}else {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId().concat("_").concat(clientId)+"_client_details_info", Collections.emptyMap());
			return Collections.emptyMap();
		}
		
	}

	/**
	 * Gets the client info details.
	 *
	 * @param cacheKey the cache key
	 * @return the client info details
	 * @throws QueryException the query exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Map<String, Object>> getClientIpDetails(String cacheKey) throws QueryException {
		Map<String,Map<String,Object>> clientIpDetails = (Map<String, Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(clientIpDetails)) {
			return clientIpDetails;
		}
		return updateClientIpDetails();
	}

	/**
	 * Update client ip details.
	 * @return 
	 *
	 * @throws QueryException the query exception
	 */
	private Map<String, Map<String, Object>> updateClientIpDetails() throws QueryException {
		List<ClientIpDetailsEntity> clientDetailsList = ApplicationConfigurationDao.updateClientIpDetails();
		Map<String ,List<ClientIpDetailsEntity>> clientGroup = clientDetailsList.stream().collect(Collectors.groupingBy(ClientIpDetailsEntity::getClientId));
		Map<String,Map<String,Object>> cacheIpMap = new HashMap<>();
		clientGroup.entrySet().forEach(action->{
			Map<String,Object> dataMap = new HashMap<>();
			Map<String,List<ClientIpDetailsEntity>> ipGroup = action.getValue().stream().collect(Collectors.groupingBy(ClientIpDetailsEntity::getIpAddress));
			List<String> ipAddressList = new ArrayList<>();
			ipGroup.entrySet().forEach(map->{
				ipAddressList.add(map.getKey());
				dataMap.put("user_id", map.getValue().get(0).getUserId());
			});

			dataMap.put("client_id", action.getKey());
			dataMap.put("ip_address", ipAddressList);
			cacheIpMap.put(action.getKey(), dataMap);
		});
		if(MapUtils.isNotEmpty(cacheIpMap)) {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId()+"_client_ip_info", cacheIpMap);
			return cacheIpMap;
		}else {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId()+"_client_ip_info", Collections.emptyMap());
			return Collections.emptyMap();
		}
		
	}
	/**
	 * getAutoumberTenantConfigurationData
	 * @param cacheKey
	 * @param tenantId 
	 * @param autonumber 
	 * @return
	 * @throws QueryException 
	 */
	public Map<String, Object> getAutoumberTenantConfigurationData(String cacheKey, String autonumber, String tenantId) throws QueryException {
		if(!CacheManager.getInstance().isKeyExists(cacheKey)) {
			updateAutoumberTenantConfigurationData(cacheKey);
		}
		Map<String,List<Map<String, Object>>> autonumberMap = (Map<String,List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(autonumberMap.isEmpty()) {
			return Collections.emptyMap();
		}
		if(autonumberMap.containsKey(autonumber)) {
			List<Map<String,Object>> autoNumberList = autonumberMap.get(autonumber).stream().filter(predicate -> predicate.get("tenant_id").equals(tenantId)).collect(Collectors.toList());
			if(autoNumberList.isEmpty()) {
				logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
				return Collections.emptyMap();
			}else {
				return autoNumberList.get(0);
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return Collections.emptyMap();
	}
	/**
	 * updateAutoumberTenantConfigurationData 
	 * @param cacheKey
	 * @throws QueryException 
	 */
	private void updateAutoumberTenantConfigurationData(String cacheKey) throws QueryException {
		List<Map<String,Object>> autonumberTenantData = ApplicationConfigurationDao.getAutoumberTenantConfigurationData();
		Map<String, List<Map<String, Object>>> autonumberMap = autonumberTenantData.stream().collect(Collectors.groupingBy(mapper -> String.valueOf(mapper.get("autonumber_def_id"))));
		CacheManager.getInstance().saveAsObject(cacheKey,autonumberMap);
	}


	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getUserIpRangeDetails(String roleData) throws QueryException {
		String cacheKey = ContextBean.getTenantId().concat(USER_IP_RANGE_DETAILS).concat(roleData);
		List<Map<String,Object>> userIpDetails =  (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(userIpDetails)) {
			return userIpDetails;
		}
		getUserIpAccessInfo(roleData);
		userIpDetails =  (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(userIpDetails)) {
			return userIpDetails;
		}
		return Collections.emptyList();
	}

	/**
	 * Gets the user ip access info.
	 * @param roleData 
	 * @param tenantId 
	 *
	 * @return the user ip access info
	 * @throws QueryException the query exception
	 */
	public void getUserIpAccessInfo(String roleData) throws QueryException {
		List<UserIpDetailsEntity> clientDetailsList = ApplicationConfigurationDao.updateUserClientIpDetails(roleData);

		if(CollectionUtils.isNotEmpty(clientDetailsList)) {

			Map<String,List<UserIpDetailsEntity>> allowedRolesGroup = 
					clientDetailsList.stream().collect(Collectors.groupingBy(UserIpDetailsEntity::getAllowedRoles));
			
			allowedRolesGroup.entrySet().stream().forEach(action->{
				List<Map<String,Object>> allowedRoleListIp = new ArrayList<>();
				Map<String,List<UserIpDetailsEntity>> allowedUsersGroup = action.getValue().stream().collect(Collectors.groupingBy(UserIpDetailsEntity::getAllowedUsers));
				
				action.getValue().stream().forEach(entityData->{
					Map<String,Object> specificDataMap = new HashMap<>();
					specificDataMap.put("ip_range_definition",entityData.getIpRangeDefinition());
					specificDataMap.put("ip_range_prefix",entityData.getIpRangePrefix());
					specificDataMap.put("ip_range_start",entityData.getIpRangeStart());
					specificDataMap.put("ip_range_end",entityData.getIpRangeEnd());
					specificDataMap.put("ip_exclude",entityData.getIpExclude());
					specificDataMap.put("ip_type",entityData.getIpType());
					List<String> usersList = new ArrayList<>(); 
					if(MapUtils.isNotEmpty(allowedUsersGroup)) {
						usersList.addAll(allowedUsersGroup.keySet());
					}
					specificDataMap.put("allowed_user",entityData.getAllowedUsers());
					allowedRoleListIp.add(specificDataMap);
				});
				CacheService.getInstance().saveToCache(ContextBean.getTenantId().concat(USER_IP_RANGE_DETAILS).concat(action.getKey()), allowedRoleListIp);
			});
		}else {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId().concat(USER_IP_RANGE_DETAILS).concat(roleData), Collections.emptyList());
		}
	
	}

	/**
	 * Gets the client ip access limit.
	 *
	 * @param clientId the client id
	 * @return the client ip access limit
	 * @throws QueryException the query exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getClientIpAccessLimit(String clientId) throws QueryException {
		Map<String,Object> userIpAccessLimit = (Map<String, Object>) CacheManager.getInstance().getWithObject(ContextBean.getTenantId()+"_client_ip_access_limit_"+clientId);
		if(Objects.nonNull(userIpAccessLimit)) {
			return userIpAccessLimit;
		}
		return updateClientIpAccessLimit(clientId);
	}

	/**
	 * Update client ip access limit.
	 *
	 * @param clientId the client id
	 * @return 
	 * @throws QueryException the query exception
	 */
	private Map<String, Object> updateClientIpAccessLimit(String clientId) throws QueryException {
		List<Map<String, Object>> clientIpAccessLimit = ApplicationConfigurationDao.updateClientIpAccessLimit(clientId);
		Map<String,Object> ipAccessLimitMap = new HashMap<>();
		if(CollectionUtils.isNotEmpty(clientIpAccessLimit)) {
			clientIpAccessLimit.stream().forEach(action->{
				ipAccessLimitMap.put(String.valueOf(action.get("client_ip_address")),action);
			});
			CacheService.getInstance().saveToCache(ContextBean.getTenantId()+"_client_ip_access_limit_"+clientId, ipAccessLimitMap);
			return ipAccessLimitMap;
		}else {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId()+"_client_ip_access_limit_"+clientId, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}



	/**
	 * Gets the client URL access limit.
	 *
	 * @param clientId the client id
	 * @return the client URL access limit
	 * @throws QueryException the query exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getClientURLAccessLimit(String clientId) throws QueryException {
		Map<String,Object> urlAccessLimit = (Map<String, Object>) CacheManager.getInstance().getWithObject(ContextBean.getTenantId()+"_client_url_access_limit_"+clientId);
		if(Objects.nonNull(urlAccessLimit)) {
			return urlAccessLimit;
		}
		return updateClientURLAccessLimit(clientId);
	}

	/**
	 * Update client URL access limit.
	 *
	 * @param clientId the client id
	 * @return 
	 * @throws QueryException the query exception
	 */
	private Map<String, Object> updateClientURLAccessLimit(String clientId) throws QueryException {
		List<ClientUrlDetailsEntity> clientUrlAccessLimit = ApplicationConfigurationDao.updateClientURLAccessLimit(clientId);

		if(CollectionUtils.isNotEmpty(clientUrlAccessLimit)) {

			Map<String,List<ClientUrlDetailsEntity>> urlGroup = clientUrlAccessLimit.stream().collect(Collectors.groupingBy(ClientUrlDetailsEntity::getMethodUrl));

			Map<String,Object> urlCacheMap = new HashMap<>();
			
			urlGroup.entrySet().stream().forEach(action->{
				Map<String,List<ClientUrlDetailsEntity>> methoTypeGroup = action.getValue().stream().collect(Collectors.groupingBy(ClientUrlDetailsEntity::getMethodType));
				
					Map<String,Object> methodMap = new HashMap<>();
					
					methoTypeGroup.entrySet().forEach(methodTypeMap->{
						List<ClientUrlDetailsEntity> entity = methodTypeMap.getValue();
						
						entity.stream().forEach(data->{
							Map<String,Object> cacheMap = new HashMap<>();
							cacheMap.put("tenant_id", data.getTenantId());
							cacheMap.put("client_id", data.getClientId());
							cacheMap.put("method_type", data.getMethodType());
							cacheMap.put("request_url", data.getMethodUrl());
							cacheMap.put("max_limit_per_day", data.getMaxLimitPerDay());
							cacheMap.put("max_limit_per_hour", data.getMaxLimitPerHour());
							cacheMap.put("max_limit_per_min", data.getMaxLimitPerHour());
							cacheMap.put("max_limit_per_sec", data.getMaxLimitPerSec());
							methodMap.put(methodTypeMap.getKey().toUpperCase(), cacheMap);
						});
					});
					
					urlCacheMap.put(action.getKey(), methodMap);
			});
			CacheService.getInstance().saveToCache(ContextBean.getTenantId()+"_client_url_access_limit_"+clientId, urlCacheMap);
			return urlCacheMap;
		}else {
			CacheService.getInstance().saveToCache(ContextBean.getTenantId()+"_client_url_access_limit_"+clientId, Collections.emptyMap());
			return Collections.emptyMap();
		}
	}

	/**
	 * Gets the tenant definition details from cache.
	 *
	 * @param cacheKey the cache key
	 * @param tenantId the tenant Id
	 * @return Map
	 * @throws QueryException the query exception
	 */
	public Map<String, Object> getTenantDefinitionData(String cacheKey, String tenantId) throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, Map<String, Object>> resultMap = JsonUtils.fromJsonOrElse(JsonUtils.toJsonOrEmpty(cacheValue),
					MAP_TYPE_MAP_REFERENCE, new HashMap<>());
			if (MapUtils.isNotEmpty(resultMap) && resultMap.containsKey(tenantId)) {
				return resultMap.get(tenantId);
			}
		}
		CacheManager.getInstance().deleteKey(cacheKey);
		updateTenantDefinitionDetails(cacheKey);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, Map<String, Object>> resultMap = JsonUtils.fromJsonOrElse(JsonUtils.toJsonOrEmpty(cacheValue),
					MAP_TYPE_MAP_REFERENCE, new HashMap<>());
			if (MapUtils.isNotEmpty(resultMap) && resultMap.containsKey(tenantId)) {
				return resultMap.get(tenantId);
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return new HashMap<>();
	}
	
	private void updateTenantDefinitionDetails(String cacheKey) throws QueryException {
		List<Map<String, Object>> resultList = TableConfigurationDao.getInstance().getTenantDefinitionDetails();
		if (CollectionUtils.isNotEmpty(resultList)) {
			Map<String, Map<String, Object>> resultMap = resultList.stream()
					.collect(Collectors.toMap(record -> String.valueOf(record.get("tenant_id")), record -> record));

			CacheManager.getInstance().saveAsObject(cacheKey, resultMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}
	
	/**
	 * Gets the current autonumber data.
	 *
	 * @param cacheKey the cache key
	 * @param autonumberDefId the autonumber def id
	 * @param tenantId the tenant id
	 * @param tableName 
	 * @param productCode 
	 * @return the current autonumber data
	 * @throws QueryException the query exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getCurrentAutonumberData (String cacheKey ,String autonumberDefId,String tenantId, String productCode, String tableName) throws QueryException {
		if(!CacheManager.getInstance().isKeyExists(cacheKey)) {
			insertAutonumberCurrentData(cacheKey, autonumberDefId,productCode,tableName);
		}
		Map<String, List<Map<String, Object>>> autonumberMap = (Map<String,List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(autonumberMap.isEmpty()) {
			return Collections.emptyMap();
		}
		if(autonumberMap.containsKey(tenantId)) {
			List<Map<String, Object>> autoNumberList = autonumberMap.get(tenantId);
			if(autoNumberList.isEmpty()) {
				logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
				return Collections.emptyMap();
			}else {
				return autoNumberList.get(0);
			}
		}else {
			insertAutonumberCurrentData(cacheKey, autonumberDefId,productCode,tableName);
			autonumberMap = (Map<String,List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
			if(autonumberMap.isEmpty()) {
				return Collections.emptyMap();
			}
			if(autonumberMap.containsKey(tenantId)) {
				List<Map<String, Object>> autoNumberList = autonumberMap.get(tenantId);
				if(autoNumberList.isEmpty()) {
					logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
					return Collections.emptyMap();
				}else {
					return autoNumberList.get(0);
				}
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return Collections.emptyMap();
	}

	/**
	 * Update autonumber current data.
	 *
	 * @param cacheKey the cache key
	 * @param autonumberDefId the autonumber def id
	 * @param tableName 
	 * @param productCode 
	 * @throws QueryException the query exception
	 */
	private void insertAutonumberCurrentData(String cacheKey, String autonumberDefId, String productCode, String tableName) throws QueryException {
		Map<String, List<Map<String, Object>>> autonumberData = ApplicationConfigurationDao.getCurrentAutonumberData(autonumberDefId,productCode,tableName);
		CacheManager.getInstance().saveAsObject(cacheKey,autonumberData);
	}
	
	/**
	 * Update current autonumber data.
	 *
	 * @param cacheKey the cache key
	 * @param autonumberDefId the autonumber def id
	 * @param tenantId the tenant id
	 * @param updatedAutoNumberMap the updated auto number map
	 * @param tableName 
	 * @param productCode 
	 * @throws QueryException the query exception
	 */
	@SuppressWarnings("unchecked")
	public void updateCurrentAutonumberData (String cacheKey ,String autonumberDefId,String tenantId, Map<String, Object> updatedAutoNumberMap, String productCode, String tableName) throws QueryException {
		if(MapUtils.isEmpty(updatedAutoNumberMap)) {
			return;
		}
		if(!CacheManager.getInstance().isKeyExists(cacheKey)) {
			insertAutonumberCurrentData(cacheKey, autonumberDefId,productCode,tableName);
		}
		Map<String, List<Map<String, Object>>> autonumberMap = (Map<String,List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(MapUtils.isEmpty(autonumberMap)) {
			autonumberMap =  new HashMap<>();
		}
		if(autonumberMap.containsKey(tenantId)) {
			List<Map<String, Object>> autoNumberList = autonumberMap.get(tenantId);
			if(autoNumberList.isEmpty()) {
				autoNumberList.add(updatedAutoNumberMap);
			}else {
				autoNumberList.get(0).putAll(updatedAutoNumberMap);
			}
		}else {
			autonumberMap.put(tenantId, Arrays.asList(updatedAutoNumberMap));
		}
		CacheManager.getInstance().saveAsObject(cacheKey,autonumberMap);
	}

	/**
	 * Removes the current autonumber data.
	 *
	 * @param cacheKey the cache key
	 * @param autonumberDefId the autonumber def id
	 * @param tenantId the tenant id
	 */
	@SuppressWarnings("unchecked")
	public void removeCurrentAutonumberData(String cacheKey, String autonumberDefId, String tenantId) {
		if(!CacheManager.getInstance().isKeyExists(cacheKey)) {
			return;
		}
		Map<String, List<Map<String, Object>>> autonumberMap = (Map<String,List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
		if(MapUtils.isEmpty(autonumberMap)) {
			return;
		}
		if(autonumberMap.containsKey(tenantId)) {
			autonumberMap.remove(tenantId);
			CacheManager.getInstance().saveAsObject(cacheKey,autonumberMap);
		}else {
			return;
		}
	}
}

