package com.nn.sova.constants;

/**
 * The type User account column constants.
 * @author Anand Kumar
 */
public class UserAccountColumnConstants {
    /**
     * Instantiates a new User account column constants.
     */
    UserAccountColumnConstants(){

    }
    /**
     * The constant API_TOKEN.
     */
    public static final String API_TOKEN = "api_token";
    /**
     * The constant ADDRESS.
     */
    public static final String ADDRESS = "address";
    /**
     * The constant BIRTHDAY.
     */
    public static final String BIRTHDAY = "birthday";
    /**
     * The constant BLOOD_GROUP.
     */
    public static final String BLOOD_GROUP = "blood_group";
    /**
     * The constant COUNTRY.
     */
    public static final String COUNTRY = "country";
    /**
     * The constant CURRENCY_FORMAT.
     */
    public static final String CURRENCY_FORMAT = "currency_format";
    /**
     * The constant DATE_FORMAT.
     */
    public static final String DATE_FORMAT = "date_format";
    /**
     * The constant EMAIL_FOR_PSWD_RECOVERY.
     */
    public static final String EMAIL_FOR_PSWD_RECOVERY = "email_for_password_recovery";
    /**
     * The constant EMP_NO.
     */
    public static final String EMP_NO = "emp_no";
    /**
     * The constant EXTENSION_NUMBER.
     */
    public static final String EXTENSION_NUMBER = "extension_number";
    /**
     * The constant FIRST_NAME.
     */
    public static final String FIRST_NAME = "first_name";
    /**
     * The constant IS_ADMIN_USER.
     */
    public static final String IS_ADMIN_USER = "is_admin_user";
    /**
     * The constant IS_LDAP_USER.
     */
    public static final String IS_LDAP_USER = "is_ldap_user";
    /**
     * The constant LAST_LOGINED_DATE_TIME.
     */
    public static final String LAST_LOGINED_DATE_TIME = "last_logined_date_time";
    /**
     * The constant LAST_NAME.
     */
    public static final String LAST_NAME = "last_name";
    /**
     * The constant LAST_PSWD_FAILED_DATE_TIME.
     */
    public static final String LAST_PSWD_FAILED_DATE_TIME = "last_password_failed_date_time";
    /**
     * The constant LAST_USED_LOCALE.
     */
    public static final String LAST_USED_LOCALE = "last_used_locale";
    /**
     * The constant LAST_USED_TIME_ZONE.
     */
    public static final String LAST_USED_TIME_ZONE = "last_used_time_zone";
    /**
     * The constant LAST_ZONED_DATE_TIME.
     */
    public static final String LAST_ZONED_DATE_TIME = "last_zoned_date_time";
    /**
     * The constant LOCALE.
     */
    public static final String LOCALE = "locale";
    /**
     * The constant LANG_CD.
     */
    public static final String LANG_CODE = "lang_code";
    /**
     * The constant DISPLAY_ORDER.
     */
    public static final String DISPLAY_ORDER = "display_order";
    /**
     * The constant LANG_TEXT.
     */
    public static final String LANG_TEXT = "lang_text";
    /**
     * The constant MAIL.
     */
    public static final String MAIL = "email";
    /**
     * The constant PHONE_NUMBER.
     */
    public static final String PHONE_NUMBER = "phone_number";
    /**
     * The constant PICTURE_PATH.
     */
    public static final String PICTURE_PATH = "picture_path";
    /**
     * The constant PSWD.
     */
    public static final String PSWD = "password";
    /**
     * The constant PSWD_FAILED.
     */
    public static final String PSWD_FAILED = "password_failed";
    /**
     * The constant STATUS.
     */
    public static final String STATUS = "status";
    /**
     * The constant TIME_FORMAT.
     */
    public static final String TIME_FORMAT = "time_format";
    /**
     * The constant TIME_ZONE.
     */
    public static final String TIME_ZONE = "time_zone";
    /**
     * The constant DB_COL_USER_ID.
     */
    public static final String DB_COL_USER_ID = "userAccount.user_id";
    /**
     * The constant USER_ID.
     */
    public static final String USER_ID = "user_id";
    /**
     * The constant TENANT_ID.
     */
    public static final String TENANT_ID = "tenant_id";
    /**
     * The constant ROLE_ID.
     */
    public static final String ROLE_ID = "role_id";
    /**
     * The constant IS_FULL_AUTHORITY.
     */
    public static final String IS_FULL_AUTHORITY = "is_full_authority";
}
