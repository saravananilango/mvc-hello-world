package com.nn.sova.constants;

/**
 * The type Common constants.
 *
 * @author Anand Kumar
 */
public class CommonConstants {
    /**
     * Instantiates a new Class configuration constants.
     */
    CommonConstants(){

    }
    /**
     * The constant NULL.
     */
    public static final String NULL = "null";
    /**
     * The constant TRUE.
     */
    public static final String TRUE = "true";
    /**
     * The constant FALSE.
     */
    public static final String FALSE = "false";
    /**
     * The constant TENANT_ID.
     */
    public static final String TENANT_ID = "tenant_id";
    /**
     * The constant PICTURE_PATH.
     */
    public static final String PICTURE_PATH = "picture_path";
}
