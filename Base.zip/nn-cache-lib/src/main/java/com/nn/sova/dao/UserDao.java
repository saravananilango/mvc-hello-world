package com.nn.sova.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.postgresql.util.PGobject;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.ini.IniService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type User dao.
 *
 * @author Mohammed Shameer U
 */
public class UserDao {
	/** The constant instance. */
	private static UserDao instance = null;

	/** The constant logger. */
	private static final ApplicationLogger logger = ApplicationLogger.create(UserDao.class);

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static UserDao getInstance() {
		if (Objects.isNull(instance)) {
			instance = new UserDao();
		}
		return instance;
	}

	/**
	 * getUserFavourites is used to get the user menu data.
	 * 
	 * @param userId
	 * @return
	 * @throws QueryException
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getUserFavourites() throws QueryException {
		Map<String, Object> iniMap = new HashMap<>();
		iniMap.put("ini_key", "menu_favourites");
		List<Map<String, Object>> menuList = IniService.getInstance().getIniDataByKey(iniMap);
		if (CollectionUtils.isNotEmpty(menuList)) {
			return (List<Object>) menuList.get(0).get("ini_object");
		} else {
			return Collections.emptyList();
		}
	}

	/**
	 * getUserRecents is used to get the user recent menu data.
	 * 
	 * @param userId
	 * @return
	 * @throws QueryException
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getUserRecents() throws QueryException {
		Map<String, Object> iniMap = new HashMap<>();
		iniMap.put("ini_key", "menu_recents");
		List<Map<String, Object>> menuList = IniService.getInstance().getIniDataByKey(iniMap);
		if (CollectionUtils.isNotEmpty(menuList)) {
			return (List<Object>) menuList.get(0).get("ini_object");
		} else {
			return Collections.emptyList();
		}
	}

	/**
	 * getUserMenuData is used to get the user menu data from the daabase.
	 * 
	 * @param locale
	 * @param roleList
	 * @param tableName
	 * @param columnName
	 * @return
	 */
	public List<Map<String, Object>> getUserMenuData(String locale, List<String> roleList, String tableName,
			String columnName) {
		QueryBuilder menuQuery = new QueryBuilder().btSchema();
		try {
			return menuQuery.select().from(tableName)
					.where(ConditionBuilder.instance().eq("lang_code", locale).and().inWithList(columnName, (List)roleList)
							.and().eq("tenant_id", ContextBean.getTenantId()))
					.orderBy("menu_order", SortType.ASC)
					.build(false).execute();
		} catch (QueryException exception) {
			logger.error("Exception occured while getting menu data", exception);
		}
		return Collections.emptyList();
	}
	
	/**
	 * getUserRoleMenuData to fetch the user role
	 * 
	 * @param locale
	 * @param role
	 * @param tableName
	 * @param columnName
	 * 	 
	 */
	public List<Map<String, Object>> getUserRoleMenuData(String locale, String role, String tableName,
			String columnName) {
		QueryBuilder menuQuery = new QueryBuilder().btSchema();
		try {
			return menuQuery.select().from(tableName)
					.where(ConditionBuilder.instance().eq("lang_code", locale).and().eq(columnName, role)
							.and().eq("tenant_id", ContextBean.getTenantId()))
					.orderBy("menu_order", SortType.ASC)
					.build(false).execute();
		} catch (QueryException exception) {
			logger.error("Exception occured while getting menu data", exception);
		}
		return Collections.emptyList();
	}
	
	/**
	 * getTemplateData is used to get the theme data.
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getTemplateData(String themeCode) {
		try {
			List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().get("json_value").from("theme_detail")
					.where(ConditionBuilder.instance().eq("theme_code", themeCode)).skipTenantId(true).build(false).execute();
			if (CollectionUtils.isNotEmpty(dataList) && Objects.nonNull(dataList.get(0).get("json_value"))) {
				return JsonUtils.fromJsonOrNull(((PGobject) dataList.get(0).get("json_value")).getValue(), Map.class);
			}
		} catch (QueryException exception) {
			logger.error("Exception occured while getting template data", exception);
		}
		return Collections.emptyMap();
	}

	/**
	 * getProductCodeTemplateData is used to get the product code template data.
	 * 
	 * @param tenantId
	 * @param productCode
	 * @return
	 */
	public Map<String, Object> getProductCodeTemplateData(String tenantId, String productCode) {
		try {
			List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().get("theme_link.product_code", "theme_detail.json_value")
					.from("theme_tenant_product_link", "theme_link").leftJoin("theme_detail", "theme_detail", ConditionBuilder.instance()
							.eq("theme_detail.theme_code", "theme_link.theme_code", true).and().eq("theme_link.product_code", productCode))
					.where(ConditionBuilder.instance().brackets(ConditionBuilder.instance().eq("theme_link.tenant_id", tenantId).and()
							.eq("theme_link.product_code", productCode)).or().brackets(ConditionBuilder.instance().eq("theme_link.tenant_id", tenantId).and()
									.eq("theme_link.product_code", tenantId))).skipTenantId(true).build(false).execute();
			if (CollectionUtils.isNotEmpty(dataList)) {
				if (dataList.size() == 1) {
					return JsonUtils.fromJsonOrNull(((PGobject) dataList.get(0).get("json_value")).getValue(), Map.class);
				} else {
					List<Map<String, Object>> filteredList = dataList.stream().filter(predicate -> String.valueOf(predicate.get("product_code"))
							.equals(productCode)).collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(filteredList)) {
						return JsonUtils.fromJsonOrNull(((PGobject) filteredList.get(0).get("json_value")).getValue(), Map.class);
					}
				}
			}
		} catch (QueryException exception) {
			logger.error("Exception occured while getting product data", exception);
		}
		return Collections.emptyMap();
	}
	
	/**
	 * getDefaultTemplateData is used to get the default template data.
	 * 
	 * @return
	 */
	public Map<String, Object> getDefaultTemplateData() {
		try {
			List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().get("json_value").from("theme_detail")
					.where(ConditionBuilder.instance().eq("theme_code", "sova")).skipTenantId(true).build(false).execute();
			if (CollectionUtils.isNotEmpty(dataList) && Objects.nonNull(dataList.get(0).get("json_value"))) {
				return JsonUtils.fromJsonOrNull(((PGobject) dataList.get(0).get("json_value")).getValue(), Map.class);
			}
		} catch (QueryException exception) {
			logger.error("Exception occured while getting template data", exception);
		}
		return Collections.emptyMap();
	}
	
 	/**
 	 * 
 	 * @param debugMode
 	 * @throws QueryException
 	 */
 	public void updateDebugMode(boolean debugMode) throws QueryException {
 		new QueryBuilder().btSchema()
 				.update().into("user_account", "is_debug").where(ConditionBuilder.instance()
 						.eq("tenant_id", ContextBean.getTenantId()).and().eq("user_id", ContextBean.getUserId()))
 				.build().execute(debugMode);
 	}
}