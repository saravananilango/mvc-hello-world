package com.nn.sova.service.screen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;

import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.constants.ScreenDefinitionConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.ScreenDefinitonDao;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.entity.ScreenDefinitionEntity;
import com.nn.sova.entity.ServiceRestrictionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Screen def cache service.
 *
 * @author Anand Kumar
 */
public class ScreenDefinitionCacheService {
	/**
	 * The constant logger.
	 */
	private static final ApplicationLogger logger = ApplicationLogger.create(ScreenDefinitionCacheService.class);
	/**
	 * The constant instance.
	 */
	private static ScreenDefinitionCacheService instance = null;
	/**
	 * Instantiates a new Screen def cache service.
	 */
	private ScreenDefinitionCacheService() {
	}

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static ScreenDefinitionCacheService getInstance() {
		if(Objects.isNull(instance)) {
			instance = new ScreenDefinitionCacheService();
		}
		return instance;
	}

	/**
	 * Gets screen by def id.
	 *
	 * @param screenDefId the screen def id
	 * @return the screen by def id
	 */
	public String getScreenByDefId(String screenDefId) throws QueryException {
		List<Map<String, Object>> screenList = ScreenDefinitonDao.getScreensByDefId(screenDefId);
		if(CollectionUtils.isNotEmpty(screenList)) {
			return screenList.get(0).get(ScreenDefinitionConstants.SCREEN_ID).toString();
		}
		return screenDefId;
	}

	/**
	 * Gets screen definition data by locale.
	 *
	 * @param cacheKey the cache key
	 * @param screenId the screen id
	 * @param locale   the locale
	 * @return the screen definition data by locale
	 */
	@SuppressWarnings("unchecked")
	public ScreenDefinitionEntity getScreenDefinitionDataByLocale(String cacheKey, String screenId, String locale) throws QueryException {
		Map<String, Object> screenDefinitionMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(screenDefinitionMap)) {
			return TypeConversionHelper.convertScreenDefMapToEntity(screenDefinitionMap, locale);
		}
		updateScreenDefinitionData(Arrays.asList(screenId));
		screenDefinitionMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.nonNull(screenDefinitionMap)) {
			return TypeConversionHelper.convertScreenDefMapToEntity(screenDefinitionMap, locale);
		}
		return null;
	}

	/**
	 * Update screen definition data.
	 *
	 * @param screenIdList the screen id list
	 */
	public void updateScreenDefinitionData(List<Object> screenIdList) throws QueryException {
		Map<String, Map<String, List<ScreenDefinitionEntity>>> screenDefinitionMap = ScreenDefinitonDao.getScreenDefinitionDataByScreen(screenIdList);
		if(Objects.nonNull(screenDefinitionMap) && !screenDefinitionMap.isEmpty()) {
			for (Map.Entry<String, Map<String, List<ScreenDefinitionEntity>>> screenMap : screenDefinitionMap.entrySet()) {
				String cacheKey = CacheKeyHelper.getScreenDefinitionPrefixKey().concat(screenMap.getKey());
				CacheManager.getInstance().saveAsObject(cacheKey, screenMap.getValue());
			}
		} else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * Update screen definition data.
	 */
	public void updateScreenDefinitionData() throws QueryException {
		Map<String, Map<String, List<ScreenDefinitionEntity>>> screenDefinitionMap = ScreenDefinitonDao.getScreenDefinitionDataByScreen();
		if(Objects.nonNull(screenDefinitionMap) && !screenDefinitionMap.isEmpty()) {
			for (Map.Entry<String, Map<String, List<ScreenDefinitionEntity>>> screenMap : screenDefinitionMap.entrySet()) {
				String cacheKey = CacheKeyHelper.getScreenDefinitionPrefixKey().concat(screenMap.getKey());
				CacheManager.getInstance().saveAsObject(cacheKey, screenMap);
			}
		} else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * Update screen definition data.
	 *
	 * @param screenIdList the screen id list
	 * @param envinfo      the envinfo
	 */
	public void updateScreenDefinitionData(List<Object> screenIdList, EnvironmentDetailsEntity envinfo) throws QueryException {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envinfo);
		Map<String, Map<String, List<ScreenDefinitionEntity>>> screenDefinitionMap = ScreenDefinitonDao.getScreenDefinitionDataByScreenList(screenIdList, envinfo);
		if(Objects.nonNull(screenDefinitionMap) && !screenDefinitionMap.isEmpty()) {
			for (Map.Entry<String, Map<String, List<ScreenDefinitionEntity>>> screenMap : screenDefinitionMap.entrySet()) {
				String cacheKey = CacheKeyHelper.getScreenDefinitionPrefixKey().concat(screenMap.getKey());
				CacheManager.getInstance().saveAsObjectWithEnvInfo(cacheKey, screenMap, redisInfo);
			}
		} else{
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * Remove tenant authority screen.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param roleId         the role id
	 * @param tenantId       the tenant id
	 */
	public void removeAuthorizedScreensByTenantId(String cachePrefixKey, String roleId, String tenantId) {
		CacheManager.getInstance().deleteKey(cachePrefixKey.concat(tenantId).concat(roleId));
	}

	/**
	 * Remove tenant authority screen.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param roleIdList     the role id list
	 */
	public void removeTenantAuthorityService(String cachePrefixKey, List<Object> roleIdList) {
		List<Object> roleList = new ArrayList<>(roleIdList);
		roleList.replaceAll(role -> cachePrefixKey.concat(ContextBean.getTenantId()).concat(role.toString()));
		CacheManager.getInstance().del(roleList.toArray(new String[roleList.size()]));
	}

	/**
	 * Remove tenant screen role link.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param roleId         the role id
	 * @param tenantId       the tenant id
	 */
	public void removeTenantScreenRoleLink(String cachePrefixKey, String roleId, String tenantId) {
		CacheManager.getInstance().deleteKey(cachePrefixKey.concat(tenantId).concat(roleId));
	}

	/**
	 * Remove screen component focus.
	 *
	 * @param cacheKey the cache key
	 */
	public void removeScreenComponentFocus(String cacheKey) {
		CacheManager.getInstance().deleteKey(cacheKey);
	}

	/**
	 * Remove screen link.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param screenId      the screen id
	 */
	public void removeScreenLink(String cachePrefixKey, String screenId) {
		CacheManager.getInstance().deleteKey(cachePrefixKey.concat(screenId));
	}

	/**
	 * Remove screen link with screen id list.
	 *
	 * @param cachePrefixKey the cache prefix key
	 * @param screenIdList  the screenId id list
	 * @param envInfo        the env info
	 */
	public void removeScreenLinkWithScreenIdList(String cachePrefixKey, List<Object> screenIdList, EnvironmentDetailsEntity envInfo) {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
		List<Object> screenList = new ArrayList<>(screenIdList);
		screenList.replaceAll(screenId -> cachePrefixKey.concat(String.valueOf(screenId)));
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(screenList.toArray(new String[screenList.size()]), redisInfo);
	}

	/**
	 * Remove screens with def id.
	 *
	 * @param screenDefIdList the screen def id list
	 * @param envInfo          the env info
	 */
	public void removeScreensWithDefId(List<Object> screenDefIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
		List<Object> screenConfigurationList = ScreenDefinitonDao.getInstance().getScreensByDefIdList(screenDefIdList, envInfo).stream().map(mapper -> mapper.get("screen_id")).collect(Collectors.toList());
		List<Object> screeDefinitionList = new ArrayList<>(screenDefIdList);
		screeDefinitionList.replaceAll(screenDefId -> CacheKeyHelper.getScreenDefinitionPrefixKey().concat(String.valueOf(screenDefId)));
		screenConfigurationList.replaceAll(screenCfgId -> CacheKeyHelper.getScreenConfigurationPrefixKey().concat(String.valueOf(screenCfgId)));
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(screeDefinitionList.toArray(new String[screeDefinitionList.size()]), redisInfo);
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(screenConfigurationList.toArray(new String[screenConfigurationList.size()]), redisInfo);
	}

	/**
	 * Remove screen.
	 *
	 * @param screenId the screen id
	 */
	public void removeScreensWithScreenId(String screenId) {
		CacheManager.getInstance().deleteKey(CacheKeyHelper.getScreenDefinitionPrefixKey().concat(screenId));
		CacheManager.getInstance().deleteKey(CacheKeyHelper.getScreenConfigurationPrefixKey().concat(screenId));
	}

	/**
	 * Remove screen.
	 *
	 * @param screenIdList the screen id list
	 * @param envInfo      the env info
	 */
	public void removeScreensWithScreenIdList(List<String> screenIdList) {
		List<Object> screenConfigurationList = new ArrayList<>(screenIdList);
		List<Object> screeDefinitionList = new ArrayList<>(screenIdList);
		screeDefinitionList.replaceAll(screenDefId -> CacheKeyHelper.getScreenDefinitionPrefixKey().concat(String.valueOf(screenDefId)));
		screenConfigurationList.replaceAll(screenCfgId -> CacheKeyHelper.getScreenConfigurationPrefixKey().concat(String.valueOf(screenCfgId)));
		CacheManager.getInstance().del(screeDefinitionList.toArray(new String[screeDefinitionList.size()]));
		CacheManager.getInstance().del(screenConfigurationList.toArray(new String[screenConfigurationList.size()]));
	}

	/**
	 * Remove screen.
	 *
	 * @param screenIdList the screen id list
	 * @param envInfo      the env info
	 */
	public void removeScreensWithScreenId(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) {
		RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
		List<Object> screenConfigurationList = new ArrayList<>(screenIdList);
		List<Object> screeDefinitionList = new ArrayList<>(screenIdList);
		screeDefinitionList.replaceAll(screenDefId -> CacheKeyHelper.getScreenDefinitionPrefixKey().concat(String.valueOf(screenDefId)));
		screenConfigurationList.replaceAll(screenCfgId -> CacheKeyHelper.getScreenConfigurationPrefixKey().concat(String.valueOf(screenCfgId)));
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(screeDefinitionList.toArray(new String[screeDefinitionList.size()]), redisInfo);
		CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(screenConfigurationList.toArray(new String[screenConfigurationList.size()]), redisInfo);
	}


	/**
	 * Gets the service access list.
	 *
	 * @param screenDefId the screen def id
	 * @return the service access list
	 * @throws QueryException the query exception
	 */
	public Set<String> getServiceAccessList(String screenDefId) throws QueryException{
		if(!CacheManager.getInstance().isKeyExists(ContextBean.getTenantId().concat("_service_access_info_").concat(screenDefId))) {
			ScreenDefinitonDao screenDefinitonDao = ScreenDefinitonDao.getInstance();
			List<Map<String,Object>> screenAccessList = screenDefinitonDao.getServiceAccessDefId();
			List<ServiceRestrictionEntity> serviceRestrictionEntitiesList = new ArrayList<>();
			screenAccessList.stream().forEach(action->{
				ServiceRestrictionEntity serviceRestrictionEntity = new ServiceRestrictionEntity();
				serviceRestrictionEntity.setScreenDefId(String.valueOf(action.get("screen_def_id")));
				serviceRestrictionEntity.setTenantId(String.valueOf(action.get("tenant_id")));
				serviceRestrictionEntity.setAccessiblServiceDefId(String.valueOf(action.get("accessible_service_def_id")));
				serviceRestrictionEntity.setAccessiblScreenUrl(String.valueOf(action.get("screen_url")));
				serviceRestrictionEntity.setAccessibleMappingUrl(String.valueOf(action.get("extra_request_mapping")));
				serviceRestrictionEntitiesList.add(serviceRestrictionEntity);
			});
			Map<String,List<ServiceRestrictionEntity>> sceenDefIdgroup = 
					serviceRestrictionEntitiesList.stream().collect(Collectors.groupingBy(ServiceRestrictionEntity::getScreenDefId));
			logger.info("screen def id group :" + sceenDefIdgroup);
			sceenDefIdgroup.entrySet().forEach(map->{
				Set<String> accessList = new HashSet();
				List<ServiceRestrictionEntity> accessListData = map.getValue();
				accessListData.stream().forEach(dataList->{
					if(Objects.nonNull(dataList.getAccessiblScreenUrl()) && !dataList.getAccessiblScreenUrl().equalsIgnoreCase("null")) {
						accessList.add(String.valueOf(dataList.getAccessiblScreenUrl()));
					}
					if(Objects.nonNull(dataList.getAccessibleMappingUrl()) && !dataList.getAccessiblScreenUrl().equalsIgnoreCase("null")) {
						accessList.add(String.valueOf(dataList.getAccessibleMappingUrl()));
					}
				});
				logger.info("screen def id group :"+ accessList);
				CacheService.getInstance().saveToCache(ContextBean.getTenantId().concat("_service_access_info_").concat(map.getKey()),accessList);
			});
		}
		Set<String> cacheData = (Set<String>) 
				CacheService.getInstance().getCacheData(ContextBean.getTenantId().concat("_service_access_info_").concat(screenDefId));
		logger.info("final data :" + cacheData);
		if(CollectionUtils.isNotEmpty(cacheData)) {
			return cacheData;
		}
		return Collections.emptySet();
	}
}
