package com.nn.sova.dao;

import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

/**
 * The type Payment Gateway Dao.
 *
 * @author Vivek Kannan E
 */
public class PaymentGatewayDao {

	/**
	 * The constant END_DATE.
	 */
	public static final String END_DATE = "end_date";
	/**
	 * The constant HANDLER_TYPE.
	 */
	public static final String HANDLER_TYPE = "handler_type";

	/**
	 * Instantiates a new Payment gateway dao.
	 */
	PaymentGatewayDao() {

	}

	/**
	 * The constant instance.
	 */
	private static PaymentGatewayDao instance = null;

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static PaymentGatewayDao getInstance() {
		if (Objects.isNull(instance)) {
			instance = new PaymentGatewayDao();
		}
		return instance;
	}

	/**
	 * Get payment gateway details from database
	 * 
	 * @param productCode
	 * @param paymentType
	 * @param sqlCurrentdate
	 * @return List
	 */
	public List<Map<String, Object>> getPaymentGatewayDetails(String productCode, Integer paymentType,
			Date sqlCurrentdate) throws QueryException {
		return new QueryBuilder().btSchema().select().distinctOn(Arrays.asList(HANDLER_TYPE))
				.from(TableViewsConstants.PAYMENT_GATEWAY_VIEW)
				.where(ConditionBuilder.instance().eq("product", productCode).and().eq("payment_type", paymentType)
						.and().between(sqlCurrentdate, "start_date", END_DATE).and()
						.between(sqlCurrentdate, "handler_start_date", "handler_end_date"))
				.orderBy(Arrays.asList(HANDLER_TYPE)).orderBy(END_DATE, SortType.DESC).build(false).execute();
	}

	/**
	 * Get payment gateway details from database
	 * 
	 * @param productCode
	 * @param gatewayId
	 * @param sqlCurrentdate
	 * @param paymentType
	 * @return List
	 */
	public List<Map<String, Object>> getPaymentGatewayDetails(String productCode, String gatewayId, Date sqlCurrentdate,
			String paymentType) throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableViewsConstants.PAYMENT_GATEWAY_VIEW)
				.where(ConditionBuilder.instance().eq("product", productCode).and().eq("gateway_id", gatewayId).and()
						.eq("payment_type", Integer.valueOf(paymentType)).and()
						.between(sqlCurrentdate, "start_date", END_DATE).and()
						.between(sqlCurrentdate, "handler_start_date", "handler_end_date"))
				.orderBy(END_DATE, SortType.DESC).orderBy("handler_end_date", SortType.DESC).build(false).execute();
	}

	/**
	 * Get payment gateway error message details from database
	 * 
	 * @param productCode
	 * @param gatewayCode
	 * @param inProductCache
	 * @return List
	 */
	public List<Map<String, Object>> getPaymentGatewayErrorMessage(String productCode, String gatewayCode,
			boolean inProductCache) throws QueryException {
		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq("gateway_code", gatewayCode);
		String viewName = TableViewsConstants.PAYMENT_GATEWAY_ERROR_MESSAGE_VIEW;
		if (inProductCache) {
			viewName = TableViewsConstants.PAYMENT_PRODUCT_ERROR_MESSAGE_VIEW;
			conditionBuilder = conditionBuilder.and().eq("product_code", productCode);
		}
		return new QueryBuilder().btSchema().select().from(viewName).where(conditionBuilder).build(false).execute();
	}

	/**
	 * Get payment gateway error Item details from database
	 * 
	 * @param gatewayCode
	 * @return List
	 */
	public List<Map<String, Object>> getPaymentGatewayErrorItem(String gatewayCode) throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableViewsConstants.PAYMENT_GATEWAY_ERROR_ITEM_VIEW)
				.where(ConditionBuilder.instance().eq("gateway_code", gatewayCode)).build(false).execute();
	}

	/**
	 * Get payment gateway transaction type details
	 * 
	 * @return List
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getPgwTransactionTypeDetails() throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableViewsConstants.PAYMENT_TRANSACTION_TYPE).build(false)
				.execute();
	}

	/**
	 * Get payment gateway transaction status details
	 * 
	 * @return List
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getPgwTransactionStatusDetails() throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableViewsConstants.PAYMENT_STATUS).build(false).execute();
	}

	/**
	 * Get payment gateway transaction type details
	 * 
	 * @return List
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getPgwOrganisationDetails() throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableViewsConstants.PAYMENT_GATEWAY_ORGANISATION)
				.build(false).execute();
	}

	/**
	 * getPaymentConfiguration details from DB
	 * 
	 * @return payment gateway configuration map
	 * @throws QueryException
	 */
	public Map<String, Object> getPaymentConfiguration() throws QueryException {
		List<Map<String, Object>> resultList = new QueryBuilder().btSchema().select()
				.from(TableViewsConstants.PAYMENT_GATEWAY_CONFIGURATION).build(false).execute();
		if (CollectionUtils.isEmpty(resultList)) {
			return new HashMap<>();
		}
		return resultList.get(0);
	}

	/**
	 * getPaymentCallbackConfiguration details from DB
	 * 
	 * @param productCode
	 * @param paymentMethod
	 * 
	 * @return payment gateway callback list
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getPaymentCallbackConfiguration(String productCode, String paymentMethod)
			throws QueryException {
		List<Map<String, Object>> resultList = new QueryBuilder().btSchema().select()
				.from(TableViewsConstants.PAYMENT_GATEWAY_CALLBACK).where(ConditionBuilder.instance()
						.eq("product_code", productCode).and().eq("payment_method_name", paymentMethod))
				.build(false).execute();
		if (CollectionUtils.isEmpty(resultList)) {
			return new ArrayList<>();
		}
		return resultList;
	}

	/**
	 * getPgwDetails details from DB
	 * 
	 * @return payment gateway master details
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getPgwDetails() throws QueryException {
		return new QueryBuilder().btSchema().select().from(TableViewsConstants.PAYMENT_GATEWAY).build(false).execute();
	}

}