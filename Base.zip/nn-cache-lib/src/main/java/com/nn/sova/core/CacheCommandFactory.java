package com.nn.sova.core;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.utility.caching.CacheCommands;
import com.nn.sova.utility.caching.CacheUtil;
import com.nn.sova.utility.caching.JedisCommand;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.logger.ApplicationLogger;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.ScanParams;
import redis.clients.jedis.ScanResult;
import redis.clients.jedis.exceptions.JedisException;

public class CacheCommandFactory implements CacheCommands {

    private static final ApplicationLogger logger = ApplicationLogger.create(CacheCommandFactory.class);

    /** The static lock. */
    private static Object staticLock = new Object();
    /** The static lock. */
    private static Object staticProductLock = new Object();

    JedisPool jedisPool;
    JedisPool jedispoolProductInstance;

    JedisCluster jedisCluster;
    JedisCluster jedisClusterProductInstance;

    boolean isProduct;

    public CacheCommandFactory(boolean isProductEnabled) {
        isProduct = isProductEnabled;
        String isClusterModeEnabled = EnvironmentReader.isClusterModeEnabled();
        if (Objects.nonNull(isClusterModeEnabled) && !isClusterModeEnabled.isEmpty()
                && isClusterModeEnabled.equalsIgnoreCase("true")) {
            setJedisClusterConnection(isProductEnabled);
        } else {
            setJedisPoolConnection(isProductEnabled);
        }

    }

    private void setJedisPoolConnection(boolean isProductEnabled) {
        try {

            if (isProductEnabled) {
                setJedisProductInstance();
            } else {
                setJedisInstance();
            }
        } catch (Exception exception) {
            logger.error(exception);
        }
    }

    private void setJedisProductInstance() {
        int jedisTimeOutValue = EnvironmentReader.getRedisConnectionTimeout();
        if (jedispoolProductInstance == null) { // avoid synchronization lock if initialization has already happened
            synchronized (staticProductLock) {
                if (jedispoolProductInstance == null) { // don't re-initialize if another thread beat us to it.
                    HostAndPort redisInstance = (HostAndPort) CollectionUtils
                            .get(CacheUtil.getProductRedisInfo().getRedisNodes(), 0);
                    if (jedisTimeOutValue > 0)
                        jedispoolProductInstance = new JedisPool(CacheUtil.getPoolConfig(), redisInstance.getHost(),
                                redisInstance.getPort(), jedisTimeOutValue);
                    else
                        jedispoolProductInstance = new JedisPool(CacheUtil.getPoolConfig(), redisInstance.getHost(),
                                redisInstance.getPort());
                }
            }
        }
    }

    private void setJedisInstance() {
        int jedisTimeOutValue = EnvironmentReader.getRedisConnectionTimeout();
        if (jedisPool == null) { // avoid synchronization lock if initialization has already happened
            synchronized (staticLock) {
                if (jedisPool == null) { // don't re-initialize if another thread beat us to it.
                    HostAndPort redisInstance = (HostAndPort) CollectionUtils
                            .get(CacheUtil.getRedisEnvInfo().getRedisNodes(), 0);
                    if (jedisTimeOutValue > 0)
                        jedisPool = new JedisPool(CacheUtil.getPoolConfig(), redisInstance.getHost(),
                                redisInstance.getPort(), jedisTimeOutValue);
                    else
                        jedisPool = new JedisPool(CacheUtil.getPoolConfig(), redisInstance.getHost(),
                                redisInstance.getPort());
                }
            }
        }
    }

    private void setJedisClusterConnection(boolean isProductEnabled) {
        if (isProductEnabled && jedisClusterProductInstance == null) {
            Set<HostAndPort> nodes = new HashSet<>();
            HostAndPort redisInstance = (HostAndPort) CollectionUtils
                    .get(CacheUtil.getProductRedisInfo().getRedisNodes(), 0);
            nodes.add(redisInstance);
            jedisClusterProductInstance = new JedisCluster(nodes, CacheUtil.getPoolConfig());
            Runtime.getRuntime().addShutdownHook(new Thread() {
                @Override
                public void run() {
                    if (jedisClusterProductInstance != null) {
                        jedisClusterProductInstance.close();
                    }
                }
            });
        } else {
            Set<HostAndPort> nodes = new HashSet<>();
            nodes.add(new HostAndPort(EnvironmentReader.getRedisURL(),
                    Integer.parseInt(EnvironmentReader.getRedisPort())));
            jedisCluster = new JedisCluster(nodes, CacheUtil.getPoolConfig());
            Runtime.getRuntime().addShutdownHook(new Thread() {

                @Override
                public void run() {
                    if (jedisCluster != null) {
                        jedisCluster.close();
                    }
                }

            });
        }
    }

    private JedisPool getJedis() {
        if (isProduct) {
//            CacheUtil.getPoolCurrentUsage(jedispoolProductInstance); // uncomment this line if need to track
            return jedispoolProductInstance;
        } else {
//            CacheUtil.getPoolCurrentUsage(jedisPool); // uncomment this line if need to track pool stats
            return jedisPool;
        }

    }

    private JedisPool getJedis(RedisEnvInfo envInfo) {
        HostAndPort redisInstance = (HostAndPort) CollectionUtils.get(envInfo.getRedisNodes(), 0);
        JedisPool jedisEnvPool = new JedisPool(CacheUtil.getPoolConfig(), redisInstance.getHost(),
                redisInstance.getPort(), EnvironmentReader.getRedisConnectionTimeout());
//        CacheUtil.getPoolCurrentUsage(jedisEnvPool); // uncomment this line if need to track pool stats
        return jedisEnvPool;
    }

    private Optional<JedisCluster> getJedisCuster() {
        if (isProduct) {
            if (jedisClusterProductInstance == null)
                return Optional.empty();
            return Optional.ofNullable(jedisClusterProductInstance);
        } else {
            if (jedisCluster == null)
                return Optional.empty();
            return Optional.ofNullable(jedisCluster);
        }

    }

    private Optional<JedisCluster> getJedisCuster(RedisEnvInfo envInfo) {
        Set<HostAndPort> nodes = new HashSet<>();
        HostAndPort redisInstance = (HostAndPort) CollectionUtils.get(envInfo.getRedisNodes(), 0);
        nodes.add(new HostAndPort(redisInstance.getHost(), redisInstance.getPort()));
        JedisCluster cluster = new JedisCluster(nodes, CacheUtil.getPoolConfig());
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                if (cluster != null) {
                    cluster.close();
                }
            }
        });
        return Optional.ofNullable(cluster);
    }

    @Override
    public String get(String key) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            String responseData = new JedisCommand<String>().execute(getJedis(), jedis -> jedis.get(key)).orElse(null);
            CacheUtil.doPrintLog(startTime, "get {String key} ", key);
            return responseData;
        } else {
            String responseData = getJedisCuster().map(jedis -> jedis.get(key)).orElse(null);
            CacheUtil.doPrintLog(startTime, "get {String key} ", key);
            return responseData;
        }
    }

    @Override
    public Object get(byte[] key) {
        long startTime = System.nanoTime();
        Object cacheObject = null;
        byte[] cacheStr = null;
        if ((jedisCluster == null))
            cacheStr = new JedisCommand<byte[]>().execute(getJedis(), jedis -> jedis.get(key)).orElse(null);
        else
            cacheStr = getJedisCuster().map(jedis -> jedis.get(key)).orElse(null);
        if (Objects.nonNull(cacheStr)) {
            cacheObject = CacheUtil.deserializeBytes(cacheStr);
        }
        CacheUtil.doPrintLog(startTime, "get {byte[] key} ", new String(key));
        return cacheObject;
    }

    public Object get(byte[] key, RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        Object cacheObject = null;
        byte[] cacheStr = null;
        if ((jedisCluster == null))
            cacheStr = new JedisCommand<byte[]>().execute(getJedis(envInfo), jedis -> jedis.get(key)).orElse(null);
        else
            cacheStr = getJedisCuster(envInfo).map(jedis -> jedis.get(key)).orElse(null);
        if (Objects.nonNull(cacheStr)) {
            cacheObject = CacheUtil.deserializeBytes(cacheStr);
        }
        CacheUtil.doPrintLog(startTime, "get {byte[] key} ", new String(key));
        return cacheObject;
    }

    public String get(String key, RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            String responseData = new JedisCommand<String>().execute(getJedis(envInfo), jedis -> jedis.get(key))
                    .orElse(null);
            CacheUtil.doPrintLog(startTime, "get {String key} ", key);
            return responseData;
        } else {
            String responseData = getJedisCuster(envInfo).map(jedis -> jedis.get(key)).orElse(null);
            CacheUtil.doPrintLog(startTime, "get {String key} ", key);
            return responseData;
        }
    }

    @Override
    public String set(String key, String value) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            String responseData = new JedisCommand<String>().execute(getJedis(), jedis -> jedis.set(key, value))
                    .orElse(null);
            CacheUtil.doPrintLog(startTime, "set {String key, String value} ", key);
            return responseData;
        } else {
            String responseData = getJedisCuster().map(jedis -> jedis.set(key, value)).orElse(null);
            CacheUtil.doPrintLog(startTime, "set {String key, String value} ", key);
            return responseData;
        }
    }

    @Override
    public void setEx(String cacheKey, Object cacheObjValue, int timeUnit) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            saveWithExpiration(cacheKey, cacheObjValue, timeUnit, false);
        } else {
            saveWithExpiration(cacheKey, cacheObjValue, timeUnit, true);
        }
        CacheUtil.doPrintLog(startTime, "setEx {String cacheKey, Object cacheObjValue, int timeUnit}", cacheKey);
    }

    @Override
    public void set(String key, Object value) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            saveAsObject(key, value, false);
        } else {
            saveAsObject(key, value, true);
        }
        CacheUtil.doPrintLog(startTime, "set {String key, Object value}", key);
    }

    public void set(String key, Object value, RedisEnvInfo envInfo) {
        if ((jedisCluster == null)) {
            saveAsObjectWithEnvInfo(key, value, envInfo, false);
        } else {
            saveAsObjectWithEnvInfo(key, value, envInfo, true);
        }
    }

    @Override
    public void set(Map<Object, Object> dataMap) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            setBulkDataInPipeline(dataMap);
        } else {
            setBulkDataWithoutPipeline(dataMap);
        }
        CacheUtil.doPrintLog(startTime, "set {Map<Object, Object> dataMap}", "-");
    }

    @Override
    public void set(Map<Object, Object> dataMap, String prefixKey) {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            setBulkDataInPipelineWithCacheKey(dataMap, prefixKey);
        } else {
            setBulkDataWithoutPipelineWithCacheKey(dataMap, prefixKey);
        }
        CacheUtil.doPrintLog(startTime, "set {Map<Object, Object> dataMap, String prefixKey}", "-");
    }

    public void set(Map<Object, Object> dataMap, RedisEnvInfo envInfo) {
        if ((jedisCluster == null)) {
            setBulkDataInPipeline(dataMap, envInfo);
        } else {
            setBulkDataWithoutPipeline(dataMap, envInfo);
        }
    }

    public void set(Map<Object, Object> dataMap, String prefixKey, RedisEnvInfo envInfo) {
        if ((jedisCluster == null)) {
            setBulkDataInPipelineWithCacheKeyAndEnvInfo(dataMap, prefixKey, envInfo);
        } else {
            setBulkDataWithoutPipelineWithCacheKeyAndEnvInfo(dataMap, prefixKey, envInfo);
        }
    }

    @Override
    public Long del(byte[]... keys) {
        long startTime = System.nanoTime();
        Long responseData;
        if ((jedisCluster == null)) {
            responseData = new JedisCommand<Long>().execute(getJedis(), jedis -> jedis.del(keys)).orElse(null);
        } else {
            responseData = getJedisCuster().map(jedis -> jedis.del(keys)).orElse(null);
        }
        CacheUtil.doPrintLog(startTime, "del {byte[]... keys}", keys.toString());
        return responseData;
    }

    @Override
    public Long del(String[] keys) {
        long startTime = System.nanoTime();
        Long responseData = null;
        if ((jedisCluster == null)) {
            responseData = new JedisCommand<Long>().execute(getJedis(), jedis -> jedis.del(keys)).orElse(null);
        } else {
            for (String key : keys) {
                responseData = getJedisCuster().map(jedis -> jedis.del(key)).orElse(null);
            }
        }
        CacheUtil.doPrintLog(startTime, "del {String[] keys}", keys.toString());
        return responseData;
    }

    @Override
    public Long del(String key) {
        long startTime = System.nanoTime();
        Long responseData;
        if ((jedisCluster == null)) {
            responseData = new JedisCommand<Long>().execute(getJedis(), jedis -> jedis.del(key)).orElse(null);
        } else {
            responseData = getJedisCuster().map(jedis -> jedis.del(key)).orElse(null);
        }
        CacheUtil.doPrintLog(startTime, "del {String key}", key);
        return responseData;
    }

    public Long del(String key, RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        Long responseData;
        if ((jedisCluster == null)) {
            responseData = new JedisCommand<Long>().execute(getJedis(envInfo), jedis -> jedis.del(key)).orElse(null);
        } else {
            responseData = getJedisCuster(envInfo).map(jedis -> jedis.del(key)).orElse(null);
        }
        CacheUtil.doPrintLog(startTime, "del {String key, RedisEnvInfo envInfo}", key);
        return responseData;
    }

    public Long del(String[] keys, RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        Long responseData = null;
        if ((jedisCluster == null)) {
            responseData = new JedisCommand<Long>().execute(getJedis(envInfo), jedis -> jedis.del(keys)).orElse(null);
        } else {
            for (String key : keys) {
                responseData = getJedisCuster(envInfo).map(jedis -> jedis.del(key)).orElse(null);
            }
        }
        CacheUtil.doPrintLog(startTime, "del {String[] keys, RedisEnvInfo envInfo}", keys.toString());
        return responseData;
    }

    @Override
    public boolean isKeyExists(String key) {
        Boolean responseData;
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            responseData = new JedisCommand<Boolean>().execute(getJedis(), jedis -> jedis.exists(key)).orElse(null);
        } else {
            responseData = getJedisCuster().map(jedis -> jedis.exists(key)).orElse(null);
        }
        CacheUtil.doPrintLog(startTime, "isKeyExists {String key}", key);
        return responseData;
    }

    @Override
    public long getTTLByKey(String key) {
        long startTime = System.nanoTime();
        long responseData;
        if ((jedisCluster == null))
            responseData = new JedisCommand<Long>().execute(getJedis(), jedis -> jedis.ttl(key.getBytes()))
                    .orElse(null);
        else
            responseData = getJedisCuster().map(jedis -> jedis.ttl(key.getBytes())).orElse(null);
        CacheUtil.doPrintLog(startTime, "getTTLByKey {String key}", key);
        return responseData;
    }

    @Override
    public void flushAll() {
        long startTime = System.nanoTime();
        if ((jedisCluster == null)) {
            new JedisCommand<>().execute(getJedis(), jedis -> jedis.flushAll()).orElse(null);
        } else {
            Map<String, JedisPool> JedisPoolMap = getJedisCuster().get().getClusterNodes();
            for (Entry<String, JedisPool> entry : JedisPoolMap.entrySet()) {
                entry.getValue().getResource().flushDB();
            }
        }
        CacheUtil.doPrintLog(startTime, "flushAll {}", "-");
    }

    @Override
    public Long getDBSize() {
        if ((jedisCluster == null))
            return new JedisCommand<Long>().execute(getJedis(), jedis -> jedis.dbSize()).orElse(null);
        else
            return 0L;
    }

    @Override
    public Set<String> search(String key) {
        if ((jedisCluster == null)) {
            return findRedisKeys(key, false);
        } else {
            return findRedisKeys(key, true);
        }
    }

    @Override
    public Set<String> searchFullText(String key, int count, String cursor) {
        if ((jedisCluster == null)) {
            return searchFullText(key, count, cursor, false);
        } else {
            return searchFullText(key, count, cursor, true);
        }
    }

    @Override
    public Set<String> searchWithPrefix(String key) {
        if ((jedisCluster == null)) {
            return findPrefixRedisKeys(key, false);
        } else {
            return findPrefixRedisKeys(key, true);
        }
    }

    public Set<String> searchWithPrefix(String key, RedisEnvInfo envInfo) {
        if ((jedisCluster == null)) {
            return findCustomKeys(key, false);
        } else {
            return findCustomKeys(key, true);
        }
    }

    @Override
    public Map<String, Object> searchFullText(String cursor, String key, int fetchLimit) {
        if ((jedisCluster == null)) {
            return findRedisKeys(cursor, key, fetchLimit, false);
        } else {
            return findRedisKeys(cursor, key, fetchLimit, true);
        }
    }

    private void setBulkDataWithoutPipelineWithCacheKeyAndEnvInfo(Map<Object, Object> dataMap, String prefixKey,
            RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = prefixKey.concat(action.getKey().toString()).getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            getJedisCuster(envInfo).get().set(byteCacheKey, byteCacheValue);
        });
        CacheUtil.doPrintLog(startTime,
                "setBulkDataWithoutPipelineWithCacheKeyAndEnvInfo { Map<Object, Object> dataMap, String prefixKey,RedisEnvInfo envInfo }",
                "-");
    }

    private void setBulkDataInPipelineWithCacheKeyAndEnvInfo(Map<Object, Object> dataMap, String prefixKey,
            RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        Pipeline pipeline = new JedisCommand<Pipeline>().execute(getJedis(envInfo), jedis -> jedis.pipelined())
                .orElse(null);
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = prefixKey.concat(action.getKey().toString()).getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            if (Objects.nonNull(pipeline))
                pipeline.set(byteCacheKey, byteCacheValue);
        });
        if (Objects.nonNull(pipeline))
            pipeline.sync();
        CacheUtil.doPrintLog(startTime,
                "setBulkDataInPipelineWithCacheKeyAndEnvInfo {Map<Object, Object> dataMap, String prefixKey, RedisEnvInfo envInfo}",
                "-");
    }

    public Set<String> searchFullText(String key, int count, String cursor, boolean isJedisCluster) {
        long startTime = System.nanoTime();
        Set<String> keys = new HashSet<>();
        if (count == 0) {
            count = 10000;
        }
        if (StringUtils.isEmpty(cursor)) {
            cursor = "0";
        }
        String cur = cursor;
        ScanParams scanparam = new ScanParams();
        scanparam.match("*" + key + "*");
        scanparam.count(count);
        ScanResult<String> scanResult;
        if (isJedisCluster) {
            return scanJedisCluster(scanparam, cursor);
        } else {
            scanResult = new JedisCommand<ScanResult<String>>().execute(getJedis(), jedis -> jedis.scan(cur, scanparam))
                    .orElse(null);
        }
        List<String> result = scanResult.getResult();
        if (Objects.nonNull(result) && !result.isEmpty()) {
            keys.addAll(result);
        }
        CacheUtil.doPrintLog(startTime, "searchFullText {String key, int count, String cursor, boolean isJedisCluster}",
                "-");
        return keys;
    }

    public Set<String> findRedisKeys(String key, boolean isJedisCluster) {
        ScanParams scanparam = new ScanParams();
        scanparam.match("*" + key + "*");
        scanparam.count(10000);
        if (isJedisCluster) {
            return scanJedisCluster(scanparam);
        } else {
            return scanJedisPool(scanparam);
        }
    }

    public Set<String> findPrefixRedisKeys(String key, boolean isJedisCluster) {
        ScanParams scanparam = new ScanParams();
        scanparam.match(key + "*");
        scanparam.count(10000);
        if (isJedisCluster) {
            return scanJedisCluster(scanparam);
        } else {
            return scanJedisPool(scanparam);
        }
    }

    public Set<String> findPrefixRedisKeys(String key, RedisEnvInfo envInfo, boolean isJedisCluster) {
        ScanParams scanparam = new ScanParams();
        scanparam.match(key + "*");
        scanparam.count(10000);
        if (isJedisCluster) {
            return scanJedisCluster(scanparam);
        } else {
            return scanJedisPool(scanparam);
        }
    }

    public Set<String> findCustomKeys(String key, boolean isJedisCluster) {
        ScanParams scanparam = new ScanParams();
        scanparam.match(key);
        scanparam.count(10000);
        if (isJedisCluster) {
            return scanJedisCluster(scanparam);
        } else {
            return scanJedisPool(scanparam);
        }
    }

    public Map<String, Object> findRedisKeys(String cursor, String key, int fetchLimit, boolean isJedisCluster) {
        String cur = cursor;
        long startTime = System.nanoTime();
        Map<String, Object> resultMap = new HashMap<>();
        ScanParams scanparam = new ScanParams();
        scanparam.match(key);
        scanparam.count(fetchLimit);
        ScanResult<String> scanResult;
        if (isJedisCluster) {
            scanResult = getJedisCuster().get().scan(cursor, scanparam);
        } else {
            scanResult = new JedisCommand<ScanResult<String>>().execute(getJedis(), jedis -> jedis.scan(cur, scanparam))
                    .orElse(null);
        }
        List<String> result = scanResult.getResult();
        Set<String> keys = new HashSet<>();
        if (Objects.nonNull(result) && !result.isEmpty()) {
            keys.addAll(result);
        }
        cursor = scanResult.getCursor();
        resultMap.put("cursor", cursor);
        resultMap.put("keys", new ArrayList<>(keys));
        CacheUtil.doPrintLog(startTime,
                "findRedisKeys {String cursor, String key, int fetchLimit, boolean isJedisCluster}", "-");
        return resultMap;
    }

    private Set<String> scanJedisPool(ScanParams scanparam) {
        long startTime = System.nanoTime();
        Set<String> allKeys = new HashSet<>();
        String cursor = ScanParams.SCAN_POINTER_START;
        boolean isCompleteIteration = false;
        do {
            String cur = cursor;
            ScanResult<String> scanResult = new JedisCommand<ScanResult<String>>()
                    .execute(getJedis(), jedis -> jedis.scan(cur, scanparam)).orElse(null);
            List<String> result = scanResult.getResult();
            if (Objects.nonNull(result) && !result.isEmpty()) {
                allKeys.addAll(result);
            }
            cursor = scanResult.getCursor();
            isCompleteIteration = scanResult.isCompleteIteration();
            System.out.println("Cursor -> " + cursor + " -- " + scanResult.getCursor());
        } while (!isCompleteIteration);
        CacheUtil.doPrintLog(startTime, "scanJedisPool {ScanParams scanparam}", "-");
        return allKeys;
    }

    private Set<String> scanJedisCluster(ScanParams scanParams, String cursor) {
        long startTime = System.nanoTime();
        Set<String> allKeys = new HashSet<>();
        Map<String, JedisPool> JedisPoolMap = getJedisCuster().get().getClusterNodes();
        for (Entry<String, JedisPool> entry : JedisPoolMap.entrySet()) {
            cursor = ScanParams.SCAN_POINTER_START;
            do {
                try (Jedis jedis = entry.getValue().getResource()) {
                    ScanResult<String> scanResult = jedis.scan(cursor, scanParams);
                    allKeys.addAll(scanResult.getResult());
                    cursor = scanResult.getCursor();
                }
            } while (!cursor.equals(ScanParams.SCAN_POINTER_START));
        }
        CacheUtil.doPrintLog(startTime, "scanJedisPool {ScanParams scanParams, String cursor}", "-");
        return allKeys;
    }

    private Set<String> scanJedisCluster(ScanParams scanParams) {
        long startTime = System.nanoTime();
        Set<String> allKeys = new HashSet<>();
        getJedisCuster().get().getClusterNodes().values().forEach((pool) -> {
            String cur = ScanParams.SCAN_POINTER_START;
            do {
                try (Jedis jedis = pool.getResource()) {
                    ScanResult<String> scanResult = jedis.scan(cur, scanParams);
                    allKeys.addAll(scanResult.getResult());
                    cur = scanResult.getCursor();
                }
            } while (!cur.equals(ScanParams.SCAN_POINTER_START));
        });
        CacheUtil.doPrintLog(startTime, "scanJedisPool {ScanParams scanParams}", "-");
        return allKeys;
    }

    private void saveWithExpiration(String cacheKey, Object cacheObjValue, int timeUnit, boolean isJedisCluster) {
        long startTime = System.nanoTime();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(byteArrayOutputStream);
            if (Objects.nonNull(cacheObjValue)) {
                String customCacheKey = cacheKey;
                byte[] byteCacheKey = customCacheKey.getBytes("UTF8");
                out.writeObject(cacheObjValue);
                out.flush();
                byte[] byteCacheValue = byteArrayOutputStream.toByteArray();
                if (isJedisCluster) {
                    getJedisCuster().get().setex(byteCacheKey, timeUnit, byteCacheValue);
                } else {
                    new JedisCommand<>()
                            .execute(getJedis(), jedis -> jedis.setex(byteCacheKey, timeUnit, byteCacheValue))
                            .orElse(null);
                }
            }
            CacheUtil.doPrintLog(startTime,
                    "saveWithExpiration {String cacheKey, Object cacheObjValue, int timeUnit, boolean isJedisCluster}",
                    "-");
        } catch (JedisException jedisException) {
            logger.error(jedisException);
        } catch (Exception exception) {
            logger.error(exception);
        }
    }

    private void saveAsObject(String key, Object value, boolean isJedisCluster) {
        long startTime = System.nanoTime();
        if (Objects.nonNull(value)) {
            byte[] byteCacheKey = key.getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(value);
            if (isJedisCluster) {
                getJedisCuster().get().set(byteCacheKey, byteCacheValue);
            } else {
                new JedisCommand<>().execute(getJedis(), jedis -> jedis.set(byteCacheKey, byteCacheValue)).orElse(null);
            }
        }
        CacheUtil.doPrintLog(startTime, "saveAsObject {String key, Object value, boolean isJedisCluster}", key);
    }

    private void saveAsObjectWithEnvInfo(String key, Object value, RedisEnvInfo envInfo, boolean isJedisCluster) {
        long startTime = System.nanoTime();
        if (Objects.nonNull(value)) {
            byte[] byteCacheKey = key.getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(value);
            if (isJedisCluster) {
                getJedisCuster(envInfo).get().set(byteCacheKey, byteCacheValue);
            } else {
                new JedisCommand<>().execute(getJedis(), jedis -> jedis.set(byteCacheKey, byteCacheValue)).orElse(null);
            }
        }
        CacheUtil.doPrintLog(startTime,
                "saveAsObjectWithEnvInfo {String key, Object value, RedisEnvInfo envInfo, boolean isJedisCluster}",
                key);
    }

    private void setBulkDataWithoutPipelineWithCacheKey(Map<Object, Object> dataMap, String prefixKey) {
        long startTime = System.nanoTime();
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = prefixKey.concat(action.getKey().toString()).getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            getJedisCuster().get().set(byteCacheKey, byteCacheValue);
        });
        CacheUtil.doPrintLog(startTime,
                "setBulkDataWithoutPipelineWithCacheKey {Map<Object, Object> dataMap, String prefixKey}", "-");
    }

    private void setBulkDataInPipelineWithCacheKey(Map<Object, Object> dataMap, String prefixKey) {
        long startTime = System.nanoTime();
        Pipeline pipeline = new JedisCommand<Pipeline>().execute(getJedis(), jedis -> jedis.pipelined()).orElse(null);
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = prefixKey.concat(action.getKey().toString()).getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            if (Objects.nonNull(pipeline))
                pipeline.set(byteCacheKey, byteCacheValue);
        });
        if (Objects.nonNull(pipeline))
            pipeline.sync();
        CacheUtil.doPrintLog(startTime,
                "setBulkDataInPipelineWithCacheKey {Map<Object, Object> dataMap, String prefixKey}", "-");
    }

    private void setBulkDataInPipeline(Map<Object, Object> dataMap) {
        long startTime = System.nanoTime();
        Pipeline pipeline = new JedisCommand<Pipeline>().execute(getJedis(), jedis -> jedis.pipelined()).orElse(null);
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = action.getKey().toString().getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            if (Objects.nonNull(pipeline))
                pipeline.set(byteCacheKey, byteCacheValue);
        });
        if (Objects.nonNull(pipeline))
            pipeline.sync();
        CacheUtil.doPrintLog(startTime, "setBulkDataInPipeline {Map<Object, Object> dataMap}", "-");
    }

    private void setBulkDataWithoutPipeline(Map<Object, Object> dataMap) {
        long startTime = System.nanoTime();
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = action.getKey().toString().getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            getJedisCuster().get().set(byteCacheKey, byteCacheValue);
        });
        CacheUtil.doPrintLog(startTime, "setBulkDataWithoutPipeline {Map<Object, Object> dataMap}", "-");
    }

    private void setBulkDataInPipeline(Map<Object, Object> dataMap, RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        Pipeline pipeline = new JedisCommand<Pipeline>().execute(getJedis(envInfo), jedis -> jedis.pipelined())
                .orElse(null);
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = action.getKey().toString().getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            if (Objects.nonNull(pipeline))
                pipeline.set(byteCacheKey, byteCacheValue);
        });
        if (Objects.nonNull(pipeline))
            pipeline.sync();
        CacheUtil.doPrintLog(startTime, "setBulkDataInPipeline {Map<Object, Object> dataMap}", "-");
    }

    private void setBulkDataWithoutPipeline(Map<Object, Object> dataMap, RedisEnvInfo envInfo) {
        long startTime = System.nanoTime();
        dataMap.entrySet().stream().forEach(action -> {
            byte[] byteCacheKey = action.getKey().toString().getBytes();
            byte[] byteCacheValue = CacheUtil.serializeObject(action.getValue());
            getJedisCuster(envInfo).get().set(byteCacheKey, byteCacheValue);
        });
        CacheUtil.doPrintLog(startTime, "setBulkDataWithoutPipeline {Map<Object, Object> dataMap}", "-");
    }

}