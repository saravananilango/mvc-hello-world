package com.nn.sova.constants;

/**
 * The type Table views constants.
 *
 * @author Anand Kumar
 */
public class TableViewsConstants {

    /**
     * The constant REDIS_TENANT_ROLE_VIEW.
     */
    public static final String REDIS_TENANT_ROLE_VIEW = "redis_tenant_role_view";
    /**
     * The constant REDIS_TENANT_AUTHORITY_SCREEN_VIEW.
     */
    public static final String REDIS_TENANT_AUTHORITY_SCREEN_VIEW = "redis_tenant_authority_screen_view";
    /**
     * The constant REDIS_TENANT_ROLE_SETTING_VIEW.
     */
    public static final String REDIS_TENANT_ROLE_SETTING_VIEW = "redis_tenant_role_setting_view";
    /**
     * The constant REDIS_TENANT_ROLE_LINK_SETTING_VIEW.
     */
    public static final String REDIS_TENANT_ROLE_LINK_SETTING_VIEW = "redis_tenant_role_link_setting_view";
    /**
     * The constant REDIS_TENANT_SCREEN_ROLE_LINK_SETTING_VIEW.
     */
    public static final String REDIS_TENANT_SCREEN_ROLE_LINK_SETTING_VIEW = "redis_tenant_screen_role_link_setting_view";
    /**
     * The constant REDIS_SCREEN_AUTHENTICATE_DETAILS.
     */
    public static final String REDIS_SCREEN_AUTHENTICATE_DETAILS = "redis_screen_authenticate_details";
    /**
     * The constant REDIS_USER_DETAILS_VIEW.
     */
    public static final String REDIS_USER_DETAILS_VIEW = "redis_user_details_view";
    /**
     * The constant REDIS_TENANT_USER_DETAILS_VIEW.
     */
    public static final String REDIS_TENANT_USER_DETAILS_VIEW = "redis_tenant_user_details_view";
    /**
     * The constant REDIS_CACHE_FULL_MENU_TRANSACTION_VIEW.
     */
    public static final String REDIS_CACHE_FULL_MENU_TRANSACTION_VIEW = "redis_cache_full_menu_transaction_view";
    /**
     * The constant REDIS_CACHE_ADMIN_MENU_TRANSACTION_VIEW.
     */
    public static final String REDIS_CACHE_ADMIN_MENU_TRANSACTION_VIEW = "redis_cache_admin_menu_transaction_view";
    /**
     * The constant REDIS_CACHE_PARTIAL_AUTHORITY_ALL_MENU_TRANSACTION_VIEW.
     */
    public static final String REDIS_CACHE_PARTIAL_AUTHORITY_ALL_MENU_TRANSACTION_VIEW = "redis_cache_partial_authority_all_menu_transaction_view";
    /**
     * The constant REDIS_CACHE_PARTIAL_MENU_TRANSACTION_SCREEN_ROLE_VIEW.
     */
    public static final String REDIS_CACHE_PARTIAL_MENU_TRANSACTION_SCREEN_ROLE_VIEW = "redis_cache_partial_menu_transaction_screen_role_view";
    /**
     * The constant REDIS_PRODUCT_TENANT_CONFIG.
     */
    public static final String REDIS_PRODUCT_TENANT_CONFIG = "redis_product_tenant_config";
    /**
     * The constant REDIS_INPUT_COMPONENT_INFO_VIEW.
     */
    public static final String CACHE_INPUT_COMPONENT_INFO_VIEW = "cache_input_component_info_view";
    /**
     * The constant CACHE_TEXT_DEF_FREMEWORK_VIEW.
     */
    public static final String CACHE_TEXT_DEF_FREMEWORK_VIEW = "cache_text_def_framework_view";
    /**
     * The constant CACHE_TEXT_DEF_FREMEWORK_VIEW.
     */
    public static final String CACHE_TEXT_DEF_APPLICATION_VIEW = "cache_text_def_application_view";
    /**
     * The constant REDIS_BUTTON_COMPONENT_INFO_VIEW.
     */
    public static final String CACHE_BUTTON_COMPONENT_INFO_VIEW = "cache_button_component_info_view";
    /**
     * The constant REDIS_APP_GEN_DATA_ELEMENT_VIEW.
     */
    public static final String REDIS_APP_GEN_DATA_ELEMENT_VIEW = "redis_app_gen_data_element_view";
    /**
     * The constant REDIS_BACKEND_VALIDATION_VIEW.
     */
    public static final String REDIS_BACKEND_VALIDATION_VIEW = "cache_backend_validation_view";
    /**
     * The constant REDIS_DIVISION_VALIDATION_VIEW.
     */
    public static final String REDIS_DIVISION_VALIDATION_VIEW = "cache_backend_division_validation_view";
    /**
     * The constant REDIS_MESSAGE_DEFINITION_VIEW.
     */
    public static final String REDIS_MESSAGE_DEFINITION_VIEW = "redis_message_definition_view";
    /**
     * The constant CACHE_APPLICATION_MESSAGE_VIEW.
     */
    public static final String CACHE_APPLICATION_MESSAGE_VIEW = "cache_application_message_view";
    /**
     * The constant CACHE_APPLICATION_MESSAGE_VIEW.
     */
    public static final String CACHE_SCREEN_DETAILS_VIEW = "cache_screen_details_view";
    /**
     * The constant REDIS_LOCALE_VIEW.
     */
    public static final String REDIS_LOCALE_VIEW = "redis_locale_view";

    /**
	 * the constant CACHE_FULL_MENU_TRANSACTION_VIEW
	 */
	public static final String CACHE_FULL_MENU_TRANSACTION_VIEW = "cache_full_menu_transaction_view";
	/**
	 * the constant CACHE_ADMIN_MENU_TRANSACTION_VIEW
	 */
	public static final String CACHE_ADMIN_MENU_TRANSACTION_VIEW = "cache_admin_menu_transaction_view";
	/**
	 * the constant CACHE_PARTIAL_AUTHORITY_MENU_TRANSACTION_VIEW
	 */
	public static final String CACHE_PARTIAL_AUTHORITY_MENU_TRANSACTION_VIEW = "cache_partial_authority_menu_transaction_view";	
	/**
	 * the constant PAYMENT_GATEWAY_VIEW
	 */
	public static final String PAYMENT_GATEWAY_VIEW = "payment_gateway_view";
	/**
	 * the constant PAYMENT_GATEWAY_ERROR_MESSAGE_VIEW
	 */
	public static final String PAYMENT_GATEWAY_ERROR_MESSAGE_VIEW = "payment_gateway_error_message_view";
	/**
	 * the constant PAYMENT_PRODUCT_ERROR_MESSAGE_VIEW
	 */
	public static final String PAYMENT_PRODUCT_ERROR_MESSAGE_VIEW = "payment_product_error_message_view";
	/**
	 * the constant PAYMENT_TRANSACTION_TYPE
	 */
	public static final String PAYMENT_TRANSACTION_TYPE = "payment_transaction_type";
	/**
	 * the constant PAYMENT_GATEWAY_ORGANISATION
	 */
	public static final String PAYMENT_GATEWAY_ORGANISATION = "payment_gateway_organisation";
	/**
	 * the constant PAYMENT_STATUS
	 */
	public static final String PAYMENT_STATUS = "payment_status";
	/**
	 * the constant PAYMENT_GATEWAY_ERROR_ITEM_VIEW
	 */
	public static final String PAYMENT_GATEWAY_ERROR_ITEM_VIEW = "payment_gateway_error_item_view";
	/**
	 * the constant PAYMENT_GATEWAY_CONFIGURATION
	 */
	public static final String PAYMENT_GATEWAY_CONFIGURATION = "payment_gateway_configuration";
	/**
	 * the constant PAYMENT_GATEWAY_CALLBACK
	 */
	public static final String PAYMENT_GATEWAY_CALLBACK = "payment_gateway_callback";
	/**
	 * the constant PAYMENT_GATEWAY
	 */
	public static final String PAYMENT_GATEWAY = "payment_gateway";
	/**
	 * Instantiates a new Table views constants.
	 */
	private TableViewsConstants() {
	}
}
