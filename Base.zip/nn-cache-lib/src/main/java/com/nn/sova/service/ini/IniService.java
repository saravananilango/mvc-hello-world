package com.nn.sova.service.ini;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.dao.IniStorageDao;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * IniService class is used to access ini storage table information.
 *
 * @author Mohammed Shameer U
 */
public abstract class IniService {

	/** the logger class */
	private static final ApplicationLogger logger = ApplicationLogger.create(IniService.class);

	/** The IniService Instance */
	private static IniService instance = null;

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static IniService getInstance() {
		if (Objects.isNull(instance)) {
			instance = new IniService() {
			};
		}
		return instance;
	}

	/** The Ini Dao Implementation */
	private static final IniStorageDao iniStorageDao = new IniStorageDao();

	/** The seperator */
	private static final String DELIMITER = ":";
	
	/** The INI_KEY */
	private static final String INI_KEY = "ini_key";
	
	/** The COMPONENT_ID */
	private static final String COMPONENT_ID = "component_id";
	
	/** The CLEAR_CACHE */
	private static final String CLEAR_CACHE = "clear_cache";
	
	/** The INI_DATA */
	private static final String INI_DATA = "ini_data";
	
	/** The STATUS */
	private static final String STATUS = "status";
	
	/** The ERROR */
	private static final String ERROR = "error";

	/**
	 * getIniDataByKey is used to get the ini data by key
	 * 
	 * @param iniMap
	 * @return
	 */
	public List<Map<String, Object>> getIniDataByKey(Map<String, Object> iniMap) {
		if (Objects.nonNull(iniMap.get(INI_KEY))) {
			return iniStorageDao.getIniDataByKeyList(Arrays.asList(iniMap.get(INI_KEY)));
		} else {
			return iniStorageDao.getIniServiceDataByKeyList(
					Objects.nonNull(iniMap.get(COMPONENT_ID)) ? Arrays.asList(iniMap.get(COMPONENT_ID))
							: new ArrayList<>());
		}
	}

	/**
	 * setIniDataByKey is used to insert ini data by key.
	 * 
	 * @param paramMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> insertIniDataByKey(Map<String, Object> paramMap) {
		Map<String, Object> dataMap = new HashMap<>();
		boolean clearCacheFlag = Objects.nonNull(paramMap.get(CLEAR_CACHE))
				? Boolean.valueOf(String.valueOf(paramMap.get(CLEAR_CACHE)))
				: false;
		if (Objects.nonNull(paramMap.get(INI_KEY))) {
			return insertIniDataByKey(Arrays.asList(paramMap), clearCacheFlag);
		} else if (Objects.nonNull(paramMap.get(INI_DATA))) {
			return insertIniDataByService(Arrays.asList((Map<String, Object>) paramMap.get(INI_DATA)));
		}
		return dataMap;
	}

	/**
	 * getIniDataByKeyList is used to het the ini by key list.
	 * 
	 * @param paramMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getIniDataByKeyList(Map<String, Object> paramMap) {
		if (Objects.nonNull(paramMap.get(INI_KEY))) {
			return iniStorageDao.getIniDataByKeyList((List<Object>) paramMap.get(INI_KEY));
		} else {
			return iniStorageDao.getIniServiceDataByKeyList(
					Objects.nonNull(paramMap.get(COMPONENT_ID)) ? (List<Object>) paramMap.get(COMPONENT_ID)
							: new ArrayList<>());
		}
	}

	/**
	 * insertIniDataByKeyList is used to get the ini data by keylist
	 * 
	 * @param paramMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> insertIniDataByKeyList(Map<String, Object> paramMap) {
		Map<String, Object> dataMap = new HashMap<>();
		if (Objects.nonNull(paramMap.get(INI_DATA))) {
			if (Objects.nonNull(paramMap.get("component_flag"))) {
				return insertIniDataByService((List<Map<String, Object>>) paramMap.get(INI_DATA));
			} else {
				return insertIniDataByKey((List<Map<String, Object>>) paramMap.get(INI_DATA),
						Objects.nonNull(paramMap.get(CLEAR_CACHE))
								? Boolean.valueOf(String.valueOf(paramMap.get(CLEAR_CACHE)))
								: false);
			}
		} else {
			dataMap.put(STATUS, false);
			dataMap.put(ERROR, "iniData missing in the arguments.");
		}
		return dataMap;
	}

	/**
	 * insertIniDataByKey is used to insert ini data by key
	 * 
	 * @param asList
	 * @param clearCacheFlag
	 * @param prefixKey
	 * @return
	 */
	private Map<String, Object> insertIniDataByKey(List<Map<String, Object>> asList, boolean clearCacheFlag) {
		Map<String, Object> dataMap = new HashMap<>();
		try {
			iniStorageDao.setIniDataByKeyList(asList);
			if (clearCacheFlag) {
				clearRedisCacheData(asList);
			}
			dataMap.put(STATUS, true);
		} catch (QueryException e) {
			logger.error("Exception occured while inserting data to ini storage table", e);
			dataMap.put(STATUS, false);
			dataMap.put(ERROR, e.getLocalizedMessage());
		}
		return dataMap;
	}

	/**
	 * insertIniDataByService inserts the ini data of the service.
	 * 
	 * @param asList
	 * @return
	 */
	private Map<String, Object> insertIniDataByService(List<Map<String, Object>> asList) {
		Map<String, Object> dataMap = new HashMap<>();
		try {
			iniStorageDao.setIniServiceDataByKeyList(asList);
			clearScreenRedisCacheData(Arrays.asList(Collections.singletonMap("screen_id", ContextBean.getSid())));
			dataMap.put(STATUS, true);
		} catch (QueryException e) {
			logger.error("Exception occured while inserting data to ini storage table", e);
			dataMap.put(STATUS, false);
			dataMap.put(ERROR, e.getLocalizedMessage());
		}
		return dataMap;
	}

	/**
	 * clearRedisCacheData is used to clear the redis cache data.
	 * 
	 * @param asList
	 * @param prefixKey
	 */
	private void clearRedisCacheData(List<Map<String, Object>> asList) {
		String tenantId = ContextBean.getTenantId();
		String userId = ContextBean.getUserId();
		asList.stream().forEach(action -> 
			CacheService.getInstance().removeCacheByKey(CacheKeyHelper
					.getIniKey(String.join(DELIMITER, tenantId, userId, String.valueOf(action.get(INI_KEY))))));
	}
	
	/**
	 * clearScreenRedisCacheData is used to clear the screen redis cache data.
	 * 
	 * @param asList
	 * @param prefixKey
	 */
	private void clearScreenRedisCacheData(List<Map<String, Object>> asList) {
		String tenantId = ContextBean.getTenantId();
		String userId = ContextBean.getUserId();
		asList.stream().forEach(action -> 
			CacheService.getInstance().removeCacheByKey(CacheKeyHelper
					.getIniKey(String.join(DELIMITER, tenantId, userId, String.valueOf(action.get("screen_id"))))));
	}

	/**
	 * getIniDataByService is used to get the ini data by service.
	 * 
	 * @return
	 */
	public List<Map<String, Object>> getIniDataByService() {
		return getIniDataByKey(new HashMap<>());
	}

	/**
	 * clearIniStorage is used to clear the ini.
	 * 
	 * @param paramMap
	 * @return
	 */
	public Map<String, Object> clearIniStorage() {
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put(STATUS, true);
		try {
			List<Map<String, Object>> iniList = iniStorageDao.getIniDataForUser();
			List<Map<String, Object>> iniScreenList = iniStorageDao.getIniServiceDataForUser();
			if (CollectionUtils.isNotEmpty(iniList)) {
				iniStorageDao.clearCommonIni();
				clearRedisCacheData(iniList);
			}
			if (CollectionUtils.isNotEmpty(iniScreenList)) {
				iniStorageDao.clearScreenIni();
				clearScreenRedisCacheData(iniScreenList);
			}
		} catch (QueryException e) {
			logger.error("Exception occured while clearing INI", e);
			resultMap.put(STATUS, false);
		}
		return resultMap;
	}
}