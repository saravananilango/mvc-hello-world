package com.nn.sova.constants;

/**
 * The type Screen configuration table constants.
 * @author Anand Kumar
 */
public class ScreenConfigurationConstants {
    /**
     * Instantiates a new Screen configuration constants.
     */
    ScreenConfigurationConstants(){

    }
    /**
     * The constant SCREEN_CONFIGURATION_SCREEN_ID.
     */
    public static final String SCREEN_CONFIGURATION_SCREEN_ID = "screenConfiguration.screenId";
    /**
     * The constant SCREEN_ID.
     */
    public static final String SCREEN_ID = "screen_id";
    /**
     * The constant DB_COL_IS_DISPLAYED.
     */
    public static final String DB_COL_IS_DISPLAYED = "screen_config.is_displayed";
    /**
     * The constant DB_COL_IS_MANDATORY.
     */
    public static final String DB_COL_IS_MANDATORY = "screen_config.mandatory";
    /**
     * The constant DB_COL_SCREEN_ID.
     */
    public static final String DB_COL_SCREEN_ID = "screen_config.screen_id";
    /**
     * The constant DB_COL_IS_DISUSE.
     */
    public static final String DB_COL_IS_DISUSE = "screen_config.is_disuse";
    /**
     * The constant DB_COL_IS_READONLY.
     */
    public static final String DB_COL_IS_READONLY = "screen_config.is_read_only";
    /**
     * The constant COMPONENT.
     */
    public static final String COMPONENT = "component";
    /**
     * The constant DB_COL_SCREEN_DEF_ID.
     */
    public static final String DB_COL_SCREEN_DEF_ID = "component.screen_definition_id";
    /**
     * The constant DB_COL_INITIAL_FOCUS.
     */
    public static final String DB_COL_INITIAL_FOCUS = "screen_config.initial_focus";
    /**
     * The constant SCREEN_CONFIG_ALIAS_NAME.
     */
    public static final String SCREEN_CONFIG_ALIAS_NAME = "screen_config";
    /**
     * The constant DB_COL_COMPONENT_ID.
     */
    public static final String DB_COL_COMPONENT_ID = "screen_config.component_id";
    /**
     * The constant LINK_ID.
     */
    public static final String LINK_ID = "link_id";
    /**
     * The constant LINK_SCREEN_ID.
     */
    public static final String LINK_SCREEN_ID = "link_screen_id";
}
