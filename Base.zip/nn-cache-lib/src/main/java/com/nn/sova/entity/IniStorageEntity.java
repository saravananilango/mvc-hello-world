package com.nn.sova.entity;

import lombok.Data;

/**
 * IniStorageEntity common entity class for ini store and retrieve.
 *
 * @author Anand Kumar
 */
@Data
public class IniStorageEntity {
    /**
     * The User id.
     */
    private String userId;
    /**
     * The screen id.
     */
    private String screenId;
    /**
     * The Component id.
     */
    private String componentId;
    /**
     * The Target id.
     */
    private String targetId;
    /**
     * The Ini value.
     */
    private String iniValue;
    /**
     * The Additional value.
     */
    private String additionalValue;
    /**
     * The Key value.
     */
    private String keyValue;
}
