package com.nn.sova.constants;

/**
 * The type Table name constants.
 *
 * @author Anand Kumar
 */
public class TableNamesConstants {
    /**
     * Instantiates a new Table names constants.
     */
    TableNamesConstants(){

    }
    /**
     * The constant CHARSET_DEF.
     */
    public static final String CHARSET_DEF = "charset_definition";
    /**
     * The constant CLASS_CONFIGURATION.
     */
    public static final String CLASS_CONFIGURATION = "class_configuration";
    /**
     * The constant COMPONENT_DEFINITION.
     */
    public static final String COMPONENT_DEFINITION = "component_definition";
    /**
     * The constant DATA_FORMAT.
     */
    public static final String DATA_FORMAT = "data_format_definition";
    /**
     * The constant DATA_ELEMENTS.
     */
    public static final String DATA_ELEMENTS = "data_element_definition";
    /**
     * The constant DIVISION_DEF.
     */
    public static final String DIVISION_DEF = "division_definition";
    /**
     * The constant LOCALE_CFG.
     */
    public static final String LOCALE_CFG = "locale_definition";
    /**
     * The constant LOCALE_CFG_TEXT.
     */
    public static final String LOCALE_CFG_TEXT = "locale_definition_text";
    /**
     * The constant MASTER_DEF.
     */
    public static final String MASTER_DEF = "master_definition";
    /**
     * The constant MENU_ICONS.
     */
    public static final String MENU_ICONS = "menu_icons";
    /**
     * The constant MENU_ICONS_TEXT.
     */
    public static final String MENU_ICONS_TEXT = "menu_icons_text";
    /**
     * The constant MESSAGE_DEFINITION.
     */
    public static final String MESSAGE_DEFINITION = "message_definition";
    /**
     * The constant SCREEN_ROLE_SETTING.
     */
    public static final String SCREEN_ROLE_SETTING = "screen_role_setting";
    /**
     * The constant ROLE_LINK_SETTING.
     */
    public static final String ROLE_LINK_SETTING = "user_role_configuration";
    /**
     * The constant ROLE_SETTING.
     */
    public static final String ROLE_SETTING = "role_setting";
    /**
     * The constant SCREEN_COMPONENT_CONFIGURATION.
     */
    public static final String SCREEN_COMPONENT_CONFIGURATION = "screen_component_configuration";
    /**
     * The constant SCREEN_CONFIGURATION.
     */
    public static final String SCREEN_CONFIGURATION = "screen_configuration";
    /**
     * The constant SCREEN_DEFINITION.
     */
    public static final String SCREEN_DEFINITION = "screen_definition";
    /**
     * The constant TABLE_CONFIG_COLUMN_DETAILS.
     */
    public static final String TABLE_CONFIG_COLUMN_DETAILS = "table_definition_column_details";
    /**
     * The constant USER_ACCOUNT.
     */
    public static final String USER_ACCOUNT = "user_account";
    /**
     * The constant REDIS_LOCALE_VIEW.
     */
    public static final String REDIS_LOCALE_VIEW = "redis_locale_view";
    /**
     * The constant REPO_CONFIG.
     */
    public static final String REPO_CONFIG = "repo_config";
    /**
     * The constant TENANT_INFO.
     */
    public static final String TENANT_INFO = "tenant_definition";
    /**
     * The constant LNS_SYSTEM_DEFINITION.
     */
    public static final String LNS_SYSTEM_DEFINITION = "lns_system_definition";
    /**
     * The constant ENVIRONMENT_CONFIGURATION.
     */
    public static final String ENVIRONMENT_CONFIGURATION = "configuration";
    /**
     * The constant SYSTEM_SETTINGS.
     */
    public static final String SYSTEM_SETTINGS = "system_settings";
    /**
     * The constant DRIVE_FILE_USER_SPACE_DATA.
     */
    public static final String DRIVE_FILE_USER_SPACE_DATA = "drive_file_user_space_data";
    /**
     * The constant USER_CALENDAR_DATA.
     */
    public static final String HOLIDAY_CALENDAR = "holiday_calendar";
    /**
     * The constant USER_CALENDAR.
     */
    public static final String USER_CALENDAR = "calendar_definition";
    /**
     * The constant COUNTRY.
     */
    public static final String COUNTRY = "all_country_data";
    /**
     * The constant AUTONUMBER_MASTER.
     */
    public static final String AUTONUMBER_MASTER = "autonumber_definition";
    /**
     * The constant SCREEN_COMPONENT_FOCUS.
     */
    public static final String SCREEN_COMPONENT_FOCUS = "screen_component_focus";
    /**
     * The constant SECURITY_OBJECT.
     */
    public static final String SECURITY_OBJECT = "security_object";
    /**
     * The constant USER_COUNTRY_DEFINITION.
     */
    public static final String USER_COUNTRY_DEFINITION = "user_country_definition";
    /**
     * The constant COUNTRY_TIMEZONE.
     */
    public static final String COUNTRY_TIMEZONE = "country_timezone";
    /**
	 * The constant INI_STORAGE.
	 */
	public static final String INI_STORAGE = "ini_storage";
	/**
	 * The constant INI_STORE_DTO.
	 */
	public static final String INI_STORE_DTO = "ini_store_dto";

}
