package com.nn.sova.constants;

/**
 * The type Class configuration constants.
 * 
 * @author Anand Kumar
 */
public class ClassConfigurationConstants {
    /**
     * Instantiates a new Class configuration constants.
     */
    ClassConfigurationConstants(){

    }

    /**
     * The constant ID.
     */
    public static final String ID = "id";
    /**
     * The constant CLASSPATH.
     */
    public static final String CLASSPATH = "class_path";
}
