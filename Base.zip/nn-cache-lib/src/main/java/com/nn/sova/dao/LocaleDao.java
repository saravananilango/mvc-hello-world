package com.nn.sova.dao;

import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.constants.UserAccountColumnConstants;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.logger.ApplicationLogger;
import org.apache.commons.collections4.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The type Locale dao.
 *
 * @author Anand Kumar
 */
public class LocaleDao {
    /**
     * The constant instance.
     */
    private static LocaleDao instance = null;
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(LocaleDao.class);

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static LocaleDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new LocaleDao();
        }
        return instance;
    }

    /**
     * Gets all locale info.
     *
     * @return the all locale info
     * @throws QueryException the query exception
     */
    public Map<String, List<Object>> getAllLocaleInfo() throws QueryException {
        QueryBuilder localeBuilder = new QueryBuilder().btSchema();
        Map<String, List<Object>> resultMap = new HashMap<>();
        List<Map<String, Object>> localeList = localeBuilder.select().from(TableNamesConstants.LOCALE_CFG, "locale").build(false).execute();
        Map<String, List<Map<String, Object>>> localeMap = localeList.stream().collect(Collectors.groupingBy(map->map.get("lang_code").toString()));
        List<Object> langList = new ArrayList<>(localeMap.keySet());
        resultMap.put("langData",langList);
        return resultMap;
    }

    /**
     * Gets locale info by lang cd.
     *
     * @param locale the locale
     * @return the locale info by lang cd
     */
    public List<Object> getLocaleInfoByLangCd(String locale) throws QueryException {
        QueryBuilder queryBuilder = new QueryBuilder().btSchema();
        List<Map<String, Object>> resultList = queryBuilder.select().from(TableNamesConstants.LOCALE_CFG, "cfg")
                .join(TableNamesConstants.LOCALE_CFG_TEXT, "cfg_text",
                        ConditionBuilder.instance().eq("cfg.lang_code", UserAccountColumnConstants.LOCALE, true))
                .where(ConditionBuilder.instance().eq(UserAccountColumnConstants.LOCALE,
                        locale))
                .build(false).execute();
        return resultList.stream().map(mapper -> mapper.get(UserAccountColumnConstants.LANG_CODE))
                .collect(Collectors.toList());
    }

    /**
     * Gets locale business object.
     *
     * @return the locale business object
     */
    public Object getLocaleBusinessObject() throws QueryException {
        SelectQueryBuilder selectBuilder = new QueryBuilder().btSchema().select();
        return selectBuilder.from(TableViewsConstants.REDIS_LOCALE_VIEW).build(false).execute();
    }
}
