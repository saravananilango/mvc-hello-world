package com.nn.sova.service.screen;

import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.constants.ScreenConfigurationConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.ScreenConfigurationDao;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.logger.ApplicationLogger;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The type Screen configuration cache service.
 *
 * @author Anand Kumar
 */
public class ScreenConfigurationCacheService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(ScreenConfigurationCacheService.class);
    /**
     * The constant instance.
     */
    private static ScreenConfigurationCacheService instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static ScreenConfigurationCacheService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new ScreenConfigurationCacheService();
        }
        return instance;
    }

    /**
     * Gets screen component focus data.
     *
     * @param cacheKey the cache key
     * @param screenId the screen id
     * @return the screen component focus data
     */
    @SuppressWarnings("unchecked")
	public List<Map<String, Object>> getScreenComponentFocusData(String cacheKey, String screenId) throws QueryException {
        Map<String, List<Map<String, Object>>> screenComponentFocusDataMap = (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(screenComponentFocusDataMap) && screenComponentFocusDataMap.containsKey(screenId)) {
            return screenComponentFocusDataMap.get(screenId);
        }
        updateScreenComponentFocusData();
        screenComponentFocusDataMap = (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(screenComponentFocusDataMap) && screenComponentFocusDataMap.containsKey(screenId)) {
            return screenComponentFocusDataMap.get(screenId);
        }
        return Collections.emptyList();
    }

	public String getProgramNameByApiUrl(String apiUrl, String productCode, String subProductCode) throws QueryException {
    	String cacheKey = CacheKeyHelper.getProgramNameByApiUrlKey(apiUrl,productCode,subProductCode);
    	String programName = CacheManager.getInstance().get(cacheKey);
        if(Objects.nonNull(programName))
            return programName;
        updateProgramNameByApiUrl(cacheKey,apiUrl,productCode,subProductCode);
    	programName = CacheManager.getInstance().get(cacheKey);
        if(Objects.nonNull(programName))
            return programName;
        return StringUtils.EMPTY;
    }
    
    private void updateProgramNameByApiUrl(String cacheKey,String apiUrl, String productCode, String subProductCode) throws QueryException {
    	String programName = ScreenConfigurationDao.getProgramNameByApiUrl(apiUrl, productCode, subProductCode);
        if(StringUtils.isNotEmpty(programName)) {
        	CacheManager.getInstance().set(cacheKey, programName);
        } else{
        	CacheManager.getInstance().set(cacheKey, StringUtils.EMPTY);
        }
	}

	/**
     * Update screen component focus data.
     * @return 
     */
    @SuppressWarnings("unchecked")
	public void updateScreenComponentFocusData() throws QueryException {
        List<Map<String, Object>> screenConfigurationList = (List<Map<String, Object>>) ScreenConfigurationDao.getScreenComponentFocusData();
        if(CollectionUtils.isNotEmpty(screenConfigurationList)) {
            Map<String, List<Map<String, Object>>> dataMap = screenConfigurationList.stream().collect(Collectors.groupingBy(group -> String.valueOf(group.get(ScreenConfigurationConstants.SCREEN_ID))));
            CacheManager.getInstance().saveAsObject(CacheKeyHelper.getScreenComponentFocusDataKey(), dataMap);
        } else{
            CacheManager.getInstance().saveAsObject(CacheKeyHelper.getScreenComponentFocusDataKey(), Collections.emptyMap());
        }
    }

    /**
     * Update screen configuration data.
     *
     * @param screenIdList the screen id list
     */
    public void updateScreenConfigurationData(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<Map<String, Object>> screenConfigurationList = (List<Map<String, Object>>) ScreenConfigurationDao.getScreenConfigurationDataByScreen(screenIdList, envInfo);
        if(CollectionUtils.isNotEmpty(screenConfigurationList)) {
            Map<Object, List<Map<String, Object>>> screenConfigDataList = TypeConversionHelper.reMapScreenConfigData(screenConfigurationList);
            CacheManager.getInstance().saveAsBulkDataWithEnvInfo(CacheKeyHelper.getScreenConfigurationPrefixKey(), new HashMap<Object, Object>(screenConfigDataList), redisInfo);
        }else{
            CacheManager.getInstance().saveAsBulkDataWithEnvInfo(CacheKeyHelper.getScreenConfigurationPrefixKey(), Collections.emptyMap(), redisInfo);
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Gets screen details based on application code.
     *
     * @param cacheKey the cache key
     * @return the screen details based on application code
     */
    public Map<String, List<Map<String, Object>>> getScreenDetailsBasedOnApplicationCode(String cacheKey) {
        return (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
    }

    /**
     * Gets screen configuration data by locale.
     *
     * @param cacheKey the cache key
     * @param screenId the screen id
     * @param locale   the locale
     * @return the screen configuration data by locale
     */
    @SuppressWarnings("unchecked")
	public Map<String, Object> getScreenConfigurationDataByLocale(String cacheKey, String screenId, String locale) throws QueryException {
        List<Map<String, Object>> screenConfigurationList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(CollectionUtils.isNotEmpty(screenConfigurationList)) {
            Optional<Map<String, Object>> returnValue = TypeConversionHelper.reConstructscreenConfigurationData(screenConfigurationList, screenId, locale);
            if(returnValue.isPresent()) {
                return returnValue.get();
            }
        }
        updateScreenConfigurationData(Arrays.asList(screenId));
        screenConfigurationList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(CollectionUtils.isNotEmpty(screenConfigurationList)) {
            Optional<Map<String, Object>> returnValue = TypeConversionHelper.reConstructscreenConfigurationData(screenConfigurationList, screenId, locale);
            if(returnValue.isPresent()) {
                return returnValue.get();
            }
        }
        return Collections.emptyMap();
    }

    /**
     * Update screen configuration data.
     *
     * @param screenIdList the screen id list
     */
    public void updateScreenConfigurationData(List<Object> screenIdList) throws QueryException {
        List<Map<String, Object>> screenConfigurationList = ScreenConfigurationDao.getScreenConfigurationDataByScreen(screenIdList);
        if(CollectionUtils.isNotEmpty(screenConfigurationList)) {
            Map<Object, List<Map<String, Object>>> screenConfigDataList = TypeConversionHelper.reMapScreenConfigData(screenConfigurationList);
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getScreenConfigurationPrefixKey(), new HashMap<Object, Object>(screenConfigDataList));
        }else{
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getScreenConfigurationPrefixKey(), Collections.emptyMap());
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Gets screen component definition data.
     *
     * @param cacheKey the cache key
     * @param screenId the screen id
     * @return the screen component definition data
     */
    public Object getScreenComponentData(String cacheKey, String screenId) throws QueryException {
        Object screenComponentDefinitionObj = CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(screenComponentDefinitionObj)) {
            return screenComponentDefinitionObj;
        }
        updateScreenComponentData(Arrays.asList(screenId));
        screenComponentDefinitionObj = CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(screenComponentDefinitionObj)) {
            return screenComponentDefinitionObj;
        }
        return null;
    }

    /**
     * Update screen component definition data.
     *
     * @param screenIdList the screen id list
     */
    public void updateScreenComponentData(List<String> screenIdList) throws QueryException {
        List<Map<String, Object>> componentDefList = ScreenConfigurationDao.getScreenComponentData(screenIdList);
        if(CollectionUtils.isNotEmpty(componentDefList)) {
            Map<Object, List<Map<String, Object>>> screenConfigDataList = TypeConversionHelper.reMapScreenComponentData(componentDefList);
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getScreenComponentDefinitionPrefixKey(), new HashMap<>(screenConfigDataList));
        } else{
        	CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getScreenComponentDefinitionPrefixKey(), Collections.emptyMap());
        }
    }

    /**
     * Update screen component definition data.
     */
    public void updateScreenComponentData() throws QueryException {
        List<Map<String, Object>> componentDefList = ScreenConfigurationDao.getScreenComponentData();
        if(CollectionUtils.isNotEmpty(componentDefList)) {
            Map<Object, List<Map<String, Object>>> screenConfigDataList = TypeConversionHelper.reMapScreenComponentData(componentDefList);
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getScreenComponentDefinitionPrefixKey(), new HashMap<Object, Object>(screenConfigDataList));
        }else{
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getScreenComponentDefinitionPrefixKey(), Collections.emptyMap());
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }
}
