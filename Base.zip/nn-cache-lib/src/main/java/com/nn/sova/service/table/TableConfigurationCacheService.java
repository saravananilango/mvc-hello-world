package com.nn.sova.service.table;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.TableConfigurationDao;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.common.CommonCacheService;
import com.nn.sova.service.locale.LocaleCacheService;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Table configuration cache service.
 */
public class TableConfigurationCacheService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(LocaleCacheService.class);
    /**
     * The constant instance.
     */
    private static TableConfigurationCacheService instance = null;

    /**
     * Instantiates a new Table configuration cache service.
     */
    private TableConfigurationCacheService() {
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static TableConfigurationCacheService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new TableConfigurationCacheService();
        }
        return instance;
    }

    /**
     * Gets data element by screen info.
     *
     * @param cacheKey the cache key
     * @param screenId the screen id
     * @param locale   the locale
     * @return the data element by screen info
     */
    @SuppressWarnings("unchecked")
	public List<Map<String, Object>> getDataElementByScreenInfo(String cacheKey, String screenId, String locale) throws QueryException {
        Map<String, List<Map<String, Object>>> dataGroupedBylocaleMap = (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(dataGroupedBylocaleMap)) {
            return  dataGroupedBylocaleMap.get(locale);
        }
        updateDataElementByScreenInfo(Collections.singletonList(screenId));
        dataGroupedBylocaleMap = (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(dataGroupedBylocaleMap)) {
            return  dataGroupedBylocaleMap.get(locale);
        }
        return Collections.emptyList();
    }
    
    /**
     * Gets data element by component Definition Type
     *
     * @param cacheKey         the cache key
     * @param screenDefType the screen definition type
     * @param key              the component key to be appended in cacheKey
     * @param locale           the locale
     * @return                 the data element by screen info
     */
    @SuppressWarnings("unchecked")
	public List<Map<String, Object>> getDataElementByScreenDefType(String cacheKey, String screenDefType, String key, String locale) throws QueryException {
        Map<String, List<Map<String, Object>>> dataGroupedBylocaleMap = (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(dataGroupedBylocaleMap) && dataGroupedBylocaleMap.containsKey(locale)) {
            return  dataGroupedBylocaleMap.get(locale);
        }
        updateDataElementByScreenDefType(cacheKey, screenDefType, key);
        dataGroupedBylocaleMap = (Map<String, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(dataGroupedBylocaleMap)  && dataGroupedBylocaleMap.containsKey(locale) ) {
            return  dataGroupedBylocaleMap.get(locale);
        }
        return Collections.emptyList();
    }
    
    /**
     * delete cache by componentDefType
     *
     * @param prefixCacheKey cache key prefix
     * @return boolean
     */
    public boolean deleteCacheByCompDef(String prefixCacheKey) {
    	if(StringUtils.isNotEmpty(prefixCacheKey)) {  
    		 Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixCacheKey);
             CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
     		return true;
    	}
    	return false;
    }

    /**
     * Gets data element for app generator.
     *
     * @param cacheKey    the cache key
     * @param dataElement the data element
     * @return the data element for app generator
     */
    @SuppressWarnings("unchecked")
	public Map<Object, List<Map<String, Object>>> getDataElementForAppGenerator(String cacheKey, String dataElement) throws QueryException {
        Map<Object, Map<Object, List<Map<String, Object>>>> dataMap = (Map<Object, Map<Object, List<Map<String, Object>>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(dataMap) && dataMap.containsKey(dataElement)) {
            return dataMap.get(dataElement);
        }
        updateDataElementForAppGenerator(cacheKey);
        dataMap = (Map<Object, Map<Object, List<Map<String, Object>>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(dataMap) && dataMap.containsKey(dataElement)) {
            return dataMap.get(dataElement);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets server side validation.
     *
     * @param cacheKey  the cache key
     * @param tableName the table name
     * @return the server side validation
     */
    public Object getServerSideValidation(String cacheKey, String tableName) throws QueryException {
        Object serverSideValidationObj = CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(serverSideValidationObj)) {
            return serverSideValidationObj;
        }
        updateServerSideValidation(Arrays.asList(tableName));
        serverSideValidationObj = CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(serverSideValidationObj)) {
            return serverSideValidationObj;
        }
        return StringUtils.EMPTY;
    }

    /**
     * Update server side validation.
     *
     * @param tableList the table list
     */
    public void updateServerSideValidation(List<Object> tableList) throws QueryException {
        List<List<Map<String, Object>>> dataList = TableConfigurationDao.getServerSideValidation(tableList);
        Map<String, Map<Object, List<Map<String, Object>>>> tableMap = TypeConversionHelper.groupServerValidationByLocale(dataList);
        if(MapUtils.isNotEmpty(tableMap)) {
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getServerSideValidationPrefixKey(), new HashMap<Object, Object>(tableMap));
        } 
        Map<Object, List<Map<String, Object>>> encryptDataMap = TypeConversionHelper.groupEncryptionDataByTableName(dataList);
        if(MapUtils.isNotEmpty(encryptDataMap)) {
            CacheManager.getInstance().saveAsBulkData(CacheKeyHelper.getServerSideValidationEncryptionPrefixKey(), new HashMap<Object, Object>(encryptDataMap));
        }
    }

    /**
     * Update server side validation.
     *
     * @param tableList the table list
     * @param envInfo   the env info
     */
    public void updateServerSideValidation(List<Object> tableList, EnvironmentDetailsEntity envInfo) throws QueryException {
        RedisEnvInfo redisNode = TypeConversionHelper.getRedisNode(envInfo);
        List<List<Map<String, Object>>> dataList = TableConfigurationDao.getServerSideValidation(tableList, envInfo);
        Map<String, Map<Object, List<Map<String, Object>>>> tableMap = TypeConversionHelper.groupServerValidationByLocale(dataList);
        if(MapUtils.isNotEmpty(tableMap)) {
            CacheManager.getInstance().saveAsBulkDataWithEnvInfo(CacheKeyHelper.getServerSideValidationPrefixKey(), new HashMap<Object, Object>(tableMap), redisNode);
        } else{
            CacheManager.getInstance().saveAsBulkDataWithEnvInfo(CacheKeyHelper.getServerSideValidationPrefixKey(), Collections.emptyMap(), redisNode);
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
        Map<Object, List<Map<String, Object>>> encrptDataMap = TypeConversionHelper.groupEncryptionDataByTableName(dataList);
        if(MapUtils.isNotEmpty(encrptDataMap)) {
            CacheManager.getInstance().saveAsBulkDataWithEnvInfo(CacheKeyHelper.getServerSideValidationEncryptionPrefixKey(), new HashMap<Object, Object>(encrptDataMap), redisNode);
        } else{
            CacheManager.getInstance().saveAsBulkDataWithEnvInfo(CacheKeyHelper.getServerSideValidationEncryptionPrefixKey(), Collections.emptyMap(), redisNode);

            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update data element for app generator.
     *
     * @param cacheKey the cache key
     */
    private void updateDataElementForAppGenerator(String cacheKey) throws QueryException {
        Map<Object, Map<Object, List<Map<String, Object>>>> screenDataElementMap = TableConfigurationDao.getInstance().getDataElementForAppGenerator();
        if(MapUtils.isNotEmpty(screenDataElementMap)) {
            CacheManager.getInstance().saveAsObject(cacheKey, screenDataElementMap);
        } else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
        }
    }

    /**
     * Update data element by Screen Definition Type
     *
     * @param cacheKey         the cache key
     * @param screenDefType the screen definition type
     * @param screenKey        the screen key for identification
     */
    public void updateDataElementByScreenDefType(String cacheKey, String screenDefType, String screenKey) throws QueryException {
        Map<String, Map<String, List<Map<String, Object>>>> screenDataElementMap = TableConfigurationDao.getInstance().getDataElementByScreenDefType(screenDefType, screenKey);
        if(MapUtils.isNotEmpty(screenDataElementMap)) {
            CacheManager.getInstance().saveAsObject(cacheKey, screenDataElementMap.get(screenKey));
        } else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }
    
    /**
     * Update data element by screen info.
     *
     * @param screenIdKeyList the screen id key list
     */
    public void updateDataElementByScreenInfo(List<Object> screenIdKeyList) throws QueryException {
        Map<String, Map<String, List<Map<String, Object>>>> screenDataElementMap = TableConfigurationDao.getInstance().getDataElementByScreenInfo(screenIdKeyList);
        if(Objects.nonNull(screenDataElementMap) && !screenDataElementMap.isEmpty()) {
            for (Map.Entry<String, Map<String, List<Map<String, Object>>>> dataElementMap : screenDataElementMap.entrySet()) {
                String key = CacheKeyHelper.getScreenDataElementKey(dataElementMap.getKey());
                CacheManager.getInstance().saveAsObject(key, dataElementMap.getValue());
            }
        }
    }

    /**
     * Update data element by screen info.
     */
    public void updateDataElementByScreenInfo() throws QueryException {
        Map<String, Map<String, List<Map<String, Object>>>> screenDataElementMap = TableConfigurationDao.getInstance().getDataElementByScreenInfo();
        if(Objects.nonNull(screenDataElementMap) && !screenDataElementMap.isEmpty()) {
            for (Map.Entry<String, Map<String, List<Map<String, Object>>>> dataElementMap : screenDataElementMap.entrySet()) {
                String key = CacheKeyHelper.getScreenDataElementKey(dataElementMap.getKey());
                CacheManager.getInstance().saveAsObject(key, dataElementMap);
            }
        } else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update data elements by env info.
     *
     * @param screenList the screen list
     * @param envInfo    the env info
     */
    public void updateDataElementsByEnvInfo(List<Object> screenList, EnvironmentDetailsEntity envInfo) throws QueryException {
        RedisEnvInfo redisEnv = TypeConversionHelper.getRedisNode(envInfo);
        Map<String, Map<String, List<Map<String, Object>>>> screenDataElementMap = TableConfigurationDao.getInstance().getAllDataElementsByEnvInfo(envInfo, screenList);
        if(Objects.nonNull(screenDataElementMap) && !screenDataElementMap.isEmpty()) {
            for (Map.Entry<String, Map<String, List<Map<String, Object>>>> dataElementMap : screenDataElementMap.entrySet()) {
                String key = CacheKeyHelper.getScreenDataElementKey(dataElementMap.getKey());
                CacheManager.getInstance().saveAsObjectWithEnvInfo(key, dataElementMap, redisEnv);
            }
        } else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update all screen data elements.
     */
    public void updateAllScreenDataElements() throws QueryException {
        Map<String, Map<String, List<Map<String, Object>>>> screenDataElementMap = TableConfigurationDao.getInstance().getAllDataElements();
        if(Objects.nonNull(screenDataElementMap) && !screenDataElementMap.isEmpty()) {
            for (Map.Entry<String, Map<String, List<Map<String, Object>>>> dataElementMap : screenDataElementMap.entrySet()) {
                String key = CacheKeyHelper.getScreenDataElementKey(dataElementMap.getKey());
                CacheManager.getInstance().saveAsObject(key, dataElementMap);
            }
        } else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Remove data element.
     *
     * @param cachePrefixKey the cache prefix key
     * @param screenId       the screenId
     */
    public void removeDataElement(String cachePrefixKey, String screenId) {
        CacheManager.getInstance().deleteKey(cachePrefixKey.concat(screenId));
    }

    /**
     * Remove data element.
     *
     * @param cachePrefixKey the cache prefix key
     * @param serviceIdList  the service id list
     */
    public void removeDataElement(String cachePrefixKey, List<String> serviceIdList) {
        List<String> screenIdList = new ArrayList<>(serviceIdList);
        screenIdList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().del(screenIdList.toArray(new String[screenIdList.size()]));
    }

    /**
     * Remove data element.
     *
     * @param cachePrefixKey the cache prefix key
     * @param serviceIdList  the service id list
     * @param envInfo        the env info
     */
    public void removeDataElement(String cachePrefixKey, List<Object> serviceIdList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<Object> screenIdList = new ArrayList<>(serviceIdList);
        screenIdList.replaceAll(serviceId -> cachePrefixKey.concat(String.valueOf(serviceId)));
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(screenIdList.toArray(new String[screenIdList.size()]), redisInfo);
    }

    /**
     * Remove data element.
     *
     * @param cachePrefixKey           the cache prefix key
     * @param elementIdList            the element id list
     * @param dataFormatList            the data class list
     * @param charsetList              the charset list
     * @param masterList               the master list
     * @param environmentDetailsEntity the environment details entity
     */
    public void removeDataElement(String cachePrefixKey, List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                  EnvironmentDetailsEntity environmentDetailsEntity) throws QueryException {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(environmentDetailsEntity);
        List<Object> serviceList = TableConfigurationCacheService.getInstance().getScreenByCompData(elementIdList, dataFormatList, charsetList,
                masterList, environmentDetailsEntity);
        if(CollectionUtils.isNotEmpty(serviceList)) {
            serviceList.replaceAll(serviceId -> cachePrefixKey.concat(String.valueOf(serviceId)));
            CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(serviceList.toArray(new String[serviceList.size()]), redisInfo);
        }
    }

    /**
     * Remove data element.
     *
     * @param cachePrefixKey the cache prefix key
     * @param elementIdList  the element id list
     * @param dataFormatList  the data class list
     * @param charsetList    the charset list
     * @param masterList     the master list
     */
    public void removeDataElement(String cachePrefixKey, List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList,
                                  List<Object> masterList) throws QueryException {
        List<Object> serviceList = TableConfigurationCacheService.getInstance().getScreenByCompData(elementIdList, dataFormatList, charsetList, masterList);
        if(CollectionUtils.isNotEmpty(serviceList)) {
            serviceList.replaceAll(serviceId -> cachePrefixKey.concat(String.valueOf(serviceId)));
            CacheManager.getInstance().del(serviceList.toArray(new String[serviceList.size()]));
        }
    }

    /**
     * Remove encryption details.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableName      the table name
     */
    public void removeEncryptionDetails(String cachePrefixKey, String tableName) {
        CacheManager.getInstance().deleteKey(cachePrefixKey.concat(tableName));
    }

    /**
     * Remove encryption details.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableNameList  the table name list
     */
    public void removeEncryptionDetails(String cachePrefixKey, List<String> tableNameList) {
        List<String> tableList = new ArrayList<>(tableNameList);
        tableList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().del(tableList.toArray(new String[tableList.size()]));
    }

    /**
     * Remove encryption details.
     *
     * @param cachePrefixKey           the cache prefix key
     * @param tableName                the table name
     * @param environmentDetailsEntity the environment details entity
     */
    public void removeEncryptionDetails(String cachePrefixKey, String tableName, EnvironmentDetailsEntity environmentDetailsEntity) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(environmentDetailsEntity);
        CacheManager.getInstance().deleteKeyWithEnvInfo(cachePrefixKey.concat(tableName), redisInfo);
    }

    /**
     * Remove encryption details.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableNameList  the table name list
     * @param envInfo        the env info
     */
    public void removeEncryptionDetails(String cachePrefixKey, List<Object> tableNameList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<Object> tableList = new ArrayList<>(tableNameList);
        tableList.replaceAll(tableName -> cachePrefixKey.concat(String.valueOf(tableName)));
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(tableList.toArray(new String[tableList.size()]), redisInfo);
    }

    /**
     * Remove table config.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableList      the table list
     * @param envInfo        the env info
     */
    public void removeTableConfig(String cachePrefixKey, List<Object> tableList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<Object> tableDetailList = new ArrayList<>(tableList);
        tableDetailList.replaceAll(tableName -> cachePrefixKey.concat(String.valueOf(tableName)));
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(tableDetailList.toArray(new String[tableDetailList.size()]),
                redisInfo);
    }

    /**
     * Remove table config.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableList      the table list
     */
    public void removeTableConfig(String cachePrefixKey, List<String> tableList) {
        List<Object> tableDetailList = new ArrayList<>(tableList);
        tableDetailList.replaceAll(tableName -> cachePrefixKey.concat(String.valueOf(tableName)));
        CacheManager.getInstance().del(tableDetailList.toArray(new String[tableDetailList.size()]));
    }

    /**
     * Remove view config.
     *
     * @param cachePrefixKey the cache prefix key
     * @param viewList       the view list
     */
    public void removeViewConfig(String cachePrefixKey, List<String> viewList) {
        List<String> viewNameList = new ArrayList<>(viewList);
        viewNameList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().del(viewNameList.toArray(new String[viewNameList.size()]));
    }

    /**
     * Remove view config.
     *
     * @param cachePrefixKey the cache prefix key
     * @param viewList       the view list
     * @param envInfo        the env info
     */
    public void removeViewConfig(String cachePrefixKey, List<String> viewList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<String> viewNameList = new ArrayList<>(viewList);
        viewNameList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(viewNameList.toArray(new String[viewNameList.size()]), redisInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableName      the table name
     */
    public void removeServerSideValidation(String cachePrefixKey, String tableName) {
        CacheManager.getInstance().deleteKey(cachePrefixKey.concat(tableName));
        String encryptionPrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        String tableConfigPrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        removeEncryptionDetails(encryptionPrefixKey, tableName);
        removeTableConfig(tableConfigPrefixKey, Collections.singletonList(tableName));
    }

    /**
     * Remove server side validation.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableNameList  the table name list
     */
    public void removeServerSideValidation(String cachePrefixKey, List<String> tableNameList) {
        List<String> tableDetailList = new ArrayList<>(tableNameList);
        tableDetailList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().del(tableDetailList.toArray(new String[tableDetailList.size()]));
        String encryptionPrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        String tableConfigPrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        removeEncryptionDetails(encryptionPrefixKey, tableNameList);
        removeTableConfig(tableConfigPrefixKey, tableNameList);
    }

    /**
     * Remove server side validation.
     *
     * @param cachePrefixKey the cache prefix key
     * @param tableNameList  the table name list
     * @param envInfo        the env info
     */
    public void removeServerSideValidation(String cachePrefixKey, List<String> tableNameList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<String> tableDetailList = new ArrayList<>(tableNameList);
        tableDetailList.replaceAll(tableName -> cachePrefixKey.concat(String.valueOf(tableName)));
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(tableDetailList.toArray(new String[tableDetailList.size()]), redisInfo);
        String encryptionPrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        String tableConfigPrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        removeEncryptionDetails(encryptionPrefixKey, tableDetailList);
        removeTableConfig(tableConfigPrefixKey, tableDetailList);
    }

    /**
     * Remove server side validation.
     *
     * @param cachePrefixKey  the cache prefix key
     * @param dataElementList the data element list
     * @param dataFormatList   the data class list
     * @param charsetList     the charset list
     * @param masterList      the master list
     * @param envInfo         the env info
     */
    public void removeServerSideValidation(String cachePrefixKey, List<Object> dataElementList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                           EnvironmentDetailsEntity envInfo) throws QueryException {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<Object> tableNameList = TableConfigurationDao.getInstance().getTableNameList(dataElementList, dataFormatList, charsetList, masterList, envInfo);
        if(CollectionUtils.isNotEmpty(tableNameList)) {
            tableNameList.replaceAll(tableName -> cachePrefixKey.concat(String.valueOf(tableName)));
            CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(tableNameList.toArray(new String[tableNameList.size()]), redisInfo);
        }
        String encryptionPrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        String tableConfigPrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        removeEncryptionDetails(encryptionPrefixKey, tableNameList, envInfo);
        removeTableConfig(tableConfigPrefixKey, tableNameList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param cachePrefixKey the cache prefix key
     * @param dataFormatList  the data class list
     * @param charsetList    the charset list
     * @param masterList     the master list
     * @param envInfo        the env info
     */
    public void removeServerSideValidation(String cachePrefixKey, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                           EnvironmentDetailsEntity envInfo) throws QueryException {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<Object> tableNameList = TableConfigurationDao.getInstance().getTableNameList(dataFormatList, charsetList, masterList, envInfo);
        if(CollectionUtils.isNotEmpty(tableNameList)) {
            tableNameList.replaceAll(tableName -> cachePrefixKey.concat(String.valueOf(tableName)));
            CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(tableNameList.toArray(new String[tableNameList.size()]), redisInfo);
        }
        String encryptionPrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        String tableConfigPrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        removeEncryptionDetails(encryptionPrefixKey, tableNameList, envInfo);
        removeTableConfig(tableConfigPrefixKey, tableNameList, envInfo);
    }

    /**
     * Remove server side validation with service id.
     *
     * @param cachePrefixKey the cache prefix key
     * @param screenId       the screen id
     */
    public void removeServerSideValidationWithServiceId(String cachePrefixKey, String screenId) throws QueryException {
        List<String> tableNameList = TableConfigurationDao.getInstance().getTableNameList(screenId);
        if(CollectionUtils.isNotEmpty(tableNameList)) {
            tableNameList.replaceAll(cachePrefixKey::concat);
            CacheManager.getInstance().del(tableNameList.toArray(new String[tableNameList.size()]));
        }
        String encryptionPrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        String tableConfigPrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        removeEncryptionDetails(encryptionPrefixKey, tableNameList);
        removeTableConfig(tableConfigPrefixKey, tableNameList);
    }

    /**
     * Remove database handler details.
     *
     * @param cachePrefixKey  the cache prefix key
     * @param productCodeList the product code list
     */
    public void removeDatabaseHandlerDetails(String cachePrefixKey, List<String> productCodeList) {
        List<String> productList = new ArrayList<>(productCodeList);
        productList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().del(productList.toArray(new String[productList.size()]));
    }

    /**
     * Remove database handler details.
     *
     * @param cachePrefixKey  the cache prefix key
     * @param productCodeList the product code list
     * @param envInfo         the env info
     */
    public void removeDatabaseHandlerDetails(String cachePrefixKey, List<String> productCodeList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        List<String> productList = new ArrayList<>(productCodeList);
        productList.replaceAll(cachePrefixKey::concat);
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(productList.toArray(new String[productList.size()]), redisInfo);
    }

    /**
     * Gets screen by component data.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @param envInfo       the env info
     * @return the screen by comp data
     */
    public List<Object> getScreenByCompData(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList, EnvironmentDetailsEntity envInfo) throws QueryException {
        return TableConfigurationDao.getScreenByCompData(elementIdList, dataFormatList, charsetList, masterList, envInfo);
    }

    /**
     * Gets screen by comp data.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @return the screen by comp data
     */
    public List<Object> getScreenByCompData(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList) throws QueryException {
        return TableConfigurationDao.getScreenByCompData(elementIdList, dataFormatList, charsetList, masterList);
    }
}
