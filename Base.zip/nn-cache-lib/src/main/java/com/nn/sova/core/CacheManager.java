package com.nn.sova.core;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

import com.nn.sova.entity.RedisEnvInfo;

/**
 * The type cache manager.
 * 
 * @author Anand Kumar
 */
public class CacheManager {

    CacheCommandFactory cacheCommandFactory;

    private static CacheManager instance = null;

    private static CacheManager productInstance = null;

    CacheManager(boolean isProductEnabled) {
        cacheCommandFactory = new CacheCommandFactory(isProductEnabled);
    }

    public static CacheManager getInstance() {
        if (Objects.isNull(instance)) {
            instance = new CacheManager(false);
        }
        return instance;
    }

    public static CacheManager getProductInstance() {
        if (Objects.isNull(productInstance)) {
            productInstance = new CacheManager(true);
        }
        return productInstance;
    }

    public String get(String key) {
        return cacheCommandFactory.get(key);
    }

    public Object getWithObject(String cacheKey) {
        return cacheCommandFactory.get(cacheKey.getBytes());
    }

    public String get(String key, RedisEnvInfo envInfo) {
        return cacheCommandFactory.get(key, envInfo);
    }

    public Object getWithObject(String cacheKey, RedisEnvInfo envInfo) {
        return cacheCommandFactory.get(cacheKey.getBytes(), envInfo);
    }

    public void set(String key, Object value) {
        cacheCommandFactory.set(key, value.toString());
    }

    public void saveWithExpiration(String cacheKey, Object cacheObjValue, int timeUnit) {
        cacheCommandFactory.setEx(cacheKey, cacheObjValue, timeUnit);
    }

    public void saveAsObject(String key, Object value) {
        cacheCommandFactory.set(key, value);
    }

    public void saveAsObjectWithEnvInfo(String key, Object value, RedisEnvInfo envInfo) {
        cacheCommandFactory.set(key, value, envInfo);
    }

    public void saveAsBulkData(Map<Object, Object> dataMap) {
        cacheCommandFactory.set(dataMap);
    }

    public void saveAsBulkData(String prefixKey, Map<Object, Object> dataMap) {
        cacheCommandFactory.set(dataMap, prefixKey);
    }

    public void saveAsBulkDataWithEnvInfo(String prefixKey, Map<Object, Object> dataMap, RedisEnvInfo envInfo) {
        cacheCommandFactory.set(dataMap, prefixKey, envInfo);
    }

    public void del(byte[]... keys) {
        cacheCommandFactory.del(keys);
    }

    public void del(String[] keys) {
        cacheCommandFactory.del(keys);
    }

    public void deleteMultipleKeys(String[] keys) {
        cacheCommandFactory.del(keys);
    }

    public void deleteKey(byte[] keys) {
        cacheCommandFactory.del(keys);
    }

    public void deleteKey(String key) {
        cacheCommandFactory.del(key);
    }

    public void deleteKeyWithEnvInfo(String key, RedisEnvInfo envInfo) {
        cacheCommandFactory.del(key, envInfo);
    }

    public void deleteMultipleKeyWithEnvInfo(String[] keys, RedisEnvInfo envInfo) {
        cacheCommandFactory.del(keys, envInfo);
    }

    public Set<String> findCustomKeys(String key) {
        return cacheCommandFactory.search(key);
    }

    public Set<String> findRedisKeys(String key) {
        return cacheCommandFactory.search(key);
    }

    public Set<String> searchAllKeys(String key, int count, String cursor) {
        return cacheCommandFactory.searchFullText(key, count, cursor);
    }

    public Set<String> findPrefixRedisKeys(String key) {
        return cacheCommandFactory.searchWithPrefix(key);
    }

    public Set<String> findPrefixRedisKeys(String key, RedisEnvInfo envInfo) {
        return cacheCommandFactory.searchWithPrefix(key, envInfo);
    }

    public Map<String, Object> findRedisKeys(String cursor, String key, int fetchLimit) {
        return cacheCommandFactory.searchFullText(cursor, key, fetchLimit);
    }

    public long getDBSize() {
        return cacheCommandFactory.getDBSize();
    }

    public boolean isKeyExists(String key) {
        return cacheCommandFactory.isKeyExists(key);
    }

    public long getTTLByKey(String key) {
        return cacheCommandFactory.getTTLByKey(key);
    }

    public void flushAll() {
        cacheCommandFactory.flushAll();
    }
}
