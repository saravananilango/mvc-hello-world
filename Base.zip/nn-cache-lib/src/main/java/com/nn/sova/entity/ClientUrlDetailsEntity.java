package com.nn.sova.entity;

import lombok.Data;

/**
 * Instantiates a new client url details entity.
 * 
 * @author vellaichamy
 */
@Data
public class ClientUrlDetailsEntity {

	/** The nn client id. */
	private String clientId;
	
	/** The nn method url. */
	private String methodUrl;
	
	/** The nn method name. */
	private String methodType;
	
	/** The nn max limit per sec. */
	private long maxLimitPerSec;
	
	/** The nn max limit per min. */
	private long maxLimitPerMin;
	
	/** The nn max limit per hour. */
	private long maxLimitPerHour;
	
	/** The nn max limit per day. */
	private long maxLimitPerDay;
	
	/** The tenant id. */
	private String tenantId;
}
