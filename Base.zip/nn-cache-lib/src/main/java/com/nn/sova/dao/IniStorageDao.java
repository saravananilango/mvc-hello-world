package com.nn.sova.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.postgresql.util.PGobject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.DeleteQueryBuilder;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * IniDao class is used to operate on ini tables.
 * 
 * @implments IniDao
 * @author Mohammed Shameer U
 */

public class IniStorageDao {

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(IniStorageDao.class);

	/** The constant instance. */
	private static IniStorageDao instance = null;

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static IniStorageDao getInstance() {
		if (Objects.isNull(instance)) {
			instance = new IniStorageDao();
		}
		return instance;
	}

	/**
	 * getIniDataByKeyList is used to get the ini data by list of keys.
	 * 
	 * @param iniKey
	 * @return
	 */
	public List<Map<String, Object>> getIniDataByKeyList(List<Object> iniKey) {
		try {
			List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().from(TableNamesConstants.INI_STORAGE)
					.get("ini_object", "ini_key")
					.where(ConditionBuilder.instance().inWithList("ini_key", iniKey).and()
							.eq("tenant_id", ContextBean.getTenantId()).and().eq("user_id", ContextBean.getUserId()))
					.build(false).execute();
			return dataList.stream().map(mapper -> {
				mapper.put("ini_object",
						JsonUtils.fromJsonOrNull(((PGobject) mapper.get("ini_object")).getValue(), List.class));
				return mapper;
			}).collect(Collectors.toList());
		} catch (QueryException e) {
			logger.error("Exception occured while getting data from ini storage data.", e);
			return new ArrayList<>();
		}
	}

	/**
	 * getIniServiceDataByKeyList is used to get the ini service data by list of
	 * keys.
	 * 
	 * @param componentId
	 * @return
	 */
	public List<Map<String, Object>> getIniServiceDataByKeyList(List<Object> componentId) {
		ConditionBuilder condition = ConditionBuilder.instance().eq("tenant_id", ContextBean.getTenantId()).and()
				.eq("user_id", ContextBean.getUserId()).and().eq("screen_id", ContextBean.getSid());
		if (CollectionUtils.isNotEmpty(componentId)) {
			condition.and().inWithList("component_id", componentId);
		}
		try {
			return new QueryBuilder().btSchema().select()
					.get("component_id", "component_type", "ini_value", "target_id", "additional_key","is_autoset_field")
					.from(TableNamesConstants.INI_STORE_DTO).where(condition).build(false).execute();
		} catch (QueryException e) {
			logger.error("Exception occured while getting data from ini storage data.", e);
			return new ArrayList<>();
		}
	}

	/**
	 * setIniDataByKeyList is used to set ini data in list.
	 * 
	 * @param iniList
	 * @throws QueryException
	 */
	public void setIniDataByKeyList(List<Map<String, Object>> iniList) throws QueryException {
		List<Map<String, Object>> dataList = iniList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put("ini_storage.tenant_id", ContextBean.getTenantId());
			resultMap.put("ini_storage.user_id", ContextBean.getUserId());
			resultMap.put("ini_storage.ini_key", mapper.get("ini_key"));
			resultMap.put("ini_storage.ini_object", this.getPgObject(mapper.get("ini_value")));
			return resultMap;
		}).collect(Collectors.toList());
		new QueryBuilder().btSchema().insert().upsertWithKeyList(TableNamesConstants.INI_STORAGE, dataList, true,
				Arrays.asList("ini_object"), "tenant_id", "user_id", "ini_key");
	}

	/**
	 * setIniServiceDataByKeyList is used to set service data through list.
	 * 
	 * @param iniList
	 * @throws QueryException
	 */
	public void setIniServiceDataByKeyList(List<Map<String, Object>> iniList) throws QueryException {
		List<Map<String, Object>> dataList = iniList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put("ini_store_dto.tenant_id", ContextBean.getTenantId());
			resultMap.put("ini_store_dto.user_id", ContextBean.getUserId());
			resultMap.put("ini_store_dto.screen_id", ContextBean.getSid());
			resultMap.put("ini_store_dto.component_id", mapper.get("component_id"));
			resultMap.put("ini_store_dto.component_type", mapper.get("component_type"));
			resultMap.put("ini_store_dto.ini_value", mapper.get("ini_value"));
			resultMap.put("ini_store_dto.target_id", mapper.get("target_id"));
			resultMap.put("ini_store_dto.additional_key", mapper.get("additional_key"));
			resultMap.put("ini_store_dto.is_autoset_field", Objects.nonNull(mapper.get("is_autoset"))? Boolean.valueOf(String.valueOf(mapper.get("is_autoset"))): false);
			return resultMap;
		}).collect(Collectors.toList());
		new QueryBuilder().btSchema().insert().upsertWithKeyList(TableNamesConstants.INI_STORE_DTO, dataList, true,
				Arrays.asList("component_type", "ini_value", "target_id", "additional_key","is_autoset_field"), "tenant_id", "user_id",
				"screen_id", "component_id");
	}

	/**
	 * To get PGObject from JSON
	 * 
	 * @param key
	 * @param dataMap
	 * @return
	 */
	PGobject getPgObject(Object encodeObject) {
		ObjectMapper mapper = new ObjectMapper();
		PGobject pgObject = new PGobject();
		pgObject.setType("json");
		try {
			pgObject.setValue(mapper.writeValueAsString(encodeObject));
		} catch (Exception e) {
		}
		return pgObject;
	}

	/**
	 * clearCommonIni is used to clear the common ini data.
	 * 
	 * @throws QueryException
	 */
	public void clearCommonIni() throws QueryException {
		new QueryBuilder().btSchema().delete().from(TableNamesConstants.INI_STORAGE)
				.where(ConditionBuilder.instance().eq("user_id", ContextBean.getUserId())).build().execute();
	}
	
	/**
	 * clearScreenIni is used to clear the screen ini data.
	 * 
	 * @throws QueryException
	 */
	public void clearScreenIni() throws QueryException {
		new QueryBuilder().btSchema().delete().from(TableNamesConstants.INI_STORE_DTO).where(ConditionBuilder
				.instance().eq("user_id", ContextBean.getUserId()).and().eq("tenant_id", ContextBean.getTenantId()))
		.build().execute();
	}

	/**
	 * getIniDataForUser is used to get the ini data for the logged in user.
	 * 
	 * @return
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getIniDataForUser() throws QueryException {
		return new QueryBuilder().btSchema()
				.select().get("ini_key").from(TableNamesConstants.INI_STORAGE).where(ConditionBuilder.instance()
						.eq("tenant_id", ContextBean.getTenantId()).and().eq("user_id", ContextBean.getUserId()))
				.build(false).execute();
	}
	
	/**
	 * getIniServiceDataForUser is used to get the screen ini data for the user
	 * 
	 * @return
	 * @throws QueryException
	 */
	public List<Map<String, Object>> getIniServiceDataForUser() throws QueryException {
		return new QueryBuilder().btSchema()
				.select().get("screen_id").from(TableNamesConstants.INI_STORE_DTO).where(ConditionBuilder.instance()
						.eq("tenant_id", ContextBean.getTenantId()).and().eq("user_id", ContextBean.getUserId()))
				.build(false).execute();
	}
}