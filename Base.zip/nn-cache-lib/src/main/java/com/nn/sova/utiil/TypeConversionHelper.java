package com.nn.sova.utiil;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.CaseFormat;
import com.nn.sova.constants.CommonConstants;
import com.nn.sova.constants.RoleConfigurationConstants;
import com.nn.sova.constants.ScreenConfigurationConstants;
import com.nn.sova.constants.TableConfigurationColumnConstants;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.UserAccountColumnConstants;
import com.nn.sova.entity.DataElementEntity;
import com.nn.sova.entity.DivisionEntity;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.entity.ScreenDefinitionEntity;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.utility.helper.TokenTypeIdentifier;
import com.nn.sova.utility.logger.ApplicationLogger;

import redis.clients.jedis.HostAndPort;

/**
 * The Type conversion helper class .
 */
public class TypeConversionHelper {
	/**
	 * Instantiates a new Type conversion helper.
	 */
	private TypeConversionHelper() {
	}

	/**
	 * The constant logger.
	 */
	private static final ApplicationLogger logger = ApplicationLogger.create(TypeConversionHelper.class);

	/**
	 * form Data Element List
	 *
	 * @param divisionEntityList               the division entity list
	 * @param inputDataElementList             the data element list
	 * @param componentAdditionalAttributeList
	 * @return screen data element list
	 */
	private static List<Map<String, Object>> formDataElement(List<Map<String, Object>> divisionEntityList,
			List<Map<String, Object>> inputDataElementList,
			List<Map<String, Object>> componentAdditionalAttributeList) {
		List<Map<String, Object>> finalDataElementList = new ArrayList<>();
		Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>> attributeMap = componentAdditionalAttributeList
				.stream()
				.collect(Collectors.groupingBy(map -> map.get("locale").toString(),
						Collectors.groupingBy(map -> map.get("screen_definition_id").toString(),
								Collectors.groupingBy(row -> row.get("component_id").toString()))));
		Map<Object, List<Map<String, Object>>> divisionLangMap = divisionEntityList.stream()
				.collect(Collectors.groupingBy(map -> map.get("lang_cd")));
		Map<Object, List<Map<String, Object>>> dataElementLangMap = inputDataElementList.stream()
				.collect(Collectors.groupingBy(map -> map.get("locale")));
		dataElementLangMap.entrySet().stream().forEach(langMap -> {
			List<Map<String, Object>> divEntityList = divisionLangMap.get(langMap.getKey());
			Map<String, List<Map<String, Object>>> divisionDomainMap = new HashMap<>();
			if (CollectionUtils.isNotEmpty(divEntityList)) {
				divisionDomainMap.putAll(divEntityList.stream()
						.collect(Collectors.groupingBy(map -> map.get("data_format").toString())));
			}
			Map<Object, Map<Object, List<Map<String, Object>>>> attributeLangMap = attributeMap.get(langMap.getKey());
			List<Map<String, Object>> dataElemetEntityList = langMap.getValue();
			dataElemetEntityList.stream().forEach(entity -> {
				if (CollectionUtils.isNotEmpty(divisionDomainMap.get(entity.get("data_format")))) {
					List<Map<String, Object>> divisionList = divisionDomainMap.get(entity.get("data_format"));
					divisionList.sort(Comparator.nullsLast(Comparator.comparing(
							map -> (Integer) (Objects.nonNull(map.get("display_order")) ? map.get("display_order")
									: "0"),
							Comparator.nullsLast(Comparator.naturalOrder()))));
					entity.put("divisionList", divisionList);
				} else {
					entity.put("divisionList", new ArrayList<>());
				}
				if (Objects.nonNull(attributeLangMap)
						&& Objects.nonNull(attributeLangMap.get(entity.get("screen_definition_id")))
						&& attributeLangMap.get(entity.get("screen_definition_id"))
								.containsKey(entity.get("component_id"))
						&& CollectionUtils.isNotEmpty(attributeLangMap.get(entity.get("screen_definition_id"))
								.get(entity.get("component_id")))) {
					entity.put("additionalAttribute",
							attributeLangMap.get(entity.get("screen_definition_id")).get(entity.get("component_id")));
				} else {
					entity.put("additionalAttribute", new ArrayList<>());
				}
				finalDataElementList.add(entity);
			});
		});

		return finalDataElementList;
	}

	/**
	 * Group the data element based on group key and locale
	 *
	 * @param finalDataElementList the data element list
	 * @param groupKey             grouping key
	 * @return screen data element list
	 */
	private static Map<String, Map<String, List<Map<String, Object>>>> groupByLocaleAndKey(
			List<Map<String, Object>> finalDataElementList, String groupKey) {
		Map<String, Map<String, List<Map<String, Object>>>> finalMap = new HashMap<>();
		Map<String, List<Map<String, Object>>> screenDefIdMap = finalDataElementList.stream()
				.collect(Collectors.groupingBy(map -> map.get(groupKey).toString()));
		screenDefIdMap.entrySet().stream().forEach(mapObj -> {
			Map<String, List<Map<String, Object>>> localeBasedscreenDataElementMap = mapObj.getValue().stream()
					.collect(Collectors.groupingBy(map -> map.get("locale").toString()));
			String screenId = mapObj.getKey();
			finalMap.put(screenId, localeBasedscreenDataElementMap);
		});
		return finalMap;
	}

	/**
	 * Group data element by screenId / locale
	 *
	 * @param divisionEntityList               the division entity list
	 * @param inputDataElementList             the data element list
	 * @param componentAdditionalAttributeList
	 * @return screen data element list
	 */
	public static Map<String, Map<String, List<Map<String, Object>>>> groupByScreenIdAndLocale(
			List<Map<String, Object>> divisionEntityList, List<Map<String, Object>> inputDataElementList,
			List<Map<String, Object>> componentAdditionalAttributeList) {
		List<Map<String, Object>> finalDataElementList = formDataElement(divisionEntityList, inputDataElementList,
				componentAdditionalAttributeList);
		return groupByLocaleAndKey(finalDataElementList, "screen_id");
	}

	/**
	 * Group data element by screenDefId / locale based on component_def_type
	 *
	 * @param divisionEntityList               the division entity list
	 * @param inputDataElementList             the data element list
	 * @param componentAdditionalAttributeList
	 * @return screen data element list
	 */
	public static Map<String, Map<String, List<Map<String, Object>>>> groupByCompKeyAndLocale(
			List<Map<String, Object>> divisionEntityList, List<Map<String, Object>> inputDataElementList,
			List<Map<String, Object>> componentAdditionalAttributeList) {
		List<Map<String, Object>> finalDataElementList = formDataElement(divisionEntityList, inputDataElementList,
				componentAdditionalAttributeList);
		return groupByLocaleAndKey(finalDataElementList, "screen_definition_id");
	}

	/**
	 * combine input field data element with component prop and charset props
	 *
	 * @param dataElementDataList the data element data list
	 * @return List of DataElementEntity
	 */
	public static List<DataElementEntity> inputCompObjectToDataElementEntity(
			List<Map<String, Object>> dataElementDataList) {
		return dataElementDataList.stream().map(valueMap -> {
			DataElementEntity dataElementEntity = new DataElementEntity();
			List<String> charsetArray = new ArrayList<>();
			objectToDataElementEntity(dataElementEntity, valueMap);
			objectToComponentProps(dataElementEntity, valueMap);
			objectToCharsetProps(dataElementEntity, valueMap, charsetArray);
			return dataElementEntity;
		}).collect(Collectors.toList());
	}

	/**
	 * combine button data elements with component prop and converts to
	 * DataElementEntity
	 *
	 * @param dataElementDataList the data element data list
	 * @return the list of DataElements
	 */
	public static List<DataElementEntity> buttonCompObjectToDataElementEntity(
			List<Map<String, Object>> dataElementDataList) {
		return dataElementDataList.stream().map(valueMap -> {
			DataElementEntity dataElementEntity = new DataElementEntity();
			dataElementEntity.setId(objectToString(valueMap.get(TableConfigurationColumnConstants.COMPONENT_ID)));
			dataElementEntity
					.setElementType(objectToString(valueMap.get(TableConfigurationColumnConstants.ELEMENT_TYPE)));
			dataElementEntity.setLangCd(objectToString(valueMap.get(TableConfigurationColumnConstants.LOCALE)));
			dataElementEntity.setScreenId(objectToString(valueMap.get(TableConfigurationColumnConstants.SCREEN_ID)));
			dataElementEntity.setLabel(objectToString(valueMap.get("text")));
			dataElementEntity.setHintLabel(objectToString(valueMap.get("hint_text")));
			dataElementEntity.setShortcutKey(objectToString(valueMap.get("shortcut")));
			String dbName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL,
					objectToString(valueMap.get(TableConfigurationColumnConstants.DB_NAME)));
			String colName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL,
					objectToString(valueMap.get(TableConfigurationColumnConstants.DB_COL_NAME)));
			String dbColName = StringUtils.EMPTY;
			if (StringUtils.isNotEmpty(dbName) && StringUtils.isNotEmpty(colName)) {
				dbColName = dbName.concat(TokenTypeIdentifier.DOT.value()).concat(colName);
			}
			dataElementEntity.setDbcolumn(dbColName);
			objectToComponentProps(dataElementEntity, valueMap);
			return dataElementEntity;
		}).collect(Collectors.toList());
	}

	/**
	 * Object to data element entity.
	 *
	 * @param dataElementEntity the data element entity
	 * @param valueMap          the value map
	 */
	private static void objectToDataElementEntity(DataElementEntity dataElementEntity, Map<String, Object> valueMap) {
		dataElementEntity.setId(objectToString(valueMap.get(TableConfigurationColumnConstants.COMPONENT_ID)));
		dataElementEntity.setDataElement(objectToString(valueMap.get(TableConfigurationColumnConstants.ELEMENT_ID)));
		dataElementEntity.setDataFormat(objectToString(valueMap.get(TableConfigurationColumnConstants.DATA_FORMAT)));
		dataElementEntity.setMinLength(objectToString(valueMap.get(TableConfigurationColumnConstants.MIN_LENGTH)));
		dataElementEntity.setMaxLength(objectToString(valueMap.get(TableConfigurationColumnConstants.MAX_LENGTH)));
		dataElementEntity.setDataType(objectToString(valueMap.get(TableConfigurationColumnConstants.DATA_TYPE)));
		dataElementEntity.setElementType(objectToString(valueMap.get(TableConfigurationColumnConstants.ELEMENT_TYPE)));
		dataElementEntity.setMinVal(objectToString(valueMap.get(TableConfigurationColumnConstants.MIN_VAL)));
		dataElementEntity.setMaxVal(objectToString(valueMap.get(TableConfigurationColumnConstants.MAX_VAL)));
		dataElementEntity.setMaxDecimal(objectToString(valueMap.get(TableConfigurationColumnConstants.MAX_DECIMAL)));
		dataElementEntity.setMinDate(objectToString(valueMap.get(TableConfigurationColumnConstants.MIN_DATE)));
		dataElementEntity.setMaxDate(objectToString(valueMap.get(TableConfigurationColumnConstants.MAX_DATE)));
		dataElementEntity.setLangCd(objectToString(valueMap.get(TableConfigurationColumnConstants.LOCALE)));
		dataElementEntity.setScreenId(objectToString(valueMap.get(TableConfigurationColumnConstants.SCREEN_ID)));
		if (Objects.isNull(valueMap.get(TableConfigurationColumnConstants.TEXT_TYPE))) {
			dataElementEntity.setTextType(TableConfigurationColumnConstants.TEXT_TYPE_MEDIUM);
			dataElementEntity.setLabel(objectToString(valueMap.get(TableConfigurationColumnConstants.MEDIUM_TEXT)));
		} else if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.TEXT_TYPE))) {
			if (valueMap.get(TableConfigurationColumnConstants.TEXT_TYPE).toString()
					.equalsIgnoreCase(TableConfigurationColumnConstants.TEXT_TYPE_SHORT)) {
				dataElementEntity.setTextType(TableConfigurationColumnConstants.TEXT_TYPE_SHORT);
				dataElementEntity.setLabel(objectToString(valueMap.get(TableConfigurationColumnConstants.SHORT_TEXT)));
			} else if (valueMap.get(TableConfigurationColumnConstants.TEXT_TYPE).toString()
					.equalsIgnoreCase(TableConfigurationColumnConstants.TEXT_TYPE_LONG)) {
				dataElementEntity.setTextType(TableConfigurationColumnConstants.TEXT_TYPE_LONG);
				dataElementEntity.setLabel(objectToString(valueMap.get(TableConfigurationColumnConstants.LONG_TEXT)));
			} else {
				dataElementEntity.setTextType(TableConfigurationColumnConstants.TEXT_TYPE_MEDIUM);
				dataElementEntity.setLabel(objectToString(valueMap.get(TableConfigurationColumnConstants.MEDIUM_TEXT)));
			}
		}
		dataElementEntity.setShortText(objectToString(valueMap.get(TableConfigurationColumnConstants.SHORT_TEXT)));
		dataElementEntity.setMediumText(objectToString(valueMap.get(TableConfigurationColumnConstants.MEDIUM_TEXT)));
		dataElementEntity.setLongText(objectToString(valueMap.get(TableConfigurationColumnConstants.LONG_TEXT)));
		dataElementEntity.setHintLabel(objectToString(valueMap.get(TableConfigurationColumnConstants.HINT_LABEL)));
		dataElementEntity.setPlaceLabel(objectToString(valueMap.get(TableConfigurationColumnConstants.PLACE_LABEL)));
		dataElementEntity
				.setEnableChars(objectToString(valueMap.get(TableConfigurationColumnConstants.ENABLE_CHARACTERS)));
		dataElementEntity
				.setDisableChars(objectToString(valueMap.get(TableConfigurationColumnConstants.DISABLE_CHARACTERS)));
		dataElementEntity.setPattern(objectToString(valueMap.get(TableConfigurationColumnConstants.REGEX_PATTERN)));
		dataElementEntity.setShortcutKey(objectToString(valueMap.get(TableConfigurationColumnConstants.SHORTCUT)));
		if (Objects.isNull(valueMap.get(TableConfigurationColumnConstants.IS_DISABLED))) {
			dataElementEntity.setDisabled(null);
		} else {
			dataElementEntity.setDisabled(
					String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_DISABLED)).equals("true"));
		}
		String dbName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL,
				objectToString(valueMap.get(TableConfigurationColumnConstants.DB_NAME)));
		String colName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL,
				objectToString(valueMap.get(TableConfigurationColumnConstants.DB_COL_NAME)));
		String dbColName = StringUtils.EMPTY;
		if (StringUtils.isNotEmpty(dbName) && StringUtils.isNotEmpty(colName)) {
			dbColName = dbName.concat(TokenTypeIdentifier.DOT.value()).concat(colName);
		}
		dataElementEntity.setDbcolumn(dbColName);
		dataElementEntity.setTableName(objectToString(valueMap.get(TableConfigurationColumnConstants.TABLE_NAME)));
		dataElementEntity
				.setSetColumnName(objectToString(valueMap.get(TableConfigurationColumnConstants.SET_COLUMN_NAME)));
		dataElementEntity
				.setShowColumnNames(objectToString(valueMap.get(TableConfigurationColumnConstants.SHOW_COLUMN_NAME)));
		dataElementEntity.setMaxMatches(objectToString(valueMap.get(TableConfigurationColumnConstants.MAX_MATCHES)));
		dataElementEntity
				.setMasterId(objectToString(valueMap.get(TableConfigurationColumnConstants.MASTER_SEARCH_IDS)));
	}

	/**
	 * Object to component props.
	 *
	 * @param dataElementEntity the data element entity
	 * @param valueMap          the value map
	 */
	private static void objectToComponentProps(DataElementEntity dataElementEntity, Map<String, Object> valueMap) {
		if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_DISPLAYED)).equals(CommonConstants.NULL)) {
			dataElementEntity.setDisplay(null);
		} else if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_DISPLAYED))
				.equals(CommonConstants.TRUE)) {
			dataElementEntity.setDisplay(CommonConstants.TRUE);
		} else {
			dataElementEntity.setDisplay(CommonConstants.FALSE);
		}
		if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_DISUSE)).equals(CommonConstants.NULL)) {
			dataElementEntity.setDisuse(null);
		} else if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_DISUSE))
				.equals(CommonConstants.TRUE)) {
			dataElementEntity.setDisuse(CommonConstants.TRUE);
		} else {
			dataElementEntity.setDisuse(CommonConstants.FALSE);
		}
		if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_READ_ONLY)).equals(CommonConstants.NULL)) {
			dataElementEntity.setReadonly(null);
		} else if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.IS_READ_ONLY))
				.equals(CommonConstants.TRUE)) {
			dataElementEntity.setReadonly(CommonConstants.TRUE);
		} else {
			dataElementEntity.setReadonly(CommonConstants.FALSE);
		}
		if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.SCREEN_CONFIG_INITIAL_FOCUS))
				.equals(CommonConstants.NULL)) {
			dataElementEntity.setInitialFocus(null);
		} else if (String.valueOf(valueMap.get(TableConfigurationColumnConstants.SCREEN_CONFIG_INITIAL_FOCUS))
				.equals(CommonConstants.TRUE)) {
			dataElementEntity.setInitialFocus(CommonConstants.TRUE);
		} else {
			dataElementEntity.setInitialFocus(CommonConstants.FALSE);
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.IS_UNDERLINED))
				&& Boolean.parseBoolean(valueMap.get(TableConfigurationColumnConstants.IS_UNDERLINED).toString())) {
			dataElementEntity.setUnderlined(true);
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.FONT_STYLE))) {
			dataElementEntity.setFontStyle(valueMap.get(TableConfigurationColumnConstants.FONT_STYLE).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.LABEL_COLOR))) {
			dataElementEntity.setLabelColor(valueMap.get(TableConfigurationColumnConstants.LABEL_COLOR).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.FONT_SIZE))) {
			dataElementEntity.setFontSize(valueMap.get(TableConfigurationColumnConstants.FONT_SIZE).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.LABEL_ALIGN))) {
			dataElementEntity.setLabelAlign(valueMap.get(TableConfigurationColumnConstants.LABEL_ALIGN).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.TEXT_COLOR))) {
			dataElementEntity.setTextColor(valueMap.get(TableConfigurationColumnConstants.TEXT_COLOR).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.INPUT_PADDING))) {
			dataElementEntity.setInputPadding(valueMap.get(TableConfigurationColumnConstants.INPUT_PADDING).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.LABEL_WIDTH))) {
			dataElementEntity.setLabelWidth(valueMap.get(TableConfigurationColumnConstants.LABEL_WIDTH).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.BORDER_COLOR))) {
			dataElementEntity.setBorderColor(valueMap.get(TableConfigurationColumnConstants.BORDER_COLOR).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.BORDER_RADIUS))) {
			dataElementEntity.setBorderRadius(valueMap.get(TableConfigurationColumnConstants.BORDER_RADIUS).toString());
		}
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.ADDITIONAL_ATTRIBUTE))) {
			ObjectMapper mapper = new ObjectMapper();
			try {
				Map<String, Object> resultMap = mapper.readValue(
						valueMap.get(TableConfigurationColumnConstants.ADDITIONAL_ATTRIBUTE).toString(),
						new TypeReference<Map<String, Object>>() {
						});
				if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.ADDITIONAL_ATTRIBUTE))) {
					dataElementEntity.setJsonData(
							valueMap.get(TableConfigurationColumnConstants.ADDITIONAL_ATTRIBUTE).toString());
				}
				if (Objects.nonNull(resultMap.get("leftBorderColor"))) {
					dataElementEntity.setLeftBorderColor(resultMap.get("leftBorderColor").toString());
				} else {
					dataElementEntity.setLeftBorderColor(null);
				}
				if (Objects.nonNull(resultMap.get("rightBorderColor"))) {
					dataElementEntity.setRightBorderColor(resultMap.get("rightBorderColor").toString());
				} else {
					dataElementEntity.setRightBorderColor(null);
				}
				if (Objects.nonNull(resultMap.get("topBorderColor"))) {
					dataElementEntity.setTopBorderColor(resultMap.get("topBorderColor").toString());
				} else {
					dataElementEntity.setTopBorderColor(null);
				}
				if (Objects.nonNull(resultMap.get("bottomBorderColor"))) {
					dataElementEntity.setBottomBorderColor(resultMap.get("bottomBorderColor").toString());
				} else {
					dataElementEntity.setBottomBorderColor(null);
				}
			} catch (IOException exception) {
				logger.error(exception);
			}
		}
	}

	/**
	 * Object to charset props.
	 *
	 * @param dataElementEntity the data element entity
	 * @param valueMap          the value map
	 * @param charsetArray      the charset array
	 */
	private static void objectToCharsetProps(DataElementEntity dataElementEntity, Map<String, Object> valueMap,
			List<String> charsetArray) {
		if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.NOT_NULL))
				&& Boolean.parseBoolean(valueMap.get(TableConfigurationColumnConstants.NOT_NULL).toString())
				&& StringUtils.isNotEmpty(valueMap.get(TableConfigurationColumnConstants.NOT_NULL).toString())) {
			dataElementEntity.setRequired(valueMap.get(TableConfigurationColumnConstants.NOT_NULL).toString());
		} else if (Objects.nonNull(valueMap.get(TableConfigurationColumnConstants.MANDATORY))
				&& Boolean.parseBoolean(valueMap.get(TableConfigurationColumnConstants.MANDATORY).toString())
				&& StringUtils.isNotEmpty(valueMap.get(TableConfigurationColumnConstants.MANDATORY).toString())) {
			dataElementEntity.setRequired(valueMap.get(TableConfigurationColumnConstants.MANDATORY).toString());
		} else {
			dataElementEntity.setRequired(CommonConstants.FALSE);
		}
		if (valueMap.get(TableConfigurationColumnConstants.UPPER_CASE_LATIN).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("u");
		}
		if (valueMap.get(TableConfigurationColumnConstants.LOWER_CASE_LATIN).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("l");
		}
		if (valueMap.get(TableConfigurationColumnConstants.DIGITS).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("0");
		}
		if (valueMap.get(TableConfigurationColumnConstants.SYMBOL).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("#");
		}
		if (valueMap.get(TableConfigurationColumnConstants.HALF_KATAKANA).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("k");
		}
		if (valueMap.get(TableConfigurationColumnConstants.FULL_HIRAGANA).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("H");
		}
		if (valueMap.get(TableConfigurationColumnConstants.FULL_KATAKANA).toString().equals(CommonConstants.TRUE)) {
			charsetArray.add("K");
		}
		if (Boolean.parseBoolean(valueMap.get(TableConfigurationColumnConstants.TAB).toString())) {
			charsetArray.add("TAB");
		}
		if (Boolean.parseBoolean(valueMap.get(TableConfigurationColumnConstants.LINE_SEPERATOR).toString())) {
			charsetArray.add("LS");
		}
		if (Objects.isNull(valueMap.get(TableConfigurationColumnConstants.SPACE))
				|| Boolean.parseBoolean(valueMap.get(TableConfigurationColumnConstants.SPACE).toString())) {
			charsetArray.add("S");
		}
		dataElementEntity.setCharset(charsetArray);
	}

	/**
	 * Object to string conversion.
	 *
	 * @param obj the obj
	 * @return the string
	 */
	public static String objectToString(Object obj) {
		Optional<Object> optionalValue = Optional.ofNullable(obj);
		if (optionalValue.isPresent()) {
			return String.valueOf(optionalValue.get());
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Object to division entity list.
	 *
	 * @param divisionDataList the division data list
	 * @return the list
	 */
	public static List<DivisionEntity> objectToDivisionEntity(List<Map<String, Object>> divisionDataList) {
		return divisionDataList.stream().map(value -> {
			DivisionEntity divisionEntity = new DivisionEntity();
			divisionEntity.setDataFormat(objectToString(value.get(TableNamesConstants.DATA_FORMAT)));
			divisionEntity.setValue(objectToString(value.get("value")));
			divisionEntity.setLabel(objectToString(value.get("text_content")));
			divisionEntity.setIsDefault(objectToString(value.get("default_value")));
			divisionEntity.setLangCd(objectToString(value.get(UserAccountColumnConstants.LOCALE)));
			divisionEntity.setDivisionTextValue(objectToString(value.get("divisionTextValue")));
			if (Objects.nonNull(objectToString(value.get("display_order")))) {
				divisionEntity.setDisplayOrder(Integer.parseInt(objectToString(value.get("display_order"))));
			} else {
				divisionEntity.setDisplayOrder(null);
			}
			return divisionEntity;
		}).collect(Collectors.toList());
	}

	/**
	 * Group data element view object by element id and locale map.
	 *
	 * @param divisionDataList the division data list
	 * @param dataElementList  the data element list
	 * @return data elements
	 */
	public static Map<Object, Map<Object, List<Map<String, Object>>>> groupByElementIdAndLocale(
			List<Map<String, Object>> divisionDataList, List<Map<String, Object>> dataElementList) {
		List<Map<String, Object>> elementList = new ArrayList<>();
		Map<String, List<Map<String, Object>>> divisionLangMap = divisionDataList.stream()
				.collect(Collectors.groupingBy(c -> c.get("locale").toString()));
		Map<String, List<Map<String, Object>>> dataElementLangMap = dataElementList.stream()
				.collect(Collectors.groupingBy(c -> c.get(TableConfigurationColumnConstants.LANG_CD).toString()));
		dataElementLangMap.entrySet().stream().forEach(langMap -> {
			List<Map<String, Object>> divEntityList = divisionLangMap.get(langMap.getKey());
			Map<String, List<Map<String, Object>>> divisionDomainMap = new HashMap<>();
			if (CollectionUtils.isNotEmpty(divEntityList)) {
				divisionDomainMap.putAll(divEntityList.stream().collect(
						Collectors.groupingBy(c -> c.get(TableConfigurationColumnConstants.DATA_FORMAT).toString())));
			}
			List<Map<String, Object>> dataElemetEntityList = langMap.getValue();
			dataElemetEntityList.stream().forEach(entity -> {
				if (CollectionUtils.isNotEmpty(
						divisionDomainMap.get(entity.get(TableConfigurationColumnConstants.DATA_FORMAT).toString()))) {
					entity.put("divisionEntity", divisionDomainMap
							.get(entity.get(TableConfigurationColumnConstants.DATA_FORMAT).toString()));
				} else {
					entity.put("divisionEntity", new ArrayList<>());
				}
				elementList.add(entity);
			});
		});
		return elementList.stream().collect(
				Collectors.groupingBy(elementMap -> String.valueOf(elementMap.get("element_id")), Collectors.groupingBy(
						localeMap -> String.valueOf(localeMap.get(TableConfigurationColumnConstants.LANG_CD)))));
	}

	/**
	 * Gets redis node.
	 *
	 * @param envInfo the env info
	 * @return the redis node
	 */
	public static RedisEnvInfo getRedisNode(EnvironmentDetailsEntity envInfo) {
		RedisEnvInfo redisEnvInfo = new RedisEnvInfo();
		Set<HostAndPort> redisNodes = new HashSet<>();
		redisNodes.add(new HostAndPort(envInfo.getRedisIp(), Integer.parseInt(envInfo.getRedisPort())));
		redisEnvInfo.setRedisNodes(redisNodes);
		return redisEnvInfo;
	}

	/**
	 * Group server validation by locale map.
	 *
	 * @param dataList the data list
	 * @return ServerValidationMap
	 */
	public static Map<String, Map<Object, List<Map<String, Object>>>> groupServerValidationByLocale(
			List<List<Map<String, Object>>> dataList) {
		Map<String, Map<String, List<Map<String, Object>>>> divisionMap = dataList.get(1).stream().collect(Collectors
				.groupingBy(map -> String.valueOf(map.get(TableConfigurationColumnConstants.DATA_FORMAT)), Collectors
						.groupingBy(lang -> String.valueOf(lang.get(TableConfigurationColumnConstants.LANG_CD)))));
		return dataList.get(0).stream().map(action -> {
			action.put("divisionList", divisionMap.get(action.get(TableConfigurationColumnConstants.DATA_FORMAT)));
			return action;
		}).collect(Collectors.groupingBy(map -> String.valueOf(map.get(TableConfigurationColumnConstants.TABLE_NAME)),
				Collectors.groupingBy(lang -> String.valueOf(lang.get(TableConfigurationColumnConstants.LANG_CD)))));
	}

	/**
	 * Group encryption data by table name .
	 *
	 * @param dataList the data list
	 * @return Encryption data Map
	 */
	public static Map<Object, List<Map<String, Object>>> groupEncryptionDataByTableName(
			List<List<Map<String, Object>>> dataList) {
		return dataList.get(2).stream().collect(
				Collectors.groupingBy(map -> String.valueOf(map.get(TableConfigurationColumnConstants.TABLE_NAME))));
	}

	/**
	 * Deserialize bytes object.
	 *
	 * @param bytes the bytes
	 * @return the object
	 * @throws IOException            the io exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	public static Object deserializeBytes(byte[] bytes) throws IOException, ClassNotFoundException {
		ByteArrayInputStream bytesIn = new ByteArrayInputStream(bytes);
		ObjectInputStream ois = new ObjectInputStream(bytesIn);
		Object obj = ois.readObject();
		ois.close();
		return obj;
	}

	/**
	 * Serialize object byte [ ].
	 *
	 * @param obj the obj
	 * @return the byte [ ]
	 * @throws IOException the io exception
	 */
	public static byte[] serializeObject(Object obj) throws IOException {
		ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bytesOut);
		oos.writeObject(obj);
		oos.flush();
		byte[] bytes = bytesOut.toByteArray();
		bytesOut.close();
		oos.close();
		return bytes;
	}

	/**
	 * Screen entity to map map.
	 *
	 * @param screenDefinitionList the screen definition list
	 * @return the map
	 */
	public static Map<String, Map<String, List<ScreenDefinitionEntity>>> screenEntityToMap(
			List<ScreenDefinitionEntity> screenDefinitionList) {
		Map<String, Map<String, List<ScreenDefinitionEntity>>> screenMap = new HashMap<>();
		Map<String, List<ScreenDefinitionEntity>> screenDefinitionMap = screenDefinitionList.stream()
				.collect(Collectors.groupingBy(ScreenDefinitionEntity::getScreenId));
		screenDefinitionMap.entrySet().stream().forEach(mapObj -> {
			Map<String, List<ScreenDefinitionEntity>> langMap = mapObj.getValue().stream()
					.collect(Collectors.groupingBy(ScreenDefinitionEntity::getLangCd));
			screenMap.put(mapObj.getKey(), langMap);
		});
		return screenMap;
	}

	/**
	 * Convert screen def map to entity screen definition entity.
	 *
	 * @param screenDefinitionMap the screen definition map
	 * @param locale              the locale
	 * @return the screen definition entity
	 */
	public static ScreenDefinitionEntity convertScreenDefMapToEntity(Map<String, Object> screenDefinitionMap,
			String locale) {
		ScreenDefinitionEntity screenDefEntity = null;
		List<Object> screenMapList = (List<Object>) screenDefinitionMap.get(locale);
		if (CollectionUtils.isNotEmpty(screenMapList) && screenMapList.get(0) instanceof ScreenDefinitionEntity) {
			screenDefEntity = (ScreenDefinitionEntity) screenMapList.get(0);
		}
		return screenDefEntity;
	}

	/**
	 * Re map screen config data map.
	 *
	 * @param screenConfigurationList the screen configuration list
	 * @return the map
	 */
	public static Map<Object, List<Map<String, Object>>> reMapScreenConfigData(
			List<Map<String, Object>> screenConfigurationList) {
		String cacheKey = CacheKeyHelper.getScreenConfigurationPrefixKey();
		return screenConfigurationList.stream().collect(Collectors.groupingBy(
				action -> String.valueOf(action.get(ScreenConfigurationConstants.SCREEN_CONFIGURATION_SCREEN_ID))));
	}

	/**
	 * Re constructscreen configuration data optional.
	 *
	 * @param screenConfigurationList the screen configuration list
	 * @param screenId                the screen id
	 * @param locale                  the locale
	 * @return the optional
	 */
	public static Optional<Map<String, Object>> reConstructscreenConfigurationData(
			List<Map<String, Object>> screenConfigurationList, String screenId, String locale) {
		return screenConfigurationList.stream()
				.filter(predicate -> predicate.get("screenConfiguration.screenId").toString().equals(screenId)
						&& predicate.get("screenConfigurationText.locale").toString().equals(locale))
				.findFirst();
	}

	/**
	 * Re map screen component data map.
	 *
	 * @param componentDefList the component def list
	 * @return the map
	 */
	public static Map<Object, List<Map<String, Object>>> reMapScreenComponentData(
			List<Map<String, Object>> componentDefList) {
		Map<Object, List<Map<String, Object>>> componentDataMap = new HashMap<>();
		Map<String, List<Map<String, Object>>> groupedData = componentDefList.stream()
				.collect(Collectors.groupingBy(row -> row.get("screenComponentConfiguration.screenId").toString()));
		groupedData.entrySet().stream().forEach(action -> componentDataMap.put(action.getKey(), action.getValue()));
		return componentDataMap;
	}

	/**
	 * Remap obj to message entity message definition entity.
	 *
	 * @param messageIdMap the message id map
	 * @param locale       the locale
	 * @return the message definition entity
	 */
	public static MessageDefinitionEntity remapObjToMessageEntity(Map<String, Object> messageIdMap, String locale) {
		MessageDefinitionEntity messageDefinitionEntity = new MessageDefinitionEntity();
		List<Object> screenMapList = new ArrayList<>();
		if (Objects.nonNull(messageIdMap) && Objects.nonNull(messageIdMap.get(locale))) {
			screenMapList = (List<Object>) messageIdMap.get(locale);
		}
		if (Objects.nonNull(screenMapList) && CollectionUtils.isNotEmpty(screenMapList)) {
			Optional<Object> tempData = screenMapList.stream().findFirst();
			if (tempData.isPresent() && tempData.get() instanceof MessageDefinitionEntity) {
				messageDefinitionEntity = (MessageDefinitionEntity) tempData.get();
			}
		}
		return messageDefinitionEntity;
	}

	/**
	 * Re map message definition data map.
	 *
	 * @param messageEntityList the message entity list
	 * @return the map
	 */
	public static Map<String, Map<String, List<MessageDefinitionEntity>>> reMapMessageDefinitioData(
			List<Map<String, Object>> messageDefList) {
		List<MessageDefinitionEntity> messageEntityList = messageDefList.stream()
				.map(MessageDefinitionEntity::getMessageEntity).collect(Collectors.toList());
		Map<String, Map<String, List<MessageDefinitionEntity>>> messageMap = new HashMap<>();
		Map<String, List<MessageDefinitionEntity>> dataMap = messageEntityList.stream()
				.collect(Collectors.groupingBy(MessageDefinitionEntity::getMessageId));
		dataMap.entrySet().stream().forEach(messageData -> {
			String key = messageData.getKey();
			Map<String, List<MessageDefinitionEntity>> message = messageData.getValue().stream()
					.collect(Collectors.groupingBy(MessageDefinitionEntity::getLangCode));
			messageMap.put(key, message);
		});
		return messageMap;
	}

	/**
	 * Re map message definition data map.
	 *
	 * @param messageEntityList the message entity list
	 * @return the map
	 */
	public static Map<String, Map<String, MessageDefinitionEntity>> reMapApplicationMessageData(
			List<Map<String, Object>> messageDefList) {
		List<MessageDefinitionEntity> messageEntityList = messageDefList.stream()
				.map(MessageDefinitionEntity::getMessageEntity).collect(Collectors.toList());
		Map<String, Map<String, MessageDefinitionEntity>> dataMap = messageEntityList.stream()
				.collect(Collectors.groupingBy(MessageDefinitionEntity::getLangCode,
						Collectors.toMap(MessageDefinitionEntity::getMessageId, map -> map)));
		return dataMap;
	}

	/**
	 * Re map text definition data map.
	 *
	 * @param textDefList the text def list
	 * @return the map
	 */
	public static Map<String, Map<String, Object>> reMapTextDefinitionData(List<Map<String, Object>> textDefList) {
		return textDefList.stream().collect(Collectors.groupingBy(map -> map.get("locale").toString(), Collectors.toMap(
				map -> map.get("text_definition_id").toString(), map -> String.valueOf(map.get("text_content")))));
	}

	/**
	 * Gets text data from map.
	 *
	 * @param dataMap the data map
	 * @param textId  the text id
	 * @param locale  the locale
	 * @return the text data from map
	 */
	public static String getTextDataFromMap(Map<String, Object> dataMap, String textId) {
		if (Objects.nonNull(dataMap) && dataMap.containsKey(textId)) {
			return String.valueOf(dataMap.get(textId));
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Remap product configuration data list.
	 *
	 * @param productTenantConfigurationList the product tenant configuration list
	 * @return the list
	 */
	public static List<String> remapProductConfigurationData(List<Map<String, Object>> productTenantConfigurationList) {
		return productTenantConfigurationList.stream()
				.filter(predicate -> Objects.nonNull(predicate.get(CommonConstants.TENANT_ID)))
				.map(mapper -> Objects.toString(mapper.get(CommonConstants.TENANT_ID), ""))
				.collect(Collectors.toList());
	}

	/**
	 * Remap user data list.
	 *
	 * @param userDataList the user data list
	 * @return the list
	 */
	public static List<Map<String, Object>> remapUserData(List<Map<String, Object>> userDataList) {
		List<Map<String, Object>> userdataList = new ArrayList<>();
		if (Objects.nonNull(userDataList) && CollectionUtils.isNotEmpty(userDataList)) {
			Map<String, Map<String, List<Map<String, Object>>>> userGroup = userDataList.stream()
					.collect(Collectors.groupingBy(
							userIdMap -> String.valueOf(userIdMap.get(UserAccountColumnConstants.USER_ID)),
							Collectors.groupingBy(tenantIdMap -> String
									.valueOf(tenantIdMap.get(UserAccountColumnConstants.TENANT_ID)))));
			userGroup.entrySet().stream().forEach(userEntryAction -> {
				Map.Entry<String, Map<String, List<Map<String, Object>>>> mapEntry = userEntryAction;
				mapEntry.getValue().entrySet().stream().forEach(tenantEntryAction -> {
					Map.Entry<String, List<Map<String, Object>>> userMapEntry = tenantEntryAction;
					List<Boolean> authorityList = new ArrayList<>();
					List<String> roleList = userMapEntry.getValue().stream()
							.filter(predicate -> Objects.nonNull(predicate.get(UserAccountColumnConstants.ROLE_ID)))
							.map(action -> {
								authorityList
										.add(Boolean.parseBoolean(Objects.nonNull(action.get("full_authority_flag"))
												? String.valueOf(action.get("full_authority_flag"))
												: CommonConstants.FALSE));
								return String.valueOf(action.get(UserAccountColumnConstants.ROLE_ID));
							}).collect(Collectors.toList());
					boolean isFullAuthority = authorityList.contains(true);
					Optional<Map<String, Object>> valueOptional = userMapEntry.getValue().stream().findFirst();
					if (valueOptional.isPresent()) {
						Map<String, Object> dataMap = valueOptional.get();
						dataMap.put(UserAccountColumnConstants.IS_FULL_AUTHORITY, isFullAuthority);
						dataMap.put(UserAccountColumnConstants.ROLE_ID, roleList);
						userdataList.add(dataMap);
					}
				});
			});
		}
		return userdataList;
	}

	/**
	 * Remap authorized screens by screen def id map.
	 *
	 * @param dataList the data list
	 * @return the map
	 */
	public static Map<Object, Map<Object, List<Map<String, Object>>>> remapAuthorizedScreensByScreenDefId(
			List<Map<String, Object>> dataList) {
		return dataList.stream().collect(Collectors.groupingBy(
				tenantMap -> String.valueOf(tenantMap.get(RoleConfigurationConstants.TENANT_ID)), Collectors.groupingBy(
						rootMenu -> String.valueOf(rootMenu.get(RoleConfigurationConstants.SCREEN_DEF_ID)))));
	}

	/**
	 * Re map roledata map.
	 *
	 * @param roleList the role list
	 * @return the map
	 */
	public static Map<String, Map<String, List<Map<String, Object>>>> reMapRoledata(
			List<Map<String, Object>> roleList) {
		return roleList.stream().collect(Collectors.groupingBy(
				roleIdMap -> String.valueOf(roleIdMap.get("roleLinkSetting.tenantId")),
				Collectors.groupingBy(tenantIdMap -> String.valueOf(tenantIdMap.get("roleLinkSetting.userId")))));
	}

	/**
	 * Remap linked screens list map.
	 *
	 * @param linkedScreenList the linked screen list
	 * @return the map
	 */
	public static Map<String, Map<String, String>> remapLinkedScreensList(List<Map<String, Object>> linkedScreenList) {
		Map<String, Map<String, String>> linkDataMap = new HashMap<>();
		linkedScreenList.stream().forEach(map -> {
			if (MapUtils.isEmpty(linkDataMap.get(map.get(ScreenConfigurationConstants.SCREEN_ID)))) {
				Map<String, String> linkMap = new HashMap<>();
				linkDataMap.put((String) map.get(ScreenConfigurationConstants.SCREEN_ID), linkMap);
			}
			linkDataMap.get(map.get(ScreenConfigurationConstants.SCREEN_ID)).put(
					map.get(ScreenConfigurationConstants.LINK_ID).toString(),
					map.get(ScreenConfigurationConstants.LINK_SCREEN_ID).toString());
		});
		return linkDataMap;
	}
}
