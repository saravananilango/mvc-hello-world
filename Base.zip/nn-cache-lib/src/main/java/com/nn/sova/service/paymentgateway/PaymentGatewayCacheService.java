package com.nn.sova.service.paymentgateway;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.postgresql.util.PGobject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.PaymentGatewayDao;
import com.nn.sova.exception.QueryException;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * Payment Gateway Cache service
 *
 * @author Vivek Kannan E
 */
public class PaymentGatewayCacheService {
	/**
	 * The constant logger.
	 */
	private static final ApplicationLogger logger = ApplicationLogger.create(PaymentGatewayCacheService.class);

	/**
	 * The MAP_TYPE_REFERENCE.
	 */
	private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE = new TypeReference<Map<String, Object>>() {
	};

	/** MAP_TYPE_MAP_REFERENCE. */
	private static final TypeReference<Map<String, Map<String, Object>>> MAP_TYPE_MAP_REFERENCE = new TypeReference<Map<String, Map<String, Object>>>() {
	};

	/** LIST_REFERENCE */
	private static final TypeReference<List<Map<String, Object>>> LIST_TYPE_REFERENCE = new TypeReference<List<Map<String, Object>>>() {
	};
	/**
	 * The constant instance.
	 */
	private static PaymentGatewayCacheService instance = null;

	/**
	 * Instantiates a new payment gateway service
	 */
	private PaymentGatewayCacheService() {
	}

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static PaymentGatewayCacheService getInstance() {
		if (Objects.isNull(instance)) {
			instance = new PaymentGatewayCacheService();
		}
		return instance;
	}

	/**
	 * Gets payment gateway details by product code and payment type
	 *
	 * @param cacheKey    the cache key
	 * @param productCode the product_code
	 * @param paymentType the payment_type if 0: All; 1: Credit Card; 2: Debit Card;
	 *                    3: UPI; 4: Internet Banking
	 * @param handlerType the handler_type as "primary" || "secondary"
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getPaymentGateWayDetails(String cacheKey, String productCode, Integer paymentType,
			String handlerType) throws QueryException {
		Date sqlCurrentdate = new Date(Calendar.getInstance().getTime().getTime());
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			return getGatewayDetails(cacheValue, cacheKey, productCode, paymentType, handlerType, sqlCurrentdate);
		}
		updatePaymentGateway(cacheKey, productCode, paymentType, sqlCurrentdate);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			return getGatewayDetails(cacheValue, cacheKey, productCode, paymentType, handlerType, sqlCurrentdate);
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	/**
	 * Gets payment gateway details from cache value if value exists in cache
	 *
	 * @param cacheKey       the cache key
	 * @param cacheValue     the cache value
	 * @param productCode    the product_code
	 * @param paymentType    the payment_type if 0: All; 1: Credit Card; 2: Debit
	 *                       Card; 3: UPI; 4: Internet Banking
	 * @param handlerType    the handler_type as "primary" || "secondary"
	 * @param sqlCurrentdate the sqlCurrentdate
	 * @return Map
	 */
	private Map<String, Object> getGatewayDetails(Object cacheValue, String cacheKey, String productCode,
			Integer paymentType, String handlerType, Date sqlCurrentdate) throws QueryException {
		Map<String, Object> resultMap = (Map<String, Object>) cacheValue;
		Object handlerObject = resultMap.get(handlerType);
		if (Objects.nonNull(handlerObject)) {
			Map<String, Object> returnMap = (Map<String, Object>) handlerObject;
			if (!validateDate(returnMap, sqlCurrentdate)) {
				CacheManager.getInstance().deleteKey(cacheKey);
				updatePaymentGateway(cacheKey, productCode, paymentType, sqlCurrentdate);
				cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
				if (Objects.nonNull(cacheValue)) {
					resultMap = (Map<String, Object>) cacheValue;
					handlerObject = resultMap.get(handlerType);
					if (Objects.nonNull(handlerObject)) {
						returnMap = (Map<String, Object>) handlerObject;
					}

				}
			}
			if (MapUtils.isNotEmpty(returnMap)) {
				return returnMap;
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	/**
	 * Gets payment gateway details by product code and gateway ID
	 *
	 * @param cacheKey    the cache key
	 * @param productCode the product_code
	 * @param gatewayId   the gateway_id
	 * @return Map
	 * @throws QueryException
	 */
	public Map<String, Object> getPaymentGateWayDetails(String cacheKey, String productCode, String paymentType,
			String gatewayId) throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			return (Map<String, Object>) cacheValue;
		}
		Date sqlCurrentdate = new Date(Calendar.getInstance().getTime().getTime());
		updatePaymentGateway(cacheKey, productCode, gatewayId, sqlCurrentdate, paymentType);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			return (Map<String, Object>) cacheValue;
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	/**
	 * To update the payment gateway details in cache service
	 *
	 * @param cacheKey       the cacheKey
	 * @param productCode    the product_code
	 * @param gatewayId      the gateway_id
	 * @param sqlCurrentdate the sqlCurrentdate
	 * @param paymentType
	 * @throws QueryException
	 */

	private void updatePaymentGateway(String cacheKey, String productCode, String gatewayId, Date sqlCurrentdate,
			String paymentType) throws QueryException {
		List<Map<String, Object>> paymentGatewayList = PaymentGatewayDao.getInstance()
				.getPaymentGatewayDetails(productCode, gatewayId, sqlCurrentdate, paymentType);
		if (CollectionUtils.isNotEmpty(paymentGatewayList)) {
			CacheManager.getInstance().saveAsObject(cacheKey, paymentGatewayList.get(0));
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * To check the current date is in between the handler_start_date, start_date
	 * and handler_end_date, end_date.
	 *
	 * @param returnMap      the resultMap
	 * @param sqlCurrentdate the sql current date
	 * @return boolean returns true if date is valid, and return false if date is
	 *         not valid or expired.
	 */
	private boolean validateDate(Map<String, Object> returnMap, Date sqlCurrentdate) {
		if (MapUtils.isEmpty(returnMap)) {
			return true;
		}
		Date startDate = (Date) returnMap.get("start_date___date");
		Object dateObject = returnMap.get("end_date___date");
		Date endDate;
		if (ObjectUtils.isEmpty(dateObject)) {
			endDate = sqlCurrentdate;
		} else {
			endDate = (Date) dateObject;
		}
		Date handlerStartDate = (Date) returnMap.get("handler_start_date___date");
		dateObject = returnMap.get("handler_end_date___date");
		Date handlerEndDate;
		if (ObjectUtils.isEmpty(dateObject)) {
			handlerEndDate = sqlCurrentdate;
		} else {
			handlerEndDate = (Date) dateObject;
		}
		boolean isValidPaymentMethod = startDate.compareTo(sqlCurrentdate) * sqlCurrentdate.compareTo(endDate) >= 0;
		boolean isValidHandler = handlerStartDate.compareTo(sqlCurrentdate)
				* sqlCurrentdate.compareTo(handlerEndDate) >= 0;
		return isValidPaymentMethod && isValidHandler;
	}

	/**
	 * To update the payment gateway details in cache service
	 *
	 * @param cacheKey       the cacheKey
	 * @param productCode    the product_code
	 * @param paymentType    the payment_type
	 * @param sqlCurrentdate the sqlCurrentdate
	 */
	private void updatePaymentGateway(String cacheKey, String productCode, Integer paymentType, Date sqlCurrentdate)
			throws QueryException {
		List<Map<String, Object>> paymentGatewayList = PaymentGatewayDao.getInstance()
				.getPaymentGatewayDetails(productCode, paymentType, sqlCurrentdate);
		if (CollectionUtils.isNotEmpty(paymentGatewayList)) {
			Map<String, Object> processedData = new HashMap<>();
			paymentGatewayList.forEach(eachRowMap -> {
				eachRowMap.put("additional_details", JsonUtils.fromJsonOrElse(
						convertJson(eachRowMap.get("additional_details")), MAP_TYPE_REFERENCE, new HashMap<>()));
				if (eachRowMap.get("handler_type").equals("primary")) {
					processedData.put("primary", eachRowMap);
				} else if (eachRowMap.get("handler_type").equals("secondary")) {
					processedData.put("secondary", eachRowMap);
				}
			});
			CacheManager.getInstance().saveAsObject(cacheKey, processedData);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}

	}

	/**
	 * getPaymentGateWayErrorMessageDetails is used to get the error message details
	 * of the payment gateway based on product_code, gateway_code and locale
	 * 
	 * @param cacheKey       the cache key
	 * @param productCode    the product_code
	 * @param gatewayCode    the gateway_code from gateway organisation
	 * @param locale         current user locale
	 * @param inProductCache boolean value to indicate whether it is a product cache
	 * @return Map
	 * @throws QueryException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Map<String, Object>> getPaymentGateWayErrorMessageDetails(String cacheKey, String productCode,
			String gatewayCode, String locale, boolean inProductCache) {
		try {
			Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
			if (Objects.nonNull(cacheValue)) {
				return getGatewayErrorMessageDetails(cacheValue, cacheKey, locale);
			}
			updatePaymentGatewayErrorMessage(cacheKey, productCode, gatewayCode, inProductCache);
			cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
			if (Objects.nonNull(cacheValue)) {
				return getGatewayErrorMessageDetails(cacheValue, cacheKey, locale);
			}
			logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
			return MapUtils.EMPTY_MAP;
		} catch (QueryException | NullPointerException exception) {
			logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
			return MapUtils.EMPTY_MAP;
		}
	}

	/**
	 * getGateWayErrorMessageDetails is used to get the error message details from
	 * cache value
	 * 
	 * @param cacheObject the cache object
	 * @param cacheKey    the cache key
	 * @param locale      current user locale
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Object>> getGatewayErrorMessageDetails(Object cacheObject, String cacheKey,
			String locale) {
		Map<String, Map<String, Map<String, Object>>> resultMap = (Map<String, Map<String, Map<String, Object>>>) cacheObject;
		if (MapUtils.isNotEmpty(resultMap)) {
			if (resultMap.containsKey(locale)) {
				return resultMap.get(locale);
			}
			logger.error(LogMessageConstants.EMPTY_RECORD_FOUND_FOR_LOCALE, locale);
			return MapUtils.EMPTY_MAP;
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	/**
	 * updatePaymentGatewayErrorMessage is store payment gateway error message into
	 * cache service when new error message is created. based on product_code,
	 * gateway_code and locale
	 * 
	 * @param cacheKey       the cache key
	 * @param productCode    the product_code
	 * @param gatewayCode    the gateway_code from gateway organisation
	 * @param inProductCache
	 * @throws QueryException
	 */
	private void updatePaymentGatewayErrorMessage(String cacheKey, String productCode, String gatewayCode,
			boolean inProductCache) throws QueryException {
		List<Map<String, Object>> paymentGatewayErrorList = PaymentGatewayDao.getInstance()
				.getPaymentGatewayErrorMessage(productCode, gatewayCode, inProductCache);
		if (CollectionUtils.isNotEmpty(paymentGatewayErrorList)) {
			Map<String, List<Map<String, Object>>> localeBasedsGatewayErrorMap = paymentGatewayErrorList.stream()
					.collect(Collectors.groupingBy(map -> map.get("locale").toString()));
			Map<String, Map<String, Map<String, Object>>> finalErrorMap = new HashMap<>();
			localeBasedsGatewayErrorMap.keySet().forEach(locale -> {
				List<Map<String, Object>> recordList = localeBasedsGatewayErrorMap.get(locale);
				Map<String, Map<String, Object>> insertMap = new HashMap<>();
				recordList.stream()
						.forEach(eachRecord -> insertMap.put(eachRecord.get("error_code").toString(), eachRecord));
				finalErrorMap.put(locale, insertMap);
			});
			CacheManager.getInstance().saveAsObject(cacheKey, finalErrorMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * getPaymentGateWayErrorItemDetails is used to get the error item details of
	 * the payment gateway based on gateway_code and locale
	 * 
	 * @param cacheKey    the cache key
	 * @param gatewayCode the gateway_code from gateway organization
	 * @param locale      current user locale
	 * @return Map
	 * @throws QueryException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getPaymentGateWayErrorItemDetails(String cacheKey, String gatewayCode, String locale)
			throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			return getGatewayErrorItemDetails(cacheKey, cacheValue, locale);
		}
		updatePaymentGatewayErrorItem(cacheKey, gatewayCode);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			return getGatewayErrorItemDetails(cacheKey, cacheValue, locale);
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	/**
	 * getGatewayErrorItemDetails is used to get the error item details of the
	 * payment gateway based on cache value
	 * 
	 * @param cacheKey    the cache key
	 * @param cacheObject the cache object
	 * @param locale      current user locale
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, String> getGatewayErrorItemDetails(String cacheKey, Object cacheObject, String locale) {
		Map<String, Map<String, String>> resultMap = (Map<String, Map<String, String>>) cacheObject;
		if (MapUtils.isNotEmpty(resultMap)) {
			if (resultMap.containsKey(locale)) {
				return resultMap.get(locale);
			}
			logger.error(LogMessageConstants.EMPTY_RECORD_FOUND_FOR_LOCALE, locale);
			return MapUtils.EMPTY_MAP;
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	/**
	 * updatePaymentGatewayErrorMessage is store payment gateway error message into
	 * cache service when new error message is created. based on product_code,
	 * gateway_code and locale
	 * 
	 * @param cacheKey    the cache key
	 * @param gatewayCode the gateway_code from gateway organization
	 * @throws QueryException
	 */
	private void updatePaymentGatewayErrorItem(String cacheKey, String gatewayCode) throws QueryException {
		List<Map<String, Object>> paymentGatewayErrorItemList = PaymentGatewayDao.getInstance()
				.getPaymentGatewayErrorItem(gatewayCode);
		if (CollectionUtils.isNotEmpty(paymentGatewayErrorItemList)) {
			Map<String, Map<String, String>> localeBasedsGatewayErrorItemMap = paymentGatewayErrorItemList.stream()
					.collect(Collectors.groupingBy(map -> map.get("locale").toString(), HashMap::new, Collectors.toMap(
							e -> Objects.toString(e.get("item_code")), e -> Objects.toString(e.get("item_text"), ""))));
			CacheManager.getInstance().saveAsObject(cacheKey, localeBasedsGatewayErrorItemMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	/**
	 * Converts objects to Json object string
	 *
	 * @param object the object
	 * @return String
	 */
	private String convertJson(Object jsonObject) {
		if (jsonObject instanceof PGobject) {
			return ((PGobject) jsonObject).getValue();
		} else if (jsonObject instanceof Map || jsonObject == null) {
			return JsonUtils.toJsonOrEmpty(jsonObject);
		}
		return jsonObject.toString();

	}

	@SuppressWarnings("unchecked")
	public Map<Integer, String> getPgwTransactionTypeDetails(String cacheKey) throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<Integer, String> resultMap = (Map<Integer, String>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		updatePgwTransactionTypeDetails(cacheKey);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<Integer, String> resultMap = (Map<Integer, String>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	private void updatePgwTransactionTypeDetails(String cacheKey) throws QueryException {
		List<Map<String, Object>> resultList = PaymentGatewayDao.getInstance().getPgwTransactionTypeDetails();
		if (CollectionUtils.isNotEmpty(resultList)) {
			Map<Integer, String> resultMap = resultList.stream()
					.collect(Collectors.toMap(record -> Integer.valueOf(String.valueOf(record.get("transaction_type"))),
							record -> String.valueOf(record.get("transaction_type_name"))));

			CacheManager.getInstance().saveAsObject(cacheKey, resultMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	@SuppressWarnings("unchecked")
	public Map<Integer, String> getPgwTransactionStatusDetails(String cacheKey) throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<Integer, String> resultMap = (Map<Integer, String>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		updatePgwTransactionStatusDetails(cacheKey);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<Integer, String> resultMap = (Map<Integer, String>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	private void updatePgwTransactionStatusDetails(String cacheKey) throws QueryException {
		List<Map<String, Object>> resultList = PaymentGatewayDao.getInstance().getPgwTransactionStatusDetails();
		if (CollectionUtils.isNotEmpty(resultList)) {
			Map<Integer, String> resultMap = resultList.stream()
					.collect(Collectors.toMap(
							record -> Integer.valueOf(String.valueOf(record.get("payment_status_type"))),
							record -> String.valueOf(record.get("payment_status_name"))));

			CacheManager.getInstance().saveAsObject(cacheKey, resultMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String, String> getPgwOrganisationDetails(String cacheKey) throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, String> resultMap = (Map<String, String>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		updatePgwOrganisationDetails(cacheKey);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, String> resultMap = (Map<String, String>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	private void updatePgwOrganisationDetails(String cacheKey) throws QueryException {
		List<Map<String, Object>> resultList = PaymentGatewayDao.getInstance().getPgwOrganisationDetails();
		if (CollectionUtils.isNotEmpty(resultList)) {
			Map<String, String> resultMap = resultList.stream()
					.collect(Collectors.toMap(record -> String.valueOf(record.get("gateway_code")),
							record -> String.valueOf(record.get("gateway_name"))));

			CacheManager.getInstance().saveAsObject(cacheKey, resultMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getPaymentGateWayConfiguration(String cacheKey) {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, Object> resultMap = (Map<String, Object>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		updateGatewayConfiguration(cacheKey);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, Object> resultMap = (Map<String, Object>) cacheValue;
			if (MapUtils.isNotEmpty(resultMap)) {
				return resultMap;
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return MapUtils.EMPTY_MAP;
	}

	private void updateGatewayConfiguration(String cacheKey) {
		Map<String, Object> configMap;
		try {
			configMap = PaymentGatewayDao.getInstance().getPaymentConfiguration();
			if (MapUtils.isNotEmpty(configMap)) {
				CacheManager.getInstance().saveAsObject(cacheKey, configMap);
			} else {
				logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND, cacheKey);
			}
		} catch (QueryException e) {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND, cacheKey);
		}
	}

	public List<Map<String, Object>> getPgwCallbackDetails(String cacheKey, String productCode, String paymentMethod)
			throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			List<Map<String, Object>> callbackList = JsonUtils.fromJsonOrElse(JsonUtils.toJsonOrEmpty(cacheValue),
					LIST_TYPE_REFERENCE, new ArrayList<>());
			if (CollectionUtils.isNotEmpty(callbackList)) {
				return callbackList;
			}
		}
		updateCallbackConfiguration(cacheKey, productCode, paymentMethod);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			List<Map<String, Object>> callbackList = JsonUtils.fromJsonOrElse(JsonUtils.toJsonOrEmpty(cacheValue),
					LIST_TYPE_REFERENCE, new ArrayList<>());
			if (CollectionUtils.isNotEmpty(callbackList)) {
				return callbackList;
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return new ArrayList<>();
	}

	private void updateCallbackConfiguration(String cacheKey, String productCode, String paymentMethod)
			throws QueryException {
		List<Map<String, Object>> callbackList;
		try {
			callbackList = PaymentGatewayDao.getInstance().getPaymentCallbackConfiguration(productCode, paymentMethod);
			if (CollectionUtils.isNotEmpty(callbackList)) {
				CacheManager.getInstance().saveAsObject(cacheKey, callbackList);
			} else {
				logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND, cacheKey);
			}
		} catch (QueryException e) {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND, cacheKey);
		}

	}

	public Map<String, Object> getPgwDetails(String cacheKey, String gatewayId) throws QueryException {
		Object cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, Map<String, Object>> resultMap = JsonUtils.fromJsonOrElse(JsonUtils.toJsonOrEmpty(cacheValue),
					MAP_TYPE_MAP_REFERENCE, new HashMap<>());
			if (MapUtils.isNotEmpty(resultMap) && resultMap.containsKey(gatewayId)) {
				return resultMap.get(gatewayId);
			}
		}
		CacheManager.getInstance().deleteKey(cacheKey);
		updatePgwDetails(cacheKey);
		cacheValue = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(cacheValue)) {
			Map<String, Map<String, Object>> resultMap = JsonUtils.fromJsonOrElse(JsonUtils.toJsonOrEmpty(cacheValue),
					MAP_TYPE_MAP_REFERENCE, new HashMap<>());
			if (MapUtils.isNotEmpty(resultMap) && resultMap.containsKey(gatewayId)) {
				return resultMap.get(gatewayId);
			}
		}
		logger.warn(LogMessageConstants.EMPTY_RECORD_FOUND, cacheKey);
		return new HashMap<>();
	}

	private void updatePgwDetails(String cacheKey) throws QueryException {
		List<Map<String, Object>> resultList = PaymentGatewayDao.getInstance().getPgwDetails();
		if (CollectionUtils.isNotEmpty(resultList)) {
			Map<String, Map<String, Object>> resultMap = resultList.stream()
					.collect(Collectors.toMap(record -> String.valueOf(record.get("gateway_id")), record -> record));

			CacheManager.getInstance().saveAsObject(cacheKey, resultMap);
		} else {
			logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
		}
	}
}
