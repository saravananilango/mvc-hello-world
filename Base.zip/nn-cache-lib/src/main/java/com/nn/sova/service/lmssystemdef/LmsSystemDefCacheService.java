package com.nn.sova.service.lmssystemdef;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.LmsSystemDefCacheDao;
import com.nn.sova.exception.QueryException;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * Perfect Singelton for getting LMS SYSTEM INFO from cache.
 * 
 * @author georgepr
 *
 */
public enum LmsSystemDefCacheService {
	
	INSTANCE;
	
	private static final ApplicationLogger LOGGER = ApplicationLogger.create(LmsSystemDefCacheService.class);
	
	private static final String PREFIX_KEY = "LmsSystemDefCache_";
	
	@SuppressWarnings("unchecked")
	public Map<String,Object> getLmsSystemDef(String systemId) {
		
		try {
			Object valueObj = CacheManager.getInstance().getWithObject(PREFIX_KEY + systemId);
			
			if(Objects.isNull(valueObj)) {
				LOGGER.info(" >>> LMS SYSTEM INFO CACHE OBJ is empty for SYSTEM ID = {} >>> ", systemId);
				LOGGER.info(" >>> Updating LMS SYSTEM INFO in cache! >>> ");
				updateLmsSystemDef(systemId);
				
				valueObj = CacheManager.getInstance().getWithObject(PREFIX_KEY + systemId);
			}
			if(valueObj instanceof Map) {
				return (Map<String,Object>) valueObj;
			}
			
		} catch (QueryException e) {
			LOGGER.info(" >>> Exceptions occurs while performing query operations >>> ");
			LOGGER.info(" >>> SYSTEM ID = {} >>> ", systemId);
			LOGGER.error(e);
		}
		return Collections.emptyMap();
	}
	
	private void updateLmsSystemDef(String systemId) throws QueryException {
		Map<String, Object> resultMap = LmsSystemDefCacheDao.INSTANCE.getLmsSystemDef(systemId);
		CacheManager.getInstance().saveAsObject(PREFIX_KEY + systemId, resultMap);
	}

}
