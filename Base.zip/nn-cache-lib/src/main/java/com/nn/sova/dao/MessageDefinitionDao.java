package com.nn.sova.dao;

import com.nn.sova.constants.MessageDefinitionConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * The type Message definition dao.
 *
 * @author Anand Kumar
 */
public class MessageDefinitionDao {
    /**
     * The constant instance.
     */
    private static MessageDefinitionDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static MessageDefinitionDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new MessageDefinitionDao();
        }
        return instance;
    }

    /**
     * Gets message definition data by message id.
     *
     * @param messageId the message id
     * @return the message definition data by message id
     */
    public List<Map<String, Object>> getMessageDefinitionDataByMessageId(String messageId) throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.REDIS_MESSAGE_DEFINITION_VIEW).where(ConditionBuilder.instance().eq(MessageDefinitionConstants.MESSAGE_ID, messageId)).build(false).execute();
    }

    /**
     * Gets message definition data by message id.
     *
     * @return the message definition data by message id
     */
    public List<Map<String, Object>> getMessageDefinitionDataByMessageId() throws QueryException {
        return new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.REDIS_MESSAGE_DEFINITION_VIEW).build(false).execute();
    }

    /**
     * Gets message definition data by message id.
     *
     * @param messageIdList the message id list
     * @param entity        the entity
     * @return the message definition data by message id
     */
    public List<Map<String, Object>> getMessageDefinitionDataByMessageId(List<Object> messageIdList, EnvironmentDetailsEntity entity) throws QueryException {
        return new QueryBuilder(entity.getUrl(), entity.getUser(), entity.getPassword(), entity.getSchema()).
                btSchema().select().skipTenantId(true).from(TableViewsConstants.REDIS_MESSAGE_DEFINITION_VIEW)
                .where(ConditionBuilder.instance().inWithList(MessageDefinitionConstants.MESSAGE_ID, messageIdList))
                .build(false).execute();
    }

	/**
	 * Gets the application message data.
	 *
	 * @param screenDefId the screen def id
	 * @return the application message data
	 * @throws QueryException the query exception
	 */
	public List<Map<String, Object>> getApplicationMessageData(String screenDefId) throws QueryException {
		return new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.CACHE_APPLICATION_MESSAGE_VIEW).where(ConditionBuilder.instance().eq(MessageDefinitionConstants.SCREEN_DEFINITION_ID, screenDefId)).build(false).execute();
	}
}
