package com.nn.sova.constants;

/**
 * The type Screen def table constants.
 * @author Anand Kumar
 */
public class ScreenDefinitionConstants {
    /**
     * Instantiates a new Screen definition constants.
     */
    ScreenDefinitionConstants(){

    }
    /**
     * The constant SCREEN_ID.
     */
    public static final String SCREEN_DEF_ID = "cfg.screen_definition_id";
    /**
     * The constant SCREEN_ID.
     */
    public static final String SCREEN_ID = "screen_id";
    /**
     * The constant SCREEN_ORDER.
     */
    public static final String SCREEN_ORDER = "cfg.screen_order";
}
