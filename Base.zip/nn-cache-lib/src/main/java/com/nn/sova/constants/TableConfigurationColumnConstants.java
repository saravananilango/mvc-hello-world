package com.nn.sova.constants;

/**
 * The type Table config column constants.
 * @author Anand Kumar
 */
public class TableConfigurationColumnConstants {
    /**
     * Instantiates a new Table configuration column constants.
     */
    TableConfigurationColumnConstants(){

    }
    /**
     * The constant COMPONENT.
     */
    public static final String COMPONENT = "component";
    /**
     * The constant COMPONENT_COLUMN_NAME.
     */
    public static final String COMPONENT_COLUMN_NAME = "component.column_name";
    /**
     * The constant COMPONENT_COMPONENT_ID.
     */
    public static final String COMPONENT_COMPONENT_ID = "component.component_id";
    /**
     * The constant COMPONENT_DATA_ELEMENT.
     */
    public static final String COMPONENT_DATA_ELEMENT = "component.data_element";
    /**
     * The constant COMPONENT_SCREEN_DEF_ID.
     */
    public static final String COMPONENT_SCREEN_DEF_ID = "component.screen_def_id";
    /**
     * The constant COMPONENT_TABLE_NAME.
     */
    public static final String COMPONENT_TABLE_NAME = "component.table_name";
    /**
     * The constant SCREEN_DEFINITION_ID.
     */
    public static final String SCREEN_DEFINITION_ID = "screen_definition_id";
    /**
     * The constant LOCALE.
     */
    public static final String LOCALE = "locale";
    /**
     * The constant SCREEN_ID.
     */
    public static final String SCREEN_ID = "screen_id";
    /**
     * The constant SCREEN_DEF_TYPE.
     */
    public static final String SCREEN_DEF_TYPE = "screen_definition_type";
    /**
     * The constant DOMAIN_CHARSET.
     */
    public static final String DOMAIN_CHARSET = "domain.charset";
    /**
     * The constant ELEMENT_DATA_FORMAT.
     */
    public static final String ELEMENT_DATA_FORMAT = "element.data_format";
    /**
     * The constant ELEMENT_ELEMENT_ID.
     */
    public static final String ELEMENT_ELEMENT_ID = "element.element_id";
    /**
     * The constant HINT_LABEL.
     */
    public static final String HINT_LABEL = "hint_label";
    /**
     * The constant LONG_TEXT.
     */
    public static final String LONG_TEXT = "longText";
    /**
     * The constant MASTER_ID.
     */
    public static final String MASTER_ID = "master.master_id";
    /**
     * The constant MEDIUM_TEXT.
     */
    public static final String MEDIUM_TEXT = "mediumText";
    /**
     * The constant ADDITIONAL_ATTRIBUTE.
     */
    public static final String ADDITIONAL_ATTRIBUTE = "additional_attribute";
    /**
     * The constant BORDER_COLOR.
     */
    public static final String BORDER_COLOR = "border_color";
    /**
     * The constant BORDER_RADIUS.
     */
    public static final String BORDER_RADIUS = "border_radius";
    /**
     * The constant COMPONENT_ID.
     */
    public static final String COMPONENT_ID = "component_id";
    /**
     * The constant DATA_FORMAT.
     */
    public static final String DATA_FORMAT = "data_format";
    /**
     * The constant CHARSET.
     */
    public static final String CHARSET = "charset";
    /**
     * The constant DATA_TYPE.
     */
    public static final String DATA_TYPE = "data_type";
    /**
     * The constant DB_COL_NAME.
     */
    public static final String DB_COL_NAME = "db_col_name";
    /**
     * The constant DB_NAME.
     */
    public static final String DB_NAME = "db_name";
    /**
     * The constant DIGITS.
     */
    public static final String DIGITS = "digits";
    /**
     * The constant DISABLE_CHARACTERS.
     */
    public static final String DISABLE_CHARACTERS = "disable_characters";
    /**
     * The constant ELEMENT_ID.
     */
    public static final String ELEMENT_ID = "data_element";
    /**
     * The constant ELEMENT_TYPE.
     */
    public static final String ELEMENT_TYPE = "element_type";
    /**
     * The constant ENABLE_CHARACTERS.
     */
    public static final String ENABLE_CHARACTERS = "enable_characters";
    /**
     * The constant FONT_SIZE.
     */
    public static final String FONT_SIZE = "font_size";
    /**
     * The constant FONT_STYLE.
     */
    public static final String FONT_STYLE = "font_style";
    /**
     * The constant FULL_HIRAGANA.
     */
    public static final String FULL_HIRAGANA = "full_hiragana";
    /**
     * The constant FULL_KATAKANA.
     */
    public static final String FULL_KATAKANA = "full_katakana";
    /**
     * The constant HALF_KATAKANA.
     */
    public static final String HALF_KATAKANA = "half_katakana";
    /**
     * The constant INPUT_PADDING.
     */
    public static final String INPUT_PADDING = "input_padding";
    /**
     * The constant IS_DISABLED.
     */
    public static final String IS_DISABLED = "is_disabled";
    /**
     * The constant IS_DISPLAYED.
     */
    public static final String IS_DISPLAYED = "is_displayed";
    /**
     * The constant IS_DISUSE.
     */
    public static final String IS_DISUSE = "is_disuse";
    /**
     * The constant IS_READ_ONLY.
     */
    public static final String IS_READ_ONLY = "is_read_only";
    /**
     * The constant IS_UNDERLINED.
     */
    public static final String IS_UNDERLINED = "is_underlined";
    /**
     * The constant LABEL_ALIGN.
     */
    public static final String LABEL_ALIGN = "label_align";
    /**
     * The constant LABEL_COLOR.
     */
    public static final String LABEL_COLOR = "label_color";
    /**
     * The constant LABEL_WIDTH.
     */
    public static final String LABEL_WIDTH = "label_width";
    /**
     * The constant LANG_CD.
     */
    public static final String LANG_CD = "lang_cd";
    /**
     * The constant LINE_SEPERATOR.
     */
    public static final String LINE_SEPERATOR = "line_seperator";
    /**
     * The constant LOWER_CASE_LATIN.
     */
    public static final String LOWER_CASE_LATIN = "lower_case_latin";
    /**
     * The constant MANDATORY.
     */
    public static final String MANDATORY = "mandatory";
    /**
     * The constant MASTER_SEARCH_IDS.
     */
    public static final String MASTER_SEARCH_IDS = "master_search_id";
    /**
     * The constant MAX_DATE.
     */
    public static final String MAX_DATE = "max_date";
    /**
     * The constant MAX_DECIMAL.
     */
    public static final String MAX_DECIMAL = "max_decimal";
    /**
     * The constant MAX_LENGTH.
     */
    public static final String MAX_LENGTH = "max_length";
    /**
     * The constant MAX_MATCHES.
     */
    public static final String MAX_MATCHES = "max_matches";
    /**
     * The constant MAX_VAL.
     */
    public static final String MAX_VAL = "max_val";
    /**
     * The constant MIN_DATE.
     */
    public static final String MIN_DATE = "min_date";
    /**
     * The constant MIN_LENGTH.
     */
    public static final String MIN_LENGTH = "min_length";
    /**
     * The constant MIN_VAL.
     */
    public static final String MIN_VAL = "min_val";
    /**
     * The constant NOT_NULL.
     */
    public static final String NOT_NULL = "not_null";
    /**
     * The constant REGEX_PATTERN.
     */
    public static final String REGEX_PATTERN = "regex_pattern";
    /**
     * The constant SET_COLUMN_NAME.
     */
    public static final String SET_COLUMN_NAME = "set_column_name";
    /**
     * The constant SHORTCUT.
     */
    public static final String SHORTCUT = "shortcut";
    /**
     * The constant SHOW_COLUMN_NAME.
     */
    public static final String SHOW_COLUMN_NAME = "show_column_names";
    /**
     * The constant SPACE.
     */
    public static final String SPACE = "space";
    /**
     * The constant SYMBOL.
     */
    public static final String SYMBOL = "symbol";
    /**
     * The constant TAB.
     */
    public static final String TAB = "tab";
    /**
     * The constant TABLE_NAME.
     */
    public static final String TABLE_NAME = "table_name";
    /**
     * The constant TEXT_COLOR.
     */
    public static final String TEXT_COLOR = "text_color";
    /**
     * The constant TEXT_TYPE.
     */
    public static final String TEXT_TYPE = "text_type";
    /**
     * The constant TEXT_TYPE_LONG.
     */
    public static final String TEXT_TYPE_LONG = "long";
    /**
     * The constant TEXT_TYPE_MEDIUM.
     */
    public static final String TEXT_TYPE_MEDIUM = "medium";
    /**
     * The constant TEXT_TYPE_SHORT.
     */
    public static final String TEXT_TYPE_SHORT = "short";
    /**
     * The constant UPPER_CASE_LATIN.
     */
    public static final String UPPER_CASE_LATIN = "upper_case_latin";
    /**
     * The constant PLACE_LABEL.
     */
    public static final String PLACE_LABEL = "place_label";
    /**
     * The constant SCREEN_CONFIG_ALIAS_NAME.
     */
    public static final String SCREEN_CONFIG_ALIAS_NAME = "screen_config";
    /**
     * The constant SCREEN_CONFIG_COMPONENT_ID.
     */
    public static final String SCREEN_CONFIG_COMPONENT_ID = "screen_config.component_id";
    /**
     * The constant SCREEN_CONFIG_INITIAL_FOCUS.
     */
    public static final String SCREEN_CONFIG_INITIAL_FOCUS = "screen_config.initial_focus";
    /**
     * The constant SCREEN_CONFIG_IS_DISPLAYED.
     */
    public static final String SCREEN_CONFIG_IS_DISPLAYED = "screen_config.is_displayed";
    /**
     * The constant SCREEN_CONFIG_IS_DISUSE.
     */
    public static final String SCREEN_CONFIG_IS_DISUSE = "screen_config.is_disuse";
    /**
     * The constant SCREEN_CONFIG_IS_MANDATORY.
     */
    public static final String SCREEN_CONFIG_IS_MANDATORY = "screen_config.mandatory";
    /**
     * The constant SCREEN_CONFIG_IS_READONLY.
     */
    public static final String SCREEN_CONFIG_IS_READONLY = "screen_config.is_read_only";
    /**
     * The constant SCREEN_CONFIG_SCREEN_ID.
     */
    public static final String SCREEN_CONFIG_SCREEN_ID = "screen_config.screen_id";
    /**
     * The constant SHORT_TEXT.
     */
    public static final String SHORT_TEXT = "shortText";
    /**
     * The constant SUBQUERY_ALIAS_NAME.
     */
    public static final String SUBQUERY_ALIAS_NAME = "subquery";
    /**
     * The constant TABLE_CONFIG_COLUMN_NAME.
     */
    public static final String TABLE_CONFIG_COLUMN_NAME = "table_config.column_name";
    /**
     * The constant TABLE_CONFIG_DATA_ELEMENT.
     */
    public static final String TABLE_CONFIG_DATA_ELEMENT = "table_config.data_element";
    /**
     * The constant TABLE_CONFIG_TABLE_NAME.
     */
    public static final String TABLE_CONFIG_TABLE_NAME = "table_config.table_name";
    /**
     * The constant COMPONENT_DEF_TABLE_NAME.
     */
    public static final String COMPONENT_DEF_TABLE_NAME = "component_def.table_name";
}
