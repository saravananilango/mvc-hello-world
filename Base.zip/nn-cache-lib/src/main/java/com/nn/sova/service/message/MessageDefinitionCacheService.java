package com.nn.sova.service.message;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.MessageDefinitionDao;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.common.CommonCacheService;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Message definition cache service.
 *
 * @author Anand Kumar
 */
public class MessageDefinitionCacheService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(MessageDefinitionCacheService.class);
    /**
     * The constant instance.
     */
    private static MessageDefinitionCacheService instance = null;

    /**
     * Instantiates a new Message definition cache service.
     */
    private MessageDefinitionCacheService() {
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static MessageDefinitionCacheService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new MessageDefinitionCacheService();
        }
        return instance;
    }

    /**
     * Gets message definition data.
     *
     * @param cacheKey  the cache key
     * @param messageId the message id
     * @param locale    the locale
     * @return the message definition data
     */
    @SuppressWarnings("unchecked")
	public MessageDefinitionEntity getMessageDefinitionData(String cacheKey, String messageId, String locale) throws QueryException {
        Map<String, Object> messageIdList = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(messageIdList)) {
            return TypeConversionHelper.remapObjToMessageEntity(messageIdList, locale);
        }
        updateMessageDefinitionData(messageId);
        messageIdList = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(messageIdList)) {
            return TypeConversionHelper.remapObjToMessageEntity(messageIdList, locale);
        }
        return null;
    }

    /**
     * Update message definition data.
     *
     * @param messageId the message id
     */
    private void updateMessageDefinitionData(String messageId) throws QueryException {
        List<Map<String, Object>> messageEntityList = MessageDefinitionDao.getInstance().getMessageDefinitionDataByMessageId(messageId);
        if(CollectionUtils.isNotEmpty(messageEntityList)) {
            Map<String, Map<String, List<MessageDefinitionEntity>>> messageEntityMap = TypeConversionHelper.reMapMessageDefinitioData(messageEntityList);
            for (Map.Entry<String, Map<String, List<MessageDefinitionEntity>>> messageMap : messageEntityMap.entrySet()) {
                String cacheKey = CacheKeyHelper.getMessageDefinitionPrefixKey().concat(messageMap.getKey());
                CacheManager.getInstance().saveAsObject(cacheKey, messageMap.getValue());
            }
        } 
    }

    /**
     * Update message definition data.
     *
     * @param messageIdList the message id list
     * @param entity        the entity
     */
    public void updateMessageDefinitionData(List<Object> messageIdList, EnvironmentDetailsEntity entity) throws QueryException {
        RedisEnvInfo redisNode = TypeConversionHelper.getRedisNode(entity);
        List<Map<String, Object>> messageEntityList = MessageDefinitionDao.getInstance().getMessageDefinitionDataByMessageId(messageIdList, entity);
        if(CollectionUtils.isNotEmpty(messageEntityList)) {
            Map<String, Map<String, List<MessageDefinitionEntity>>> messageEntityMap = TypeConversionHelper.reMapMessageDefinitioData(messageEntityList);
            for (Map.Entry<String, Map<String, List<MessageDefinitionEntity>>> messageMap : messageEntityMap.entrySet()) {
                String cacheKey = CacheKeyHelper.getMessageDefinitionPrefixKey().concat(messageMap.getKey());
                CacheManager.getInstance().saveAsObjectWithEnvInfo(cacheKey, messageMap, redisNode);
            }
        }else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update message definition data.
     */
    public void updateMessageDefinitionData() throws QueryException {
        List<Map<String, Object>> messageEntityList = MessageDefinitionDao.getInstance().getMessageDefinitionDataByMessageId();
        if(CollectionUtils.isNotEmpty(messageEntityList)) {
            Map<String, Map<String, List<MessageDefinitionEntity>>> messageEntityMap = TypeConversionHelper.reMapMessageDefinitioData(messageEntityList);
            for (Map.Entry<String, Map<String, List<MessageDefinitionEntity>>> messageMap : messageEntityMap.entrySet()) {
                String cacheKey = CacheKeyHelper.getMessageDefinitionPrefixKey().concat(messageMap.getKey());
                CacheManager.getInstance().saveAsObject(cacheKey, messageMap);
            }
        }else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Remove message def.
     */
    public void removeMessageDefinition() {
        String prefixKey = CacheKeyHelper.getMessageDefinitionPrefixKey();
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey);
        CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }

    /**
     * Remove message def.
     *
     * @param keyList the key list
     */
    public void removeMessageDefinition(List<String> keyList) {
        String prefixKey = CacheKeyHelper.getMessageDefinitionPrefixKey();
        keyList.replaceAll(prefixKey::concat);
        CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }

    /**
     * Remove message def.
     *
     * @param keyList the key list
     * @param envInfo the env info
     */
    public void removeMessageDefinition(List<String> keyList, EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisEnvInfo = TypeConversionHelper.getRedisNode(envInfo);
        String prefixKey = CacheKeyHelper.getMessageDefinitionPrefixKey();
        keyList.replaceAll(prefixKey::concat);
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(keyList.toArray(new String[keyList.size()]), redisEnvInfo);
    }
    
    /**
     * Gets the application message data.
     *
     * @param screenDefId the screen def id
     * @param cacheKey the cache key
     * @return the application message data
     * @throws QueryException the query exception
     */
    @SuppressWarnings("unchecked")
	public Map<String, MessageDefinitionEntity> getApplicationMessageData(String screenDefId, String cacheKey) throws QueryException {
		Map<String, MessageDefinitionEntity> dataMap = (Map<String, MessageDefinitionEntity>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(Objects.nonNull(dataMap)) {
    		return dataMap;
    	}
    	updateApplicationMessageData(screenDefId);
    	dataMap = (Map<String, MessageDefinitionEntity>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(Objects.nonNull(dataMap)) {
    		return dataMap;
    	}
    	return Collections.emptyMap();
	}
    
    
    /**
     * Update text definition data.
     * @param productCode 
     *
     * @param locale  the locale
     * @param purpose the purpose
     */
    public void updateApplicationMessageData(String screenDefId) throws QueryException {
    	List<Map<String, Object>> messageEntityList = MessageDefinitionDao.getInstance().getApplicationMessageData(screenDefId);
        if(CollectionUtils.isNotEmpty(messageEntityList)) {
            Map<String, Map<String, MessageDefinitionEntity>> messageEntityMap = TypeConversionHelper.reMapApplicationMessageData(messageEntityList);
            for (Map.Entry<String, Map<String, MessageDefinitionEntity>> messageMap : messageEntityMap.entrySet()) {
            	String langCode = messageMap.getKey();
    			String cacheKey = CacheKeyHelper.getApplicationMessageKey(screenDefId, langCode);
    			CacheManager.getInstance().saveAsObject(cacheKey, messageMap.getValue());
            }
        } else{
        	String cacheKey =  CacheKeyHelper.getApplicationMessageKey(screenDefId, ContextBean.getLocale());
			CacheManager.getInstance().saveAsObject(cacheKey, new HashMap<>());
        }
    }

	/**
	 * Removes the application message data.
	 *
	 * @param screenDefId the screen def id
	 */
	public void removeApplicationMessageData(String screenDefId) {
		String prefixKey = CacheKeyHelper.getApplicationMessagePrefixKey();
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey);
        CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
	}
}
