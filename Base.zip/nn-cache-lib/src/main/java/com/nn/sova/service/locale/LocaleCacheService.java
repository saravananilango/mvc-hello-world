package com.nn.sova.service.locale;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.LocaleDao;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Locale cache service.
 *
 * @author Anand Kumar
 */
public class LocaleCacheService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(LocaleCacheService.class);
    /**
     * The constant instance.
     */
    private static LocaleCacheService instance = null;

    /**
     * Instantiates a new Locale cache service.
     */
    private LocaleCacheService() {
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static LocaleCacheService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new LocaleCacheService();
        }
        return instance;
    }

    /**
     * Gets locale info by lang cd.
     *
     * @param cacheKey the cache key
     * @param locale   the locale
     * @return the locale info by lang cd
     */
    @SuppressWarnings("unchecked")
	public List<Object> getLocaleInfoByLangCd(String cacheKey, String locale) throws QueryException {
        List<Object> resultList = (List<Object>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(resultList)) {
            return resultList;
        }
        return updateLocaleInfoByLangCd(cacheKey, locale);
    }

    /**
     * Gets all locale.
     *
     * @param cacheKey the cache key
     * @return the all locale
     */
    @SuppressWarnings("unchecked")
	public List<Object> getAllLocale(String cacheKey) throws QueryException {
        Map<String, List<Object>> resultList = (Map<String, List<Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(resultList)) {
            return resultList.get("langData");
        }
        return updateLocaleInfo(cacheKey);
    }

    /**
     * Gets locale business object.
     *
     * @param cacheKey the cache key
     * @return the locale business object
     */
    public Object getLocaleBusinessObject(String cacheKey) throws QueryException {
        Object value = CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(value)) {
            return value;
        }
        return updateLocaleBusinessObject(cacheKey);
    }

    /**
     * Update locale business object.
     *
     * @param cacheKey the cache key
     * @return 
     */
    private Object updateLocaleBusinessObject(String cacheKey) throws QueryException {
        Object resultValue = LocaleDao.getInstance().getLocaleBusinessObject();
        if(Objects.nonNull(resultValue)) {
            CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
            return resultValue;
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, StringUtils.EMPTY);
        	return StringUtils.EMPTY;
        }
    }

    /**
     * Update locale info.
     *
     * @param cacheKey the cache key
     * @return 
     */
    public List<Object> updateLocaleInfo(String cacheKey) throws QueryException {
        Map<String, List<Object>> dataMap = LocaleDao.getInstance().getAllLocaleInfo();
        if(MapUtils.isNotEmpty(dataMap)) {
            CacheManager.getInstance().saveAsObject(cacheKey, dataMap);
            return dataMap.get("langData");
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
        	return Collections.emptyList();
        }
    }

    /**
     * Update locale info by lang cd.
     *
     * @param cacheKey the cache key
     * @param locale   the locale
     * @return 
     */
    private List<Object> updateLocaleInfoByLangCd(String cacheKey, String locale) throws QueryException {
        List<Object> dataList = LocaleDao.getInstance().getLocaleInfoByLangCd(locale);
        if(!dataList.isEmpty()) {
            CacheManager.getInstance().saveAsObject(cacheKey, dataList);
            return dataList;
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
        	return Collections.emptyList();
        }
    }

    /**
     * Remove locale.
     */
    public void removeLocale() {
        CacheManager.getInstance().deleteKey(CacheKeyHelper.getActiveLangCodeKeyPrefix());
        CacheManager.getInstance().deleteKey(CacheKeyHelper.getLocaleKey());
    }
}
