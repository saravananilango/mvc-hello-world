package com.nn.sova.service.text;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.TextDefinitionDao;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.common.CommonCacheService;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Text definition cache service.
 *
 * @author Anand Kumar
 */
public class TextDefinitionCacheService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(TextDefinitionCacheService.class);
    /**
     * The constant instance.
     */
    private static TextDefinitionCacheService instance = null;

    /**
     * Instantiates a new Table config cache service.
     */
    private TextDefinitionCacheService() {
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static TextDefinitionCacheService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new TextDefinitionCacheService();
        }
        return instance;
    }

    /**
     * Gets all text definition data.
     *
     * @param cacheKey the cache key
     * @param locale   the locale
     * @param purpose  the purpose
     * @return the all text definition data
     */
    @SuppressWarnings("unchecked")
	public Object getFrameworkTextDefinitionData(String cacheKey) throws QueryException {
    	Map<String, Object> dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(Objects.nonNull(dataMap)) {
    		return dataMap;
    	}
    	updateFrameworkTextDefinitionData();
    	dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(Objects.nonNull(dataMap)) {
    		return dataMap;
    	}
    	return Collections.emptyMap();
    }
    /**
     * Gets all text definition data.
     *
     * @param cacheKey the cache key
     * @param locale   the locale
     * @param purpose  the purpose
     * @return the all text definition data
     */
    @SuppressWarnings("unchecked")
	public Map<String, Object> getApplicationTextDefinitionData(String screenDefId,String cacheKey) throws QueryException {
    	Map<String, Object> dataMap =  (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(Objects.nonNull(dataMap)) {
    		return dataMap;
    	}
    	updateApplicationTextDefinitionData(screenDefId);
    	dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(Objects.nonNull(dataMap)) {
    		return dataMap;
    	}
    	return Collections.emptyMap();
    }

    /**
     * Gets text definition data.
     *
     * @param cacheKey the cache key
     * @param textId   the text id
     * @param locale   the locale
     * @param purpose  the purpose
     * @return the text definition data
     */
    @SuppressWarnings("unchecked")
	public String getFrameworTextDefinitionData(String cacheKey, String textId) throws QueryException {
        Map<String, Object> dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
        if(MapUtils.isNotEmpty(dataMap))
            return TypeConversionHelper.getTextDataFromMap(dataMap, textId);
        updateFrameworkTextDefinitionData();
        dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
        if(MapUtils.isNotEmpty(dataMap))
            return TypeConversionHelper.getTextDataFromMap(dataMap, textId);
        return StringUtils.EMPTY;
    }
    /**
     * Gets text definition data.
     *
     * @param cacheKey the cache key
     * @param textId   the text id
     * @param locale   the locale
     * @param purpose  the purpose
     * @return the text definition data
     */
    @SuppressWarnings("unchecked")
	public String getApplicationTextDefinitionData(String screenDefId,String cacheKey, String textId) throws QueryException {
    	Map<String, Object> dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(MapUtils.isNotEmpty(dataMap))
    		return TypeConversionHelper.getTextDataFromMap(dataMap, textId);
    	updateApplicationTextDefinitionData(screenDefId);
    	dataMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
    	if(MapUtils.isNotEmpty(dataMap))
    		return TypeConversionHelper.getTextDataFromMap(dataMap, textId);
    	return StringUtils.EMPTY;
    }

    /**
     * Update text definition data.
     * @param productCode 
     *
     * @param locale  the locale
     * @param purpose the purpose
     */
    public void updateApplicationTextDefinitionData(String screenDefId) throws QueryException {
        List<Map<String, Object>> textDefList = TextDefinitionDao.getApplicationTextDefinitionData(screenDefId);
        if(CollectionUtils.isNotEmpty(textDefList)) {
            Map<String, Map<String, Object>> textData = TypeConversionHelper.reMapTextDefinitionData(textDefList);
            for (Entry<String, Map<String, Object>> textMap : textData.entrySet()) {
    			String langCode = textMap.getKey();
    			String cacheKey;
    			cacheKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId).concat(CacheKeyHelper.DELIMITER).concat(langCode);
    			CacheManager.getInstance().saveAsObject(cacheKey, textMap.getValue());
    		}
        }else{
        	String cacheKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId).concat(CacheKeyHelper.DELIMITER).concat(ContextBean.getLocale());
			CacheManager.getInstance().saveAsObject(cacheKey, new HashMap<>());
        }
    }
    /**
     * Update text definition data.
     *
     * @param locale  the locale
     * @param purpose the purpose
     */
    public void updateFrameworkTextDefinitionData() throws QueryException {
    	List<Map<String, Object>> textDefList = TextDefinitionDao.getFrameworkTextDefinitionData();
    	if(CollectionUtils.isNotEmpty(textDefList)) {
    		Map<String, Map<String, Object>> textData = TypeConversionHelper.reMapTextDefinitionData(textDefList);
    		for (Entry<String, Map<String, Object>> textMap : textData.entrySet()) {
    			String langCode = textMap.getKey();
    			String cacheKey = CacheKeyHelper.getTextDefinitionFrameworkPrefixKey().concat(langCode);
    			CacheManager.getInstance().saveAsObject(cacheKey, textMap.getValue());
    			CacheManager.getInstance().saveAsObject("sova_lang_fw_text_data_key", UUID.randomUUID());
    		}
    	}
    }

    /**
     * Update text definition data.
     *
     * @param envInfo the env info
     * @param locale  the locale
     * @param purpose the purpose
     */
    public void updateApplicationTextDefinitionData(String screenDefId,EnvironmentDetailsEntity envInfo) throws QueryException {
        RedisEnvInfo redisNode = TypeConversionHelper.getRedisNode(envInfo);
        List<Map<String, Object>> textDefList = TextDefinitionDao.getApplicationTextDefinitionData(screenDefId);
        if(CollectionUtils.isNotEmpty(textDefList)) {
            Map<String, Map<String, Object>> textDatas = TypeConversionHelper.reMapTextDefinitionData(textDefList);
            for (Entry<String, Map<String, Object>> textMap : textDatas.entrySet()) {
    			String langCode = textMap.getKey();
    			String cacheKey;
    			cacheKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId).concat(CacheKeyHelper.DELIMITER).concat(langCode);
                CacheManager.getInstance().saveAsObjectWithEnvInfo(cacheKey, textMap, redisNode);
            }
        } else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Remove application text def.
     */
    public void removeApplicationTextDef() {
        String prefixKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey();
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey);
        CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }

    /**
     * Remove application text def.
     *
     * @param productCode the product code
     */
    public void removeApplicationTextDef(String screenDefId) {
        String prefixKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId);
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey);
        CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }

    /**
     * Remove application text def.
     *
     * @param productCodeList the product code list
     */
    public void removeApplicationTextDef(List<String> screenDefIdList) {
        if(CollectionUtils.isNotEmpty(screenDefIdList)) {
            Set<String> keyList = new HashSet<>();
            String prefixKey = "";
            for (String screenDefId : screenDefIdList) {
                prefixKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId);
                keyList.addAll(CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey));
            }
            CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
        }
    }

    /**
     * Remove application text def.
     *
     * @param envInfo the env info
     */
    public void removeApplicationTextDef(EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        String prefixKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey();
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey, redisInfo);
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(keyList.toArray(new String[keyList.size()]), redisInfo);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo     the env info
     * @param productCode the product code
     */
    public void removeApplicationTextDef(EnvironmentDetailsEntity envInfo, String screenDefId) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        String prefixKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId);
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey, redisInfo);
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(keyList.toArray(new String[keyList.size()]), redisInfo);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo         the env info
     * @param productCodeList the product code list
     */
    public void removeApplicationTextDef(EnvironmentDetailsEntity envInfo, List<String> screenDefIdList) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        if(CollectionUtils.isNotEmpty(screenDefIdList)) {
            Set<String> keyList = new HashSet<>();
            String prefixKey = "";
            for (String screenDefId : screenDefIdList) {
                prefixKey = CacheKeyHelper.getTextDefinitionApplicationPrefixKey().concat(screenDefId);
                keyList.addAll(CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey, redisInfo));
            }
            CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(keyList.toArray(new String[keyList.size()]), redisInfo);
        }
    }

    /**
     * Remove framework text def.
     */
    public void removeFrameworkTextDef() {
        String prefixKey = CacheKeyHelper.getTextDefinitionFrameworkPrefixKey();
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey);
        CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }

    /**
     * Remove framework text def.
     *
     * @param envInfo the env info
     */
    public void removeFrameworkTextDef(EnvironmentDetailsEntity envInfo) {
        RedisEnvInfo redisInfo = TypeConversionHelper.getRedisNode(envInfo);
        String prefixKey = CacheKeyHelper.getTextDefinitionFrameworkPrefixKey();
        Set<String> keyList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(prefixKey, redisInfo);
        CacheManager.getInstance().deleteMultipleKeyWithEnvInfo(keyList.toArray(new String[keyList.size()]), redisInfo);
    }
}
