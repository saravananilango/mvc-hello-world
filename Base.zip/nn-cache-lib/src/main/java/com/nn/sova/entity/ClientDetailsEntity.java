package com.nn.sova.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * Instantiates a new client details entity.
 */

/**
 * Instantiates a new client details entity.
 */
@Data
public class ClientDetailsEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
	/** The nn tenant id. */
	private String tenantId;

	/** The nn client id. */
	private String clientId;
	
	/** The nn user id. */
	private String userId;
	
	/** The nn api role name. */
	private String apiRoleName;
	
	/** The nn product code. */
	private String productCode;
	
	/** The nn sub product name. */
	private String subProductName;
	
	/** The nn api entity name. */
	private String apiEntityName;
	
	/** The nn method url. */
	private String methodUrl;
	
	/** The nn get method access. */
	private boolean getMethodAccess;
	
	/** The nn post method access. */
	private boolean postMethodAccess;
	
	/** The nn put method access. */
	private boolean	putMethodAccess;
	
	/** The nn delete method access. */
	private boolean deleteMethodAccess;
	
	/** The nn batch method access. */
	private boolean patchMethodAccess;
	
	/** The nn max limit per sec. */
	private int maxLimitPerSec;
	
	/** The nn max limit per min. */
	private int maxLimitPerMin;
	
	/** The nn max limit per hour. */
	private int maxLimitPerHour;
	
	/** The nn max limit per day. */
	private int maxLimitPerDay;
}
