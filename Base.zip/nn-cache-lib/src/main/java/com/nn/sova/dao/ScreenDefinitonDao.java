package com.nn.sova.dao;

import com.nn.sova.constants.ScreenDefinitionConstants;
import com.nn.sova.constants.TableNamesConstants;
import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.ScreenDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utiil.TypeConversionHelper;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * The type Screen definiton dao.
 *
 * @author Anand Kumar
 */
public class ScreenDefinitonDao {
    /**
     * The constant instance.
     */
    private static ScreenDefinitonDao instance = null;

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static ScreenDefinitonDao getInstance() {
        if(Objects.isNull(instance)) {
            instance = new ScreenDefinitonDao();
        }
        return instance;
    }

    /**
     * Gets screens by def id.
     *
     * @param screenDefId the screen def id
     * @return the screens by def id
     */
    public static List<Map<String, Object>> getScreensByDefId(String screenDefId) throws QueryException {
        SelectQueryBuilder selectBuilder = new QueryBuilder().btSchema().select();
        return selectBuilder.get(ScreenDefinitionConstants.SCREEN_ID).skipTenantId(true).from(TableNamesConstants.SCREEN_DEFINITION, "def")
                .leftJoin(TableNamesConstants.SCREEN_CONFIGURATION, "cfg",
                        ConditionBuilder.instance().eq(ScreenDefinitionConstants.SCREEN_DEF_ID, ScreenDefinitionConstants.SCREEN_DEF_ID, true))
                .where(ConditionBuilder.instance().eq(ScreenDefinitionConstants.SCREEN_DEF_ID, screenDefId))
                .orderBy(ScreenDefinitionConstants.SCREEN_ORDER, SortType.ASC).build(false).execute();
    }

    /**
     * Gets screen definition data by screen.
     *
     * @return the screen definition data by screen
     */
    public static Map<String, Map<String, List<ScreenDefinitionEntity>>> getScreenDefinitionDataByScreen() throws QueryException {
        SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.CACHE_SCREEN_DETAILS_VIEW);
        List<Map<String, Object>> screenDefList = selectQueryBuilder.build(false).execute();
        List<ScreenDefinitionEntity> screenDefinitionDataByScreenList = makeScreenDefinitionEntity(screenDefList);
        return TypeConversionHelper.screenEntityToMap(screenDefinitionDataByScreenList);
    }

    /**
     * Gets screen definition data by screen map.
     *
     * @param screenIdList the screen id list
     * @return the screen definition data by screen map
     */
    public static Map<String, Map<String, List<ScreenDefinitionEntity>>> getScreenDefinitionDataByScreen(List<Object> screenIdList) throws QueryException {
        SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select().skipTenantId(true).from(TableViewsConstants.CACHE_SCREEN_DETAILS_VIEW);
        List<Map<String, Object>> screenDefList = selectQueryBuilder.where(ConditionBuilder.instance().inWithList(ScreenDefinitionConstants.SCREEN_ID, screenIdList))
                .build(false).execute();
        List<ScreenDefinitionEntity> screenDefinitionDataByScreenList = makeScreenDefinitionEntity(screenDefList);
        return TypeConversionHelper.screenEntityToMap(screenDefinitionDataByScreenList);
    }

    /**
     * Gets screen id list.
     *
     * @param screenDefIdList the screen def id list
     * @param envInfo         the env info
     * @return the screen id list
     */
    public static Map<String, Map<String, List<ScreenDefinitionEntity>>> getScreenDefinitionDataByScreenList(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
        SelectQueryBuilder selectQueryBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema())
                .btSchema().select().skipTenantId(true).from(TableViewsConstants.CACHE_SCREEN_DETAILS_VIEW);
        List<Map<String, Object>> screenDefList = selectQueryBuilder.where(ConditionBuilder.instance().inWithList(ScreenDefinitionConstants.SCREEN_ID, screenIdList))
                .build(false).execute();
        List<ScreenDefinitionEntity> screenDefinitionDataByScreenList = makeScreenDefinitionEntity(screenDefList);
        return TypeConversionHelper.screenEntityToMap(screenDefinitionDataByScreenList);
    }

    /**
     * Make screen definition entity list.
     *
     * @param screenDefList the screen def list
     * @return the list
     */
    private static List<ScreenDefinitionEntity> makeScreenDefinitionEntity(List<Map<String, Object>> screenDefList) {
        return screenDefList.stream().map(value -> {
            ScreenDefinitionEntity screenDefEntity = new ScreenDefinitionEntity();
            screenDefEntity.setScreenDefinitionId(TypeConversionHelper.objectToString(value.get("screen_definition_id")));
            screenDefEntity.setScreenId(TypeConversionHelper.objectToString(value.get("screen_id")));
            screenDefEntity.setScreenName(TypeConversionHelper.objectToString(value.get("text_content")));
            screenDefEntity.setApplicationCode(TypeConversionHelper.objectToString(value.get("product_code")));
            screenDefEntity.setVuePath(TypeConversionHelper.objectToString(value.get("vue_path")));
            screenDefEntity.setScreenURL(TypeConversionHelper.objectToString(value.get("screen_url")));
            screenDefEntity.setLangCd(TypeConversionHelper.objectToString(value.get("lang_code")));
            return screenDefEntity;
        }).collect(Collectors.toList());
    }

    /**
     * Gets screens by def id list.
     *
     * @param screenDefIdList the screen def id list
     * @return the screens by def id list
     * @throws QueryException the query exception
     */
    public List<Map<String, Object>> getScreensByDefIdList(List<Object> screenDefIdList) throws QueryException {
        SelectQueryBuilder selectBuilder = new QueryBuilder().btSchema().select();
        return selectBuilder.get(ScreenDefinitionConstants.SCREEN_ID).skipTenantId(true).from(TableNamesConstants.SCREEN_DEFINITION, "def")
                .leftJoin(TableNamesConstants.SCREEN_CONFIGURATION, "cfg",
                        ConditionBuilder.instance().eq(ScreenDefinitionConstants.SCREEN_DEF_ID, ScreenDefinitionConstants.SCREEN_DEF_ID, true))
                .where(ConditionBuilder.instance().inWithList(ScreenDefinitionConstants.SCREEN_DEF_ID, screenDefIdList))
                .orderBy(ScreenDefinitionConstants.SCREEN_ORDER, SortType.ASC).build(false).execute();
    }
    
    /**
     * Gets screens by def id list.
     *
     * @param screenDefIdList the screen def id list
     * @param envInfo          the env info
     * @return the screens by def id list
     * @throws QueryException the query exception
     */
    public List<Map<String, Object>> getScreensByDefIdList(List<Object> screenDefIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
        SelectQueryBuilder selectBuilder = new QueryBuilder(envInfo.getUrl(), envInfo.getUser(), envInfo.getPassword(), envInfo.getSchema()).btSchema().select();
        return selectBuilder.get(ScreenDefinitionConstants.SCREEN_ID).skipTenantId(true).from(TableNamesConstants.SCREEN_DEFINITION, "def")
                .leftJoin(TableNamesConstants.SCREEN_CONFIGURATION, "cfg",
                        ConditionBuilder.instance().eq(ScreenDefinitionConstants.SCREEN_DEF_ID, ScreenDefinitionConstants.SCREEN_DEF_ID, true))
                .where(ConditionBuilder.instance().inWithList(ScreenDefinitionConstants.SCREEN_DEF_ID, screenDefIdList))
                .orderBy(ScreenDefinitionConstants.SCREEN_ORDER, SortType.ASC).build(false).execute();
    }
    
    /**
     * Gets the service access def id.
     *
     * @return the service access def id
     * @throws QueryException the query exception
     */
    public List<Map<String,Object>> getServiceAccessDefId() throws QueryException{
    	SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select().checkIndependentTenant(true);
    	return selectQueryBuilder.from("service_restriction_view").build(false).execute();
    }
}
