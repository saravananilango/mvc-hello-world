package com.nn.sova.constants;

/**
 * The type Log message constants.
 * @author Anand Kumar
 */
public class LogMessageConstants {
    /**
     * Instantiates a new Log message constants.
     */
    LogMessageConstants(){

    }
    /**
     * The constant EMPTY_RECORD_FOUND.
     */
    public static final String EMPTY_RECORD_FOUND = "Empty Record Found !! Data Not inserted to cache ... [ %s ]";
    /**
     * The constant EMPTY_RECORD_FOUND_FOR_LOCALE.
     */
    public static final String EMPTY_RECORD_FOUND_FOR_LOCALE = "Empty Record Found for the locale [ %s ] !!";
    /**
     * The constant EMPTY_RECORD_FOUND.
     */
    public static final String DB_EMPTY_RECORD_FOUND = "Empty Record Found for the query !!";

    /**
     * The constant REDIS_EXCEPTION_MESSAGE.
     */
    public static final String REDIS_EXCEPTION_MESSAGE = "Failed to convert into bytes : ";

    /**
     * The constant REDIS_SERVER_EXCEPTION.
     */
    public static final String REDIS_SERVER_EXCEPTION = "Failed to connect to Redis server: ";
    /**
     * The constant NO_DATA_ELEMENTS_FOUND.
     */
    public static final String NO_DATA_ELEMENTS_FOUND = "No data elements found";

}
