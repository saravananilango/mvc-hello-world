package com.nn.sova.entity;

import lombok.Data;

/**
 * The type Environment details entity.
 * @author Anand Kumar
 */
@Data
public class EnvironmentDetailsEntity {
    /**
     * The Redis ip.
     */
    private String redisIp;
    /**
     * The Redis port.
     */
    private String redisPort;
    /**
     * The Url.
     */
    private String url;
    /**
     * The User.
     */
    private String user;
    /**
     * The Password.
     */
    private String password;
    /**
     * The Schema.
     */
    private String schema;
}
