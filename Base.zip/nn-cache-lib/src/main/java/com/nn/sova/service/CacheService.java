package com.nn.sova.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.core.CacheManager;
import com.nn.sova.entity.EnvironmentDetailsEntity;
import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.entity.ScreenDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.application.ApplicationConfigurationCacheService;
import com.nn.sova.service.common.CommonCacheService;
import com.nn.sova.service.lmssystemdef.LmsSystemDefCacheService;
import com.nn.sova.service.locale.LocaleCacheService;
import com.nn.sova.service.message.MessageDefinitionCacheService;
import com.nn.sova.service.paymentgateway.PaymentGatewayCacheService;
import com.nn.sova.service.role.RoleConfigurationService;
import com.nn.sova.service.screen.ScreenConfigurationCacheService;
import com.nn.sova.service.screen.ScreenDefinitionCacheService;
import com.nn.sova.service.table.TableConfigurationCacheService;
import com.nn.sova.service.text.TextDefinitionCacheService;
import com.nn.sova.service.user.UserMenuCacheService;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.utility.cache.CacheGetServiceImpl;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * The type Cache service.
 *
 * @author Anand Kumar
 */
public class CacheService {
    /**
     * The constant instance.
     */
    private static CacheService instance = null;
    
    /** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(CacheService.class);

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static CacheService getInstance() {
        if(instance == null) {
            instance = new CacheService();
        }
        return instance;
    }

    /**
     * Update roles linked with user id.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     */
    public void updateRolesLinkedWithUserId(List<Object> userId, String tenantId) throws QueryException {
        RoleConfigurationService.getInstance().updateRolesLinkedWithUserId(userId, tenantId);
    }

    /**
     * Get all locale info list.
     *
     * @return the list
     */
    public List<Object> getAllLocaleInfo() throws QueryException {
        String cacheKey = CacheKeyHelper.getActiveLangCodeKeyPrefix();
        return LocaleCacheService.getInstance().getAllLocale(cacheKey);
    }

    /**
     * Get locale info by lang cd list.
     *
     * @param locale the locale
     * @return the list
     */
    public List<Object> getLocaleInfoByLangCd(String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getActiveLangCodeByLocaleKey(locale);
        return LocaleCacheService.getInstance().getLocaleInfoByLangCd(cacheKey, locale);
    }

    /**
     * Get locale business object.
     *
     * @return the object
     */
    public Object getLocaleBusinessObject() throws QueryException {
        String cacheKey = CacheKeyHelper.getLocaleKey();
        return LocaleCacheService.getInstance().getLocaleBusinessObject(cacheKey);
    }

    /**
     * Update locale info.
     *
     * @throws QueryException the query exception
     */
    public void updateLocaleInfo() throws QueryException {
        String prefixCacheKey = CacheKeyHelper.getActiveLangCodeKeyPrefix();
        LocaleCacheService.getInstance().updateLocaleInfo(prefixCacheKey);
    }

    /**
     * Update all screen data elements.
     */
    public void updateAllScreenDataElements() throws QueryException {
        TableConfigurationCacheService.getInstance().updateAllScreenDataElements();
    }

    /**
     * Update data elements by env info.
     *
     * @param screenList the screen list
     * @param envInfo    the env info
     */
    public void updateDataElementsByEnvInfo(List<Object> screenList, EnvironmentDetailsEntity envInfo) throws QueryException {
        TableConfigurationCacheService.getInstance().updateDataElementsByEnvInfo(screenList, envInfo);
    }

    /**
     * Update data elements by comp info and env info.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @param envInfo       the env info
     */
    public void updateDataElementsByCompInfoAndEnvInfo(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList, EnvironmentDetailsEntity envInfo) throws QueryException {
        List<Object> screenList = TableConfigurationCacheService.getInstance().getScreenByCompData(elementIdList, dataFormatList, charsetList, masterList, envInfo);
        TableConfigurationCacheService.getInstance().updateDataElementsByEnvInfo(screenList, envInfo);
    }

    /**
     * Update data element by screen info.
     */
    public void updateDataElementByScreenInfo() throws QueryException {
        TableConfigurationCacheService.getInstance().updateDataElementByScreenInfo();
    }

    /**
     * Get data element by screen info list.
     *
     * @param screensDefId the screens def id
     * @param screenId     the screen id
     * @param locale       the locale
     * @return the list
     */
    public List<Map<String, Object>> getDataElementByScreenInfo(String screensDefId, String screenId, String locale) throws QueryException {
        if(StringUtils.isNotEmpty(screenId)) {
            String cacheKey = CacheKeyHelper.getScreenDataElementKey(screenId);
            return TableConfigurationCacheService.getInstance().getDataElementByScreenInfo(cacheKey, screenId, locale);
        }
        screenId = ScreenDefinitionCacheService.getInstance().getScreenByDefId(screensDefId);
        if(!screenId.isEmpty()) {
            String cacheKey = CacheKeyHelper.getScreenDataElementKey(screenId);
            return TableConfigurationCacheService.getInstance().getDataElementByScreenInfo(cacheKey, screenId, locale);
        }
        return Collections.emptyList();
    }
    
    /**
     * Get data element by component Definition Type
     *
     * @param screenDefType the screen definition type
     * @param key              the component key to be appended in cacheKey
     * @param locale           the locale
     * @return                 the list
     */
    public List<Map<String, Object>> getDataElementByScreenDefType(String screenDefType, String key, String locale) throws QueryException {
        if(StringUtils.isNotEmpty(screenDefType) && (StringUtils.isNotEmpty(key)) && (StringUtils.isNotEmpty(locale))) {
            String cacheKey = CacheKeyHelper.getCompDataElementKey(screenDefType, key);
            return TableConfigurationCacheService.getInstance().getDataElementByScreenDefType(cacheKey, screenDefType, key, locale);
        }
        return Collections.emptyList();
    }
    
    /**
     * delete cache by componentDefType and componentKey
     *
     * @param componentDefType the component definition type
     * @param key              the component key to be appended in cacheKey
     * @return boolean
     */
    public boolean deleteCacheByCompDefAndKey(String componentDefType, String key) {
    	if(StringUtils.isNotEmpty(componentDefType) && (StringUtils.isNotEmpty(key))) {  
    		String cacheKey = CacheKeyHelper.getCompDataElementKey(componentDefType, key);
    		CommonCacheService.getInstance().removeCacheByKey(cacheKey);
    		return true;
    	}
    	return false;
    }
    
	public boolean deleteCacheByCompDefAndKey(String componentDefType, List<String> keys) {
		if (StringUtils.isNotEmpty(componentDefType) && (CollectionUtils.isNotEmpty(keys))) {
			String[] actualKeys = new String[keys.size()];
			IntStream.range(0, keys.size()).forEach(index -> {
				actualKeys[index] = CacheKeyHelper.getCompDataElementKey(componentDefType, keys.get(index));
			});
			CacheManager.getInstance().del(actualKeys);
			return true;
		}
		return false;
	}
    
    /**
     * delete cache by componentDefType and componentKey
     *
     * @param componentDefType the component definition type
     * @param key              the component key to be appended in cacheKey
     * @return boolean
     */
    public boolean deleteCacheByCompDefType(String componentDefType) {
    	if(StringUtils.isNotEmpty(componentDefType)) {  
    		String prefixCacheKey = CacheKeyHelper.getCompDataElementKey(componentDefType, StringUtils.EMPTY);
            return TableConfigurationCacheService.getInstance().deleteCacheByCompDef(prefixCacheKey);
    	}
    	return false;
    }

    /**
     * Get data element for app generator.
     *
     * @param dataElement the data element
     * @return the map
     */
    public Map<Object, List<Map<String, Object>>> getDataElementForAppGenerator(String dataElement) throws QueryException {
        String cacheKey = CacheKeyHelper.getAppGenScreenDataElementKey();
        return TableConfigurationCacheService.getInstance().getDataElementForAppGenerator(cacheKey, dataElement);
    }

    /**
     * Update server side validation.
     */
    public void updateServerSideValidation() throws QueryException {
        TableConfigurationCacheService.getInstance().updateServerSideValidation(new ArrayList<>());
    }

    /**
     * Update server side validation.
     *
     * @param tableNameList the table name list
     * @param envInfo       the env info
     */
    public void updateServerSideValidation(List<Object> tableNameList, EnvironmentDetailsEntity envInfo) throws QueryException {
        TableConfigurationCacheService.getInstance().updateServerSideValidation(tableNameList, envInfo);
    }

    /**
     * Gets server side validation.
     *
     * @param tableName the table name
     * @return the server side validation
     */
    public Object getServerSideValidation(String tableName) throws QueryException {
        String cacheKey = CacheKeyHelper.getServerSideValidationKey(tableName);
        return TableConfigurationCacheService.getInstance().getServerSideValidation(cacheKey, tableName);
    }

    /**
     * Update screen cache data with Screen Id.
     *
     * @param screenId the screen id
     */
    public void updateServiceCacheDataWithScreenId(String screenId) throws QueryException {
        updateServiceCacheDataWithScreenIdList(Collections.singletonList(screenId));
    }

    /**
     * Update screen cache data with ScreenId list.
     *
     * @param screenIdList the screen id list
     */
    public void updateServiceCacheDataWithScreenIdList(List<Object> screenIdList) throws QueryException {
        TableConfigurationCacheService.getInstance().updateDataElementByScreenInfo(Collections.singletonList(screenIdList));
        TableConfigurationCacheService.getInstance().updateServerSideValidation(new ArrayList<>());
        ScreenConfigurationCacheService.getInstance().updateScreenConfigurationData(Collections.singletonList(screenIdList));
        ScreenDefinitionCacheService.getInstance().updateScreenDefinitionData(Collections.singletonList(screenIdList));
    }

    /**
     * Update screen component data.
     */
    public void updateScreenComponentData() throws QueryException {
        ScreenConfigurationCacheService.getInstance().updateScreenComponentData();
    }

    /**
     * Update screen component data.
     *
     * @param screenList the screen list
     * @throws QueryException the query exception
     */
    public void updateScreenComponentData(List<String> screenList) throws QueryException {
        ScreenConfigurationCacheService.getInstance().updateScreenComponentData(screenList);
    }

    /**
     * Get screen component definition data object.
     *
     * @param screenId the screen id
     * @return screen component definition object
     */
    public Object getScreenComponentData(String screenId) throws QueryException {
        String cacheKey = CacheKeyHelper.getScreenComponentDefinitionkey(screenId);
        return ScreenConfigurationCacheService.getInstance().getScreenComponentData(cacheKey, screenId);
    }

    /**
     * Get screen definition data by locale and screenId.
     *
     * @param screenId the screen id
     * @param locale   the locale
     * @return the screen definition entity
     */
    public ScreenDefinitionEntity getScreenDefinitionDataByLocale(String screenId, String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getScreenDefinitionKey(screenId);
        return ScreenDefinitionCacheService.getInstance().getScreenDefinitionDataByLocale(cacheKey, screenId, locale);
    }

    /**
     * Update screen definition data.
     */
    public void updateScreenDefinitionData() throws QueryException {
        ScreenDefinitionCacheService.getInstance().updateScreenDefinitionData();
    }

    /**
     * Update screen definition data.
     *
     * @param screenIdList the screen id list
     * @param envinfo      the envinfo
     */
    public void updateScreenDefinitionData(List<Object> screenIdList, EnvironmentDetailsEntity envinfo) throws QueryException {
        ScreenDefinitionCacheService.getInstance().updateScreenDefinitionData(screenIdList, envinfo);
    }

    /**
     * Get screen configuration data by locale and screenId
     *
     * @param screenId the screen id
     * @param locale   the locale
     * @return Screen Configuration Data Map
     */
    public Map<String, Object> getScreenConfigurationDataByLocale(String screenId, String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getScreenConfigurationKey(screenId);
        return ScreenConfigurationCacheService.getInstance().getScreenConfigurationDataByLocale(cacheKey, screenId, locale);
    }

    /**
     * Update screen configuration data.
     *
     * @param screenIdList the screen id list
     * @param envinfo      the envinfo
     */
    public void updateScreenConfigurationData(List<Object> screenIdList, EnvironmentDetailsEntity envinfo) throws QueryException {
        ScreenConfigurationCacheService.getInstance().updateScreenConfigurationData(screenIdList, envinfo);
    }

    /**
     * Update screen configuration data.
     */
    public void updateScreenConfigurationData(List<Object> screenIdList) throws QueryException {
        ScreenConfigurationCacheService.getInstance().updateScreenConfigurationData(screenIdList);
    }

    /**
     * Get screen component focus data list.
     *
     * @param screenId the screen id
     * @return the list
     */
    public List<Map<String, Object>> getScreenComponentFocusData(String screenId) throws QueryException {
        String cacheKey = CacheKeyHelper.getScreenComponentFocusDataKey();
        return ScreenConfigurationCacheService.getInstance().getScreenComponentFocusData(cacheKey, screenId);
    }

    /**
     * Update screen component focus data.
     *
     * @throws QueryException the query exception
     */
    public void updateScreenComponentFocusData() throws QueryException {
        ScreenConfigurationCacheService.getInstance().updateScreenComponentFocusData();
    }

    /**
     * Gets screen details based on application code.
     *
     * @param cacheKey the cache key
     * @return the screen details based on application code
     */
    public Map<String, List<Map<String, Object>>> getScreenDetailsBasedOnApplicationCode(String cacheKey) {
        return ScreenConfigurationCacheService.getInstance().getScreenDetailsBasedOnApplicationCode(cacheKey);
    }

    /**
     * Gets authorized screens by role id.
     *
     * @param roleId the role id
     * @return the aupdateScreenRoleLinkDatauthorized screens by role id
     */
    public Map<Object, List<Map<String, Object>>> getAuthorizedScreensByRoleId(String roleId) throws QueryException {
        String cacheKey = CacheKeyHelper.getAuthorizedScreensKey(roleId, ContextBean.getTenantId());
        return RoleConfigurationService.getInstance().getAuthorizedScreensByRoleId(cacheKey);
    }

    /**
     * Get message definition data message definition entity.
     *
     * @param messageId the message id
     * @param locale    the locale
     * @return the message definition entity
     */
    public MessageDefinitionEntity getMessageDefinitionData(String messageId, String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getMessageDefinitionKey(messageId);
        return MessageDefinitionCacheService.getInstance().getMessageDefinitionData(cacheKey, messageId, locale);
    }

    /**
     * Update message definition data.
     *
     * @param messageIdList the message id list
     * @param entity        the entity
     */
    public void updateMessageDefinitionData(List<Object> messageIdList, EnvironmentDetailsEntity entity) throws QueryException {
        MessageDefinitionCacheService.getInstance().updateMessageDefinitionData(messageIdList, entity);
    }

    /**
     * Update message definition data.
     */
    public void updateMessageDefinitionData() throws QueryException {
        MessageDefinitionCacheService.getInstance().updateMessageDefinitionData();
    }

    /**
     * Get application text definition data object.
     *
     * @return the object
     */
    public Map<String, Object> getApplicationTextDefinitionData(String screenDefId) throws QueryException {
        String cacheKey = CacheKeyHelper.getTextDefinitionApplicationKey(screenDefId,ContextBean.getLocale());
        return TextDefinitionCacheService.getInstance().getApplicationTextDefinitionData(screenDefId,cacheKey);
    }

    /**
     * Get application text definition data string.
     *
     * @param textId the text id
     * @param locale the locale
     * @return the string
     */
    public String getApplicationTextDefinitionData(String textId,String screenDefId, String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getTextDefinitionApplicationKey(screenDefId,locale);
        return TextDefinitionCacheService.getInstance().getApplicationTextDefinitionData(screenDefId,cacheKey, textId);
    }

    /**
     * Update text definition data.
     */
    public void updateApplicationTextDefinitionData(String screenDefId) throws QueryException {
        TextDefinitionCacheService.getInstance().updateApplicationTextDefinitionData(screenDefId);
    }

    /**
     * Update text definition data.
     *
     * @param envInfo the env info
     */
    public void updateTextDefinitionData(String screenDefId,EnvironmentDetailsEntity envInfo) throws QueryException {
        TextDefinitionCacheService.getInstance().updateApplicationTextDefinitionData(screenDefId,envInfo);
    }

    /**
     * Get framework text definition data object.
     *
     * @return the object
     */
    public Object getFrameworkTextDefinitionData() throws QueryException {
        String cacheKey = CacheKeyHelper.getTextDefinitionFrameworkKey(ContextBean.getLocale());
        return TextDefinitionCacheService.getInstance().getFrameworkTextDefinitionData(cacheKey);
    }
    
    /**
     * Get framework text definition data object.
     *
     * @return the object
     */
    public Object getFrameworkTextDefinitionData(String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getTextDefinitionFrameworkKey(locale);
        return TextDefinitionCacheService.getInstance().getFrameworkTextDefinitionData(cacheKey);
    }

    /**
     * Get framework text definition data string.
     *
     * @param textId the text id
     * @param locale the locale
     * @return the string
     */
    public String getFrameworkTextDefinitionData(String textId, String locale) throws QueryException {
        String cacheKey = CacheKeyHelper.getTextDefinitionFrameworkKey(locale);
        return TextDefinitionCacheService.getInstance().getFrameworTextDefinitionData(cacheKey, textId);
    }

    /**
     * Update class configuration data.
     */
    public void updateClassConfigurationData() throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateClassConfigurationData();
    }

    /**
     * Update class configuration data.
     *
     * @param classIdList the class id list
     * @param entity      the entity
     */
    public void updateClassConfigurationData(List<Object> classIdList, EnvironmentDetailsEntity entity) throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateClassConfigurationData(classIdList, entity);
    }

    /**
     * Update product by user id.
     *
     * @param productCode the product code
     */
    public void updateProductByUserId(String productCode) {
        String cacheKey = CacheKeyHelper.getProductByUserIdKey(ContextBean.getUserId());
        ApplicationConfigurationCacheService.getInstance().updateProductByUserId(cacheKey, productCode);
    }

    /**
     * Gets product by user id.
     *
     * @return the product by user id
     */
    public String getProductByUserId() {
        String cacheKey = CacheKeyHelper.getProductByUserIdKey(ContextBean.getUserId());
        return ApplicationConfigurationCacheService.getInstance().getProductByUserId(cacheKey);
    }

    /**
     * Get product tenant configuration details list.
     *
     * @param productCode the product code
     * @return the list
     */
    public List<String> getProductTenantConfigurationDetails(String productCode) throws QueryException {
        String cacheKey = CacheKeyHelper.getProductTenantConfigurationKey(productCode);
        return ApplicationConfigurationCacheService.getInstance().getProductTenantConfigurationDetails(cacheKey, productCode);
    }

    /**
     * Get repo configuration data list.
     *
     * @return the list
     */
    public List<Map<String, Object>> getRepoConfigurationData() throws QueryException {
        String cacheKey = CacheKeyHelper.getRepoConfigurationKey();
        return ApplicationConfigurationCacheService.getInstance().getRepoConfigurationData(cacheKey);
    }

    /**
     * Get tenant configuration data list.
     *
     * @return the list
     */
    public List<Map<String, Object>> getTenantConfigurationData() throws QueryException {
        String cacheKey = CacheKeyHelper.getTenantConfigurationDataKey();
        return ApplicationConfigurationCacheService.getInstance().getTenantConfigurationData(cacheKey);
    }
    
	/**
	 * Get tenant definition.
	 *
	 * @return the list
	 */
	public Map<String, Object> getTenantDefinition(String tenantId) throws QueryException {
		String cacheKey = CacheKeyHelper.getTenantDefinitionDataKey();
		return ApplicationConfigurationCacheService.getInstance().getTenantDefinitionData(cacheKey, tenantId);
	}

    /**
     * Gets tenant user data by tenant Id.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     * @return the tenant user data
     */
    public Map<String, Object> getUserDataByTenantId(String userId, String tenantId) throws QueryException {
        String cacheKey = CacheKeyHelper.getTenantUserKey(tenantId, userId);
        return ApplicationConfigurationCacheService.getInstance().getTenantUserData(cacheKey, tenantId, userId);
    }

    /**
     * Update tenant user data.
     */
    public void updateTenantUserData() throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateTenantUserData();
    }

    /**
     * Update tenant user data.
     *
     * @param userIdList the user id list
     * @param tenantId   the tenant id
     */
    public void updateTenantUserData(List<Object> userIdList, String tenantId) throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateTenantUserData(userIdList, tenantId);
    }

    /**
     * Update tenant user data.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     * @param userMap  the user map
     * @throws QueryException the query exception
     */
    public void updateTenantUserData(String userId,String tenantId,Map<String,Object> userMap) throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateTenantUserData(userId,tenantId,userMap);
    }

    /**
     * Update tenant user data.
     *
     * @param userIdList the user id list
     */
    public void updateTenantUserData(List<Object> userIdList) throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateTenantUserData(userIdList);
    }

    /**
     * Update tenant user data.
     *
     * @param userId the user id
     */
    public void updateTenantUserData(String userId) throws QueryException {
        ApplicationConfigurationCacheService.getInstance().updateTenantUserData(userId);
    }



    /**
     * Gets tenant user data by default tenant.
     *
     * @param userId the user id
     * @return the tenant user dataApplicationCode
     */
    public Map<String, Object> getUserDataByTenantId(String userId) throws QueryException {
        String cacheKey = CacheKeyHelper.getTenantUserKey(ContextBean.getTenantId(), userId);
        return ApplicationConfigurationCacheService.getInstance().getTenantUserData(cacheKey, ContextBean.getTenantId(), userId);
    }

    /**
     * Gets role data by tenant id.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     * @return the role data by tenant id
     */
    public List<Map<String, Object>> getRoleDataByTenantId(String roleId, String tenantId) throws QueryException {
        String cacheKey = CacheKeyHelper.getRoleConfigurationKey(roleId, tenantId);
        return RoleConfigurationService.getInstance().getRoleDataByTenantId(cacheKey, roleId, tenantId);
    }

    /**
     * Update roles linked with tenant id.
     */
    public void updateRoleDataByTenantId() throws QueryException {
        RoleConfigurationService.getInstance().updateRoleDataByTenantId();
    }

    /**
     * Update roles linked with user id.
     */
    public void updateRolesLinkedWithUserId() throws QueryException {
        RoleConfigurationService.getInstance().updateRolesLinkedWithUserId();
    }

    /**
     * Get roles linked with user id list.
     *
     * @param userId the user id
     * @return the list
     */
    public List<Map<String, Object>> getRolesLinkedWithUserId(String userId) throws QueryException {
        String cacheKey = CacheKeyHelper.getRolesLinkedWithUserIdKey(userId);
        return RoleConfigurationService.getInstance().getRolesLinkedWithUserId(cacheKey, userId);
    }

    /**
     * Get tenant roles linked with user id list.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     * @return the list
     */
    public List<Map<String, Object>> getTenantRolesLinkedWithUserId(String userId, String tenantId) throws QueryException {
        String cacheKey = CacheKeyHelper.getTenantRolesLinkedWithUserIdKey(tenantId, userId);
        return RoleConfigurationService.getInstance().getRolesLinkedWithUserId(cacheKey, tenantId, userId);
    }

    /**
     * Get screen role link data list.
     *
     * @param roleId the role id
     * @return the list
     */
    public List<Map<String, Object>> getScreenRoleLinkData(String roleId) throws QueryException {
        String cacheKey = CacheKeyHelper.getScreenRoleLinkKey(roleId);
        return RoleConfigurationService.getInstance().getScreenRoleLinkData(cacheKey, roleId);
    }

    /**
     * Update screen role link data.
     */
    public void updateScreenRoleLinkData(String roleId) throws QueryException {
        RoleConfigurationService.getInstance().updateScreenRoleLinkData(roleId);
    }

    /**
     * Update tenant screen role link data.
     */
    public void updateTenantScreenRoleLinkData(String tenantId, String roleId) throws QueryException {
        RoleConfigurationService.getInstance().updateTenantScreenRoleLinkData(tenantId,roleId);
    }


    /**
     * Get tenant screen role link data list.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     * @return the list
     */
    public List<Map<String, Object>> getTenantScreenRoleLinkData(String roleId, String tenantId) throws QueryException {
        String cacheKey = CacheKeyHelper.getTenantScreenRoleLinkKey(roleId, tenantId);
        return RoleConfigurationService.getInstance().getTenantScreenRoleLinkData(cacheKey, tenantId, roleId);
    }

    /**
     * Gets landscape system definition data.
     *
     * @return the landscape system definition data
     */
    public List<Map<String, Object>> getLandscapeSystemDefinitionData() throws QueryException {
        String cacheKey = CacheKeyHelper.getLandscapeSystemDefinitionKey();
        return ApplicationConfigurationCacheService.getInstance().getLandscapeSystemDefinitionData(cacheKey);
    }

    /**
     * Gets environment properties data.
     *
     * @return the environment properties data
     */
    public Map<String, Object> getEnvironmentPropertiesData() throws QueryException {
        String cacheKey = CacheKeyHelper.getEnvironmentPropertiesKey();
        return ApplicationConfigurationCacheService.getInstance().getEnvironmentProperties(cacheKey);
    }

    /**
     * Gets environment properties by key.
     *
     * @param key the key
     * @return the environment properties by key
     */
    public String getEnvironmentPropertiesByKey(String key) throws QueryException {
        Map<String, Object> environmentPropertiesMap = getEnvironmentPropertiesData();
        return String.valueOf(environmentPropertiesMap.get(key));
    }

    /**
     * Gets system settings data.
     *
     * @return the system settings data
     */
    public Object getSystemSettingsData() throws QueryException {
        String cacheKey = CacheKeyHelper.getSystemSettingsKey();
        return ApplicationConfigurationCacheService.getInstance().getSystemSettingsData(cacheKey);
    }

    /**
     * Gets drive user space info.
     *
     * @return the drive user space info
     */
    public Object getDriveUserSpaceInfo() throws QueryException {
        String cacheKey = CacheKeyHelper.getDriveUserSpaceInfoKey();
        return ApplicationConfigurationCacheService.getInstance().getDriveUserSpaceInfo(cacheKey);
    }

    /**
     * Gets festival holidays.
     *
     * @return the festival holidays
     */
    public List<Map<String, Object>> getFestivalHolidays() throws QueryException {
        String cacheKey = CacheKeyHelper.getFestivalHolidaysKey();
        return ApplicationConfigurationCacheService.getInstance().getFestivalHolidays(cacheKey);
    }

    /**
     * Gets holiday dates.
     *
     * @return the holiday dates
     */
    public List<Map<String, Object>> getHolidayDates() throws QueryException {
        String cacheKey = CacheKeyHelper.getHolidayDatesKey();
        return ApplicationConfigurationCacheService.getInstance().getHolidayDates(cacheKey);
    }

    /**
     * Gets countries phone prefix info.
     *
     * @return the countries phone prefix info
     */
    public Object getCountriesPhonePrefixInfo() throws QueryException {
        String cacheKey = CacheKeyHelper.getCountriesPhonePrefixInfoKey();
        return ApplicationConfigurationCacheService.getInstance().getCountriesPhonePrefixInfo(cacheKey);
    }

    /**
     * Gets user image path.
     *
     * @param userId the user id
     * @return the user image path
     */
    public String getUserImagePath(String userId) throws QueryException {
        Map<String, Object> userDataMap = getUserDataByTenantId(userId);
        return ApplicationConfigurationCacheService.getInstance().getUserImagePath(userDataMap, userId);
    }

    /**
     * Gets cache data.
     *
     * @param cacheKey the cache key
     * @return the cache data
     */
    public Object getCacheData(String cacheKey) {
        return CommonCacheService.getInstance().getCacheData(cacheKey);
    }

    /**
     * Gets partial cache keys.
     *
     * @param cacheKey the cache key
     * @return the partial cache keys
     */
    public Set<String> getPartialCacheKeys(String cacheKey) {
        return CommonCacheService.getInstance().getPartialCacheKeys(cacheKey);
    }

    /**
     * Get ttl by key long.
     *
     * @param cacheKey the cache key
     * @return the long
     */
    public long getTTLByKey(String cacheKey) {
        return CommonCacheService.getInstance().getTTLByKey(cacheKey);
    }

    /**
     * Remove cache by key.
     *
     * @param cacheKey the cache key
     */
    public void removeCacheByKey(String cacheKey) {
        CommonCacheService.getInstance().removeCacheByKey(cacheKey);
    }

    /**
     * Remove cache by key.
     *
     * @param cacheKey the cache key
     * @param envInfo  the env info
     */
    public void removeCacheByKey(String cacheKey, RedisEnvInfo envInfo) {
        CommonCacheService.getInstance().removeCacheByKey(cacheKey, envInfo);
    }

    /**
     * Save to cache.
     *
     * @param cacheKey   the cache key
     * @param cacheValue the cache value
     */
    public void saveToCache(String cacheKey, Object cacheValue) {
        CommonCacheService.getInstance().saveToCache(cacheKey, cacheValue);
    }

    /**
     * Save to cache with env info.
     *
     * @param cacheKey      the cache key
     * @param cacheObjValue the cache obj value
     * @param envInfo       the env info
     */
    public void saveToCacheWithEnvInfo(String cacheKey, Object cacheObjValue, RedisEnvInfo envInfo) {
        CommonCacheService.getInstance().saveToCacheWithEnvInfo(cacheKey, cacheObjValue, envInfo);
    }

    /**
     * Save to cache with expiration.
     *
     * @param cacheKey      the cache key
     * @param cacheObjValue the cache obj value
     * @param timeUnit      the time unit
     */
    public void saveToCacheWithExpiration(String cacheKey, Object cacheObjValue, int timeUnit) {
        CommonCacheService.getInstance().saveToCacheWithExpiration(cacheKey, cacheObjValue, timeUnit);
    }

    /**
     * Remove environment properties from cache.
     */
    public void removeEnvironmentPropertiesFromCache() {
        String cacheKey = CacheKeyHelper.getEnvironmentPropertiesKey();
        ApplicationConfigurationCacheService.getInstance().removeEnvironmentPropertiesFromCache(cacheKey);
    }

    /**
     * Remove environment properties from cache.
     *
     * @param envInfo the env info
     */
    public void removeEnvironmentPropertiesFromCache(EnvironmentDetailsEntity envInfo) {
        String cacheKey = CacheKeyHelper.getEnvironmentPropertiesKey();
        ApplicationConfigurationCacheService.getInstance().removeEnvironmentPropertiesFromCache(cacheKey, envInfo);
    }

    /**
     * Remove archive search setting.
     */
    public void removeArchiveSearchSetting() {
        String cacheKey = CacheKeyHelper.getArchiveSearchSettingKey();
        ApplicationConfigurationCacheService.getInstance().removeArchiveSearchSetting(cacheKey);
    }

    /**
     * Remove auto numbering.
     */
    public void removeAutoNumbering() throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getAutoNumberingPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeAutoNumbering(cachePrefixKey);
    }

    /**
     * Remove auto numbering.
     *
     * @param keyList the key list
     */
    public void removeAutoNumbering(List<String> keyList) {
        String cachePrefixKey = CacheKeyHelper.getAutoNumberingPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeAutoNumbering(cachePrefixKey, keyList);
    }

    /**
     * Remove auto numbering.
     *
     * @param keyList the key list
     * @param entity  the entity
     */
    public void removeAutoNumbering(List<String> keyList, EnvironmentDetailsEntity entity) {
        String cachePrefixKey = CacheKeyHelper.getAutoNumberingPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeAutoNumbering(cachePrefixKey, keyList, entity);
    }
    
    /**
     * Remove class configuration.
     *
     * @param id     the id
     */
    public void removeClassConfiguration(String id) {
        String cachePrefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeClassConfiguration(cachePrefixKey, id);
    }

    /**
     * Remove class configuration.
     *
     * @param idList the id list
     * @param entity the entity
     */
    public void removeClassConfiguration(List<Object> idList) {
        String cachePrefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeClassConfiguration(cachePrefixKey, idList);
    }    

    /**
     * Remove class configuration.
     *
     * @param id     the id
     * @param entity the entity
     */
    public void removeClassConfiguration(String id, EnvironmentDetailsEntity entity) {
        String cachePrefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeClassConfiguration(cachePrefixKey, id, entity);
    }

    /**
     * Remove class configuration.
     *
     * @param idList the id list
     * @param entity the entity
     */
    public void removeClassConfiguration(List<Object> idList, EnvironmentDetailsEntity entity) {
        String cachePrefixKey = CacheKeyHelper.getClassConfigurationPrefixKey();
        ApplicationConfigurationCacheService.getInstance().removeClassConfiguration(cachePrefixKey, idList, entity);
    }

    /**
     * Remove landscape system definition.
     */
    public void removeLandscapeSystemDefinition() {
        String cacheKey = CacheKeyHelper.getLandscapeSystemDefinitionKey();
        ApplicationConfigurationCacheService.getInstance().removeLandscapeSystemDefinition(cacheKey);
    }

    /**
     * Remove countries phone prefix info key.
     */
    public void removeCountriesPhonePrefixInfoKey() {
        String cacheKey = CacheKeyHelper.getCountriesPhonePrefixInfoKey();
        ApplicationConfigurationCacheService.getInstance().removePhoneDetails(cacheKey);
    }

    /**
     * Remove drive file user space.
     */
    public void removeDriveFileUserSpace() {
        String cacheKey = CacheKeyHelper.getDriveUserSpaceInfoKey();
        ApplicationConfigurationCacheService.getInstance().removeDriveFileUserSpace(cacheKey);
    }

    /**
     * Remove system setting.
     */
    public void removeSystemSetting() {
        String cacheKey = CacheKeyHelper.getSystemSettingsKey();
        ApplicationConfigurationCacheService.getInstance().removeSystemSetting(cacheKey);
    }

    /**
     * Remove repo config details.
     */
    public void removeRepoConfigDetails() {
        String cacheKey = CacheKeyHelper.getRepoConfigurationKey();
        ApplicationConfigurationCacheService.getInstance().removeRepoConfigDetails(cacheKey);
    }

    /**
     * Remove holidays.
     */
    public void removeHolidays() {
        ApplicationConfigurationCacheService.getInstance().removeHolidays();
    }

    /**
     * Remove data element.
     *
     * @param serviceId the service id
     */
    public void removeDataElement(String serviceId) {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, serviceId);
    }

    /**
     * Remove data element.
     *
     * @param serviceIdList the service id list
     */
    public void removeDataElement(List<String> serviceIdList) {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, serviceIdList);
    }

    /**
     * Remove data element.
     *
     * @param serviceIdList the service id list
     * @param envInfo       the env info
     */
    public void removeDataElement(List<Object> serviceIdList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, serviceIdList, envInfo);
    }

    /**
     * Remove data element.
     *
     * @param elementIdList            the element id list
     * @param dataFormatList            the data class list
     * @param charsetList              the charset list
     * @param masterList               the master list
     * @param environmentDetailsEntity the environment details entity
     */
    public void removeDataElement(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                  EnvironmentDetailsEntity environmentDetailsEntity) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, elementIdList, dataFormatList, charsetList, masterList, environmentDetailsEntity);
    }

    /**
     * Remove data element.
     *
     * @param elementIdList the element id list
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     */
    public void removeDataElement(List<Object> elementIdList, List<Object> dataFormatList, List<Object> charsetList,
                                  List<Object> masterList) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getScreenDataElementPrefixKey();
        TableConfigurationCacheService.getInstance().removeDataElement(cachePrefixKey, elementIdList, dataFormatList, charsetList, masterList);
    }

    /**
     * Remove encryption details.
     *
     * @param tableName the table name
     */
    public void removeEncryptionDetails(String tableName) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableName);
    }

    /**
     * Remove encryption details.
     *
     * @param tableNameList the table name list
     */
    public void removeEncryptionDetails(List<String> tableNameList) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableNameList);
    }

    /**
     * Remove encryption details.
     *
     * @param tableName the table name
     * @param envInfo   the env info
     */
    public void removeEncryptionDetails(String tableName, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableName, envInfo);
    }

    /**
     * Remove encryption details.
     *
     * @param tableNameList the table name list
     * @param envInfo       the env info
     */
    public void removeEncryptionDetails(List<Object> tableNameList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationEncryptionPrefixKey();
        TableConfigurationCacheService.getInstance().removeEncryptionDetails(cachePrefixKey, tableNameList, envInfo);
    }

    /**
     * Remove table config.
     *
     * @param tableList the table list
     * @param envInfo   the env info
     */
    public void removeTableConfig(List<Object> tableList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeTableConfig(cachePrefixKey, tableList, envInfo);
    }

    /**
     * Remove table config.
     *
     * @param tableList the table list
     */
    public void removeTableConfig(List<String> tableList) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeTableConfig(cachePrefixKey, tableList);
    }

    /**
     * Remove view config.
     *
     * @param viewList the view list
     */
    public void removeViewConfig(List<String> viewList) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeViewConfig(cachePrefixKey, viewList);
    }

    /**
     * Remove view config.
     *
     * @param viewList the view list
     * @param envInfo  the env info
     */
    public void removeViewConfig(List<String> viewList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getTableConfigurationPrefixKey();
        TableConfigurationCacheService.getInstance().removeViewConfig(cachePrefixKey, viewList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param tableName the table name
     */
    public void removeServerSideValidation(String tableName) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, tableName);
        removeEncryptionDetails(tableName);
        removeTableConfig(Arrays.asList(tableName));
        CommonCacheService.removeTableValidationData(Arrays.asList(tableName));
    }
    
    /**
     * Remove server side validation.
     *
     * @param tableName the table name
     */
    public void removeServerSideValidation(String tableName,String productCode) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, tableName);
        removeEncryptionDetails(tableName);
        removeTableConfig(Arrays.asList(tableName));
        CommonCacheService.removeTableValidationData(Arrays.asList(tableName),productCode);
    }

    /**
     * Remove server side validation.
     *
     * @param tableNameList the table name list
     */
    public void removeServerSideValidation(List<String> tableNameList) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, tableNameList);
        CommonCacheService.removeTableValidationData(tableNameList);
    }
    /**
     * Remove server side validation.
     *
     * @param tableNameList the table name list
     */
    public void removeServerSideValidation(List<String> tableNameList,String productCode) {
    	String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
    	TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, tableNameList);
    	CommonCacheService.removeTableValidationData(tableNameList,productCode);
    }

    /**
     * Remove server side validation.
     *
     * @param tableNameList the table name list
     * @param envInfo       the env info
     */
    public void removeServerSideValidation(List<String> tableNameList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, tableNameList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param dataElementList the data element list
     * @param dataFormatList   the data class list
     * @param charsetList     the charset list
     * @param masterList      the master list
     * @param envInfo         the env info
     */
    public void removeServerSideValidation(List<Object> dataElementList, List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                           EnvironmentDetailsEntity envInfo) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, dataElementList, dataFormatList, charsetList, masterList, envInfo);
    }

    /**
     * Remove server side validation.
     *
     * @param dataFormatList the data class list
     * @param charsetList   the charset list
     * @param masterList    the master list
     * @param envInfo       the env info
     */
    public void removeServerSideValidation(List<Object> dataFormatList, List<Object> charsetList, List<Object> masterList,
                                           EnvironmentDetailsEntity envInfo) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidation(cachePrefixKey, dataFormatList, charsetList, masterList, envInfo);
    }

    /**
     * Remove server side validation with service id.
     *
     * @param serviceId the service id
     */
    public void removeServerSideValidationWithServiceId(String serviceId) throws QueryException {
        String cachePrefixKey = CacheKeyHelper.getServerSideValidationPrefixKey();
        TableConfigurationCacheService.getInstance().removeServerSideValidationWithServiceId(cachePrefixKey, serviceId);
    }

    /**
     * Remove database handler details.
     *
     * @param productCodeList the product code list
     */
    public void removeDatabaseHandlerDetails(List<String> productCodeList) {
        String cachePrefixKey = CacheKeyHelper.getDatabaseHandlerPrefixKey();
        TableConfigurationCacheService.getInstance().removeDatabaseHandlerDetails(cachePrefixKey, productCodeList);
    }

    /**
     * Remove database handler details.
     *
     * @param productCodeList the product code list
     * @param envInfo         the env info
     */
    public void removeDatabaseHandlerDetails(List<String> productCodeList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getDatabaseHandlerPrefixKey();
        TableConfigurationCacheService.getInstance().removeDatabaseHandlerDetails(cachePrefixKey, productCodeList, envInfo);
    }

    /**
     * Remove authorized screens by tenant id.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     */
    public void removeAuthorizedScreensByTenantId(String roleId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getAuthorizedScreensPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeAuthorizedScreensByTenantId(cachePrefixKey, tenantId, roleId);
    }

    /**
     * Remove authorized screens.
     *
     * @param roleIdList the role id list
     */
    public void removeAuthorizedScreens(List<Object> roleIdList) {
        String cachePrefixKey = CacheKeyHelper.getAuthorizedScreensPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeTenantAuthorityService(cachePrefixKey, roleIdList);
    }

    /**
     * Remove screen role link.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     */
    public void removeTenantScreenRoleLink(String roleId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getScreenRoleLinkPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeTenantScreenRoleLink(cachePrefixKey, tenantId, roleId);
    }

    /**
     * Remove screen component focus.
     */
    public void removeScreenComponentFocus() {
        String cacheKey = CacheKeyHelper.getScreenComponentFocusDataKey();
        ScreenDefinitionCacheService.getInstance().removeScreenComponentFocus(cacheKey);
    }

    /**
     * Remove screen link.
     *
     * @param screenId the screen id
     */
    public void removeScreenLink(String screenId) {
        String cachePrefixKey = CacheKeyHelper.getLinkedScreensDefinitionPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeScreenLink(cachePrefixKey, screenId);
    }

    /**
     * Remove screen link with screen id list.
     *
     * @param screenIdList the screen id list
     * @param envInfo      the env info
     */
    public void removeScreenLinkWithScreenIdList(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) {
        String cachePrefixKey = CacheKeyHelper.getLinkedScreensDefinitionPrefixKey();
        ScreenDefinitionCacheService.getInstance().removeScreenLinkWithScreenIdList(cachePrefixKey, screenIdList, envInfo);
    }

    /**
     * Remove screens with def id.
     *
     * @param serviceDefIdList the service def id list
     * @param envInfo          the env info
     */
    public void removeScreensWithDefId(List<Object> serviceDefIdList, EnvironmentDetailsEntity envInfo) throws QueryException {
        ScreenDefinitionCacheService.getInstance().removeScreensWithDefId(serviceDefIdList, envInfo);
    }

    /**
     * Remove service.
     *
     * @param screenId the screen id
     */
    public void removeScreensWithScreenId(String screenId) {
        ScreenDefinitionCacheService.getInstance().removeScreensWithScreenId(screenId);
    }

    /**
     * Remove service.
     *
     * @param screenIdList the screen id list
     * @param envInfo      the env info
     */
    public void removeScreensWithScreenIdList(List<String> screenIdList) {
        ScreenDefinitionCacheService.getInstance().removeScreensWithScreenIdList(screenIdList);
    }
    
    /**
     * Remove service.
     *
     * @param screenIdList the screen id list
     * @param envInfo      the env info
     */
    public void removeScreensWithScreenId(List<Object> screenIdList, EnvironmentDetailsEntity envInfo) {
        ScreenDefinitionCacheService.getInstance().removeScreensWithScreenId(screenIdList, envInfo);
    }

    /**
     * Remove application text def.
     */
    public void removeApplicationTextDef() {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef();
    }

    /**
     * Remove application text def.
     *
     * @param productCode the product code
     */
    public void removeApplicationTextDef(String screenDefId) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(screenDefId);
    }

    /**
     * Remove application text def.
     *
     * @param productCodeList the product code list
     */
    public void removeApplicationTextDef(List<String> screenDefIdList) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(screenDefIdList);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo the env info
     */
    public void removeApplicationTextDef(EnvironmentDetailsEntity envInfo) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(envInfo);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo     the env info
     * @param productCode the product code
     */
    public void removeApplicationTextDef(EnvironmentDetailsEntity envInfo, String screenDefId) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(envInfo, screenDefId);
    }

    /**
     * Remove application text def.
     *
     * @param envInfo         the env info
     * @param productCodeList the product code list
     */
    public void removeApplicationTextDef(EnvironmentDetailsEntity envInfo, List<String> screenDefIdList) {
        TextDefinitionCacheService.getInstance().removeApplicationTextDef(envInfo, screenDefIdList);
    }

    /**
     * Remove framework text def.
     */
    public void removeFrameworkTextDef() {
    	removeCacheByKey("sova_lang_fw_text_data_key");
        TextDefinitionCacheService.getInstance().removeFrameworkTextDef();
    }

    /**
     * Remove framework text def.
     *
     * @param envInfo the env info
     */
    public void removeFrameworkTextDef(EnvironmentDetailsEntity envInfo) {
        TextDefinitionCacheService.getInstance().removeFrameworkTextDef(envInfo);
    }

    /**
     * Remove tenant role data.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     */
    public void removeTenantRoleData(String roleId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getRoleConfigurationPrefixKey();
        RoleConfigurationService.getInstance().removeTenantRoleData(cachePrefixKey, tenantId, roleId);
    }

    /**
     * Remove tenant role link data.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     */
    public void removeTenantRoleLinkData(String userId, String tenantId) {
        String cachePrefixKey = CacheKeyHelper.getRolesLinkedWithUserIdPrefixKey();
        RoleConfigurationService.getInstance().removeTenantRoleLinkData(cachePrefixKey, tenantId, userId);
    }

    /**
     * Remove role links.
     *
     * @param userIdList the user id list
     */
    public void removeRoleLinks(List<Object> userIdList) {
        String cachePrefixKey = CacheKeyHelper.getRolesLinkedWithUserIdPrefixKey();
        RoleConfigurationService.getInstance().removeRoleLinks(cachePrefixKey, userIdList);
    }

    /**
     * Remove tenant users.
     *
     * @param userIdList the user id list
     */
    public void removeTenantUsers(List<Object> userIdList) {
        String cachePrefixKey = CacheKeyHelper.getTenantUserPrefixKey();
        RoleConfigurationService.getInstance().removeTenantUsers(cachePrefixKey, userIdList);
    }

    /**
     * Remove tenant role links.
     *
     * @param userIdList the user id list
     */
    public void removeTenantRoleLinks(List<Object> userIdList) {
        String cachePrefixKey = CacheKeyHelper.getTenantRolesLinkedWithUserIdPrefixKey();
        RoleConfigurationService.getInstance().removeTenantRoleLinks(cachePrefixKey, userIdList);
    }

    /**
     * Remove message def.
     */
    public void removeMessageDefinition() {
        MessageDefinitionCacheService.getInstance().removeMessageDefinition();
    }

    /**
     * Remove message def.
     *
     * @param keyList the key list
     */
    public void removeMessageDefinition(List<String> keyList) {
        MessageDefinitionCacheService.getInstance().removeMessageDefinition(keyList);
    }

    /**
     * Remove message def.
     *
     * @param keyList the key list
     * @param envInfo the env info
     */
    public void removeMessageDefinition(List<String> keyList, EnvironmentDetailsEntity envInfo) {
        MessageDefinitionCacheService.getInstance().removeMessageDefinition(keyList, envInfo);
    }

    /**
     * Remove tenant user data.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     */
    public void removeTenantUserData(String userId, String tenantId) {
        ApplicationConfigurationCacheService.getInstance().removeTenantUserData(userId, tenantId);
        CacheService.getInstance().removeCacheByKey(CacheKeyHelper.getUserPreferenceRandomKey(tenantId, userId));
    }

    /**
     * Remove product tenant config.
     *
     * @param productCode the product code
     */
    public void removeProductTenantConfig(String productCode) {
        ApplicationConfigurationCacheService.getInstance().removeProductTenantConfig(productCode);
    }

    /**
     * Remove users.
     *
     * @param userIdList the user id list
     */
    public void removeUsers(List<Object> userIdList) {
        ApplicationConfigurationCacheService.getInstance().removeUsers(userIdList);
    }

    /**
     * Remove locale.
     */
    public void removeLocale() {
        LocaleCacheService.getInstance().removeLocale();
    }

    /**
     * Update product redis data.
     *
     * @param cacheKey   the cache key
     * @param cacheValue the cache value
     */
    public void updateProductRedisData(String cacheKey, Object cacheValue) {
        CommonCacheService.getInstance().updateProductRedisData(cacheKey, cacheValue);
    }

    /**
     * Gets product redis data.
     *
     * @param cacheKey the cache key
     * @return the product redis data
     */
    public Object getProductRedisData(String cacheKey) {
        return CommonCacheService.getInstance().getProductRedisData(cacheKey);
    }
    
    /**
     * Gets client info redis data.
     *
     * @param cacheKey the cache key
     * @return the client redis data
     */
    public Map<String,Object> getClientInfoDetails(String clientId) throws QueryException{
    	return ApplicationConfigurationCacheService.getInstance().getClientInfoDetails(clientId);
    }
    
    /**
     * Gets client ip redis data.
     *
     * @param cacheKey the cache key
     * @return the client ip redis data
     */
    public Map<String, Map<String, Object>> getClientIpDetails(String cacheKey) throws QueryException{
    	return ApplicationConfigurationCacheService.getInstance().getClientIpDetails(cacheKey);
    }
    
    /**
     * Get application text definition data object.
     *
     * @param screenDefId the screen def id
     * @return the object
     * @throws QueryException the query exception
     */
    public Map<String, MessageDefinitionEntity> getApplicationMessageData(String screenDefId) throws QueryException {
        String cacheKey = CacheKeyHelper.getApplicationMessageKey(screenDefId,ContextBean.getLocale());
        return MessageDefinitionCacheService.getInstance().getApplicationMessageData(screenDefId,cacheKey);
    }

    /**
     * Update application message data.
     *
     * @param screenDefId the screen def id
     * @throws QueryException the query exception
     */
    public void updateApplicationMessageData(String screenDefId) throws QueryException {
    	MessageDefinitionCacheService.getInstance().updateApplicationMessageData(screenDefId);
    }
    
    /**
     * Removes the application message data.
     *
     * @param screenDefId the screen def id
     */
    public void removeApplicationMessageData(String screenDefId) {
    	MessageDefinitionCacheService.getInstance().removeApplicationMessageData(screenDefId);
    }
    
    /**
     * Removes the application message data.
     *
     * @param screenDefId the screen def id
     */
    public void removeApplicationMessageData(List<String> screenDefIdList) {
    	MessageDefinitionCacheService messageDefinitionCacheService = MessageDefinitionCacheService.getInstance();
    	screenDefIdList.forEach(screenDefId -> messageDefinitionCacheService.removeApplicationMessageData(screenDefId));
    }
    /**
     * Get application text definition data object.
     *
     * @param screenDefId the screen def id
     * @param messageId the message id
     * @param locale the locale
     * @return the object
     * @throws QueryException the query exception
     */
    public MessageDefinitionEntity getApplicationMessageData(String screenDefId,String  messageId,String locale) throws QueryException {
    	String cacheKey = CacheKeyHelper.getApplicationMessageKey(screenDefId,locale);
    	Map<String, MessageDefinitionEntity> messageMap = MessageDefinitionCacheService.getInstance().getApplicationMessageData(screenDefId,cacheKey);
    	if(messageMap.containsKey(messageId)) {
    		return messageMap.get(messageId);
    	}else {
    		return null;
    	}
    }

	/**
	 * getUserFavouritesByTenantAndUserId is used to get user info by tenant and
	 * user id.
	 * 
	 * @param userId
	 * @param tenantId
	 * @return
	 * @throws QueryException
	 */
	public List<Object> getUserFavouritesByTenantAndUserId() throws QueryException {
		String cacheKey = CacheKeyHelper.getUserFavouritesMenuKey(ContextBean.getTenantId(), ContextBean.getUserId());
		return UserMenuCacheService.getInstance().getUserFavouritesByTenantAndUserId(cacheKey);
	}

	/**
	 * getUserRecentsByTenantAndUserId is used to get user info by tenant and user
	 * id.
	 * 
	 * @param userId
	 * @param tenantId
	 * @return
	 * @throws QueryException
	 */
	public List<Object> getUserRecentsByTenantAndUserId() throws QueryException {
		String cacheKey = CacheKeyHelper.getUserRecentsMenuKey(ContextBean.getTenantId(), ContextBean.getUserId());
		return UserMenuCacheService.getInstance().getUserRecentsByTenantAndUserId(cacheKey);
	}

	/**
	 * getUserFullAuthorityMenuData is used to get full authority user menu data.
	 * @param tenantId 
	 * 
	 * @param userId
	 * @param tenantId
	 * @return
	 * @throws QueryException
	 */
	public Map<String, Object> getUserFullAuthorityMenuData(String authority, String locale, String tenantId, List<String> roleList) throws QueryException {
		String cacheKey = CacheKeyHelper.getAuthorityMenuKey(authority.concat("_User"), locale, tenantId);
		return UserMenuCacheService.getInstance().getUserFullAuthorityMenuData(cacheKey, authority, locale, roleList, tenantId);
	}

	/**
	 * getUserAdminAuthorityMenuData is used to get user admin menu data
	 * 
	 * @param userId
	 * @param tenantId
	 * @return
	 * @throws QueryException
	 */
	public Map<String, Object> getUserAdminAuthorityMenuData(String authority, String locale, String tenantId) throws QueryException {
		String cacheKey = CacheKeyHelper.getAuthorityMenuKey(authority, locale, tenantId);
		return UserMenuCacheService.getInstance().getUserAdminAuthorityMenuData(cacheKey, authority, locale);
	}

	/**
	 * getUserRoleAuthorityMenuData is used to get the role level data.
	 * 
	 * @param role
	 * @param roleList
	 * @return
	 */
	public Map<String, Object> getUserRoleAuthorityMenuData(List<String> roleList, String locale, String tenantId) {
		return UserMenuCacheService.getInstance().getUserRoleAuthorityMenuDataFetch(roleList, locale, tenantId);
	}
	
	/**
	 * getPaymentGatewayDetails is used to get the latest payment gateway details
	 * based on product_code, payment_type and handler_type
	 * 
	 * @param productCode the product_code
	 * @param paymentType the payment_type if 0: All; 1: Credit Card; 2: Debit Card;
	 *                    3: UPI; 4: Internet Banking
	 * @param handlerType the handler_type as "primary" || "secondary"
	 * @return Map
	 */
	public Map<String, Object> getPaymentGatewayDetails(String productCode, Integer paymentType, String handlerType)
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPaymentGatewayKey(productCode, String.valueOf(paymentType));
		return PaymentGatewayCacheService.getInstance().getPaymentGateWayDetails(cacheKey, productCode, paymentType,
				handlerType);
	}
	
	/**
	 * getPaymentGatewayDetails is used to get the latest payment gateway details
	 * based on product_code, gateway_id
	 * 
	 * @param productCode the product_code
	 * @param paymentType the payment_type if 0: All; 1: Credit Card; 2: Debit Card;
	 *                    3: UPI; 4: Internet Banking
	 * @param gatewayId   the gateway_id
	 * @return Map
	 */
	public Map<String, Object> getPaymentGatewayDetails(String productCode, String paymentType, String gatewayId)
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPaymentGatewayKey(productCode, String.join(":", paymentType, gatewayId));
		return PaymentGatewayCacheService.getInstance().getPaymentGateWayDetails(cacheKey, productCode, paymentType,
				gatewayId);
	}
	
	/**
	 * getPgwDetails is used to get the payment gateway details
	 * @param gatewayId   the gateway_id
	 * @return Map
	 */
	public Map<String, Object> getPgwDetails(String gatewayId)
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPgwDetailsKey();
		return PaymentGatewayCacheService.getInstance().getPgwDetails(cacheKey, gatewayId);
	}
	
	/**
	 * getPgwTransactionTypeDetails is used to get the Transaction Type Details.
	 * 
	 * @return Map
	 */
	public Map<Integer, String> getPgwTransactionTypeDetails()
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPgwTransactionTypeKey();
		return PaymentGatewayCacheService.getInstance().getPgwTransactionTypeDetails(cacheKey);
	}
	
	/**
	 * getPgwCallbackDetails is used to get the callback details for payment gateway
	 * service.
	 * 
	 * @param productCode the product code
	 * @return Map
	 */
	public List<Map<String, Object>> getPgwCallbackDetails(String productCode, String paymentMethod)
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPgwCallbackDetailsKey(productCode, paymentMethod);
		return PaymentGatewayCacheService.getInstance().getPgwCallbackDetails(cacheKey, productCode, paymentMethod);
	}
	
	/**
	 * getPgwTransactionStatusDetails is used to get the Transaction status Details.
	 * 
	 * @return Map
	 */
	public Map<Integer, String> getPgwTransactionStatusDetails()
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPgwTransactionStatusKey();
		return PaymentGatewayCacheService.getInstance().getPgwTransactionStatusDetails(cacheKey);
	}
	
	/**
	 * getPgwOrganisationDetails is used to get the Organisation Details.
	 * 
	 * @return Map
	 */
	public Map<String, String> getPgwOrganisationDetails()
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPgwGatewayName();
		return PaymentGatewayCacheService.getInstance().getPgwOrganisationDetails(cacheKey);
	}
	
	/**
	 * getPaymentGatewayErrorMessage is used to get the error message details of the
	 * payment gateway based on product_code, gateway_code and locale
	 * 
	 * @param productCode the product_code
	 * @param gatewayCode the gateway_code from gateway organisation
	 * @param locale      current user locale
	 * @return Map
	 */
	public Map<String, Map<String, Object>> getPaymentGatewayErrorMessage(String productCode, String gatewayCode,
			String locale) {
		boolean inProductCache = true;
		/** If Product is Empty or null it means Gateway cache else Product cache */
		if (StringUtils.isEmpty(productCode)) {
			inProductCache = false;
			productCode = StringUtils.EMPTY;
		}
		String cacheKey = CacheKeyHelper.getPaymentGatewayErrorKey(inProductCache, productCode, gatewayCode);
		return PaymentGatewayCacheService.getInstance().getPaymentGateWayErrorMessageDetails(cacheKey, productCode,
				gatewayCode, locale, inProductCache);
	}

	/**
	 * To remove the payment gateway by product_code and payment_type based on
	 * product_code, payment_type
	 * 
	 * @param productCode the product_code
	 * @param paymentType the payment_type if 0: All; 1: Credit Card; 2: Debit Card;
	 *                    3: UPI; 4: Internet Banking
	 */
	public void removePaymentGatewayDetails(String productCode, Integer paymentType) {
		String cacheKey = CacheKeyHelper.getPaymentGatewayKey(productCode, String.valueOf(paymentType));
		CommonCacheService.getInstance().removeCacheByKey(cacheKey);
	}
	
	/**
	 * getClientCode method used to get client code based on tenant
	 * 
	 * @return clientCode
	 * @throws QueryException 
	 * @throws CustomException 
	 */
	public String getClientCode() throws QueryException, CustomException {
		List<Map<String,Object>> getTenantList = getTenantConfigurationData();
		if(getTenantList.isEmpty()) {
			throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured_independent"));
		}else {
		Map<Object, List<Map<String, Object>>> tenantMap = getTenantList.stream().collect(Collectors.groupingBy(mapper -> String.valueOf(mapper.get("tenant_id"))));
		if(tenantMap.containsKey(ContextBean.getTenantId())) {
			boolean independentFlag =Objects.nonNull( tenantMap.get(ContextBean.getTenantId()).get(0).get("independent_tenant_flag")) ? (boolean)(tenantMap.get(ContextBean.getTenantId()).get(0).get("independent_tenant_flag")) : false;
			if(independentFlag) {
				if(Objects.nonNull(tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code")) && !tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code").toString().isEmpty())
				return String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code"));
				else
					throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured"));
			}else {
				if(Objects.nonNull(tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code")) && !tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code").toString().isEmpty()) {
					return String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code"));
				}else {
				Map<String, Object> getPropertyMap = CacheGetServiceImpl.getInstance().getConfigurationProperty();
				if(Objects.isNull(getPropertyMap.get("client_code"))){
				     throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured_independent"));
				}else{
				    return getPropertyMap.get("client_code").toString();
				}

			}
			}
		}else {
			 throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured_independent"));
		}
		}
		
	}
	/**
	 * getClientCodeWithUnderScore method used to get client code based on tenant
	 * @return clientCode
	 * @throws QueryException 
	 * @throws CustomException 
	 */
	public String getClientCodeWithUnderScore() throws QueryException, CustomException {
		List<Map<String,Object>> getTenantList = getTenantConfigurationData();
		if(getTenantList.isEmpty()) {
			throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured_independent"));
		}else {
		Map<Object, List<Map<String, Object>>> tenantMap = getTenantList.stream().collect(Collectors.groupingBy(mapper -> String.valueOf(mapper.get("tenant_id"))));
		if(tenantMap.containsKey(ContextBean.getTenantId())) {
			boolean independentFlag =Objects.nonNull( tenantMap.get(ContextBean.getTenantId()).get(0).get("independent_tenant_flag")) ? (boolean)(tenantMap.get(ContextBean.getTenantId()).get(0).get("independent_tenant_flag")) : false;
			if(independentFlag) {
				if(Objects.isNull(tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code"))) {
					throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured"));
				}else if(String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code")).endsWith("_")) {
					return String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code"));
				}else {
					return String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code")).concat("_");
				}
			}else {
				if(Objects.nonNull(tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code")) && !tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code").toString().isEmpty()) {
					if(tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code").toString().endsWith("_")) {
					return String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code"));
					}
					else {
						return String.valueOf( tenantMap.get(ContextBean.getTenantId()).get(0).get("client_code")).concat("_");
					}
				}else {
				Map<String, Object> getPropertyMap = CacheGetServiceImpl.getInstance().getConfigurationProperty();
				if(Objects.isNull(getPropertyMap.get("client_code"))){
					throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured_independent"));
				}else if(getPropertyMap.get("client_code").toString().endsWith("_")){
				    return getPropertyMap.get("client_code").toString();
				}else{
				    return getPropertyMap.get("client_code").toString().concat("_");
				}
				}
			}
		}else {
			throw new CustomException(getClientCodeErrorMsg("nn_framework_common_client_code_not_configured_independent"));
		}
		}
		
	}
	/**
	 * getClientCodeErrorMsg used to get client code error message
	 * @param errorKey
	 * @return message
	 */
	public String getClientCodeErrorMsg(String errorKey) {
		Map<String,List<String>> errorMap = new HashMap<>();
		errorMap.put(errorKey,null);
		  Map<String, String> errorMessage = QueryUtils.getBtTextWithParam(Arrays.asList(errorKey),
				errorMap, ContextBean.getLocale(),"sova_core");
		  if(errorMessage.isEmpty()) {
			  return StringUtils.EMPTY;
		  }else {
			  return errorMessage.get(errorKey);
		  }
	}
	/**
	 * getAutonumber tenant data 
	 * 
	 * @return map
	 * @throws QueryException 
	 */
	public Map<String,Object> getAutonumberTenantData(String autonumber, String tenantId) throws QueryException{
		String cacheKey = CacheKeyHelper.getAutoumberigTenantDefinitionKey();
		 return ApplicationConfigurationCacheService.getInstance().getAutoumberTenantConfigurationData(cacheKey,autonumber,tenantId);
	}
	
	
	public Set<String> getServiceAccessList(String screenDefId) throws QueryException{
		ScreenDefinitionCacheService screenDefinitionCacheService = ScreenDefinitionCacheService.getInstance();
		return screenDefinitionCacheService.getServiceAccessList(screenDefId);
	}
	

	public List<Map<String, Object>> getUserIpRangeDetails(String cacheKey) throws QueryException{
		return ApplicationConfigurationCacheService.getInstance().getUserIpRangeDetails(cacheKey);
	}
	
	
	public Map<String, Object> getClientIpAccessLimit(String clientId) throws QueryException{
		return ApplicationConfigurationCacheService.getInstance().getClientIpAccessLimit(clientId);
	}
	
	
	public Map<String, Object> getClientURLAccessLimit(String clientId) throws QueryException{
		return ApplicationConfigurationCacheService.getInstance().getClientURLAccessLimit(clientId);
	}
	
	/**
	 * getPaymentGatewayErrorItem is used to get the error item details of the payment gateway
	 * based on gateway_code and locale
	 * 
	 * @param gatewayCode the gateway_code from gateway organisation
	 * @param locale current user locale
	 * @return Map
	 */
	public Map<String, String> getPaymentGatewayErrorItem(String gatewayCode, String locale)
			throws QueryException {
		String cacheKey = CacheKeyHelper.getPaymentGatewayErrorItemKey(gatewayCode);
		return PaymentGatewayCacheService.getInstance().getPaymentGateWayErrorItemDetails(cacheKey,gatewayCode,
				locale);
	}

	/**
	 * getTemplateData is used to get full the template data
	 * 
	 * @param themeCode
	 * @return
	 * @throws QueryException
	 */
	public Map<String, Object> getTemplateData(String themeCode) {
		String cacheKey = CacheKeyHelper.getTenantThemeKey(ContextBean.getTenantId(), themeCode);
		return UserMenuCacheService.getInstance().getTemplateData(cacheKey, themeCode);
	}
	
	/**
	 *  getUserScreenIniData is used to get the user screen ini data
	 * @param tenantId
	 * @param userId
	 * @param sid
	 * @return
	 */
	public List<Map<String, Object>> getUserScreenIniData(String tenantId, String userId, String sid) {
		String cacheKey = CacheKeyHelper.getScreenIniKey(tenantId,userId,sid);
		return UserMenuCacheService.getInstance().getScreenIniData(cacheKey);
	}
	
	/**
	 * getPaymentGatewayConfiguration used for getting the payment gateway configuration from DB
	 * 
	 * @return Map
	 */
	public Map<String, Object> getPaymentGatewayConfiguration() {
		String cacheKey = CacheKeyHelper.getPaymentGatewayConfigKey();
		return PaymentGatewayCacheService.getInstance().getPaymentGateWayConfiguration(cacheKey);
	}
	
	/**
	 * getProgramNameByApiUrl used for getting the program Name for the given API URL
	 * 
	 * @return String
	 */
	public String getProgramNameByApiUrl(String apiUrl, String productCode, String subProductCode) throws QueryException {
		return ScreenConfigurationCacheService.getInstance().getProgramNameByApiUrl(apiUrl, productCode, subProductCode);
	}
	
	/**
	 * getAutonumber tenant data 
	 * @param tableName 
	 * @param productCode 
	 * 
	 * @return map
	 * @throws QueryException 
	 */
	public Map<String,Object> getCurrentAutonumberData(String autonumberDefId,String tenantId, String productCode, String tableName) throws QueryException{
		String cacheKey = CacheKeyHelper.getAutoumberCurrentDataKey(autonumberDefId,productCode,tableName);
		 return ApplicationConfigurationCacheService.getInstance().getCurrentAutonumberData(cacheKey,autonumberDefId,tenantId,productCode,tableName);
	}
	
	/**
	 * getAutonumber tenant data 
	 * 
	 * @return map
	 * @throws QueryException 
	 */
	public void updateCurrentAutonumberData(String autonumberDefId,String tenantId, Map<String, Object> updatedAutoNumberMap, String productCode, String tableName) throws QueryException{
		String cacheKey = CacheKeyHelper.getAutoumberCurrentDataKey(autonumberDefId,productCode,tableName);
		ApplicationConfigurationCacheService.getInstance().updateCurrentAutonumberData(cacheKey,autonumberDefId,tenantId,updatedAutoNumberMap,productCode,tableName);
	}
	
	/**
     * Remove users.
     *
     * @param userIdList the user id list
     */
    public void removeCurrentAutonumberData(String autonumberDefId,String tenantId, String productCode, String tableName) {
    	String cacheKey = CacheKeyHelper.getAutoumberCurrentDataKey(autonumberDefId,productCode,tableName);
        ApplicationConfigurationCacheService.getInstance().removeCurrentAutonumberData(cacheKey,autonumberDefId,tenantId);
    }
    

	/**
	 * getProductCodeTemplateData is used to get the product code template data.
	 * 
	 * @param productCode
	 * @param tenantId
	 * @return
	 */
	public Map<String, Object> getProductCodeTemplateData(String productCode, String tenantId) {
		String cacheKey = CacheKeyHelper.getUserThemeKey(tenantId, productCode);
		return UserMenuCacheService.getInstance().getProductCodeTemplateData(cacheKey, tenantId, productCode);
	}
	
	/**
	 * getDefaultTemplateData is used to get the default template data.
	 * 
	 * @return
	 */
	public Map<String, Object> getDefaultTemplateData() {
		String cacheKey = CacheKeyHelper.getUserThemeKey(ContextBean.getTenantId(), "default_template");
		return UserMenuCacheService.getInstance().getDefaultTemplateData(cacheKey);
	}
	
	/**
	 * get TemplateCacheData is used to get the template data.
	 * 
	 * @param themeCode 
	 * @return 
	 */
	public Map<String, Object> getTemplateCacheData(String themeCode) {
		Map<String, Object> templateData = getTemplateData(themeCode);
		if (MapUtils.isEmpty(templateData)) {
			// get tenant based theme.
			// currently product based theme is not supported . So product is hardcoded as EMPTY.
			logger.info("Loading theme based on tenant - {}", ContextBean.getTenantId());
			templateData = getProductCodeTemplateData("sova_def", ContextBean.getTenantId());
		}
		if (MapUtils.isEmpty(templateData)) {
			// if tenant based theme is not found. 
			// get sova theme .
			logger.info("Theme not found for tenant {} , so loading default sova theme", ContextBean.getTenantId());
			templateData = getProductCodeTemplateData("sova_def", "sova");
		}
		if (MapUtils.isEmpty(templateData)) {
			// get default theme available in theme_detail where theme_code='sova'
			logger.info("loading default theme from theme_details theme-code {}", "sova");
			templateData = getDefaultTemplateData();
		}
		return templateData;
	}
	
	/*
	 * gets the lms system def for the current system id
	 * 
	 * @return
	 */
	public Map<String, Object> getLmsSystemDef() {
		return LmsSystemDefCacheService.INSTANCE.getLmsSystemDef(EnvironmentReader.getSystemId());
	}
}
