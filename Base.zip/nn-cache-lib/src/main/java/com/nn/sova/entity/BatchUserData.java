package com.nn.sova.entity;

import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * Represents the default user with user_id = 'batchUser'.
 */
@Data
@EqualsAndHashCode(callSuper = true)
public final class BatchUserData extends HashMap<String, Object> {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Constant USER_ID. */
	private static final String USER_ID = "batchUser";

	/** The Constant COL_USER_ID. */
	// do not directly use this columns, if needed add methods and access it
	private static final String COL_USER_ID = "user_id";

	/** The Constant COL_TENANT_ID. */
	private static final String COL_TENANT_ID = "tenant_id";

	/** The Constant COL_API_TOKEN. */
	private static final String COL_API_TOKEN = "api_token";

	/** The Constant COL_LOCALE. */
	private static final String COL_LOCALE = "user_locale";

	/** The Constant COL_TIME_ZONE. */
	private static final String COL_TIME_ZONE = "time_zone";

	/** The Constant COL_DATE_FORMAT. */
	private static final String COL_DATE_FORMAT = "date_format";

	/** The Constant COL_TIME_FORMAT. */
	private static final String COL_TIME_FORMAT = "time_format";

	/**
	 * Instantiates a new batch user data.
	 *
	 * @param batchUserDataMap the batch user data map
	 */
	private BatchUserData(Map<String, Object> batchUserDataMap) {
		super(batchUserDataMap);
		// validation - tenantId, userId, apiToken must be non-null
		getTenantId();
		getUserId();
		getApiToken();
	}

	/**
	 * Gets the user details.
	 *
	 * @param tenantId the tenant id
	 * @param userId   the user id
	 * @return the user details
	 * @throws QueryException the query exception
	 */
	private static BatchUserData getUserDetails(String tenantId, String userId)
		throws BatchUserDataAccessException {
		try {
			Map<String, Object> batchUserDataMap = CacheService.getInstance()
				.getUserDataByTenantId(userId, tenantId);
			if (isEmpty(batchUserDataMap)) {
				throw new BatchUserDataAccessException(
					"User data not available for tenant_id : "
						+ tenantId
						+ ", user_id : "
						+ userId);
			}
			return new BatchUserData(batchUserDataMap);
		} catch (QueryException cause) {
			throw new BatchUserDataAccessException(cause);
		}
	}

	/**
	 * Gets the string or throw.
	 *
	 * @param columnName   the column name
	 * @param defaultValue the default value
	 * @return the string or throw
	 */
	private String getStringOrThrow(String columnName, String defaultValue) {
		String stringValue = StringUtils.trimToEmpty(
			Objects.toString(this.get(columnName), defaultValue));
		if (StringUtils.isEmpty(stringValue)) {
			throw new InvalidParameterException(columnName
				+ " column must be non-null and not-empty");
		}
		return stringValue;
	}

	/**
	 * Gets the or throw.
	 *
	 * @param <T>          the generic type
	 * @param columnName   the column name
	 * @param defaultValue the default value
	 * @return the or throw
	 */
	@SuppressWarnings("unchecked")
	private <T> T getOrThrow(String columnName, T defaultValue) {
		return (T)this.getOrDefault(columnName, defaultValue);
	}

	/**
	 * Gets the default value.
	 *
	 * @param tenantId the tenant id
	 * @return the default value
	 * @throws QueryException               the query exception
	 * @throws BatchUserDataAccessException
	 */
	public static BatchUserData getDefaultValue(String tenantId)
		throws BatchUserDataAccessException {
		return BatchUserData.getUserDetails(tenantId, USER_ID);
	}

	/**
	 * Gets the inits the value.
	 *
	 * @param tenantId the tenant id
	 * @param userId   the user id
	 * @return the inits the value
	 * @throws QueryException the query exception
	 */
	public static BatchUserData getInitValue(String tenantId, String userId)
		throws BatchUserDataAccessException {
		return BatchUserData.getUserDetails(tenantId, userId);
	}

	/**
	 * Gets the tenant id.
	 *
	 * @return the tenant id
	 */
	public String getTenantId() {
		return this.getStringOrThrow(COL_TENANT_ID, null);
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return this.getStringOrThrow(COL_USER_ID, null);
	}

	/**
	 * Gets the api token.
	 *
	 * @return the api token
	 */
	public String getApiToken() {
		return this.getStringOrThrow(COL_API_TOKEN, null);
	}

	/**
	 * Gets the locale.
	 *
	 * @return the locale
	 */
	public String getLocale() {
		return this.getStringOrThrow(COL_LOCALE, null);
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return this.getStringOrThrow(COL_TIME_ZONE, null);
	}

	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return this.getStringOrThrow(COL_DATE_FORMAT, null);
	}

	/**
	 * Gets the time format.
	 *
	 * @return the time format
	 */
	public String getTimeFormat() {
		return this.getStringOrThrow(COL_TIME_FORMAT, null);
	}

	/**
	 * Gets the value.
	 *
	 * @param <T>          the generic type
	 * @param columnName   the column name
	 * @param defaultValue the default value
	 * @return the value
	 */
	public <T> T getValue(String columnName, T defaultValue) {
		return this.getOrThrow(columnName, defaultValue);
	}

	/**
	 * Gets the string value.
	 *
	 * @param columnName   the column name
	 * @param defaultValue the default value
	 * @return the string value
	 */
	public String getStringValue(String columnName, String defaultValue) {
		return this.getOrThrow(columnName, defaultValue);
	}

	/**
	 * Checks if is empty.
	 *
	 * @param <K>  the key type
	 * @param <V>  the value type
	 * @param data the data
	 * @return true, if is empty
	 */
	public static <K, V> boolean isEmpty(Map<K, V> data) {
		return data == null || data.isEmpty();
	}

	/**
	 * The Class BatchUserDataAccessException.
	 */
	public static class BatchUserDataAccessException extends Exception {

		/** The Constant serialVersionUID. */
		private static final long serialVersionUID = 1L;

		/**
		 * Instantiates a new batch user data access exception.
		 *
		 * @param message the message
		 */
		public BatchUserDataAccessException(String message) {
			super(message);
		}

		/**
		 * Instantiates a new batch user data access exception.
		 *
		 * @param throwable the throwable
		 */
		public BatchUserDataAccessException(Throwable throwable) {
			super(throwable.getMessage(), throwable);
		}

	}

}
