package com.nn.sova.entity;

import lombok.Data;


/**
 * Instantiates a new service restriction entity.
 */
@Data
public class ServiceRestrictionEntity {

	/** The screen def id. */
	private String screenDefId;
	
	/** The accessibl service def id. */
	private String accessiblServiceDefId;
	
	/** The tenant id. */
	private String tenantId;
	
	/** The accessibl screen url. */
	private String accessiblScreenUrl;
	
	/** The accessible mapping url. */
	private String accessibleMappingUrl;
}
