package com.nn.sova.key;

import com.nn.sova.utility.context.ContextBean;

/**
 * The type Cache key helper.
 *
 * @author Anand Kumar
 */
public class CacheKeyHelper {
    /**
     * Instantiates a new Cache key helper.
     */
    CacheKeyHelper(){

    }
    /**
     * The constant defaultPrefix.
     */
    private static final String defaultPrefix = "sova_core";
    /**
     * The constant DELIMITER.
     */
    public static final String DELIMITER = ":";
    /**
     * The constant TEXT_DEFINITION.
     */
    private static final String TEXT_DEFINITION = "text_definition";
    /**
     * The constant PAYMENT_GATEWAY.
     */
    private static final String PAYMENT_GATEWAY = "payment_gateway";
    /**
     * The constant prefix.
     */
    private static String prefix = null;

    /**
     * Gets prefix.
     *
     * @return the prefix
     */
    public static String getPrefix() {
        if(prefix != null) {
            return prefix;
        }
        return defaultPrefix;
    }

    /**
     * Sets prefix.
     *
     * @param keyPrefix the key prefix
     */
    public static void setPrefix(String keyPrefix) {
        prefix = keyPrefix;
    }

    /**
     * Gets key.
     *
     * @param key the key
     * @return the key
     */
    public static String getKey(String key) {
        return getPrefix() + ':' + key;
    }

    /**
     * Gets active lang code key.
     *
     * @return the active lang code key
     */
    public static String getActiveLangCodeKeyPrefix() {
        return getKey("active_lang_code").concat(DELIMITER).concat("all_locale");
    }

    /**
     * Gets active lang code by locale key.
     *
     * @param locale the locale
     * @return the active lang code by locale key
     */
    public static String getActiveLangCodeByLocaleKey(String locale) {
        return getKey(String.join(DELIMITER, "active_lang_code", locale));
    }

    /**
     * Gets locale key.
     *
     * @return the locale key
     */
    public static String getLocaleKey() {
        return getKey("locale:information");
    }

    /**
     * Gets screen data element key.
     *
     * @param screenId the screen id
     * @return the screen data element key
     */
    public static String getScreenDataElementKey(String screenId) {
        return getKey(String.join(DELIMITER, "data_element", screenId));
    }
    
    /**
     * Gets data element based on component definition type.
     *
     * @param componentDefType the component definition type ex: wizard/inputDialog
     * @param key for mapping the data elements
     * @return the Component data element key
     */
    public static String getCompDataElementKey(String componentDefType, String key) {
        return getKey(String.join(DELIMITER, "data_element", componentDefType, key));
    }

    /**
     * Gets screen data element prefix key.
     *
     * @return the screen data element prefix key
     */
    public static String getScreenDataElementPrefixKey() {
        return getKey(String.join(DELIMITER, "data_element")).concat(DELIMITER);
    }

    /**
     * Gets app gen screen data element key.
     *
     * @return the app gen screen data element key
     */
    public static String getAppGenScreenDataElementKey() {
        return getKey("app_gen_data_element");
    }

    /**
     * Gets server side validation key.
     *
     * @param tableName the table name
     * @return the server side validation key
     */
    public static String getServerSideValidationKey(String tableName) {
        return getKey(String.join(DELIMITER, "server_side_validation", tableName));
    }

    /**
     * Gets server side validation prefix key.
     *
     * @return the server side validation prefix key
     */
    public static String getServerSideValidationPrefixKey() {
        return getKey(String.join(DELIMITER, "server_side_validation")).concat(DELIMITER);
    }

    /**
     * Gets server side validation encryption prefix key.
     *
     * @return the server side validation encryption prefix key
     */
    public static String getServerSideValidationEncryptionPrefixKey() {
        return getKey(String.join(DELIMITER, "server_side_validation_encrypt")).concat(DELIMITER);
    }

    /**
     * Gets table configuration prefix key.
     *
     * @return the table configuration prefix key
     */
    public static String getTableConfigurationPrefixKey() {
        return getKey(String.join(DELIMITER, "table_configuration")).concat(DELIMITER);
    }

    /**
     * Gets view configuration prefix key.
     *
     * @return the view configuration prefix key
     */
    public static String getViewConfigurationPrefixKey() {
        return getKey(String.join(DELIMITER, "view_configuration")).concat(DELIMITER);
    }

    /**
     * Gets text def key.
     *
     * @param productCode the product code
     * @param purpose     the purpose
     * @param locale      the locale
     * @return the text def key
     */
    public static String getTextDefKey(String productCode, String purpose, String locale) {
        return getKey(String.join(DELIMITER, "text_def", productCode, purpose, locale));
    }

    /**
     * Gets screen definition prefix key.
     *
     * @return the screen definition prefix key
     */
    public static String getScreenDefinitionPrefixKey() {
        return getKey(String.join(DELIMITER, "screen_definition")).concat(DELIMITER);
    }

    /**
     * Gets screen definition key.
     *
     * @param screenId the screen id
     * @return the screen definition key
     */
    public static String getScreenDefinitionKey(String screenId) {
        return getKey(String.join(DELIMITER, "screen_definition", screenId));
    }

    /**
     * Gets screen configuration prefix key.
     *
     * @return the screen configuration prefix key
     */
    public static String getScreenConfigurationPrefixKey() {
        return getKey(String.join(DELIMITER, "screen_configuration")).concat(DELIMITER);
    }

    /**
     * Gets screen configuration key.
     *
     * @param screenId the screen id
     * @return the screen configuration key
     */
    public static String getScreenConfigurationKey(String screenId) {
        return getKey(String.join(DELIMITER, "screen_configuration", screenId));
    }

    /**
     * Gets linked screens definition prefix key.
     *
     * @return the linked screens definition prefix key
     */
    public static String getLinkedScreensDefinitionPrefixKey() {
        return getKey(String.join(DELIMITER, "linked_screen_definition")).concat(DELIMITER);
    }

    /**
     * Gets linked screens definition key.
     *
     * @param screenId the screen id
     * @return the linked screens definition key
     */
    public static String getLinkedScreensDefinitionKey(String screenId) {
        return getKey(String.join(DELIMITER, "linked_screen_definition", screenId));
    }

    /**
     * Gets screen component definition prefix key.
     *
     * @return the screen component definition prefix key
     */
    public static String getScreenComponentDefinitionPrefixKey() {
        return getKey(String.join(DELIMITER, "component_definition")).concat(DELIMITER);
    }

    /**
     * Gets screen component definition key.
     *
     * @param screenId the screen id
     * @return the screen component definition key
     */
    public static String getScreenComponentDefinitionkey(String screenId) {
        return getKey(String.join(DELIMITER, "component_definition", screenId));
    }

    /**
     * Gets message definition prefix key.
     *
     * @return the message definition prefix key
     */
    public static String getMessageDefinitionPrefixKey() {
        return getKey(String.join(DELIMITER, "message_definition")).concat(DELIMITER);
    }

    /**
     * Gets message definition key.
     *
     * @param messageId the message id
     * @return the message definition key
     */
    public static String getMessageDefinitionKey(String messageId) {
        return getKey(String.join(DELIMITER, "message_definition", messageId));
    }

    /**
     * Gets text definition application prefix key.
     *
     * @return the text definition application prefix key
     */
    public static String getTextDefinitionApplicationPrefixKey() {
        return getKey(String.join(DELIMITER, TEXT_DEFINITION, "application")).concat(DELIMITER);
    }

    /**
     * Gets text definition application key.
     *
     * @param locale the locale
     * @param screenDefId 
     * @return the text definition application key
     */
    public static String getTextDefinitionApplicationKey(String screenDefId,String locale) {
        return getKey(String.join(DELIMITER, TEXT_DEFINITION, "application", screenDefId, locale));
    }

    /**
     * Gets text definition framework prefix key.
     *
     * @return the text definition framework prefix key
     */
    public static String getTextDefinitionFrameworkPrefixKey() {
        return getKey(String.join(DELIMITER, TEXT_DEFINITION, "framework")).concat(DELIMITER);
    }

    /**
     * Gets text definition framework key.
     *
     * @param textId the text id
     * @return the text definition framework key
     */
    public static String getTextDefinitionFrameworkKey(String locale) {
        return getKey(String.join(DELIMITER, TEXT_DEFINITION, "framework", locale));
    }

    /**
     * Gets class configuration prefix key.
     *
     * @return the class configuration prefix key
     */
    public static String getClassConfigurationPrefixKey() {
        return getKey(String.join(DELIMITER, "class_configuration"));
    }

    /**
     * Gets product by user id key.
     *
     * @param userId the user id
     * @return the product by user id key
     */
    public static String getProductByUserIdKey(String userId) {
        return getKey(String.join(DELIMITER, "product", userId));
    }

    /**
     * Gets product tenant configuration prefix key.
     *
     * @return the product tenant configuration prefix key
     */
    public static String getProductTenantConfigurationPrefixKey() {
        return getKey(String.join(DELIMITER, "product_tenant_configuration")).concat(DELIMITER);
    }

    /**
     * Gets product tenant configuration key.
     *
     * @param productCode the product code
     * @return the product tenant configuration key
     */
    public static String getProductTenantConfigurationKey(String productCode) {
        return getKey(String.join(DELIMITER, "product_tenant_configuration", productCode));
    }

    /**
     * Gets repo configuration key.
     *
     * @return the repo configuration key
     */
    public static String getRepoConfigurationKey() {
        return getKey("repo_configuration");
    }

    /**
     * Gets tenant configuration data key.
     *
     * @return the tenant configuration data key
     */
    public static String getTenantConfigurationDataKey() {
        return getKey("tenant_configuration");
    }
    
    /**
     * Gets tenant definition data key.
     *
     * @return the tenant definition data key
     */
    public static String getTenantDefinitionDataKey() {
        return getKey(String.join(DELIMITER, "tenant_definition", "master"));
    }

    /**
     * Gets tenant user prefix key.
     *
     * @return the tenant user prefix key
     */
    public static String getTenantUserPrefixKey() {
        return getKey(String.join(DELIMITER, "user_infomation")).concat(DELIMITER);
    }

    /**
     * Gets tenant user key.
     *
     * @param tenantId the tenant id
     * @param userId   the user id
     * @return the tenant user key
     */
    public static String getTenantUserKey(String tenantId, String userId) {
        return getKey(String.join(DELIMITER, "user_infomation", tenantId, userId));
    }

    /**
     * Gets authorized screens prefix key.
     *
     * @return the authorized screens prefix key
     */
    public static String getAuthorizedScreensPrefixKey() {
        return getKey(String.join(DELIMITER, "authorized_screens")).concat(DELIMITER);
    }

    /**
     * Gets authorized screens key.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     * @return the authorized screens key
     */
    public static String getAuthorizedScreensKey(String roleId, String tenantId) {
        return getKey(String.join(DELIMITER, "authorized_screens", tenantId, roleId));
    }

    /**
     * Gets role configuration prefix key.
     *
     * @return the role configuration prefix key
     */
    public static String getRoleConfigurationPrefixKey() {
        return getKey(String.join(DELIMITER, "role_information")).concat(DELIMITER);
    }

    /**
     * Gets role configuration key.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     * @return the role configuration key
     */
    public static String getRoleConfigurationKey(String roleId, String tenantId) {
        return getKey(String.join(DELIMITER, "role_information", tenantId, roleId));
    }

    /**
     * Gets roles linked with user id prefix key.
     *
     * @return the roles linked with user id prefix key
     */
    public static String getRolesLinkedWithUserIdPrefixKey() {
        return getKey(String.join(DELIMITER, "role_link")).concat(DELIMITER);
    }

    /**
     * Gets roles linked with user id key.
     *
     * @param userId the user id
     * @return the roles linked with user id key
     */
    public static String getRolesLinkedWithUserIdKey(String userId) {
        return getKey(String.join(DELIMITER, "role_link", userId));
    }

    /**
     * Gets tenant roles linked with user id prefix key.
     *
     * @return the tenant roles linked with user id prefix key
     */
    public static String getTenantRolesLinkedWithUserIdPrefixKey() {
        return getKey(String.join(DELIMITER, "tenant_role_link")).concat(DELIMITER);
    }

    /**
     * Gets tenant roles linked with user id key.
     *
     * @param tenantId the tenant id
     * @param userId   the user id
     * @return the tenant roles linked with user id key
     */
    public static String getTenantRolesLinkedWithUserIdKey(String tenantId, String userId) {
        return getKey(String.join(DELIMITER, "tenant_role_link", tenantId, userId));
    }

    /**
     * Gets screen role link prefix key.
     *
     * @return the screen role link prefix key
     */
    public static String getScreenRoleLinkPrefixKey() {
        return getKey(String.join(DELIMITER, "screens_role_link")).concat(DELIMITER);
    }

    /**
     * Gets screen role link key.
     *
     * @param roleId the role id
     * @return the screen role link key
     */
    public static String getScreenRoleLinkKey(String roleId) {
        return getKey(String.join(DELIMITER, "screens_role_link", roleId));
    }

    /**
     * Gets tenant screen role link prefix key.
     *
     * @return the tenant screen role link prefix key
     */
    public static String getTenantScreenRoleLinkPrefixKey() {
        return getKey(String.join(DELIMITER, "tenant_screens_role_link")).concat(DELIMITER);
    }

    /**
     * Gets tenant screen role link key.
     *
     * @param roleId   the role id
     * @param tenantId the tenant id
     * @return the tenant screen role link key
     */
    public static String getTenantScreenRoleLinkKey(String roleId, String tenantId) {
        return getKey(String.join(DELIMITER, "tenant_screens_role_link", tenantId, roleId));
    }

    /**
     * Gets screen component focus data key.
     *
     * @return the screen component focus data key
     */
    public static String getScreenComponentFocusDataKey() {
        return getKey(String.join(DELIMITER, "component_focus"));
    }

    /**
     * Gets landscape system definition key.
     *
     * @return the landscape system definition key
     */
    public static String getLandscapeSystemDefinitionKey() {
        return getKey(String.join(DELIMITER, "lns_system_definition"));
    }

    /**
     * Gets environment properties key.
     *
     * @return the environment properties key
     */
    public static String getEnvironmentPropertiesKey() {
        return getKey(String.join(DELIMITER, "environment_configuration"));
    }

    /**
     * Gets system settings key.
     *
     * @return the system settings key
     */
    public static String getSystemSettingsKey() {
        return getKey(String.join(DELIMITER, "system_settings"));
    }

    /**
     * Gets drive user space info key.
     *
     * @return the drive user space info key
     */
    public static String getDriveUserSpaceInfoKey() {
        return getKey(String.join(DELIMITER, "drive_file_space_details"));
    }

    /**
     * Gets festival holidays key.
     *
     * @return the festival holidays key
     */
    public static String getFestivalHolidaysKey() {
        return getKey(String.join(DELIMITER, "festival_holidays"));
    }

    /**
     * Gets holiday dates key.
     *
     * @return the holiday dates key
     */
    public static String getHolidayDatesKey() {
        return getKey(String.join(DELIMITER, "holiday_dates"));
    }
    /**
     * getAutoumberigTenantDefinitionKey.
     *
     * @return getAutoumberigTenantDefinitionKey
     */
    public static String getAutoumberigTenantDefinitionKey() {
        return getKey("autonumber_tenant_definition");
    }

    /**
     * Gets countries phone prefix info key.
     *
     * @return the countries phone prefix info key
     */
    public static String getCountriesPhonePrefixInfoKey() {
        return getKey(String.join(DELIMITER, "country_phone_prefix")).concat(DELIMITER);
    }

    /**
     * Gets archive search setting key.
     *
     * @return the archive search setting key
     */
    public static String getArchiveSearchSettingKey() {
        return getKey(String.join(DELIMITER, "archive_search_setting", ContextBean.getTenantId(), ContextBean.getUserId()));
    }

    /**
     * Gets auto numbering prefix key.
     *
     * @return the auto numbering prefix key
     */
    public static String getAutoNumberingPrefixKey() {
        return "sova_autonumbering" + "_";
    }

    /**
     * Gets database handler prefix key.
     *
     * @return the database handler prefix key
     */
    public static String getDatabaseHandlerPrefixKey() {
        return getKey(String.join(DELIMITER, "product_code_handler")).concat(DELIMITER);
    }

    /**
     * Gets user account prefix key.
     *
     * @return the user account prefix key
     */
    public static String getUserAccountPrefixKey() {
        return getKey(String.join(DELIMITER, "user_account_info")).concat(DELIMITER);
    }

    /**
     * Gets roles linked with tenant id prefix key.
     *
     * @return the roles linked with tenant id prefix key
     */
    public static String getRolesLinkedWithTenantIdPrefixKey() {
        return getKey(String.join(DELIMITER, "tenant_roles")).concat(DELIMITER);
    }

	/**
	 * Gets the application message key.
	 *
	 * @param screenDefId the screen def id
	 * @param locale the locale
	 * @return the application message key
	 */
	public static String getApplicationMessageKey(String screenDefId, String locale) {
		 return getKey(String.join(DELIMITER, "message", "application", screenDefId, locale));
	}
	
    /**
     * Gets the application message prefix key.
     *
     * @return the application message prefix key
     */
    public static String getApplicationMessagePrefixKey() {
        return getKey(String.join(DELIMITER, "message", "application")).concat(DELIMITER);
    }


	/**
	 * getUserFavouritesMenu gets the user favourites menu.
	 * 
	 * @param tenantId
	 * @param userId
	 * @return
	 */
	public static String getUserFavouritesMenuKey(String tenantId, String userId) {
		return getIniKey(String.join(DELIMITER, tenantId, userId, "menu_favourites"));
	}

	/**
	 * getUserRecentsMenuKey gets the user recents menu.
	 * 
	 * @param tenantId
	 * @param userId
	 * @return
	 */
	public static String getUserRecentsMenuKey(String tenantId, String userId) {
		return getIniKey(String.join(DELIMITER, tenantId, userId, "menu_recents"));
	}

	/**
	 * getFullAuthorityMenuKey gets the full authority menu data.
	 * 
	 * @param authority
	 * @param locale
	 * @param tenantId 
	 * @return
	 */
	public static String getAuthorityMenuKey(String authority, String locale, String tenantId) {
		return getKey(String.join(DELIMITER, tenantId, authority, locale, "menu"));
	}
	
	/**
	 * getPaymentGatewayKey gets the payment gateway key.
	 * 
	 * @param productCode
	 * @param secondaryName
	 * @return
	 */
	public static String getPaymentGatewayKey(String productCode, String secondaryName) {
		return getKey(String.join(DELIMITER, PAYMENT_GATEWAY, productCode, secondaryName, ContextBean.getTenantId()));
	}
	
	/**
	 * getPgwTransactionTypeKey gets the payment gateway transaction type key.
	 * 
	 * @return
	 */
	public static String getPgwTransactionTypeKey() {
		return getKey(String.join(DELIMITER, PAYMENT_GATEWAY, "transaction_type"));
	}
	
	/**
	 * getPgwDetailsKey gets the payment gateway master key.
	 * 
	 * @return
	 */
	public static String getPgwDetailsKey() {
		return getKey(String.join(DELIMITER, PAYMENT_GATEWAY, "gateway", ContextBean.getTenantId()));
	}
	
	/**
	 * getPgwTransactionTypeKey gets the payment gateway transaction type key.
	 * 
	 * @param productCode
	 * @param paymentMethod
	 * @return
	 */
	public static String getPgwCallbackDetailsKey(String productCode, String paymentMethod) {
		return getKey(String.join(DELIMITER, PAYMENT_GATEWAY, "callback", productCode, paymentMethod, ContextBean.getTenantId()));
	}
	
	/**
	 * getPgwTransactionStatusKey gets the payment gateway transaction status key.
	 * 
	 * @return
	 */
	public static String getPgwTransactionStatusKey() {
		return getKey(String.join(DELIMITER, PAYMENT_GATEWAY, "transaction_status"));
	}
	
	/**
	 * getPgwGatewayName gets the payment gateway gateway name key.
	 * 
	 * @return
	 */
	public static String getPgwGatewayName() {
		return getKey(String.join(DELIMITER, PAYMENT_GATEWAY, "gateway_organisation"));
	}

	/**
	 * Gets key.
	 *
	 * @param key the key
	 * @return the key
	 */
	public static String getIniKey(String key) {
		return getPrefix() + DELIMITER + "ini" + DELIMITER + key;
	}

	/**
	 * getPaymentGatewayErrorKey gets the payment gateway key for error message.
	 * 
	 * @param isProductGateway
	 * @param productCode
	 * @param gatewayCode
	 * @return
	 */
	public static String getPaymentGatewayErrorKey(boolean isProductGateway, String productCode, String gatewayCode) {
		if(isProductGateway) {
			return getKey(String.join(DELIMITER, "payment_gateway_product_error", productCode, gatewayCode, ContextBean.getTenantId()));
		} else {
			return getKey(String.join(DELIMITER, "payment_gateway_error", gatewayCode));
		}	
	}
	
	/**
	 * getPaymentGatewayErrorItemKey gets the payment gateway key for error Item description.
	 * 
	 * @param gatewayCode
	 * @return cache key
	 */
	public static String getPaymentGatewayErrorItemKey(String gatewayCode) {
		return getKey(String.join(DELIMITER, "payment_gateway_error_item", gatewayCode));
	}
	
	/**
	 * getTenantThemeKey gets the user recents menu.
	 * 
	 * @param tenantId
	 * @param themeCode
	 * @return
	 */
	public static String getTenantThemeKey(String tenantId, String themeCode) {
		return getKey(String.join(DELIMITER, tenantId, themeCode, "theme_data"));
	}
	
	/**
	 * getUserRecentsMenuKey gets the user recents menu.
	 * 
	 * @param tenantId
	 * @param userId
	 * @return
	 */
	public static String getUserThemeKey(String tenantId, String userId) {
		return getIniKey(String.join(DELIMITER, tenantId, userId, "theme_data"));
	}
	
	/**
	 * getScreenIniKey is used to get the screen ini key
	 * 
	 * @param tenantId
	 * @param tenantId2
	 * @param sid
	 * @return
	 */
	public static String getScreenIniKey(String tenantId, String userId, String sid) {
		return getIniKey(String.join(DELIMITER, tenantId, userId, sid));
	}
	
	/**
	 * getUserBookmarkKey is used to get the bookmark key
	 * 
	 * @param userId
	 * @param sid 
	 * @return
	 */
	public static String getUserBookmarkKey(String userId, String sid) {
		return getKey(String.join(DELIMITER, "bookmarks", userId, sid));
	}
	
	/**
	 * getPaymentGatewayConfigKey gets the payment gateway gateway configuration key.
	 * 
	 * @return cache key
	 */
	public static String getPaymentGatewayConfigKey() {
		return getKey("payment_gateway_config_setting");
	}
	/**
	 * getProgramNameByApiUrlKey gets the program Name for the given API URL key.
	 * 
	 * @return cache key
	 */
	public static String getProgramNameByApiUrlKey(String apiUrl, String productCode, String subProductCode) {
		return getKey(String.join(DELIMITER, "PGMNAME",productCode , subProductCode ,apiUrl));
	}
	
	/**
	 * getUserPreferenceRandomKey gets the program Name for the given API URL key.
	 * 
	 * @return cache key
	 */
	public static String getUserPreferenceRandomKey(String tenantId, String userId) {
		return getKey(String.join(DELIMITER, tenantId, userId , "user_preference_random_key"));
	}
	
	/**
	 * getUserPreferenceDtataKey gets the program Name for the given API URL key.
	 * 
	 * @return cache key
	 */
	public static String getUserPreferenceDtataKey(String tenantId, String userId) {
		return getKey(String.join(DELIMITER, tenantId, userId , "user_data_cache"));
	}
	
	/**
	 * Gets the autoumber current data key.
	 *
	 * @param autonumberId the autonumber id
	 * @param tableName 
	 * @param productCode 
	 * @return the autoumber current data key
	 */
	public static String getAutoumberCurrentDataKey(String autonumberId, String productCode, String tableName) {
        return getKey(String.join(DELIMITER,"autonumber_current_data",productCode,tableName,autonumberId));
    }
}
