package com.nn.sova.service.common;

import com.nn.sova.core.CacheManager;
import com.nn.sova.entity.RedisEnvInfo;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.utility.logger.ApplicationLogger;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * The type Common cache service.
 *
 * @author Anand Kumar
 */
public class CommonCacheService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(CommonCacheService.class);
    /**
     * The constant instance.
     */
    private static CommonCacheService instance = null;

    /**
     * Instantiates a new Locale cache service.
     */
    private CommonCacheService() {
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static CommonCacheService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new CommonCacheService();
        }
        return instance;
    }

    /**
     * Gets cache data.
     *
     * @param cacheKey the cache key
     * @return the cache data
     */
    public Object getCacheData(String cacheKey) {
        return CacheManager.getInstance().getWithObject(cacheKey);
    }

    /**
     * Gets partial cache keys.
     *
     * @param cacheKey the cache key
     * @return the partial cache keys
     */
    public Set<String> getPartialCacheKeys(String cacheKey) {
        return CacheManager.getInstance().findRedisKeys(cacheKey);
    }

    /**
     * Gets partial cache keys by prefix value.
     *
     * @param prefixCacheKey the prefix cache key
     * @return the partial cache keys by prefix value
     */
    public Set<String> getPartialCacheKeysByPrefixValue(String prefixCacheKey) {
        return CacheManager.getInstance().findPrefixRedisKeys(prefixCacheKey);
    }

    /**
     * Gets partial cache keys by prefix value.
     *
     * @param prefixCacheKey the prefix cache key
     * @param envInfo        the env info
     * @return the partial cache keys by prefix value
     */
    public Set<String> getPartialCacheKeysByPrefixValue(String prefixCacheKey, RedisEnvInfo envInfo) {
        return CacheManager.getInstance().findPrefixRedisKeys(prefixCacheKey, envInfo);
    }

    /**
     * Get ttl by key long.
     *
     * @param cacheKey the cache key
     * @return the long
     */
    public long getTTLByKey(String cacheKey) {
        return CacheManager.getInstance().getTTLByKey(cacheKey);
    }

    /**
     * Remove cache by key.
     *
     * @param cacheKey the cache key
     */
    public void removeCacheByKey(String cacheKey) {
        CacheManager.getInstance().deleteKey(cacheKey);
    }

    /**
     * Remove cache by key.
     *
     * @param cacheKey the cache key
     * @param envInfo  the env info
     */
    public void removeCacheByKey(String cacheKey, RedisEnvInfo envInfo) {
        CacheManager.getInstance().deleteKeyWithEnvInfo(cacheKey, envInfo);
    }

    /**
     * Save to cache.
     *
     * @param cacheKey   the cache key
     * @param cacheValue the cache value
     */
    public void saveToCache(String cacheKey, Object cacheValue) {
        CacheManager.getInstance().saveAsObject(cacheKey, cacheValue);
    }

    /**
     * Save to cache with env info.
     *
     * @param cacheKey      the cache key
     * @param cacheObjValue the cache obj value
     * @param envInfo       the env info
     */
    public void saveToCacheWithEnvInfo(String cacheKey, Object cacheObjValue, RedisEnvInfo envInfo) {
        CacheManager.getInstance().saveAsObjectWithEnvInfo(cacheKey, cacheObjValue, envInfo);
    }

    /**
     * Save to cache with expiration.
     *
     * @param cacheKey      the cache key
     * @param cacheObjValue the cache obj value
     * @param timeUnit      the time unit
     */
    public void saveToCacheWithExpiration(String cacheKey, Object cacheObjValue, int timeUnit) {
        CacheManager.getInstance().saveWithExpiration(cacheKey, cacheObjValue, timeUnit);
    }

    /**
     * Update product redis data.
     *
     * @param cacheKey   the cache key
     * @param cacheValue the cache value
     */
    public void updateProductRedisData(String cacheKey, Object cacheValue) {
        CacheManager.getProductInstance().saveAsObject(cacheKey, cacheValue);
    }

    /**
     * Gets product redis data.
     *
     * @param cacheKey the cache key
     * @return the product redis data
     */
    public Object getProductRedisData(String cacheKey) {
        return CacheManager.getProductInstance().getWithObject(cacheKey);
    }

    /**
     * Removes the application message data.
     *
     * @param tableNameList the table name list
     */
    public static void removeTableValidationData(List<String> tableNameList) {
    	Set<String> keyList = new HashSet<>();
    	tableNameList.stream().forEach(tableName->{
    		keyList.add("sova_"+tableName);
    		keyList.add("sova_tableConfig_"+tableName);
    		keyList.add("sova_viewConfig_"+tableName);
    		keyList.add("sova_encrypt_"+tableName);
    	});
    	CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }
    /**
     * Removes the application message data.
     *
     * @param tableNameList the table name list
     * @param productCode 
     */
    public static void removeTableValidationData(List<String> tableNameList, String productCode) {
    	Set<String> keyList = new HashSet<>();
    	tableNameList.stream().forEach(tableName->{
    		keyList.add("sova_"+productCode+"_"+tableName);
    		keyList.add("sova_tableConfig_"+productCode+"_"+tableName);
    		keyList.add("sova_viewConfig_"+productCode+"_"+tableName);
    		keyList.add("sova_encrypt_"+productCode+"_"+tableName);
    	});
    	CacheManager.getInstance().del(keyList.toArray(new String[keyList.size()]));
    }
}
