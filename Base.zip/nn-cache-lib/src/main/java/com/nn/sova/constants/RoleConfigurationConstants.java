package com.nn.sova.constants;

/**
 * The type Role configuration constants.
 *
 * @author Anand Kumar
 */
public class RoleConfigurationConstants {
    /**
     * Instantiates a new Role configuration constants.
     */
    RoleConfigurationConstants(){

    }
    /**
     * The constant TENANT_ID_DB_COL.
     */
    public static final String TENANT_ID_DB_COL = "roleSetting.tenantId";
    /**
     * The constant GROUP_LINK_ID_DB_COL.
     */
    public static final String GROUP_LINK_ID_DB_COL = "roleSetting.roleId";
    /**
     * The constant ROLE_ID.
     */
    public static final String ROLE_ID = "role_id";
    /**
     * The constant SCREEN_DEF_ID.
     */
    public static final String SCREEN_DEF_ID = "screen_def_id";
    /**
     * The constant TENANT_ID.
     */
    public static final String TENANT_ID = "tenant_id";
    /**
     * The constant SCREEN_ROLE_SETTING_ROLE_ID.
     */
    public static final String SCREEN_ROLE_SETTING_ROLE_ID = "screen_role_setting.role_id";
    /**
     * The constant SECURITY_CODE.
     */
    public static final String SECURITY_CODE = "screen_role_setting.security_code";
    /**
     * The constant USER_ID.
     */
    public static final String USER_ID = "user_id";
    /**
     * The constant CREATED_USER.
     */
    public static final String CREATED_USER = "created_by";
}
