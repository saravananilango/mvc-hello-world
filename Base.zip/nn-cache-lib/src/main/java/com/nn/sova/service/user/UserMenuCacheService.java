package com.nn.sova.service.user;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.UserDao;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.ini.IniService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The type Menu User cache service.
 *
 * @author Mohammed Shameer U
 */
public class UserMenuCacheService {
	/**
	 * The constant logger.
	 */
	private static final ApplicationLogger logger = ApplicationLogger.create(UserMenuCacheService.class);
	
	/**
	 * The constant ROOT_MENU_ID.
	 */
	public static final String ROOT_MENU_ID = "root_menu_id";
	
	/**
	 * The constant MENU_CODE.
	 */
	public static final String MENU_CODE = "menu_code";
	
	/**
	 * The constant CHILD_LIST.
	 */
	public static final String CHILD_LIST = "childIdList";
	
	/**
	 * The constant URL_PATH.
	 */
	public static final String URL_PATH = "urlPath";

	/**
	 * The constant instance.
	 */
	private static UserMenuCacheService instance = null;

	/**
	 * Instantiates a new Locale cache service.
	 */
	private UserMenuCacheService() {
	}

	/**
	 * Gets instance.
	 *
	 * @return the instance
	 */
	public static UserMenuCacheService getInstance() {
		if (Objects.isNull(instance)) {
			instance = new UserMenuCacheService();
		}
		return instance;
	}

	/**
	 * Gets locale info by lang cd.
	 * 
	 * @param
	 *
	 * @param cacheKey the cache key
	 * @param locale   the locale
	 * @return the locale info by lang cd
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getUserFavouritesByTenantAndUserId(String cacheKey) throws QueryException {
		List<Object> resultList = (List<Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultList)) {
			return resultList;
		}
		return updateUserFavouriteMenu(cacheKey);
	}

	/**
	 * updateUserMenuData is used to update user menu data.
	 * 
	 * @param tenantId
	 * @param userId
	 * @param cacheKey
	 * @return 
	 * @throws QueryException
	 */
	private List<Object> updateUserFavouriteMenu(String cacheKey) throws QueryException {
		List<Object> resultValue = UserDao.getInstance().getUserFavourites();
		if (CollectionUtils.isNotEmpty(resultValue)) {
			CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
			return resultValue;
		}else {
			CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			return Collections.emptyList();
		}
	}

	/**
	 * getUserRecentsByTenantAndUserId is used to get the recent data
	 *
	 * @param cacheKey the cache key
	 * @param locale   the locale
	 * @return the locale info by lang cd
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getUserRecentsByTenantAndUserId(String cacheKey) throws QueryException {
		List<Object> resultList = (List<Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultList)) {
			return resultList;
		}
		return updateUserRecentMenu(cacheKey);
	}

	/**
	 * updateUserRecentMenu is used to update user recent menu data.
	 * 
	 * @param tenantId
	 * @param userId
	 * @param cacheKey
	 * @return 
	 * @throws QueryException
	 */
	private List<Object> updateUserRecentMenu(String cacheKey) throws QueryException {
		List<Object> resultValue = UserDao.getInstance().getUserRecents();
		if (CollectionUtils.isNotEmpty(resultValue)) {
			CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
			return resultValue;
		}
		CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
		return Collections.emptyList();
	}

	/**
	 * Gets user menu data.
	 *
	 * @param cacheKey the cache key
	 * @param locale   the locale
	 * @param roleList 
	 * @param tenantId 
	 * @param
	 * @return the locale info by lang cd
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getUserFullAuthorityMenuData(String cacheKey, String authority, String locale,
			List<String> roleList, String tenantId) {
		return updateUserFullAuthorityMenuData(authority, locale, cacheKey, roleList, tenantId);
	}

	/**
	 * updateUserFullAuthorityMenuData is to update the user full authority menu
	 * data
	 * 
	 * @param authority
	 * @param locale
	 * @param cacheKey
	 * @param roleList 
	 * @param tenantId 
	 * @return 
	 */
	private Map<String, Object> updateUserFullAuthorityMenuData(String authority, String locale, String cacheKey,
			List<String> roleList, String tenantId) {
		List<Map<String, Object>> resultList = new ArrayList<>();
		List<Map<String, Object>> fullAuthCacheList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		//Checking the full auth cache
		if (Objects.nonNull(fullAuthCacheList)) {
			resultList.addAll(fullAuthCacheList);
		} else {
			//Cache is not exist then loaded it from the DB
			List<Map<String, Object>> fullAuthList = loadRoleMenuData(locale, authority, TableViewsConstants.CACHE_FULL_MENU_TRANSACTION_VIEW, ROOT_MENU_ID);
			resultList.addAll(fullAuthList);
			//If data exist then save it to the cache 
			if (CollectionUtils.isNotEmpty(fullAuthList)) {
				CacheManager.getInstance().saveAsObject(cacheKey, fullAuthList);
			} else {
				CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
			}
		}
		//To fetch the partial menu checking the role list. 
		if (CollectionUtils.isNotEmpty(roleList)) {
			getRoleMenuData(roleList, resultList, locale, tenantId);
		}
		//Both the menus are fetched then forming to return object 
		if (!resultList.isEmpty()) {
			return formatMenuData(resultList);
		}
		return Collections.emptyMap();
	}
	
	/**
	 * formatMenuData is used to format and set menu data.
	 * 
	 * @param menuDataList
	 * @return
	 */
	private Map<String, Object> formatMenuData(List<Map<String, Object>> menuDataList) {
		Map<String, Object> dataMap = new HashMap<>();
		List<Map<String, Object>> menuEntityList = new ArrayList<>();
		for (Map<String, Object> element : menuDataList) {
			Map<String, Object> valueMap = new HashMap<>();
			for (Entry<String, Object> entry : element.entrySet()) {
				valueMap.put(entry.getKey(), entry.getValue());
			}
			menuEntityList.add(valueMap);
		}
		
		Collections.sort(menuEntityList, new Comparator<Map<String, Object>>() {
		    @Override
		    public int compare(Map<String, Object> map1, Map<String, Object> map2) {
		        return ((BigDecimal) map1.get("menu_order")).compareTo((BigDecimal) map2.get("menu_order"));
		    }
		});
		
		Map<String, Map<String, Object>> menuMap = new LinkedHashMap<>();

		menuEntityList.stream().filter(menuData -> !menuMap.containsKey(String.valueOf(menuData.get(MENU_CODE))))
				.map(menuData -> {
					getMenuItemData(menuData);
					menuMap.put(String.valueOf(menuData.get(MENU_CODE)), menuData);
					return menuData;
				}).collect(Collectors.toList());

		dataMap.putAll(formMenuTransaction(menuEntityList, menuMap));
		return dataMap;
	}

	/**
	 * formMenuTransaction is used to form entity for menu.
	 * 
	 * @param menuEntityList
	 * @param menuMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> formMenuTransaction(List<Map<String, Object>> menuEntityList,
			Map<String, Map<String, Object>> menuMap) {
		Map<String, Object> dataMap = new HashMap<>();
		List<String> parentList;
		List<String> parentIdList = new ArrayList<>();
		menuEntityList.stream().forEach(list -> {
			StringBuilder builder = new StringBuilder();
			String parentId = String.valueOf(list.get("parent_id"));
			String menuCode = String.valueOf(list.get(MENU_CODE));
			if (StringUtils.equals(parentId.trim(), String.valueOf(list.get(ROOT_MENU_ID)))) {
				parentIdList.add(menuCode);
			} else {
				if (menuMap.containsKey(parentId)) {
					if (Objects.isNull(menuMap.get(parentId).get(CHILD_LIST))) {
						menuMap.get(parentId).put(CHILD_LIST, new ArrayList<>());
					}
					((List<String>) menuMap.get(parentId).get(CHILD_LIST)).add(menuCode);
				}
				menuMap.get(menuCode).put("parentId", parentId);
				if (Objects.nonNull(list.get("service_id"))) {
					menuMap.get(list.get(ROOT_MENU_ID)).put(URL_PATH, (builder.append("/")
							.append(list.get("service_url")).append("?sid=").append(list.get("service_id"))));
				}
			}
		});
		parentList = parentIdList.stream().distinct().collect(Collectors.toList());

		dataMap.put("menuData", returnVo(menuMap));
		dataMap.put("menuRoots", parentList);
		return dataMap;
	}

	/**
	 * returnVo is used to return the entity for menu.
	 * 
	 * @param menuMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Object>> returnVo(Map<String, Map<String, Object>> menuMap) {
		Map<String, Map<String, Object>> returnMap = new HashMap<>();
		menuMap.entrySet().stream().forEach(action-> {
			String key = action.getKey();
			Map<String, Object> menuEntity = action.getValue();
			boolean isServiceMenu = menuEntity.get("menu_type").equals("Service");
			Map<String, Object> returnEntity = new HashMap<>();
			returnEntity.put("icon", menuEntity.get("iconImage"));
			returnEntity.put("status", menuEntity.get("status"));
			if (isServiceMenu) {
				if(menuEntity.get("menu_label") == null || StringUtils.isBlank(String.valueOf(menuEntity.get("menu_label")))) {
					returnEntity.put("label", menuEntity.get("service_label"));
				}else {
					returnEntity.put("label", menuEntity.get("menu_label"));
				}
				returnEntity.put("activeDefId", menuEntity.get("screen_definition_id"));
				returnEntity.put("url", menuEntity.get(URL_PATH));
			} else {
				returnEntity.put("label", menuEntity.get("menu_label"));
			}
			String iconColor = Objects.toString(menuEntity.get("menu_icon_color"), StringUtils.EMPTY);
			String textColor = Objects.toString(menuEntity.get("menu_text_color"), StringUtils.EMPTY);
			if(StringUtils.isNotEmpty(iconColor)) {
				Map<String, Object> iconstyleMap = new HashMap<>();
				iconstyleMap.put("color", iconColor);
				returnEntity.put("iconStyle", iconstyleMap);
			}
			if(StringUtils.isNotEmpty(textColor)) {
				Map<String, Object> textstyleMap = new HashMap<>();
				textstyleMap.put("color", textColor);
				returnEntity.put("labelStyle", textstyleMap);
			}
			if (Objects.nonNull(menuEntity.get(CHILD_LIST))) {
				Set<String> dataSet = new LinkedHashSet<>();
				((List<String>)menuEntity.get(CHILD_LIST)).stream().forEach(child-> dataSet.add(child));
				returnEntity.put("children", dataSet);
			} else {
				returnEntity.put("children", new ArrayList<>());
			}
			returnMap.put(key, returnEntity);
		});
		return returnMap;
	}

	/**
	 * getMenuItemData is used to get the menu item data from the list.
	 * 
	 * @param menuData
	 */
	private void getMenuItemData(Map<String, Object> menuData) {
		StringBuilder menuUrl = new StringBuilder();
		Object screenId = menuData.get("screen_id");
		if ((Objects.nonNull(menuData.get("repo_name"))) && (Objects.nonNull(screenId))) {
			menuUrl = new StringBuilder(String.valueOf(menuData.get("repo_name"))).append(((!String.valueOf(menuData.get("screen_url")).startsWith("/")) ? "/":"") +menuData.get("screen_url"))
					.append("?sid=" + screenId);
		}
		menuData.put(URL_PATH, menuUrl);
		menuData.put("iconImage", menuData.get("image_url"));
		menuData.put("status", menuData.get("status"));
	}

	/**
	 * getUserAdminAuthorityMenuData is to get the admin menu user data.
	 * 
	 * @param authority
	 * @param locale
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getUserAdminAuthorityMenuData(String cacheKey, String authority, String locale) {
		Map<String, Object> resultMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultMap)) {
			return resultMap;
		}
		return updateUserAdminAuthorityMenuData(authority, locale, cacheKey);
	}

	/**
	 * updateUserAdminAuthorityMenuData is used to the admin menu data.
	 * 
	 * @param authority
	 * @param locale
	 * @param cacheKey
	 * @return 
	 */
	private Map<String, Object> updateUserAdminAuthorityMenuData(String authority, String locale, String cacheKey) {
		Map<String, Object> resultValue = loadMenuData(locale, Arrays.asList(authority),TableViewsConstants.CACHE_ADMIN_MENU_TRANSACTION_VIEW, ROOT_MENU_ID);
		if (MapUtils.isNotEmpty(resultValue)) {
			CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
			return resultValue;
		}
		CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
		return Collections.emptyMap();
	}

	/**
	 * loadMenuData loads the menu data.
	 * 
	 * @param locale
	 * @param roleList
	 * @param tenantId
	 * 
	 * @return
	 */
	private Map<String, Object> loadMenuData(String locale, List<String> roleList, String tableName, String columnName) {
		List<Map<String, Object>> menuDataList = UserDao.getInstance().getUserMenuData(locale, roleList, tableName,
				columnName);
		return formatMenuData(menuDataList);
	}
	
	private List<Map<String, Object>> loadRoleMenuData(String locale, String role, String tableName, String columnName) {
		return UserDao.getInstance().getUserRoleMenuData(locale, role, tableName,
				columnName);
	}

	/**
	 * getUserRoleAuthorityMenuData is used to get user role authority menu data.
	 * 
	 * @param roleList
	 * @param locale
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getUserRoleAuthorityMenuData(String cacheKey, List<String> roleList, String locale) {
		Map<String, Object> resultMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultMap)) {
			return resultMap;
		}
		return updateUserRoleAuthorityMenuData(roleList, locale, cacheKey);
	}
	
	/**
	 * getUserRoleAuthorityMenuDataFetch is used to get user role authority menu data.
	 * 
	 * @param roleList
	 * @param locale
	 * @param tenantId 
	 * @return
	 */
	public Map<String, Object> getUserRoleAuthorityMenuDataFetch(List<String> roleList, String locale, String tenantId) {
		List<Map<String, Object>> resultList = new ArrayList<Map<String,Object>>();
		getRoleMenuData(roleList, resultList, locale, tenantId);
		if (!resultList.isEmpty()) {
			return formatMenuData(resultList);
		}
		return new HashMap<>();
	}
	
	/**
	 * getRoleMenuData method used to collect the role menu data and store it into cache
	 * @param roleList
	 * @param resultList
	 * @param locale
	 * @param tenantId
	 */
	private void getRoleMenuData(List<String> roleList, List<Map<String, Object>> resultList,
			String locale, String tenantId ) {
		roleList.stream().forEach(role -> {
			String cacheKey = CacheKeyHelper.getAuthorityMenuKey(role, locale, tenantId);
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> cacheResult = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
			if(cacheResult == null || CollectionUtils.isEmpty(cacheResult)) {
				List<Map<String, Object>> resultValue = loadRoleMenuData(locale, role,
						TableViewsConstants.CACHE_PARTIAL_AUTHORITY_MENU_TRANSACTION_VIEW, "role_id");
				if (CollectionUtils.isNotEmpty(resultValue)) {
					CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
					resultList.addAll(resultValue);
				}
			} else {
				resultList.addAll(cacheResult);				
			}
		});
	}

	/**
	 * updateUserRoleAuthorityMenuData is used to update the user role authority
	 * menu data.
	 * 
	 * @param roleList
	 * @param locale
	 * @param cacheKey
	 * @return 
	 */
	private Map<String, Object> updateUserRoleAuthorityMenuData(List<String> roleList, String locale, String cacheKey) {
		Map<String, Object> resultValue = loadMenuData(locale, roleList,
				TableViewsConstants.CACHE_PARTIAL_AUTHORITY_MENU_TRANSACTION_VIEW, "role_id");
		if (MapUtils.isNotEmpty(resultValue)) {
			CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
			return resultValue;
		}
		CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
		return Collections.emptyMap();
	}
	
	/**
	 * getTemplateData is used to get the template data.
	 * 
	 * @param cacheKey
	 * @param themeCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getTemplateData(String cacheKey, String themeCode) {
		Map<String, Object> resultList = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultList)) {
			return resultList;
		}
		return updateUserThemeData(cacheKey, themeCode);
	}
	
	/**
	 * updateUserThemeData is used to update the user theme data.
	 * 
	 * @param cacheKey
	 * @param themeCode 
	 * @return 
	 */
	private Map<String, Object> updateUserThemeData(String cacheKey, String themeCode) {
		Map<String, Object> resultValue = UserDao.getInstance().getTemplateData(themeCode);
		CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
		return resultValue;
	}
	
	/**
	 * getScreenIniData is used to
	 * @param cacheKey
	 * @return
	 */
	public List<Map<String, Object>> getScreenIniData(String cacheKey) {
		List<Map<String, Object>> resultList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultList)) {
			return resultList;
		}
		return updateScreenIniDataForTheUser(cacheKey);
	}
	
	/**
	 * updateScreenIniDataForTheUser is used to update the user screen ini data.
	 * 
	 * @param cacheKey
	 * @return
	 */
	private List<Map<String, Object>> updateScreenIniDataForTheUser(String cacheKey) {
		List<Map<String, Object>> resultValue = IniService.getInstance().getIniDataByService();
		if (CollectionUtils.isNotEmpty(resultValue)) {
			CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
			return resultValue;
		}
		CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
		return Collections.emptyList();
	}

	/**
	 * getTemplateData is used to get the template data.
	 * 
	 * @param cacheKey
	 * @param productCode 
	 * @param tenantId 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getProductCodeTemplateData(String cacheKey, String tenantId, String productCode) {
		Map<String, Object> resultMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultMap) && !resultMap.isEmpty()) {
			return resultMap;
		}
		return updateProductCodeTemplateData(cacheKey, tenantId, productCode);
	}
	
	/**
	 * updateUserThemeData is used to update the user theme data.
	 * 
	 * @param cacheKey
	 * @param productCode 
	 * @param tenantId 
	 * @return 
	 */
	private Map<String, Object> updateProductCodeTemplateData(String cacheKey, String tenantId, String productCode) {
		Map<String, Object> resultValue = UserDao.getInstance().getProductCodeTemplateData(tenantId, productCode);
		CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
		return resultValue;
	}
	
	/**
	 * getTemplateData is used to get the template data.
	 * 
	 * @param cacheKey
	 * @param productCode 
	 * @param tenantId 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getDefaultTemplateData(String cacheKey) {
		Map<String, Object> resultMap = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultMap) && !resultMap.isEmpty()) {
			return resultMap;
		}
		return updateDefaultTemplateData(cacheKey);
	}
	
	/**
	 * updateUserThemeData is used to update the user theme data.
	 * 
	 * @param cacheKey
	 * @param productCode 
	 * @param tenantId 
	 * @return 
	 */
	private Map<String, Object> updateDefaultTemplateData(String cacheKey) {
		Map<String, Object> resultValue = UserDao.getInstance().getDefaultTemplateData();
		CacheManager.getInstance().saveAsObject(cacheKey, resultValue);
		return resultValue;
	}
	
 	/**
 	 * updateUserThemeData is used to update the user theme data.
 	 * 
 	 * @param cacheKey
 	 * @param productCode 
 	 * @param tenantId 
 	 * @return 
 	 */
 	public void updateDebugMode(boolean debugMode) throws QueryException {
 		UserDao.getInstance().updateDebugMode(debugMode);
 		String userInfoCacheKey = CacheKeyHelper.getTenantUserKey(ContextBean.getTenantId(), ContextBean.getUserId());
 		CacheManager.getInstance().deleteKey(userInfoCacheKey);
 	}
}
