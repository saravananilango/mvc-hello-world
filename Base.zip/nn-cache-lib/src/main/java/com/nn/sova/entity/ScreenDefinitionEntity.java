package com.nn.sova.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * The type screen definition entity.
 *
 * @author Anand Kumar
 */
@Data
public class ScreenDefinitionEntity implements Serializable {
    /**
     * The constant serialVersionUID.
     */
    private static final long serialVersionUID = -8601236549696694737L;
    /**
     * The screen def id.
     */
    private String screenDefinitionId;
    /**
     * The Application code.
     */
    private String applicationCode;
    /**
     * The Jsp path.
     */
    private String vuePath;
    /**
     * The screen url.
     */
    private String screenURL;
    /**
     * The screen name.
     */
    private String screenName;
    /**
     * The screen id.
     */
    private String screenId;
    /**
     * The Lang cd.
     */
    private String langCd;
}
