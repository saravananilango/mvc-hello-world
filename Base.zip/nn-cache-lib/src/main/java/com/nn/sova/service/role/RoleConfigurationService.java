package com.nn.sova.service.role;

import com.nn.sova.constants.LogMessageConstants;
import com.nn.sova.constants.RoleConfigurationConstants;
import com.nn.sova.core.CacheManager;
import com.nn.sova.dao.RoleConfigurationDao;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.utiil.TypeConversionHelper;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The type Role configuration service.
 *
 * @author Anand Kumar
 */
public class RoleConfigurationService {
    /**
     * The constant logger.
     */
    private static final ApplicationLogger logger = ApplicationLogger.create(RoleConfigurationService.class);
    /**
     * The constant instance.
     */
    private static RoleConfigurationService instance = null;

    /**
     * Instantiates a new Message definition cache service.
     */
    private RoleConfigurationService() {
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static RoleConfigurationService getInstance() {
        if(Objects.isNull(instance)) {
            instance = new RoleConfigurationService();
        }
        return instance;
    }

    /**
     * Gets role data by tenant id.
     *
     * @param cacheKey the cache key
     * @param roleId   the role id
     * @param tenantId the tenant id
     * @return the role data by tenant id
     */
    @SuppressWarnings("unchecked")
	public  List<Map<String, Object>> getRoleDataByTenantId(String cacheKey, String roleId, String tenantId) throws QueryException {
        List<Map<String, Object>> roleDataMap = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(roleDataMap)) {
            return roleDataMap;
        }
        updateRoleDataByTenantId(tenantId, roleId);
        roleDataMap = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(roleDataMap)) {
            return roleDataMap;
        }
        return Collections.emptyList();
    }

    /**
     * Update role data by tenant id.
     *
     * @param tenantId the tenant id
     * @param roleId   the role id
     */
    private static void updateRoleDataByTenantId(String tenantId, String roleId) throws QueryException {
        List<Map<String, Object>> roleDataList = RoleConfigurationDao.getRoleDataByTenantId(tenantId, roleId);
        if(CollectionUtils.isNotEmpty(roleDataList)) {
            String prefixKey = CacheKeyHelper.getRoleConfigurationPrefixKey();
            String tenantIdValue = roleDataList.get(0).get(RoleConfigurationConstants.TENANT_ID_DB_COL).toString();
            String roleIdValue = roleDataList.get(0).get(RoleConfigurationConstants.GROUP_LINK_ID_DB_COL).toString();
            String cacheKey = prefixKey.concat(tenantIdValue).concat(CacheKeyHelper.DELIMITER).concat(roleIdValue);
            CacheManager.getInstance().saveAsObject(cacheKey, roleDataList);
        }
    }

    /**
     * Gets authorized screens by role id.
     *
     * @param cacheKey the cache key
     * @param roleId   the role id
     * @return the authorized screens by role id
     */
    @SuppressWarnings("unchecked")
	public  Map<Object, List<Map<String, Object>>> getAuthorizedScreensByRoleId(String cacheKey) throws QueryException {
        Map<Object, List<Map<String, Object>>> authorizedScreensMap = (Map<Object, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(authorizedScreensMap)) {
            return authorizedScreensMap;
        }
        updateAuthorizedScreensByRoleId();
        authorizedScreensMap = (Map<Object, List<Map<String, Object>>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(authorizedScreensMap)) {
            return authorizedScreensMap;
        }
        return Collections.emptyMap();
    }

    /**
     * Update authorized screens by role id.
     */
    private static void updateAuthorizedScreensByRoleId() throws QueryException {
        Map<String, Object> userMap = CacheService.getInstance().getUserDataByTenantId(ContextBean.getUserId(), ContextBean.getTenantId());
        List<String> roleList = (List<String>) userMap.get(RoleConfigurationConstants.ROLE_ID);
        if(CollectionUtils.isNotEmpty(roleList)) {
            List<Map<String, Object>> dataList = RoleConfigurationDao.getAuthorizedScreensByRoleId(roleList.get(0));
            Map<Object, Map<Object, List<Map<String, Object>>>> groupingMap = TypeConversionHelper.remapAuthorizedScreensByScreenDefId(dataList);
            for (Map.Entry<Object, Map<Object, List<Map<String, Object>>>> grouping : groupingMap.entrySet()) {
                CacheManager.getInstance().saveAsObject(
                        CacheKeyHelper.getAuthorizedScreensPrefixKey()
                        .concat(grouping.getKey().toString())
                        .concat(CacheKeyHelper.DELIMITER)
                        .concat(roleList.get(0)),
                        grouping.getValue());
            }
        }
    }

    /**
     * Gets screen role link data.
     *
     * @param cacheKey the cache key
     * @param roleId   the role id
     * @return the screen role link data
     */
    @SuppressWarnings("unchecked")
	public  List<Map<String, Object>> getScreenRoleLinkData(String cacheKey, String roleId) throws QueryException {
        List<Map<String, Object>> screenRoleLinkDataList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(screenRoleLinkDataList)) {
            return screenRoleLinkDataList;
        }
        return updateScreenRoleLinkData(roleId);
    }

    /**
     * Update screen role link data.
     *
     * @param roleId the role id
     * @return 
     */
    public List<Map<String, Object>> updateScreenRoleLinkData(String roleId) throws QueryException {
        List<Map<String, Object>> roleDataList = RoleConfigurationDao.getScreenRoleLinkData(roleId);
        String cacheKey = CacheKeyHelper.getRoleConfigurationPrefixKey().concat(roleId);
        if(CollectionUtils.isNotEmpty(roleDataList)) {
            CacheManager.getInstance().saveAsObject(cacheKey, roleDataList);
            return roleDataList;
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
        	return Collections.emptyList();
        }
    }

    /**
     * Gets tenant screen role link data.
     *
     * @param cacheKey the cache key
     * @param tenantId the tenant id
     * @param roleId   the role id
     * @return the tenant screen role link data
     */
    @SuppressWarnings("unchecked")
	public  List<Map<String, Object>> getTenantScreenRoleLinkData(String cacheKey, String tenantId, String roleId) throws QueryException {
        List<Map<String, Object>> screenRoleLinkDataList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(screenRoleLinkDataList)) {
            return screenRoleLinkDataList;
        }
        return updateTenantScreenRoleLinkData(tenantId, roleId);
    }

    /**
     * Update tenant screen role link data.
     *
     * @param tenantId the tenant id
     * @param roleId   the role id
     * @return 
     */
    public List<Map<String, Object>> updateTenantScreenRoleLinkData(String tenantId, String roleId) throws QueryException {
        List<Map<String, Object>> roleDataList = RoleConfigurationDao.getTenantScreenRoleLinkData(tenantId, roleId);
        String cacheKey = CacheKeyHelper.getTenantScreenRoleLinkPrefixKey().concat(tenantId).concat(CacheKeyHelper.DELIMITER).concat(roleId);
        if(CollectionUtils.isNotEmpty(roleDataList)) {
            CacheManager.getInstance().saveAsObject(cacheKey, roleDataList);
            return roleDataList;
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
        	return Collections.emptyList();
        }
    }

    /**
     * Gets roles linked with user id.
     *
     * @param cacheKey the cache key
     * @param userId   the user id
     * @return the roles linked with user id
     */
    @SuppressWarnings("unchecked")
	public  List<Map<String, Object>> getRolesLinkedWithUserId(String cacheKey, String userId) throws QueryException {
        List<Map<String, Object>> rolesLinkedWithDataList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(rolesLinkedWithDataList)) {
            return rolesLinkedWithDataList;
        }
        return updateRolesLinkedWithUserId(userId);
    }

    /**
     * Update roles linked with user id.
     *
     * @param userId the user id
     * @return 
     */
    private static List<Map<String, Object>> updateRolesLinkedWithUserId(String userId) throws QueryException {
        List<Map<String, Object>> rolesLinkedWithUserIdList = RoleConfigurationDao.getRolesLinkedWithUserId(userId);
        String cacheKey = CacheKeyHelper.getRolesLinkedWithUserIdPrefixKey().concat(userId.toLowerCase());
        if(CollectionUtils.isNotEmpty(rolesLinkedWithUserIdList)) {
            CacheManager.getInstance().saveAsObject(cacheKey, rolesLinkedWithUserIdList);
            return rolesLinkedWithUserIdList;
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
        	return Collections.emptyList();
        }
    }

    /**
     * Gets roles linked with user id.
     *
     * @param cacheKey the cache key
     * @param tenantId the tenant id
     * @param userId   the user id
     * @return the roles linked with user id
     */
    @SuppressWarnings("unchecked")
	public  List<Map<String, Object>> getRolesLinkedWithUserId(String cacheKey, String tenantId, String userId) throws QueryException {
        List<Map<String, Object>> rolesLinkedWithDataList = (List<Map<String, Object>>) CacheManager.getInstance().getWithObject(cacheKey);
        if(Objects.nonNull(rolesLinkedWithDataList)) {
            return rolesLinkedWithDataList;
        }
        return updateRolesLinkedWithUserId(userId, tenantId);
    }

    /**
     * Update roles linked with user id.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     * @return 
     */
    private static List<Map<String, Object>> updateRolesLinkedWithUserId(String userId, String tenantId) throws QueryException {
        List<Map<String, Object>> rolesLinkedWithUserIdList = RoleConfigurationDao.getRolesLinkedWithUserId(tenantId, Collections.singletonList(userId));
        String cacheKey = CacheKeyHelper.getTenantRolesLinkedWithUserIdPrefixKey().concat(tenantId).concat(CacheKeyHelper.DELIMITER).concat(userId);
        if(CollectionUtils.isNotEmpty(rolesLinkedWithUserIdList)) {
            CacheManager.getInstance().saveAsObject(cacheKey, rolesLinkedWithUserIdList);
            return rolesLinkedWithUserIdList;
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyList());
        	return Collections.emptyList();
        }
    }

    /**
     * Update roles linked with user id.
     *
     * @param userId   the user id
     * @param tenantId the tenant id
     */
    public void updateRolesLinkedWithUserId(List<Object> userId, String tenantId) throws QueryException {
        List<Map<String, Object>> rolesLinkedWithUserIdList = RoleConfigurationDao.getRolesLinkedWithUserId(tenantId, userId);
        Map<String, List<Map<String, Object>>> userMap = rolesLinkedWithUserIdList.stream().collect(Collectors.groupingBy(group -> group.get("roleLinkSetting.userId").toString().toLowerCase()));
        String cacheKey = CacheKeyHelper.getTenantRolesLinkedWithUserIdPrefixKey().concat(tenantId);
        if(MapUtils.isNotEmpty(userMap)) {
            CacheManager.getInstance().saveAsBulkData(cacheKey, new HashMap<Object, Object>(userMap));
        }else{
        	CacheManager.getInstance().saveAsObject(cacheKey, Collections.emptyMap());
        	logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update screen role link data.
     */
    public void updateScreenRoleLinkData() throws QueryException {
        List<Map<String, Object>> serviceRoleLinkList = RoleConfigurationDao.getAllTenantScreenRoleLink();
        if(CollectionUtils.isNotEmpty(serviceRoleLinkList)) {
            Map<String, Map<String, List<Map<String, Object>>>> serviceRoleLinkMap = serviceRoleLinkList.stream()
                    .collect(Collectors.groupingBy(
                            roleIdMap -> String.valueOf(roleIdMap.get("screenRoleSetting.tenantId")),
                            Collectors.groupingBy(
                                    tenantIdMap -> String.valueOf(tenantIdMap.get("screenRoleSetting.roleId")))));
            serviceRoleLinkMap.entrySet().stream().forEach(action -> {
                Map.Entry<String, Map<String, List<Map<String, Object>>>> roleLinkEntry = action;
                action.getValue().entrySet().stream().forEach(roleDataMap -> {
                    Map.Entry<String, List<Map<String, Object>>> userEntry = roleDataMap;
                    String cacheKey = CacheKeyHelper.getScreenRoleLinkPrefixKey().concat(roleLinkEntry.getKey()).concat(CacheKeyHelper.DELIMITER).concat(userEntry.getKey());
                    CacheManager.getInstance().saveAsObject(cacheKey, userEntry);
                });
            });
        }else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update roles linked with user id.
     */
    public void updateRolesLinkedWithUserId() throws QueryException {
        List<Map<String, Object>> roleList = RoleConfigurationDao.getAllRolesLinkedWithUserId();
        if(CollectionUtils.isNotEmpty(roleList)) {
            Map<String, Map<String, List<Map<String, Object>>>> userMap = TypeConversionHelper.reMapRoledata(roleList);
            userMap.entrySet().stream().forEach(action -> action.getValue().entrySet().stream().forEach(roleDataMap -> {
                Map.Entry<String, List<Map<String, Object>>> userEntry = roleDataMap;
                String cacheKey = CacheKeyHelper.getRolesLinkedWithUserIdPrefixKey().concat(userEntry.getKey().toLowerCase());
                CacheManager.getInstance().saveAsObject(cacheKey, userEntry.getValue());
            }));
        }else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Update roles linked with tenant id.
     */
    public void updateRoleDataByTenantId() throws QueryException {
        List<Map<String, Object>> roleList = RoleConfigurationDao.getRoleDataByTenantId();
        String prefixCacheKey = CacheKeyHelper.getRolesLinkedWithTenantIdPrefixKey();
        if(CollectionUtils.isNotEmpty(roleList)) {
            roleList.stream().forEach(mapper ->
                    CacheManager.getInstance().saveAsObject(prefixCacheKey
                            .concat(mapper.get(RoleConfigurationConstants.TENANT_ID).toString())
                            .concat(CacheKeyHelper.DELIMITER)
                            .concat(mapper.get(RoleConfigurationConstants.ROLE_ID).toString()), mapper)
            );
        }else{
            logger.warn(LogMessageConstants.DB_EMPTY_RECORD_FOUND);
        }
    }

    /**
     * Remove bt tenant role data.
     *
     * @param cachePrefixKey the cache prefix key
     * @param roleId         the role id
     * @param tenantId       the tenant id
     */
    public void removeTenantRoleData(String cachePrefixKey, String roleId, String tenantId) {
        CacheManager.getInstance().deleteKey(cachePrefixKey.concat(tenantId).concat(CacheKeyHelper.DELIMITER).concat(roleId));
    }

    /**
     * Remove bt tenant role link data.
     *
     * @param cachePrefixKey the cache prefix key
     * @param userId         the user id
     * @param tenantId       the tenant id
     */
    public void removeTenantRoleLinkData(String cachePrefixKey, String userId, String tenantId) {
        CacheManager.getInstance().deleteKey(cachePrefixKey.concat(tenantId).concat(CacheKeyHelper.DELIMITER).concat(userId));
    }

    /**
     * Remove role links.
     *
     * @param cachePrefixKey the cache prefix key
     * @param userIdList     the user id list
     */
    public void removeRoleLinks(String cachePrefixKey, List<Object> roleIdList) {
        List<Object> userList = new ArrayList<>(roleIdList);
        userList.replaceAll(user -> cachePrefixKey.concat(user.toString().toLowerCase()));
        CacheManager.getInstance().del(userList.toArray(new String[userList.size()]));
    }

    /**
     * Remove tenant users.
     *
     * @param cachePrefixKey the cache prefix key
     * @param userIdList     the user id list
     */
    public void removeTenantUsers(String cachePrefixKey, List<Object> userIdList) {
        List<Object> userList = new ArrayList<>(userIdList);
        userList.replaceAll(user -> cachePrefixKey.concat(user.toString().toLowerCase()));
        CacheManager.getInstance().del(userList.toArray(new String[userList.size()]));
    }

    /**
     * Remove tenant role links.
     *
     * @param cachePrefixKey the cache prefix key
     * @param userIdList     the user id list
     */
    public void removeTenantRoleLinks(String cachePrefixKey, List<Object> userIdList) {
        List<Object> userList = new ArrayList<>(userIdList);
        userList.replaceAll(user -> cachePrefixKey.concat(ContextBean.getTenantId()).concat(CacheKeyHelper.DELIMITER).concat(user.toString().toLowerCase()));
        CacheManager.getInstance().del(userList.toArray(new String[userList.size()]));
    }
}
