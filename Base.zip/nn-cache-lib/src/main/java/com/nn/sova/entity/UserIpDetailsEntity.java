package com.nn.sova.entity;

import lombok.Data;

/**
 * Instantiates a new user ip details entity.
 * 
 * @author vellaichamy
 * 
 */
@Data
public class UserIpDetailsEntity {

	/** The tenant id. */
	private String tenantId;
	
	/** The ip range definition. */
	private String ipRangeDefinition;
	
	/** The ip type. */
	private String ipType;
	
	/** The allowed roles. */
	private String allowedRoles;
	
	/** The allowed users. */
	private String allowedUsers;
	
	/** The ip range prefix. */
	private String ipRangePrefix;
	
	/** The ip range start. */
	private String ipRangeStart;
	
	/** The ip range end. */
	private String ipRangeEnd;
	
	/** The ip exclude. */
	private String ipExclude;
	
}
