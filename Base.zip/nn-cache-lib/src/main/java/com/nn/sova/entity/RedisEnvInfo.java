package com.nn.sova.entity;

import redis.clients.jedis.HostAndPort;

import java.util.Set;

/**
 * The type Redis env info.
 *
 * @author Anand Kumar
 */
public class RedisEnvInfo {
    /**
     * The Redis nodes.
     */
    Set<HostAndPort> redisNodes;

    /**
     * Gets redis nodes.
     *
     * @return the redis nodes
     */
    public Set<HostAndPort> getRedisNodes() {
        return redisNodes;
    }

    /**
     * Sets redis nodes.
     *
     * @param redisNodes the redis nodes
     */
    public void setRedisNodes(Set<HostAndPort> redisNodes) {
        this.redisNodes = redisNodes;
    }
}
