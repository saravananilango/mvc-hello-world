package com.nn.sova.service.dao.productSelector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.postgresql.util.PGobject;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.querybuilder.functions.StatementBuilder;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * ProductSelectorDaoImpl class used to make DB operation related to save or retrieve of productCode and subProductCode 
 * 
 * @implments ProductSelectorDao
 * @author Inigo Raj G V
 */
public class ProductSelectorDaoImpl implements ProductSelectorDao {

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(ProductSelectorDaoImpl.class);
	
	/** Constant **/
	private static final String PRODUCT_CODE_AUTHORITY_VIEW = "product_code_authority_view";
	
	/** Constant **/
	private static final String REPO_CONFIG = "repo_config";
	
	/** Constant **/
	private static final String PRODUCT_CODE = "product_code";
	/** Constant **/
	private static final String PRODUCT_NAME = "product_name";
	/** Constant **/
	private static final String ROLE_ID = "role_id";
	/** Constant **/
	private static final String SYSTEM_ID = "system_id";
	/** Constant **/
	private static final String SUB_PRODUCT_CODE = "sub_product_code";
	/** Constant **/
	private static final String SUB_PRODUCT_NAME = "sub_product_name";
	/** Constant **/
	private static final String REPO_TYPE = "repo_type";
	/** Constant **/
	private static final String EXTERNAL_DEVELOPMENT = "external_development";
	/** Constant **/
	private static final String MAIN_ALIAS = "main.";
	/** Constant **/
	private static final String REPO_ALIAS = "repo.";
	/** Constant **/
	private static final String INI_KEY = "ini_key";
	/** Constant **/
	private static final String USER_ID = "user_id";
	/** Constant **/
	private static final String REPO_STATUS = "repo_status";
	
	@Override
	public List<Map<String, Object>> getProductDetails(String productText, List<String> roleIds) {
		ConditionBuilder condition = ConditionBuilder.instance();
		ConditionBuilder filterCondition = ConditionBuilder.instance();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select();
		List<String> distinctColumns = new ArrayList<>();
		distinctColumns.add(PRODUCT_CODE);
		filterCondition.ilike(PRODUCT_CODE, "%"+productText+"%");
		filterCondition.or().ilike(PRODUCT_NAME, "%"+productText+"%");
		condition.eq(SYSTEM_ID, EnvironmentReader.getSystemId());
		condition.and().brackets(filterCondition);
			try {
				selectedDataList = selectQueryBuilder.distinct().get(PRODUCT_NAME,PRODUCT_CODE).from(PRODUCT_CODE_AUTHORITY_VIEW)
						.join("redis_tenant_user_details_view", "redis",
						ConditionBuilder.instance()
						.eq("product_status", "SUCCESS").and()
						.eq("product_code_authority_view.role_id", "redis.role_id", true).and()
						.eq("product_code_authority_view.locale", ContextBean.getLocale()).and()
						.eq(USER_ID, ContextBean.getUserId())).where(condition)
						.orderBy(PRODUCT_NAME, SortType.ASC)
						.orderBy(PRODUCT_CODE, SortType.ASC)
				.build(false).execute();
			} catch (QueryException exception) {
				logger.error(exception);
			}
		return selectedDataList;
	}

	@Override
	public List<Map<String, Object>> getSubProductDetails(String subProductText, String productCode, List<Object> repoType, boolean isExternalDevelop, boolean externalDevelop) {
		ConditionBuilder filterCondition = ConditionBuilder.instance();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select().distinct();
		filterCondition.eq(MAIN_ALIAS + PRODUCT_CODE, productCode);
		filterCondition.and().eq(MAIN_ALIAS + REPO_STATUS , "SUCCESS");
		filterCondition.and().inWithList(MAIN_ALIAS + REPO_TYPE, repoType);
		if (isExternalDevelop) {
			filterCondition.and().eq(MAIN_ALIAS + EXTERNAL_DEVELOPMENT, externalDevelop);
		}
		try {
			SelectQueryBuilder innerQuery = new QueryBuilder().btSchema().select().distinct().concat(REPO_ALIAS + SUB_PRODUCT_NAME, SUB_PRODUCT_NAME).from(REPO_CONFIG, "repo")
					.where(ConditionBuilder.instance().eq(REPO_ALIAS + PRODUCT_CODE, productCode).and().inWithList(REPO_ALIAS + REPO_TYPE, repoType).and().eq(REPO_ALIAS + REPO_STATUS, "SUCCESS").and()
							.eq(REPO_ALIAS + SUB_PRODUCT_CODE, MAIN_ALIAS + SUB_PRODUCT_CODE, true).and().isNotNull(REPO_ALIAS + SUB_PRODUCT_NAME)).setLanguage("en").build(false);
			selectQueryBuilder.get(StatementBuilder.instance().caseExp().whenCondition(
					ConditionBuilder.instance().isNull(SUB_PRODUCT_NAME))
							.thenCondition(innerQuery).elseCondition(SUB_PRODUCT_NAME).end(), SUB_PRODUCT_NAME)
					.get(MAIN_ALIAS + SUB_PRODUCT_CODE).from(REPO_CONFIG, "main").where(filterCondition)
					.lang(true)
			.build(false);
			selectedDataList = new QueryBuilder().select().from(selectQueryBuilder, "fullRecords").where(ConditionBuilder.instance()
				.brackets(ConditionBuilder.instance().ilike("fullRecords." + SUB_PRODUCT_NAME, "%"+subProductText+"%").or().ilike("fullRecords." + SUB_PRODUCT_CODE, "%"+subProductText+"%")))
				.orderBy(SUB_PRODUCT_NAME, SortType.ASC).build(false).execute();
		} catch (QueryException exception) {
			logger.error(exception);
		}
		return selectedDataList;
	}

	@Override
	public void saveProductDetailsAsIni(PGobject resultData, String productIniKey) {
		List<Map<String, Object>> dataList = new ArrayList<>();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("ini_storage.ini_object", resultData);
		resultMap.put("ini_storage.user_id", ContextBean.getUserId());
		resultMap.put("ini_storage.ini_key", productIniKey);
		dataList.add(resultMap);
		try {
			new QueryBuilder().btSchema().insert().upsertWithKeyList("ini_storage", dataList, true,
					Arrays.asList(USER_ID, "ini_object", INI_KEY), USER_ID, INI_KEY);
		} catch (QueryException exception) {
			logger.error(exception);
		}
	}

	@Override
	public List<Map<String, Object>> getIniDetails(String productIniKey) {
		QueryBuilder selectQueryBuilder = new QueryBuilder().btSchema();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		ConditionBuilder condition = ConditionBuilder.instance();
		condition.eq(INI_KEY, productIniKey);
		condition.and().eq(USER_ID, ContextBean.getUserId());
		
		try {
			selectedDataList =selectQueryBuilder.select().get("ini_object")
					.from("ini_storage").where(condition)
					.build(false).execute();
		} catch (QueryException exception) {
			logger.error(exception);
		}
		return selectedDataList;
	}
	
	@Override
	public List<Map<String, Object>> getProduct(String productCode, List<String> roleIds) {
		ConditionBuilder condition = ConditionBuilder.instance();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select();
		List<String> distinctColumns = new ArrayList<>();
		distinctColumns.add(PRODUCT_CODE);
		condition.eq(SYSTEM_ID, EnvironmentReader.getSystemId());
		condition.and().eq(PRODUCT_CODE,productCode);
			try {
				selectedDataList = selectQueryBuilder.distinctOn(distinctColumns).from(PRODUCT_CODE_AUTHORITY_VIEW)
						.join("redis_tenant_user_details_view", "redis",
						ConditionBuilder.instance()
						.eq("product_status", "SUCCESS").and()
						.eq("product_code_authority_view.role_id", "redis.role_id", true).and()
						.eq("product_code_authority_view.locale", ContextBean.getLocale()).and()
						.eq(USER_ID, ContextBean.getUserId())).where(condition)
				.build(false).execute();
			} catch (QueryException exception) {
				logger.error(exception);
			}
		return selectedDataList;
	}

}