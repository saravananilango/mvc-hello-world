package com.nn.sova.service.enums;

/**
 * TableTypeEnum USED FOR Default status and tables type maintain
 * 
 * @author MOHAN RAM
 *
 */
public enum TableTypeEnum {
	/**
	 * DATA_DEFINITION_REQUEST for check it is data definition request
	 */
	DATA_DEFINITION_REQUEST,
	/**
	 * change request parent request type
	 */
	PARENTREQUEST,
	/**
	 * table status released
	 */
	RELEASED,
	/**
	 * table status inprogress
	 */
	INPROGRESS,
	/**
	 * table stauts released
	 */
	INACTIVE,
	/**
	 * table repo_list for source code generation
	 */
	REPOS_LIST,
	/**
	 * SUCCESS
	 */
	SUCCESS,
	/**
	 * SOURCE_CODE
	 */
	SOURCE_CODE,
	/**
	 * RENAME_TABLE
	 */
	RENAME_TABLE,
	/**
	 * RENAME_COLUMN
	 */
	RENAME_COLUMN,
	
	/**
	 * HANDLER_CHANGE
	 */
	HANDLER_CHANGE
	
}
