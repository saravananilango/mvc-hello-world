package com.nn.sova.service.utils.viewobject;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.service.CacheService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.CustomException;

import net.sf.jsqlparser.expression.Alias;
import net.sf.jsqlparser.expression.CaseExpression;
import net.sf.jsqlparser.expression.CastExpression;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.Function;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.Parenthesis;
import net.sf.jsqlparser.expression.StringValue;
import net.sf.jsqlparser.expression.operators.arithmetic.Addition;
import net.sf.jsqlparser.expression.operators.arithmetic.Multiplication;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
import net.sf.jsqlparser.expression.operators.relational.LikeExpression;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.create.table.ColDataType;
import net.sf.jsqlparser.statement.select.AllColumns;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.select.SelectBody;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;
import net.sf.jsqlparser.statement.select.SetOperationList;
import net.sf.jsqlparser.statement.select.SubSelect;
import net.sf.jsqlparser.statement.select.WithItem;


public class ViewObjectParserUtils {

	/**
	 * parseQuery method parses the query
	 * 
	 * @param query
	 * @return
	 * @throws CustomException 
	 */
	public void parseQuery(String query, Map<String, Object> paramMap) throws CustomException {
		try {
			String parsedQuery = query.replace(";", "");
			CCJSqlParserManager parserManager = new CCJSqlParserManager();
			Select select = (Select) parserManager.parse(new StringReader(parsedQuery));
			if (select.getSelectBody() instanceof PlainSelect) {
				PlainSelect plainSelect=(PlainSelect)select.getSelectBody(); 
				getFromSelect(plainSelect, paramMap);
				if(Objects.nonNull(select.getWithItemsList())) {
					List<WithItem> withItemList = select.getWithItemsList();
					for(WithItem itemObj : withItemList) {
						if(itemObj.getSelectBody() instanceof SetOperationList) {
							SetOperationList setOperationList = (SetOperationList) itemObj.getSelectBody();
							buildSetOperationList(setOperationList, paramMap);
						}
					}
				}
			} else if (select.getSelectBody() instanceof SetOperationList) {
				SetOperationList setOperationList = (SetOperationList) select.getSelectBody();
				buildSetOperationList(setOperationList, paramMap);
			}
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
	}
	
	public void checkForLikeExpression(PlainSelect plainSelect) {
		Expression whereEp = plainSelect.getWhere();
		if(whereEp instanceof AndExpression) {
			AndExpression tempOrExp = (AndExpression)whereEp;
			Expression andLeftExpression = tempOrExp.getLeftExpression();
			Expression andRightExpression = tempOrExp.getRightExpression();
			formLikeExpression(andLeftExpression);
			formLikeExpression(andRightExpression);
		}else if(whereEp instanceof OrExpression) {
			OrExpression tempOrExp = (OrExpression)whereEp;
			Expression orLeftExpression = tempOrExp.getLeftExpression();
			Expression orRightExpression = tempOrExp.getRightExpression();
			formLikeExpression(orLeftExpression);
			formLikeExpression(orRightExpression);
		}else if(whereEp instanceof LikeExpression) {
			formLikeExpression(whereEp);
		}
	}
	
	private void formLikeExpression(Expression expression) {
		
		if(expression instanceof AndExpression) {
			AndExpression tempAndExpression = (AndExpression)expression;
			Expression orLeftExpression = tempAndExpression.getLeftExpression();
			Expression orRightExpression = tempAndExpression.getRightExpression();
			formLikeExpression(orLeftExpression);
			formLikeExpression(orRightExpression);
		}else if(expression instanceof OrExpression){
			OrExpression tempOrExpression = (OrExpression)expression;
			Expression orLeftExpression = tempOrExpression.getLeftExpression();
			Expression orRightExpression = tempOrExpression.getRightExpression();
			formLikeExpression(orLeftExpression);
			formLikeExpression(orRightExpression);
		}else if(expression instanceof LikeExpression) {
			LikeExpression likeExp = (LikeExpression)expression;
			if(likeExp.isCaseInsensitive()) {
			Expression leftLikeExp = likeExp.getLeftExpression();
			if(leftLikeExp instanceof Column) {
				Column tempColumn = (Column)leftLikeExp;
				Function tempFunction = new Function();
				tempFunction.setName("lower");
				tempFunction.setParameters(new ExpressionList(tempColumn));
				likeExp.setLeftExpression(tempFunction);
				likeExp.setCaseInsensitive(false);
			}
			}
		}else if(expression instanceof Parenthesis) {
			Parenthesis tempParExpression = (Parenthesis)expression;
			Expression tempExpression = tempParExpression.getExpression();
			formLikeExpression(tempExpression);
		}
		
	}
	
	
	/**
	 * getFromSelect method is to get values from select query
	 * @param plainSelect
	 * @param paramMap
	 * @throws CustomException
	 */
	private void getFromSelect(PlainSelect plainSelect,Map<String,Object> paramMap) throws CustomException {
		List<SelectItem> selectitems=plainSelect.getSelectItems();
		try{
			if(!selectitems.isEmpty() && selectitems.get(0) instanceof AllColumns) {
				ViewObjectCommonUtils.addErrorMessage(paramMap, CacheService.getInstance().getApplicationTextDefinitionData("view_object_empty_column_manual", "ViewObjectDetail", ContextBean.getLocale()));
				return;
			}
		if(!paramMap.containsKey("columnDataList")){
			formColumnList(selectitems, paramMap);
		}else{
			formSubQueryColumnList(selectitems, paramMap);
		}
		if(plainSelect.getFromItem() instanceof Table){
		Table fromTable= (Table) plainSelect.getFromItem();
		getTablesWithAlias(paramMap, fromTable);
		if(!paramMap.containsKey("main_table")){
			paramMap.put("main_table", fromTable.getName());
		}
		buildJoinTables(plainSelect, paramMap);
		}else if(plainSelect.getFromItem() instanceof SubSelect){
			SubSelect subSelect = (SubSelect) plainSelect.getFromItem();
			if(subSelect.getSelectBody() instanceof PlainSelect){
			PlainSelect subPlainSelect=(PlainSelect)subSelect.getSelectBody();
			buildJoinTables(subPlainSelect, paramMap);
			getFromSelect(subPlainSelect, paramMap);
			}else if(subSelect.getSelectBody() instanceof SetOperationList){
				SetOperationList setOperationList = (SetOperationList) subSelect.getSelectBody();
				buildSetOperationList(setOperationList, paramMap);
			}
		}
		buildJoinTables(plainSelect, paramMap);
		}catch(Exception exception){
			throw new CustomException(exception);
		}
	}
	
	
	
	/**
	 * formColumnList acquires select columns from the query
	 * @param selectitems
	 * @param paramMap
	 * @throws CustomException
	 */
	private void formColumnList(List<SelectItem> selectitems,Map<String,Object> paramMap) throws CustomException{
		Map<String,Object> columnDataDetailsMap = new HashMap<>();
		Map<String,Object> expressionColumnMap = new HashMap<>();
		try{
		if(!selectitems.isEmpty()){
            buildColumns(selectitems, paramMap,columnDataDetailsMap,expressionColumnMap);			
			paramMap.put("columnDataList", columnDataDetailsMap);
			paramMap.put("expressionColumns", expressionColumnMap);
			}
		}catch(Exception exception){
			throw new CustomException(exception);
		}
		
	}
	
	
	/**
	 * formColumnList acquires select columns from the query
	 * @param selectitems
	 * @param paramMap
	 * @throws CustomException
	 */
	private void formSubQueryColumnList(List<SelectItem> selectitems,Map<String,Object> paramMap) throws CustomException{
		Map<String,Object> columnDataDetailsMap = new HashMap<>();
		Map<String,Object> expressionColumnMap = new HashMap<>();
		try{
			if(paramMap.containsKey("subQueryColumnMap") && Objects.nonNull(paramMap.get("subQueryColumnMap"))){
				columnDataDetailsMap = (Map<String, Object>) paramMap.get("subQueryColumnMap");
			}
			if(paramMap.containsKey("subQueryexpressionColumns") && Objects.nonNull(paramMap.get("subQueryexpressionColumns"))){
				expressionColumnMap = (Map<String, Object>) paramMap.get("subQueryexpressionColumns");
			}
		if(!selectitems.isEmpty()){
            buildColumns(selectitems, paramMap,columnDataDetailsMap,expressionColumnMap);			
			paramMap.put("subQueryColumnMap", columnDataDetailsMap);
			paramMap.put("subQueryexpressionColumns", expressionColumnMap);
			}
		}catch(Exception exception){
			throw new CustomException(exception);
		}
		
	}
	
	
	
	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param paramMap
	 * @param table 
	 * @throws CustomException
	 */
	private void getTablesWithAlias(Map<String,Object> paramMap , Table table) throws CustomException{
		Map<String,Object> tableAliasNameMap = new HashMap<>();
		try{
			if(paramMap.containsKey("tableAliasMap") && Objects.nonNull(paramMap.get("tableAliasMap"))){
				tableAliasNameMap = (Map<String, Object>) paramMap.get("tableAliasMap");
			}
			if(Objects.nonNull(table)){
			tableAliasNameMap.put(Objects.isNull(table.getAlias()) ? table.getName() : table.getAlias().getName(),table.getName());
			paramMap.put("tableAliasMap", tableAliasNameMap);
			}
		}catch(Exception exception){
			throw new CustomException(exception);
		}
	}
	
	
	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param paramMap
	 * @param expressionColumnMap2 
	 * @param columnDataDetailsMap2 
	 * @param table
	 * @throws CustomException
	 */
	private void buildColumns(List<SelectItem> selectitems,Map<String,Object> paramMap, Map<String, Object> columnDataDetailsMap, Map<String, Object> expressionColumnMap) throws CustomException{
		try{
		if(!selectitems.isEmpty()){
			for(int i=0;i<selectitems.size();i++){
				Alias aliasName = ((SelectExpressionItem) selectitems.get(i)).getAlias();
				Expression expression=((SelectExpressionItem) selectitems.get(i)).getExpression();  
				if(expression instanceof Column){
					Column col=(Column)expression;
					if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
						columnDataDetailsMap.put(aliasName.getName(), col.getName(false));
					}else{
						columnDataDetailsMap.put(col.getColumnName(), col.getName(false));
					}
				}else if(expression instanceof Function){
					if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
						expressionColumnMap.put(aliasName.getName(),((Function) expression).getName());
					}else{
						expressionColumnMap.put(((Function) expression).getName(),((Function) expression).getName());
					}
				}else if(expression instanceof CaseExpression){
					if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
						expressionColumnMap.put(aliasName.getName(),"CASE");
				}
				}else if(expression instanceof StringValue){
					StringValue column = (StringValue)expression;
					if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
						expressionColumnMap.put(aliasName.getName(), column.getValue());
					}else{
						expressionColumnMap.put(column.getValue(), column.getValue());
					}
				}else if(expression instanceof CastExpression){
					CastExpression  castExp = (CastExpression)expression;
					Expression leftElement = castExp.getLeftExpression();
					ColDataType colDataType =  castExp.getType();
					if(leftElement instanceof CaseExpression){
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
						}else{
							expressionColumnMap.put("CASE", colDataType.getDataType());
						}
						}else if(leftElement instanceof Parenthesis){
							if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
								expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
							}	
					}else if(leftElement instanceof StringValue){
						StringValue column = (StringValue)leftElement;
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
						}else{
							expressionColumnMap.put(column.getValue(), colDataType.getDataType());
						}
			      }else if(leftElement instanceof LongValue){
			    	  LongValue column = (LongValue)leftElement;
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
						}else{
							expressionColumnMap.put(Long.toString(column.getValue()), colDataType.getDataType());
						}
			      }else if(leftElement instanceof Column){
			    	     Column col=(Column)leftElement;
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
						}else{
							expressionColumnMap.put(col.getColumnName(), colDataType.getDataType());
						}
			       }else if(leftElement instanceof Function){
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(),colDataType.getDataType());
						}else{
							expressionColumnMap.put(((Function) leftElement).getName(),colDataType.getDataType());
						}
					}else if(leftElement instanceof Addition || leftElement instanceof Multiplication){
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(),colDataType.getDataType());
						}else{
							expressionColumnMap.put(((Function) leftElement).getName(),colDataType.getDataType());
						}
					}
	         }else if(expression instanceof Parenthesis) {
	        	Expression brackExpression =  ((Parenthesis) expression).getExpression();
	        	if(brackExpression instanceof Addition) {
	        		if(((Addition) brackExpression).getLeftExpression() instanceof LongValue && ((Addition) brackExpression).getRightExpression() instanceof LongValue) {
	        			if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
	        				expressionColumnMap.put(aliasName.getName(),"integer");
	        			}else{
	        				expressionColumnMap.put("column","integer");
	        			}
	        		}else if(((Addition) brackExpression).getLeftExpression() instanceof StringValue && ((Addition) brackExpression).getRightExpression() instanceof StringValue) {
	        			if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
	        				expressionColumnMap.put(aliasName.getName(),"text");
	        			}else{
	        				expressionColumnMap.put("column","text");
	        			}
	        		}else {
	        			if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
	        				expressionColumnMap.put(aliasName.getName(),"text");
	        			}else{
	        				expressionColumnMap.put("column","text");
	        			}
	        		}
	        	}else if(brackExpression instanceof CaseExpression) {
	        			if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(),"CASE");
	        		}
	        	}else {
        			if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
        				expressionColumnMap.put(aliasName.getName(),"text");
        			}else{
        				expressionColumnMap.put("column","text");
        			}
        		}
	         }
			}
		}
		}catch(Exception exception){
			throw new CustomException(exception);
			}
		}
	

	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param paramMap
	 * @param expressionColumnMap2 
	 * @param columnDataDetailsMap2 
	 * @param table
	 * @throws CustomException
	 */
	private void buildJoinTables(PlainSelect plainSelect,Map<String,Object> paramMap) throws CustomException{
		List<Join> joinTablesList =plainSelect.getJoins();
		if(Objects.nonNull(joinTablesList) && !joinTablesList.isEmpty()){
		for(int i=0;i<joinTablesList.size();i++){
			if(joinTablesList.get(i).getRightItem() instanceof Table){
			Table tempTable = (Table) joinTablesList.get(i).getRightItem();
			getTablesWithAlias(paramMap, tempTable);
			}else if(joinTablesList.get(i).getRightItem() instanceof SubSelect){
				SubSelect subSelect = (SubSelect) joinTablesList.get(i).getRightItem();
				if(subSelect.getSelectBody() instanceof PlainSelect){
				PlainSelect subPlainSelect=(PlainSelect)subSelect.getSelectBody();
				buildJoinTables(subPlainSelect, paramMap);
				getFromSelect(subPlainSelect, paramMap);
				}
			}else  if(joinTablesList.get(i).getRightItem() instanceof PlainSelect){
				PlainSelect subPlainSelect = (PlainSelect) joinTablesList.get(i).getRightItem();
				buildJoinTables(subPlainSelect, paramMap);
				getFromSelect(subPlainSelect, paramMap);
			}
		}
		}
	}
	
	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param paramMap
	 * @param expressionColumnMap2 
	 * @param columnDataDetailsMap2 
	 * @param table
	 * @throws CustomException
	 */
	private void buildSetOperationList(SetOperationList setOperationList ,Map<String,Object> paramMap) throws CustomException{
		List<SelectBody> selectList = setOperationList.getSelects();
		for(int i=0;i<selectList.size();i++){
			if(selectList.get(i) instanceof PlainSelect){
				PlainSelect tempSelect = (PlainSelect) selectList.get(i);
				if(Objects.nonNull(tempSelect)){
					getFromSelect(tempSelect, paramMap);
				}
			}
		}
	}
	
	
}
