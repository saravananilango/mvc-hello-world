package com.nn.sova.service.mastersearch.builder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.cache.CacheGetManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.mastersearch.model.MasterSearchLoadInfo;
import com.nn.sova.service.mastersearch.model.MasterSearchRequestParam;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.utility.cache.CacheGetService;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * 
 * MasterSearchQueryBuilder class is used to build the search query from the
 * database.
 * 
 * @author Logchand
 *
 */
public class MasterSearchQueryBuilder {
	
	/** The Constant CONST_DOT. */
	private static final String CONST_DOT = ".";
	
	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(MasterSearchQueryBuilder.class);

	/**
	 * getSearchResult method will get the result from db.
	 *
	 * @param param      the param
	 * @param masterInfo the master info
	 * @param offset     the offset
	 * @param countFlag  the count flag
	 * @param searchType the search type
	 * @return List<Map<String, Object>>
	 */
	@SuppressWarnings("unchecked")
	public List<List<Map<String, Object>>> getSearchResult(MasterSearchRequestParam param,
			MasterSearchLoadInfo masterInfo, int offset, boolean countFlag, Map<String, Object> searchType) {
		Set<String> tableNameList = new HashSet<>();
		tableNameList.add(masterInfo.getTableName());
		String inputKeyword = param.getInputKeyword().get(0).trim();
		Map<String, Object> filterFields = param.getFilterFields();
		Map<String, Object> filterConditions = param.getFilterConditions();
		Set<String> columnSet = new LinkedHashSet<>();
		if (Objects.nonNull(masterInfo.getShowColumnName()) && masterInfo.getShowColumnName().trim().length() > 0) {
			String[] columnNames = masterInfo.getShowColumnName().split(",");
			columnSet.addAll(Arrays.asList(columnNames));
		}
		if (Objects.nonNull(masterInfo.getSetColumnName()) && masterInfo.getSetColumnName().trim().length() > 0) {
			String[] showColumnNames = masterInfo.getSetColumnName().split(",");
			columnSet.addAll(Arrays.asList(showColumnNames));
		}
		String keyColumnName = null;
		if (Objects.nonNull(masterInfo.getKeyColumnName())) {
			keyColumnName = masterInfo.getKeyColumnName();
		}
		String tableName = masterInfo.getTableName();
		QueryBuilder searchBuilder;
		String url;
		String user;
		String password;
		String schema;
		String productCode = masterInfo.getProductName();
		if (Objects.nonNull(masterInfo.getProductName()) && masterInfo.getProductName().trim().length() > 0) {
			if (Objects.nonNull(EnvironmentReader
					.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("url")))) {
				url = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("url"));
				user = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("user"));
				password = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("password"));
				schema = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("schema"));
			} else {
				Map<String, Object> dbDetails = new HashMap<>();
				Object data = CacheGetService.getInstance()
						.getCustomCacheData("sova_product_code_handler_" + productCode);
				if (Objects.nonNull(data) && !CollectionUtils
						.isEmpty((Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>>) data)) {
					Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>> dataMap = (Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>>) data;
					if (StringUtils.isEmpty(EnvironmentReader.getSystemId())) {
						throw new RuntimeException("Default systemId Not present in Application Properties");
					}
					List<Map<String, Object>> dataList;
					if (StringUtils.isNotEmpty(ContextBean.getMsaName()) && dataMap.entrySet().iterator().next()
							.getValue().get(EnvironmentReader.getSystemId()).containsKey(ContextBean.getMsaName())) {
						dataList = dataMap.entrySet().iterator().next().getValue().get(EnvironmentReader.getSystemId())
								.get(ContextBean.getMsaName());
					} else {
						dataList = dataMap.entrySet().iterator().next().getValue().get(EnvironmentReader.getSystemId())
								.entrySet().iterator().next().getValue();
					}
					if (!CollectionUtils.isEmpty(dataList)) {
						dbDetails = dataList.get(0);
					} else {
						throw new RuntimeException(
								"Error: Database handler details is incorrect/not exist for handler '"
										+ dbDetails.get("handler_name") + "' in Product '" + productCode + "'.");
					}
				}
				try {
					url = QueryUtils.makeDatabaseUrl(dbDetails.get("database_type").toString(),
							dbDetails.get("ip_address").toString(), dbDetails.get("port").toString(),
							dbDetails.get("database_name").toString());
					user = dbDetails.get("database_username").toString();
					password = dbDetails.get("database_password").toString();
					schema = dbDetails.get("database_schema").toString();
				} catch (NullPointerException exception) {
					throw new RuntimeException("Error: Database handler details is incorrect/not exist for handler '"
							+ dbDetails.get("handler_name") + "' in Product '" + productCode + "'.");
				}
			}
			searchBuilder = new QueryBuilder(url, user, password, schema);
		} else {
			searchBuilder = new QueryBuilder();
		}
		ConditionBuilder conditionBuilder = ConditionBuilder.instance();
		SelectQueryBuilder queryBuilder;
		SelectQueryBuilder countQueryBuilder;
		if (masterInfo.isDistinct()) {
			queryBuilder = searchBuilder.select().distinct();
			countQueryBuilder = searchBuilder.select().count("DISTINCT( " +  keyColumnName + " )",
					"count");
		} else {
			queryBuilder = searchBuilder.select();
			countQueryBuilder = searchBuilder.select().count( keyColumnName, "count");
		}
		queryBuilder.from(tableName);
		countQueryBuilder.from(tableName);
		List<String> searchColumnsList = new ArrayList<>(columnSet);
		Set<String> extraColumnSet = new LinkedHashSet<>();
		if (StringUtils.isNotEmpty(masterInfo.getExtraFields())) {
			String[] extraFields = masterInfo.getExtraFields().split(",");
			extraColumnSet.addAll(Arrays.asList(extraFields));
		}
		List<String> finalGetColumns = new ArrayList<>(extraColumnSet);
		String[] columnArray = new String[finalGetColumns.size()];
		String[] finalColumnArray = finalGetColumns.toArray(columnArray);
		String[] searchColumnArray = new String[searchColumnsList.size()];
		String[] finalSearchColumnArray = searchColumnsList.toArray(searchColumnArray);
		if(StringUtils.isNotEmpty(inputKeyword.trim())) {
			conditionBuilder.simpleSearch(inputKeyword, finalSearchColumnArray);
		}
		filterColumns(masterInfo, conditionBuilder, filterFields, filterConditions);
		if ("tag".equals(searchType.get("searchTypeElement"))) {
			List<Object> filterTagValue = (List<Object>) searchType.get("filterTagsValue");
			if (!filterTagValue.isEmpty()) {
				AtomicInteger loopCount = new AtomicInteger(0);
				String keyColumn = keyColumnName;
				if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
					conditionBuilder.and();
				}
				conditionBuilder.not();
				ConditionBuilder inWithConditionBuilder = ConditionBuilder.instance();
				filterTagValue.stream().forEach(filter -> {
					if (loopCount.get() != filterTagValue.size() - 1) {
						inWithConditionBuilder.like(tableName + '.' + keyColumn, filter.toString()).or();
					} else {
						inWithConditionBuilder.like(tableName + '.' + keyColumn, filter.toString());
					}
					loopCount.incrementAndGet();
				});
				conditionBuilder.brackets(inWithConditionBuilder);
			}
		}
		makeWhereCondition(tableName, conditionBuilder,productCode);
		queryBuilder.where(conditionBuilder);
		countQueryBuilder.where(conditionBuilder);
		if (StringUtils.isNotEmpty(masterInfo.getSortBy()) && StringUtils.isNotEmpty(masterInfo.getSortType())) {
  			String sortColumn = masterInfo.getSortBy();
  			SortType sortType = Optional.ofNullable(masterInfo.getSortType()).map(Objects::toString).map(SortType::valueOf).orElse(null);
	  		queryBuilder.orderBy(sortColumn,sortType);
  		}else if (StringUtils.isNotEmpty(masterInfo.getSortBy())) {
  			String[] orderByColumns = masterInfo.getSortBy().split(",");
  			List<String> orderByList = new ArrayList<>(Arrays.asList(orderByColumns));
 	 		queryBuilder.orderBy(orderByList);
		}
		queryBuilder.get(finalColumnArray);
		queryBuilder.get(finalSearchColumnArray);
		if (StringUtils.isNotEmpty(keyColumnName) && 
				!finalGetColumns.contains(keyColumnName) && 
				!searchColumnsList.contains(keyColumnName)) {
			queryBuilder.get(keyColumnName);
		}
		if(masterInfo.isIndependentTenantFlag()) {
			queryBuilder.checkIndependentTenant(true);
		}
		queryBuilder.checkSoftDelete(true);
		countQueryBuilder.checkSoftDelete(true);
		queryBuilder.setProductCode(productCode);
		countQueryBuilder.setProductCode(productCode);
		List<List<Map<String, Object>>> resultList = new ArrayList<>();
		List<Map<String, Object>> queryResult;
		try {
			queryResult = queryBuilder.limit(5).offset(offset).build(false).execute();
			resultList.add(queryResult);
			if (countFlag) {
				List<Map<String, Object>> countResult = countQueryBuilder.build(false).execute();
				resultList.add(countResult);
			}
		} catch (QueryException exception) {
			logger.error(exception);
		}
		return resultList;
	}

	/**
	 * getSearchResult method will get the result from db.
	 *
	 * @param param                 the param
	 * @param masterInfo            the master info
	 * @param offset                the offset
	 * @param countFlag             the count flag
	 * @param searchType            the search type
	 * @param customConditionKeyMap the custom condition key map
	 * @return List<Map<String, Object>>
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@SuppressWarnings("unchecked")
	public List<List<Map<String, Object>>> getCustomConditionSearchResult(MasterSearchRequestParam param,
			MasterSearchLoadInfo masterInfo, int offset, boolean countFlag, Map<String, Object> searchType,
			Map<String, Object> customConditionKeyMap) throws IOException {
		Set<String> tableNameList = new HashSet<>();
		tableNameList.add(masterInfo.getTableName());
		String inputKeyword = param.getInputKeyword().get(0).trim();
		Set<String> columnSet = new LinkedHashSet<>();
		if (Objects.nonNull(masterInfo.getShowColumnName()) && masterInfo.getShowColumnName().trim().length() > 0) {
			String[] columnNames = masterInfo.getShowColumnName().split(",");
			columnSet.addAll(Arrays.asList(columnNames));
		}
		if (Objects.nonNull(masterInfo.getSetColumnName()) && masterInfo.getSetColumnName().trim().length() > 0) {
			String[] showColumnNames = masterInfo.getSetColumnName().split(",");
			columnSet.addAll(Arrays.asList(showColumnNames));
		}
		String keyColumnName = null;
		if (Objects.nonNull(masterInfo.getKeyColumnName())) {
			keyColumnName = masterInfo.getKeyColumnName();
		}
		String tableName = masterInfo.getTableName();
		QueryBuilder searchBuilder;
		String url;
		String user;
		String password;
		String schema;
		String productCode = masterInfo.getProductName();
		if (Objects.nonNull(masterInfo.getProductName()) && masterInfo.getProductName().trim().length() > 0) {
			if (Objects.nonNull(EnvironmentReader
					.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("url")))) {
				url = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("url"));
				user = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("user"));
				password = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("password"));
				schema = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("schema"));
			} else {
				Map<String, Object> dbDetails = new HashMap<>();
				Object data = CacheGetService.getInstance()
						.getCustomCacheData("sova_product_code_handler_" + productCode);
				if (Objects.nonNull(data) && !CollectionUtils
						.isEmpty((Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>>) data)) {
					Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>> dataMap = (Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>>) data;
					if (StringUtils.isEmpty(EnvironmentReader.getSystemId())) {
						throw new RuntimeException("Default systemId Not present in Application Properties");
					}
					List<Map<String, Object>> dataList;
					if (StringUtils.isNotEmpty(ContextBean.getMsaName()) && dataMap.entrySet().iterator().next()
							.getValue().get(EnvironmentReader.getSystemId()).containsKey(ContextBean.getMsaName())) {
						dataList = dataMap.entrySet().iterator().next().getValue().get(EnvironmentReader.getSystemId())
								.get(ContextBean.getMsaName());
					} else {
						dataList = dataMap.entrySet().iterator().next().getValue().get(EnvironmentReader.getSystemId())
								.entrySet().iterator().next().getValue();
					}
					if (!CollectionUtils.isEmpty(dataList)) {
						dbDetails = dataList.get(0);
					} else {
						throw new RuntimeException(
								"Error: Database handler details is incorrect/not exist for handler '"
										+ dbDetails.get("handler_name") + "' in Product '" + productCode + "'.");
					}
				}
				try {
					url = QueryUtils.makeDatabaseUrl(dbDetails.get("database_type").toString(),
							dbDetails.get("ip_address").toString(), dbDetails.get("port").toString(),
							dbDetails.get("database_name").toString());
					user = dbDetails.get("database_username").toString();
					password = dbDetails.get("database_password").toString();
					schema = dbDetails.get("database_schema").toString();
				} catch (NullPointerException exception) {
					throw new RuntimeException("Error: Database handler details is incorrect/not exist for handler '"
							+ dbDetails.get("handler_name") + "' in Product '" + productCode + "'.");
				}
			}
			searchBuilder = new QueryBuilder(url, user, password, schema);
		} else {
			searchBuilder = new QueryBuilder();
		}
		ConditionBuilder conditionBuilder = null;
		SelectQueryBuilder queryBuilder;
		SelectQueryBuilder countQueryBuilder;
		if (masterInfo.isDistinct()) {
			queryBuilder = searchBuilder.select().distinctOn(Arrays.asList(keyColumnName));
			countQueryBuilder = searchBuilder.select().count("DISTINCT( " + keyColumnName + " )",
					"count");
		} else {
			queryBuilder = searchBuilder.select();
			countQueryBuilder = searchBuilder.select().count(keyColumnName, "count");
		}
		queryBuilder.from(tableName);
		countQueryBuilder.from(tableName);
		List<String> searchColumnsList = new ArrayList<>(columnSet);
		String[] searchColumnArray = new String[searchColumnsList.size()];
		String[] finalSearchColumnArray = searchColumnsList.toArray(searchColumnArray);
		List<Map<String, Object>> customFilterList = new ArrayList<>();
		String customConditionKey = Objects.toString(customConditionKeyMap.get("key"), null);
		if (Objects.nonNull(customConditionKey)) {
			try {
				customFilterList = new QueryBuilder().btSchema().select().get("condition")
						.from("appgen_master_filter")
						.where(ConditionBuilder.instance().eq("key", customConditionKey)).build(false).execute();
			} catch (QueryException exception) {
				logger.error("Master Search Query Error", exception);
			}
		}
		if (!customFilterList.isEmpty() && Objects.nonNull(customFilterList.get(0))
				&& customFilterList.get(0).containsKey("condition")
				&& Objects.nonNull(customFilterList.get(0).get("condition"))) {
			ObjectMapper object = new ObjectMapper();
			String conditionString = Objects.toString(customFilterList.get(0).get("condition"), "");
			Map<String, Object> valueMap = Objects.nonNull(customConditionKeyMap.get("valueMap"))
					? ((Map<String, Object>) customConditionKeyMap.get("valueMap"))
							: new HashMap<>();
					Iterator<Map.Entry<String, Object>> itr = valueMap.entrySet().iterator();
					while (itr.hasNext()) {
						Map.Entry<String, Object> value = itr.next();
						conditionString = conditionString.replaceAll(Pattern.quote(value.getKey()),
								QueryUtils.toQuotedString(Objects.toString(value.getValue(), "")));
					}
					List<Map<String, Object>> conditionList = object.readValue(conditionString,
							new TypeReference<List<Map<String, Object>>>() {
					});
					conditionBuilder = ConditionBuilder.instance().brackets(ConditionBuilder.instance(conditionList));
		} else {
			conditionBuilder = ConditionBuilder.instance();
		}
		Set<String> extraColumnSet = new LinkedHashSet<>();
		if (StringUtils.isNotEmpty(masterInfo.getExtraFields())) {
			String[] extraFields = masterInfo.getExtraFields().split(",");
			extraColumnSet.addAll(Arrays.asList(extraFields));
		}
		List<String> finalGetColumns = new ArrayList<>(extraColumnSet);
		String[] columnArray = new String[finalGetColumns.size()];
		String[] finalColumnArray = finalGetColumns.toArray(columnArray);
		queryBuilder.get(finalColumnArray);
		queryBuilder.get(finalSearchColumnArray);
		if (StringUtils.isNotEmpty(keyColumnName) && 
				!finalGetColumns.contains(keyColumnName) && 
				!searchColumnsList.contains(keyColumnName)) {
			queryBuilder.get(keyColumnName);
		}
		if(StringUtils.isNotEmpty(inputKeyword.trim())) {
			if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
				conditionBuilder.and();
			}
			conditionBuilder.simpleSearch(inputKeyword, finalSearchColumnArray);
		}
		if(masterInfo.isIndependentTenantFlag()) {
			queryBuilder.checkIndependentTenant(true);
		}
		queryBuilder.checkSoftDelete(true);
		countQueryBuilder.checkSoftDelete(true);
		queryBuilder.setProductCode(productCode);
		countQueryBuilder.setProductCode(productCode);
		List<List<Map<String, Object>>> resultList = new ArrayList<>();
		makeWhereCondition(tableName, conditionBuilder,productCode);
		List<Map<String, Object>> queryResult;
		try {
			queryResult = queryBuilder.where(conditionBuilder).limit(5).offset(offset).build(false).execute();
			resultList.add(queryResult);
			if (countFlag) {
				List<Map<String, Object>> countResult = countQueryBuilder.where(conditionBuilder).build(false)
						.execute();
				resultList.add(countResult);
			}
		} catch (QueryException exception) {
			logger.error("Master Search Query Error", exception);
		}
		return resultList;
	}

	/**
	 * Make where condition.
	 *
	 * @param tableName             the table name
	 * @param finalConditionBuilder the final condition builder
	 */
	@SuppressWarnings("unchecked")
	private static void makeWhereCondition(String tableName, ConditionBuilder finalConditionBuilder,String productCode) {
		Set<String> langColumns = new HashSet<>();
		CacheGetManager redisGetManager = CacheGetManager.getInstance();
		Map<String, Object> viewConfig = (Map<String, Object>) redisGetManager.getViewConfig(tableName,productCode);
		if (Objects.nonNull(viewConfig) && !CollectionUtils.isEmpty(viewConfig)) {
			viewConfig.entrySet().stream().forEach(action -> {
				Map<String, Object> tableConfig = (Map<String, Object>) redisGetManager
						.getServerSideValidation(action.getKey(), ContextBean.getLocale(),productCode);
				if (Objects.nonNull(tableConfig) && !CollectionUtils.isEmpty(tableConfig)
						&& tableConfig.containsKey(ContextBean.getLocale())) {
					List<Map<String, Object>> data = (List<Map<String, Object>>) tableConfig
							.get(ContextBean.getLocale());
					List<Map<String, Object>> viewData = (List<Map<String, Object>>) action.getValue();
					Map<String, Object> viewMap = new HashMap<>();
					viewData.stream().forEach(viewDatas -> {
						viewMap.put(viewDatas.get("column_name").toString(),
								viewDatas.get("table_alias_name").toString());
					});
					data.stream()
					.filter(predicate -> Objects.nonNull(predicate.get("lang_dependent"))
							&& "true".equals(predicate.get("lang_dependent").toString()))
					.forEach(langData -> {
						if (viewMap.containsKey(langData.get("column_name"))) {
							langColumns
							.add(viewMap.get(langData.get("column_name")).toString() + "_locale");
						}
					});
				}
			});
			langColumns.stream().forEach(action -> {
				if (!StringUtils.isAllEmpty(finalConditionBuilder.getQuery().trim())) {
					finalConditionBuilder.and();
				}
				finalConditionBuilder.eq(action, ContextBean.getLocale(), false);
			});
		}
	}

	/**
	 * Filter columns.
	 *
	 * @param masterInfo       the master info
	 * @param conditionBuilder the condition builder
	 * @param filterFields     the filter fields
	 * @param filterConditions the filter conditions
	 */
	public void filterColumns(MasterSearchLoadInfo masterInfo, ConditionBuilder conditionBuilder,
			Map<String, Object> filterFields, Map<String, Object> filterConditions) {
		if (StringUtils.isNotEmpty(masterInfo.getFilterFields()) && MapUtils.isNotEmpty(filterFields)) {
			String[] filterColumns = masterInfo.getFilterFields().split(",");
			Arrays.asList(filterColumns).stream().filter(filterFields::containsKey).forEach(column -> {
				if (Objects.nonNull(filterConditions.get(column))
						&& StringUtils.isNotEmpty(Objects.toString(filterConditions.get(column), ""))) {
					String conditions = Objects.toString(filterConditions.get(column), "");
					if (conditions.equalsIgnoreCase("eq")) {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.eq(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					} else if (conditions.equalsIgnoreCase("neq")) {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.notEq(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					} else if (conditions.equalsIgnoreCase("gt")) {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.gt(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					} else if (conditions.equalsIgnoreCase("lt")) {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.lt(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					} else if (conditions.equalsIgnoreCase("gte")) {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.gte(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					} else if (conditions.equalsIgnoreCase("lte")) {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.lte(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					} else if (conditions.equalsIgnoreCase("in")) {
						if(Objects.nonNull(filterFields.get(column))) {
							List<Object> inList = (List<Object>)filterFields.get(column);
							if(!CollectionUtils.isEmpty(inList)) {
								if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
									conditionBuilder.and();
								}
								conditionBuilder.inWithList(column, true, inList);
							}
						}
					} else if (conditions.equalsIgnoreCase("notin")) {
						if (Objects.nonNull(filterFields.get(column))) {
							List<Object> inList = (List<Object>) filterFields.get(column);
							if (!CollectionUtils.isEmpty(inList)) {
								if (!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())) {
									conditionBuilder.and();
								}
								conditionBuilder.not().inWithList(column, true, inList);
							}
						}
					} else {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.eq(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					}
				} else {
					if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
						conditionBuilder.and();
					}
					conditionBuilder.eq(column,
							QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
				}
			});
		}
	}
}
