package com.nn.sova.service.controller.wizard;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.controller.ComponentAttributeController;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.ScreenDefTypeEnum;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.service.wizard.WizardService;
import com.nn.sova.service.service.wizard.WizardServiceImpl;

@SovaMapping("/wizard")
public class WizardController extends ComponentAttributeController {

    /** The WizardService */
    private final WizardService wizardService;

    /**
	 * WizardController is a constructor used to initialize the value for
	 * WizardService
	 *
	 */
    public WizardController() {
        wizardService = new WizardServiceImpl();
    }

    /**
	 * getWizardData method is to get wizard data from the screen
	 * 
	 * @param paramMap
	 * @return Map of data
	 */
	@SovaMapping(value = "/getData", method = SovaRequestMethod.GET)
    public Map<String, Object> getWizardData(SovaHttpRequest request, SovaHttpResponse response) throws IOException, QueryException {
		Map<String, String> paramMap = request.getQueryParameters();
//		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, Object> returnMap = new HashMap<>();
        String wizardId = String.valueOf(paramMap.get("wizardId"));
        String wizardDialogId = String.valueOf(paramMap.get("wizardDialogId"));
        Map<String, Object> wizardDataMap = wizardService.getWizardData(wizardId, wizardDialogId);
        String wizardKey = convertToTitleCase(wizardId);
        List<FrontVo> dataElementList = getComponentElementData(ScreenDefTypeEnum.WIZARD.getValue(), wizardKey);
        returnMap.put("wizardTemplate", wizardDataMap);
        returnMap.put("wizardDataElement", dataElementList);
        return returnMap;
    }

    /**
	 * deleteCacheByKey method is to delete the cache data by wizard key
	 * 
	 * @param paramMap
	 * @return
	 * @throws IOException 
	 */
    @SovaMapping(value = "/deleteCacheByKey", method = SovaRequestMethod.GET)
    public String deleteCacheByKey(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, String> paramMap = request.getQueryParameters();
//		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        String wizardId = String.valueOf(paramMap.get("wizardId"));
        return wizardService.deleteCacheByKey(wizardId);
    }

    /**
	 * deleteAllCache method is to delete all the wizard cache
	 * 
	 * @param paramMap
	 * @return
	 */
    @SovaMapping(value = "/deleteAllCache", method = SovaRequestMethod.GET)
    public String deleteAllCache(SovaHttpRequest request, SovaHttpResponse response) {
        return wizardService.deleteAllCache();
    }

    /**
	 * convertToTitleCase method is to convert hyphen separated string to Title case
	 * 
	 * @param hyhenSeperatedString
	 * @return String
	 */
    private String convertToTitleCase(String hyhenSeperatedString) {
        if (StringUtils.isEmpty(hyhenSeperatedString)) {
            return StringUtils.EMPTY;
        }
        String[] splittedArray = hyhenSeperatedString.split("-");
        StringBuilder stringBuilder = new StringBuilder();
        for (String currentString : splittedArray) {
            stringBuilder.append(currentString.substring(0, 1).toUpperCase() + currentString.substring(1).toLowerCase());
        }
        return stringBuilder.toString();
    }
}
