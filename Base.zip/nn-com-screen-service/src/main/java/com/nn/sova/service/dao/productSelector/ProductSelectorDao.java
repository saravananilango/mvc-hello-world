package com.nn.sova.service.dao.productSelector;

import java.util.List;
import java.util.Map;

import org.postgresql.util.PGobject;

/**
 * ProductSelectorDao interface
 * 
 * @author Inigo Raj V
 */
public interface ProductSelectorDao {

	List<Map<String, Object>> getProductDetails(String productText, List<String> roleIds);

	List<Map<String, Object>> getSubProductDetails(String subProductText, String productCode, List<Object> repoType, boolean isExternalDevelop, boolean externalDevelop);

	void saveProductDetailsAsIni(PGobject resultData, String productIniKey);

	List<Map<String, Object>> getIniDetails(String productIniKey);
	
	List<Map<String, Object>> getProduct(String productText, List<String> roleIds);

}