package com.nn.sova.service.service.wizard;

import java.util.Map;

/**
 * WizardService interface
 * 
 * @author Vivek Kannan E
 */
public interface WizardService {

	Map<String,Object> getWizardData(String wizardId);
	
	Map<String,Object> getWizardData(String wizardId, String wizardDialogId);
	
    String deleteCacheByKey(String wizardId);
   
    String deleteAllCache();

}
