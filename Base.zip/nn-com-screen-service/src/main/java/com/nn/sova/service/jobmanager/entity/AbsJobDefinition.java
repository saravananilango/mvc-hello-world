package com.nn.sova.service.jobmanager.entity;

import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.ARTIFACT_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.DELIMITER_DOT;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.GROUP_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_DESCRIPTION;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_NAME;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_EXCLUSIVITY_TYPE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_STATE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_TYPE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.PRODUCT_CODE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.SUB_PRODUCT_CODE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.nn.sova.utility.jobmanager.JobManagerComponent;
import com.nn.sova.utility.jobmanager.constants.JobExclusivityType;
import com.nn.sova.utility.jobmanager.constants.JobState;
import com.nn.sova.utility.jobmanager.constants.JobType;
import com.nn.sova.utility.jobmanager.entity.JobCallbackUrl;
import com.nn.sova.utility.jobmanager.entity.JobManagerTable;
import com.nn.sova.utility.jobmanager.entity.JobParameters;
import com.nn.sova.utility.jobmanager.exception.JobManagerJsonConversionException;
import com.nn.sova.utility.jobmanager.exception.JobManagerRuntimeException;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * The Class {@code AbsJobDefinition} represents an abstract job definition
 *
 * @author praveen_kumar_nr
 */
@Data
@EqualsAndHashCode(of = { "jobDefId" }, callSuper = false)
@ToString(callSuper = true)
public abstract class AbsJobDefinition extends JobManagerTable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The job def id. */
	private String jobDefId;

	/** The job def name. */
	private String jobDefName;

	/** The job def description. */
	private String jobDefDescription;

	/** The job type. */
	private JobType jobType;

	/** The product code. */
	private String productCode;

	/** The sub product code. */
	private String subProductCode;

	/** The group id. */
	private String groupId;

	/** The artifact id. */
	private String artifactId;

	/** The job state. */
	private JobState jobState;

	/** The job exclusivity type. */
	private JobExclusivityType jobExclusivityType;

	/**
	 * Instantiates a new abs job definition.
	 *
	 * @param tableName the table name
	 */
	protected AbsJobDefinition(String tableName) {
		super(tableName);
	}

	/**
	 * Instantiates a new job definition.
	 *
	 * @param dataMap the data map
	 */
	protected AbsJobDefinition(String tableName, Map<String, Object> dataMap) {
		super(tableName, dataMap);
		if (dataMap == null || dataMap.isEmpty()) {
			throw new NullPointerException("Expected a non-null and non-empty map, but provide map="
				+ dataMap);
		}
		this.jobDefId = (String)dataMap.get(JOB_DEF_ID);
		this.jobDefName = (String)dataMap.get(JOB_DEF_NAME);
		this.jobDefDescription = (String)dataMap.get(JOB_DEF_DESCRIPTION);
		this.jobType = JobType.from(dataMap.get(JOB_TYPE));
		this.productCode = (String)dataMap.get(PRODUCT_CODE);
		this.subProductCode = (String)dataMap.get(SUB_PRODUCT_CODE);
		this.groupId = (String)dataMap.get(GROUP_ID);
		this.artifactId = (String)dataMap.get(ARTIFACT_ID);
		this.jobState = JobState.from(dataMap.get(JOB_STATE));
		this.jobExclusivityType = JobExclusivityType.from(dataMap.get(JOB_EXCLUSIVITY_TYPE));
	}

	/**
	 * converts the entity into insert data map.
	 *
	 * @return the map
	 * @throws JobManagerJsonConversionException the json conversion exception
	 */
	@Override
	public Map<String, Object> toInsertMap() {
		Map<String, Object> insertDataMap = new HashMap<>();
		insertDataMap.put(getInsertKey(JOB_DEF_ID), getJobDefId());
		insertDataMap.put(getInsertKey(JOB_DEF_NAME), getJobDefName());
		insertDataMap.put(getInsertKey(JOB_DEF_DESCRIPTION), getJobDefDescription());
		insertDataMap.put(getInsertKey(JOB_TYPE), getJobType().getValue());
		insertDataMap.put(getInsertKey(PRODUCT_CODE), getProductCode());
		insertDataMap.put(getInsertKey(SUB_PRODUCT_CODE), getSubProductCode());
		insertDataMap.put(getInsertKey(GROUP_ID), getGroupId());
		insertDataMap.put(getInsertKey(ARTIFACT_ID), getArtifactId());
		insertDataMap.put(getInsertKey(JOB_STATE), getJobState().getValue());
		insertDataMap.put(getInsertKey(JOB_EXCLUSIVITY_TYPE), getJobExclusivityType().getValue());
		return insertDataMap;
	}

	/**
	 * Creates a new Job definition from a JSON String.
	 *
	 * @param <T>   the generic type
	 * @param json  the json
	 * @param clazz the clazz
	 * @return the job definition framework jar
	 */
	public static <T extends AbsJobDefinition> T fromJson(String json, Class<T> clazz) {
		if (json == null || json.isEmpty()) {
			return null;
		}
		return JobManagerComponent.getValueFromJson(json, clazz);
	}

	/**
	 * Gets the job parameters.
	 *
	 * @return the job parameters
	 */
	public abstract JobParameters getJobParameters();

	/**
	 * Gets the job callback urls.
	 *
	 * @return the job callback urls
	 */
	public abstract List<JobCallbackUrl> getJobCallbackUrls();

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public abstract String getVersion();

	/**
	 * Gets the job parameters as map.
	 *
	 * @param jobParameters the job parameters
	 * @return the job parameters map
	 */
	@JsonIgnore
	public Map<String, Object> getJobParametersMap() {
		return JobParameters.asMap(this.getJobParameters());
	}

	/**
	 * Gets the job parameters.
	 *
	 * @param other the other
	 * @return the job parameters
	 */
	public JobParameters getJobParameters(JobParameters other) {
		JobParameters jobParameters = this.getJobParameters();
		return jobParameters == null ? other : jobParameters.merge(other);
	}

	/**
	 * Gets the job parameters map.
	 *
	 * @param other the other
	 * @return the job parameters map
	 */
	public Map<String, Object> getJobParametersMap(JobParameters other) {
		return JobParameters.asMap(getJobParameters(other));
	}

	/**
	 * Gets the insert key.
	 *
	 * @param columnName the column name
	 * @return the insert key
	 */
	protected String getInsertKey(String columnName) {
		return getTableName() + DELIMITER_DOT + columnName;
	}

	/**
	 * Creates the job definition.
	 *
	 * @param dataMap the data map
	 * @return the abs job definition
	 */
	public static AbsJobDefinition from(Map<String, Object> dataMap) {
		String jobDefId = (String)dataMap.get(JOB_DEF_ID);
		if (StringUtils.isEmpty(jobDefId)) {
			throw new JobManagerRuntimeException("jobDefId is Required");
		}
		JobType jobType = JobType.from(dataMap.get(JOB_TYPE));
		if (Objects.isNull(jobType)) {
			throw new JobManagerRuntimeException("jobType is Required");
		}
		if (jobType.isFrameworkJar()) {
			return new JobDefinitionFrameworkJar(dataMap);
		} else if (jobType.isExternalJar()) {
			return new JobDefinitionExternalJar(dataMap);
		} else if (jobType.isFrameworkApi() || jobType.isExternalApi()) {
			return new JobDefinitionApi(dataMap);
		}
		throw new JobManagerRuntimeException("Undefined JobType, jobType="
			+ jobType + ", jobDefId=" + jobDefId);
	}

}
