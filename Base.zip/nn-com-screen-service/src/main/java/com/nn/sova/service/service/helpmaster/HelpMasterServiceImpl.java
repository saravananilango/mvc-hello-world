package com.nn.sova.service.service.helpmaster;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.service.CacheService;
import com.nn.sova.service.dao.helpmaster.HelpMasterDao;
import com.nn.sova.service.dao.helpmaster.HelpMasterDaoImpl;
import com.nn.sova.service.enums.ScreenDefTypeEnum;

/**
 * HelpMasterServiceImpl class is used for implementing the functionalities
 * related to help master
 * 
 * @author Sakthivel
 *
 */
public class HelpMasterServiceImpl implements HelpMasterService {

	private final HelpMasterDao helpMasterDao;

	/**
	 * HelpMasterServiceImpl constructor which initialize HelpMasterDaoImpl
	 */
	public HelpMasterServiceImpl() {
		helpMasterDao = new HelpMasterDaoImpl();
	}

	@Override
	public Map<String,Object> getHelpMasterData(String screenId) {
		List<Map<String,Object>> helpMasterDataList = helpMasterDao.getData(screenId);
		Map<String,Object> helpMasterMap = new HashMap<>();
		if(CollectionUtils.isNotEmpty(helpMasterDataList) ) {
			helpMasterMap = helpMasterDataList.stream().collect(Collectors.toMap(map -> map.get("id").toString(), map -> map));
		}
		return helpMasterMap;
		
	}

	@Override
	public Map<String,Object> getHelpMasterData(String screenId, String helpMasterId) {
		return helpMasterDao.getData(screenId, helpMasterId);
	}

	@Override
	public String deleteCacheByKey(String screenId) {
		boolean status = CacheService.getInstance().deleteCacheByCompDefAndKey(ScreenDefTypeEnum.HELP_MASTER.getValue(), screenId);
		if(status) {
			return "success";
		}
		return "failure";
	}

	@Override
	public String deleteAllCache() {
		boolean status = CacheService.getInstance().deleteCacheByCompDefType(ScreenDefTypeEnum.HELP_MASTER.getValue());
		if(status) {
			return "success";
		}
		return "failure";
	}

	

}