package com.nn.sova.service.controller.roboticPaste;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.fit.pdfdom.PDFDomTree;
import org.postgresql.util.PGobject;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.math.DoubleMath;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.workflow.entity.ApplicationDataEntity;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * RoboticPaste class used to convert PDF file to HTML DOM Element using Apache PDFBOX and CSSBOX library,
 * robotic paste gets the HTML DOM from CSSBOX parser and predicts the space between word elements 
 * and reduces it into the single element and default classes are renamed to robotic paste classes
 * 
 * @author Punithan Antony Das(punithanantony.d@vaken.cloud)
 *
 */
@SovaMapping("/roboticPaste")
public class RoboticPaste {
	
	/** RoboticPaste Constants used */
	private static final String FILE_UNPARSABLE = "FILE_UNPARSABLE";
	private static final String FILE_PARSABLE = "FILE_PARSABLE";
	private static final String INVALID_PASSWORD = "INVALID_PASSWORD";
	private static final String HTML_FILE = "htmlFile";
	private static final String SUCCESS = "success";
	private static final String INCORRECT_PASSWORD = "incorrectPassword";
	private static final String MESSAGE = "message";
	private static final String ERROR = "ERROR";
	private static final String PASSWORD = "password";
	private static final String COMPONENT_LIST = "componentList";
	private static final String KEY_ID = "id";
	private static final String KEY_LABEL = "label";
	private static final String KEY_USER_ID = "userId";
	private static final String KEY_SCREEN_ID = "screenId";
	private static final Integer CONST_ONE = 1;
	private static final Integer START_INDEX = 0;
	private static final String COLUMN_USER_ID = "user_id";
	private static final String COLUMN_SCREEN_ID = "screen_id";
	private static final String MAPPING_ID = "mapping-id";
	private static final String COLUMN_SELECTION_HISTORY = "selection_history";
	private static final String ROBOTIC_PASTE_SELECTION_TABLE = "robotic_paste_selection_history";
	private static final String[] SEPARATORS = new String[]{":","-", "="};
	private static final String STRING_EMPTY = StringUtils.EMPTY;
	private static final String STYLE = "style";
	private static final String WIDTH = "width";
	private static final String FONT_SIZE = "font-size";
	private static final String IS_LAST_ELEMENT = "isLastElement";
	private static final String ELEMENT = "element";
	private static final String CLASS = "class";
	
	/** logger class */
	private static ApplicationLogger logger = ApplicationLogger.create(RoboticPaste.class);


	/**
	 * converttPdf2Html function used to convert PDF document to HTML String
	 * 
	 * @param request
	 * @param response
	 * 
	 * @return result map as String
	 * 
	 * @throws IOException
	 * @throws JsonConversionException
	 */
	@SovaMapping(value = "/fileConversion", method = SovaRequestMethod.POST)
	public void converttPdf2Html(SovaHttpRequest request, SovaHttpResponse response) throws JsonConversionException{
		logger.info("CONVERTTPDF2HTML METHOD CALLED");
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
		logger.error("Post Param Map Object {}", postParamMap);
		logger.error("Post Param Map Object {}", postParamMap.get(COMPONENT_LIST));
		String password = objectToString(postParamMap, PASSWORD);
		String userId = objectToString(postParamMap, KEY_USER_ID);
		String screenId = objectToString(postParamMap, KEY_SCREEN_ID);
		List<Map<String, String>> componentList = JsonUtils.fromJsonOrThrow(String.valueOf(postParamMap.get(COMPONENT_LIST)), 
				new TypeReference<List<Map<String, String>>>() {});
		List<String> componentIdList = new ArrayList<>();
		List<String> componentLabelList = new ArrayList<>();
		if(CollectionUtils.isNotEmpty(componentList)) {
			addManualSelections(userId, screenId, componentList);
			componentList.stream().filter(component -> component.containsKey(KEY_ID) 
					&& component.containsKey(KEY_LABEL) && Objects.nonNull(component.get(KEY_LABEL)))
				.forEach(component -> {
				componentIdList.add(component.get(KEY_ID));
				componentLabelList.add(component.get(KEY_LABEL).toLowerCase());
			});
		}
		try{
			final List<MultipartFile> files = (List<MultipartFile>) postParamMap.get("files");
			files.stream().forEach(file -> {
				try {
					converttPdf2Html(file.getInputStream(), password, componentIdList, componentLabelList, resultMap);
				} catch (IOException exception) {
					resultMap.put(SUCCESS, false);
					resultMap.put(INCORRECT_PASSWORD, false);
					resultMap.put(MESSAGE, ERROR);
					logger.error("ERROR OCCURS WHILE PROCESSING FILE IN LOOP", exception);
				}
	        });
		}catch(Exception exception) {
			resultMap.put(SUCCESS, false);
			resultMap.put(INCORRECT_PASSWORD, false);
			resultMap.put(MESSAGE, ERROR);
			logger.error("ERROR OCCURS WHILE PROCESSING FILE", exception);
		}
		response.withBody(JsonUtils.toPrettyJsonOrNull(resultMap));
	}
	
	@SovaMapping(value = "/learnManualSelections", method = SovaRequestMethod.POST)
	public void learnManualSelections(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		Map<String, Object> resultMap = new HashMap<>();
		String userId = objectToString(paramMap, KEY_USER_ID);
		String screenId = objectToString(paramMap, KEY_SCREEN_ID);
		String componentId = objectToString(paramMap, KEY_ID);
		String label = objectToString(paramMap, KEY_LABEL);
		/** check if component id is present */
		if(StringUtils.isEmpty(componentId) || StringUtils.isEmpty(label)) {
			resultMap.put(SUCCESS, false);
			response.withBody(JsonUtils.toPrettyJsonOrNull(resultMap));
			return;
		}
		label = label.replace(":", "").replace("-", "").replace("=", "").trim();
		List<Map<String, Object>> selctionHistoryList = getSelectionHistory(userId, screenId);
		/** if selection history already present,then update the data, else insert as new record*/
		if(CollectionUtils.isNotEmpty(selctionHistoryList)) {
			updateData(userId, screenId, componentId, label, selctionHistoryList.get(START_INDEX), resultMap);
		}else {
			insertData(userId, screenId, componentId, label, resultMap);
		}
		response.withBody(JsonUtils.toPrettyJsonOrNull(resultMap));
	}
	
	@SovaMapping(value = "/removeSelections", method = SovaRequestMethod.POST)
	public void removeSelections(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		Map<String, Object> resultMap = new HashMap<>();
		String userId = objectToString(paramMap, KEY_USER_ID);
		String screenId = objectToString(paramMap, KEY_SCREEN_ID);
		String componentId = objectToString(paramMap, KEY_ID);
		if(StringUtils.isEmpty(componentId)) {
			response.withBody(JsonUtils.toPrettyJsonOrNull(resultMap));
			return;
		}
		List<Map<String, Object>> selctionHistoryList = getSelectionHistory(userId, screenId);
		if(CollectionUtils.isEmpty(selctionHistoryList)) {
			resultMap.put(SUCCESS, false);
			response.withBody(JsonUtils.toPrettyJsonOrNull(resultMap));
			return;
		}
		try {			
			removeSelectionHistory(userId, screenId, componentId, selctionHistoryList.get(START_INDEX), resultMap);
		}catch(Exception exception) {
			logger.error("ERROR OCCURS WHILE CONVERTING SELECTION HISTORY TO LIST - REMOVE", exception);
		}
		response.withBody(JsonUtils.toPrettyJsonOrNull(resultMap));
	}
	
	/**
	 * converttPdf2Html function used to convert PDF document to HTML String
	 * 
	 * @param file
	 * @param password
	 * 
	 * @return result map
	 */
	private Map<String, Object> converttPdf2Html(InputStream file, String password, List<String> componentIdList, List<String> componentLabelList,
			Map<String, Object> resultMap) {
		Map<String, String> componentValueMap = new HashMap<>();
		try (PDDocument pdDocument = PDDocument.load(file, password)) {
			pdDocument.setAllSecurityToBeRemoved(true);
			pdDocument.setAllSecurityToBeRemoved(true);
			parseDocument(pdDocument, resultMap, componentLabelList, componentIdList, componentValueMap);
		}catch(InvalidPasswordException exception) {
			resultMap.put(SUCCESS, false);
			resultMap.put(INCORRECT_PASSWORD, StringUtils.isNotEmpty(password));
			resultMap.put(MESSAGE, INVALID_PASSWORD);
			logger.error("IVALID OR EMPTY FILE PASSWORD PASSED", exception);
		}catch(IOException exception) {
			resultMap.put(SUCCESS, false);
			resultMap.put(INCORRECT_PASSWORD, false);
			resultMap.put(MESSAGE, ERROR);
			logger.error("ERROR OCCURS WHILE PROCESSING FILE", exception);
		}
		return resultMap;
	}
	
	/**
	 * parseDocument function used to parse PDF document to HTML document
	 * 
	 * @param pdDocument
	 * @param resultMap
	 * 
	 * @return result map
	 * 
	 * @throws IOException
	 */
	private Map<String, Object> parseDocument(PDDocument pdDocument, Map<String, Object> resultMap, 
			List<String> componentLabelList, List<String> componentIdList, Map<String, String> componentValueMap) throws IOException{
		try {
			PDFDomTree parser = new PDFDomTree();
			Document htmlDocument = parser.createDOM(pdDocument);
			String styleHtmlString = getHeadStyles(htmlDocument);
			String bodyHtmlString = processPages(htmlDocument, componentLabelList, componentIdList, componentValueMap);
			resultMap.put(HTML_FILE,  styleHtmlString.concat(bodyHtmlString));
			resultMap.put(SUCCESS, true);
			resultMap.put(MESSAGE, FILE_PARSABLE);
			resultMap.put(INCORRECT_PASSWORD, false);
			logger.info("PDF FILE PARSED AND COVERTED TO HTML STRING SUCCESSFULLY");
		}catch(IOException exception) {
			resultMap.put(SUCCESS, false);
			resultMap.put(MESSAGE, FILE_UNPARSABLE);
			resultMap.put(INCORRECT_PASSWORD, false);
			logger.error("ERROR OCCURS WHILE PARSING FILE TO HTML", exception);
		}
		resultMap.put("value", componentValueMap);
		return resultMap;
	}
	
	/**
	 * getHeadStyles function used to get style inner text from the style tag in head
	 * 
	 * @param htmlDocument
	 * 
	 * @return style
	 */
	private String getHeadStyles(Document htmlDocument) {
		Node headNode = htmlDocument.getElementsByTagName("head").item(0);
		Element styleNode =  (Element) headNode.getLastChild();
		String styleText = "";
		/** get style tag name from the head element, and replace all default classes*/
		if(STYLE.equals(styleNode.getTagName())) {
			styleText = styleNode.getTextContent();
			styleText = styleText.replaceAll("\\.page\\{", ".nn-robotic-paste-page{")
					.replaceAll("\\.p,\\.r\\{", ".nn-robotic-paste-text, .nn-robotic-paste-img, .nn-robotic-paste-svg, .nn-robotic-paste-line, .nn-robotic-paste-unknown-element{")
					.replaceAll("\\.p\\{", ".nn-robotic-paste-text{width:auto !important; ")
					.concat(".nn-robotic-paste-img, .nn-robotic-paste-svg, .nn-robotic-paste-line, .nn-robotic-paste-unknown-element{user-select:none;}");
			styleNode.setTextContent(styleText);
		}
		return nodeToHtmlString((Node)styleNode);
	}
	
	/**
	 * processPages function used to get and manipulate page from the document
	 * 
	 * @param document
	 * 
	 * @return HTML String
	 */
	private String processPages(Document document, List<String> componentLabelList, List<String> componentIdList, Map<String, String> componentValueMap) {
		List<Element> pageList = new ArrayList<>();
		Node bodyNode = document.getElementsByTagName("body").item(0);
		if (Objects.nonNull(bodyNode)) {
			NodeList childNodes = bodyNode.getChildNodes();
			for (int i = 0; i < childNodes.getLength(); i++) {
				Element page = (Element)childNodes.item(i);
				pageList.add(page);
			}
		}
		pageList.stream().forEach(page -> 
			processElements(page, componentLabelList, componentIdList, componentValueMap));
		return nodeToHtmlString(bodyNode);
	}
	
	/**
	 * processElements function used to get all child elements from page and also performs element aggregation within the page
	 * 
	 * @param page
	 */
	private void processElements(Element page, List<String> componentLabelList, List<String> componentIdList, Map<String, String> componentValueMap) {
		List<Map<String, Object>> pageElementList = getPageElements(page);
		removeChilds(page);
		Map<Double, List<Map<String, Object>>> groupedNodesByTop = pageElementList.stream().collect(Collectors.groupingBy(elementMap -> getAsDouble(elementMap, "top")));
		Map<Double, List<Map<String, Object>>> orderedNodes = new TreeMap<>(groupedNodesByTop); 
		orderedNodes.entrySet().stream().forEach(elementMap -> manipulateElement(elementMap.getValue(), page,
				componentLabelList, componentIdList, componentValueMap));
		setCustomClass(page, "page");
	}
	
	/**
	 * getPageElements function used to get all child elements from page
	 * 
	 * @param page
	 * 
	 * @return list of page
	 */
	private List<Map<String, Object>> getPageElements(Element page) {
		List<Map<String, Object>> pageElements = new ArrayList<>();
		if(Objects.isNull(page)) {
			return pageElements;
		}
		NodeList childNodes = page.getChildNodes();
		for (int index = 0; index < childNodes.getLength(); index++) {
			Element pageElement = (Element)childNodes.item(index);
			pageElements.add(getElementStyleMap(pageElement));
		}
		return pageElements;
	}
	
	/**
	 * getElementStyleMap function used to get styles from given element 
	 * 
	 * @param pageElement
	 * 
	 * @return map of page element
	 */
	private Map<String, Object> getElementStyleMap(Element pageElement){
		Map<String, String> styleMap = getStyleMap(pageElement.getAttribute(STYLE));
		Map<String, Object> elementMap = new HashMap<>();
		elementMap.put("top", Double.valueOf(styleMap.get("top").replace("pt", "")));
		elementMap.put("left", Double.valueOf(styleMap.get("left").replace("pt", "")));
		elementMap.put(WIDTH, Double.valueOf(styleMap.get(WIDTH).replace("pt", "")));
		if(styleMap.containsKey(FONT_SIZE)) {
			elementMap.put(FONT_SIZE, Double.valueOf(styleMap.get(FONT_SIZE).replace("pt", "")));
		}
		elementMap.put(IS_LAST_ELEMENT, false);
		elementMap.put(ELEMENT, pageElement);
		return elementMap;
	}
	
	/**
	 * getStyleMap function used to get style attribute string as map  
	 * 
	 * @param styleString
	 * 
	 * @return map of element style
	 */
	private Map<String, String> getStyleMap(String styleString) {
		Map<String, String> keymaps = new HashMap<>();
		String[] list = styleString.split("[:;]");
		for (int i = 0; i < list.length; i+=2) {
			keymaps.put(list[i].trim(), list[i+1].trim());
		}
		return keymaps;
	}

	/**
	 * manipulateElement function used to reduce the small element to aggregated one 
	 * and appends as new child in page element
	 * 
	 * @param elementDetailList
	 * @param page
	 * @param componentLabelList
	 * @param componentIdList
	 * @param componentValueMap
	 */
	private void manipulateElement(List<Map<String, Object>> elementDetailList, Element page,
			List<String> componentLabelList, List<String> componentIdList, Map<String, String> componentValueMap){
		elementDetailList.sort(Comparator.comparing(elementMap -> getAsDouble(elementMap, "left")));
		int listSize = elementDetailList.size();
		elementDetailList.get(listSize - 1).put(IS_LAST_ELEMENT, true);
		AtomicReference<Element> previousElement = new AtomicReference<>(null);
		AtomicReference<Double> previousLeft = new AtomicReference<>(0.00);
		AtomicReference<Double> previousWidth = new AtomicReference<>(0.00);
		AtomicReference<String> previousTextNode = new AtomicReference<>("");
		AtomicReference<Element> labelElement = new AtomicReference<>(null);
		AtomicReference<Element> valueElement = new AtomicReference<>(null);
		elementDetailList.stream().forEach(elementMap ->{
			Element currentElement = (Element) elementMap.get(ELEMENT);
			String tagName = currentElement.getTagName();
			String defaultClass = currentElement.getAttribute(CLASS);
			/** call reduceTextElements only if the node tage name is div or p, else set custom class by tag name*/
			if("div".equals(tagName) && "p".equals(defaultClass)) {
				reduceTextElements(page, elementMap, componentValueMap, previousLeft, previousWidth, previousElement, previousTextNode, 
						labelElement, valueElement, componentLabelList, componentIdList);
			}else {
				defaultClass = StringUtils.isEmpty(defaultClass) ? tagName : defaultClass;
				setCustomClass(currentElement, defaultClass);
				page.appendChild(currentElement);
			}
		});

	}
	
	/**
	 * reduceTextElements checks and converts individual text element to single reduced element 
	 * 
	 * @param page
	 * @param elementMap
	 * @param componentValueMap
	 * @param previousLeft
	 * @param previousWidth
	 * @param previousElement
	 * @param previousTextNode
	 * @param labelElement
	 * @param valueElement
	 * @param componentLabelList
	 * @param componentIdList
	 */
	private void reduceTextElements(Element page, Map<String, Object> elementMap, Map<String, String> componentValueMap,
			AtomicReference<Double> previousLeft, AtomicReference<Double> previousWidth, AtomicReference<Element> previousElement, 
			AtomicReference<String> previousTextNode, AtomicReference<Element> labelElement, AtomicReference<Element> valueElement, 
			List<String> componentLabelList, List<String> componentIdList){
		Element currentElement = (Element)elementMap.get(ELEMENT);
		double currentElementLeft = getAsDouble(elementMap, "left");
		double currentElementWidth = getAsDouble(elementMap, WIDTH);
		double fontSize = getAsDouble(elementMap, FONT_SIZE);
		String currentTextContent = StringUtils.isEmpty(currentElement.getTextContent()) ? StringUtils.EMPTY : currentElement.getTextContent();
		boolean isLastElement = Boolean.parseBoolean(String.valueOf(elementMap.get(IS_LAST_ELEMENT)));
		if(Objects.isNull(previousElement.get())) {
			previousLeft.set(currentElementLeft);
			previousWidth.set(currentElementWidth);
			previousElement.set(currentElement);
			previousTextNode.set(currentTextContent);
			if(isLastElement) {
				page.appendChild(checkAndAppendElement(previousTextNode.get(), previousElement.get(), 
						componentLabelList, componentIdList, labelElement, valueElement, componentValueMap));
			}
		}else {
			if(isReducibleElement(fontSize, currentElementLeft, previousLeft.get(), previousWidth.get())) {
				boolean isSeparatorExists = StringUtils.containsAny(previousTextNode.get(), SEPARATORS) &&
						CONST_ONE == StringUtils.countMatches(previousTextNode.get(), ":");
				boolean isSeparator = Arrays.asList(SEPARATORS).contains(currentTextContent);
				/** checks whether the current element is a separator or contains any separator*/
				if(isSeparatorExists || isSeparator) {
					page.appendChild(checkAndAppendElement(previousTextNode.get(), previousElement.get(), 
							componentLabelList, componentIdList, labelElement, valueElement, componentValueMap));
					currentElementLeft = getCurrentLeft(currentElement, fontSize);
					previousElement.set(currentElement);
					previousTextNode.set(currentTextContent);
				}else {					
					previousTextNode.set(previousTextNode.get().concat(StringUtils.SPACE).concat(currentTextContent));
				}
				/** separately handling last element to check and append in the page*/
				if(isLastElement) {
					page.appendChild(checkAndAppendElement(previousTextNode.get(), previousElement.get(), 
							componentLabelList, componentIdList, labelElement, valueElement, componentValueMap));
				}
			}else {
				page.appendChild(checkAndAppendElement(previousTextNode.get(), previousElement.get(), 
						componentLabelList, componentIdList, labelElement, valueElement, componentValueMap));
				previousElement.set(currentElement);
				previousTextNode.set(currentTextContent);
				/** separately handling last element to check and append in the page*/
				if(isLastElement) {
					page.appendChild(checkAndAppendElement(previousTextNode.get(), previousElement.get(), 
							componentLabelList, componentIdList, labelElement, valueElement, componentValueMap));
				}
			}
			previousWidth.set(currentElementWidth);
			previousLeft.set(currentElementLeft);
		} 
	}
	
	/**
	 * checkAndAppendElement function checks and append whether the given element in label or value
	 * 
	 * @param currentTextContent
	 * @param aggregatedElement
	 * @param componentLabelList
	 * @param componentIdList
	 * @param labelElement
	 * @param valueElement
	 * @param componentValueMap
	 * 
	 * @return element
	 */
	private Element checkAndAppendElement(String currentTextContent, Element aggregatedElement, 
			List<String> componentLabelList, List<String> componentIdList, 
			AtomicReference<Element> labelElement, AtomicReference<Element> valueElement, Map<String, String> componentValueMap) {
		String elementId = aggregatedElement.getAttribute(KEY_ID).replace("p", "nn-robotic-paste-text-");
		aggregatedElement.setAttribute(KEY_ID, elementId);
		/** check whether the current element contains any separators */
		if(Arrays.asList(SEPARATORS).contains(currentTextContent)){
			return formAggregatedElement(aggregatedElement, currentTextContent, null, null);
		}else {
			checkForLableValuePair(currentTextContent, aggregatedElement, componentLabelList, componentIdList, 
					labelElement, valueElement, componentValueMap);
			return formAggregatedElement(aggregatedElement, currentTextContent, labelElement.get(), valueElement.get());
		}
	}
	
	/**
	 * checkForLableValuePair checks whether the given element in label or value
	 * 
	 * @param currentTextContent
	 * @param componentLabelList
	 * @param componentIdList
	 * @param labelElement
	 * @param valueElement
	 * @param componentValueMap
	 */
	private void checkForLableValuePair(String currentTextContent, Element aggregatedElement, 
			List<String> componentLabelList, List<String> componentIdList,
			AtomicReference<Element> labelElement, AtomicReference<Element> valueElement, Map<String, String> componentValueMap) {
		if(Objects.nonNull(labelElement.get())) {
			checkForValue(currentTextContent, aggregatedElement, labelElement, valueElement, componentValueMap);
			labelElement.set(null);
		}else {			
			checkForLabel(currentTextContent, aggregatedElement, componentIdList, componentLabelList, labelElement);
			valueElement.set(null);
		}
	}
	
	/**
	 * checkForLabel function predicts whether the label present in component Label list
	 * 
	 * @param currentTextContent
	 * @param aggregatedElement
	 * @param componentIdList
	 * @param componentLabelList
	 * @param labelElement
	 */
	private void checkForLabel(String currentTextContent, Element aggregatedElement, 
			List<String> componentIdList, List<String> componentLabelList, AtomicReference<Element> labelElement) {
		String mappingLabel = "";
		String lastCharacter = String.valueOf(currentTextContent.charAt(currentTextContent.length() - CONST_ONE));
		/** checking for separators in first character*/
		if(Arrays.asList(SEPARATORS).contains(lastCharacter)){
			mappingLabel = currentTextContent.substring(START_INDEX, currentTextContent.length() - CONST_ONE).trim().toLowerCase();
		}else {
			mappingLabel = currentTextContent.trim().toLowerCase();
		}		
		if(componentLabelList.contains(mappingLabel) 
				&& componentLabelList.indexOf(mappingLabel) != -1) {
			int labelIndex = componentLabelList.indexOf(mappingLabel);
			aggregatedElement.setAttribute(MAPPING_ID, componentIdList.get(labelIndex));
			componentLabelList.remove(labelIndex);
			componentIdList.remove(labelIndex);
		}
		labelElement.set(aggregatedElement);
	}
	
	/**
	 * checkForValue function predicts the value for the previous label
	 * 
	 * @param currentTextContent
	 * @param aggregatedElement
	 * @param labelElement
	 * @param valueElement
	 * @param componentValueMap
	 */
	private void checkForValue(String currentTextContent, Element aggregatedElement, 
			AtomicReference<Element> labelElement, AtomicReference<Element> valueElement,
			Map<String, String> componentValueMap) {
		if(Objects.isNull(labelElement.get())) {
			valueElement.set(null);
			return;
		}
		String firstCharacter = String.valueOf(currentTextContent.charAt(START_INDEX));
		/** checking for separators in first character*/
		if(Arrays.asList(SEPARATORS).contains(firstCharacter)) {
			currentTextContent = currentTextContent.replaceFirst(firstCharacter, "");
		}
		aggregatedElement.setAttribute("label-id", labelElement.get().getAttribute(KEY_ID));
		String existingValueId = labelElement.get().getAttribute("value-id");
		String valueElementId = aggregatedElement.getAttribute(KEY_ID);
		labelElement.get().setAttribute("value-id", 
				StringUtils.isNotEmpty(existingValueId) ? existingValueId.concat(":").concat(valueElementId): valueElementId);
		if(StringUtils.isNotEmpty(labelElement.get().getAttribute(MAPPING_ID))) {	
			componentValueMap.put(labelElement.get().getAttribute(MAPPING_ID), currentTextContent.trim());
			aggregatedElement.setAttribute("data-mapped", "true");
		}
		valueElement.set(aggregatedElement);
		
	}
	
	/**
	 * getCurrentLeft function calculates the current left of element
	 * 
	 * @param currentElement
	 * @param fontSize
	 * 
	 * @return currentElementLeft
	 */
	private double getCurrentLeft(Element currentElement, double fontSize) {
		double fontSpacePts = fontSize * 0.25;
		Map<String, String> elementStyleMap = getStyleMap(currentElement.getAttribute(STYLE));
		double currentElementLeft = Double.valueOf(elementStyleMap.get("left").replace("pt", "")) + fontSpacePts;
		elementStyleMap.put("left", currentElementLeft + "pt");
		AtomicReference<String> newStyleString = new AtomicReference<>("");
		elementStyleMap.entrySet().stream().forEach(styleMap -> 
			newStyleString.set(newStyleString.get()
					.concat(styleMap.getKey().replace("\"", "")).concat(":")
					.concat(styleMap.getValue().replace("\"", "")).concat(";")));
		currentElement.setAttribute(STYLE, newStyleString.get());
		return currentElementLeft;
	}
	
	/**
	 * formAggregatedElement function used to create the aggregated element from individual small element 
	 * 
	 * @param aggregatedElement
	 * @param aggregatedText
	 * 
	 * @return result element
	 */
	private Element formAggregatedElement(Element aggregatedElement, String aggregatedText, Element labelElement, Element valueElement) {
		setCustomClass(aggregatedElement, "p");
		aggregatedElement.setTextContent(aggregatedText);
		String defaultClass = aggregatedElement.getAttribute(CLASS);
		/** checks whether the lable contains mapping id & data-mapped to that element*/
		if(Objects.nonNull(labelElement) && StringUtils.isNotEmpty(labelElement.getAttribute(MAPPING_ID))) {
			aggregatedElement.setAttribute(CLASS, defaultClass.concat(" nn-robotic-paste-label"));
		}else if(Objects.nonNull(valueElement) && StringUtils.isNotEmpty(valueElement.getAttribute("data-mapped"))) {
			aggregatedElement.setAttribute(CLASS, defaultClass.concat(" nn-robotic-paste-value"));
		}
		
		return aggregatedElement;
	}
	
	/**
	 * isReducibleElement function checks whether the element can be reduced
	 * 
	 * @param fontSize
	 * @param currentLeft
	 * @param previousLeft
	 * @param previousWidth
	 * 
	 * @return boolean
	 */
	private boolean isReducibleElement(double fontSize, double currentLeft, double previousLeft, double previousWidth) {
		double spacePts = Math.abs((previousLeft + previousWidth) - currentLeft);
		double fontSpacePts = fontSize * 0.25;
		return DoubleMath.fuzzyEquals(fontSpacePts, spacePts, 2) || (fontSpacePts > spacePts);
	}
	
	/**
	 * removeChilds function used to remove default children of the page
	 * 
	 * @param parentElement
	 */
	private void removeChilds(Element parentElement) {
		while (parentElement.hasChildNodes()) {
			parentElement.removeChild(parentElement.getFirstChild());
		}
	}
	
	/**
	 * getAsDouble function used to convert object to double
	 * 
	 * @param valueMap
	 * @param key
	 * 
	 * @return result value
	 */
	private double getAsDouble(Map<String, Object> valueMap, String key) {
		Double doubleValue = 0.00;
		try {
			doubleValue = Double.valueOf(String.valueOf(valueMap.get(key)));
		}catch(NumberFormatException exception) {
			logger.error("STRING COULD NOT BE CONVERTED TO DOUBLE", exception);
		}
		return doubleValue;
	}

	/**
	 * setCustomClass function used to change default class to robotic paste classes 
	 * 
	 * @param nodeElement
	 * @param defaultClass
	 */
	private void setCustomClass(Element nodeElement, String defaultClass) {
		nodeElement.removeAttribute(CLASS);
		switch (defaultClass) {
		case "page":
			nodeElement.setAttribute(CLASS, "nn-robotic-paste-page");
			break;
		case "p":
			nodeElement.setAttribute(CLASS, "nn-robotic-paste-element nn-robotic-paste-text");
			break;
		case "r":
			nodeElement.setAttribute(CLASS, "nn-robotic-paste-element nn-robotic-paste-line");
			break;
		case "img":
			nodeElement.setAttribute(CLASS, "nn-robotic-paste-element nn-robotic-paste-img");
			break;
		case "svg":
			nodeElement.setAttribute(CLASS, "nn-robotic-paste-element nn-robotic-paste-svg");
			break;
		default:
			nodeElement.setAttribute(CLASS, "nn-robotic-paste-element nn-robotic-paste-unknown");
			break;
		}
	}
	
	/**
	 * nodeToHtmlString function converts HTML node element to string  
	 * 
	 * @param nodeElement
	 * 
	 * @return HTML String
	 */
	private String nodeToHtmlString(Node nodeElement) {
		try {
			DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
			DOMImplementationLS impl = (DOMImplementationLS)registry.getDOMImplementation("LS");
			LSSerializer writer = impl.createLSSerializer();
			LSOutput output = impl.createLSOutput();
			writer.getDomConfig().setParameter("format-pretty-print", true);
			Writer outputStream = new StringWriter();
			output.setCharacterStream(outputStream);
			writer.write(nodeElement, output);
			return outputStream.toString();
		} catch (ClassCastException | ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			throw new DocumentRuntimeException(e);
		}
	}
	
	private void addManualSelections(String userId, String screenId, List<Map<String, String>> componentList) {
		List<Map<String, Object>> selctionHistoryList = getSelectionHistory(userId, screenId);
		boolean isEmptyKey = StringUtils.isEmpty(userId) || StringUtils.isEmpty(screenId);
		if(CollectionUtils.isEmpty(selctionHistoryList) || isEmptyKey) {
			return;
		}
		Map<String, Object> selectionHistoryMap = selctionHistoryList.get(START_INDEX);
		try {			
			List<Map<String, String>> selectionHistoryList = JsonUtils.fromJsonOrThrow((
					(PGobject) selectionHistoryMap.get(COLUMN_SELECTION_HISTORY)).getValue(), List.class);
			selectionHistoryList.stream().forEach(selectionData -> 
			setManualSelections(componentList, selectionData.get(KEY_ID), selectionData.get(KEY_LABEL)));
		}catch(Exception exception) {
			logger.error("ERROR OCCURS WHILE CONVERTING SELECTION HISTORY TO LIST", exception);
		}
	}
	
	private void setManualSelections(List<Map<String, String>> componentList, String componentId, String componentLabel) {
		boolean containsKey = componentList.stream().anyMatch(componentData -> componentId.equals(componentData.get(KEY_ID)));
		if(containsKey) {
			componentList.stream().filter(componentData -> componentId.equals(componentData.get(KEY_ID)))
			.forEach(componentData -> componentData.put(KEY_LABEL, componentLabel));
		}else {
			Map<String, String> componentData = new HashMap<>();
			componentData.put(KEY_ID, componentId);
			componentData.put(KEY_LABEL, componentLabel);
			componentList.add(componentData);
		}
	}
	
	private List<Map<String, Object>> getSelectionHistory(String userId, String screenId){
		QueryBuilder queryBuilder = new QueryBuilder();
		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(COLUMN_USER_ID, userId).and().eq(COLUMN_SCREEN_ID, screenId);
		try {			
			return queryBuilder.select().get(COLUMN_SELECTION_HISTORY).from(ROBOTIC_PASTE_SELECTION_TABLE)
					.where(conditionBuilder).build(false).execute();
		}catch(Exception exception) {
			logger.error("ERROR OCCURS WHILE GETTING SELECTION HISTORY TABLE", exception);
			return new ArrayList<>();
		}
	}
	
	private void updateData(String userId, String screenId, String componentId, String componentLabel, 
			Map<String, Object> selectionHistoryMap, Map<String, Object> resultMap){
		try {			
			List<Map<String, String>> selectionHistoryList = JsonUtils.fromJsonOrThrow(String.valueOf(selectionHistoryMap.get(COLUMN_SELECTION_HISTORY)),
					new TypeReference<List<Map<String, String>>>(){});
			setManualSelections(selectionHistoryList, componentId, componentLabel);
			QueryBuilder queryBuilder = new QueryBuilder();
			ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(COLUMN_USER_ID, userId).and().eq(COLUMN_SCREEN_ID, screenId);
			queryBuilder.update().into(ROBOTIC_PASTE_SELECTION_TABLE, COLUMN_SELECTION_HISTORY, "updated_by", "updated_at")
						.where(conditionBuilder).build().execute(JsonUtils.toJsonOrNull(selectionHistoryList), userId, new Timestamp(new Date().getTime()));
			resultMap.put(SUCCESS, true);
		}catch(Exception exception) {
			logger.error("ERROR OCCURS WHILE UPDATING SELECTION HISTORY TABLE", exception);
			resultMap.put(SUCCESS, false);
		}
	}
	
	private void insertData(String userId, String screenId, String componentId, String label,
			Map<String, Object> resultMap) {
		Timestamp currentDateTime = new Timestamp(new Date().getTime());
		Map<String, String> selectionHistoryMap = new HashMap<>();
		selectionHistoryMap.put(KEY_ID, componentId);
		selectionHistoryMap.put(KEY_LABEL, label);
		List<Map<String, String>> selectionHistoryList = new ArrayList<>();
		selectionHistoryList.add(selectionHistoryMap);
		Map<String, Object> insertDataMap = new HashMap<>();
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat(COLUMN_USER_ID), userId);
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat(COLUMN_SCREEN_ID), screenId);
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat(COLUMN_SELECTION_HISTORY), JsonUtils.toJsonOrNull(selectionHistoryList));
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat("created_by"), userId);
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat("created_at"), currentDateTime);
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat("updated_by"), userId);
		insertDataMap.put(ROBOTIC_PASTE_SELECTION_TABLE.concat(".").concat("updated_at"), currentDateTime);
		try {			
			QueryBuilder queryBuilder = new QueryBuilder();
			queryBuilder.insert().insertWithMap(ROBOTIC_PASTE_SELECTION_TABLE, insertDataMap);
			resultMap.put(SUCCESS, true);
		}catch(Exception exception) {
			logger.error("ERROR OCCURS WHILE INSERTING SELECTION HISTORY TABLE", exception);
			resultMap.put(SUCCESS, false);
		}
	}
	
	private void removeSelectionHistory(String userId, String screenId, String componentId,
			Map<String, Object> selectionHistoryMap, Map<String, Object> resultMap) throws JsonConversionException, QueryException {
		List<Map<String, String>> selectionHistoryList = JsonUtils.fromJsonOrThrow(String.valueOf(selectionHistoryMap.get(COLUMN_SELECTION_HISTORY)),
				new TypeReference<List<Map<String, String>>>(){});
		boolean containsKey = selectionHistoryList.stream().anyMatch(historyData -> componentId.equals(String.valueOf(historyData.get(KEY_ID))));
		if(!containsKey) {
			resultMap.put(SUCCESS, false);
			return;
		}
		List<Map<String, String>> filteredHistoryList = selectionHistoryList.stream().filter(historyData -> 
		!componentId.equals(String.valueOf(historyData.get(KEY_ID)))).collect(Collectors.toList());
		QueryBuilder queryBuilder = new QueryBuilder();
		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(COLUMN_USER_ID, userId).and().eq(COLUMN_SCREEN_ID, screenId);
		queryBuilder.update().into(ROBOTIC_PASTE_SELECTION_TABLE, COLUMN_SELECTION_HISTORY, "updated_by", "updated_at")
					.where(conditionBuilder).build().execute(JsonUtils.toJsonOrNull(filteredHistoryList), userId, new Timestamp(new Date().getTime()));
		resultMap.put(SUCCESS, true);
	}
	
	/**
	 * DocumentRunTimeException InnerClass is a custom exception throw while converting document to HTML String
	 */
	private static class DocumentRuntimeException extends RuntimeException {
		private static final long serialVersionUID = 1L;
		private DocumentRuntimeException(Exception excpetion) {
			logger.error("EXCEPTION OCCURS WHILE CONVERTING NODE TO HTML STRING", excpetion);
		}
	}
	
	/**
	 * objectToString common function used to converts object to string  from passed map
	 * @param paramMap
	 * @param mapKey
	 * @return result string
	 */
	private String objectToString(Map<String, Object> paramMap, String mapKey){
		String resultString = STRING_EMPTY;
		if(Objects.nonNull(paramMap.get(mapKey))){
			resultString = paramMap.get(mapKey).toString();
		}
		return resultString;
	}
}
