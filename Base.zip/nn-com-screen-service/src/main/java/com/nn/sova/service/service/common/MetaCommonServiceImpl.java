package com.nn.sova.service.service.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Iterables;
import com.nn.sova.changerequest.ChangeRequestStatusEnum;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.constants.Constants;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class MetaCommonServiceImpl.
 */
public class MetaCommonServiceImpl implements MetaCommonService {

    ApplicationLogger applicationLogger = ApplicationLogger.create(MetaCommonServiceImpl.class);

    /**
     * Update change CR status.
     *
     * @param paramMap the param map
     * @throws QueryException the query exception
     */
    @Override
    public void updateChangeCRStatus(Map<String, Object> paramMap) throws QueryException {

        String changeRequstId = Objects.toString(paramMap.get("changeRequestId"), "");
        String screenType = getScreenType(paramMap);

        String status = Objects.toString(paramMap.get("status"), "");
        if (StringUtils.isNotEmpty(screenType) || StringUtils.isNotEmpty(status)) {
            String tableName = getTableName(screenType);
            if (Objects.nonNull(changeRequstId)) {
                ConditionBuilder condition = ConditionBuilder.instance();
                condition.eq("change_request_id", changeRequstId);
                QueryBuilder queryBuilder = new QueryBuilder();
                queryBuilder.update().skipTenantId(true).skipChangeRequest(true).into(tableName, "release_status")
                        .where(condition).build().execute(status);
            }
        }
    }

    /**
     * getScreenType used to get ScreenType from paramMap.
     *
     * @param paramMap the param map
     * @return the screen type
     */
    @SuppressWarnings("unchecked")
    private String getScreenType(Map<String, Object> paramMap) {
        /** meta screen */
        List<String> screenTypeList = CommonUtils.getListForReference(paramMap.get("screenType"),
                new TypeReference<String>() {
                });
        screenTypeList = CollectionUtils.isEmpty(screenTypeList)
                ? JsonUtils.fromJsonOrElse(Objects.toString(paramMap.get("screenType")), List.class,
                        new ArrayList<String>())
                : screenTypeList;
        return Iterables.getFirst(screenTypeList, "");
    }

    /**
     * getTableName used to get table name from screenType.
     *
     * @param screenType the screen type
     * @return the table name
     */
    private String getTableName(String screenType) {
        String tableName = "";
        if ("componentDef".equals(screenType)) {
            tableName = Constants.COMPONENT_DEFINITION;
        } else if ("screenDef".equals(screenType)) {
            tableName = "screen_component_configuration";
        } else if ("textDef".equals(screenType)) {
            tableName = "application_text_definition";
        } else if ("messageDef".equals(screenType)) {
            tableName = "message_definition";
        } else if ("classConfig".equals(screenType)) {
            tableName = Constants.CLASS_CONFIGURATION;
        } else if ("fwTextDef".equals(screenType)) {
            tableName = "framework_text_definition";
        } else if ("text_id".equals(screenType)) {
            tableName = "program_text_detail";
        } else if ("message_id".equals(screenType)) {
            tableName = "program_messages_detail";
        } else if ("versionMeta".equals(screenType)) {
            tableName = "version_master";
        }
        return tableName;
    }

    /**
     * Checks if is released.
     *
     * @param paramMap the param map
     * @return the map
     * @throws QueryException the query exception
     */
    @Override
    public Map<String, Object> isReleased(Map<String, Object> paramMap) throws QueryException {
        Map<String, Object> resultMap = new HashMap<>();
        boolean isReleased = false;
        String changeRequstId = Objects.toString(paramMap.get("changeRequestId"), "");
        String screenType = getScreenType(paramMap);
        String status = Objects.toString(paramMap.get("status"), "");
        applicationLogger.info("paramMap data:" + paramMap + "screenType" + screenType);
        if (StringUtils.isNotEmpty(screenType) || StringUtils.isNotEmpty(status)) {
            String tableName = getTableName(screenType);
            String offlineTableName = getOfflineTableName(screenType);
            applicationLogger.info("Table name :- " + tableName);
            if (StringUtils.isNotEmpty(changeRequstId) && StringUtils.isNotEmpty(tableName)
                    && StringUtils.isNotEmpty(offlineTableName)) {
                QueryBuilder queryBuilder = new QueryBuilder();
                Map<String, Object> dataMap = null;
                boolean isAlreadyChecked = false;
                if (Arrays.asList("message_id", "text_id", "textDef", "messageDef", "fwTextDef").contains(screenType)) {
                    dataMap = queryBuilder.select().get("release_status").from(offlineTableName)
                            .where(ConditionBuilder.instance().eq("change_request_id", changeRequstId)).build(false)
                            .execute().stream().findFirst().orElse(new HashMap<>());

                    if (MapUtils.isNotEmpty(dataMap)) {
                        isAlreadyChecked = true;
                    }
                }

                if (!isAlreadyChecked) {
                    String columnName = "release_status";
                    if ("versionMeta".equalsIgnoreCase(screenType))
                        columnName = "job_status";
                    List<Map<String, Object>> tableData = queryBuilder.select().get(columnName).from(tableName)
                            .where(ConditionBuilder.instance().eq("change_request_id", changeRequstId)).build(false)
                            .execute();
                    dataMap = tableData.stream().findFirst().orElse(new HashMap<>());
                    if ("versionMeta".equals(screenType)) {
                        List<Map<String, Object>> notReleasedList = tableData.stream()
                                .filter(predicate -> ChangeRequestStatusEnum.NOT_RELEASED.name()
                                        .equalsIgnoreCase(Objects.toString(predicate.get("job_status"))))
                                .collect(Collectors.toList());
                        applicationLogger.info("Version master not released list " + notReleasedList);
                        if (CollectionUtils.isNotEmpty(notReleasedList))
                            dataMap = notReleasedList.stream().findFirst().orElse(new HashMap<>());
                    }
                    String releaseStatus = Objects.toString(dataMap.get(columnName), "");
                    isReleased = ChangeRequestStatusEnum.DELIVERED.name().equals(releaseStatus)
                            || ChangeRequestStatusEnum.RELEASED.name().equals(releaseStatus);
                    if (MapUtils.isEmpty(dataMap) || StringUtils.isEmpty(releaseStatus)) {
                        isReleased = true;
                    }
                }
            } else {
                applicationLogger.info("ScreenType : " + screenType + ", ChangeRequest Id : " + changeRequstId);
            }
        }
        resultMap.put("status", isReleased);

        return resultMap;
    }

    /**
     * Gets the offline table name.
     *
     * @param screenType the screen type
     * @return the offline table name
     */
    private String getOfflineTableName(String screenType) {
        String tableName = "";
        if ("componentDef".equals(screenType)) {
            tableName = Constants.COMPONENT_DEFINITION;
        } else if ("screenDef".equals(screenType)) {
            tableName = "screen_component_configuration";
        } else if ("textDef".equals(screenType)) {
            tableName = "application_text_definition_offline";
        } else if ("messageDef".equals(screenType)) {
            tableName = "message_definition_offline";
        } else if ("classConfig".equals(screenType)) {
            tableName = Constants.CLASS_CONFIGURATION;
        } else if ("fwTextDef".equals(screenType)) {
            tableName = "framework_text_definition_offline";
        } else if ("text_id".equals(screenType)) {
            tableName = "program_text_detail_offline";
        } else if ("message_id".equals(screenType)) {
            tableName = "program_messages_detail_offline";
        } else if ("versionMeta".equals(screenType)) {
            tableName = "version_master";
        }
        return tableName;
    }

}
