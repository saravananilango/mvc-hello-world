package com.nn.sova.service.mastersearch.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.stereotype.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.common.CommonCacheService;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.mastersearch.dao.InputLearningDao;
import com.nn.sova.service.mastersearch.model.InputLearningParameters;
import com.nn.sova.service.mastersearch.model.MasterInputLearningParameters;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.utility.cache.CacheGetService;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * CommonController class is to to perform user input learning.
 * @author Logchand
 *
 */
@Controller
@SovaMapping("/function/inputlearning")
public class CommonController {

    /** The Constant LOGGER. */
    private static final ApplicationLogger LOGGER = ApplicationLogger.create(CommonController.class);

    /** The Constant SCREEN_ID. */
    private static final String SCREEN_ID = "screenId";

    /** The Constant COMPONENT_ID. */
    private static final String COMPONENT_ID = "componentId";

    /** The Constant LEARN_VALUE. */
    private static final String LEARN_VALUE = "learnValue";

    /** The Constant SEARCH_ID. */
    private static final String SEARCH_ID = "searchId";

    /**
	 * requestSuggestion method is used to set the suggestion for the input
	 * components.
	 *
	 * @param dataMap the data map
	 * @return suggestions
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@SovaMapping(value = "/userinputlearning/request", method = SovaRequestMethod.POST)
    public String requestSuggestion(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String componentId = dataMap.get(COMPONENT_ID).toString().trim();
        String currentValue = dataMap.get(LEARN_VALUE).toString().trim();
        InputLearningParameters parameters = new InputLearningParameters();
        parameters.setComponentId(componentId);
        parameters.setLearningValue(currentValue);
        parameters.setScreenId(screenId);
        parameters.setUserId(userId);
        List<Object> suggestionList = InputLearningDao.loadLearnValue(parameters, getRedisCacheKeyFormat(userId, screenId, componentId));
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(suggestionList);
    }

    /**
	 * inputLearning method is to learn the user inputs for a component.
	 *
	 * @param dataMap the data map
	 * @return the string
	 */
	@SovaMapping(value = "/userinputlearning/learning", method = SovaRequestMethod.POST)
    public String inputLearning(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String componentId = dataMap.get(COMPONENT_ID).toString().trim();
        String learnValue = dataMap.get(LEARN_VALUE).toString().trim();
        InputLearningParameters parameters = new InputLearningParameters();
        parameters.setComponentId(componentId);
        parameters.setLearningValue(learnValue);
        parameters.setScreenId(screenId);
        parameters.setUserId(userId);
        return InputLearningDao.checkHistory(parameters, getRedisCacheKeyFormat(userId, screenId, componentId));
    }

    /**
	 * removeHistory method is used to remove the history of a particular component.
	 *
	 * @param dataMap the data map
	 */
	@SovaMapping(value = "/userinputlearning/delete", method = SovaRequestMethod.POST)
    public void removeHistory(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String componentId = dataMap.get(COMPONENT_ID).toString().trim();
        InputLearningDao.removeHistory(screenId, userId, componentId, getRedisCacheKeyFormat(userId, screenId, componentId));
    }

    /**
	 * getRedisCacheData method will return redis data to js.
	 *
	 * @param dataMap the data map
	 * @return the redis cache data
	 */
	@SovaMapping(value = "/userinputlearning/getRedisData", method = SovaRequestMethod.POST)
    public String getRedisCacheData(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String componentId = dataMap.get(COMPONENT_ID).toString().trim();
        String cacheKey = getRedisCacheKeyFormat(userId, screenId, componentId);
        Object result = CacheGetService.getInstance().getCustomCacheData(cacheKey);
        if (Objects.nonNull(result)) {
            return Objects.toString(result, "");
        } else {
            return null;
        }
    }

    /**
	 * getCompleteHistory will get all the records from history table.
	 *
	 * @param dataMap the data map
	 * @return the complete history
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@SovaMapping(value = "/userinputlearning/loadAllHistory", method = SovaRequestMethod.POST)
    public String getCompleteHistory(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String componentId = dataMap.get(COMPONENT_ID).toString().trim();
        String cacheKey = getRedisCacheKeyFormat(userId, screenId, componentId);
        ObjectMapper mapper = new ObjectMapper();
        List<String> finalArray = new ArrayList<>();
        String array = Objects.toString(CacheGetService.getInstance().getCustomCacheData(cacheKey), "");
        if (StringUtils.isNotEmpty(array)) {
            try {
                JSONArray jsonArray = new JSONArray(array);
                for (int index = 0; index < jsonArray.length(); index++) {
                    String value = jsonArray.getString(index);
                    if (!finalArray.contains(value)) {
                        finalArray.add(value);
                    }
                }
            } catch (JSONException exception) {
                LOGGER.error(exception);
            }
        }
        return mapper.writeValueAsString(finalArray);
    }

    /**
	 * insertMasterData method will insert master data in db.
	 *
	 * @param dataMap the data map
	 * @return the string
	 */
	@SovaMapping(value = "/userinputlearning/learnMasterData", method = SovaRequestMethod.POST)
    public String insertMasterData(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        String setText = dataMap.get("setText").toString().trim();
        String showText = dataMap.get("showText").toString().trim();
        String cacheKey = getRedisMasterKeyFormat(userId, screenId, searchId);
        MasterInputLearningParameters masterLearningData = new MasterInputLearningParameters(searchId, setText, showText, screenId, userId);
        return InputLearningDao.learnMasterData(masterLearningData, cacheKey);
    }

    /**
	 * requestMasterDataByUser method will get master data based on user.
	 *
	 * @param dataMap the data map
	 * @return the string
	 */
	@SovaMapping(value = "/userinputlearning/loadUserMasterData", method = SovaRequestMethod.POST)
    public String requestMasterDataByUser(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        String cacheKey = getRedisMasterKeyFormat(userId, screenId, searchId);
        Object historyData = CacheGetService.getInstance().getCustomCacheData(cacheKey);
        MasterInputLearningParameters masterLearningData = new MasterInputLearningParameters(searchId, null, null, screenId, userId);
        if (Objects.nonNull(historyData)) {
            return InputLearningDao.validateHistory(Objects.toString(historyData, ""), masterLearningData, cacheKey);
        } else {
            return InputLearningDao.loadMasterDataFromDatabase(masterLearningData, cacheKey);
        }
    }

    /**
	 * requestMasterDataByservice method will get master data based on service.
	 *
	 * @param dataMap the data map
	 * @return the string
	 */
	@SovaMapping(value = "/userinputlearning/loadServiceMasterData", method = SovaRequestMethod.POST)
    public String requestMasterDataByservice(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String userId = UserContext.getInstance().getUserName();
        String screenId = dataMap.get(SCREEN_ID).toString().trim();
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        String tenantId = UserContext.getInstance().getTenantId();
        String cacheKey = tenantId.concat("_").concat(searchId.trim()).concat("_").concat(screenId.trim());
        MasterInputLearningParameters masterLearningData = new MasterInputLearningParameters(searchId, null, null, screenId, userId);
        Set<String> keysList = CommonCacheService.getInstance().getPartialCacheKeysByPrefixValue(cacheKey);
        List<String> values = getRedisMultiKeymasterData(keysList, masterLearningData);
        return values.toString();
    }

    /**
	 * getRedisCacheKeyFormat method will return cache key in the cache format.
	 *
	 * @param userId      the user id
	 * @param screenId    the screen id
	 * @param componentId the component id
	 * @return the redis cache key format
	 */
    public String getRedisCacheKeyFormat(String userId, String screenId, String componentId) {
        String tenantId = UserContext.getInstance().getTenantId();
        return tenantId.concat("_").concat(screenId.trim()).concat("_").concat(componentId.trim()).concat("_").concat(userId.trim()).concat("_hd");
    }

    /**
	 * getRedisMasterKeyFormat will return the key in master format.
	 *
	 * @param userId   the user id
	 * @param screenId the screen id
	 * @param searchId the search id
	 * @return the redis master key format
	 */
    public String getRedisMasterKeyFormat(String userId, String screenId, String searchId) {
        String tenantId = UserContext.getInstance().getTenantId();
        return tenantId.concat("_").concat(searchId.trim()).concat("_").concat(screenId.trim()).concat("_").concat(userId.trim()).concat("_hd");
    }

    /**
	 * getRedisMultiKeyData will return data based on a set of keys from cache.
	 *
	 * @param keyList the key list
	 * @return the redis multi key data
	 */
    public List<String> getRedisMultiKeyData(Set<String> keyList) {
        List<String> finalArray = new ArrayList<>();
        keyList.stream().forEach(key -> {
            String array = String.valueOf(CacheGetService.getInstance().getCustomCacheData(key));
            if (StringUtils.isNotEmpty(array)) {
                try {
                    JSONArray jsonArray = new JSONArray(array);
                    for (int index = 0; index < jsonArray.length(); index++) {
                        String value = jsonArray.getString(index);
                        if (!finalArray.contains(value))
                            finalArray.add(value);
                    }
                } catch (JSONException exception) {
                    LOGGER.error(exception);
                }
            }
        });
        return finalArray;
    }

    /**
	 * getRedisMultiKeymasterData will get the data based on set of keys from
	 * master.
	 *
	 * @param keyList            the key list
	 * @param masterLearningData the master learning data
	 * @return the redis multi keymaster data
	 */
    public List<String> getRedisMultiKeymasterData(Set<String> keyList, MasterInputLearningParameters masterLearningData) {
        List<String> finalArray = new ArrayList<>();
        keyList.stream().forEach(key -> {
            String userArray = Objects.toString(CacheGetService.getInstance().getCustomCacheData(key), "");
            if (StringUtils.isNotEmpty(userArray)) {
                String array = InputLearningDao.validateHistory(userArray, masterLearningData, key);
                if (StringUtils.isNotEmpty(array)) {
                    try {
                        JSONArray jsonArray = new JSONArray(array);
                        for (int index = 0; index < jsonArray.length(); index++) {
                            String value = jsonArray.getString(index);
                            if (!finalArray.contains(value))
                                finalArray.add(value);
                        }
                    } catch (JSONException exception) {
                        LOGGER.error(exception);
                    }
                }
            }
        });
        return finalArray;
    }
}
