package com.nn.sova.service.utils.tabledefinition.tabletemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.postgresql.util.PGobject;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.service.constants.tabledefinition.TableDefinitionConstants;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.util.entity.ForeignKeyColumnReferenceEntity;
import com.nn.sova.util.entity.ForeignKeyTableReferenceEntity;
import com.nn.sova.util.entity.ForeignKeyTableReferenceEntity.MatchEnum;
import com.nn.sova.util.entity.IndexTableColumnDefinitionEntity;
import com.nn.sova.util.entity.TableColumnDefinitionEntity;
import com.nn.sova.util.enums.OnchangeActionEnum;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;
import com.nn.sova.service.utils.tabledefinition.TableDefinitionUtils;

/**
 * CreateTableTemplate CLASS used for creating tables with predefined keys and
 * structure
 * 
 * @author MOHAN RAM
 *
 */
public class CreateTableTemplate {

	private static final String DATA_ENCRYPTION_FLAG = ".dataEncryptionFlag";
	private static final String DEFAULT_VALUE2 = ".defaultValue";
	private static final String LENGTH = ".length";
	private static final String DATA_TYPE2 = ".dataType";
	private static final String DATA_TYPE = "data_type";
	private static final String AUTONUMBER_FLAG = ".autonumberFlag";
	private static final String AUTONUMBER = "autonumber";
	private static final String DATA_ELEMENT = ".dataElement";
	private static final String DATA_FORMAT = ".dataFormat";
	private static final String PRECISION = "precision";
	private static final String DEFAULT_VALUE = "default_value";
	private static final String DECIMAL_VALUE = "decimal_value";
	private static final String MAX_LENGTH = "max_length";
	private static final String COLUMN_NAME = ".columnName";
	/**
	 * logger for CreateTableTemplate class
	 */
	private static ApplicationLogger logger = ApplicationLogger.create(CreateTableTemplate.class);

	/**
	 * createTable method used for table creation
	 * 
	 * @param createTableQueryExecutor contains table creation connection
	 * @param resultMap                contains table details
	 * @throws CustomException when exception occurs at table creation
	 */
	@SuppressWarnings("unchecked")
	public static void createTable(QueryExecutor createTableQueryExecutor, Map<String, Object> resultMap)
			throws CustomException {
		logger.info("createTable method execution started.");
		try {
			String tableName = String.valueOf(resultMap.get(TableDefinitionConstants.TABLENAME));
			String applicationName = String.valueOf(resultMap.get(TableDefinitionConstants.PRODUCT_CODE));
			List<Map<String, Object>> langDependentColumnList = new ArrayList<>();
			List<String> primaryKeyList = new ArrayList<>();
			List<TableColumnDefinitionEntity> mainTableColumnDefinitionList = generateTableColumnDefinitionEntity(
					resultMap, langDependentColumnList, primaryKeyList);
			if (resultMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_MAP)
					&& resultMap.get(TableDefinitionConstants.TABLE_DEFINITION_MAP) instanceof List
					&& !((List<Map<String, Object>>) (resultMap.get(TableDefinitionConstants.TABLE_DEFINITION_MAP)))
							.isEmpty()
					&& (boolean) (((List<Map<String, Object>>) (resultMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_MAP))).get(0)
									.get(TableDefinitionConstants.TABLE_DEFINITION_MAIN + DATA_ENCRYPTION_FLAG))) {
				addEncryptionColumn(mainTableColumnDefinitionList);
			}
			ForeignKeyTableReferenceEntity langDependentForeignEntity = new ForeignKeyTableReferenceEntity();
			List<TableColumnDefinitionEntity> langTableColumnDefinitionList = new ArrayList<>();
			if (langDependentColumnList.size() != primaryKeyList.size()) {
				logger.info("table contains lang dependent table.");
				langTableColumnDefinitionList = landependentAddTableList(langDependentColumnList, resultMap);
				addingForeignKeyContraintsForLangDependent(tableName, langDependentForeignEntity, primaryKeyList);
				addLocaleColumnDetails(langTableColumnDefinitionList);
			}
			List<ForeignKeyTableReferenceEntity> mainTableForeignKeyTableReferenceEntityList = checkForeignKeyList(
					resultMap);
			Map<String, List<String>> uniqueKeyList = checkUniqueKeyList(resultMap);
			List<IndexTableColumnDefinitionEntity> indexTableEntities = checkIndexKeyList(resultMap);
			createTableQueryExecutor.queryBuilder().table().createtable().tableName(tableName)
					.setProductCode(applicationName).productCode(applicationName).columns(mainTableColumnDefinitionList)
					.foreignKeyConstraint(mainTableForeignKeyTableReferenceEntityList).uniqueConstraint(uniqueKeyList)
					.primaryKeyConstraint(primaryKeyList).build().execute();
			if (!langTableColumnDefinitionList.isEmpty()) {
				primaryKeyList.add("locale");
				createTableQueryExecutor.queryBuilder().table().createtable().productCode(applicationName)
						.setProductCode(applicationName).tableName(tableName + "_text")
						.columns(langTableColumnDefinitionList)
						.foreignKeyConstraint(Arrays.asList(langDependentForeignEntity))
						.primaryKeyConstraint(primaryKeyList).build().execute();
			}
			if (!indexTableEntities.isEmpty()) {
				createTableQueryExecutor.queryBuilder().table().createIndex().setProductCode(applicationName)
						.indexTablesDetails(indexTableEntities).build().execute();
			}
		} catch (Exception exception) {
			logger.error("Exception occured at createTable method" + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("createTable method execution ended.");
		resultMap.put("tableCreated", true);
		resultMap.put("sourceCodeGenerate", true);
	}

	/**
	 * addEncryptionColumn to add encryption column
	 * 
	 * @param mainTableColumnDefinitionList
	 */
	private static void addEncryptionColumn(List<TableColumnDefinitionEntity> mainTableColumnDefinitionList) {
		TableColumnDefinitionEntity tableColumnDefinitionEntity = new TableColumnDefinitionEntity();
		tableColumnDefinitionEntity.setcolumnName(TableDefinitionConstants.TABLE_DEFINITION_ENCRYPT_KEY);
		tableColumnDefinitionEntity
				.setdataType(TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
		mainTableColumnDefinitionList.add(tableColumnDefinitionEntity);

	}

	/**
	 * 
	 * @param langTableColumnDefinitionList
	 */
	private static void addLocaleColumnDetails(List<TableColumnDefinitionEntity> langTableColumnDefinitionList) {
		TableColumnDefinitionEntity localeColumnDefinitionEntity = new TableColumnDefinitionEntity();
		localeColumnDefinitionEntity.setcolumnName("locale");
		localeColumnDefinitionEntity
				.setdataType(TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
		localeColumnDefinitionEntity.setisNotNull(true);
		langTableColumnDefinitionList.add(localeColumnDefinitionEntity);
	}

	/**
	 * checkIndexKeyList used to check index present
	 * 
	 * @param resultMap contains index constraint details
	 * @return indexEntityList contains index list
	 * @throws CustomException when getting index exception
	 */
	@SuppressWarnings("unchecked")
	private static List<IndexTableColumnDefinitionEntity> checkIndexKeyList(Map<String, Object> resultMap)
			throws CustomException {
		logger.info("checkIndexKeyList method execution started.");
		List<IndexTableColumnDefinitionEntity> indexEntityList = new ArrayList<>();
		try {
			List<Map<String, Object>> indexKeyDetailsList = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP);
			if (indexKeyDetailsList.isEmpty()) {
				logger.info("No index entries");
			} else {
				for (Map<String, Object> indexDetails : indexKeyDetailsList) {
					IndexTableColumnDefinitionEntity indexEntity = new IndexTableColumnDefinitionEntity();
					indexEntity.setIndexColumnNames((List<String>) JsonUtils.fromJsonOrThrow(((PGobject) indexDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".columnNames"))
									.getValue(),
							List.class));
					indexEntity.setIndexName(String.valueOf(indexDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".indexName")));
					indexEntity.setTableName(String.valueOf(indexDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".tableName")));
					indexEntityList.add(indexEntity);
				}
			}
		} catch (Exception exception) {
			logger.error("Exception occured at checkForeignKeyList method" + exception);
			logger.info("checkIndexKeyList method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("checkIndexKeyList method execution ended.");
		return indexEntityList;
	}

	/**
	 * checkUniqueKeyList method used for check unique constraint
	 * 
	 * @param resultMap contains unique constraint details
	 * @return uniqueKeyMap that contains unique key details
	 * @throws CustomException when error occurred at getting unique key details
	 */
	@SuppressWarnings("unchecked")
	private static Map<String, List<String>> checkUniqueKeyList(Map<String, Object> resultMap) throws CustomException {
		logger.info("checkUniqueKeyList method execution started.");
		Map<String, List<String>> uniqueKeyMap = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		try {
			List<Map<String, Object>> uniqueConstraintList = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP);
			if (uniqueConstraintList.isEmpty()) {
				logger.info("No unique constraint details");
			} else {
				for (Map<String, Object> uniqueKeyDetailsMap : uniqueConstraintList) {
					uniqueKeyMap.put(
							uniqueKeyDetailsMap.get(
									TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + ".uniqueKeyName")
									.toString(),
							(List<String>) JsonUtils.fromJsonOrThrow(((PGobject) uniqueKeyDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN
											+ ".uniqueColumnDetails")).getValue(),
									List.class));
				}
			}
		} catch (Exception exception) {
			logger.error("Exception occured at checkUniqueKeyList method" + exception);
			logger.info("checkUniqueKeyList method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("checkUniqueKeyList method execution ended.");
		return uniqueKeyMap;
	}

	/**
	 * checkForeignKeyList used for check foreign constraint details present
	 * 
	 * @param resultMap contains foreign constraint details
	 * @return foreignKeyTableReferenceEntityList contains foreign key details
	 * @throws CustomException when getting foreign constraint details
	 */
	@SuppressWarnings("unchecked")
	private static List<ForeignKeyTableReferenceEntity> checkForeignKeyList(Map<String, Object> resultMap)
			throws CustomException {
		logger.info("checkForeignKeyList method execution started.");
		List<ForeignKeyTableReferenceEntity> foreignKeyTableReferenceEntityList = new ArrayList<>();
		try {
			List<Map<String, Object>> foreignKeyList = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP);
			if (foreignKeyList.isEmpty()) {
				logger.info("No foreign key details");
			} else {
				foreignKeyList.forEach(foreignKeyDetails -> {
					ForeignKeyTableReferenceEntity foreignKeyTableReferenceEntity = new ForeignKeyTableReferenceEntity();
					List<ForeignKeyColumnReferenceEntity> foreignKeyColumnReferenceEntityList = new ArrayList<>();
					try {
						for (Map.Entry<String, String> entry : ((Map<String, String>) JsonUtils
								.fromJsonOrThrow(((PGobject) foreignKeyDetails
										.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
												+ ".foreignKeyColumnDetails")).getValue(),
										Map.class)).entrySet()) {
							ForeignKeyColumnReferenceEntity foreignKeyColumnReferenceEntity = new ForeignKeyColumnReferenceEntity();
							foreignKeyColumnReferenceEntity.setLocalColumnName(entry.getKey());
							foreignKeyColumnReferenceEntity.setReferenceColumnName(entry.getValue());
							foreignKeyColumnReferenceEntityList.add(foreignKeyColumnReferenceEntity);
						}
					} catch (JsonConversionException exception) {
						logger.error(exception);
					}
					foreignKeyTableReferenceEntity.setcolumnList(foreignKeyColumnReferenceEntityList);
					foreignKeyTableReferenceEntity.setconstraintName(String.valueOf(foreignKeyDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".foreignKeyName")));
					foreignKeyTableReferenceEntity.setMatchType(MatchEnum.SIMPLE);
					foreignKeyTableReferenceEntity.setOnDelete(OnchangeActionEnum.NO_ACTION);
					foreignKeyTableReferenceEntity.setOnUpdate(OnchangeActionEnum.NO_ACTION);
					foreignKeyTableReferenceEntity.setreferenceTableName(String.valueOf(foreignKeyDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".referenceTable")));
					foreignKeyTableReferenceEntityList.add(foreignKeyTableReferenceEntity);
				});
			}
		} catch (Exception exception) {
			logger.error("Exception occured at checkForeignKeyList method" + exception);
			logger.info("checkForeignKeyList method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("checkForeignKeyList method execution ended.");
		return foreignKeyTableReferenceEntityList;
	}

	/**
	 * addingForeignKeyContraintsForLangDependent method is used to add foreign
	 * constraint by default for lang table
	 * 
	 * @param tableName                      table for foreign key constraint
	 * @param foreignKeyTableReferenceEntity set foreign key details for lang
	 *                                       dependent
	 */
	public static void addingForeignKeyContraintsForLangDependent(String tableName,
			ForeignKeyTableReferenceEntity foreignKeyTableReferenceEntity, Iterable<String> primaryKeyColumns) {
		logger.info("addingForeignKeyContraintsForLangDependent method execution started.");
		foreignKeyTableReferenceEntity.setconstraintName(tableName.concat("_lang_fkey_lang"));
		foreignKeyTableReferenceEntity.setreferenceTableName(tableName);
		foreignKeyTableReferenceEntity.setMatchType(MatchEnum.SIMPLE);
		foreignKeyTableReferenceEntity.setOnDelete(OnchangeActionEnum.NO_ACTION);
		foreignKeyTableReferenceEntity.setOnUpdate(OnchangeActionEnum.NO_ACTION);
		foreignKeyTableReferenceEntity.setLangDependent(true);
		List<ForeignKeyColumnReferenceEntity> foreignKeyColumnReferenceList = new ArrayList<>();
		primaryKeyColumns.forEach(columnName -> {
			ForeignKeyColumnReferenceEntity foreignKeyColumnReference = new ForeignKeyColumnReferenceEntity();
			foreignKeyColumnReference.setLocalColumnName(columnName);
			foreignKeyColumnReference.setReferenceColumnName(columnName);
			foreignKeyColumnReferenceList.add(foreignKeyColumnReference);
		});
		foreignKeyTableReferenceEntity.setcolumnList(foreignKeyColumnReferenceList);
		logger.info("addingForeignKeyContraintsForLangDependent method execution ended.");
	}

	/**
	 * 
	 * @param langDependentColumnList
	 * @param resultMap               contains table details
	 */
	public static List<TableColumnDefinitionEntity> landependentAddTableList(
			List<Map<String, Object>> langDependentColumnList, Map<String, Object> resultMap) throws CustomException {
		logger.info("landependentAddTableList method execution started.");
		List<TableColumnDefinitionEntity> tableColumnDefintionList = new ArrayList<>();
		try {
			for (Map<String, Object> tableColumnMap : langDependentColumnList) {
				logger.info("getting column details"
						+ tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)
						+ "started");
				primaryTableDetailsMap(resultMap, new ArrayList<>(), new ArrayList<>(), tableColumnDefintionList,
						tableColumnMap);
				logger.info("getting column details"
						+ tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)
						+ "ended.");
			}
		} catch (Exception exception) {
			logger.error("Error occured at landependentAddTableList method  " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("landependentAddTableList method execution ended.");
		return tableColumnDefintionList;
	}

	/**
	 * generateTableColumnDefinitionEntity used to generate main table column list
	 * 
	 * @param resultMap               column details
	 * @param langDependentColumnList details of lang dependent columns
	 * @param primaryKeyList          main table primary key list
	 * @return List<TableColumnDefinitionEntity> contains column details in entity
	 */
	@SuppressWarnings("unchecked")
	private static List<TableColumnDefinitionEntity> generateTableColumnDefinitionEntity(Map<String, Object> resultMap,
			List<Map<String, Object>> langDependentColumnList, List<String> primaryKeyList) throws CustomException {
		logger.info("generateTableColumnDefinitionEntity method execution started.");
		List<TableColumnDefinitionEntity> tableColumnDefintionList = new ArrayList<>();
		try {
			List<Map<String, Object>> tableColumnDetails = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP);
			for (Map<String, Object> tableColumnMap : tableColumnDetails) {
				logger.info("getting column details "
						+ tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)
						+ "started");
				if (Objects
						.nonNull(tableColumnMap.get(
								TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
						&& Boolean.parseBoolean(String.valueOf(
								tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
										+ ".langDependentFlag")))) {
					logger.info("Lang dependent column ");
					langDependentColumnList.add(tableColumnMap);
				} else {
					primaryTableDetailsMap(resultMap, langDependentColumnList, primaryKeyList, tableColumnDefintionList,
							tableColumnMap);
				}
				logger.info("getting column details "
						+ tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)
						+ "ended.");
			}
		} catch (Exception exception) {
			logger.error("Error occured at generateTableColumnDefinitionEntity method  " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("generateTableColumnDefinitionEntity method execution ended.");
		return tableColumnDefintionList;
	}

	/**
	 * primaryTableDetailsMap method used for setting primary and adding column
	 * details
	 * 
	 * @param resultMap                contains data class details
	 * @param langDependentColumnList  contains lang dependent details
	 * @param primaryKeyList           contains primary key details
	 * @param tableColumnDefintionList contains table column details entity
	 * @param tableColumnMap           contains table column details map
	 */
	@SuppressWarnings("unchecked")
	private static void primaryTableDetailsMap(Map<String, Object> resultMap,
			List<Map<String, Object>> langDependentColumnList, List<String> primaryKeyList,
			List<TableColumnDefinitionEntity> tableColumnDefintionList, Map<String, Object> tableColumnMap) {
		logger.info("primaryTableDetailsMap method execution started.");
		TableColumnDefinitionEntity tableColumnDefinitionEntity = new TableColumnDefinitionEntity();
		Map<String, Object> dataElementDetailsMap = new HashMap<>();
		Map<String, Object> dataFormatDetailsMap = new HashMap<>();
		if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
				&& !tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT)
						.toString().isBlank()) {
			dataElementDetailsMap = ((Map<String, List<Map<String, Object>>>) resultMap
					.get(TableDefinitionConstants.DATA_ELEMENT_DETAILS))
							.get(tableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
							.get(0);
			tableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
					Objects.nonNull(dataElementDetailsMap.get(AUTONUMBER))
							&& (boolean) dataElementDetailsMap.get(AUTONUMBER));
		} else if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
				&& !tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT)
						.toString().isBlank()) {
			dataFormatDetailsMap = ((Map<String, List<Map<String, Object>>>) resultMap
					.get(TableDefinitionConstants.DATA_FORMAT_DETAILS))
							.get(tableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
							.get(0);
			tableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
					Objects.nonNull(dataFormatDetailsMap.get(AUTONUMBER))
							&& (boolean) dataFormatDetailsMap.get(AUTONUMBER));
		}

		setPrimaryKeyAndNotNull(langDependentColumnList, primaryKeyList, tableColumnMap, tableColumnDefinitionEntity);
		if (Objects
				.nonNull(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))
				&& Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG)))) {
			tableColumnDefinitionEntity
					.setdataType(TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
		} else if (!dataElementDetailsMap.isEmpty()) {
			setDataTypeAndLength(tableColumnDefinitionEntity, dataElementDetailsMap);
		} else if (!dataFormatDetailsMap.isEmpty()) {
			setDataTypeAndLength(tableColumnDefinitionEntity, dataFormatDetailsMap);
		} else {
			dataElementAndDataTypeNotMentioned(tableColumnMap, tableColumnDefinitionEntity);
		}
		tableColumnDefinitionEntity.setcolumnName(String.valueOf(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
		tableColumnDefintionList.add(tableColumnDefinitionEntity);
		logger.info("primaryTableDetailsMap method execution ended.");
	}

	/**
	 * dataElementAndDataTypeNotMentioned method used when *** for data element and
	 * data class
	 * 
	 * @param tableColumnMap              contains data type details
	 * @param tableColumnDefinitionEntity when data type is set
	 */
	private static void dataElementAndDataTypeNotMentioned(Map<String, Object> tableColumnMap,
			TableColumnDefinitionEntity tableColumnDefinitionEntity) {
		logger.info("dataElementAndDataTypeNotMentioned method execution started.");
		if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE2))
				&& !StringUtils.isEmpty(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE2).toString()
						.trim())) {
			tableColumnDefinitionEntity.setdefaultValue(String.valueOf(tableColumnMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE2)));
		}
		if (String
				.valueOf(TableDefinitionUtils.convertDataType(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)))
				.equals(TableDefinitionConstants.NUMERIC_DATATYPE)
				&& Objects.nonNull(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
				&& !String
						.valueOf(tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						.isEmpty()) {
			tableColumnDefinitionEntity.setLength(Integer.parseInt(String
					.valueOf(tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
					.split(",")[0]));
			if (String
					.valueOf(tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
					.contains(",")) {
				tableColumnDefinitionEntity.setPrecision(Integer.parseInt(String
						.valueOf(tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						.split(",")[1]));
			}
		}
		if (String
				.valueOf(TableDefinitionUtils.convertDataType(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)))
				.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)
				&& Objects.nonNull(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
				&& !String
						.valueOf(tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						.isEmpty()) {
			tableColumnDefinitionEntity.setLength(Integer.parseInt(String.valueOf(
					tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))));
		}
		tableColumnDefinitionEntity.setdataType(TableDefinitionUtils.convertDataType(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)));
		logger.info("dataElementAndDataTypeNotMentioned method execution ended.");
	}

	/**
	 * setDataTypeAndLength method used for setting data type and length
	 * 
	 * @param tableColumnDefinitionEntity contains column details in entity
	 * @param dataElementDetailsMap       contains length, data type and default
	 *                                    value details
	 */
	private static void setDataTypeAndLength(TableColumnDefinitionEntity tableColumnDefinitionEntity,
			Map<String, Object> dataElementDetailsMap) {
		logger.info("setDataTypeAndLength method execution started.");
		tableColumnDefinitionEntity
				.setdataType(TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE)));
		if (Objects.nonNull(dataElementDetailsMap.get(DEFAULT_VALUE))
				&& !StringUtils.isEmpty(dataElementDetailsMap.get(DEFAULT_VALUE).toString().trim())) {
			tableColumnDefinitionEntity.setdefaultValue(String.valueOf(dataElementDetailsMap.get(DEFAULT_VALUE)));
		}
		if (String.valueOf(TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE))).equals(
				TableDefinitionConstants.NUMERIC_DATATYPE) && Objects.nonNull(dataElementDetailsMap.get(PRECISION))
				&& !String.valueOf(dataElementDetailsMap.get(PRECISION)).isEmpty()) {
			tableColumnDefinitionEntity
					.setLength(Integer.parseInt(String.valueOf(dataElementDetailsMap.get(PRECISION))));
			if (Objects.nonNull(dataElementDetailsMap.get(DECIMAL_VALUE))
					&& !String.valueOf(dataElementDetailsMap.get(DECIMAL_VALUE)).isEmpty()) {
				tableColumnDefinitionEntity
						.setPrecision(Integer.parseInt(String.valueOf(dataElementDetailsMap.get(DECIMAL_VALUE))));
			}
		}
		if (String.valueOf(TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE)))
				.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)
				&& Objects.nonNull(dataElementDetailsMap.get(MAX_LENGTH))
				&& !String.valueOf(dataElementDetailsMap.get(MAX_LENGTH)).isEmpty()) {
			tableColumnDefinitionEntity
					.setLength(Integer.parseInt(String.valueOf(dataElementDetailsMap.get(MAX_LENGTH))));
		}
		logger.info("setDataTypeAndLength method execution ended.");
	}

	/**
	 * setPrimaryKeyAndNotNull method used for set primary key and not null changes
	 * 
	 * @param langDependentColumnList     used for lang dependent changes add
	 * @param primaryKeyList              add primary key list
	 * @param tableColumnMap              contains table column details
	 * @param tableColumnDefinitionEntity contains table column entity
	 */
	private static void setPrimaryKeyAndNotNull(List<Map<String, Object>> langDependentColumnList,
			List<String> primaryKeyList, Map<String, Object> tableColumnMap,
			TableColumnDefinitionEntity tableColumnDefinitionEntity) {
		logger.info("setPrimaryKeyAndNotNull method execution started.");
		if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".primaryKey"))
				&& Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".primaryKey")))) {
			logger.info("primary key column column ");
			langDependentColumnList.add(tableColumnMap);
			primaryKeyList.add(String.valueOf(
					tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
			tableColumnDefinitionEntity.setisNotNull(true);
		} else if (Objects
				.nonNull(tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".notNull"))
				&& Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".notNull")))) {
			logger.info("Not Null column ");
			tableColumnDefinitionEntity.setisNotNull(true);
		}
		logger.info("setPrimaryKeyAndNotNull method execution ended.");
	}

}
