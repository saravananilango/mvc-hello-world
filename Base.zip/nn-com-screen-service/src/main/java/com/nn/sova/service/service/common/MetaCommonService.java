package com.nn.sova.service.service.common;

import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * The Interface MetaCommonService.
 */
public interface MetaCommonService {
    
    /**
     * Update change CR status.
     *
     * @param paramMap the param map
     * @throws QueryException the query exception
     */
    void updateChangeCRStatus(Map<String, Object> paramMap) throws QueryException;

    /**
     * Checks if is released.
     *
     * @param paramMap the param map
     * @return the map
     * @throws QueryException the query exception
     */
    Map<String, Object> isReleased(Map<String, Object> paramMap) throws QueryException;
}
