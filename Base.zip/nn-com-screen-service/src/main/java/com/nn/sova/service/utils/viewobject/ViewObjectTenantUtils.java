package com.nn.sova.service.utils.viewobject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.calcite.avatica.util.Quoting;
import org.apache.calcite.config.Lex;
import org.apache.calcite.sql.JoinType;
import org.apache.calcite.sql.SqlBasicCall;
import org.apache.calcite.sql.SqlDelete;
import org.apache.calcite.sql.SqlIdentifier;
import org.apache.calcite.sql.SqlInsert;
import org.apache.calcite.sql.SqlJoin;
import org.apache.calcite.sql.SqlLiteral;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.SqlNumericLiteral;
import org.apache.calcite.sql.SqlOperator;
import org.apache.calcite.sql.SqlOrderBy;
import org.apache.calcite.sql.SqlSelect;
import org.apache.calcite.sql.SqlUpdate;
import org.apache.calcite.sql.parser.SqlParseException;
import org.apache.calcite.sql.parser.SqlParser;
import org.apache.calcite.sql.parser.SqlParserPos;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.utility.cache.TextResourceManager;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;
import com.nn.sova.validation.QueryValidation;

/**
 * BusniessTenantParserUtils is used to parse the query.
 * 
 * @author Hariprasath Kamaraj
 *
 */
public class ViewObjectTenantUtils {

	private static ViewObjectTenantUtils instance = null;
	private static final String IGNORED_OPERATORS_IS_NULL="IS NULL";
	private static final String IGNORED_OPERATORS_IS_NOT_NULL="IS NOT NULL";
	protected Map<Integer, String> sortedMap = new TreeMap<Integer, String>(Collections.reverseOrder());
	protected String fromJoinColumn = StringUtils.EMPTY;
	protected String fromJoinAliasColumn = StringUtils.EMPTY;
	protected String productCode = StringUtils.EMPTY;
	
	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(ViewObjectTenantUtils.class);

	public ViewObjectTenantUtils(String productCode) {
		this.productCode = productCode;
	}
	/**
	 * getInstance is used to get the instance of RedisGetManager
	 * 
	 * @return RedisGetManager instance
	 */
	public static ViewObjectTenantUtils getInstance(String productCode) {
		instance = Objects.nonNull(instance) ? instance : new ViewObjectTenantUtils(productCode);
		return instance;
	}
	/**
	 * addTenantToQuery to add tenantId to the provided query
	 * 
	 * @param query
	 * @return
	 */
	public String addTenantToQuery (String query) throws CustomException{
		logger.debug("## addTenantToQuery method execution started.");
		try{
		sortedMap =  new TreeMap<Integer, String>(Collections.reverseOrder());
		fromJoinColumn = StringUtils.EMPTY;
		fromJoinAliasColumn = StringUtils.EMPTY;
		StringBuilder returnBuilder = new StringBuilder();
		SqlNode parsedStatement = parseQuery(query);
		checkParseStatement(parsedStatement);
		returnBuilder.append(query);
		sortedMap.entrySet().stream().forEach(action -> {
		 if(!StringUtils.equals(String.valueOf(action.getKey()),"-1")){
				returnBuilder.insert(action.getKey(), action.getValue());
		}
		});
		logger.debug("## addTenantToQuery method execution ended.");
		return returnBuilder.toString();
		}catch(Exception exp){
			logger.debug("## addTenantToQuery method execution ended with exception" + exp.getMessage());
			throw new CustomException(exp);
		}
	}
	/**
	 * parseQuery
	 * 
	 * @param query
	 * @return
	 */
	private SqlNode parseQuery(String query) throws CustomException{
		logger.debug("## parseQuery method execution started.");
		try{
		String escapeQuery = query.replaceAll(";", "");
		SqlParser.ConfigBuilder configBuilder =  SqlParser.configBuilder();
		configBuilder.setLex(Lex.JAVA);
		configBuilder.setCaseSensitive(false);
		configBuilder.setQuoting(Quoting.DOUBLE_QUOTE);
		SqlParser.Config config = configBuilder.build();
		SqlParser parser = SqlParser.create(escapeQuery, config);
		SqlNode parsedStatement = null;
		try {
			parsedStatement = parser.parseStmt();
		} catch (SqlParseException exception) {
			StringBuilder exceptionMessage=new StringBuilder(TextResourceManager.getInstance()
					.getBtTextWithParam("framework_common_query_parser_error", ContextBean.getLocale(), Arrays.asList(query)));
			exceptionMessage.append(", ").append(exception.getMessage());
			throw new CustomException(exceptionMessage.toString());
		}
		logger.debug("## parseQuery method execution ended");
		return parsedStatement;
		}catch(Exception e){
			logger.debug("## parseQuery method execution ended with exception" + e.getMessage());
			throw new CustomException(e);
		}
	}

	/**
	 * checkParseStatement
	 * 
	 * @param sqlNode
	 */
	private void checkParseStatement(SqlNode sqlNode)  throws CustomException{
		logger.debug("## checkParseStatement method execution started.");
		try{
		if(sqlNode instanceof SqlBasicCall){
			List<SqlNode> list = ((SqlBasicCall) sqlNode).getOperandList();
			checkParseStatement(list.get(0));
			if(list.size() > 1 ){
				checkParseStatement(list.get(1));
			}
		}
		if(sqlNode instanceof SqlJoin){
			checkParseStatement(((SqlJoin) sqlNode).getCondition());
		}
		if(sqlNode instanceof SqlSelect){
			makeSelect((SqlSelect)sqlNode);
		}
		if(sqlNode instanceof SqlOrderBy){
			makeOrderBy((SqlOrderBy)sqlNode);
		}
		logger.debug("## checkParseStatement method exception ended");
		}catch(Exception exp){
			logger.debug("## checkParseStatement method exception occured"+exp.getMessage());
			throw new CustomException(exp);
		}
	}

	/**
	 * makeSelect
	 * 
	 * @param parsedStatement
	 * @throws CustomException 
	 */
	private void makeSelect(SqlSelect parsedStatement) throws CustomException {
		logger.debug("## makeSelect method started");
		try{
		List<String> fromTable = makeFromStatement(parsedStatement);
		makeWhereStatement(parsedStatement,fromTable);
		logger.debug("## makeSelect method ended");
		}catch(Exception exp){
			logger.debug("## makeSelect method exception occured"+exp.getMessage());
			throw new CustomException(exp);
		}
	}

	/**
	 * makeOrderBy
	 * 
	 * @param sqlNode
	 */
	private void makeOrderBy(SqlOrderBy sqlNode) throws CustomException{
		logger.debug("## makeOrderBy method execution started ");
		try {
		sqlNode.getOperandList().stream().forEach(action -> {
			if (!(action instanceof SqlNumericLiteral)){
					try {
						checkParseStatement(action);
					} catch (Exception ex) {
						logger.debug("## checkParseStatement method from makeorderby execution ended with exception" + ex.getMessage());
						try {
							throw new CustomException(ex);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
			}
		});
		logger.debug("## makeOrderBy method execution ended");
		} catch (Exception exp) {
			logger.debug("## makeOrderBy method execution ended with exception" + exp.getMessage());
			throw new CustomException(exp);
		}
	}

	/**
	 * makeFromStatement
	 * 
	 * @param parsedStatement
	 * @return
	 */
	private List<String> makeFromStatement(SqlSelect parsedStatement) throws CustomException {
		logger.debug("## makeFromStatement method started");
		try{
		StringBuilder fromBuilder = new StringBuilder();
		StringBuilder joinBuilder = new StringBuilder();
		Set<String> columns = new LinkedHashSet<>();
		List<String> tableList;
		String fromTable = StringUtils.EMPTY;
		String toTable = StringUtils.EMPTY;
		String toTableAlias = StringUtils.EMPTY;
		SqlNode from = parsedStatement.getFrom();
		if(Objects.nonNull(from)){
		if(from instanceof SqlJoin){
			if(!(((SqlJoin) from).getLeft() instanceof SqlJoin)){
				checkBasicCall(((SqlJoin) from).getLeft(),fromBuilder,columns);
				fromTable = new ArrayList<String>(columns).get(0);
				if(columns.size()>1){
					fromJoinAliasColumn = new ArrayList<String>(columns).get(1);
				}
				tableList= new ArrayList<String>(columns);
				columns.clear();
			}else{
				checkBasicCall(((SqlJoin) from).getLeft(),fromBuilder,columns);
				fromTable = fromJoinColumn;
				tableList= Arrays.asList(fromJoinColumn);
				columns.clear();
			}
			fromBuilder.append(selectJoinType(((SqlJoin) from).getJoinType()));
			checkBasicCall(((SqlJoin) from).getRight(),fromBuilder,columns);
			toTable = new ArrayList<String>(columns).get(0);
			if(columns.size()>1){
				toTableAlias = new ArrayList<String>(columns).get(1);
			}
			columns.clear();
			fromBuilder.append(((SqlJoin) from).getConditionType());
			checkBasicCall(((SqlJoin) from).getCondition(),joinBuilder,columns);
			if(!fromTable.endsWith("_text") && !toTable.endsWith("_text")){
			addJoinTenantId(fromTable, toTable,joinBuilder, columns,((SqlJoin) from).getCondition().getParserPosition().getColumnNum()-1,fromJoinAliasColumn,toTableAlias);
			}
		}else{
			checkBasicCall(from,fromBuilder,columns);
			fromTable = new ArrayList<String>(columns).get(columns.size()-1);
			tableList= new ArrayList<String>(columns);
		}
		logger.debug("## makeFromStatement method exception ended");
		return tableList;
		}else{
			logger.debug("## makeFromStatement method with empty arraylist ended");
			return new ArrayList<>();	
		}
		}catch(Exception exp){
			logger.debug("## makeFromStatement method exception occured" + exp.getMessage());
			throw new CustomException(exp); 
		}
	}

	/**
	 * makeWhereStatement
	 * 
	 * @param parsedStatement
	 * @param fromTable
	 * @throws CustomException 
	 */
	private void makeWhereStatement(SqlSelect parsedStatement, List<String> fromTable) throws CustomException {
		logger.debug("## makeWhereStatement method started");
		try{
		StringBuilder whereBuilder = new StringBuilder();
		Set<String> columns = new HashSet<>();
		SqlNode where = parsedStatement.getWhere();
		checkBasicCall(where,whereBuilder,columns);
		SqlParserPos parsePosition;
		int whereEndPosition=0;
		if(where != null){
			if(parsedStatement.toString().endsWith(where.toString())){
				parsePosition = parsedStatement.getParserPosition();
			}else{
				parsePosition = where.getParserPosition();
			}
		}else{
			if(parsedStatement.getFrom() instanceof SqlJoin){
				SqlJoin joinPosition = (SqlJoin)parsedStatement.getFrom();
				parsePosition = joinPosition.getCondition().getParserPosition();
			}else{
				parsePosition = parsedStatement.getFrom().getParserPosition();
			}
		}
		whereEndPosition=whereEndPosition+parsePosition.getEndColumnNum();
		}catch(Exception exp){
		logger.debug("## makeFromStatement method exception occured" + exp.getMessage());
		throw new CustomException(exp); 
	}
	}

	/**
	 * checkBasicCall
	 * 
	 * @param sqlNode
	 * @param builder
	 * @param column
	 * @throws CustomException 
	 */
	private void checkBasicCall(SqlNode sqlNode,StringBuilder builder,Set<String> column) throws CustomException {
		logger.debug("## checkBasicCall method execution started ");
		try{
		if(sqlNode instanceof SqlBasicCall){
			List<SqlNode> list = ((SqlBasicCall) sqlNode).getOperandList();
			SqlOperator operator = ((SqlBasicCall) sqlNode).getOperator();
			if((list.get(0)instanceof SqlIdentifier)&&(list.size() > 1 && list.get(1)instanceof SqlLiteral)){
				String columnName =((SqlIdentifier) list.get(0)).toString();
				if(columnName.contains(".")){
					columnName = columnName.split("\\.")[1];
				}
				String columnValue = ((SqlLiteral) list.get(1)).getValue().toString();
			}else if((list.get(0)instanceof SqlIdentifier)){
				String columnName =((SqlIdentifier) list.get(0)).toString();
				if(columnName.contains(".")){
					columnName = columnName.split("\\.")[1];
				}
				if(columnName.equals(QueryUtils.getClientTenantId()) && Objects.nonNull(operator) && (operator.toString().equals(IGNORED_OPERATORS_IS_NULL) || operator.toString().equals(IGNORED_OPERATORS_IS_NOT_NULL))){
					throw new CustomException(TextResourceManager.getInstance().getBtText("framework_common_query_invalid_tenant", ContextBean.getLocale()));
				}
			}
		}
		if(sqlNode instanceof SqlIdentifier){
			String tableName =((SqlIdentifier) sqlNode).toString();
			if(tableName.contains(".")){
				tableName = tableName.split("\\.")[1];
			}
			column.add(tableName);
			builder.append(" ").append(((SqlIdentifier) sqlNode).toString()).append(" ");
		}
		else if(sqlNode instanceof SqlLiteral){
			builder.append(" ").append(((SqlLiteral) sqlNode).getValue()).append(" ");
		}
		else if(sqlNode instanceof SqlBasicCall){
			List<SqlNode> list = ((SqlBasicCall) sqlNode).getOperandList();
			SqlOperator operator = ((SqlBasicCall) sqlNode).getOperator();
			((SqlBasicCall) sqlNode).getOperands();
			checkBasicCall(list.get(0),builder,column);
			builder.append(" ").append(operator.getName()).append(" ");
			if(list.size() > 1 ){
				checkBasicCall(list.get(1),builder,column);
			}
		}
		else if(sqlNode instanceof SqlJoin){
			makeJoinStatement((SqlJoin)sqlNode);
		}
		else if(sqlNode instanceof SqlSelect){
			makeSelect((SqlSelect)sqlNode);
		}
		}catch(Exception exp){
			logger.debug("## checkBasicCall method exception occured" + exp.getMessage());
			throw new CustomException(exp); 
		}
	}

	/**
	 * makeJoinStatement
	 * 
	 * @param joinStatement
	 * @throws CustomException 
	 */
	private void makeJoinStatement(SqlJoin joinStatement) throws CustomException {
		logger.debug("## makeJoinStatement method execution started ");
		try{
		StringBuilder fromBuilder = new StringBuilder();
		StringBuilder joinBuilder = new StringBuilder();
		Set<String> columns = new LinkedHashSet<>();
		String toTable = StringUtils.EMPTY;
		String toTableAlias = StringUtils.EMPTY;
		String fromTableAlias = StringUtils.EMPTY;
		if(joinStatement instanceof SqlJoin){
			if(((SqlJoin) joinStatement).getLeft() instanceof SqlBasicCall){
				checkBasicCall(((SqlJoin) joinStatement).getLeft(),fromBuilder,columns);
				fromJoinColumn = new ArrayList<String>(columns).get(0);
				if(columns.size() > 1){
					fromJoinAliasColumn =  new ArrayList<String>(columns).get(1);
				}
				columns.clear();
			}else{
				checkBasicCall(((SqlJoin) joinStatement).getLeft(),fromBuilder,columns);
			}
			fromBuilder.append(selectJoinType(((SqlJoin) joinStatement).getJoinType()));
			checkBasicCall(((SqlJoin) joinStatement).getRight(),fromBuilder,columns);
			toTable = new ArrayList<String>(columns).get(0);
			if(columns.size()>1){
			toTableAlias = new ArrayList<String>(columns).get(1);
			}
			columns.clear();
			fromBuilder.append(((SqlJoin) joinStatement).getConditionType());
			checkBasicCall(((SqlJoin) joinStatement).getCondition(),joinBuilder,columns);
			if(!fromJoinColumn.endsWith("_text") && !toTable.endsWith("_text") && Objects.nonNull(joinStatement.getCondition())){
			addJoinTenantId(fromJoinColumn, toTable,joinBuilder, columns,joinStatement.getCondition().getParserPosition().getColumnNum()-1,fromJoinAliasColumn,toTableAlias);
			}
		}
		logger.debug("## makeJoinStatement method execution ended ");
		}catch(Exception exp){
			logger.debug("## makeFromStatement method exception occured" + exp.getMessage());
			throw new CustomException(exp); 
		}
	}

	/**
	 * addWhereTenantId
	 * 
	 * @param fromTable
	 * @param builder
	 * @param columns
	 * @param position
	 */
	private void addWhereTenantId(List<String> fromTableList, StringBuilder builder,Set<String> columns, int position) {
		QueryValidation queryValidator =  new QueryValidation();
		StringBuilder insert = new StringBuilder();
		String fromTable=StringUtils.EMPTY;
		String aliasName=StringUtils.EMPTY;
		if(CollectionUtils.isNotEmpty(fromTableList)){
			fromTable=fromTableList.get(0);
			aliasName=fromTableList.get(fromTableList.size()-1);
		}
		Map<String, Object> retrunValueMap = queryValidator.getTableProperties(QueryUtils.removeProductTableNamePrefix(fromTable,productCode),productCode);
		Boolean isTenant = Boolean.valueOf(String.valueOf(retrunValueMap.get("isTenant")));
		if(isTenant){
			if(!columns.contains(QueryUtils.getClientTenantId())){
				if(!StringUtils.isEmpty(builder.toString())){
					insert.append(" AND ");
				}else{
					insert.append(" WHERE ");
				}
				insert.append(aliasName+"."+QueryUtils.getClientTenantId()+" = ").append(QueryUtils.toQuotedString(ContextBean.getTenantId()));
			}
		}
		if(StringUtils.isNotEmpty(insert.toString())){
		sortedMap.put(position, insert.toString());
		}
	}

	/**
	 * addJoinTenantId
	 * 
	 * @param fromTable
	 * @param toTable
	 * @param joinBuilder
	 * @param columns
	 * @param position
	 * @param toTableAlias 
	 * @param fromTableAlias 
	 * @throws CustomException 
	 */
	private void addJoinTenantId(String fromTable, String toTable,
			StringBuilder joinBuilder, Set<String> columns, int position, String fromTableAlias, String toTableAlias) throws CustomException {
		logger.debug("## addJoinTenantId method execution started ");
		try{
		QueryValidation queryValidator =  new QueryValidation();
		StringBuilder insert = new StringBuilder();
		Map<String, Object> retrunValueMap = queryValidator.getTableDetails(QueryUtils.removeProductTableNamePrefix(fromTable,productCode),productCode);
		Boolean isTenant = Boolean.valueOf(String.valueOf(retrunValueMap.get("isTenant")));
		Map<String,Object> softOneMap = (Map<String, Object>) retrunValueMap.get("softDeleteMap");
		retrunValueMap = queryValidator.getTableDetails(QueryUtils.removeProductTableNamePrefix(toTable,productCode),productCode);
		Map<String,Object> softTwoMap = (Map<String, Object>) retrunValueMap.get("softDeleteMap");
		Boolean secondTenant = Boolean.valueOf(String.valueOf(retrunValueMap.get("isTenant")));
//		softOneMap.entrySet().stream().forEach(action->{
//			insert.append(" ").append((!StringUtils.isEmpty(fromTableAlias)? fromTableAlias :fromTable)+"."+action.getKey()+" <> ").append(QueryUtils.toQuotedString(Objects.toString(action.getValue())));
//			if(!StringUtils.isEmpty(joinBuilder.toString())){
//				insert.append(" AND ");
//			}
//		});
//		
//		softTwoMap.entrySet().stream().forEach(action->{
//			insert.append(" ").append((!StringUtils.isEmpty(toTableAlias)? toTableAlias :toTable)+"."+action.getKey()+" <> ").append(QueryUtils.toQuotedString(Objects.toString(action.getValue())));
//			if(!StringUtils.isEmpty(joinBuilder.toString())){
//				insert.append(" AND ");
//			}
//		});
		
		if(isTenant && secondTenant){
			if(!columns.contains(QueryUtils.getClientTenantId())){
				insert.append(" ").append((!StringUtils.isEmpty(fromTableAlias)? fromTableAlias :fromTable)+"."+QueryUtils.getClientTenantId()+" = ").append((!StringUtils.isEmpty(toTableAlias)? toTableAlias :toTable)+"."+QueryUtils.getClientTenantId());
				if(!StringUtils.isEmpty(joinBuilder.toString())){
					insert.append(" AND ");
				}
			}
		}
		sortedMap.put(position, insert.toString());
		logger.debug("## addJoinTenantId method execution ended ");
		}catch(Exception exp){
			logger.debug("## addJoinTenantId method exception occured"+exp.getMessage());
			throw new CustomException(exp);
		}
		}

	/**
	 * selectJoinType
	 * 
	 * @param joinType
	 * @return
	 */
	private String selectJoinType (JoinType joinType){
		String returnString;
		switch (joinType){
		case INNER:
			returnString = " inner join";
			break;
		case FULL:
			returnString = " full join";
			break;
		case CROSS:
			returnString = " cross join";
			break;
		case LEFT:
			returnString = " left join";
			break;
		case RIGHT:
			returnString = " right join";
			break;
		default:
			returnString = " join";
			break;
		}
		return returnString;
	}

	/**
	 * getTableNameCUD to add tenantId to the provided query
	 * 
	 * @param query
	 * @return
	 * @throws CustomException 
	 */
	public String getTableNameForIUD (String query) throws CustomException {
		logger.debug("## getTableNameForIUD method execution started ");
		SqlNode parsedStatement = parseQuery(query);
		return getTableName(parsedStatement);
	}

	/**
	 * getTableName
	 * 
	 * @param parsedStatement
	 * @return
	 */
	private String getTableName(SqlNode parsedStatement) {
		String returnTable = StringUtils.EMPTY;
		if(parsedStatement instanceof SqlDelete){
			SqlDelete delete = (SqlDelete)parsedStatement;
			SqlNode targetTable = delete.getTargetTable();
			returnTable = extractTableFromQuery(returnTable, targetTable);
		}
		if(parsedStatement instanceof SqlInsert){
			SqlInsert insert = (SqlInsert)parsedStatement;
			SqlNode targetTable = insert.getTargetTable();
			returnTable = extractTableFromQuery(returnTable, targetTable);
		}
		if(parsedStatement instanceof SqlUpdate){
			SqlUpdate update = (SqlUpdate)parsedStatement;
			SqlNode targetTable = update.getTargetTable();
			returnTable = extractTableFromQuery(returnTable, targetTable);
		}
		return returnTable;		
	}

	private String extractTableFromQuery(String returnTable, SqlNode targetTable) {
		if(targetTable instanceof SqlIdentifier){
			String tableName =((SqlIdentifier) targetTable).toString();
			returnTable=tableName;
			if(tableName.contains(".")){
				returnTable = tableName.split("\\.")[1];
			}
		}
		return returnTable;
	}


	
	/**
	 * isTenant
	 * @param targetTable
	 * @return
	 */
	private boolean isTenant(SqlNode targetTable){
		String returnTable = StringUtils.EMPTY;
		String tableName = extractTableFromQuery(returnTable,targetTable);
		QueryValidation queryValidator =  new QueryValidation();
		Map<String, Object> retrunValueMap = queryValidator.getTableProperties(QueryUtils.removeProductTableNamePrefix(tableName,productCode),productCode);
		return Boolean.valueOf(String.valueOf(retrunValueMap.get("isTenant")));
	}


	private List<String> getTargetColumnList(String tableName,String schema) throws CustomException{
		List<Map<String, Object>> columnData;
		try {
			columnData = new QueryBuilder().btSchema()
					.select().get("column_name")
					.from("information_schema.columns")
					.where(ConditionBuilder.instance()
							.eq("table_schema", schema).and()
							.eq("table_name", tableName)).orderBy("ordinal_position", SortType.ASC).build(false)
					.execute();
			if(CollectionUtils.isNotEmpty(columnData)){
				return columnData.stream().map(mapper->String.valueOf(mapper.get("column_name"))).collect(Collectors.toList());
			}else{
				return new ArrayList<>();
			}
		} catch (Exception exp) {
			exp.printStackTrace();
			throw new CustomException(exp);
		}
	}
	
	
}
