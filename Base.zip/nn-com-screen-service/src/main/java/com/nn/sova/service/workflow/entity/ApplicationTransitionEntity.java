package com.nn.sova.service.workflow.entity;

import java.sql.Timestamp;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ApplicationTransitionEntity class provides common transition data between approval flow and application
 * @author punithanantony.d@vaken.cloud (Punithan Antony Das)
 *
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationTransitionEntity {
	
	/** The application id. */
	private UUID applicationId;
	
	/** The application version. */
	private int version;
	
	/** The status. */
	private String status;

	/** The screen id. */
	private String screenId;

	/** The application name. */
	private String applicationName = StringUtils.EMPTY;
	
	/** view path URL of the screen*/
	private String screenViewUrl = "";
	
	/** The Due Date & time. */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss.SSS")
	private Timestamp dueDateTime;
	
	/** The service id. */
	private String actionBy = StringUtils.EMPTY;
	
	/** The service id. */
	private String actionByProfileName = StringUtils.EMPTY;
	
	/** The action time. */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss.SSS")
	private Timestamp actionTime;
	
	/** The comment given by the user. */
	private String comment;
	
	/** The priority of the application. */
	private boolean urgent = false;
	
	/** The submitted by. */
	private String submittedBy = StringUtils.EMPTY;
	
	/** The submitted by profile name. */
	private String submittedByProfileName = StringUtils.EMPTY;
	
	/** The application message. */
	private String message = StringUtils.EMPTY;
	
	/** The application status. */
	private String applicationStatus;
	
	/** The application state. */
	private int applicationState = 0;
	
	/** The application's unique id. */
	private String applicationUniqueId = StringUtils.EMPTY;
	
	/** The application state. */
	private boolean batchProcess = false;
	
	/** whether the process is bulk */
	private boolean bulkProcess = false;
	
	/** The result returns true if process succeeds. */
	private boolean success = false;
	
	/** The next application id. */ 
	private String nextApplication = StringUtils.EMPTY;
	
	/** The next application version. */ 
	private String nextVersion = StringUtils.EMPTY;
	
	/** The next application service id. */ 
	private String nextServiceId = StringUtils.EMPTY;
	
	private String priority = "NORMAL";
}
