package com.nn.sova.service.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections.MapUtils;

import com.google.common.base.CaseFormat;
import com.nn.sova.service.entity.FrontVo;

/**
 * CommonController class is common controller for component
 *
 * @author Logchand
 * 
 */
public abstract class CommonController {

	/**
	 * Front vo converter
	 *
	 * @param dataElementByComponentInfo the data element by component info
	 * @return the list
	 */
	public List<FrontVo> frontVoConverter(List<Map<String, Object>> dataElementInfo) {
		List<FrontVo> elementList = new ArrayList<>();
		List<String> keys = Arrays.asList("divisionList","additionalAttribute","screen_id","screen_definition_id","product_code");
		dataElementInfo.stream().forEach(action->{
			String componentId = String.valueOf(action.get("component_id"));
			Map<String,Object> attributeMap = new HashMap<>();
			action.entrySet().stream().filter(predicate->!keys.contains(predicate.getKey()) && Objects.nonNull(predicate.getValue())).forEach(map->{
				attributeMap.put(keyNameConverter(map.getKey()), map.getValue());
			});
			attributeMap.put("items", action.get("divisionList"));
			List<Map<String, Object>> additionalAttribute = (List<Map<String, Object>>)action.get("additionalAttribute");
			additionalAttribute.stream().filter(filter-> MapUtils.isNotEmpty(filter) && filter.containsKey("attribute_value") && 
					Objects.nonNull(filter.get("attribute_value"))).forEach(additionalMap->{
				attributeMap.put(keyNameConverter(additionalMap.get("attribute_key").toString()), additionalMap.get("attribute_value"));
			});
			addMultipleAttribute(componentId, attributeMap, elementList);
		});
		return elementList;
	}

	/**
	 * Key name converter.
	 *
	 * @param key the key
	 * @return the string
	 */
	private String keyNameConverter(String key) {
		String name = key.replace("", "");
		if (key.contains("_")) {
			name = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, name);
		}
		return name;
	}

	/**
	 * Adds the attribute.
	 *
	 * @param id             the id
	 * @param attributeKey   the attribute key
	 * @param attributeValue the attribute value
	 * @param returnList     the return list
	 */
	public static void addAttribute(String id, String attributeKey, Object attributeValue, List<FrontVo> returnList) {
		FrontVo vo = new FrontVo();
		vo.setId(id);
		vo.setMethod("setAttribute");
		vo.setParams(Arrays.asList(attributeKey, attributeValue));
		returnList.add(vo);
	}

	/**
	 * Adds the Multiple attribute.
	 *
	 * @param id           the id
	 * @param attributeMap the attribute map
	 * @param returnList   the return list
	 */
	public static void addMultipleAttribute(String id, Map<String, Object> attributeMap, List<FrontVo> returnList) {
		FrontVo vo = new FrontVo();
		vo.setId(id);
		vo.setMethod("setAttribute");
		vo.setParams(Arrays.asList(attributeMap));
		returnList.add(vo);
	}

	/**
	 * Adds the data.
	 *
	 * @param key        the key
	 * @param value      the value
	 * @param returnList the return list
	 */
	public static void addData(String key, Object value, List<FrontVo> returnList) {
		FrontVo vo = new FrontVo();
		vo.setId(key);
		vo.setMethod("hidden");
		vo.setParams(value);
		returnList.add(vo);
	}

	/**
	 * Adds the method.
	 *
	 * @param id         the id
	 * @param methodName the method name
	 * @param params     the params
	 * @param returnList the return list
	 */
	public static void addMethod(String id, String methodName, List<Object> params, List<FrontVo> returnList) {
		FrontVo vo = new FrontVo();
		vo.setId(id);
		vo.setMethod(methodName);
		vo.setParams(params);
		returnList.add(vo);
	}
}
