package com.nn.sova.service.service.sqleditor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.dao.tablequery.TableQueryDao;
import com.nn.sova.service.dao.tablequery.TableQueryDaoImpl;

/**
 * SqlEditorServiceImpl class is used for implementing the functionalities
 * related to sql editor component
 * 
 * @author Vivek Kannan E
 *
 */
public class SqlEditorServiceImpl implements SqlEditorService {

	private final TableQueryDao tableQueryDao;

	/**
	 * SqlEditorServiceImpl constructor which initialize TableQueryDaoImpl
	 */
	public SqlEditorServiceImpl() {
		tableQueryDao = new TableQueryDaoImpl();
	}

	@Override
	public Map<String, Object> loadSuggestion(Map<String, Object> requestMap) throws QueryException {
		Map<String, Object> resultMap = new HashMap<>();
		String productCode = String.valueOf(requestMap.get("productCode"));
		String targetText = String.valueOf(requestMap.get("targetText"));
		List<Map<String, Object>> returnList = tableQueryDao.getSuggestion(productCode, targetText);
		resultMap.put("searchedList", returnList);
		return resultMap;
	}

}