package com.nn.sova.service.controller.productSelector;

import java.io.IOException;
import java.util.Map;

import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.service.productSelector.ProductSelectorService;
import com.nn.sova.service.service.productSelector.ProductSelectorServiceImpl;

@SovaMapping("/productselector")
public class ProductSelectorController {
    private final ProductSelectorService productSelectorService;

    public ProductSelectorController() {
        productSelectorService = new ProductSelectorServiceImpl();
    }

    /**
	 * getProductDetails method is to search product details based on user input 
	 * 
	 * @param dataMap
	 * @return String
	 * @throws IOException
	 */
    //post_lambda 
	@SovaMapping(value = "/getProductDetails", method = SovaRequestMethod.POST)
    public String getProductDetails(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        return productSelectorService.getProductDetails(dataMap);
    }

    /**
	 * getSubProductDetails is to search sub Products based on selected product code and repoType
	 * 
	 * @param dataMap
	 * @return String
	 * @throws IOException
	 */
    //post_lambda 
	@SovaMapping(value = "/getSubProductDetails", method = SovaRequestMethod.POST)
    public String getSubProductDetails(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        return productSelectorService.getSubProductDetails(dataMap);
    }

    /**
	 * saveProductDetailsAsIni is to save productCode and subProductCode for the userId with key "product_details"
	 * 
	 * @param dataMap
	 * @throws IOException
	 */
    //post_lambda 
	@SovaMapping(value = "/saveProductDetailsAsIni", method = SovaRequestMethod.POST)
    public void saveProductDetailsAsIni(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        productSelectorService.saveProductDetailsAsIni(dataMap);
    }

    /**
	 * getIniDetails is to retrieve productCode and subProductCode for the userId  with key "product_details"
	 * 
	 * @param dataMap
	 * @return String
	 * @throws IOException
	 */
    //post_lambda 
	@SovaMapping(value = "/getIniDetails", method = SovaRequestMethod.POST)
    public String getIniDetails(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        return productSelectorService.getIniDetails();
    }
}
