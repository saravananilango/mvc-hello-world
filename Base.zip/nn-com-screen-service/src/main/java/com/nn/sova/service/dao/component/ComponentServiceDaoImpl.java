package com.nn.sova.service.dao.component;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.postgresql.util.PGobject;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.autonumber.AutonumberService;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.InsertQueryBuilder;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.querybuilder.functions.StatementBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;

/**
 * ComponentServiceDaoImpl class is used to access demo table information.
 *
 * @author Vignesh Palanisamy
 */
public class ComponentServiceDaoImpl implements ComponentServiceDao {

	/** The Constant COMPONENT_HANDLER_DETAIL. */
	private static final String COMPONENT_HANDLER_DETAIL = "component_handler_detail";

	/** The Constant COMPONENT_HANDLER_GROUP. */
	private static final String COMPONENT_HANDLER_GROUP = "component_handler_group";

	/** The Constant COMPONENT_HANDLER_ATTRIBUTE_DETAIL. */
	private static final String COMPONENT_HANDLER_ATTRIBUTE_DETAIL = "component_handler_attribute_detail";

	/** The Constant COMPONENT_HANDLER_ATTRIBUTE_GROUP. */
	private static final String COMPONENT_HANDLER_ATTRIBUTE_GROUP = "component_handler_attribute_group";

	/** The Constant COMPONENT_HANDLER_STYLE_DETAILS. */
	private static final String COMPONENT_HANDLER_STYLE_DETAILS = "component_handler_style_details";

	/** The Constant COMPONENT_HANDLER_STYLE_GROUP. */
	private static final String COMPONENT_HANDLER_STYLE_GROUP = "component_handler_style_group";

	/** The Constant COMPONENT_HANDLER_STYLE_SUB_GROUP. */
	private static final String COMPONENT_HANDLER_STYLE_SUB_GROUP = "component_handler_style_sub_group";

	/** The Constant DATA_FORMAT_DEFINITION. */
	private static final String DATA_FORMAT_DEFINITION = "data_format_definition";

	/** The Constant DIVISION_DEFINITION. */
	private static final String DIVISION_DEFINITION = "division_definition";

	/** The Constant COMP_STYLE_HANDLER_MAIN. */
	private static final String COMP_STYLE_HANDLER_MAIN = "comp_style_handler_main";

	/** The Constant COMP_STYLE_HANDLER_SUB. */
	private static final String COMP_STYLE_HANDLER_SUB = "comp_style_handler_sub";

	/** The Constant COMPONENT_HANDLER_DETAIL_ALIAS. */
	private static final String COMPONENT_HANDLER_DETAIL_ALIAS = "cmpDetail";

	/** The Constant COMPONENT_HANDLER_GROUP_ALIAS. */
	private static final String COMPONENT_HANDLER_GROUP_ALIAS = "cmpGroup";

	/** The Constant COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS. */
	private static final String COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS = "attrDetail";

	/** The Constant COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS. */
	private static final String COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS = "attrGroup";

	/** The Constant COMPONENT_HANDLER_STYLE_DETAILS_ALIAS. */
	private static final String COMPONENT_HANDLER_STYLE_DETAILS_ALIAS = "styleDetail";

	/** The Constant COMPONENT_HANDLER_STYLE_GROUP_ALIAS. */
	private static final String COMPONENT_HANDLER_STYLE_GROUP_ALIAS = "styleGroup";

	/** The Constant COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS. */
	private static final String COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS = "styleSubGroup";

	/** The Constant DATA_FORMAT_DEFINITION_ALIAS. */
	private static final String DATA_FORMAT_DEFINITION_ALIAS = "dataFormatDef";

	/** The Constant DIVISION_DEFINITION_ALIAS. */
	private static final String DIVISION_DEFINITION_ALIAS = "divDef";

	/** The Constant COMP_STYLE_HANDLER_MAIN_ALIAS. */
	private static final String COMP_STYLE_HANDLER_MAIN_ALIAS = "compStyleMain";

	/** The Constant COMP_STYLE_HANDLER_SUB_ALIAS. */
	private static final String COMP_STYLE_HANDLER_SUB_ALIAS = "compStyleSub";

	/** The Constant TAG_NAME. */
	private static final String TAG_NAME = Column.TAG_NAME;

	/** The Constant ATTRIBUTE_GROUP_ID. */
	private static final String ATTRIBUTE_GROUP_ID = "attribute_group_id";

	/** The Constant DISPLAY_ORDER. */
	private static final String DISPLAY_ORDER = "display_order";

	/** The Constant GROUP_TEXT. */
	private static final String GROUP_ID = "group_id";


	/** The Constant COMP_NAME. */
	private static final String COMP_NAME = "comp_name";

	/** The Constant ATTRIBUTE_GROUP. */
	private static final String ATTRIBUTE_GROUP = Column.ATTRIBUTE_GROUP;

	/** The Constant ATTRIBUTE_DATA. */
	private static final String ATTRIBUTE_DATA = "attribute_data";

	/** The Constant STYLE_GROUP_KEY. */
	private static final String STYLE_GROUP_KEY = Column.STYLE_GROUP_KEY;

	/** The Constant SUB_GROUP_ID. */
	private static final String SUB_GROUP_ID = "sub_group_id";



	/** The Constant DATA_FORMAT. */
	private static final String DATA_FORMAT = "data_format";

	/** The Constant ATTRIBUTE_NAME. */
	private static final String ATTRIBUTE_NAME = Column.ATTRIBUTE_NAME;

	/** The Constant ELEMENT_TYPE. */
	private static final String ELEMENT_TYPE = "element_type";

	/** The Constant DEFAULT_VALUE. */
	private static final String DEFAULT_VALUE = "default_value";

	/** The Constant ATTRIBUTE_COMPONENT_LABEL. */
	private static final String ATTRIBUTE_COMPONENT_LABEL = Column.ATTRIBUTE_COMPONENT_LABEL;

	/** The Constant VALUE. */
	private static final String VALUE = "value";

	/** The Constant ATTRIBUTE_DATA_FORMAT. */
	private static final String ATTRIBUTE_DATA_FORMAT = "attribute_data_format";

	/** The Constant COMPONENT_AND_GROUP_MAP. */
	private static final String COMPONENT_AND_GROUP_MAP = "componentAndGroupMap";

	/** The Constant COMPONENT_ATTRIBUTE. */
	private static final String COMPONENT_ATTRIBUTE = "componentAttribute";

	/** The Constant COMPONENT_STYLE_V1. */
	private static final String COMPONENT_STYLE_V1 = "componentStyleV1";

	/** The Constant TEXT_CONTENT. */
	private static final String TEXT_CONTENT = Column.TEXT_CONTENT;

	/** The Constant ATTRIBUTE_GROUP. */
	private static final String ATTRIBUTE_COMPONENT_DESCRIPTION = Column.ATTRIBUTE_COMPONENT_DESCRIPTION;

	/** The Constant ATTRIBUTE_GROUP_DISPLAY_ORDER. */
	private static final String ATTRIBUTE_GROUP_DISPLAY_ORDER = "attribute_group_display_order";
	
	/** The Constant ATTRIBUTE_DETAIL_DISPLAY_ORDER. */
	private static final String ATTRIBUTE_DETAIL_DISPLAY_ORDER = "attribute_detail_display_order";

	/** The Constant MAIN_LABEL_CODE. */
	private static final String MAIN_LABEL_CODE = Column.MAIN_LABEL_CODE;

	/** The Constant SUB_LABEL_CODE. */
	private static final String SUB_LABEL_CODE = "sub_label_code";


	/** The Constant STYLE_TYPE. */
	private static final String STYLE_TYPE = Column.STYLE_TYPE;
	
	/** The Constant STYLE_TYPE_TEXT. */
	private static final String STYLE_TYPE_TEXT = "styleTypeText";

	/** The Constant STYLE_STATE. */
	private static final String STYLE_STATE = "style_state";

	/** The Constant ATTRIBUTE_VALUE. */
	private static final String ATTRIBUTE_VALUE = "attribute_value";

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = "class_name";

	/** The Constant COMP_FRAMEWORK_COMMON. */
	private static final String COMP_FRAMEWORK_COMMON = "component_framework_common";

	/** The Constant COMP_STYLE_MASTER. */
	private static final String COMP_STYLE_MASTER = "comp_style_master";
	
	/** The Constant COMP_STYLE_TEMPLATE_NAME_MASTER. */
	private static final String COMP_STYLE_TEMPLATE_NAME_MASTER = "comp_style_template_name_master";

	/** The Constant COMP_STYLE_DETAIL_TEMPLATE_NAME. */
	private static final String COMP_STYLE_DETAIL_TEMPLATE_NAME = "comp_style_detail_template_name";

	/** The Constant COMP_STYLE_DETAIL_DATA. */
	private static final String COMP_STYLE_DETAIL_DATA = "comp_style_detail_data";

	/** The Constant COMP_STYLE_INSIDE_COMPONENT. */
	private static final String COMP_STYLE_INSIDE_COMPONENT = "comp_style_inside_component";
	
	/** The Constant COMP_STYLE_DETAIL_ATTRIBUTE_LABEL. */
	private static final String COMP_STYLE_DETAIL_ATTRIBUTE_LABEL = "comp_style_detail_attribute_label";

	/** The Constant COMP_STYLE_MASTER_ALIAS. */
	private static final String COMP_STYLE_MASTER_ALIAS = "cmpMst";
	
	/** The Constant COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS. */
	private static final String COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS = "cmpTemplateMst";

	/** The Constant COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS. */
	private static final String COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS = "cmpTemplateName";

	/** The Constant COMP_STYLE_DETAIL_DATA_ALIAS. */
	private static final String COMP_STYLE_DETAIL_DATA_ALIAS = "cmpDtlData";

	/** The Constant COMP_STYLE_INSIDE_COMPONENT_ALIAS. */
	private static final String COMP_STYLE_INSIDE_COMPONENT_ALIAS = "cmpInsideCmp";
	
	/** The Constant COMPONENT_TEMPLATE_MASTER_V3. */
	private static final String COMPONENT_TEMPLATE_MASTER_V3 = "componentTemplateMasterV3";

	/** The Constant COMPONENT_STYLE_MASTER_V3. */
	private static final String COMPONENT_STYLE_MASTER_V3 = "componentStyleMasterV3";

	/** The Constant COMPONENT_STYLE_DETAIL_TEMPLATE_V3. */
	private static final String COMPONENT_STYLE_DETAIL_TEMPLATE_V3 = "componentStyleDetailTemplateV3";

	/** The Constant COMPONENT_STYLE_DATA_V3. */
	private static final String COMPONENT_STYLE_DATA_V3 = "componentStyleDataV3";

	/** The Constant COMPONENT_STYLE_INSIDE_COMP_DATA_V3. */
	private static final String COMPONENT_STYLE_INSIDE_COMP_DATA_V3 = "componentStyleInsideComponentDataV3";

	/** The Constant COMPONENT_STYLE_INSIDE_COMP_V3. */
	private static final String COMPONENT_STYLE_INSIDE_COMP_V3 = "componentStyleInsideComponentV3";

	/** The Constant TEMPLATE_NAME. */
	private static final String TEMPLATE_NAME = Column.TEMPLATE_NAME;
	
	/** The Constant TEMPLATE_NAME_TEXT. */
	private static final String TEMPLATE_NAME_TEXT = "templateNameText";

	/** The Constant INSIDE_COMP_CLASS_NAME. */
	private static final String INSIDE_COMP_CLASS_NAME = Column.INSIDE_COMP_CLASS_NAME;

	/** The Constant COMP_STYLE_PROPS_DATA. */
	private static final String COMP_STYLE_PROPS_DATA = "comp_style_props_data";

	/** The Constant COMP_STYLE_PROPS_DATA_ALIAS. */
	private static final String COMP_STYLE_PROPS_DATA_ALIAS = "propsDataTbl";

	/** The Constant COMPONENT_STYLE_PROPS_DATA_V3. */
	private static final String COMPONENT_STYLE_PROPS_DATA_V3 = "componentStylePropsDataV3";

	/** The Constant INSIDE_COMP_NONE. */
	private static final String INSIDE_COMP_NONE = "none";
	
	/** The Constant THEME_DETAIL. */
	private static final String THEME_DETAIL = "theme_detail";
	
	/** The Constant THEME_DETAIL_DATA. */
	private static final String THEME_DETAIL_DATA = "themeDetailData";
	
	/** The Constant THEME_DETAIL_ALIAS. */
	private static final String THEME_DETAIL_ALIAS = "thmDtl";
	
	/** The Constant TENANT_THEME_DETAIL. */
	private static final String TENANT_THEME_DETAIL = "tenant_theme_detail";
	
	/** The Constant ATTRIBUTE_LABEL_ALIAS. */
	private static final String ATTRIBUTE_LABEL_ALIAS = "attrLabel";
	
	/** The Constant THEME_CODE. */
	private static final String THEME_CODE = "theme_code";
	
	/** The Constant JSON_VALUE. */
	private static final String JSON_VALUE = "json_value";
	
	/** The Constant TENANT_ID. */
	private static final String TENANT_ID = "tenant_id";
	
	/** The Constant PRODUCT_CODE. */
	private static final String PRODUCT_CODE = "product_code";
	
	/** The CREATED_AT */
	private static final String CREATED_AT = "created_at";

	/** The UPDATED_AT */
	private static final String UPDATED_AT = "updated_at";

	/** The CREATED_BY */
	private static final String CREATED_BY = "created_by";

	/** The UPDATED_BY */
	private static final String UPDATED_BY = "updated_by";
	
	/** The IS_DEFAULT */
	private static final String IS_DEFAULT = "is_default";
	
	/** The ATTRIBUTE_ID */
	private static final String ATTRIBUTE_ID = Column.ATTRIBUTE_ID;
	
	/** The ATTRIBUTE_LABEL */
	private static final String ATTRIBUTE_LABEL = Column.ATTRIBUTE_LABEL;
	
	/** The Constant SOVA_COMPONENT_LIST_CACHE_KEY. */
	private static final String SOVA_COMPONENT_LIST_CACHE_KEY = "sova_component_list_value_";
	
	private static final String STATUS = "status";
	private static final String SUCCESS = "success";
	
	private static final String FAILURE = "failure";
	
	/** The Constant COMPONENT_HANDLER_EVENTS. */
	private static final String COMPONENT_HANDLER_EVENTS = "component_handler_events";
	
	/** The Constant COMPONENT_HANDLER_EVENTS_ALIAS. */
	private static final String COMPONENT_HANDLER_EVENTS_ALIAS = "cmpEvent";

	/** The Constant COMPONENT_HANDLER_EVENTS_TEXT. */
	private static final String COMPONENT_HANDLER_EVENTS_TEXT = "component_handler_events_text";
	
	/** The Constant COMPONENT_HANDLER_EVENTS_TEXT_ALIAS. */
	private static final String COMPONENT_HANDLER_EVENTS_TEXT_ALIAS = "cmpEventText";
	
	/** EVENT_NAME */
	public static final String EVENT_NAME = "event_name";
	
	/** EVENT_CONTENT */
	public static final String EVENT_CONTENT = "event_content";
	
	/** EVENT_DESCRIPTION */
	public static final String EVENT_DESCRIPTION = "event_description";

	/** COMPONENT_AND_EVENTS_MAP */
	private static final String COMPONENT_AND_EVENTS_MAP = "componentAndEventsMap";
	
	/** THEME_TENANT_PRODUCT_LINK */
	private static final String THEME_TENANT_PRODUCT_LINK = "theme_tenant_product_link";

	
	/**
	 * getComponents will get components data
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> getComponents() throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		Map<String, Object> exceptionMap = new HashMap<>();
		loadComponentAndGroup(returnMap, exceptionMap);
		loadComponentAttribute(returnMap, exceptionMap);
		loadComponentEvents(returnMap, exceptionMap);
		loadComponentStyleV1(returnMap, exceptionMap);
		
		loadThemeDetail(returnMap);
		loadComponentTemplateMasterV3(returnMap);

		loadComponentStyleMasterV3(returnMap);
		loadComponentStyleTemplateV3(returnMap);
		loadComponentStyleDataV3(returnMap);
		loadComponentStyleInsideCompV3(returnMap);
		loadComponentStylePropsDataV3(returnMap);
		return returnMap;
	}

	private void loadComponentEvents(Map<String, Object> returnMap, Map<String, Object> exceptionMap) 
			throws QueryException {
		List<Object> exceptionList = new ArrayList<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder().btSchema();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
				
		SelectQueryBuilder innerSQLEventContent = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(EVENT_CONTENT, EVENT_CONTENT)
				.from(COMPONENT_HANDLER_EVENTS,"event1")
				.where(ConditionBuilder.instance().eq("event1.tag_name", COMPONENT_HANDLER_EVENTS_ALIAS + "." + TAG_NAME, true))
				.build(false);
		
		SelectQueryBuilder innerSQLEventDesc = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(EVENT_DESCRIPTION, EVENT_DESCRIPTION)
				.from(COMPONENT_HANDLER_EVENTS,"event2")
				.where(ConditionBuilder.instance().eq("event2.tag_name", COMPONENT_HANDLER_EVENTS_ALIAS + "." + TAG_NAME, true))
				.build(false);
		
		StatementBuilder eventContent = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_EVENTS_ALIAS + "." + EVENT_CONTENT))
				.thenCondition(COMPONENT_HANDLER_EVENTS_ALIAS + "." + EVENT_CONTENT)
				.elseCondition(innerSQLEventContent)
				.end();
		StatementBuilder eventDesc = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_EVENTS_ALIAS + "." + EVENT_DESCRIPTION))
				.thenCondition(COMPONENT_HANDLER_EVENTS_ALIAS + "." + EVENT_DESCRIPTION)
				.elseCondition(innerSQLEventDesc)
				.end();

		List<Map<String, Object>>  componentAndEventList = selectQueryBuilder
				.from(COMPONENT_HANDLER_EVENTS, COMPONENT_HANDLER_EVENTS_ALIAS)
				.join(COMPONENT_HANDLER_DETAIL, COMPONENT_HANDLER_DETAIL_ALIAS, 
						ConditionBuilder.instance().eq(COMPONENT_HANDLER_DETAIL_ALIAS+"."+TAG_NAME, 
								COMPONENT_HANDLER_EVENTS_ALIAS+"."+TAG_NAME, true))

				.get(COMPONENT_HANDLER_EVENTS_ALIAS + ".*")
				.get(eventContent, EVENT_CONTENT)
				.get(eventDesc, EVENT_DESCRIPTION)
				.orderBy(COMPONENT_HANDLER_EVENTS_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.build(false)
				.execute();

		LinkedHashMap<Object, List<Map<String, Object>>> componentAndEventDataMap = componentAndEventList.stream()
				.filter(item -> {
					if (Objects.nonNull(item.get(TAG_NAME))) {
						return true;
					}
					exceptionList.add(item);
					return false;
				}).collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new, Collectors.toList()));
		returnMap.put(COMPONENT_AND_EVENTS_MAP, componentAndEventDataMap);
		exceptionMap.put(COMPONENT_AND_EVENTS_MAP, exceptionList);
	}

	/**
	 * loadComponentAndGroup will load component and group data from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentAndGroup(Map<String, Object> returnMap, Map<String, Object> exceptionMap)
			throws QueryException  {
		List<Object> exceptionList = new ArrayList<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder().btSchema();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
				
		SelectQueryBuilder innerSQLComponentName = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.COMPONENT_NAME, Column.COMPONENT_NAME)
				.from(COMPONENT_HANDLER_DETAIL,"chd1")
				.where(
						ConditionBuilder.instance().eq("chd1.tag_name" , COMPONENT_HANDLER_DETAIL_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("chd1.group_id" , COMPONENT_HANDLER_GROUP_ALIAS + "." + GROUP_ID, true)
						.and()
						.notEq(Column.COMPONENT_NAME, "''"))
				.build(false);
		
		SelectQueryBuilder innerSQLComponentDesc = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.COMPONENT_DESCRIPTION, Column.COMPONENT_DESCRIPTION)
				.from(COMPONENT_HANDLER_DETAIL,"chd2")
				.where(
						ConditionBuilder.instance().eq("chd2.tag_name" , COMPONENT_HANDLER_DETAIL_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("chd2.group_id" , COMPONENT_HANDLER_GROUP_ALIAS + "." + GROUP_ID, true).and()
						.notEq(Column.COMPONENT_DESCRIPTION, "''"))
				.build(false);
		
		SelectQueryBuilder innerSQLGroupText = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.GROUP_TEXT, Column.GROUP_TEXT)
				.from(COMPONENT_HANDLER_GROUP,"chg")
				.where(
						ConditionBuilder.instance()
						.eq("chg.group_id" , COMPONENT_HANDLER_GROUP_ALIAS + "." + GROUP_ID, true).and()
						.notEq(Column.GROUP_TEXT, "''"))
				.build(false);
		
		StatementBuilder componentName = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_DETAIL_ALIAS + "." + Column.COMPONENT_NAME))
				.thenCondition(COMPONENT_HANDLER_DETAIL_ALIAS + "." + Column.COMPONENT_NAME)
				.elseCondition(innerSQLComponentName)
				.end();
		StatementBuilder componentDesc = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_DETAIL_ALIAS + "." + Column.COMPONENT_DESCRIPTION))
				.thenCondition(COMPONENT_HANDLER_DETAIL_ALIAS + "." + Column.COMPONENT_DESCRIPTION)
				.elseCondition(innerSQLComponentDesc)
				.end();
		StatementBuilder groupText = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_GROUP_ALIAS + "." + Column.GROUP_TEXT))
				.thenCondition(COMPONENT_HANDLER_GROUP_ALIAS + "." + Column.GROUP_TEXT)
				.elseCondition(innerSQLGroupText)
				.end();

		List<Map<String, Object>>  componentAndGroupList = selectQueryBuilder.from(COMPONENT_HANDLER_DETAIL, COMPONENT_HANDLER_DETAIL_ALIAS)
				.join(COMPONENT_HANDLER_GROUP, COMPONENT_HANDLER_GROUP_ALIAS,
						ConditionBuilder.instance().eq(COMPONENT_HANDLER_GROUP_ALIAS + "." + GROUP_ID,
								COMPONENT_HANDLER_DETAIL_ALIAS + "." + GROUP_ID, true))

				.get(COMPONENT_HANDLER_DETAIL_ALIAS + ".*")
				.get(COMPONENT_HANDLER_GROUP_ALIAS + ".*")
				.get(componentName, Column.COMPONENT_NAME)
				.get(componentDesc, Column.COMPONENT_DESCRIPTION)
				.get(groupText, Column.GROUP_TEXT)
				.get(COMPONENT_HANDLER_GROUP_ALIAS + "." + DISPLAY_ORDER + " as group_display_order")

				.orderBy(COMPONENT_HANDLER_GROUP_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.orderBy(COMPONENT_HANDLER_DETAIL_ALIAS + "." + DISPLAY_ORDER, SortType.ASC).build(false).execute();

		LinkedHashMap<Object, List<Map<String, Object>>> componentAndGroupDataMap = componentAndGroupList.stream()
				.filter(item -> {
					if (Objects.nonNull(item.get(GROUP_ID))) {
						return true;
					}
					exceptionList.add(item);
					return false;
				}).collect(Collectors.groupingBy(map -> map.get(GROUP_ID), LinkedHashMap::new, Collectors.toList()));
		returnMap.put(COMPONENT_AND_GROUP_MAP, componentAndGroupDataMap);
		exceptionMap.put(COMPONENT_AND_GROUP_MAP, exceptionList);
	}

	/**
	 * loadComponentAttribute will load component attributes from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 * @throws QueryException 
	 */
	public void loadComponentAttribute(Map<String, Object> returnMap, Map<String, Object> exceptionMap) throws QueryException {
		Map<String, LinkedHashMap<String, Object>> returnAttrMap = new HashMap<>();
		List<Object> exceptionList = new ArrayList<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.btSchema().select();
		
		SelectQueryBuilder innerSQLatrGroup = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.ATTRIBUTE_GROUP, Column.ATTRIBUTE_GROUP)
				.from(COMPONENT_HANDLER_ATTRIBUTE_GROUP,"chag")
				.where(
						ConditionBuilder.instance().eq("chag.tag_name" , COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("chag.attribute_group_id" , COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + ATTRIBUTE_GROUP_ID, true).and()
						.notEq(Column.ATTRIBUTE_GROUP, "''"))
				.build(false);
		SelectQueryBuilder innerSQDivText = queryBuilderInstance.select()
				.lang(true)
				.skipTenantId(true)
				.setLanguage("en")
				.concat(Column.TEXT_CONTENT, Column.TEXT_CONTENT)
				.from(DIVISION_DEFINITION,"dd")
				.where(
						ConditionBuilder.instance().eq("dd.data_format" , DIVISION_DEFINITION_ALIAS + "." + DATA_FORMAT, true)
						.and()
						.eq("dd.value" , DIVISION_DEFINITION_ALIAS + "." + VALUE, true).and()
						.notEq(Column.TEXT_CONTENT, "''"))
				.build(false);
		
		SelectQueryBuilder innerSQLCompDesc = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.ATTRIBUTE_COMPONENT_DESCRIPTION, Column.ATTRIBUTE_COMPONENT_DESCRIPTION)
				.from(COMPONENT_HANDLER_ATTRIBUTE_DETAIL,"chad1")
				.where(
						ConditionBuilder.instance().eq("chad1.tag_name" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("chad1.attribute_name" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_NAME, true)
						.and()
						.eq("chad1.attribute_group_id" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_GROUP_ID, true).and()
						.notEq(Column.ATTRIBUTE_COMPONENT_DESCRIPTION, "''"))
				.build(false);
		SelectQueryBuilder innerSQLCompLabel = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.ATTRIBUTE_COMPONENT_LABEL, Column.ATTRIBUTE_COMPONENT_LABEL)
				.from(COMPONENT_HANDLER_ATTRIBUTE_DETAIL,"chad2")
				.where(
						ConditionBuilder.instance().eq("chad2.tag_name" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("chad2.attribute_name" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_NAME, true)
						.and()
						.eq("chad2.attribute_group_id" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_GROUP_ID, true).and()
						.notEq(Column.ATTRIBUTE_COMPONENT_LABEL, "''"))
				.build(false);
		SelectQueryBuilder innerSQLCompPlaceHolder = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.ATTRIBUTE_COMPONENT_PLACEHOLDER, Column.ATTRIBUTE_COMPONENT_PLACEHOLDER)
				.from(COMPONENT_HANDLER_ATTRIBUTE_DETAIL,"chad3")
				.where(
						ConditionBuilder.instance().eq("chad3.tag_name" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("chad3.attribute_name" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_NAME, true)
						.and()
						.eq("chad3.attribute_group_id" , COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_GROUP_ID, true).and()
						.notEq(Column.ATTRIBUTE_COMPONENT_PLACEHOLDER, "''"))
				.build(false);
		
		StatementBuilder atrGroup = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + Column.ATTRIBUTE_GROUP))
				.thenCondition(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + Column.ATTRIBUTE_GROUP)
				.elseCondition(innerSQLatrGroup)
				.end();
		StatementBuilder textContent = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(DIVISION_DEFINITION_ALIAS + "." + Column.TEXT_CONTENT))
				.thenCondition(DIVISION_DEFINITION_ALIAS + "." + Column.TEXT_CONTENT)
				.elseCondition(innerSQDivText)
				.end();
		StatementBuilder atrCompDesc = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_COMPONENT_DESCRIPTION))
				.thenCondition(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_COMPONENT_DESCRIPTION)
				.elseCondition(innerSQLCompDesc)
				.end();
		StatementBuilder atrCompLabel = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_COMPONENT_LABEL))
				.thenCondition(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_COMPONENT_LABEL)
				.elseCondition(innerSQLCompLabel)
				.end();
		StatementBuilder atrCompPlaceHolder = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_COMPONENT_PLACEHOLDER))
				.thenCondition(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + Column.ATTRIBUTE_COMPONENT_PLACEHOLDER)
				.elseCondition(innerSQLCompPlaceHolder)
				.end();
		List<Map<String, Object>> componentAndAttributeList = selectQueryBuilder
				.from(COMPONENT_HANDLER_ATTRIBUTE_DETAIL, COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS)
				.join(COMPONENT_HANDLER_ATTRIBUTE_GROUP, COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS, ConditionBuilder
						.instance()
						.brackets(ConditionBuilder.instance()
								.eq(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + TAG_NAME,
										COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + TAG_NAME, true)

								.and().eq(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + ATTRIBUTE_GROUP_ID,
										COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_GROUP_ID, true))
						.or()
						.brackets(ConditionBuilder.instance()
								.eq(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + TAG_NAME,
										"'" + COMP_FRAMEWORK_COMMON + "'", true)
								.and().eq(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + ATTRIBUTE_GROUP_ID,
										COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_GROUP_ID, true)))
				.leftJoin(DATA_FORMAT_DEFINITION, DATA_FORMAT_DEFINITION_ALIAS,
						ConditionBuilder.instance().eq(DATA_FORMAT_DEFINITION_ALIAS + "." + DATA_FORMAT,
								COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_DATA_FORMAT, true))

				.leftJoin(DIVISION_DEFINITION, DIVISION_DEFINITION_ALIAS,
						ConditionBuilder.instance().eq(DIVISION_DEFINITION_ALIAS + "." + DATA_FORMAT,
								COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + ATTRIBUTE_DATA_FORMAT, true))
				.get(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + ".*")
				.get(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + ".*")
				.get(DATA_FORMAT_DEFINITION_ALIAS + ".*")
				.get(DIVISION_DEFINITION_ALIAS + ".*")
				.get(atrGroup, Column.ATTRIBUTE_GROUP)
				.get(atrCompDesc, Column.ATTRIBUTE_COMPONENT_DESCRIPTION)
				.get(atrCompLabel, Column.ATTRIBUTE_COMPONENT_LABEL)
				.get(atrCompPlaceHolder, Column.ATTRIBUTE_COMPONENT_PLACEHOLDER)
				.get(textContent, Column.TEXT_CONTENT)
				.get(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." +  DISPLAY_ORDER + " as " + ATTRIBUTE_DETAIL_DISPLAY_ORDER
						,COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + DISPLAY_ORDER + " as "
						+ ATTRIBUTE_GROUP_DISPLAY_ORDER)

				.orderBy(COMPONENT_HANDLER_ATTRIBUTE_GROUP_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.orderBy(COMPONENT_HANDLER_ATTRIBUTE_DETAIL_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.orderBy(DIVISION_DEFINITION_ALIAS + "." + DISPLAY_ORDER, SortType.ASC).skipTenantId(true).build(false)
				.execute();

		Map<Object, LinkedHashMap<Object, List<Map<String, Object>>>> componentAndAttributeDataMap = componentAndAttributeList
				.stream().filter(item -> {
					if (Objects.nonNull(item.get(TAG_NAME)) && Objects.nonNull(item.get(ATTRIBUTE_NAME))) {
						return true;
					}
					exceptionList.add(item);
					return false;
				}).collect(Collectors.groupingBy(map -> map.get(TAG_NAME), Collectors
						.groupingBy(key -> key.get(ATTRIBUTE_NAME), LinkedHashMap::new, Collectors.toList())));

		componentAndAttributeDataMap.keySet().stream().forEach(compName -> {
			LinkedHashMap<Object, List<Map<String, Object>>> attributeGroupMap = componentAndAttributeDataMap
					.get(compName);
			LinkedHashMap<String, Object> retrunAttrGroupMap = new LinkedHashMap<>();
			attributeGroupMap.keySet().stream().forEach(attributeKey -> {
				List<Map<String, Object>> attributeDataList = attributeGroupMap.get(attributeKey);
				Map<String, Object> dataMap = new HashMap<>();
				dataMap.put("attributes", new HashMap<>());
				if (!attributeDataList.isEmpty()) {
					Map<String, Object> attrMap = attributeDataList.get(0);
					dataMap.put(COMP_NAME, attrMap.get(COMP_NAME));
					dataMap.put(Column.ATTRIBUTE_GROUP, attrMap.get(ATTRIBUTE_GROUP));
					dataMap.put(Column.ATTRIBUTE_NAME, attrMap.get(ATTRIBUTE_NAME));
					dataMap.put(ATTRIBUTE_GROUP_ID, attrMap.get(ATTRIBUTE_GROUP_ID));
					dataMap.put("attribute_display_order", attrMap.get(ATTRIBUTE_DETAIL_DISPLAY_ORDER));
					dataMap.put(ATTRIBUTE_GROUP_DISPLAY_ORDER, attrMap.get(ATTRIBUTE_GROUP_DISPLAY_ORDER));
					dataMap.put(Column.ATTRIBUTE_COMPONENT_DESCRIPTION, attrMap.get(ATTRIBUTE_COMPONENT_DESCRIPTION));
					PGobject attrPgObj = (PGobject) attrMap.get(ATTRIBUTE_DATA);
					try {
					Map<String, Object> compAttrMap = Objects.nonNull(attrPgObj) ? JsonUtils.fromJsonOrEmptyMap(attrPgObj.getValue(), new TypeReference<Map<String, Object>>() {
					}) : new HashMap<>();
					String label = !Objects.isNull(attrMap.get(ATTRIBUTE_COMPONENT_LABEL))
							? attrMap.get(ATTRIBUTE_COMPONENT_LABEL).toString()
							: "";
					compAttrMap.put("label", label);
					if (("Division".equals(attrMap.get(ELEMENT_TYPE)))) {
						List<Map<String, Object>> itemsList = new ArrayList<>();
						attributeDataList.forEach(attrItem -> {
							Map<String, Object> itemMap = new HashMap<>();
							itemMap.put("id", attrItem.get(VALUE));
							itemMap.put(VALUE, attrItem.get(VALUE));
							itemMap.put("label", attrItem.get(TEXT_CONTENT));
							itemMap.put("defaultValue", attrItem.get(DEFAULT_VALUE));
							itemMap.put("displayOrder", attrItem.get(DISPLAY_ORDER));
							itemsList.add(itemMap);
						});
						compAttrMap.put("items", itemsList);
					}
					dataMap.put(ATTRIBUTE_DATA, compAttrMap);
					} catch (Exception e) {
						System.out.println(" *///////////////");
					}
					dataMap.put("otherData", attrMap);
				}
				retrunAttrGroupMap.put((String) attributeKey, dataMap);
			});
			returnAttrMap.put((String) compName, retrunAttrGroupMap);
		});

		returnMap.put(COMPONENT_ATTRIBUTE, returnAttrMap);
		exceptionMap.put(COMPONENT_ATTRIBUTE, exceptionList);
	}

	/**
	 * loadComponentStyle will load component style from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentStyleV1(Map<String, Object> returnMap, Map<String, Object> exceptionMap) throws QueryException  {
		List<Object> exceptionList = new ArrayList<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		
		SelectQueryBuilder innerSQLSubGroup = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.STYLE_SUB_GROUP, Column.STYLE_SUB_GROUP)
				.from(COMPONENT_HANDLER_STYLE_SUB_GROUP,"ssg")
				.where(
						ConditionBuilder.instance().eq("ssg.style_group_key" , COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + Column.STYLE_GROUP_KEY, true)
						.and()
						.eq("ssg.sub_group_id" , COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + SUB_GROUP_ID, true)
						.and()
						.eq("ssg.tag_name" , COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + Column.TAG_NAME, true).and()
						.notEq(Column.STYLE_SUB_GROUP, "''"))
				.build(false);
		StatementBuilder subGroup = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + Column.STYLE_SUB_GROUP))
				.thenCondition(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + Column.STYLE_SUB_GROUP)
				.elseCondition(innerSQLSubGroup)
				.end();
		SelectQueryBuilder innerSQLStyleGroup = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.STYLE_GROUP, Column.STYLE_GROUP)
				.from(COMPONENT_HANDLER_STYLE_GROUP,"sg")
				.where(
						ConditionBuilder.instance().eq("sg.style_group_key" , COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + Column.STYLE_GROUP_KEY, true)
						.and()
						.eq("sg.tag_name" , COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + Column.TAG_NAME, true).and()
						.notEq(Column.STYLE_GROUP, "''"))
				.build(false);
		StatementBuilder styleGroup = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + Column.STYLE_GROUP))
				.thenCondition(COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + Column.STYLE_GROUP)
				.elseCondition(innerSQLStyleGroup)
				.end();
		SelectQueryBuilder innerSQLAttrLabel = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.STYLE_ATTRIBUTE_LABEL, Column.STYLE_ATTRIBUTE_LABEL)
				.from(COMPONENT_HANDLER_STYLE_DETAILS,"sd")
				.where(
						ConditionBuilder.instance().eq("sd.style_group_key" , COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + Column.STYLE_GROUP_KEY, true)
						.and()
						.eq("sd.style_attribute_key" , COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + "style_attribute_key", true)
						.and()
						.eq("sd.tag_name" , COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + Column.TAG_NAME, true).and()
						.notEq(Column.STYLE_ATTRIBUTE_LABEL, "''"))
				.build(false);
		StatementBuilder attrLabel = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + Column.STYLE_ATTRIBUTE_LABEL))
				.thenCondition(COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + Column.STYLE_ATTRIBUTE_LABEL)
				.elseCondition(innerSQLAttrLabel)
				.end();
		
		List<Map<String, Object>> componentAndStyleList = selectQueryBuilder
				.from(COMPONENT_HANDLER_STYLE_DETAILS, COMPONENT_HANDLER_STYLE_DETAILS_ALIAS)
				.join(COMPONENT_HANDLER_STYLE_GROUP, COMPONENT_HANDLER_STYLE_GROUP_ALIAS,
						ConditionBuilder.instance()
								.eq(COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + TAG_NAME,
										COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + TAG_NAME, true)

								.and().eq(COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + STYLE_GROUP_KEY,
										COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + STYLE_GROUP_KEY, true))

				.leftJoin(COMPONENT_HANDLER_STYLE_SUB_GROUP, COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS,
						ConditionBuilder.instance()
								.eq(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + TAG_NAME,
										COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + TAG_NAME, true)
								.and()
								.eq(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + STYLE_GROUP_KEY,
										COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + STYLE_GROUP_KEY, true)

								.and().eq(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + SUB_GROUP_ID,
										COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + SUB_GROUP_ID, true))

				.get(COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + ".*")
				.get(subGroup, Column.STYLE_SUB_GROUP)
				.get(styleGroup, Column.STYLE_GROUP)
				.get(attrLabel, Column.STYLE_ATTRIBUTE_LABEL)
				.get(COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + DISPLAY_ORDER + " as style_group_display_order")
				.get(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + DISPLAY_ORDER
						+ " as style_sub_group_display_order")

				.orderBy(COMPONENT_HANDLER_STYLE_SUB_GROUP_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.orderBy(COMPONENT_HANDLER_STYLE_GROUP_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.orderBy(COMPONENT_HANDLER_STYLE_DETAILS_ALIAS + "." + DISPLAY_ORDER, SortType.ASC).build(false)
				.execute();

		Map<Object, LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>> componentAndStyleDataMap = componentAndStyleList
				.stream().filter(item -> {
					if (Objects.nonNull(item.get(TAG_NAME)) && Objects.nonNull(item.get(STYLE_GROUP_KEY))) {
						return true;
					}
					exceptionList.add(item);
					return false;
				}).collect(Collectors.groupingBy(map -> map.get(TAG_NAME), Collectors
						.groupingBy(map -> map.get(STYLE_GROUP_KEY), LinkedHashMap::new, Collectors.groupingBy(key -> {
							if (!Objects.isNull(key.get(SUB_GROUP_ID))) {
								return key.get(SUB_GROUP_ID);
							}
							return key.get(STYLE_GROUP_KEY);
						}, LinkedHashMap::new, Collectors.toList()))));
		returnMap.put(COMPONENT_STYLE_V1, componentAndStyleDataMap);
		exceptionMap.put(COMPONENT_STYLE_V1, exceptionList);
	}

	/**
	 * upsertComponentInlineStyleV3 will upsert components data v3
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> upsertComponentInlineStyleV3(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> 
				resultMap.put(COMP_STYLE_DETAIL_DATA + "." + updateKey, mapper.get(updateKey))
			);
			return resultMap;
		}).collect(Collectors.toList());

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(COMP_STYLE_DETAIL_DATA, dataList, true, Arrays.asList(ATTRIBUTE_VALUE),
				TEMPLATE_NAME, TAG_NAME, STYLE_TYPE, STYLE_STATE, MAIN_LABEL_CODE, SUB_LABEL_CODE, ATTRIBUTE_NAME,
				INSIDE_COMP_CLASS_NAME);
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}

	/**
	 * upsertInlineStylePropsDataV3 will upsert components data v3
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> upsertInlineStylePropsDataV3(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> 
				resultMap.put(COMP_STYLE_PROPS_DATA + "." + updateKey, mapper.get(updateKey))
			);
			return resultMap;
		}).collect(Collectors.toList());

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(COMP_STYLE_PROPS_DATA, dataList, true, Arrays.asList(ATTRIBUTE_VALUE),
				TEMPLATE_NAME, TAG_NAME, STYLE_TYPE, ATTRIBUTE_NAME);
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_props_data_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}

	/**
	 * loadComponentStyleMasterV3 will load new component style master from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentStyleMasterV3(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		SelectQueryBuilder innerSQL = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.STYLE_TYPE_TEXT, Column.STYLE_TYPE_TEXT)
				.from(COMP_STYLE_MASTER,"csm")
				.where(
						ConditionBuilder.instance().eq("csm.style_type" , COMP_STYLE_MASTER_ALIAS + "." + Column.STYLE_TYPE, true)
						.and()
						.eq("csm.tag_name" , COMP_STYLE_MASTER_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.eq("csm.template_name" , COMP_STYLE_MASTER_ALIAS + "." + Column.TEMPLATE_NAME, true)
						.and()
						.notEq("csm.style_type_text", "''")
						)
				.build(false);
		StatementBuilder stmnt = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMP_STYLE_MASTER_ALIAS + "." + Column.STYLE_TYPE_TEXT))
				.thenCondition(COMP_STYLE_MASTER_ALIAS + "." + Column.STYLE_TYPE_TEXT)
				.elseCondition(innerSQL)
				.end();
		List<Map<String, Object>> componentMasterList = selectQueryBuilder.from(COMP_STYLE_MASTER, COMP_STYLE_MASTER_ALIAS)
				.get(COMP_STYLE_MASTER_ALIAS + ".*")
				.get(stmnt,Column.STYLE_TYPE_TEXT)
				.orderBy(COMP_STYLE_MASTER_ALIAS + "." + DISPLAY_ORDER, SortType.ASC).build(false).execute();

		LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>> componentMasterDataMap = componentMasterList
				.stream()
				.filter(item -> Objects.nonNull(item.get(TEMPLATE_NAME)) && Objects.nonNull(item.get(TAG_NAME)))
				.collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new,
						Collectors.groupingBy(map -> map.get(TEMPLATE_NAME), LinkedHashMap::new, Collectors.toList())));

		returnMap.put(COMPONENT_STYLE_MASTER_V3, componentMasterDataMap);
	}
	
	/**
	 * loadComponentTemplateMasterV3 will load new component style master from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentTemplateMasterV3(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		SelectQueryBuilder innerSQL = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.TEMPLATE_NAME_TEXT, Column.TEMPLATE_NAME_TEXT)
				.from(COMP_STYLE_TEMPLATE_NAME_MASTER,"tnm")
				.where(
						ConditionBuilder.instance().eq("tnm.template_name" , COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS + "." + Column.TEMPLATE_NAME, true)
						.and()
						.notEq("tnm.template_name_text", "''")
						)
				.build(false);
		StatementBuilder stmnt = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS + "." + Column.TEMPLATE_NAME_TEXT))
				.thenCondition(COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS + "." + Column.TEMPLATE_NAME_TEXT)
				.elseCondition(innerSQL)
				.end();
		List<Map<String, Object>> componentTemplateMasterList = selectQueryBuilder.from(COMP_STYLE_TEMPLATE_NAME_MASTER, COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS)
				.get(COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS + ".*")
				.get(stmnt,Column.TEMPLATE_NAME_TEXT)
				.orderBy(COMP_STYLE_TEMPLATE_NAME_MASTER_ALIAS + "." + DISPLAY_ORDER, SortType.ASC).build(false).execute();

		returnMap.put(COMPONENT_TEMPLATE_MASTER_V3, componentTemplateMasterList);
	}

	/**
	 * loadComponentStyleTemplateV3 will load component style from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentStyleTemplateV3(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		
		SelectQueryBuilder innerSQL1 = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.MAIN_LABEL_TEXT, Column.MAIN_LABEL_TEXT)
				.from(COMP_STYLE_HANDLER_MAIN,"hm")
				.where(
						ConditionBuilder.instance().eq("hm.main_label_code" , COMP_STYLE_HANDLER_MAIN_ALIAS + "." + Column.MAIN_LABEL_CODE, true)
						.and()
						.eq("hm.tag_name" , COMP_STYLE_HANDLER_MAIN_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.notEq("hm.main_label_text", "''")
						)
				.build(false);
		StatementBuilder stmnt1 = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMP_STYLE_HANDLER_MAIN_ALIAS + "." + Column.MAIN_LABEL_TEXT))
				.thenCondition(COMP_STYLE_HANDLER_MAIN_ALIAS + "." + Column.MAIN_LABEL_TEXT)
				.elseCondition(innerSQL1)
				.end();
		
		SelectQueryBuilder innerSQL2 = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.SUB_LABEL_TEXT, Column.SUB_LABEL_TEXT)
				.from(COMP_STYLE_HANDLER_SUB,"hs")
				.where(
						ConditionBuilder.instance().eq("hs.main_label_code" , COMP_STYLE_HANDLER_SUB_ALIAS + "." + Column.MAIN_LABEL_CODE, true)
						.and()
						.eq("hs.sub_label_code" , COMP_STYLE_HANDLER_SUB_ALIAS + "." + Column.SUB_LABEL_CODE, true)
						.and()
						.eq("hs.tag_name" , COMP_STYLE_HANDLER_SUB_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.notEq("hs.sub_label_text", "''")
						)
				.build(false);
		StatementBuilder stmnt2 = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMP_STYLE_HANDLER_SUB_ALIAS + "." + Column.SUB_LABEL_TEXT))
				.thenCondition(COMP_STYLE_HANDLER_SUB_ALIAS + "." + Column.SUB_LABEL_TEXT)
				.elseCondition(innerSQL2)
				.end();
		
		SelectQueryBuilder innerSQL3 = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.ATTRIBUTE_LABEL_TEXT, Column.ATTRIBUTE_LABEL_TEXT)
				.from(COMP_STYLE_DETAIL_ATTRIBUTE_LABEL,"dal")
				.where(
						ConditionBuilder.instance().eq("dal.attribute_id" , ATTRIBUTE_LABEL_ALIAS + "." + Column.ATTRIBUTE_ID, true)
						.and()
						.eq("dal.attribute_name" , ATTRIBUTE_LABEL_ALIAS + "." + Column.ATTRIBUTE_NAME, true)
						.and()
						.eq("dal.attribute_label" , ATTRIBUTE_LABEL_ALIAS + "." + Column.ATTRIBUTE_LABEL, true)
						.and()
						.notEq("dal.attribute_label_text", "''")
						)
				.build(false);
		StatementBuilder stmnt3 = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(ATTRIBUTE_LABEL_ALIAS + "." + Column.ATTRIBUTE_LABEL_TEXT))
				.thenCondition(ATTRIBUTE_LABEL_ALIAS + "." + Column.ATTRIBUTE_LABEL_TEXT)
				.elseCondition(innerSQL3)
				.end();
		
		List<Map<String, Object>> componentList = selectQueryBuilder.from(COMP_STYLE_DETAIL_TEMPLATE_NAME, COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS)
				.join(COMP_STYLE_HANDLER_MAIN, COMP_STYLE_HANDLER_MAIN_ALIAS, ConditionBuilder.instance()

						.eq(COMP_STYLE_HANDLER_MAIN_ALIAS + "." + TAG_NAME,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + TAG_NAME, true)

						.and().eq(COMP_STYLE_HANDLER_MAIN_ALIAS + "." + MAIN_LABEL_CODE,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + MAIN_LABEL_CODE, true))

				.join(COMP_STYLE_HANDLER_SUB, COMP_STYLE_HANDLER_SUB_ALIAS, ConditionBuilder.instance()

						.eq(COMP_STYLE_HANDLER_SUB_ALIAS + "." + TAG_NAME,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + TAG_NAME, true)

						.and()
						.eq(COMP_STYLE_HANDLER_SUB_ALIAS + "." + MAIN_LABEL_CODE,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + MAIN_LABEL_CODE, true)

						.and().eq(COMP_STYLE_HANDLER_SUB_ALIAS + "." + SUB_LABEL_CODE,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + SUB_LABEL_CODE, true))
				.leftJoin(COMP_STYLE_DETAIL_ATTRIBUTE_LABEL, ATTRIBUTE_LABEL_ALIAS, ConditionBuilder.instance()

						.eq(ATTRIBUTE_LABEL_ALIAS + "." + ATTRIBUTE_ID,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + ATTRIBUTE_ID, true)

						.and()
						.eq(ATTRIBUTE_LABEL_ALIAS + "." + ATTRIBUTE_NAME,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + ATTRIBUTE_NAME, true)

						.and().eq(ATTRIBUTE_LABEL_ALIAS + "." + ATTRIBUTE_LABEL,
								COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + ATTRIBUTE_LABEL, true))
				
				.get(COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + ".*")
				.get(stmnt1,Column.MAIN_LABEL_TEXT)
				.get(stmnt2,Column.SUB_LABEL_TEXT)
				.get(stmnt3,Column.ATTRIBUTE_LABEL_TEXT)
				.get(COMP_STYLE_HANDLER_MAIN_ALIAS + "." + DISPLAY_ORDER + " as style_main_display_order",
						COMP_STYLE_HANDLER_MAIN_ALIAS + "." + CLASS_NAME + " as style_main_class_name")

				.get(COMP_STYLE_HANDLER_SUB_ALIAS + "." + DISPLAY_ORDER + " as style_sub_display_order",
						COMP_STYLE_HANDLER_SUB_ALIAS + "." + CLASS_NAME + " as style_sub_class_name")
				

				.orderBy(COMP_STYLE_HANDLER_MAIN_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
//				.orderBy(COMP_STYLE_HANDLER_SUB_ALIAS + "." + DISPLAY_ORDER, SortType.ASC)
				.orderBy(COMP_STYLE_DETAIL_TEMPLATE_NAME_ALIAS + "." + DISPLAY_ORDER, SortType.ASC).build(false)
				.execute();

		LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>> componentAndStyleLinkDataMap = componentList
				.stream()
				.filter(item -> Objects.nonNull(item.get(TAG_NAME)) && Objects.nonNull(item.get(MAIN_LABEL_CODE)))
				.collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new, Collectors
						.groupingBy(map -> map.get(MAIN_LABEL_CODE), LinkedHashMap::new, Collectors.groupingBy(key -> {
							if (!Objects.isNull(key.get(SUB_LABEL_CODE))) {
								return key.get(SUB_LABEL_CODE);
							}
							return key.get(MAIN_LABEL_CODE);
						}, LinkedHashMap::new, Collectors.toList()))));
		returnMap.put(COMPONENT_STYLE_DETAIL_TEMPLATE_V3, componentAndStyleLinkDataMap);
	}

	/**
	 * loadComponentStyleDataV3 will load component data from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentStyleDataV3(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();

		List<Map<String, Object>> componentList = selectQueryBuilder.from(COMP_STYLE_DETAIL_DATA, COMP_STYLE_DETAIL_DATA_ALIAS).build(false)
				.execute();

		LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>>>>>> componentStyleDataMap = componentList
				.stream()
				.filter(item -> ((Objects.nonNull(item.get(TEMPLATE_NAME)) && Objects.nonNull(item.get(TAG_NAME)))
						&& (Objects.nonNull(item.get(STYLE_TYPE)) && Objects.nonNull(item.get(STYLE_STATE)))
						&& (Objects.nonNull(item.get(MAIN_LABEL_CODE)) && Objects.nonNull(item.get(ATTRIBUTE_NAME)))
						&& (Objects.isNull(item.get(INSIDE_COMP_CLASS_NAME))
								|| StringUtils.isEmpty(item.get(INSIDE_COMP_CLASS_NAME)) 
								|| INSIDE_COMP_NONE.equals(item.get(INSIDE_COMP_CLASS_NAME)))))

				.collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new,
						Collectors.groupingBy(map -> map.get(TEMPLATE_NAME), LinkedHashMap::new,
								Collectors.groupingBy(map -> map.get(STYLE_TYPE), LinkedHashMap::new,
										Collectors.groupingBy(map -> map.get(STYLE_STATE), LinkedHashMap::new,
												Collectors.groupingBy(map -> map.get(MAIN_LABEL_CODE),
														LinkedHashMap::new, Collectors.groupingBy(map -> {
															if (!Objects.isNull(map.get(SUB_LABEL_CODE))) {
																return map.get(SUB_LABEL_CODE);
															}
															return map.get(MAIN_LABEL_CODE);
														}, LinkedHashMap::new,
																Collectors.groupingBy(map -> map.get(ATTRIBUTE_NAME),
																		LinkedHashMap::new, Collectors.toList()))))))));

		LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>>>>>>> componentStyleInsideCompDataMap = componentList
				.stream()
				.filter(item -> ((Objects.nonNull(item.get(TEMPLATE_NAME)) && Objects.nonNull(item.get(TAG_NAME)))
						&& (Objects.nonNull(item.get(STYLE_TYPE)) && Objects.nonNull(item.get(STYLE_STATE)))
						&& (Objects.nonNull(item.get(MAIN_LABEL_CODE)) && Objects.nonNull(item.get(ATTRIBUTE_NAME)))
						&& (Objects.nonNull(item.get(INSIDE_COMP_CLASS_NAME))
								&& !StringUtils.isEmpty(item.get(INSIDE_COMP_CLASS_NAME))
								&& !INSIDE_COMP_NONE.equals(item.get(INSIDE_COMP_CLASS_NAME)))))

				.collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new,
						Collectors.groupingBy(map -> map.get(INSIDE_COMP_CLASS_NAME), LinkedHashMap::new,
								Collectors.groupingBy(map -> map.get(TEMPLATE_NAME), LinkedHashMap::new,
										Collectors.groupingBy(map -> map.get(STYLE_TYPE), LinkedHashMap::new,
												Collectors.groupingBy(map -> map.get(STYLE_STATE), LinkedHashMap::new,
														Collectors.groupingBy(map -> map.get(MAIN_LABEL_CODE),
																LinkedHashMap::new, Collectors.groupingBy(map -> {
																	if (!Objects.isNull(map.get(SUB_LABEL_CODE))) {
																		return map.get(SUB_LABEL_CODE);
																	}
																	return map.get(MAIN_LABEL_CODE);
																}, LinkedHashMap::new,
																		Collectors.groupingBy(
																				map -> map.get(ATTRIBUTE_NAME),
																				LinkedHashMap::new,
																				Collectors.toList())))))))));

		returnMap.put(COMPONENT_STYLE_DATA_V3, componentStyleDataMap);
		returnMap.put(COMPONENT_STYLE_INSIDE_COMP_DATA_V3, componentStyleInsideCompDataMap);

	}

	/**
	 * loadComponentStyleInsideCompV3 will load inside component data from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentStyleInsideCompV3(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		SelectQueryBuilder innerSQL1 = queryBuilderInstance.select()
				.lang(true)
				.setLanguage("en")
				.concat(Column.INSIDE_COMP_TEXT, Column.INSIDE_COMP_TEXT)
				.from(COMP_STYLE_INSIDE_COMPONENT,"sic")
				.where(
						ConditionBuilder.instance().eq("sic.inside_comp" , COMP_STYLE_INSIDE_COMPONENT_ALIAS + "." + "inside_comp", true)
						.and()
						.eq("sic.inside_comp_class_name" , COMP_STYLE_INSIDE_COMPONENT_ALIAS + "." + Column.INSIDE_COMP_CLASS_NAME, true)
						.and()
						.eq("sic.tag_name" , COMP_STYLE_INSIDE_COMPONENT_ALIAS + "." + Column.TAG_NAME, true)
						.and()
						.notEq("sic.inside_comp_text", "''")
						)
				.build(false);
		StatementBuilder stmnt1 = StatementBuilder.instance()
				.caseExp().
				whenCondition(ConditionBuilder.instance().isNotNull(COMP_STYLE_INSIDE_COMPONENT_ALIAS + "." + Column.INSIDE_COMP_TEXT))
				.thenCondition(COMP_STYLE_INSIDE_COMPONENT_ALIAS + "." + Column.INSIDE_COMP_TEXT)
				.elseCondition(innerSQL1)
				.end();
		List<Map<String, Object>> componentList  = selectQueryBuilder.from(COMP_STYLE_INSIDE_COMPONENT, COMP_STYLE_INSIDE_COMPONENT_ALIAS)
				.get(COMP_STYLE_INSIDE_COMPONENT_ALIAS + ".*")
				.get(stmnt1,Column.INSIDE_COMP_TEXT)
				.build(false).execute();

		LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>> insideComponentDataMap = componentList
				.stream()
				.filter(item -> Objects.nonNull(item.get(INSIDE_COMP_CLASS_NAME))
						&& Objects.nonNull(item.get(TAG_NAME)))
				.collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new, Collectors
						.groupingBy(map -> map.get(INSIDE_COMP_CLASS_NAME), LinkedHashMap::new, Collectors.toList())));

		returnMap.put(COMPONENT_STYLE_INSIDE_COMP_V3, insideComponentDataMap);
	}

	/**
	 * loadComponentStylePropsDataV3 will load props component data from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadComponentStylePropsDataV3(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		List<Map<String, Object>> componentList = selectQueryBuilder.from(COMP_STYLE_PROPS_DATA, COMP_STYLE_PROPS_DATA_ALIAS).build(false)
				.execute();

		LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>>> stylePropsDataMap = componentList
				.stream()
				.filter(item -> ((Objects.nonNull(item.get(TEMPLATE_NAME)) && Objects.nonNull(item.get(TAG_NAME)))
						&& (Objects.nonNull(item.get(STYLE_TYPE)) && Objects.nonNull(item.get(ATTRIBUTE_NAME)))))
				.collect(Collectors.groupingBy(map -> map.get(TAG_NAME), LinkedHashMap::new,
						Collectors.groupingBy(map -> map.get(TEMPLATE_NAME), LinkedHashMap::new,
								Collectors.groupingBy(map -> map.get(STYLE_TYPE), LinkedHashMap::new,
										Collectors.groupingBy(map -> map.get(ATTRIBUTE_NAME), LinkedHashMap::new,
												Collectors.toList())))));

		returnMap.put(COMPONENT_STYLE_PROPS_DATA_V3, stylePropsDataMap);
	}
	
	/**
	 * loadThemeDetail will load themes from database
	 * 
	 * @param returnMap
	 * @throws QueryException 
	 */
	public void loadThemeDetail(Map<String, Object> returnMap) throws QueryException  {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		List<Map<String, Object>> themeList = selectQueryBuilder.from(THEME_DETAIL, THEME_DETAIL_ALIAS)
				.build(false).execute();

		returnMap.put(THEME_DETAIL_DATA, themeList);
	}
	
	/**
	 * upsertTenantThemeDetails will upsert tenant theme details
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> upsertTenantThemeDetails(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> 
				resultMap.put(TENANT_THEME_DETAIL + "." + updateKey, mapper.get(updateKey))
			);
			return resultMap;
		}).collect(Collectors.toList());

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(TENANT_THEME_DETAIL, dataList, true, Arrays.asList(JSON_VALUE),
				TENANT_ID, PRODUCT_CODE);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
	
	/**
	 * insertThemeDetails will insert theme details
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> insertThemeDetails(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> {
				if (org.apache.commons.lang3.StringUtils.equals(Column.THEME_NAME, updateKey)) {
					resultMap.put(THEME_DETAIL + "." + THEME_CODE, 
							AutonumberService.getNextAutonumber("nn_theme_code", EnvironmentReader.getBtProduct(), THEME_DETAIL).replace("_", "_" + mapper.get(updateKey) + "_"));
				}
				resultMap.put(THEME_DETAIL + "." + updateKey, mapper.get(updateKey));
			});
			resultMap.put(THEME_DETAIL + "." + CREATED_BY, ContextBean.getUserId());
			resultMap.put(THEME_DETAIL + "." + CREATED_AT, timestamp);
			resultMap.put(THEME_DETAIL + "." + UPDATED_BY, ContextBean.getUserId());
			resultMap.put(THEME_DETAIL + "." + UPDATED_AT, timestamp);
			resultMap.put(THEME_DETAIL + "." + IS_DEFAULT, false);
			return resultMap;
		}).collect(Collectors.toList());
		

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(THEME_DETAIL, dataList, true, Arrays.asList(JSON_VALUE),
				THEME_CODE);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_theme_detail_data";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put("insertedTheme", dataList);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
	
	/**
	 * upsertThemeDetails will update theme details
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> upsertThemeDetails(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> 
				resultMap.put(THEME_DETAIL + "." + updateKey, mapper.get(updateKey))
			);
			resultMap.put(THEME_DETAIL + "." + CREATED_BY, ContextBean.getUserId());
			resultMap.put(THEME_DETAIL + "." + CREATED_AT, timestamp);
			resultMap.put(THEME_DETAIL + "." + UPDATED_BY, ContextBean.getUserId());
			resultMap.put(THEME_DETAIL + "." + UPDATED_AT, timestamp);
			return resultMap;
		}).collect(Collectors.toList());
		

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(THEME_DETAIL, dataList, true, Arrays.asList(JSON_VALUE),
				THEME_CODE);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_theme_detail_data";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
	
	/**
	 * insertTemplate will insert template name
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> insertTemplate(List<Map<String, Object>> insertList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		List<Map<String, Object>> dataList = insertList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> {
				if (org.apache.commons.lang3.StringUtils.equals(Column.TEMPLATE_NAME_TEXT, updateKey)) {
					String tenantId = ContextBean.getTenantId();
					resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + TEMPLATE_NAME, tenantId +
							AutonumberService.getNextAutonumber("nn_template_name", EnvironmentReader.getBtProduct(), COMP_STYLE_TEMPLATE_NAME_MASTER).replace("_", "_" + mapper.get(updateKey) + "_"));
				}
				resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + updateKey, mapper.get(updateKey));
			});
			resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + CREATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + CREATED_AT, timestamp);
			resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + UPDATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + UPDATED_AT, timestamp);
			return resultMap;
		}).collect(Collectors.toList());
		

		queryBuilderInstance
			.insert()
			.insertWithList(COMP_STYLE_TEMPLATE_NAME_MASTER, dataList);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_template_mst";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put("insertedTemplate", dataList);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
	
	/**
	 * copyTemplate will insert template name
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> copyTemplate(List<Map<String, Object>> copyList,String compName, String newTemplateName, String existingTemplateName) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		String tenantId = ContextBean.getTenantId();
		String copyTemplateKey = tenantId + AutonumberService.getNextAutonumber("nn_template_name", EnvironmentReader.getBtProduct(), COMP_STYLE_TEMPLATE_NAME_MASTER);
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		List<Map<String,Object>> result = selectQueryBuilder.from(COMP_STYLE_TEMPLATE_NAME_MASTER).lang(true).where(ConditionBuilder.instance().eq(Column.TEMPLATE_NAME, existingTemplateName)).build(false).execute();
		if(result.size() > 0) {
			List<Map<String, Object>> dataList = copyList.stream().map(mapper -> {
				Map<String, Object> resultMap = new HashMap<>();
				mapper.keySet().stream().forEach(updateKey -> {
					if (org.apache.commons.lang3.StringUtils.equals(Column.TEMPLATE_NAME_TEXT, updateKey)) {
						resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + TEMPLATE_NAME, copyTemplateKey.replace("_", "_" + mapper.get(updateKey) + "_"));
					}
					resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + updateKey, mapper.get(updateKey));
				});
				resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + CREATED_BY, ContextBean.getUserId());
				resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + CREATED_AT, timestamp);
				resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + UPDATED_BY, ContextBean.getUserId());
				resultMap.put(COMP_STYLE_TEMPLATE_NAME_MASTER + "." + UPDATED_AT, timestamp);
				return resultMap;
			}).collect(Collectors.toList());
			queryBuilderInstance
			.insert()
			.insertWithList(COMP_STYLE_TEMPLATE_NAME_MASTER, dataList);
			String userLocale = UserContext.getInstance().locale();
			String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_template_mst";
			CacheService.getInstance().removeCacheByKey(cacheKey);
			Map<String, Object> copyTemplateMap = new HashMap<>();
			if(dataList.size() > 0) {
				dataList.get(0).forEach((key,value) -> 
				copyTemplateMap.put(key.replace("comp_style_template_name_master.", ""), value));
				returnMap.put("copyTemplate", copyTemplateMap);
			} else {
				returnMap.put("copyTemplate", copyTemplateMap);
			}
			selectQueryBuilder = queryBuilderInstance.select();
			List<Map<String,Object>> existingVariantResult = selectQueryBuilder.from(COMP_STYLE_MASTER).lang(true).where(ConditionBuilder.instance().eq(Column.TEMPLATE_NAME, existingTemplateName)).build(false).execute();
			if(existingVariantResult.size() > 0 ) {
			    List<Map<String, Object>> copyVariantList = existingVariantResult.stream().map(mapper -> {
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put("template_name", copyTemplateKey);
				resultMap.put("tag_name", mapper.get("tag_name"));
				resultMap.put("style_type", mapper.get("style_type"));
				resultMap.put("style_type_text", mapper.get("style_type_text"));
				resultMap.put("display_order",  mapper.get("display_order"));
				resultMap.put("is_default",  mapper.get("is_default"));
				return resultMap;
			    }).collect(Collectors.toList());
			    Map<String, Object> copiedVariantMap = insertCopyVariants(copyVariantList);
			    returnMap.put("copiedVariant", copiedVariantMap.get("insertedVariant"));
			    selectQueryBuilder = queryBuilderInstance.select();
			    List<Map<String,Object>> existingStyleResult = selectQueryBuilder.from(COMP_STYLE_DETAIL_DATA).lang(true).where(ConditionBuilder.instance().eq(Column.TEMPLATE_NAME, existingTemplateName)).build(false).execute();
			    if(existingStyleResult.size() > 0 ) {
				   List<Map<String, Object>> copyStyleList = existingStyleResult.stream().map(mapper -> {
				       Map<String, Object> resultMap = new HashMap<>();
				       resultMap = mapper;
				       resultMap.put(TEMPLATE_NAME,copyTemplateKey);
			           resultMap.put(TAG_NAME, mapper.get(TAG_NAME) != null ? mapper.get(TAG_NAME) : "default");
			           resultMap.put(STYLE_TYPE, mapper.get(STYLE_TYPE) != null ? mapper.get(STYLE_TYPE) : "default");
			           resultMap.put(STYLE_STATE, mapper.get(STYLE_STATE) != null ? mapper.get(STYLE_STATE) : "default");
			           resultMap.put(MAIN_LABEL_CODE, mapper.get(MAIN_LABEL_CODE) != null ? mapper.get(MAIN_LABEL_CODE) : "default");
			           resultMap.put(SUB_LABEL_CODE, mapper.get(SUB_LABEL_CODE) != null ? mapper.get(SUB_LABEL_CODE) : "default");
			           resultMap.put(ATTRIBUTE_NAME, mapper.get(ATTRIBUTE_NAME) != null ? mapper.get(ATTRIBUTE_NAME) : "default");
			           resultMap.put(INSIDE_COMP_CLASS_NAME, mapper.get(INSIDE_COMP_CLASS_NAME) != null && !mapper.get(INSIDE_COMP_CLASS_NAME).toString().isEmpty() ? mapper.get(INSIDE_COMP_CLASS_NAME) : "none");
				       resultMap.put(TEMPLATE_NAME,copyTemplateKey);
				       return resultMap;
			      }).collect(Collectors.toList());
			    upsertComponentInlineStyleV3(copyStyleList);
			    returnMap.put("copiedStyleDetailMap", copyStyleList);
			    }
			    selectQueryBuilder = queryBuilderInstance.select();
			    List<Map<String,Object>> existingPropResult = selectQueryBuilder.from(COMP_STYLE_PROPS_DATA).lang(true).where(ConditionBuilder.instance().eq(Column.TEMPLATE_NAME, existingTemplateName)).build(false).execute();
                if(existingPropResult.size() > 0) {
			         List<Map<String, Object>> copyPropsList = existingPropResult.stream().map(mapper -> {
				            Map<String, Object> resultMap = new HashMap<>();
				            resultMap = mapper;
				            resultMap.put(TEMPLATE_NAME,copyTemplateKey);
				            return resultMap;
			                }).collect(Collectors.toList());
			                upsertInlineStylePropsDataV3(copyPropsList);
			               returnMap.put("copiedPropDetailMap", copyPropsList);
			     }
			}
		  returnMap.put(STATUS, SUCCESS);
		} else {
	     returnMap.put("error", "Copied Data not exist");
		 returnMap.put(STATUS, FAILURE);
		}		
		return returnMap;
	}
	
	/**
	 * insertVariants will insert Variant for the component
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> insertVariants(List<Map<String, Object>> insertList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		List<Map<String, Object>> dataList = insertList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> {
				if (org.apache.commons.lang3.StringUtils.equals(Column.STYLE_TYPE_TEXT, updateKey)) {
					String tenantId = ContextBean.getTenantId();
					resultMap.put(COMP_STYLE_MASTER + "." + STYLE_TYPE, tenantId +
							AutonumberService.getNextAutonumber("nn_style_type", EnvironmentReader.getBtProduct(), COMP_STYLE_MASTER).replace("_", "_" + mapper.get(updateKey) + "_"));
				}
				resultMap.put(COMP_STYLE_MASTER + "." + updateKey, mapper.get(updateKey));
			});
			resultMap.put(COMP_STYLE_MASTER + "." + IS_DEFAULT, false);
			resultMap.put(COMP_STYLE_MASTER + "." + CREATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_MASTER + "." + CREATED_AT, timestamp);
			resultMap.put(COMP_STYLE_MASTER + "." + UPDATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_MASTER + "." + UPDATED_AT, timestamp);
			return resultMap;
		}).collect(Collectors.toList());
		

		queryBuilderInstance
		  .insert()
		  .insertWithList(COMP_STYLE_MASTER, dataList);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put("insertedVariant", dataList);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
		
	}
	
	
	/**
	 * insertVariants will insert Variant for the component
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> insertCopyVariants(List<Map<String, Object>> copyVariantList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		List<Map<String, Object>> dataList = copyVariantList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> {
				resultMap.put(COMP_STYLE_MASTER + "." + updateKey, mapper.get(updateKey));
			});
			resultMap.put(COMP_STYLE_MASTER + "." + CREATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_MASTER + "." + CREATED_AT, timestamp);
			resultMap.put(COMP_STYLE_MASTER + "." + UPDATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_MASTER + "." + UPDATED_AT, timestamp);
			return resultMap;
		}).collect(Collectors.toList());
		

		queryBuilderInstance
		  .insert()
		  .insertWithList(COMP_STYLE_MASTER, dataList);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put("insertedVariant", dataList);
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
		
	}
	
	/**
	 * copyVariants will insert new Variant with respect to existing variant for the component
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> copyVariants(List<Map<String, Object>> copyList, String compName, String selectedTemplate, String existedVariantText) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		String tenantId = ContextBean.getTenantId();
		String copyStyleKey = tenantId +
				AutonumberService.getNextAutonumber("nn_style_type", EnvironmentReader.getBtProduct(), COMP_STYLE_MASTER);
		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(TEMPLATE_NAME , selectedTemplate).
				and().eq(STYLE_TYPE, existedVariantText);
		
		List<Map<String,Object>> resultList = selectQueryBuilder.from(COMP_STYLE_MASTER).lang(true).where(conditionBuilder).build(false).execute();
		if(resultList.size() > 0 ) {
		List<Map<String, Object>> dataList = resultList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> {
				if (org.apache.commons.lang3.StringUtils.equals(Column.STYLE_TYPE_TEXT, updateKey) ) {
					resultMap.put(COMP_STYLE_MASTER + "." + STYLE_TYPE, copyStyleKey.replace("_", "_" + mapper.get(updateKey) + "_"));
				}
				resultMap.put(COMP_STYLE_MASTER + "." + updateKey, mapper.get(updateKey));
			});
			resultMap.put(COMP_STYLE_MASTER + "." + Column.STYLE_TYPE_TEXT, copyList.get(0).get("style_type_text"));
			resultMap.put(COMP_STYLE_MASTER + "." + STYLE_TYPE_TEXT, copyList.get(0).get("style_type_text"));
			resultMap.put(COMP_STYLE_MASTER + "." + IS_DEFAULT, false);
			resultMap.put(COMP_STYLE_MASTER + "." + CREATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_MASTER + "." + CREATED_AT, timestamp);
			resultMap.put(COMP_STYLE_MASTER + "." + UPDATED_BY, ContextBean.getUserId());
			resultMap.put(COMP_STYLE_MASTER + "." + UPDATED_AT, timestamp);
			return resultMap;
		}).collect(Collectors.toList());
        queryBuilderInstance
		  .insert()
		  .insertWithList(COMP_STYLE_MASTER, dataList);
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		returnMap.put("copiedVariant", dataList);
		selectQueryBuilder = queryBuilderInstance.select();
	    List<Map<String,Object>> existingStyleResult = selectQueryBuilder.from(COMP_STYLE_DETAIL_DATA).lang(true).where(conditionBuilder).build(false).execute();
	    if(existingStyleResult.size() > 0 ) {
		       List<Map<String, Object>> copyStyleList = existingStyleResult.stream().map(mapper -> {
		       Map<String, Object> resultMap = new HashMap<>();
		       resultMap = mapper;
		       resultMap.put(STYLE_TYPE,copyStyleKey);
		       resultMap.put(TEMPLATE_NAME,selectedTemplate);
		       return resultMap;
	    }).collect(Collectors.toList());
	    upsertComponentInlineStyleV3(copyStyleList);
	    returnMap.put("copiedStyleDetailMap", existingStyleResult);
	    }
	    selectQueryBuilder = queryBuilderInstance.select();
	    List<Map<String,Object>> existingPropResult = selectQueryBuilder.from(COMP_STYLE_PROPS_DATA).lang(true).where(conditionBuilder).build(false).execute();
        if(existingPropResult.size() > 0) {
	            List<Map<String, Object>> copyPropsList = existingPropResult.stream().map(mapper -> {
		        Map<String, Object> resultMap = new HashMap<>();
		        resultMap = mapper;
		        resultMap.put(STYLE_TYPE,copyStyleKey);
		        resultMap.put(TEMPLATE_NAME,selectedTemplate);
		        return resultMap;
	    }).collect(Collectors.toList());
	    upsertInlineStylePropsDataV3(copyPropsList);
	    returnMap.put("copiedPropDetailMap", copyPropsList);
	    }     
		returnMap.put(STATUS, SUCCESS);
		} else {
	    returnMap.put("error", "Copied variant not exist");
	    returnMap.put(STATUS, FAILURE);
		}
		return returnMap;
		
	}
	
	/**
	 * deleteTemplate will delete template name
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> deleteTemplate(String templateName) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();

		queryBuilderInstance.delete()
			.from(COMP_STYLE_TEMPLATE_NAME_MASTER).where(ConditionBuilder.instance().eq(TEMPLATE_NAME, templateName))
			.build().execute();
		
		queryBuilderInstance.delete()
			.from(COMP_STYLE_MASTER).where(ConditionBuilder.instance().eq(TEMPLATE_NAME, templateName))
			.build().execute();
		
		queryBuilderInstance.delete()
			.from(COMP_STYLE_DETAIL_DATA).where(ConditionBuilder.instance().eq(TEMPLATE_NAME, templateName))
			.build().execute();
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_template_mst";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
	
	/**
	 * deleteVariant will delete Variant for the component
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> deleteVariant(String styleType, String templateType) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();

		queryBuilderInstance.delete()
			.from(COMP_STYLE_MASTER).where(ConditionBuilder.instance().eq(STYLE_TYPE, styleType).and()
					.eq(TEMPLATE_NAME, templateType))
			.build().execute();
		
		queryBuilderInstance.delete()
			.from(COMP_STYLE_DETAIL_DATA).where(ConditionBuilder.instance().eq(STYLE_TYPE, styleType).and()
					.eq(TEMPLATE_NAME, templateType))
			.build().execute();
		
//		need to execute this delete for props removal for the deleted variant facing issue in text table but table not present
//		queryBuilderInstance.delete()
//		.from(COMP_STYLE_PROPS_DATA).where(ConditionBuilder.instance().eq(STYLE_TYPE, styleType).and()
//				.eq(TEMPLATE_NAME, templateType))
//		.build().execute();
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
		
	}
	
	/**
	 * makeDefaultVariant will make Variant as default for the component
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> makeDefaultVariant(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> 
				resultMap.put(COMP_STYLE_MASTER + "." + updateKey, mapper.get(updateKey))
			);
			return resultMap;
		}).collect(Collectors.toList());

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(COMP_STYLE_MASTER, dataList, true, Arrays.asList(IS_DEFAULT),
				TEMPLATE_NAME, TAG_NAME, STYLE_TYPE);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		return returnMap;
	}
	
	/**
	 * removeDefaultVariant will remove Variant as default for the component
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> removeDefaultVariant(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		List<Map<String, Object>> dataList = updateList.stream().map(mapper -> {
			Map<String, Object> resultMap = new HashMap<>();
			mapper.keySet().stream().forEach(updateKey -> 
				resultMap.put(COMP_STYLE_MASTER + "." + updateKey, mapper.get(updateKey))
			);
			return resultMap;
		}).collect(Collectors.toList());

		InsertQueryBuilder upsertQueryBuilder = queryBuilderInstance.insert();
		upsertQueryBuilder.upsertWithKeyList(COMP_STYLE_MASTER, dataList, true, Arrays.asList(IS_DEFAULT),
				TEMPLATE_NAME, TAG_NAME, STYLE_TYPE);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		return returnMap;
	}
	
	/**
	 * updateTemplate will update template data
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> updateTemplate(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());

		Map<String, Object> mapper = updateList.get(0);
		String templateName = (String)mapper.get(TEMPLATE_NAME);

		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(TEMPLATE_NAME , templateName);


		queryBuilderInstance.update()
			.into(COMP_STYLE_TEMPLATE_NAME_MASTER, TEMPLATE_NAME, TEMPLATE_NAME_TEXT, UPDATED_BY, UPDATED_AT)
			.where(conditionBuilder).build()
			.execute(templateName, mapper.get(Column.TEMPLATE_NAME_TEXT), ContextBean.getUserId(), timestamp);

		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_template_mst";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
	
	/**
	 * updateVariant will update Variant data
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> updateVariant(List<Map<String, Object>> updateList) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());

		Map<String, Object> mapper = updateList.get(0); 
		
		String templateName = (String)mapper.get(TEMPLATE_NAME);
		String styleType = (String)mapper.get(STYLE_TYPE);
		String tagName = (String)mapper.get(TAG_NAME);
		
		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(TEMPLATE_NAME , templateName)
				.and().eq(STYLE_TYPE , styleType)
				.and().eq(TAG_NAME , tagName);
		

		queryBuilderInstance.update()
				.into(COMP_STYLE_MASTER, TEMPLATE_NAME, STYLE_TYPE, TAG_NAME, STYLE_TYPE_TEXT, UPDATED_BY, UPDATED_AT)
				.where(conditionBuilder).build()
				.execute(templateName, styleType, tagName, mapper.get(Column.STYLE_TYPE_TEXT), ContextBean.getUserId(), timestamp);
		
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + userLocale + "_inline_mst_v3";
		CacheService.getInstance().removeCacheByKey(cacheKey);
		
		returnMap.put(STATUS, SUCCESS);
		return returnMap;

	}
	
	/**
	 * check whether template name already exist.
	 * @param templateName
	 * @return
	 * @throws QueryException
	 */
	@Override
	public boolean validateIsTemplateExist(String templateName) throws QueryException {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		List<Map<String,Object>> result = selectQueryBuilder.from(COMP_STYLE_TEMPLATE_NAME_MASTER).lang(true).where(ConditionBuilder.instance().eq(Column.TEMPLATE_NAME_TEXT, templateName)).build(false).execute();
		return result.isEmpty() ? false : true; 
	}
	
	/**
	 * check whether theme name already exist.
	 * @param templateName
	 * @return
	 * @throws QueryException
	 */
	@Override
	public boolean validateIsThemeExist(String themeName) throws QueryException {
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		List<Map<String,Object>> result = selectQueryBuilder.from(THEME_DETAIL).lang(true).where(ConditionBuilder.instance().eq(Column.THEME_NAME, themeName)).build(false).execute();
		return result.isEmpty() ? false : true; 
	}
	
	private static class Column{
		public static final String STYLE_SUB_GROUP = "style_sub_group";
		public static final String TRIANGLE = "' [▲] '";
		public static final String COMPONENT_NAME = "component_name";
		public static final String TAG_NAME = "tag_name";
		public static final String COMPONENT_DESCRIPTION = "component_description";
		public static final String GROUP_TEXT = "group_text";
		public static final String ATTRIBUTE_GROUP = "attribute_group";
		public static final String TEXT_CONTENT = "text_content";
		public static final String ATTRIBUTE_COMPONENT_DESCRIPTION = "attribute_component_description";
		public static final String ATTRIBUTE_COMPONENT_LABEL = "attribute_component_label";
		public static final String ATTRIBUTE_NAME = "attribute_name";
		public static final String ATTRIBUTE_COMPONENT_PLACEHOLDER = "attribute_component_placeholder";
		public static final String STYLE_GROUP_KEY = "style_group_key";
		public static final String STYLE_GROUP = "style_group";
		public static final String STYLE_ATTRIBUTE_LABEL = "style_attribute_label";
		public static final String STYLE_TYPE_TEXT = "style_type_text";
		public static final String STYLE_TYPE = "style_type";
		public static final String TEMPLATE_NAME = "template_name";
		public static final String TEMPLATE_NAME_TEXT = "template_name_text";
		public static final String MAIN_LABEL_TEXT = "main_label_text";
		public static final String MAIN_LABEL_CODE = "main_label_code";
		public static final String SUB_LABEL_TEXT = "sub_label_text";
		public static final String SUB_LABEL_CODE = "sub_label_code";
		public static final String THEME_NAME = "theme_name";
		
		public static final String ATTRIBUTE_LABEL_TEXT = "attribute_label_text";
		public static final String ATTRIBUTE_ID = "attribute_id";
		public static final String ATTRIBUTE_LABEL = "attribute_label";
		public static final String INSIDE_COMP_TEXT = "inside_comp_text";
		
		public static final String INSIDE_COMP_CLASS_NAME = "inside_comp_class_name";
		public static final String TENANT_ID = "tenant_id";
		public static final String THEME_CODE = "theme_code";
		public static final String PRODUCT_CODE = "product_code";
		
	}
	
	/**
	 * defaultThemeForTenant will insert theme for tenant
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> defaultThemeForTenant(String themeName) throws QueryException  {
		Map<String, Object> returnMap = new HashMap<>();
		QueryBuilder queryBuilderInstance = new QueryBuilder();
		Timestamp timestamp = Timestamp.from(Instant.now());
		String tenantId = ContextBean.getTenantId();
		SelectQueryBuilder selectQueryBuilder = queryBuilderInstance.select();
		List<Map<String,Object>> result = selectQueryBuilder.from(THEME_TENANT_PRODUCT_LINK).where(ConditionBuilder.instance().eq(Column.TENANT_ID, tenantId).and().eq(Column.THEME_CODE, themeName).and().eq(Column.PRODUCT_CODE, "sova_def")).build(false).execute();
		if(result.size() == 0 ) {
		InsertQueryBuilder insertQueryBuilder = queryBuilderInstance.insert();
		List<Map<String,Object>> dataList = new ArrayList<>();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + TENANT_ID, tenantId);
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + PRODUCT_CODE, "sova_def");
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + THEME_CODE, themeName);
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + CREATED_BY, ContextBean.getUserId());
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + CREATED_AT, timestamp);
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + UPDATED_BY, ContextBean.getUserId());
		resultMap.put(THEME_TENANT_PRODUCT_LINK + "." + UPDATED_AT, timestamp);
		dataList.add(resultMap);
		insertQueryBuilder.upsertWithKeyList(THEME_TENANT_PRODUCT_LINK, dataList, true, 
				Arrays.asList(TENANT_ID,PRODUCT_CODE,THEME_CODE,CREATED_BY,CREATED_AT,UPDATED_BY,UPDATED_AT), TENANT_ID, PRODUCT_CODE);
		} else {
			returnMap.put(STATUS, "Already default added");
		}
		returnMap.put(STATUS, SUCCESS);
		return returnMap;
	}
}
