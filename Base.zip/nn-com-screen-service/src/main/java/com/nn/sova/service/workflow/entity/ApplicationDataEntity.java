package com.nn.sova.service.workflow.entity;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.nn.sova.service.workflow.enums.ApprovalStatusEnum;

import lombok.Data;

/**
 * ApplicationDataEntity entity class holds the application over details from Main table
 * and step details from steps table, this entity holds the full biography 
 * of individual application
 * 
 * @author punithanantony.d@vaken.cloud (Punithan Antony Das)
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationDataEntity{
	
	/** Application id */
	private UUID applicationId;
	
	/** Application version */
	private int version = 1;
	
	/** Application previous version */
	private int previousVersion = 0;
	
	/**Application screen id */
	private String screenId = "";
	
	/**Application screen Name */
	private String screenName = "";
	
	/** whether to use approval flow */
	private boolean useApproval  = true;
	
	/** whether the flow is application specific */
	private boolean applicationSpecific  = false;
	
	/** Application priority level*/
	private String priority = "NORMAL";
	
	/** Application previous priority */
	private String previousPriority = "NORMAL";
	
	/** Application current state*/
	private int applicationState = 0;
		
	/** Application Status*/
	private String applicationStatus = ApprovalStatusEnum.INPROGRESS.getValue();
	
	/** The application's unique id. */
	private String applicationUniqueId = StringUtils.EMPTY;
	
	/** Application submission date*/
	private String submissionDate;
	
	/** Application submission time stamp*/
	private Timestamp submissionTimeStamp;
	
	/** Application Due date*/
	private Timestamp dueDate;
	
	/** Applicant user id*/
	private String applicantId = "";
	
	/** Applicant Full Name */
	private String applicantName = "";
	
	/** applicant Image URL */
	private String applicantImageUrl = "";
	
	/** Applicant comment*/
	private String comment = "";
	
	/** user id who recently updated application status partially or fully*/
	private String statusModifierId = "";
	
	/** Whether the logged in user is applicant of current application*/
	private boolean actualApplicant = false;
	
	/** Whether the logged in user is one of the approver of current application*/
	private boolean actualApprover = false;
	
	/** Whether the application is already processed and completed*/
	private boolean applicationCompleted = false;
	
	/** Whether the application is saved already as draft*/
	private boolean draftedApplication = false;
	
	/** whether the application is duplicate */
	private boolean duplicate = false;
	
	/** Whether the application is saved as draft*/
	private boolean resubmitted = false;
	
	/** whether the process is batch */
	private boolean batchProcess = false;
	
	/** whether the process is bulk */
	private boolean bulkProcess = false;
	
	/** whether the application can be resubmitted directly */
	private boolean directResubmission = false;
	
	/** description of the application*/
	private String description = "";
	
	/** application created by the flow id */
	private String flowId = "";
	
	/** step number where the user can perform the MASTER Approval action*/
	private int masterStepNumber = 0;
	
	/** total number of steps in application*/
	private int totalSteps = 0;
	
	/** PROXY member map */
	private Map<String, String> proxyLinkMap = new HashMap<>();
	
	/** resubmitting PROXY member list */
	private List<String> resubmittingUserList = new ArrayList<>();
	
	/** resubmitting step number */
	private int resubmittingStep = 0;
	
	/** view path URL of the screen*/
	private String screenViewUrl = "";
	
	/** failure or success reason message */
	private String message;
	
	/** page number of current application*/
	private BigInteger page;
	
	/** total count of applications in current status */
	private BigInteger total;
	
	/** target application id*/
	private String targetAppId;
	
	/** target application version*/
	private String targetVersion;
	
	/** target screen id*/
	private String targetScreenId;
	
	/** list of Application steps*/
	private List<ApplicationStepEntity> applicationStepEntityList = new ArrayList<>();
	
	/** Applicant's Designation*/
	private String applicantDesignation;
	
	private boolean urgent = false;
}