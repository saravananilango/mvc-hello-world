package com.nn.sova.service.jobmanager.entity;

import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_CALLBACK_URLS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_API;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_PARAMETERS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.VERSION;

import java.util.List;
import java.util.Map;

import com.nn.sova.utility.jobmanager.entity.JobCallbackUrl;
import com.nn.sova.utility.jobmanager.entity.JobParameters;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * The Class {@code JobDefinitionApi} represents a row in
 * {@code job_definiton_api} table
 *
 * @author praveen_kumar_nr
 */
@Data
@EqualsAndHashCode(of = { "version" }, callSuper = true)
@ToString(callSuper = true)
public final class JobDefinitionApi extends AbsJobDefinition {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The version. */
	private String version;

	/** The callback url. */
	private JobCallbackUrl url;

	/** The job parameters. */
	private JobParameters jobParameters;

	/** The job callback urls. */
	private List<JobCallbackUrl> jobCallbackUrls;

	/**
	 * Instantiates a new job definition api.
	 */
	public JobDefinitionApi() {
		super(JOB_DEFINITION_API);
	}

	/**
	 * Instantiates a new {@code JobDefinitionFrameworkJar} from a map.
	 *
	 * @param dataMap the data map
	 */
	public JobDefinitionApi(Map<String, Object> dataMap) {
		super(JOB_DEFINITION_API, dataMap);
		this.version = (String)dataMap.get(VERSION);
		this.url = null; // FIXME : Yet to decide
		this.jobParameters = JobParameters.from(dataMap.get(JOB_PARAMETERS));
		this.jobCallbackUrls = JobCallbackUrl.from(dataMap.get(JOB_CALLBACK_URLS));
	}

}
