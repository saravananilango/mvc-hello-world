package com.nn.sova.service.dao.helpmaster;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * HelpMasterDao class used to make DB operation related to help master
 * 
 * @implments HelpMasterDao
 * @author Sakthivel
 */

public class HelpMasterDaoImpl implements HelpMasterDao {

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(HelpMasterDao.class);

	/** Constant **/
	private static final String HELP_MASTER = "help_master";

	/** Constant **/
	private static final String SCREEN_ID = "screen_id";

	/** Constant **/
	private static final String HELP_MASTER_ID = "help_master_id";
	
	/** Constant **/
	private static final String HELP_MASTER_TEMPLATE = "help_master_template";
	
	/** Constant **/
	private static final String HELP_MASTER_TEMPLATE_DATA = "help_master_template_data";
	
	/** Constant **/
	private static final String HELP_MASTER_TEMPLATE_METHODS = "help_master_template_methods";
	
	/** Constant **/
	private static final String HELP_MASTER_ATTRIBUTE = "help_master_attribute";
	
	/** Constant **/
	private static final String DISPLAY_OPTION = "display_option";

	/**
	 * getData method used to get the help master values stored in the database
	 * 
	 * @param {String} screenId
	 * @return {List<Object>} helpMasterList
	 */
	@Override
	public List<Map<String, Object>> getData(String screenId) {
		logger.info("getData method started for Help master screen id={}", screenId);
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		try {
			selectedDataList= queryBuilder.select()
					.getWithAliasName(HELP_MASTER_ID, "id")
					.getWithAliasName(HELP_MASTER_TEMPLATE, "template")
					.getWithAliasName(HELP_MASTER_TEMPLATE_DATA, "templateData")
					.getWithAliasName(HELP_MASTER_TEMPLATE_METHODS, "templateMethods")
					.getWithAliasName(HELP_MASTER_ATTRIBUTE, "helpMasterAttribute")
					.getWithAliasName(DISPLAY_OPTION, "displayOption")
					.from(HELP_MASTER)
					.where(ConditionBuilder.instance().eq(SCREEN_ID, screenId))
					.build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in getData method. " + exception);
		}
		logger.info("getData method ends...");
		return selectedDataList;
	}

	/**
	 * getData method used to get the help master values stored in the database
	 * 
	 * @param {String} screenId
	 * @param {String} helpMasterId
	 * @return {Object} helpMasterMap
	 */
	@Override
	public Map<String, Object> getData(String screenId, String helpMasterId) {
		logger.info("getData method started for screenId={}, helpMasterId={}.", screenId, helpMasterId);
		QueryBuilder queryBuilder = new QueryBuilder();
		Map<String, Object> helpMasterMap = new HashMap<>();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		try {
			selectedDataList= queryBuilder.select()
					.getWithAliasName(HELP_MASTER_ID, "id")
					.getWithAliasName(HELP_MASTER_TEMPLATE, "template")
					.getWithAliasName(HELP_MASTER_TEMPLATE_DATA, "templateData")
					.getWithAliasName(HELP_MASTER_TEMPLATE_METHODS, "templateMethods")
					.getWithAliasName(HELP_MASTER_ATTRIBUTE, "helpMasterAttribute")
					.getWithAliasName(DISPLAY_OPTION, "displayOption")
					.from(HELP_MASTER)
					.where(ConditionBuilder.instance().eq(HELP_MASTER_ID, helpMasterId))
					.build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in getData method. " + exception);
		}
		if(CollectionUtils.isNotEmpty(selectedDataList)) {
			helpMasterMap = selectedDataList.get(0);
		}
		logger.info("getData method ends...");
		return helpMasterMap;
	}
}