package com.nn.sova.service.utils.viewobject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParseException;
import com.nn.sova.changerequest.ChangeRequest;
import com.nn.sova.changerequest.ChangeRequestDao;
import com.nn.sova.changerequest.ChangeRequestStatusEnum;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.util.entity.CreateMatViewEntity;
import com.nn.sova.util.entity.CreateViewEntity;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

public class ViewObjectTransportUtils {
	
	/**
	 * logger for ViewObjectTransportUtils class
	 */
	private static ApplicationLogger logger = ApplicationLogger.create(ViewObjectTransportUtils.class);

	
	//status
	public void updateViewAfterTransport(Map<String,Object> dataMap) throws CustomException
	{
		logger.info("## call for updateViewAfterTransport from build process"+dataMap);
		try {
			String message = "";
			String changeRequestId = String.valueOf(dataMap.get("changeRequestId"));
			String status = String.valueOf(dataMap.get("repoStatus"));
			boolean revert = false;
			if(Objects.nonNull(dataMap.get("repoStatus"))&& String.valueOf(dataMap.get("repoStatus")).equalsIgnoreCase("REVERTED")){
				logger.info("## revert flag after status return"+dataMap.get("revert"));
				revert = true;
			}else if(Objects.nonNull(dataMap.get("repoStatus"))&& String.valueOf(dataMap.get("repoStatus")).equalsIgnoreCase("FAILURE")) {
				 message= Objects.toString(dataMap.get("errorStage"))+"_"+Objects.toString(dataMap.get("errorMessage")); 
			}
		Map<String, Object> resultDataMap = new HashMap<>();
		List<Map<String, Map<String, Object>>> transportDataList = new ArrayList<>();
		QueryBuilder queryBuilder = new QueryBuilder();
		if(!revert){
			logger.info("## call for generateViewRequestData from processViewObjectData");
				resultDataMap = generateViewRequestData(changeRequestId,queryBuilder);
			logger.info("##  generateViewRequestData call completed");
 			if(resultDataMap.containsKey("transportDataList")){
 		     transportDataList = (List<Map<String, Map<String, Object>>>) resultDataMap.get("transportDataList");
 		    logger.info("## transportDataList from processViewObjectData" +transportDataList);
 			}
 			for(Map<String, Map<String, Object>> transportDataMap : transportDataList){
 			for (Entry<String, Map<String, Object>> tables : transportDataMap.entrySet()) {
 				logger.info("View Name: " + tables.getKey());
 				Map<String, Object> tableValueMap = tables.getValue();
 				if(StringUtils.isEmpty(Objects.toString(tableValueMap.get("released_status"),""))){
 				tableValueMap.put("view_object_name", tables.getKey());
 				tableValueMap.put("changeRequestId", changeRequestId);
 				if(!String.valueOf(tableValueMap.get("viewType")).equals("create")){
 					logger.info("## call for updateForDelete after transport"+tableValueMap);
						updateForDelete(tables.getKey(), queryBuilder, status,tableValueMap,message);
				}else{
					logger.info("## call for updateForEditOrCreate after transport"+tableValueMap);
					updateForEditOrCreate(tables.getKey(), queryBuilder, status,tableValueMap,message);
				}
 				}
 			}
 			}
		}else{
			updateEmptyTableRequestConfig(queryBuilder, changeRequestId);
		}
 				logger.info("##commit change request---- updateViewAfterTransport");
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("## updateViewAfterTransport exception occured" + e.getMessage());
			throw new CustomException(e);
		}
	        
	}
	
	
	public void updateForEditOrCreate(String viewObject, QueryBuilder queryBuilder,String status, Map<String, Object> tabelValueMap, String message) throws CustomException {
		logger.info("updateForEditOrCreate method starts for transport "+viewObject);
		try{
			String changeRequestId = Objects.toString(tabelValueMap.get("changeRequestId"),"");
			String productCode = Objects.toString(tabelValueMap.get("productCode"),"");
			String versionNumber = Objects.toString(tabelValueMap.get("versionNumber"),"");
 			 List<Map<String, Object>> selectionList = queryBuilder.select().checkIndependentTenant(true).from(ViewObjectConstants.VIEW_OBJECT_DEFINITION).where(ConditionBuilder.instance()
						.eq("view_object_name", viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode)).build(false).execute();
 			 ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq("view_object_name", viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode); 
 			 if(!selectionList.isEmpty()){
 				 Map<String,Object> updateMap = new HashMap<>();
 				 if(StringUtils.equals(ChangeRequestStatusEnum.DELIVERED.name(), status)){
 					 updateMap.put(bindConfigTableWithColumn("source_status"), "RELEASED");
 					 updateMap.put(bindConfigTableWithColumn("error_message"), "");
 					 updateMap.put(bindConfigTableWithColumn("status_flag"), true);
 					 updateTableRequestConfig(queryBuilder, changeRequestId);
 				 }else{
					 updateEmptyTableRequestConfig(queryBuilder, changeRequestId);
 					 updateMap.put(bindConfigTableWithColumn("source_status"), "FAILURE");
 					 updateMap.put(bindConfigTableWithColumn("status_flag"), true);
 					 updateMap.put(bindConfigTableWithColumn("error_message"), message);
 				 }
 				 updateMap.put(bindConfigTableWithColumn("active_flag"), false);
 				updateMap.put(bindConfigTableWithColumn("updated_by"), Objects.toString(selectionList.get(0).get("updated_by"),Objects.toString(selectionList.get(0).get("created_by"),"")));
 				queryBuilder.update().skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, conditionBuilder);
 				if(!StringUtils.isEmpty(versionNumber)) {
 					conditionBuilder.and().eq(ViewObjectConstants.VERSION_NO, versionNumber);
 					Map<String,Object> activeMap = new HashMap<>();
 					activeMap.put(bindConfigTableWithColumn("active_flag"), true);
 					queryBuilder.update().skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, activeMap, conditionBuilder);
 				}
 			 }
 			logger.info("updateForEditOrCreate method ends for transport "+viewObject);
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}
	
	
	
	public void updateForDelete(String viewObject, QueryBuilder queryBuilder,String status, Map<String, Object> tabelValueMap, String message) throws CustomException {
		try{
			logger.info("updateForDelete started "+viewObject);
			String changeRequestId = Objects.toString(tabelValueMap.get("changeRequestId"),"");
			String productCode = Objects.toString(tabelValueMap.get("productCode"),"");
			String versionNumber = Objects.toString(tabelValueMap.get("versionNumber"),"");
 			 List<Map<String, Object>> selectionList = queryBuilder.select().checkIndependentTenant(true).from(ViewObjectConstants.VIEW_OBJECT_DEFINITION).where(ConditionBuilder.instance()
						.eq("view_object_name", viewObject).and().eq("product_code", productCode)).build(false).execute();
 			 ChangeRequest changeRequestObject = new ChangeRequest();
 			 if(!selectionList.isEmpty()){
 				 Map<String,Object> updateMap = new HashMap<>();
 				 if(StringUtils.equals(ChangeRequestStatusEnum.DELIVERED.name(), status)){
 					 Map<String,Object> tempDeleteMap = selectionList.get(0);
 					 if(Objects.nonNull(tempDeleteMap) && !tempDeleteMap.isEmpty()) {
 						 if(Boolean.parseBoolean(Objects.toString(tempDeleteMap.get("delete_flag"),"false"))){
 							logger.info("DELETE initiate since soft delete true"+viewObject);
 							 ConditionBuilder deleteBuilder = ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode);
 							 if(!StringUtils.isEmpty(versionNumber)) {
 								 deleteBuilder.and().eq(ViewObjectConstants.VERSION_NO,versionNumber);
 							 }
 							 queryBuilder.delete().skipTenantId(true).from(ViewObjectConstants.VIEW_OBJECT_DEFINITION).where(deleteBuilder).build().execute();
 							 queryBuilder.delete().skipTenantId(true).from(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS).where(deleteBuilder).build().execute();
 						 }else {
 							logger.info("DELETE skipped since soft delete false"+viewObject);
 							 updateMap.put(bindConfigTableWithColumn("source_status"), "RELEASED");
 		 					 updateMap.put(bindConfigTableWithColumn("error_message"), "");
 		 					 updateMap.put(bindConfigTableWithColumn("status_flag"), true);
 							updateMap.put(bindConfigTableWithColumn("updated_by"), Objects.toString(selectionList.get(0).get("updated_by"),Objects.toString(selectionList.get(0).get("created_by"),"")));
 			 				queryBuilder.update().skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().eq("view_object_name", viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
 						 }
 					 }
 					 updateTableRequestConfig(queryBuilder, changeRequestId);
 				 }else{
 					 updateMap.put(bindConfigTableWithColumn("source_status"), "FAILURE");
 					 updateMap.put(bindConfigTableWithColumn("status_flag"), false);
 					 updateMap.put(bindConfigTableWithColumn("delete_flag"), true);
 					  updateMap.put(bindConfigTableWithColumn("error_message"), message);
 					 updateMap.put(bindConfigTableWithColumn("updated_by"), Objects.toString(selectionList.get(0).get("updated_by"),Objects.toString(selectionList.get(0).get("created_by"),"")));
 					  updateEmptyTableRequestConfig(queryBuilder, changeRequestId);
 					 queryBuilder.update().skipChangeRequest(true).skipTenantId(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
 				 }
 			 }
 			logger.info("updateForDelete ends "+viewObject);
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}
	
	
	/**
	 * validateRequestId is used to get the requestId and validate it
	 * @param objectString
	 * @param paramMap
	 * @param sourceBranchId
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private boolean validateChangeRequestId(String objectString, Map<String, Object> paramMap) throws JsonParseException, JsonMappingException, IOException {
		if(objectString!=null && !StringUtils.isEmpty(objectString)){
			logger.debug("## validateChangeRequestId from BO method execution started.");
			  Map<String,Object> requestMap = new ObjectMapper().readValue(objectString,Map.class);
			  if(requestMap.containsKey("status") && Objects.nonNull(requestMap.get("status")) && !MapUtils.getBooleanValue(requestMap, "status")) {
				 addErrorMessage(paramMap, String.valueOf(requestMap.get("message")));
				  logger.debug("## validateChangeRequestId from BO method execution ended.  result: false");
				  return false;
			  }
			  if(Objects.nonNull(requestMap)){
				  paramMap.put("sourceBranchId", Objects.toString(requestMap.get("requestId"), ""));
				  logger.debug("## validateChangeRequestId from BO method execution ended.  result: true");
				  return true;
			  } else{
				  addErrorMessage(paramMap, "Change Request for source data is not created");
				  logger.debug("## validateChangeRequestId from BO method execution ended.  result: false");
				  return false;
			  }
		} else{
			
			addErrorMessage(paramMap, "System Id or Request Id is null");
			  paramMap.put(ViewObjectConstants.ERROR, "System Id or Request Id is null");
			  logger.debug("## validateChangeRequestId from BO method execution ended.  result: false");
			  return false;
		}
	}	

	
	private void updateTableRequestConfig(QueryBuilder queryBuilder ,String changeRequestId) throws CustomException {
		try {
			logger.info("updateTableRequestConfig  method info starts.---"+changeRequestId);
			Map<String,Object> updateMap = new HashMap<String, Object>(); 
			updateMap.put(ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS+".released_status", "RELEASED");
			queryBuilder.update().skipTenantId(true).forceUpdate(true).skipChangeRequest(true).updateWithMap(ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS, updateMap, ConditionBuilder.instance().eq("change_request_id", changeRequestId).and().eq("config_type", "VIEW"));
			logger.info("updateTableRequestConfig  method info ends---"+changeRequestId);
		} catch (Exception exp) {
			logger.info("updateTableRequestConfig  method exception "+exp); 
			throw new CustomException(exp);
		}
	}

	 /**
     * getChangeRequestStage method is used to get the stage of current change
     * request
     * 
     * @param changeRequestId
     * @return
	 * @throws CustomException 
     */
    public void deleteDeploymentHistory(QueryExecutor queryExecutor ,String changeRequestId) throws CustomException {
      try {
    	  queryExecutor.skipChangeRequest(true);
		queryExecutor.queryBuilder().delete().from("cr_transport_detail_history").skipTenantId(true).where(ConditionBuilder.instance().eq("change_request_id", changeRequestId)).build().execute();
		queryExecutor.skipChangeRequest(false);
	} catch (Exception exp) {
		throw new CustomException(exp);
		}
    }
	
  private void updateEmptyTableRequestConfig(QueryBuilder queryBuilder ,String changeRequestId) throws CustomException {
		try {
			logger.info("updateEmptyTableRequestConfig  method info starts.---"+changeRequestId);
			Map<String,Object> updateMap = new HashMap<String, Object>(); 
			updateMap.put(ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS+".released_status", "");
			queryBuilder.update().skipChangeRequest(true).skipTenantId(true).forceUpdate(true).updateWithMap(ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS, updateMap, ConditionBuilder.instance().eq("change_request_id", changeRequestId).and().eq("config_type", "VIEW"));
			logger.info("updateEmptyTableRequestConfig  method info ends.---"+changeRequestId);
		} catch (Exception exp) {
			logger.info("updateEmptyTableRequestConfig  method info exception.---");
			throw new CustomException(exp);
		}
	}

  /** generateRequestData is used to generate the data.
	 *  
	 * @param changeRequestId
	 * @param ivQueryExecutor 
	 * @return 
	 * @throws Exception 
	 */
	public static Map<String, Object> generateViewRequestData(String changeRequestId, QueryBuilder queryBuilder) throws Exception {
		logger.info("*** generateviewRequestData method execution Started. ***");
		Map<String,Object> resultMap = new HashMap<>();
		try {
			JSONParser jsonParser = new JSONParser();
			ObjectMapper objectMapper = new ObjectMapper(); 
			ChangeRequest changeRequest = new ChangeRequest();
			List<Map<String, Map<String, Object>>> transportDataList = new ArrayList<>();
			Object jsonObject = null;
			List<Object> parentRequestDetails = new ArrayList<>();
			 List<Map<String, Object>> requestIdDetails = getTableConfigChangeRequestDetails(changeRequestId,false,queryBuilder); 
			Map<String, Map<String, Object>> returnMap = new HashMap<>();
			Map<String,Object> dataConfigMap = new HashMap<>();
			for(Map<String,Object> requestDataMap : requestIdDetails) {
				String type = String.valueOf(requestDataMap.get("config_type"));
				jsonObject = jsonParser.parse(String.valueOf(requestDataMap.get("table_json")));
				Map<String,Object> transportDataMap = objectMapper.readValue(String.valueOf(jsonObject),new TypeReference<Map<String,Object>>() {});
				Map<String,Object> elementMap = (Map<String, Object>) transportDataMap.get("transportData");
				logger.info("*** transport data from table ***"+elementMap);
				if(type.equalsIgnoreCase("VIEW")){
				  elementMap.values().stream().forEach(action->{
						((Map<String, Object>) action).put("released_status",Objects.toString(requestDataMap.get("released_status"),""));
					});
					dataConfigMap.put(type, elementMap);
				}
				if(dataConfigMap.containsKey("VIEW")) {
					returnMap = (Map<String, Map<String, Object>>) dataConfigMap.get("VIEW");	
				}
				if(Objects.nonNull(returnMap) && !returnMap.isEmpty()){
					transportDataList.add(returnMap);
				}
			}
			resultMap.put("transportDataList", transportDataList);
			logger.info("*** generateviewRequestData method execution ended. ***");
			return resultMap;
		}catch(Exception exception) {
			logger.error("*** generateviewRequestData method excuetion failed ***" + exception.getMessage());
			throw new CustomException(exception.getMessage());
		}
	}

	/** getTableConfigChangeRequestDetails is used to get record from table_config_change_request_details table.
	 * @param changeRequestId
	 * @param queryExecutor 
	 * @return List
	 * @throws CustomException 
	 */
	public static List<Map<String,Object>> getTableConfigChangeRequestDetails(String changeRequestId,boolean sortable, QueryBuilder queryBuilder) throws CustomException{
		List<Map<String,Object>> requestHistoryList = new ArrayList<>();
		SelectQueryBuilder selectBuilder = queryBuilder.btSchema().select().from(ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS);
		ConditionBuilder condition = ConditionBuilder.instance().eq("change_request_id", changeRequestId);
		selectBuilder.where(condition);
		if(sortable){
			selectBuilder.orderBy("update_date", SortType.DESC_NULLS_LAST);
		}
		try {
			requestHistoryList= selectBuilder.build(false).execute();
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
		return requestHistoryList;
	}
	
	



	/**
	 * beforeCrExecution used to validate the data before cr execution.
	 * 
	 * @param paramMap
	 * @return Map
	 * @throws CustomException 
	 */
	public Map<String, Object> beforeViewCrExecution(Map<String, Object> paramMap) throws CustomException {
		Map<String, Object> resultMap = new HashMap<>();
		QueryExecutor queryExecutor = null;
		logger.info("beforeCrExecution method starts...");
		try {
			if(paramMap.containsKey("btExecutor")) {
				queryExecutor =(QueryExecutor) paramMap.get("btExecutor");
			}
		String changeRequestId = String.valueOf(paramMap.get("changeRequestId"));
		boolean isRevert = Boolean.parseBoolean(String.valueOf(paramMap.get("isRevert")));
		List<Map<String, Object>> changeRequestHistoryList = getChangeRequestHistoryList(changeRequestId);
		if(changeRequestHistoryList.isEmpty()) {
			paramMap.put("status", false);
			paramMap.put("message", "No data present in change request.");
			return paramMap;
		}
			resultMap = processViewDefinition(changeRequestHistoryList, isRevert,queryExecutor,paramMap);
		resultMap.put("btExecutor", queryExecutor);
		logger.info("beforeCrExecution method ends...");
		}catch(Exception exception) {
			rollBackExecutor(queryExecutor);
			logger.error("exception"+exception);
			resultMap.put("status", false);
			resultMap.put("message", exception.getMessage());
			return resultMap;
		}
		return resultMap;
	}

	/**
	 * afterCrExecution used to validate the data after cr execution.
	 * 
	 * @param paramMap
	 * @return Map
	 */
	public Map<String, Object> afterViewCrExecution(Map<String, Object> paramMap) {
		logger.info("afterCrExecution method starts...");
		Map<String, Object> resultMap ;
			resultMap = processViewObjectAfterCrExecution(paramMap);
		logger.info("afterCrExecution method ends...");
		return resultMap;
	}




	/**
	 * getDataList used to get the data list.
	 * 
	 * @param tableName
	 * @param condition
	 * @param queryExecutor
	 * @return List
	 * @throws CustomException
	 */
	private List<Map<String, Object>> getDataList(String tableName, ConditionBuilder condition, QueryExecutor queryExecutor) throws CustomException {
		logger.info("getDataList method starts...");
		List<Map<String, Object>> dataList = new ArrayList<>();
		try {
			if (Objects.isNull(queryExecutor)) {
				queryExecutor = new QueryBuilder().btSchema().getQueryExecutor();
			}
			dataList = queryExecutor.queryBuilder().select().checkIndependentTenant(true).from(tableName).where(condition).build(false).execute();
		} catch (Exception exception) {
			rollBackExecutor(queryExecutor);
			logger.error("Exception in getting data list " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("getDataList method ends...");
		return dataList;
	}


	
	/**
	 * getChangeRequestHistoryList used to get the change request history list.
	 * 
	 * @return List
	 * @param changeReuestId
	 */
	private List<Map<String, Object>> getChangeRequestHistoryList(String changeReuestId) {
		return ChangeRequestDao.fetchRequestData(changeReuestId, null, SortType.ASC);
	}

	/**
	 * processTableDefinition used to process the table definition data.
	 * 
	 * @param changeReuestId
	 * @param isRevert
	 * @param queryExecutor 
	 * @param paramMap 
	 * @return Map
	 * @throws CustomException 
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> processViewDefinition(List<Map<String, Object>> changeRequestHistoryList,
			boolean isRevert, QueryExecutor queryExecutor, Map<String, Object> paramMap) throws CustomException {
		logger.info("processTableDefinition method starts...");
		JSONParser parser = new JSONParser();
		ObjectMapper mapper = new ObjectMapper();
		Map<String,Object> viewNameMap = new HashMap<>();
		List<Object> viewNameList = new ArrayList<>();
		List<Object>productCodeList= new ArrayList<>();
		List<Map<String,Object>>viewNameMapList= new ArrayList<>();
		Map<String, Object> viewDefinitionDetails = new HashMap<>();
		AtomicBoolean notDeleteFlag = new AtomicBoolean(true);
		AtomicReference<String> columnName = new AtomicReference<>("transport_data");
		if (isRevert) {
			columnName.set("revert_data");
		}
		try {
			changeRequestHistoryList.stream().forEach(action -> {
				try {
					List<Map<String, Object>> queryList = new ArrayList<>();
					Object jsonData = parser.parse(String.valueOf(action.get(columnName.get())));
					Map<String,Object> jsonMap = JsonUtils.fromJsonOrThrow(jsonData.toString(), Map.class);
					if(isRevert) {
						if (jsonMap.containsKey("delete") || jsonMap.containsKey("upsert")) {
							String mapKey = jsonMap.containsKey("upsert") ? "upsert" : "delete";
							Map<String, Object> valueMap = (Map<String, Object>) parser.parse(String.valueOf(jsonMap.get(mapKey)));
							queryList = mapper.readValue(valueMap.get("query").toString(),
									new TypeReference<List<Map<String, Object>>>() {
							});
						}else if (jsonMap.containsKey("query")) {
							queryList = mapper.readValue(jsonMap.get("query").toString(),
									new TypeReference<List<Map<String, Object>>>() {
									});
						}
						}else {
							queryList = mapper.readValue(jsonMap.get("query").toString(),
									new TypeReference<List<Map<String, Object>>>() {
							});
						}
						for (Map<String, Object> query : queryList) {
								String tableName = String.valueOf(query.get("tableName"));
								if (tableName.equalsIgnoreCase(ViewObjectConstants.VIEW_OBJECT_DEFINITION)) {
									if (query.get("queryType").equals("delete")) {
										notDeleteFlag.set(false);
										List<Map<String, Object>> conditionList = (List<Map<String, Object>>) query
												.get("condition");
										if (!conditionList.isEmpty()) {
											List<Object> conditionValues = (List<Object>) conditionList.get(0).get("values");
											List<Object> conditionMap = (List<Object>) conditionList.get(0).get("columnsList");
											String viewName = "";
											String versionNo = "";
											for (int iterator = 0; iterator < conditionMap.size(); iterator++) {
												if (conditionMap.get(iterator).equals("product_code")) {
													productCodeList.add(conditionValues.get(iterator));
												}
												if (conditionMap.get(iterator).equals("view_object_name")) {
													viewNameList.add(conditionValues.get(iterator));
													viewName = Objects.toString(conditionValues.get(iterator));
												}
												if (conditionMap.get(iterator).equals("version_no")) {
													versionNo = Objects.toString(conditionValues.get(iterator));
												}
											}
											viewNameMap.put(viewName,versionNo);
										}
									} else {
										List<Map<String, Object>> dataList = (List<Map<String, Object>>) query.get("data");
									   dataList.stream().forEach(data -> {
										if (data.containsKey(bindConfigTableWithColumn("view_object_name"))) {
											if(!viewNameMap.containsKey(Objects.toString(data.get(bindConfigTableWithColumn("view_object_name"))))) {
												viewNameMap.put(Objects.toString(data.get(bindConfigTableWithColumn("view_object_name"))),Objects.toString(data.get(bindConfigTableWithColumn("version_no"))));
											}
											viewNameList.add(Objects.toString(data.get(bindConfigTableWithColumn("view_object_name"))));
											productCodeList.add(Objects.toString(data.get(bindConfigTableWithColumn("product_code"))));
										}else if(data.containsKey("viewObjectDefinition.viewObjectName")) {
											if(!viewNameMap.containsKey(Objects.toString(data.get("viewObjectDefinition.viewObjectName")))) {
												viewNameMap.put(Objects.toString(data.get("viewObjectDefinition.viewObjectName")),Objects.toString(data.get("viewObjectDefinition.versionNo")));
											}
											viewNameList.add(Objects.toString(data.get("viewObjectDefinition.viewObjectName")));
											productCodeList.add(Objects.toString(data.get("viewObjectDefinition.productCode")));
										}
									});}
								}
						}
				} catch (Exception exception) {
					logger.error("Exception in processing change request history list " + exception);
				}
			});
			logger.error("view names after processing views" + viewNameList);
			if(!viewNameList.isEmpty()) {
				logger.info("processTableDefinition method after get metdata..."+viewDefinitionDetails);
				viewDefinitionDetails = getViewDefinitionDataWithOutVersion(viewNameMap, queryExecutor,String.valueOf(productCodeList.get(0)));
			if (notDeleteFlag.get() && !((List<Map<String, Object>>) viewDefinitionDetails
					.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION)).isEmpty()) {
				
				if (paramMap.containsKey(ViewObjectConstants.WHOLE_PACKAGING) && (boolean) (paramMap.get(ViewObjectConstants.WHOLE_PACKAGING))) {
					logger.info("whole packaging request");
					viewDefinitionDetails.put(ViewObjectConstants.WHOLE_PACKAGING, true);
					getViewDetailsForWholePackaging(viewNameList.stream().distinct().collect(Collectors.toList()),
							queryExecutor, viewDefinitionDetails, String.valueOf(productCodeList.get(0)),viewNameMap);
				} else {
					viewDefinitionDetails.put("edit", true);
					dropFromMetaTables(String.valueOf(viewNameList.get(0)), queryExecutor,
							String.valueOf(productCodeList.get(0)));
				}
			}
			viewDefinitionDetails.put("viewNameMap", viewNameMap);
			viewDefinitionDetails.put("isEditFlag", notDeleteFlag);
			viewDefinitionDetails.put("productCode", productCodeList.get(0));
			viewDefinitionDetails.put("viewNameList", viewNameList.stream().distinct().collect(Collectors.toList()));
			viewDefinitionDetails.put("viewName", viewNameList.get(0));
			viewDefinitionDetails.put("status", true);
			}else {
				viewDefinitionDetails.put("status", false);
				rollBackExecutor(queryExecutor);
				viewDefinitionDetails.put("message", "View name not specified.");
			}
			logger.info("processTableDefinition method after proces complete..."+viewDefinitionDetails);
		} catch (Exception exception) {
			rollBackExecutor(queryExecutor);
			logger.error("Exception in processTableDefinition " + exception);
			viewDefinitionDetails.put("message", "Exception in processTableDefinition " +exception.getMessage());
			viewDefinitionDetails.put("status", false);
			throw new CustomException(exception.getMessage());
		}
		logger.info("processTableDefinition method ends...");
		return viewDefinitionDetails;
	}

	private void getViewDetailsForWholePackaging(List<Object> viewNameList, QueryExecutor queryExecutor,
			Map<String, Object> viewDefinitionDetails, String productCode, Map<String, Object> viewNameMap) throws CustomException {
		Map<String, Object> wholePackagingMap = new HashMap<>();
		for (Object viewName : viewNameList) {
			Map<String,Object> viewTempMap = new HashMap<>();
			viewTempMap.put(Objects.toString(viewName), viewNameMap.get(viewName));
			Map<String, Object> tableMap = new HashMap<>();
			tableMap = getViewDefinitionData(viewTempMap, queryExecutor, productCode);
			tableMap.put("edit", true);
			dropFromMetaTables(String.valueOf(viewName), queryExecutor,
					String.valueOf(productCode));
			wholePackagingMap.put(String.valueOf(viewName), tableMap);
		}
		viewDefinitionDetails.put("viewDetailList", wholePackagingMap);
		
	}


	/**
	 * getTableDefinitionData used to get the table definition tables data.
	 * 
	 * @param tableNameList
	 * @param queryExecutor 
	 * @param productCode 
	 * @returnMap
	 * @throws CustomException
	 */
	public Map<String, Object> getViewDefinitionData(Map<String,Object> viewObjectMap, QueryExecutor queryExecutor, String productCode) throws CustomException {
		logger.info("getTableDefinitionData method starts..."+viewObjectMap);
		Map<String, Object> dataMap = new HashMap<>();
		ConditionBuilder condition = ConditionBuilder.instance();
		for(Entry<String,Object>conditionEntry :  viewObjectMap.entrySet()) {
			if(Objects.nonNull(condition) && !StringUtils.isEmpty(condition.getQuery())) {
				condition.or();
			}
			ConditionBuilder bracketBuilder = ConditionBuilder.instance();
			bracketBuilder.eq(ViewObjectConstants.VIEW_OBJECT_NAME, conditionEntry.getKey())
			.and().eq(ViewObjectConstants.VERSION_NO, conditionEntry.getValue());
			if(!StringUtils.isEmpty(productCode)) {
				bracketBuilder.and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode);
		}
			condition.brackets(bracketBuilder);
		}
		dataMap.put(ViewObjectConstants.VIEW_OBJECT_DEFINITION,
				getDataList(ViewObjectConstants.VIEW_OBJECT_DEFINITION, condition, queryExecutor));
		dataMap.put(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS,
				getDataList(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS, condition, queryExecutor));
		logger.info("getTableDefinitionData method ends...");
		return dataMap;
	}

	/**
	 * processTableDefinitionAfterCrExecution used to process the table definition
	 * data after cr execution.
	 * 
	 * @param viewObjectDetails
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> processViewObjectAfterCrExecution(Map<String, Object> viewObjectDetails) {
		logger.info("processTableDefinitionAfterCrExecution method starts...");
		Map<String, Map<String, Object>> dataMap = new HashMap<>();
		Map<String, Object> resultMap = new HashMap<>();
		QueryExecutor queryExecutor = null;
		Map<String,Object> productExecutorMap = new HashMap<>();
		QueryExecutor viewObjectExecutor = null;
		String changeRequestId = String.valueOf(viewObjectDetails.get("changeRequestId"));
		ViewObjectGeneration viewObjectGeneration = new ViewObjectGeneration();
		ViewObjectCommonUtils viewObjectCommonUtils = new ViewObjectCommonUtils();
		boolean status = true;
		try {
			 queryExecutor = (QueryExecutor) viewObjectDetails.get("btExecutor");
			Map<String,Object> viewNameMap = (Map<String,Object>) viewObjectDetails.get("viewNameMap");
			List<String> viewNameList = (List<String>) viewObjectDetails.get("viewNameList");
			String productCode = String.valueOf(viewObjectDetails.get("productCode"));
			if(viewObjectDetails.containsKey("wholePackaging") && (boolean)(viewObjectDetails.get("wholePackaging"))) {
				return	processWholePackagingRequest(viewObjectDetails,queryExecutor,viewNameList,productCode,resultMap);
			}else {
				Map<String, Object> updatedTableDefinitionDetails = getViewDefinitionData(viewNameMap, queryExecutor,productCode);
				compareViewObjectData(viewObjectDetails, updatedTableDefinitionDetails, dataMap);
				if(dataMap.containsKey(ViewObjectConstants.VIEW_OBJECT_DEFINITION)) {
					Map<String,Object> tableDetail= (Map<String,Object>)dataMap.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION);
					logger.info("view creation or deletion process....."+dataMap);
					if(tableDetail.containsKey("create") && !((Set<Object>)tableDetail.get("create")).isEmpty()) {
						logger.info("view creation process  starts in transport....."+tableDetail);
						String viewObject = String.valueOf(((List<Map<String,Object>>) (updatedTableDefinitionDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("view_object_name"));
						String versionNumber = String.valueOf(((List<Map<String,Object>>) (updatedTableDefinitionDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("version_no"));
						resultMap.put(ViewObjectConstants.VIEW_OBJECT, viewObject);
						resultMap.put(ViewObjectConstants.PRODUCT_CODE, productCode);
						resultMap.put("edit", true);
						resultMap.put("modeType", "EDIT");
						resultMap.putAll(prepareDataForViewCreation(viewObject, updatedTableDefinitionDetails));
						viewObjectGeneration.createViewInDatabase(resultMap, queryExecutor);
						queryExecutor.commit();
						resultMap.remove("viewObjectExecutor");
//						if (viewObjectDetails.containsKey("generateSource")
//								&&Boolean.parseBoolean(Objects.toString(viewObjectDetails.get("generateSource"),"true"))) {
							resultMap.put("isSourceCodeOnly", true);
							resultMap.put("productCode", productCode);
							resultMap.put("viewObject", viewObject);
//							resultMap.put("nochange", true);
//							logger.info("view creation process source code process starts....."+viewObject);
//							new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId,
//									false, new QueryBuilder());
//							Map<String, Object> repoMap = new HashMap<>();
//							repoMap.put("createList", Arrays.asList(viewObject));
//							Map<String,Object> tableDataForCrMap =  new HashMap<>();
//							Map<String,Object> tableDetails = new HashMap<>();
//							Map<String,Map<String,Object>> tableMap = new HashMap<>();
//							String tableName = String.valueOf(resultMap.get(ViewObjectConstants.VIEW_OBJECT));
//							tableDetails.put("productCode",Objects.toString(resultMap.get(ViewObjectConstants.PRODUCT_CODE),""));
//							tableDetails.put("databaseHandlerName",Objects.toString(resultMap.get("database_handler"),""));
//							tableDetails.put("versionNumber",Objects.toString(((List<Map<String,Object>>) (updatedTableDefinitionDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("version_no"),""));
//							tableDetails.put("viewType", "create");
//							tableMap.put(tableName,tableDetails);
//							tableDataForCrMap.put("transportData", tableMap);
//							tableDataForCrMap.put("isBusinessObject", true);
//							resultMap.put("viewData",JSON.toString(tableDataForCrMap));
//							insertToTableRequestDetails(ViewObjectTypeEnum.VIEW.name(), changeRequestId, resultMap);
							logger.info("view creation process source code process ends.....");
//						} else {
							logger.info("view creation process no change....");
							resultMap.put("nochange", true);
							viewObjectCommonUtils.updateViewObjectStatus(viewObject, versionNumber, productCode, true, "");;
//						}
						logger.info("view creation process  ends in transport....."+tableDetail);
					}else if(tableDetail.containsKey("drop") && !((Set<Object>)tableDetail.get("drop")).isEmpty()) {
						logger.info("view drop process  starts in transport....."+tableDetail);
						productCode = String.valueOf(((List<Map<String,Object>>) (viewObjectDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("product_code"));
						String viewObject = String.valueOf(((List<Map<String,Object>>) (viewObjectDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("view_object_name"));
						String versionNumber = String.valueOf(((List<Map<String,Object>>) (viewObjectDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("version_no"));
						resultMap.put(ViewObjectConstants.VIEW_OBJECT, viewObject);
						resultMap.put(ViewObjectConstants.PRODUCT_CODE, productCode);
						resultMap.put("edit", true);
						resultMap.putAll(prepareDataForViewCreation(viewObject, viewObjectDetails));
						viewObjectGeneration.dropViewInDatabase(resultMap, queryExecutor);
						queryExecutor.commit();
						resultMap.remove("viewObjectExecutor");
//						if (viewObjectDetails.containsKey("generateSource")
//								&&Boolean.parseBoolean(Objects.toString(viewObjectDetails.get("generateSource"),"true"))) {
							resultMap.put("isSourceCodeOnly", true);
							resultMap.put("commitType", "delete");
							resultMap.put("productCode", productCode);
							resultMap.put("viewObject", viewObject);
							logger.info("view drop process source code starts in transport....."+viewObject);
//							new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId,
//									false, new QueryBuilder());
//							Map<String,Object> tableDataForCrMap =  new HashMap<>();
//							Map<String,Object> tableDetails = new HashMap<>();
//							Map<String,Map<String,Object>> tableMap = new HashMap<>();
//							String tableName = String.valueOf(resultMap.get(ViewObjectConstants.VIEW_OBJECT));
//							tableDetails.put("productCode",Objects.toString(resultMap.get(ViewObjectConstants.PRODUCT_CODE),""));
//							tableDetails.put("databaseHandlerName",Objects.toString(resultMap.get("database_handler"),""));
//							tableDetails.put("versionNumber",Objects.toString(((List<Map<String,Object>>) (viewObjectDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION))).get(0).get("version_no"),""));
//							tableDetails.put("viewType", "drop");
//							tableMap.put(tableName,tableDetails);
//							tableDataForCrMap.put("transportData", tableMap);
//							tableDataForCrMap.put("isBusinessObject", true);
//							resultMap.put("viewData",JSON.toString(tableDataForCrMap));
							resultMap.put("nochange", true);
							 QueryBuilder queryBuilder = new QueryBuilder();
							 ConditionBuilder deleteBuilder = ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode);
 							 if(!StringUtils.isEmpty(versionNumber)) {
 								 deleteBuilder.and().eq(ViewObjectConstants.VERSION_NO,versionNumber);
 							 }
 							 queryBuilder.delete().skipTenantId(true).from(ViewObjectConstants.VIEW_OBJECT_DEFINITION).where(deleteBuilder).build().execute();
 							 queryBuilder.delete().skipTenantId(true).from(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS).where(deleteBuilder).build().execute();
							logger.info("view drop process source code ends in transport....."+viewObject);
//						}else {
							logger.info("view drop process no change...."+viewObject);
//						}
						logger.info("view drop process  ends in transport.....");
					}
				}else {
					logger.info("view data map is empty ");
					commitExecutor(viewObjectExecutor);
					queryExecutor.commit();
				}
			}
		} catch (Exception exception) {
			try {
				rollBackExecutor(viewObjectExecutor);
				rollBackExecutor(queryExecutor);
			} catch (CustomException e) {
				e.printStackTrace();
			}
			logger.error("Exception in process table definition after cr execution. " + exception);
			resultMap.put("message", "Exception table process after cr execution. " + exception.getMessage());
			status = false;
		}
		resultMap.put("status", status);
		logger.info("processTableDefinitionAfterCrExecution method ends...");
		return resultMap;
	}

	/**
	 * compareTableDefinitionData used to compare the table definition data.
	 * 
	 * @param tableDefinitionDetails
	 * @param updatedTableDefinitionDetails
	 * @param dataMap
	 */
	private void compareViewObjectData(Map<String, Object> tableDefinitionDetails,
			Map<String, Object> updatedTableDefinitionDetails, Map<String, Map<String, Object>> dataMap) {
		logger.info("compareTableDefinitionData method starts...");
		processViewObjectData(tableDefinitionDetails, updatedTableDefinitionDetails, dataMap,
				ViewObjectConstants.VIEW_OBJECT_DEFINITION);
		logger.info("compareTableDefinitionData method ends...");
	}

	/**
	 * processTableDefinitionData used to prepare the data based on the operation.
	 * 
	 * @param tableDefinitionDetails
	 * @param updatedTableDefinitionDetails
	 * @param dataMap
	 * @param tableName
	 */
	@SuppressWarnings("unchecked")
	private void processViewObjectData(Map<String, Object> tableDefinitionDetails,
			Map<String, Object> updatedTableDefinitionDetails, Map<String, Map<String, Object>> dataMap,
			String tableName) {
		logger.info("processTableDefinitionData method starts...");
		Set<Object> dropList = new HashSet<>();
		Set<Object> createList = new HashSet<>();
		Set<Object> alterList = new HashSet<>();
		Map<String, Object> detailMap = new HashMap<>();
		List<Map<String, Object>> oldTableDefinitionData = (List<Map<String, Object>>) tableDefinitionDetails
				.get(tableName);
		logger.info("oldTableDefinitionData....."+oldTableDefinitionData);
		List<Map<String, Object>> newTableDefinitionData = (List<Map<String, Object>>) updatedTableDefinitionDetails
				.get(tableName);
		logger.info("newTableDefinitionData....."+newTableDefinitionData);
		Map<Object, List<Map<String, Object>>> oldGroupedData = groupData(oldTableDefinitionData,
				ViewObjectConstants.VIEW_OBJECT_NAME);
		logger.info("oldGroupedData....."+oldGroupedData);
		Map<Object, List<Map<String, Object>>> newGroupedData = groupData(newTableDefinitionData,
				ViewObjectConstants.VIEW_OBJECT_NAME);
		logger.info("newGroupedData....."+newGroupedData);
		oldGroupedData.entrySet().stream().forEach(action -> {
			if (newGroupedData.containsKey(action.getKey())) {
				createList.add(action);
			} else {
				dropList.add(action);
			}
		});
		newGroupedData.entrySet().stream().forEach(action -> {
			if (!oldGroupedData.containsKey(action.getKey())) {
				createList.add(action.getKey());
			}
		});
		detailMap.put("create", createList);
		detailMap.put("alter", alterList);
		detailMap.put("drop", dropList);
		dataMap.put(tableName, detailMap);
		logger.info("data comparision results"+detailMap);
		logger.info("processTableDefinitionData method ends...");
	}

	/**
	 * groupData used to group the data based on the key.
	 * 
	 * @param dataList
	 * @param key
	 * @return Map
	 */
	private Map<Object, List<Map<String, Object>>> groupData(List<Map<String, Object>> dataList, String key) {
		logger.info("groupData method starts...");
		Map<Object, List<Map<String, Object>>> groupedData = new HashMap<>();
		if (CollectionUtils.isNotEmpty(dataList)) {
			groupedData = dataList.stream().collect(Collectors.groupingBy(action -> action.get(key)));
		}
		logger.info("groupData method ends...");
		return groupedData;
	}



	/**
	 * prepareDataForViewCreation used to process the data definition
	 * after cr execution.
	 * 
	 * @param dataMap
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	 private Map<String, Object> prepareDataForViewCreation(String viewObject, Map<String, Object> updatedTableDefinitionDetails) throws CustomException {
			Map<String,Object> paramMap = new HashMap<>();
			List<Map<String, Object>> tableObjectConfigList;
			try {
				tableObjectConfigList = (List<Map<String, Object>>) updatedTableDefinitionDetails.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION);
			List<Map<String,Object>> tableColumList = (List<Map<String, Object>>) updatedTableDefinitionDetails.get(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS);
			List entityColumnList = new ArrayList<>();
			try {
				logger.debug("## prepareForViewCreation method creation started");
				List<Map<String,Object>> tableColumnDataList = new ArrayList<>();
			if(!tableObjectConfigList.isEmpty() && !tableColumList.isEmpty()){
				ObjectMapper objectMapper = new ObjectMapper();
				Map<String,Object> configData = new HashMap<String, Object>();
				Map<String,Object> tempMap = tableObjectConfigList.get(0);;
				for (Entry<String,Object> entity : tempMap.entrySet()) {
					configData.put(bindConfigTableWithColumn(entity.getKey()), entity.getValue());
				}
				configData.put(bindConfigTableWithColumn("active_flag"), true);
				configData.put(bindConfigTableWithColumn("status_flag"), true);
				configData.put(bindConfigTableWithColumn("source_status"), "RELEASED");
				paramMap.put(ViewObjectConstants.PRODUCT_CODE, String.valueOf(configData.get(bindConfigTableWithColumn(ViewObjectConstants.PRODUCT_CODE_COL))));
				paramMap.put(ViewObjectConstants.VIEW_OBJECT, String.valueOf(configData.get(bindConfigTableWithColumn(ViewObjectConstants.VIEW_OBJECT_NAME))));
				paramMap.put(ViewObjectConstants.VERSION_NUMBER, String.valueOf(configData.get(bindConfigTableWithColumn(ViewObjectConstants.VERSION_NO))));
				paramMap.put("database_handler", String.valueOf(configData.get(bindConfigTableWithColumn("database_handler"))));
				paramMap.put("databaseHandler", String.valueOf(configData.get(bindConfigTableWithColumn("database_handler"))));
				 String condDetails = String.valueOf(configData.get(bindConfigTableWithColumn("condition_details")));
				paramMap.put("isWhere", StringUtils.contains(condDetails.toLowerCase(),"where")? true : false);
	             
	             for (Map<String,Object> data : tableColumList) {
	            	 Map<String,Object> columnData = new HashMap<>();
	            	 for (Entry<String, Object> entry :data.entrySet()){
	            		 columnData.put(bindDetailTableWithColumnDetails(entry.getKey()), entry.getValue());
	            	 }
	            	 tableColumnDataList.add(columnData);
	             }
	             paramMap.put(ViewObjectConstants.CONFIG_TABLE_DATA, configData);
	             paramMap.put("entityColumnList", entityColumnList);
	             paramMap.put(ViewObjectConstants.COLUMN_DETAILS, tableColumnDataList);
	             paramMap.put("beanColumnList", tableColumList);
	             paramMap.put("isPresent", true);
			}else{
				paramMap.put("isPresent", false);
				logger.debug("## prepareForViewCreation method no data found in tableobject config or tablecolumnlist");
			}
			logger.debug("## prepareForViewCreation method creation completed");
			} catch (Exception exception) {
				logger.debug("## prepareForViewCreation method creation failed" + exception.getMessage());
				throw new CustomException(exception);
			}
			} catch (Exception exception) {
				throw new CustomException(exception);
			}
			return paramMap;
		}

	/**
	 * 
	 * @param viewName
	 * @param viewMetaExecutor
	 * @param productCode
	 * @throws CustomException
	 */
	void dropFromMetaTables(String viewName, QueryExecutor viewMetaExecutor, String productCode)
			throws CustomException {
		logger.info("dropFromMetaTables  method info starts.");
		try {
			viewMetaExecutor.queryBuilder().delete().skipTenantId(true)
					.from(ViewObjectConstants.VIEW_OBJECT_DEFINITION)
					.where(ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewName).and()
							.eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode))
					.build().execute();
			viewMetaExecutor.queryBuilder().delete().skipTenantId(true)
					.from(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS)
					.where(ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewName).and()
							.eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode))
					.build().execute();
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("dropFromMetaTables  method info ends.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("dropFromMetaTables  method info ends.");
	}
	
	public void updateSuccessStatus(String viewObject, String productCode) throws CustomException {
		logger.info("updateSuccessStatus method starts for transport "+viewObject);
		try{
 				 Map<String,Object> updateMap = new HashMap<>();
 					 updateMap.put(bindConfigTableWithColumn("source_status"), "RELEASED");
 					 updateMap.put(bindConfigTableWithColumn("error_message"), "");
 					 updateMap.put(bindConfigTableWithColumn("status_flag"), true);
 				new QueryBuilder().update().skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().eq("view_object_name", viewObject).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
 			logger.info("updateSuccessStatus method ends for transport "+viewObject);
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}
	
	
	

	/**
	 * 
	 * @param viewDefinitionDetails
	 * @param queryExecutor
	 * @param viewNameList
	 * @param productCode
	 * @throws CustomException 
	 */
		@SuppressWarnings("unchecked")
		private Map<String,Object> processWholePackagingRequest(Map<String, Object> viewDefinitionDetails, QueryExecutor queryExecutor,
				List<String> viewNameList, String productCode,Map<String,Object> resultMap) throws CustomException {
			logger.info("processWholePackagingRequest method execution starts");
			boolean status = true;
			ViewObjectGeneration viewObjectGeneration = new ViewObjectGeneration();
			ViewObjectCommonUtils viewObjectCommonUtils = new ViewObjectCommonUtils();
			Map<String,QueryExecutor> productExecutorMap = new HashMap<>();
			List<Map<String,Object>> viewNameMapList= (List<Map<String, Object>>) viewDefinitionDetails.get("viewNameMapList");
			try {
				String changeRequestId = String.valueOf(viewDefinitionDetails.get("changeRequestId"));
				boolean noDelete = true;
				Map<String,Object> viewNameMap = (Map<String,Object>) viewDefinitionDetails.get("viewNameMap");
			for(String viewObject : viewNameList) {
				QueryExecutor productExecutor = null;
				Map<String,Object> viewTempMap = new HashMap<>();
				viewTempMap.put(viewObject, viewNameMap.get(viewObject));
				Map<String, Object> updatedTableDefinitionDetails = getViewDefinitionData(viewTempMap, queryExecutor, productCode);
				logger.info("view creation process  starts in processWholePackagingRequest....."+viewObject);
				resultMap.put(ViewObjectConstants.VIEW_OBJECT, viewObject);
				resultMap.put(ViewObjectConstants.PRODUCT_CODE, productCode);
				resultMap.put("edit", true);
				resultMap.put("modeType","EDIT");
				resultMap.putAll(prepareDataForViewCreation(viewObject, updatedTableDefinitionDetails));
				String handlerName = Objects.toString(resultMap.get("databaseHandler"));
				if(productExecutorMap.containsKey(productCode+handlerName)) {
			productExecutor = productExecutorMap.get(productCode+handlerName);
		}else {
		Map<String, Object> productDetailsMap = viewObjectCommonUtils.getApplicationDatabaseDetails(productCode, handlerName, queryExecutor.queryBuilder());
		if (productDetailsMap.containsKey("error")
				&& (boolean) productDetailsMap.get("error")) {
			logger.info("processTableDefinitionAfterCrExecution method execution ended"
					+ productDetailsMap);
			productDetailsMap.put(ViewObjectConstants.STATUS, false);
			rollBackExecutor(queryExecutor);
			return productDetailsMap;
		}
		QueryBuilder viewQueryBuilder = new QueryBuilder(getString(productDetailsMap.get(ViewObjectConstants.URL_KEY)),getString(productDetailsMap.get(ViewObjectConstants.USER)),getString(productDetailsMap.get(ViewObjectConstants.PASSKEY)),getString(productDetailsMap.get(ViewObjectConstants.SCHEMA)));
		productExecutor = viewQueryBuilder.getQueryExecutor();
		productExecutor.skipChangeRequest(true);
		productExecutorMap.put(productCode+handlerName,productExecutor);
		}
				createViewInTransport(resultMap, queryExecutor, viewObjectGeneration,productExecutor);
				resultMap.remove("viewObjectExecutor");
				logger.info("view creation process  ends in transport....."+viewObject);
			}
			if(status) {
				productExecutorMap.values().stream().forEach(executorList ->
					{
						try {
							viewObjectCommonUtils.commitExecutor(executorList);
						} catch (CustomException exception) {
							logger.error(exception);
						}
					}
				);
				queryExecutor.commit();
//				if (viewDefinitionDetails.containsKey("generateSource")
//						&&Boolean.parseBoolean(Objects.toString(viewDefinitionDetails.get("generateSource"),"true"))) {
//					logger.info("view creation process source code process application packaging.....");
////					for(String viewObject : viewNameList) {
////						resultMap.put("isSourceCodeOnly", true);
////						resultMap.put("productCode", productCode);
////						resultMap.put("viewObject", viewObject);
////						if(noDelete) {
////							noDelete=false;
////						}else {
////							resultMap.put("noDelete", true);
////						}
////						new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId,
////								false, new QueryBuilder());
////					}
//					Map<String, Object> repoMap = new HashMap<>();
//					repoMap.put("createList", Arrays.asList(viewNameList));
//					Map<String,Object> tableDataForCrMap =  new HashMap<>();
//					Map<String,Object> tableDetails = new HashMap<>();
//					Map<String,Map<String,Object>> tableMap = new HashMap<>();
//					String tableName = String.valueOf(resultMap.get(ViewObjectConstants.VIEW_OBJECT));
//					tableDetails.put("productCode",Objects.toString(resultMap.get(ViewObjectConstants.PRODUCT_CODE),""));
//					tableDetails.put("databaseHandlerName",Objects.toString(resultMap.get("database_handler"),""));
//					tableDetails.put("versionNumber",getString(resultMap.get(ViewObjectConstants.VERSION_NUMBER)));
//					tableDetails.put("viewType", "create");
//					tableMap.put(tableName,tableDetails);
//					tableDataForCrMap.put("transportData", tableMap);
//					tableDataForCrMap.put("isBusinessObject", true);
//					resultMap.put("viewData",JSON.toString(tableDataForCrMap));
//					insertToTableRequestDetails(ViewObjectTypeEnum.VIEW.name(), changeRequestId, resultMap);
//					logger.info("view creation process source code process ends.....");
//				} else {
					logger.info("view creation process no change....");
					resultMap.put("nochange", true);
					updateSuccessStatus(viewNameList, productCode);
//				}
			}
			}catch(Exception exception) {
				productExecutorMap.values().stream().forEach(executorList ->
				{
					try {
						viewObjectCommonUtils.rollBackExecutor(executorList);
					} catch (CustomException e) {
						e.printStackTrace();
					}
				}
	);
				rollBackExecutor(queryExecutor);
				throw new CustomException(exception.getMessage());
			}
			logger.info("processWholePackagingRequest method execution ends");
			resultMap.put(ViewObjectConstants.STATUS, status);
			return resultMap;
		}

		/**
		 * createviewObjectView method 
		 * creates viewobject(view) in the database in corresponding schema based on product.
		 * @param viewObjectMap
		 * @param metaQueryExecutor
		 * @throws CustomException
		 */
		public void createViewInTransport(Map<String, Object> viewObjectMap,QueryExecutor metaQueryExecutor,ViewObjectGeneration viewObjectGeneration,QueryExecutor viewObjectExecutor) throws CustomException {
			logger.debug("## createviewObjectView method execution started");
			String productCode = getString(viewObjectMap.get(ViewObjectConstants.PRODUCT_CODE));
			String viewObject = getString(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT));
			String versionNumber = getString(viewObjectMap.get(ViewObjectConstants.VERSION_NUMBER));
			String modeType = getString(viewObjectMap.get("modeType"));
			logger.debug("## createTableObjectView method execution started");
			String langJoinData = "";
			try {
				if(StringUtils.equals(modeType, "EDIT")) {
					logger.debug("## createTableObjectView method execution started");
					Map<String,Object> dependentMap = new HashMap();
					dependentMap.putAll(viewObjectMap);
					dependentMap.put("dependentViews",viewObjectGeneration.getDependentViewObjects(viewObject, metaQueryExecutor.queryBuilder(),versionNumber));
					viewObjectGeneration.dropDependentViews(dependentMap, metaQueryExecutor,viewObjectExecutor);
				}
				Map configDataMap = (Map)viewObjectMap.get(ViewObjectConstants.CONFIG_TABLE_DATA);
				langJoinData = Objects.toString(configDataMap.get(bindConfigTableWithColumn("condition_details")));
				boolean matViewFlag = Boolean.parseBoolean(Objects.toString(configDataMap.get(bindConfigTableWithColumn("mat_view_flag"))));
			     langJoinData = langJoinData.replaceAll(" is true", "  = true ").replaceAll(" is false ", "  = false ");
			     ViewObjectLanguageUtils langUtils = new ViewObjectLanguageUtils();
			     langJoinData = langUtils.getLangJoinQuery(viewObjectMap,metaQueryExecutor);
			     if(!matViewFlag) {
			    	 CreateViewEntity viewEntity = new CreateViewEntity();
			    	 viewEntity.setProductCode(productCode);
			    	 viewEntity.setViewName(viewObject);
			    	 viewEntity.setSelectString(langJoinData);
			    	 viewObjectExecutor.queryBuilder().table().createView()
			    	 .skipChangeRequest(true).viewData(viewEntity).setProductCode(productCode).build().execute();
			     }else {
			    	 CreateMatViewEntity viewEntity = new CreateMatViewEntity();
			    	 viewEntity.setProductCode(productCode);
			    	 viewEntity.setViewName(viewObject);
			    	 viewEntity.setSelectString(langJoinData);
			    	 viewObjectExecutor.queryBuilder().table().createMatView()
			    	 .skipChangeRequest(true).viewData(viewEntity).setProductCode(productCode).build().execute();
			     }
				logger.debug("## createviewObjectView method execution ended");
			} catch (Exception exception) {
				logger.debug("## createviewObjectView method execution failed due to " +exception.getMessage());
				viewObjectMap.put(ViewObjectConstants.EXCEPTION, exception);
				addErrorMessage(viewObjectMap, exception.getMessage());
					try {
					    rollBackExecutor(viewObjectExecutor);
					    rollBackExecutor(metaQueryExecutor);
						throw new CustomException(exception);
					} catch (Exception exp) {
						logger.debug("## createviewObjectView method exception while handling" +exp.getMessage());
						throw new CustomException(exp);
					}
				}
		}
		
		protected String getString(Object obj) {
			return Objects.toString(obj,"");
		}		

		
		public void updateSuccessStatus(List<String> viewNameList , String productCode) throws CustomException {
			logger.info("updateSuccessStatus method starts for transport "+viewNameList);
			try{
	 				 Map<String,Object> updateMap = new HashMap<>();
	 					 updateMap.put(bindConfigTableWithColumn("source_status"), "RELEASED");
	 					 updateMap.put(bindConfigTableWithColumn("error_message"), "");
	 					 updateMap.put(bindConfigTableWithColumn("status_flag"), true);
	 				new QueryBuilder().update().skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().in("view_object_name", viewNameList.toArray()).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
	 			logger.info("updateSuccessStatus method ends for transport "+viewNameList);
			} catch (Exception exception) {
				logger.error(exception);
				throw new CustomException(exception);
			}
		}
		
		
		/**
		 * getTableDefinitionData used to get the table definition tables data.
		 * 
		 * @param tableNameList
		 * @param queryExecutor 
		 * @returnMap
		 * @throws CustomException
		 */
		private Map<String, Object> getViewDefinitionDataWithOutVersion(Map<String,Object> viewObjectMap, QueryExecutor queryExecutor,String productCode) throws CustomException {
			logger.info("getTableDefinitionData method starts..."+viewObjectMap);
			Map<String, Object> dataMap = new HashMap<>();
			ConditionBuilder condition = ConditionBuilder.instance();
			for(Entry<String,Object>conditionEntry :  viewObjectMap.entrySet()) {
				if(Objects.nonNull(condition) && !StringUtils.isEmpty(condition.getQuery())) {
					condition.or();
				}
				ConditionBuilder bracketBuilder = ConditionBuilder.instance();
				bracketBuilder.eq(ViewObjectConstants.VIEW_OBJECT_NAME, conditionEntry.getKey());
				if(!StringUtils.isEmpty(productCode)) {
					bracketBuilder.and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode);
			}
				condition.brackets(bracketBuilder);
			}
			dataMap.put(ViewObjectConstants.VIEW_OBJECT_DEFINITION,
					getDataList(ViewObjectConstants.VIEW_OBJECT_DEFINITION, condition, queryExecutor));
			dataMap.put(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS,
					getDataList(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS, condition, queryExecutor));
			logger.info("getTableDefinitionData method ends...");
			return dataMap;
		}
		
		/**
		 * bindConfigTableWithColumn binds the column name with configuration table.
		 * @param objectData
		 * @return
		 */
		public static String bindConfigTableWithColumn(String columnName) {
			return ViewObjectConstants.VIEW_OBJECT_DEFINITION+"."+columnName;
		}
		
		
		/**
		 * bindDetailTableWithColumnDetails binds the column name with column details table
		 * @param objectData
		 * @return
		 */
		public static String bindDetailTableWithColumnDetails(String columnName) {
			return ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS+"."+columnName;
		
		}
		
		
		/**
		 * bindHistoryTableWithColumn binds the column name with history details table
		 * @param objectData
		 * @return
		 */
		public static String bindHistoryTableWithColumn(String columnName) {
			return ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS+"."+columnName;
		
		}
		
		/**
		 * addSuccessMessage for all api default success key
		 * 
		 * @param returnMap
		 *            contains return values for api
		 * @return returnMap
		 */
		public static Map<String, Object> addSuccessMessage(Map<String, Object> returnMap,String successMessage) {
			logger.info("addSuccessMessage method execution started.");
			returnMap.put(ViewObjectConstants.ERROR, false);
			returnMap.put(ViewObjectConstants.STATUS, true);
			returnMap.put(ViewObjectConstants.MESSAGE, successMessage);
			logger.info("addSuccessMessage method execution ended.");
			return returnMap;
		}

		/**
		 * addErrorMessage for all api default error status addition
		 * 
		 * @param returnMap
		 *            contains return values for api
		 * @param errorMessage
		 *            contains error message
		 * @return returnMap
		 */
		public static Map<String, Object> addErrorMessage(Map<String, Object> returnMap, String errorMessage) {
			logger.info("addErrorMessage method execution started.");
			returnMap.put(ViewObjectConstants.ERROR, true);
			returnMap.put(ViewObjectConstants.STATUS, false);
			returnMap.put(ViewObjectConstants.MESSAGE, errorMessage);
			logger.info("addErrorMessage method execution ended.");
			return returnMap;
		}
		
		
		
		/**
		 * commitExecutor used for commit autocommit false connection
		 * 
		 * @param queryExecutor
		 *            contains database connection
		 * @throws CustomException
		 *             when error at commiting
		 */
		public static void commitExecutor(QueryExecutor queryExecutor) throws CustomException {
			logger.info("commitExecutor method exeuction started");
			try {
				if (Objects.nonNull(queryExecutor)) {
					queryExecutor.commit();
					logger.info("commitExecutor commit done");
				}
			} catch (Exception queryException) {
				rollBackExecutor(queryExecutor);
				logger.error(queryException);
				throw new CustomException(queryException.getMessage());
			}
			logger.info("commitExecutor method exeuction ended");
		}



		/**
		 * rollBackExecutor used for rollback connection
		 * 
		 * @param queryExecutor
		 *            contains database connection
		 * @throws CustomException 
		 */
		public static void rollBackExecutor(QueryExecutor queryExecutor) throws CustomException {
			logger.info("rollBackExecutor method exeuction started");
			try {
				if (Objects.nonNull(queryExecutor)) {
					queryExecutor.rollBack();
					logger.info("rollBackExecutor rollback done");
				}
			} catch (Exception queryException) {
				logger.error(queryException);
				throw new CustomException(queryException);
			}
			logger.info("rollBackExecutor method exeuction ended");
		}
		
		
}
