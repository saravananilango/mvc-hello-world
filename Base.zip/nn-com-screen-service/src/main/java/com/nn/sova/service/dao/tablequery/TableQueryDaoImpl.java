package com.nn.sova.service.dao.tablequery;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * TableQueryDaoImpl class used to make DB operation related to sql editor
 * 
 * @implments TableQueryDao
 * @author Vivek Kannan E
 */

public class TableQueryDaoImpl implements TableQueryDao {

	/** The Constant APPLICATION_NAME. */
	private static final String PRODUCT_CODE = "product_code";

	/** The Constant SQL_EDITOR_SUGGESTION_TARGET. */
	private static final String SQL_EDITOR_SUGGESTION_TARGET = "sql_editor_suggestion_target";

	@Override
	public List<Map<String, Object>> getSuggestion(String productCode, String targetText) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		return queryBuilder.btSchema().select().setProductCode(productCode)
				.getWithAliasName(SQL_EDITOR_SUGGESTION_TARGET, "suggestion")
				.getWithAliasName("suggestion_icon", "icon").from("sql_editor_suggestion_view")
				.where(ConditionBuilder.instance().ilike(SQL_EDITOR_SUGGESTION_TARGET, "%" + targetText + "%").and()
						.brackets(ConditionBuilder.instance().eq(PRODUCT_CODE, productCode).or().isNull(PRODUCT_CODE)))
				.orderBy(SQL_EDITOR_SUGGESTION_TARGET, SortType.ASC).limit(30).distinct().build(true).execute();
	}
}