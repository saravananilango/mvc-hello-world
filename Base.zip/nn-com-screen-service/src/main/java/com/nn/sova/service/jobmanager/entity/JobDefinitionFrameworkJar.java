package com.nn.sova.service.jobmanager.entity;

import static com.nn.sova.utility.jobmanager.JobManagerComponent.toJson;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_CALLBACK_URLS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_FRAMEWORK_JAR;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_PARAMETERS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.MAIN_CLASS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.VERSION;

import java.util.List;
import java.util.Map;

import com.nn.sova.utility.jobmanager.entity.JobCallbackUrl;
import com.nn.sova.utility.jobmanager.entity.JobParameters;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * The Class {@code JobDefinitionFrameworkJar} represents a row in
 * {@code job_definiton_framework_jar} table
 *
 * @author praveen_kumar_nr
 */
@Data
@EqualsAndHashCode(of = { "version" }, callSuper = true)
@ToString(callSuper = true)
public class JobDefinitionFrameworkJar extends AbsJobDefinition {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The version. */
	private String version;

	/** The main class. */
	private String mainClass;

	/** The job parameters. */
	private JobParameters jobParameters;

	/** The job callback urls. */
	private List<JobCallbackUrl> jobCallbackUrls;

	/**
	 * Instantiates a new job definition framework jar.
	 */
	public JobDefinitionFrameworkJar() {
		super(JOB_DEFINITION_FRAMEWORK_JAR);
	}

	/**
	 * Instantiates a new {@code JobDefinitionFrameworkJar} from a map.
	 *
	 * @param dataMap the data map
	 */
	public JobDefinitionFrameworkJar(Map<String, Object> dataMap) {
		super(JOB_DEFINITION_FRAMEWORK_JAR, dataMap);
		this.version = (String)dataMap.get(VERSION);
		this.mainClass = (String)dataMap.get(MAIN_CLASS);
		this.jobParameters = JobParameters.from(dataMap.get(JOB_PARAMETERS));
		this.jobCallbackUrls = JobCallbackUrl.from(dataMap.get(JOB_CALLBACK_URLS));
	}

	@Override
	public Map<String, Object> toInsertMap() {
		Map<String, Object> insertDataMap = super.toInsertMap();
		insertDataMap.put(getInsertKey(VERSION), getVersion());
		insertDataMap.put(getInsertKey(MAIN_CLASS), getMainClass());
		insertDataMap.put(getInsertKey(JOB_PARAMETERS), toJson(getJobParameters()));
		insertDataMap.put(getInsertKey(JOB_CALLBACK_URLS), toJson(getJobCallbackUrls()));
		return insertDataMap;
	}

}
