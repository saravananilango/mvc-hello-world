package com.nn.sova.service.dao.classconfig;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * ClassConfigDaoImpl class is to perform db operation in class configuration
 * table.
 *
 * @author Sundhar
 */
public class ClassConfigDaoImpl implements ClassConfigDao {

    /**
     * To delete data in class configuration table by class id.
     *
     * @param classIds the class ids
     * @param executor the executor
     * @throws Exception the exception
     */
    @Override
    public void deleteByClassId(List<Object> classIds, QueryExecutor executor) throws Exception {
        if (CollectionUtils.isNotEmpty(classIds)) {
            ConditionBuilder condition = ConditionBuilder.instance().inWithList("class_config_id", classIds);
            executor.queryBuilder().delete().skipTenantId(true).skipChangeRequest(true).from("class_configuration")
                    .where(condition).build().execute();
        }
    }

}
