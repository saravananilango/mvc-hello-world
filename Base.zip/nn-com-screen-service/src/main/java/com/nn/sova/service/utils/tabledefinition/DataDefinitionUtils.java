package com.nn.sova.service.utils.tabledefinition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.UpdateQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.constants.tabledefinition.TableDefinitionConstants;
import com.nn.sova.service.enums.TableTypeEnum;
import com.nn.sova.service.utils.tabledefinition.tabletemplate.AlterTableTemplate;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

public class DataDefinitionUtils {
	private static final String TABLE_DEFINITION_COLUMN_DETAILS = "table_definition_column_details";
	private static final String SERIAL_NUMBER = "serial_number";
	private static final String PRIMARY_KEY = "primary_key";
	private static final String LENGTH = "length";
	private static final String LANG_DEPENDENT_FLAG = "lang_dependent_flag";
	private static final String DATABASE_HANDLER = "database_handler";
	private static final String DATA_ELEMENT = "data_element";
	private static final String COLUMN_NAME = "column_name";
	private static final String STATUS2 = ".status";
	private static final String PRODUCT_CODE2 = "productCode";
	private static final String PRODUCT_CODE = "product_code";
	private static final String TABLE_NAME = "table_name";
	private static final String TABLE_DEFINITION = "table_definition";
	/**
	 * logger for TableDefinitionUtils class
	 */
	private static ApplicationLogger logger = ApplicationLogger.create(DataDefinitionUtils.class);
	/**
	 * alterFromDataElements method used for alter call from data elements
	 * 
	 * @param alterDetailsMap contains alter table name and data class and data
	 *                        element details
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> alterFromDataElements(Map<String, Object> alterDetailsMap) {
		logger.info("alterFromDataElements method execution started.");
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> processMap = new HashMap<>();
		QueryExecutor productExecutor = null;
		QueryExecutor tableMetaExecutor = null;
		String productCode = null;
		String tableName = String.valueOf(alterDetailsMap.get(TableDefinitionConstants.TABLENAME));
		processMap.put(TableDefinitionConstants.TABLENAME, tableName);
		try {
			List<Map<String, Object>> getTableDetails = getTableDetailsFromOnline(tableName,
					String.valueOf(alterDetailsMap.get(PRODUCT_CODE2)));
			productCode = String.valueOf(getTableDetails.get(0).get(PRODUCT_CODE));
			processMap.put(TableDefinitionConstants.PRODUCT_CODE, getTableDetails.get(0).get(PRODUCT_CODE));
			Map<String, Object> productDetailsMap = TableDefinitionUtils.getApplicationDatabaseDetails(
					String.valueOf(getTableDetails.get(0).get(PRODUCT_CODE)),
					String.valueOf(getTableDetails.get(0).get(DATABASE_HANDLER)));
			if (productDetailsMap.containsKey(TableDefinitionConstants.ERROR_KEY)
					&& (boolean) productDetailsMap.get(TableDefinitionConstants.ERROR_KEY)) {
				inactiveStateMove(Arrays.asList(tableName),
						String.valueOf(productDetailsMap.get(TableDefinitionConstants.ERROR_MESSAGE_KEY)), null,
						StringUtils.EMPTY, String.valueOf(productDetailsMap.get(PRODUCT_CODE)));
				logger.info("alterFromDataElements method execution ended" + productDetailsMap);
				return productDetailsMap;
			}
			List<Object> dataElementList;
			List<Object> dataFormatList;
			ConditionBuilder conditionBuilder = ConditionBuilder.instance();
			conditionBuilder.eq(TableDefinitionConstants.TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode)
					.and();
			ConditionBuilder joinConditionBuilder = ConditionBuilder.instance();
			boolean conditionListSet = false;
			if (alterDetailsMap.containsKey(TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN)
					&& !((List<Object>) alterDetailsMap.get(TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN))
							.isEmpty()) {
				dataElementList = (List<Object>) alterDetailsMap
						.get(TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN);
				joinConditionBuilder.inWithList(DATA_ELEMENT, dataElementList);
				conditionListSet = true;
				processMap.put(TableDefinitionConstants.ONLINE_DATA_ELEMENT_LIST, dataElementList);
			}
			if (alterDetailsMap.containsKey(TableDefinitionConstants.DATA_FORMAT_DEFINTION_MAIN)
					&& !((List<Object>) alterDetailsMap.get(TableDefinitionConstants.DATA_FORMAT_DEFINTION_MAIN))
							.isEmpty()) {
				dataFormatList = (List<Object>) alterDetailsMap
						.get(TableDefinitionConstants.DATA_FORMAT_DEFINTION_MAIN);
				if (conditionListSet) {
					joinConditionBuilder.or();
				}
				joinConditionBuilder.inWithList("data_format", dataFormatList);
				processMap.put(TableDefinitionConstants.ONLINE_DATA_FORMAT_LIST, dataFormatList);
			}
			conditionBuilder.brackets(joinConditionBuilder);
			List<Map<String, Object>> columnDetailsList = getTableDefinitionColumnDetails(conditionBuilder);
			List<Map<String, Object>> tempColumnList = getTableDefinitionColumnDetails(conditionBuilder);
			processMap.put(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP, columnDetailsList);
			processMap.put("productDetailsMap", productDetailsMap);
			productExecutor = TableDefinitionUtils.getProductExecutor(productDetailsMap);
			productExecutor.skipChangeRequest(true);
			tableMetaExecutor = new QueryBuilder().btSchema().getQueryExecutor();
			tableMetaExecutor.skipChangeRequest(true);
			TableDefinitionUtils.getDataDefinitionDetailsFromOnline(tableMetaExecutor, processMap);
			AlterTableTemplate.alterFromDataClass(productExecutor, processMap, tableMetaExecutor, tempColumnList);
			if (processMap.containsKey("alterDone")) {
				resultMap.put("alterDone", true);
				TableDefinitionUtils.commitExecutor(productExecutor);
				logger.info("Commit product executor done after table alter.");
				if (processMap.containsKey("setSourceCodeGenerate")) {
					resultMap.put("setSourceCodeGenerate", true);
				}
				TableDefinitionUtils.updateProgramBusinessObject(Arrays.asList(tableName));
			} else {
				logger.info("rollback product executor after failed to table alter.");
				TableDefinitionUtils.rollBackExecutor(productExecutor);
			}
			columnDetailsList = (List<Map<String, Object>>) processMap.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP);
			logger.info("Column details list for update. " + columnDetailsList);
			upsertTableDetailsForOfflineTables(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN,
					columnDetailsList, tableMetaExecutor);
			TableDefinitionUtils.commitExecutor(tableMetaExecutor);
			logger.info("Commit product executor done after table meta data upsert.");
			CacheService.getInstance().removeServerSideValidation(tableName, productCode);
		} catch (Exception exception) {
			logger.error("Exception in alterFromDataElements method. " + exception);
			TableDefinitionUtils.rollBackExecutor(productExecutor);
			TableDefinitionUtils.rollBackExecutor(tableMetaExecutor);
			inactiveStateMove(Arrays.asList(tableName), exception.getMessage(), null, StringUtils.EMPTY, productCode);
			TableDefinitionUtils.addErrorMessage(resultMap, exception.getMessage());
		}
		logger.info("alterFromDataElements method execution ended.");
		return resultMap;
	}
	
	private List<Map<String, Object>> getTableDefinitionColumnDetails(ConditionBuilder conditionBuilder)
			throws QueryException {
		return new QueryBuilder().btSchema().select()
				.getWithAliasName("tenant_id",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".tenantId")
				.getWithAliasName(PRODUCT_CODE,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".productCode")
				.getWithAliasName(TABLE_NAME,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".tableName")
				.getWithAliasName(COLUMN_NAME,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".columnName")
				.getWithAliasName(DATA_ELEMENT,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataElement")
				.getWithAliasName("data_format",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataFormat")
				.getWithAliasName("data_type",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataType")
				.getWithAliasName(LENGTH, TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".length")
				.getWithAliasName(PRIMARY_KEY,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".primaryKey")
				.getWithAliasName("not_null",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".notNull")
				.getWithAliasName("default_value",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".defaultValue")
				.getWithAliasName("audit_log_flag",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".auditLogFlag")
				.getWithAliasName(LANG_DEPENDENT_FLAG,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag")
				.getWithAliasName("data_archive_flag",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataArchiveFlag")
				.getWithAliasName("column_description",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".columnDescription")
				.getWithAliasName("data_encryption_flag",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataEncryptionFlag")
				.getWithAliasName("autonumber_flag",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".autonumberFlag")
				.getWithAliasName(SERIAL_NUMBER,
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".serialNumber")
				.getWithAliasName("translate_flag",
						TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".translateFlag")
				.from(TABLE_DEFINITION_COLUMN_DETAILS).skipTenantId(true).where(conditionBuilder).build(false)
				.execute();
	}
	
	/**
	 * upsertTableDetailsForOfflineTables used for table upsert offline tables
	 * 
	 * @param tableName
	 * @param insertTableDetails
	 * @param queryExecutor
	 * @throws CustomException when insert value in table
	 */
	private void upsertTableDetailsForOfflineTables(String tableName, List<Map<String, Object>> insertTableDetails,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("upsertTableDetailsForOfflineTables method execution started.");
		try {
			List<String> primaryKeyList = new ArrayList<>();
			switch (tableName) {
			case TableDefinitionConstants.TABLE_DEFINITION_META:
			case TableDefinitionConstants.TABLE_DEFINITION_MAIN:
				primaryKeyList.addAll(TableDefinitionConstants.TABLE_DEFINITION_PRIMARY_KEY_LIST);
				break;
			case TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_META:
			case TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN:
				primaryKeyList.addAll(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_PRIMARY_KEY_LIST);
				break;
			case TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_META:
			case TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN:
				primaryKeyList
						.addAll(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_KEY_DEFINITION_PRIMARY_KEY_LIST);
				break;
			case TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_META:
			case TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN:
				primaryKeyList.addAll(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DEFINITION_PRIMARY_KEY_LIST);
				break;
			case TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_META:
			case TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN:
				primaryKeyList.addAll(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DEFINITION_PRIMARY_KEY_LIST);
				break;
			}
			List<String> updateColumns = getUpdateColumnKeys(insertTableDetails.get(0), tableName);
			updateColumns.removeAll(primaryKeyList);
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(tableName, insertTableDetails,
					true, updateColumns, primaryKeyList.toArray(new String[primaryKeyList.size()]));
		} catch (Exception exception) {
			logger.error(exception + "\n Table Name : " + tableName);
			throw new CustomException(exception.getMessage());
		}
		logger.info("upsertTableDetailsForOfflineTables method execution ended.");
	}

	/**
	 * getUpdateColumnKeys used for upsert updateColumnList get
	 * 
	 * @param insertMap contains key for upsert values
	 * @param tableName
	 * @return updateColumnList
	 */
	List<String> getUpdateColumnKeys(Map<String, Object> insertMap, String tableName) {
		logger.info("getUpdateColumnKeys method execution started.");
		List<String> updateColumnList = insertMap.keySet().stream().filter(predicate -> predicate.startsWith(tableName))
				.map(tableKey -> tableKey.split("\\.")[1]).collect(Collectors.toList());
		logger.info("getUpdateColumnKeys method execution ended.");
		return updateColumnList;
	}
	/**
	 * inactiveStateMove method used for move to table to inactive stage
	 * 
	 * @param tableName    contains which table name to moved
	 * @param errorMessage contains error message
	 * @param errorStage   contains change request error stage
	 * @param string
	 */
	void inactiveStateMove(List<Object> tableName, String errorMessage, String errorStage, String changeRequestId,
			String productCode) {
		logger.info("inactiveStateMove method execution started. ");
		try {
			UpdateQueryBuilder updateQueryBuilder = new QueryBuilder().btSchema().update();
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".errorStage",
					Objects.nonNull(errorStage) ? errorStage : "");
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + STATUS2, TableTypeEnum.INACTIVE.name());
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".errorMessage",
					Objects.nonNull(errorMessage) ? errorMessage : "");
			updateQueryBuilder.skipChangeRequest(true).skipTenantId(true).updateWithMap(
					TableDefinitionConstants.TABLE_DEFINITION_MAIN, updateMap,
					ConditionBuilder.instance().inWithList(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode));
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("Exception occured at inactiveStateMove method" + exception.getMessage());
			logger.info("inactiveStateMove method execution ended. ");
		}
		logger.info("inactiveStateMove method execution ended. ");
	}
	
	/**
	 * getTableDetailsFromOnline method used to get online table definition list
	 * 
	 * @param tableName contains table name
	 * @return table details
	 * @throws QueryException
	 */
	List<Map<String, Object>> getTableDetailsFromOnline(String tableName, String productCode) throws QueryException {
		return new QueryBuilder()
				.btSchema().select().from(TABLE_DEFINITION).skipTenantId(true).where(ConditionBuilder.instance()
						.eq(TableDefinitionConstants.TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode))
				.build(false).execute();
	}
}
