package com.nn.sova.service.workflow.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.nn.sova.service.workflow.enums.ApprovalStatusEnum;

import lombok.Data;

/**
 * ApplicationStepEntity entity class used to holds the application's
 * individual step's over all details and list of step members
 * 
 * @author punithanantony.d@vaken.cloud (Punithan Antony Das)
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationStepEntity{
	
	/** step number*/
	private int stepOrder = 0;
	
	/** minimum approval action required to complete the step*/
	private int minimumApprovalCount = 1;
	
	/** actual approval action happened*/
	private int actualApprovalCount = 0;
	
	/** whether the application's first step*/
	private boolean firstStep = false;
	
	/** whether the application's last step*/
	private boolean lastStep = false;
	
	/** whether the step is about to verification*/
	private boolean verificationStep = false;
	
	/** whether the step current processing step*/
	private boolean processingStep = false;
	
	/** whether the step is upcoming in next level of steps*/
	private boolean upcomingStep = false;
	
	/** whether the step is eligible for master step */
	private boolean masterStep = false;
	
	/** whether the step process is completed*/
	private boolean stepCompleted = false;
	
	/** unit id of the step configuration */
	private String unitId = "";
	
	/**organization code of the step configuration */
	private String orgStrCode = "";
	
	/** cumulative status of the current step in application*/
	private String stepStatus = ApprovalStatusEnum.NOT_SUBMITTED.getValue();
	
	/** list of step members user id*/
	private List<String> stepMemberList = new ArrayList<>();
	
	/** list of step member entity*/
	private List<ApplicationStepMemberEntity> stepMemberEntityList = new ArrayList<>();
}