package com.nn.sova.service.mastersearch.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MasterSearchRequestParam class is to get and set the master data.
 *
 * @author Logchand
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MasterSearchRequestParam {

	/** The input keyword. */
	private List<String> inputKeyword;

	/** The master key. */
	private String masterKey;

	/** The filter fields. */
	private Map<String, Object> filterFields;

	/** The filter conditions. */
	private Map<String, Object> filterConditions;

	/**
	 * Instantiates a new master search request param.
	 *
	 * @param inputKeyWord the input key word
	 * @param masterKey    the master key
	 */
	public MasterSearchRequestParam(List<String> inputKeyWord, String masterKey) {
		this.inputKeyword = inputKeyWord;
		this.masterKey = masterKey;
	}
}
