package com.nn.sova.service.utils.appgen;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.postgresql.util.PGobject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.dao.screenconfiguration.ScreenConfigurationDao;
import com.nn.sova.service.dao.screenconfiguration.ScreenConfigurationDaoImpl;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;

public class AppgenCommonUtils extends CommonUtils {
	
	/** The Constant STATUS * */
    private static final String STATUS = "status";
    
    /** The Constant MESSAGE * */
    private static final String MESSAGE = "message";
    
    /** screenConfigurationDao */
    private static final ScreenConfigurationDao screenConfigurationDao = new ScreenConfigurationDaoImpl();
    
    /**
     * getSecurityObjects method is to return security object data.
     * @return
     */
    public static List<String> getSecurityObjects() {
    	String sId = ContextBean.getSid();
    	String cacheKey = "securityObject_" + sId;
    	Object cacheData = CacheService.getInstance().getCacheData(cacheKey);
    	if(Objects.nonNull(cacheData)) {
    		return getListForReference(cacheData, new TypeReference<String>() {});
    	}
    	Map<String, Object> securityData = screenConfigurationDao.getScreenConfigurationData(sId);
    	List<String> securityObjectData = Optional.ofNullable(securityData.get("security_object"))
    		.filter(predicate -> predicate instanceof PGobject)
    		.map(mapper -> ((PGobject) mapper).getValue())
    		.map(mapper -> JsonUtils.fromJsonOrEmptyList(mapper, new TypeReference<List<String>>() {}))
    		.orElse(new ArrayList<>());
    	CacheService.getInstance().saveToCache(cacheKey, securityObjectData);
    	return securityObjectData;
    }

}
