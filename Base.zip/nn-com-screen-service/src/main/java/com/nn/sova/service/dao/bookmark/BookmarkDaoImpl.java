package com.nn.sova.service.dao.bookmark;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;

/**
 * BookmarkDaoImpl is used to do database related operations of bookmark.
 * 
 * @author Mohammed Shameer
 *
 */
public class BookmarkDaoImpl implements BookmarkDao {

	/** The BOOKMARK */
	private static final String BOOKMARK = "bookmark";

	/** The BOOKMARK_SHARE */
	private static final String BOOKMARK_SHARE = "bookmark_share";

	/** The BOOKMARK_NAME */
	private static final String BOOKMARK_NAME = "bookmark_name";

	/** The DEFAULT_FLAG */
	private static final String DEFAULT_FLAG = "default_flag";

	/** The TENANT_ID */
	private static final String TENANT_ID = "tenant_id";

	/** The SCREEN_ID */
	private static final String SCREEN_ID = "screen_id";

	/** The USER_ID */
	private static final String USER_ID = "user_id";

	/** The SHARED_TO_USER */
	private static final String SHARED_TO_USER = "shared_to_user";

	/** The SHARED_BY_USER */
	private static final String SHARED_BY_USER = "shared_by_user";

	/** The CREATED_AT */
	private static final String CREATED_AT = "created_at";

	/** The UPDATED_AT */
	private static final String UPDATED_AT = "updated_at";

	/** The CREATED_BY */
	private static final String CREATED_BY = "created_by";

	/** The UPDATED_BY */
	private static final String UPDATED_BY = "updated_by";

	/** The COMPONENT_ID */
	private static final String COMPONENT_ID = "component_id";

	@Override
	public List<Map<String, Object>> getUserBookmarkData() throws QueryException {
		return new QueryBuilder().btSchema().select().get(BOOKMARK_NAME, DEFAULT_FLAG, COMPONENT_ID).from(BOOKMARK)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(USER_ID, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()))
				.orderBy(CREATED_AT, SortType.ASC_NULLS_FIRST).build(false).execute();
	}

	@Override
	public List<Map<String, Object>> getSharedBookmarkData() throws QueryException {
		return new QueryBuilder().btSchema().select()
				.get(BOOKMARK_NAME, DEFAULT_FLAG, SHARED_TO_USER, SHARED_BY_USER, COMPONENT_ID).from(BOOKMARK_SHARE)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(SHARED_TO_USER, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()))
				.orderBy(CREATED_AT, SortType.ASC_NULLS_FIRST).build(false).execute();
	}

	@Override
	public void insertBookmarkData(Map<String, Object> paramMap) throws QueryException {
		Map<String, Object> insertMap = new HashMap<>();
		Timestamp timestamp = Timestamp.from(Instant.now());
		insertMap.put(BOOKMARK + "." + TENANT_ID, ContextBean.getTenantId());
		insertMap.put(BOOKMARK + "." + USER_ID, ContextBean.getUserId());
		insertMap.put(BOOKMARK + "." + SCREEN_ID, ContextBean.getSid());
		insertMap.put(BOOKMARK + "." + BOOKMARK_NAME, paramMap.get("bookmarkName"));
		insertMap.put(BOOKMARK + ".component_id", JsonUtils.toJsonOrEmpty(paramMap.get("componentId")));
		insertMap.put(BOOKMARK + "." + DEFAULT_FLAG, paramMap.get("isDefault"));
		insertMap.put(BOOKMARK + ".shared_user", null);
		insertMap.put(BOOKMARK + ".visible_flag", null);
		insertMap.put(BOOKMARK + "." + CREATED_BY, ContextBean.getUserId());
		insertMap.put(BOOKMARK + "." + CREATED_AT, timestamp);
		insertMap.put(BOOKMARK + "." + UPDATED_BY, ContextBean.getUserId());
		insertMap.put(BOOKMARK + "." + UPDATED_AT, timestamp);
		new QueryBuilder().btSchema().insert().upsertWithKeyList(BOOKMARK, Arrays.asList(insertMap), true,
				Arrays.asList(COMPONENT_ID, DEFAULT_FLAG, "shared_user", "visible_flag", UPDATED_BY, UPDATED_AT),
				TENANT_ID, USER_ID, SCREEN_ID, BOOKMARK_NAME);
	}

	@Override
	public void deleteBookmarkData(String bookmarkName) throws QueryException {
		new QueryBuilder().btSchema().delete().from(BOOKMARK)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(USER_ID, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(BOOKMARK_NAME, bookmarkName))
				.build().execute();
	}

	@Override
	public void deleteSharedBookmarkData(String bookmarkName, String sharedUser) throws QueryException {
		new QueryBuilder().btSchema().delete().from(BOOKMARK_SHARE)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(SHARED_TO_USER, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(BOOKMARK_NAME, bookmarkName).and().eq(SHARED_BY_USER, sharedUser))
				.build().execute();
	}

	@Override
	public void markPrivateDefaultBookmarkData(String bookmarkName) throws QueryException {
		new QueryBuilder().btSchema().update().forceUpdate(true).into(BOOKMARK, DEFAULT_FLAG)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(USER_ID, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(DEFAULT_FLAG, true))
				.build().execute(false);
		markPrivateDefault(String.valueOf(bookmarkName), true);
	}

	@Override
	public void markSharedDefaultBookmarkData(String bookmarkName, String sharedUser) throws QueryException {
		new QueryBuilder().btSchema().update().forceUpdate(true).into(BOOKMARK_SHARE, DEFAULT_FLAG)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(SHARED_TO_USER, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(DEFAULT_FLAG, true))
				.build().execute(false);
		markSharedDefault(bookmarkName, sharedUser, true);
	}

	/**
	 * markPrivateDefault is used to mark private default data.
	 * 
	 * @param bookmarkName
	 * @param defaultValue
	 * @throws QueryException
	 */
	private void markPrivateDefault(String bookmarkName, Boolean defaultValue) throws QueryException {
		new QueryBuilder().btSchema().update().forceUpdate(true).into(BOOKMARK, DEFAULT_FLAG)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(USER_ID, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(BOOKMARK_NAME, bookmarkName))
				.build().execute(defaultValue);
	}

	/**
	 * markSharedDefault is used to mark shared default data.
	 * 
	 * @param bookmarkName
	 * @param sharedUser
	 * @param defaultValue
	 * @throws QueryException
	 */
	private void markSharedDefault(String bookmarkName, String sharedUser, Boolean defaultValue) throws QueryException {
		new QueryBuilder().btSchema().update().forceUpdate(true).into(BOOKMARK_SHARE, DEFAULT_FLAG)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(SHARED_TO_USER, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(BOOKMARK_NAME, bookmarkName).and().eq(SHARED_BY_USER, sharedUser))
				.build().execute(defaultValue);
	}

	@Override
	public List<Map<String, Object>> getSharedBookmarkDataByName(String bookmarkName, String sharedUser)
			throws QueryException {
		return new QueryBuilder().btSchema().select().get(BOOKMARK_NAME, COMPONENT_ID).from(BOOKMARK_SHARE)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(SHARED_TO_USER, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(BOOKMARK_NAME, bookmarkName).and().eq(SHARED_BY_USER, sharedUser))
				.build(false).execute();
	}

	@Override
	public List<Map<String, Object>> getPrivateBookmarkDataByName(String bookmarkName) throws QueryException {
		return new QueryBuilder().btSchema().select().get(BOOKMARK_NAME, COMPONENT_ID).from(BOOKMARK)
				.where(ConditionBuilder.instance().eq(TENANT_ID, ContextBean.getTenantId()).and()
						.eq(USER_ID, ContextBean.getUserId()).and().eq(SCREEN_ID, ContextBean.getSid()).and()
						.eq(BOOKMARK_NAME, bookmarkName))
				.build(false).execute();
	}

	@Override
	public void shareBookmarkData(Map<String, Object> bookmarkData, List<Object> usersList) throws QueryException {
		Timestamp currentTime = Timestamp.from(Instant.now());
		String userId = ContextBean.getUserId();
		List<Map<String, Object>> dataList = usersList.stream().map(mapper -> {
			Map<String, Object> dataMap = new HashMap<>();
			dataMap.put(BOOKMARK_SHARE + "." + TENANT_ID, ContextBean.getTenantId());
			dataMap.put(BOOKMARK_SHARE + "." + SHARED_BY_USER, userId);
			dataMap.put(BOOKMARK_SHARE + "." + SCREEN_ID, ContextBean.getSid());
			dataMap.put(BOOKMARK_SHARE + "." + BOOKMARK_NAME, bookmarkData.get(BOOKMARK_NAME));
			dataMap.put(BOOKMARK_SHARE + "." + SHARED_TO_USER, mapper);
			dataMap.put(BOOKMARK_SHARE + "." + COMPONENT_ID, bookmarkData.get(COMPONENT_ID));
			dataMap.put(BOOKMARK_SHARE + "." + DEFAULT_FLAG, false);
			dataMap.put(BOOKMARK_SHARE + "." + "shared_date", currentTime);
			dataMap.put(BOOKMARK_SHARE + "." + CREATED_AT, currentTime);
			dataMap.put(BOOKMARK_SHARE + "." + UPDATED_AT, currentTime);
			dataMap.put(BOOKMARK_SHARE + "." + CREATED_BY, userId);
			dataMap.put(BOOKMARK_SHARE + "." + UPDATED_BY, userId);
			return dataMap;
		}).collect(Collectors.toList());
		new QueryBuilder().btSchema().insert().upsertWithKeyList(BOOKMARK_SHARE, dataList, true,
				Arrays.asList(TENANT_ID, SHARED_BY_USER, SHARED_TO_USER, SCREEN_ID, BOOKMARK_NAME, COMPONENT_ID,
						DEFAULT_FLAG, "shared_date", CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY),
				TENANT_ID, SHARED_BY_USER, SHARED_TO_USER, BOOKMARK_NAME, SCREEN_ID);
	}

	@Override
	public void removePrivateDefaultBookmarkData(String bookmarkName) throws QueryException {
		markPrivateDefault(String.valueOf(bookmarkName), false);
	}

	@Override
	public void removeSharedDefaultBookmarkData(String bookmarkName, String sharedUser) throws QueryException {
		markSharedDefault(bookmarkName, sharedUser, false);
	}
}