package com.nn.sova.service.service.user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.constants.TableViewsConstants;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.dao.logger.ApplicationLoggerDao;
import com.nn.sova.service.dao.screenconfiguration.ScreenConfigurationDao;
import com.nn.sova.service.dao.screenconfiguration.ScreenConfigurationDaoImpl;
import com.nn.sova.service.dao.user.UserAccountDao;
import com.nn.sova.service.dao.user.UserAccountDaoImpl;
import com.nn.sova.service.entity.useraccount.UserProfileEntity;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.service.user.UserMenuCacheService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.date.DateStyle;
import com.nn.sova.utility.date.TimeStyle;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * UserServiceImpl class is to do change the user data.
 * 
 * @author Mohammed Shameer U
 *
 */
public class UserServiceImpl implements UserService {

	/** The logger */
	private static final ApplicationLogger logger = ApplicationLogger.create(UserServiceImpl.class);

	/** The Constant userAccDao **/
	private UserAccountDao userAccDao;

	private ScreenConfigurationDao screenConfigurationDao;

	/**
	 * UserServiceImpl constructor
	 */
	public UserServiceImpl() {
		userAccDao = new UserAccountDaoImpl();
		screenConfigurationDao = new ScreenConfigurationDaoImpl();
	}

	@Override
	public Map<String, Object> changeUserImage(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		try {
			userAccDao.changeUserImage(String.valueOf(paramMap.get("fileId")), String.valueOf(paramMap.get("referenceId")));
			CacheService.getInstance().removeTenantUserData(ContextBean.getUserId(), ContextBean.getTenantId());
			resultMap.put("status", true);
		} catch (QueryException e) {
			logger.error("Error occured while changing user image", e);
			resultMap.put("status", false);
		}
		return resultMap;
	}

	@Override
	public Map<String, Object> getUserPreferenceData() throws QueryException {
		CacheService cacheService = CacheService.getInstance();
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> userDataByTenantId = cacheService.getUserDataByTenantId(ContextBean.getUserId(), ContextBean.getTenantId());
		String locale = "en";
		if (Objects.nonNull(userDataByTenantId.get("user_locale"))) {
			locale = String.valueOf(userDataByTenantId.get("user_locale"));
			ContextBean.setLocale(locale);
		}
		resultMap.put("locale", locale);
		DateStyle dateStyle = DateStyle.DEFAULT;
		TimeStyle timeStyle = TimeStyle.DEFAULT;
		try {
			if (Objects.nonNull(userDataByTenantId.get("date_format"))) {
				dateStyle = DateStyle.valueOf(String.valueOf(userDataByTenantId.get("date_format")));
			}
		} catch (Exception exception) {
			logger.error("Error occured while getting date format", exception);
			dateStyle = DateStyle.DEFAULT;
		}
		if (Objects.nonNull(dateStyle)) {
			String pattern = DateStyle.getPattern(locale, dateStyle);
			resultMap.put("dateStyle", dateStyle.toString());
			resultMap.put("dateFormat", pattern);
		} else {
			resultMap.put("dateStyle", DateStyle.DEFAULT.toString());
			resultMap.put("dateFormat", DateStyle.getPattern(locale, DateStyle.DEFAULT));
		}
		try {
			if (Objects.nonNull(userDataByTenantId.get("time_format"))) {
				timeStyle = TimeStyle.valueOf(String.valueOf(userDataByTenantId.get("time_format")));
			}
		} catch (Exception exception) {
			logger.error("Error occured while getting time format", exception);
			timeStyle = TimeStyle.DEFAULT;
		}
		if (Objects.nonNull(timeStyle)) {
			String pattern = TimeStyle.getPattern(Locale.forLanguageTag(locale), timeStyle, true);
			resultMap.put("timeStyle", timeStyle.toString());
			resultMap.put("timeFormat", pattern);
		} else {
			resultMap.put("timeStyle", TimeStyle.DEFAULT.toString());
			resultMap.put("timeFormat", TimeStyle.getPattern(Locale.forLanguageTag(locale), TimeStyle.DEFAULT, true));
		}
		resultMap.put("menuType", Objects.toString(userDataByTenantId.get("menu_type"), "default"));
		resultMap.put("currentTab",
				Objects.nonNull(userDataByTenantId.get("current_tab_flag"))
						? Boolean.valueOf(String.valueOf(userDataByTenantId.get("current_tab_flag")))
						: false);
		resultMap.put("currencyFormat", Objects.toString(userDataByTenantId.get("currency_format"), StringUtils.EMPTY));
		resultMap.put("landingPageUrl",
				Objects.toString(userDataByTenantId.get("landing_page_url"), StringUtils.EMPTY));
		List<Map<String, Object>> localeData = (List<Map<String, Object>>) CacheService.getInstance().getLocaleBusinessObject();
        if (Objects.nonNull(localeData) && CollectionUtils.isNotEmpty(localeData)) {
        	resultMap.put("localeInputData", localeData.stream().filter(predicate -> Objects.nonNull(predicate.get("locale")) && 
            		predicate.get("locale").toString().equals(ContextBean.getLocale())).collect(Collectors.toList()));
        }
		resultMap.put("dataKey", cacheService.getCacheData(CacheKeyHelper.getUserPreferenceRandomKey(ContextBean.getTenantId(), ContextBean.getUserId())));
		if (StringUtils.isNotEmpty(ContextBean.getAppUserId())) {
			resultMap.put("isOtpUser", true);
		} else {
			resultMap.put("isOtpUser", false);
		}
		resultMap.put("themeCode", Objects.toString(userDataByTenantId.get("theme_code"), ""));
		return resultMap;
	}
	
 	@Override
 	public boolean updateDebugMode(boolean isDebug) {
 		try {
 			UserMenuCacheService.getInstance().updateDebugMode(isDebug);
 			ApplicationLoggerDao.updateDebugModeByUserId(ContextBean.getUserId(), isDebug);
 			return true;
 		} catch (QueryException e) {
 			logger.error("Error occured while updating debug mode", e);
 			return false;
 		}
 	}
 	
 	
 	/**
 	 * get the target screen url based on 
 	 * @param sourceScreenId
 	 * @param targetScreenDefId
 	 * @return
 	 */
 	@Override
	public Map<String, Object> getTargetScreenIdData(String sourceScreenId, String targetScreenDefId) {
 		if (StringUtils.isBlank(sourceScreenId) && !StringUtils.isBlank(targetScreenDefId)) {
 			return getScreenDataBasedByAuthority(targetScreenDefId);
 		}
		if (!StringUtils.isBlank(sourceScreenId) && !StringUtils.isBlank(targetScreenDefId)) {
			Map<String, Object> targetScreenIdMap = getTargetScreenIdDataFromSecurityLink(sourceScreenId, targetScreenDefId);
			if (!targetScreenIdMap.isEmpty()) {
				return getScreenAuthorityByScreenDefAndScreenId(targetScreenDefId,
						(String.valueOf(targetScreenIdMap.get("target_screen_id"))));
			}
			return getScreenDataBasedByAuthority(targetScreenDefId);
		}
		return Collections.EMPTY_MAP;
	}
 	
    /**
     * Based on the given screenDefId and screenId, 
     * will check if the user current user role has access and return the screen data .
     * @param targetScreenDefId
     * @param targetScreenId
     * @return
     */
    private Map<String, Object> getScreenAuthorityByScreenDefAndScreenId(String targetScreenDefId, String targetScreenId) {
    	UserProfileEntity userContext = UserContext.getInstance().getUserProfile();
    	QueryBuilder queyBuilder = new QueryBuilder();
    	List<Map<String,Object>> result = new ArrayList<>();
    	try {
		if (userContext.isFullyAuthorized() || userContext.isAdminUser()) {
			result = queyBuilder.btSchema().select()
			.from(TableViewsConstants.REDIS_SCREEN_AUTHENTICATE_DETAILS)
			.where(ConditionBuilder.instance()
			        .eq("screen_def_id", targetScreenDefId)
			        .and()
			        .eq("screen_id", targetScreenId))
					.build(false).execute();
		} else {
	    	List<String> roleList = userContext.getRoleList();
	    	result = queyBuilder.btSchema().select()
				.from("partial_auth_screen_navigation_by_role")
				.where(ConditionBuilder.instance()
				        .eq("screen_definition_id", targetScreenDefId)
				        .and()
				        .eq("screen_id", targetScreenId)
				        .and()
				        .inWithList("role_id", new ArrayList<Object>(roleList)))
						.build(false).execute();	
		}
		if(!result.isEmpty()) {
			Map<String,Object> screenData = result.get(0);
			return formScreenUrl(screenData);
		}
		} catch (QueryException e) {
			logger.info("Exception while fetching screen data {}", e);
			return Collections.EMPTY_MAP;
		}
		return Collections.EMPTY_MAP;
    }

	/**
     * fetch the target screen Id based on the source screenId.
     * Spec Doc : https://docs.google.com/presentation/d/1y2Limpg9KAEzunzsBg_0_OTbYxrnjzsgRw3Ju5KGCjE/edit#slide=id.gdeed8e5a8c_1_16
     * Issue - http://172.20.21.19/redmine/issues/16981
     * @param sourceScreenId
     * @param targetScreenDefId
     * @return
     */
    private Map<String, Object> getTargetScreenIdDataFromSecurityLink(String sourceScreenId, String targetScreenDefId) {
    	QueryBuilder queyBuilder = new QueryBuilder();
    	try {
			List<Map<String, Object>> result  = queyBuilder.btSchema().select()
			.from("screen_link")
			.where(ConditionBuilder.instance()
			        .eq("source_screen_id", sourceScreenId)
			        .and()
			        .eq("target_screen_def_id", targetScreenDefId))
					.build(false).execute();
			if(CollectionUtils.isNotEmpty(result)) {
				return result.get(0);
			}
		} catch (QueryException e) {
			 logger.error("Error occured while fetching data from table - screen_link");
			 return Collections.emptyMap();
		}
    	 return Collections.emptyMap();
		
	}
    
    /**
     * Based on the given screenDefId , will check if the user current user role has access and fetch the top screen based on the order .
     * @param screenDefId
     * @return
     */
    private Map<String, Object> getScreenDataBasedByAuthority(String screenDefId) {
    	UserProfileEntity userContext = UserContext.getInstance().getUserProfile();
    	QueryBuilder queyBuilder = new QueryBuilder();
    	List<Map<String,Object>> result = new ArrayList<>();
    	try {
		if (userContext.isFullyAuthorized() || userContext.isAdminUser()) {
			result = queyBuilder.btSchema().select()
			.from(TableViewsConstants.REDIS_SCREEN_AUTHENTICATE_DETAILS)
			.where(ConditionBuilder.instance()
			        .eq("screen_def_id", screenDefId))
			        .orderBy("screen_order", SortType.ASC)
					.build(false).execute();
		} else {
	    	List<String> roleList = userContext.getRoleList();
	    	result = queyBuilder.btSchema().select()
				.from("partial_auth_screen_navigation_by_role")
				.where(ConditionBuilder.instance()
				        .eq("screen_definition_id", screenDefId)
				        .and()
				        .inWithList("role_id", new ArrayList<Object>(roleList)))
				        .orderBy("screen_order", SortType.ASC)
						.build(false).execute();	
		}
		if(!result.isEmpty()) {
			Map<String,Object> screenData = result.get(0);
			return formScreenUrl(screenData);
		}
		} catch (QueryException e) {
			logger.info("Exception while fetching screen data {}", e);
			return Collections.EMPTY_MAP;
		}
		return Collections.EMPTY_MAP;
    }
    
    
    /**
     * 
     * @param screenData
     * @return
     */
	private Map<String, Object> formScreenUrl(Map<String, Object> screenData) {
		Map<String, Object> resultMap = new HashMap<>();
		if (MapUtils.isNotEmpty(screenData)) {
			String urlPath = Objects.toString(screenData.get("screen_url"));
			if (!urlPath.startsWith("/")) {
				urlPath = "/".concat(urlPath);
			}
			resultMap.put("urlPath", urlPath.concat("?sid=").concat(String.valueOf(screenData.get("screen_id"))));
			String contextPath = Objects.toString(screenData.get("screen_context_path"), "");
			if (StringUtils.isNotEmpty(contextPath)) {
				resultMap.put("repoName", screenData.get("screen_context_path"));
			} else {
				setRepoName(screenData, resultMap);
			}
			resultMap.put("status", true);
		} else {
			resultMap.put("status", false);
		}
		return resultMap;
	}
	
    /**
     * setRepoName method checks whether the program is created by APP GEN and set Repo name
     * 
     * @param data
     * @param resultMap
     */
    private void setRepoName(Map<String, Object> data, Map<String, Object> resultMap) {
    	String actualRepoName = Objects.toString(data.get("repo_name"), StringUtils.EMPTY);
        if(data.containsKey("program_name") && 
        		StringUtils.isNotEmpty(Objects.toString(data.get("program_name"), StringUtils.EMPTY)) && 
        		actualRepoName.contains("-front")) {
        	String programName = String.valueOf(data.get("program_name"));
        	String[] repoNameArray = actualRepoName.split("-front");
        	String hyphenedProgramName = camelCaseToHyphenated(programName);
        	hyphenedProgramName = hyphenedProgramName.startsWith("-") ? hyphenedProgramName : "-" + hyphenedProgramName;
        	resultMap.put("repoName", repoNameArray[0].concat(hyphenedProgramName).concat("-front"));
        }else {                	
        	resultMap.put("repoName", actualRepoName);
        }
    }
    
    /**
     * camelCaseToHyphenated method converts camelCase to Hyphened String
     * 
     * @param paramString
     * @return Hyphenated String
     */
    private String camelCaseToHyphenated(String paramString) {
    	Pattern pattern = Pattern.compile("(?=[A-Z][a-z])");
		Matcher matcher = pattern.matcher(paramString);
		return matcher.replaceAll("-").toLowerCase();
    }
    
    @Override
    public String getUserHigherOrderSid(String screenId) {
		try {
			String screenDefId = screenConfigurationDao.getScreenDefId(screenId);
			Map<String, Object> serviceMap = getScreenDataBasedByAuthority(screenDefId);
			if (MapUtils.isNotEmpty(serviceMap)) {
				return String.valueOf(serviceMap.get("repoName")).concat(String.valueOf(serviceMap.get("urlPath")));
			}
		} catch (QueryException e) {
			logger.error("FAILED TO FETCH THE SERVICE ID", e);
		}
		return "";
	}

}