package com.nn.sova.service.utils.tabledefinition.dataprocess;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.json.simple.parser.JSONParser;
import org.postgresql.util.PGobject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.changerequest.ChangeRequest;
import com.nn.sova.changerequest.ChangeRequestDao;
import com.nn.sova.service.constants.tabledefinition.DataDefinitionConstants;
import com.nn.sova.service.constants.tabledefinition.MessageEntriesConstants;
import com.nn.sova.service.constants.tabledefinition.TableDefinitionConstants;
import com.nn.sova.service.enums.TableTypeEnum;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.util.entity.ForeignKeyColumnReferenceEntity;
import com.nn.sova.util.entity.ForeignKeyTableReferenceEntity;
import com.nn.sova.util.entity.ForeignKeyTableReferenceEntity.MatchEnum;
import com.nn.sova.util.enums.OnchangeActionEnum;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;
import com.nn.sova.service.utils.tabledefinition.DataDefinitionCommonUtils;
import com.nn.sova.service.utils.tabledefinition.DataDefinitionUtils;
import com.nn.sova.service.utils.tabledefinition.TableDefinitionUtils;
import com.nn.sova.service.utils.tabledefinition.tabletemplate.AlterTableTemplate;
import com.nn.sova.service.utils.tabledefinition.tabletemplate.CreateTableTemplate;

/**
 * DataProcessUtils used to process the data in transport.
 * 
 * @author Sakthivel
 */
public class DataProcessUtils {
	private static final String WHOLE_PACKAGING = "wholePackaging";
	private static final String PRODUCT_CODE2 = "productCode";
	private static final String VIEW_OBJECT = "viewObject";
	private static final String IS_SOURCE_CODE_ONLY = "isSourceCodeOnly";
	private static final String COUNT = "count";
	private static final String REPO_DETAILS_MAP = "repoDetailsMap";
	private static final String ALTER = "alter";
	private static final String SOURCE_CODE_GENERATE = "sourceCodeGenerate";
	private static final String DATA_DEFINITION = "dataDefinition";
	private static final String UPSERT = "upsert";
	private static final String DELETE_PRIMARY_KEY_MAP = "deletePrimaryKeyMap";
	private static final String DELETE = "delete";
	private static final String QUERY = "query";
	private static final String REPO_NAME = "repoName";
	private static final String PRODUCT_CODE = "product_code";
	private static final String CREATE_LIST = "createList";
	private static final String GENERATE_SOURCE = "generateSource";
	private static final String DATABASE_HANDLER = "database_handler";
	private static final String CREATE = "create";
	private static final String TABLE_NAME2 = "tableName";
	private static final String NOCHANGE = "nochange";
	private static final String TABLE_DEFINITION = "table_definition";
	private static final String REPO_MAP_DETAILS = "repoMapDetails";
	private static final String TABLE_PROCESSED_LIST = "tableProcessedList";
	private static final String TABLE_NAME = "table_name";
	private static final String FORCE_TRUNCATE = "forceTruncate";
	private static final String SCREEN_DEF_ID = "TableDefinitionDetail";
	private static final String CHANGE_REQUEST_ID = "changeRequestId";
	private static final String MESSAGE = "message";
	private static final String STATUS = "status";
	private static final String BT_EXECUTOR = "btExecutor";
	private static ApplicationLogger logger = ApplicationLogger.create(DataProcessUtils.class);

	/**
	 * beforeCrExecution used to validate the data before cr execution.
	 * 
	 * @param paramMap
	 * @return Map
	 */
	public Map<String, Object> beforeCrExecution(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		QueryExecutor queryExecutor = null;
		logger.info("beforeCrExecution method starts..." + paramMap);
		try {
			if (paramMap.containsKey(BT_EXECUTOR)) {
				queryExecutor = (QueryExecutor) paramMap.get(BT_EXECUTOR);
				queryExecutor.skipChangeRequest(true);
			}
			String changeReuestId = String.valueOf(paramMap.get(CHANGE_REQUEST_ID));
			boolean isRevert = Boolean.parseBoolean(String.valueOf(paramMap.get("isRevert")));
			List<Map<String, Object>> changeRequestHistoryList = getChangeRequestHistoryList(changeReuestId);
			if (changeRequestHistoryList.isEmpty()) {
				paramMap.put(STATUS, false);
				paramMap.put(MESSAGE, "No data present in change request.");
				return paramMap;
			}
			List<String> tableNameList = changeRequestHistoryList.stream()
					.map(mapper -> String.valueOf(mapper.get(TABLE_NAME))).collect(Collectors.toList());
			AtomicBoolean isDataDefinition = new AtomicBoolean(false);
			DataDefinitionConstants.DATA_DEFINITION_TABLE_LIST.stream().forEach(action -> {
				if (tableNameList.contains(action)) {
					isDataDefinition.set(true);
				}
			});
			if (isDataDefinition.get()) {
				resultMap = processDataDefinition(changeRequestHistoryList, isRevert, queryExecutor);
			} else {
				if (isRevert && Objects.nonNull(paramMap.get("revertId"))
						&& !String.valueOf(paramMap.get("revertId")).equals(changeReuestId)) {
					logger.info("revert id " + paramMap.get("revertId"));
					changeRequestHistoryList = getChangeRequestHistoryList(String.valueOf(paramMap.get("revertId")));
					isRevert = false;
				}
				resultMap = processTableDefinition(changeRequestHistoryList, isRevert, queryExecutor, paramMap);
			}
			resultMap.put(BT_EXECUTOR, queryExecutor);
			logger.info("beforeCrExecution method ends...");
		} catch (Exception exception) {
			DataDefinitionCommonUtils.executeRollback(queryExecutor);
			logger.error("exception" + exception);
			resultMap.put(STATUS, false);
			resultMap.put(MESSAGE, exception.getMessage());
			return resultMap;
		}
		return resultMap;
	}

	/**
	 * afterCrExecution used to validate the data after cr execution.
	 * 
	 * @param paramMap
	 * @return Map
	 */
	public Map<String, Object> afterCrExecution(Map<String, Object> paramMap) {
		logger.info("afterCrExecution method starts...");
		Map<String, Object> resultMap;
		boolean isDataDefinition = Boolean.parseBoolean(String.valueOf(paramMap.get(DATA_DEFINITION)));
		if (isDataDefinition) {
			resultMap = processDataDefinitionAfterCrExecution(paramMap);
		} else {
			resultMap = processTableDefinitionAfterCrExecution(paramMap);
		}
		logger.info("afterCrExecution method ends...");
		return resultMap;
	}

	/**
	 * processDataDefinition used to process the data definition tables.
	 * 
	 * @param changeReuestId
	 * @param isRevert
	 * @param queryExecutor2
	 * @return Map
	 * @throws CustomException
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> processDataDefinition(List<Map<String, Object>> changeRequestHistoryList,
			boolean isRevert, QueryExecutor queryExecutor) throws CustomException {
		logger.info("processDataDefinition method starts...");
		Map<String, Object> resultMap = new HashMap<>();
		JSONParser parser = new JSONParser();
		ObjectMapper mapper = new ObjectMapper();
		try {
			Map<String, List<Object>> upsertDataMap = new HashMap<>();
			Map<String, List<Object>> upsertPrimaryKeyMap = new HashMap<>();
			Map<String, List<Object>> deletePrimaryKeyMap = new HashMap<>();
			Map<String, List<Map<String, Object>>> dataMap = new HashMap<>();
			Map<String, List<Object>> upsertErrorMap = new HashMap<>();
			Map<String, List<Object>> deleteErrorMap = new HashMap<>();
			AtomicReference<String> columnName = new AtomicReference<>("transport_data");
			if (isRevert) {
				columnName.set("revert_data");
			}
			changeRequestHistoryList.stream().forEach(action -> {
				try {
					List<Map<String, Object>> queryList = new ArrayList<>();
					Object jsonData = parser.parse(String.valueOf(action.get(columnName.get())));
					Map<String, Object> jsonMap = JsonUtils.fromJsonOrThrow(jsonData.toString(), Map.class);
					if (isRevert) {
						if (jsonMap.containsKey(DELETE) || jsonMap.containsKey(UPSERT)) {
							String mapKey = jsonMap.containsKey(UPSERT) ? UPSERT : DELETE;
							Map<String, Object> valueMap = (Map<String, Object>) parser
									.parse(String.valueOf(jsonMap.get(mapKey)));
							queryList = mapper.readValue(valueMap.get(QUERY).toString(),
									new TypeReference<List<Map<String, Object>>>() {
									});
						} else if (jsonMap.containsKey(QUERY)) {
							queryList = mapper.readValue(jsonMap.get(QUERY).toString(),
									new TypeReference<List<Map<String, Object>>>() {
									});
						}
					} else {
						queryList = mapper.readValue(jsonMap.get(QUERY).toString(),
								new TypeReference<List<Map<String, Object>>>() {
								});
					}
					for (Map<String, Object> query : queryList) {
						processRowData(query, upsertDataMap, upsertPrimaryKeyMap, dataMap, deletePrimaryKeyMap);
					}
				} catch (Exception exception) {
					logger.error("Exception in processing change request history list " + exception);
				}
			});
			validateDataDefinition(upsertDataMap, upsertPrimaryKeyMap, dataMap, upsertErrorMap, queryExecutor);
			Map<String, List<Map<String, Object>>> dataDefinitionList = getDataDefinitionList(upsertDataMap,
					queryExecutor);
			resultMap.put(DELETE_PRIMARY_KEY_MAP, deletePrimaryKeyMap);
			resultMap.put("dataDefinitionList", dataDefinitionList);
			resultMap.put(DATA_DEFINITION, true);
			resultMap.put("upsertDataMap", upsertDataMap);
			processResult(resultMap, upsertErrorMap, deleteErrorMap);
		} catch (Exception exception) {
			logger.error("Exception in processDataDefinition " + exception);
			resultMap.put(STATUS, false);
			DataDefinitionCommonUtils.executeRollback(queryExecutor);
			resultMap.put(MESSAGE, exception.getMessage());
			throw new CustomException(exception.getMessage());
		}
		logger.info("processDataDefinition method ends...");
		return resultMap;
	}

	/**
	 * processResult used to process the error.
	 * 
	 * @param resultMap
	 * @param upsertErrorMap
	 * @param deleteErrorMap
	 */
	private void processResult(Map<String, Object> resultMap, Map<String, List<Object>> upsertErrorMap,
			Map<String, List<Object>> deleteErrorMap) {
		logger.info("process error result" + upsertErrorMap + deleteErrorMap);
		boolean status = true;
		StringBuilder builder = new StringBuilder();
		if (MapUtils.isNotEmpty(upsertErrorMap)) {
			status = false;
			upsertErrorMap.entrySet().stream().forEach(action -> {
				switch (action.getKey()) {
				case DataDefinitionConstants.DATA_ELEMENT_DEFINITION:
				case DataDefinitionConstants.AUTONUMBER_DEFINITION:
				case DataDefinitionConstants.DIVISION_DEFINITION:
					String dataFormatMessage = TableDefinitionUtils.getMessageDefintionText(
							MessageEntriesConstants.NN_DATA_DEF_DATA_FORMAT_NOT_PRESENT_IN_TRANSPORT);
					dataFormatMessage = dataFormatMessage.replace("%1$s", action.getValue().toString());
					builder.append(dataFormatMessage + "\n");
					break;
				case DataDefinitionConstants.DATA_FORMAT_DEFINITION:
					String charsetMessage = TableDefinitionUtils.getMessageDefintionText(
							MessageEntriesConstants.NN_DATA_DEF_CHARSET_ID_NOT_PRESENT_IN_TRANSPORT);
					charsetMessage = charsetMessage.replace("%1$s", action.getValue().toString());
					builder.append(charsetMessage + "\n");
					break;
				case DataDefinitionConstants.MASTER_DEFINITION:
					String masterMessage = TableDefinitionUtils.getMessageDefintionText(
							MessageEntriesConstants.NN_DATA_DEF_MASTER_ID_NOT_PRESENT_IN_TRANSPORT);
					masterMessage = masterMessage.replace("%1$s", action.getValue().toString());
					builder.append(masterMessage);
					break;
				default:
					break;
				}
			});
		}
		if (MapUtils.isNotEmpty(deleteErrorMap)) {
			status = false;
			deleteErrorMap.entrySet().stream().forEach(action -> {
				switch (action.getKey()) {
				case DataDefinitionConstants.DATA_ELEMENT_DEFINITION:
					builder.append(String.format(
							TableDefinitionUtils.getMessageDefintionText(
									MessageEntriesConstants.NN_DATA_DEF_DATA_ELEMENT_NOT_PRESENT_IN_TRANSPORT),
							Arrays.toString(action.getValue().toArray()).replace("[", "").replace("]", "")) + "\n");
					break;
				case DataDefinitionConstants.DATA_FORMAT_DEFINITION:
					builder.append(String.format(
							TableDefinitionUtils.getMessageDefintionText(
									MessageEntriesConstants.NN_DATA_DEF_FORMAT_ID_NOT_PRESENT_IN_TRANSPORT),
							Arrays.toString(action.getValue().toArray()).replace("[", "").replace("]", "")) + "\n");
					break;
				case DataDefinitionConstants.MASTER_DEFINITION:
					builder.append(String.format(
							TableDefinitionUtils
									.getMessageDefintionText("nn_table_definition_master_used_in_table"),
							Arrays.toString(action.getValue().toArray()).replace("[", "").replace("]", "")) + "\n");
					break;
				default:
					break;
				}
			});
		}
		resultMap.put(DataDefinitionConstants.MESSAGE, builder.toString());
		resultMap.put(STATUS, status);
	}

	/**
	 * getDataDefinitionList used to fetch the data list.
	 * 
	 * @param upsertDataMap
	 * @param queryExecutor
	 * @return Map
	 * @throws CustomException
	 */
	private Map<String, List<Map<String, Object>>> getDataDefinitionList(Map<String, List<Object>> upsertDataMap,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("getDataDefinitionList method starts...");
		Map<String, List<Map<String, Object>>> dataMap = new HashMap<>();
		AtomicBoolean error = new AtomicBoolean(false);
		upsertDataMap.entrySet().forEach(action -> {
			try {
				ConditionBuilder condition = ConditionBuilder.instance();
				String primaryKey = getPrimaryKey(action.getKey());
				condition.inWithList(primaryKey, action.getValue());
				List<Map<String, Object>> dataList = getDataList(action.getKey(), condition, queryExecutor);
				dataMap.put(action.getKey(), dataList);
			} catch (CustomException exception) {
				logger.error("Exception in fetching data definition list. " + exception);
				error.set(true);
			}
		});
		if (error.get()) {
			throw new CustomException("Eception in fetching data definition list.");
		}
		logger.info("getDataDefinitionList method ends...");
		return dataMap;
	}

	/**
	 * getPrimaryKey used to get the primary key of the table.
	 * 
	 * @param tableName
	 * @return String
	 */
	private String getPrimaryKey(String tableName) {
		logger.info("getPrimaryKey method starts...");
		String key = null;
		switch (tableName) {
		case DataDefinitionConstants.CHARSET_DEFINITION:
			key = DataDefinitionConstants.CHARSET_ID;
			break;
		case DataDefinitionConstants.DATA_FORMAT_DEFINITION:
			key = DataDefinitionConstants.DATA_FORMAT;
			break;
		case DataDefinitionConstants.DATA_ELEMENT_DEFINITION:
			key = DataDefinitionConstants.DATA_ELEMENT;
			break;
		case DataDefinitionConstants.MASTER_DEFINITION:
			key = DataDefinitionConstants.MASTER_ID;
			break;
		case DataDefinitionConstants.AUTONUMBER_DEFINITION:
			key = DataDefinitionConstants.AUTONUMBER_DEF_ID;
			break;
		case DataDefinitionConstants.DIVISION_DEFINITION:
			key = DataDefinitionConstants.DATA_FORMAT;
			break;
		default:
			break;
		}
		logger.info("getPrimaryKey method ends...");
		return key;
	}

	/**
	 * processRowData used to process the data one by one.
	 * 
	 * @param item
	 * @param item
	 * @param upsertDataMap
	 * @param deleteDataMap
	 * @param upsertPrimaryKeyMap
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 */
	private void processRowData(Map<String, Object> query, Map<String, List<Object>> upsertDataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> deletePrimaryKeyMap) {
		logger.info("processRowData method starts...");
		if (String.valueOf(query.get(DataDefinitionConstants.QUERY_TYPE))
				.equalsIgnoreCase(DataDefinitionConstants.UPSERT)) {
			processQueryTypeData(query, upsertDataMap, upsertPrimaryKeyMap, DataDefinitionConstants.UPSERT, dataMap);
		} else if (String.valueOf(query.get(DataDefinitionConstants.QUERY_TYPE))
				.equalsIgnoreCase(DataDefinitionConstants.DELETE)) {
			processDeleteData(query, deletePrimaryKeyMap);
		}
		logger.info("processRowData method ends...");
	}

	/**
	 * processQueryTypeData used to process the upsert/delete query types.
	 * 
	 * @param item
	 * @param addMap
	 * @param removeMap
	 * @param upsertPrimaryKeyMap
	 * @param operation
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 */
	@SuppressWarnings("unchecked")
	private void processDeleteData(Map<String, Object> item, Map<String, List<Object>> deletePrimaryKeyMap) {
		logger.info("processQueryTypeData method starts...");
		String tableName = String.valueOf(item.get(DataDefinitionConstants.TABLENAME));
		List<Map<String, Object>> conditionList = (List<Map<String, Object>>) item.get("condition");
		List<Object> conditionValues = (List<Object>) conditionList.get(0).get("values");
		List<Object> conditionMap = (List<Object>) conditionList.get(0).get("columnsList");
		switch (tableName) {
		case DataDefinitionConstants.DATA_ELEMENT_DEFINITION:
			deleteDataDefinitionList(deletePrimaryKeyMap, conditionValues, conditionMap,
					DataDefinitionConstants.DATA_ELEMENT_DEFINITION, "data_element");
			break;
		case DataDefinitionConstants.DATA_FORMAT_DEFINITION:
			deleteDataDefinitionList(deletePrimaryKeyMap, conditionValues, conditionMap,
					DataDefinitionConstants.DATA_FORMAT_DEFINITION, "data_format");
			break;
		case DataDefinitionConstants.CHARSET_DEFINITION:
			deleteDataDefinitionList(deletePrimaryKeyMap, conditionValues, conditionMap,
					DataDefinitionConstants.CHARSET_DEFINITION, "charset_id");
			break;
		case DataDefinitionConstants.MASTER_DEFINITION:
			deleteDataDefinitionList(deletePrimaryKeyMap, conditionValues, conditionMap,
					DataDefinitionConstants.MASTER_DEFINITION, "master_id");
			break;
		case DataDefinitionConstants.AUTONUMBER_DEFINITION:
			deleteDataDefinitionList(deletePrimaryKeyMap, conditionValues, conditionMap,
					DataDefinitionConstants.AUTONUMBER_DEFINITION, "autonumber_def_id");
			break;
		case DataDefinitionConstants.DIVISION_DEFINITION:
			deleteDataDefinitionList(deletePrimaryKeyMap, conditionValues, conditionMap,
					DataDefinitionConstants.DIVISION_DEFINITION, "data_format");
			break;
		default:
			break;
		}
		logger.info("processQueryTypeData method ends...");
	}

	private void deleteDataDefinitionList(Map<String, List<Object>> deletePrimaryKeyMap, List<Object> conditionValues,
			List<Object> conditionMap, String tableName, String key) {
		for (int iterator = 0; iterator < conditionMap.size(); iterator++) {
			if (conditionMap.get(iterator).equals(key)) {
				Object value = conditionValues.get(iterator);
				addDataToMap(deletePrimaryKeyMap, tableName, value);
			}

		}
	}

	/**
	 * processQueryTypeData used to process the upsert/delete query types.
	 * 
	 * @param item
	 * @param addMap
	 * @param removeMap
	 * @param upsertPrimaryKeyMap
	 * @param operation
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 */
	@SuppressWarnings("unchecked")
	private void processQueryTypeData(Map<String, Object> item, Map<String, List<Object>> addMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, String operation,
			Map<String, List<Map<String, Object>>> dataMap) {
		logger.info("processQueryTypeData method starts...");
		String tableName = String.valueOf(item.get(DataDefinitionConstants.TABLENAME));
		List<Map<String, Object>> dataList = (List<Map<String, Object>>) item.get("data");
		switch (tableName) {
		case DataDefinitionConstants.DATA_ELEMENT_DEFINITION:
			processData(dataList, DataDefinitionConstants.DATA_ELEMENT_DEFINITION,
					"data_element_definition.data_element", addMap, upsertPrimaryKeyMap, operation, dataMap);
			break;
		case DataDefinitionConstants.DATA_FORMAT_DEFINITION:
			processData(dataList, DataDefinitionConstants.DATA_FORMAT_DEFINITION, "data_format_definition.data_format",
					addMap, upsertPrimaryKeyMap, operation, dataMap);
			break;
		case DataDefinitionConstants.CHARSET_DEFINITION:
			processData(dataList, DataDefinitionConstants.CHARSET_DEFINITION, "charset_definition.charset_id", addMap,
					upsertPrimaryKeyMap, operation, dataMap);
			break;
		case DataDefinitionConstants.MASTER_DEFINITION:
			processData(dataList, DataDefinitionConstants.MASTER_DEFINITION, "master_definition.master_id", addMap,
					upsertPrimaryKeyMap, operation, dataMap);
			break;
		case DataDefinitionConstants.AUTONUMBER_DEFINITION:
			processData(dataList, DataDefinitionConstants.AUTONUMBER_DEFINITION,
					"autonumber_definition.autonumber_def_id", addMap, upsertPrimaryKeyMap, operation, dataMap);
			break;
		case DataDefinitionConstants.DIVISION_DEFINITION:
			processData(dataList, DataDefinitionConstants.DIVISION_DEFINITION, "division_definition.data_format",
					addMap, upsertPrimaryKeyMap, operation, dataMap);
			break;
		default:
			break;
		}
		logger.info("processQueryTypeData method ends...");
	}

	/**
	 * processData used to process the dataList one by one.
	 * 
	 * @param dataList
	 * @param tableName
	 * @param primaryKey
	 * @param addMap
	 * @param removeMap
	 * @param upsertPrimaryKeyMap
	 * @param operation
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 */
	private void processData(List<Map<String, Object>> dataList, String tableName, String primaryKey,
			Map<String, List<Object>> addMap, Map<String, List<Object>> upsertPrimaryKeyMap, String operation,
			Map<String, List<Map<String, Object>>> dataMap) {
		logger.info("processData method starts...");
		dataList.stream().forEach(data -> {
			if (data.containsKey(primaryKey)) {
				addAndRemoveData(addMap, tableName, data, upsertPrimaryKeyMap, operation, dataMap, primaryKey);
			}
		});
		logger.info("processData method ends...");
	}

	/**
	 * addAndRemoveData used to add the data to upsert/delete map.
	 * 
	 * @param addMap
	 * @param removeMap
	 * @param key
	 * @param data
	 * @param upsertPrimaryKeyMap
	 * @param operation
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 * @param primaryKey
	 */
	private void addAndRemoveData(Map<String, List<Object>> addMap, String key, Map<String, Object> data,
			Map<String, List<Object>> upsertPrimaryKeyMap, String operation,
			Map<String, List<Map<String, Object>>> dataMap, String primaryKey) {
		logger.info("addDataToMap method starts...");
		Object value = data.get(primaryKey);
		if (operation.equalsIgnoreCase(DataDefinitionConstants.UPSERT)) {
			addDataToMap(upsertPrimaryKeyMap, key, value);
			List<Map<String, Object>> dataList = new ArrayList<>();
			if (dataMap.containsKey(key) && Objects.nonNull(dataMap.get(key))) {
				dataList = dataMap.get(key);
			}
			dataList.add(data);
			dataMap.put(key, dataList);
		}
		addDataToMap(addMap, key, value);
		logger.info("addDataToMap method ends...");
	}

	/**
	 * addDataToMap used to add the data in map.
	 * 
	 * @param dataMap
	 * @param key
	 * @param value
	 */
	private void addDataToMap(Map<String, List<Object>> dataMap, String key, Object value) {
		logger.info("addDataToMap method starts...");
		List<Object> valueList = new ArrayList<>();
		if (dataMap.containsKey(key) && Objects.nonNull(dataMap.get(key))) {
			valueList = dataMap.get(key);
		}
		valueList.add(value);
		dataMap.put(key, valueList.stream().distinct().collect(Collectors.toList()));
		logger.info("addDataToMap method ends...");
	}

	/**
	 * validateDataDefinition used to validate the insert and delete data with their
	 * dependent tables.
	 * 
	 * @param upsertDataMap
	 * @param deleteDataMap
	 * @param upsertPrimaryKeyMap
	 * @param dataMap
	 * @param errorMap
	 * @param deletePrimaryKeyMap
	 * @param deleteErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDataDefinition(Map<String, List<Object>> upsertDataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> upsertErrorMap, QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDataDefinition method starts...");
		validateUpsertData(upsertDataMap, upsertPrimaryKeyMap, dataMap, upsertErrorMap, queryExecutor);
		logger.info("validateDataDefinition method ends...");
	}

	/**
	 * validateUpsertData used to validate the upsert data.
	 * 
	 * @param upsertDataMap
	 * @param upsertPrimaryKeyMap
	 * @param dataMap
	 * @param upsertErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateUpsertData(Map<String, List<Object>> upsertDataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> upsertErrorMap, QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateUpsertData method starts...");
		if (upsertDataMap.containsKey(DataDefinitionConstants.DATA_FORMAT_DEFINITION)
				&& Objects.nonNull(upsertDataMap.get(DataDefinitionConstants.DATA_FORMAT_DEFINITION))) {
			validateDataClassUpsertData(dataMap, upsertPrimaryKeyMap, upsertErrorMap, queryExecutor);
		}
		if (upsertDataMap.containsKey(DataDefinitionConstants.AUTONUMBER_DEFINITION)
				&& Objects.nonNull(upsertDataMap.get(DataDefinitionConstants.AUTONUMBER_DEFINITION))) {
			validateAutoNumberUpsertData(dataMap, upsertPrimaryKeyMap, upsertErrorMap, queryExecutor);
		}
		if (upsertDataMap.containsKey(DataDefinitionConstants.DIVISION_DEFINITION)
				&& Objects.nonNull(upsertDataMap.get(DataDefinitionConstants.DIVISION_DEFINITION))) {
			validateDivisionUpsertData(dataMap, upsertPrimaryKeyMap, upsertErrorMap, queryExecutor);
		}
		if (upsertDataMap.containsKey(DataDefinitionConstants.DATA_ELEMENT_DEFINITION)
				&& Objects.nonNull(upsertDataMap.get(DataDefinitionConstants.DATA_ELEMENT_DEFINITION))) {
			validateDataElementUpsertData(dataMap, upsertPrimaryKeyMap, upsertErrorMap, queryExecutor);
		}
		logger.info("validateUpsertData method ends...");
	}

	/**
	 * validateDataClassUpsertData used to validate data class upsert data.
	 * 
	 * @param upsertDataMap
	 * @param dataMap
	 * @param upsertPrimaryKeyMap
	 * @param upsertErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDataClassUpsertData(Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Object>> upsertErrorMap,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDataClassUpsertData method starts...");
		List<Object> errorDataClassList = new ArrayList<>();
		List<Object> errorMasterList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		List<Map<String, Object>> dataFormatList = dataMap.get(DataDefinitionConstants.DATA_FORMAT_DEFINITION);
		dataFormatList.stream().forEach(action -> {
			try {
				String charset = String.valueOf(action.get("data_format_definition.charset_id"));
				ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.CHARSET_ID,
						charset);
				boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.CHARSET_DEFINITION, condition,
						queryExecutor);
				if (!isDataPresent) {
					isDataPresent = checkInInsertList(charset, upsertPrimaryKeyMap,
							DataDefinitionConstants.CHARSET_DEFINITION);
					if (!isDataPresent) {
						errorDataClassList
								.add(action.get("data_format_definition." + DataDefinitionConstants.CHARSET_ID));
					}
				}
				validateDataClassMasterTypeData(queryExecutor, action, upsertPrimaryKeyMap, errorMasterList);
			} catch (CustomException exception) {
				error.set(true);
				logger.error("Exception in validate data class upsert data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException("Exception in validate data class upsert data.");
		}
		if (CollectionUtils.isNotEmpty(errorMasterList)) {
			upsertErrorMap.put(DataDefinitionConstants.MASTER_DEFINITION, errorMasterList);
		}
		if (CollectionUtils.isNotEmpty(errorDataClassList)) {
			upsertErrorMap.put(DataDefinitionConstants.DATA_FORMAT_DEFINITION, errorDataClassList);
		}
		logger.info("validateDataClassUpsertData method ends...");
	}

	/**
	 * validateDataClassMasterTypeData used to validate master id for data class.
	 * 
	 * @param queryExecutor
	 * @param action
	 * @param upsertPrimaryKeyMap
	 * @param errorMasterList
	 * @throws CustomException
	 */
	private void validateDataClassMasterTypeData(QueryExecutor queryExecutor, Map<String, Object> action,
			Map<String, List<Object>> upsertPrimaryKeyMap, List<Object> errorMasterList) throws CustomException {
		String elementType = String.valueOf(action.get("data_format_definition.element_type"));
		if (elementType.equals(DataDefinitionConstants.MASTER)) {
			String masterId = String.valueOf(action.get("data_format_definition.master_id"));
			ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.MASTER_ID, masterId);
			boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.MASTER_DEFINITION, condition,
					queryExecutor);
			if (!isDataPresent) {
				isDataPresent = checkInInsertList(masterId, upsertPrimaryKeyMap,
						DataDefinitionConstants.MASTER_DEFINITION);
				if (!isDataPresent) {
					errorMasterList.add(action.get("data_format_definition." + DataDefinitionConstants.MASTER_ID));
				}
			}
		}
	}

	/**
	 * checkInInsertList used to check the data present in insert list.
	 * 
	 * @param data
	 * @param upsertPrimaryKeyMap
	 * @param key
	 * @return boolean
	 */
	private boolean checkInInsertList(String data, Map<String, List<Object>> upsertPrimaryKeyMap, String key) {
		logger.info("checkInInsertList method starts...");
		boolean isPresent = false;
		if (upsertPrimaryKeyMap.containsKey(key) && CollectionUtils.isNotEmpty(upsertPrimaryKeyMap.get(key))) {
			List<Object> dataList = upsertPrimaryKeyMap.get(key);
			return dataList.contains(data);
		}
		logger.info("checkInInsertList method ends...");
		return isPresent;
	}

	/**
	 * checkDataPresentInTable used to data present in table.
	 * 
	 * @param tableName
	 * @param condition
	 * @param queryExecutor
	 * @return boolean
	 * @throws CustomException
	 */
	private boolean checkDataPresentInTable(String tableName, ConditionBuilder condition, QueryExecutor queryExecutor)
			throws CustomException {
		logger.info("checkDataPresentInTable method starts...");
		boolean isPresent = false;
		List<Map<String, Object>> dataList = getDataList(tableName, condition, queryExecutor);
		if (CollectionUtils.isNotEmpty(dataList))
			isPresent = true;
		logger.info("checkDataPresentInTable method ends...");
		return isPresent;
	}

	/**
	 * getDataList used to get the data list.
	 * 
	 * @param tableName
	 * @param condition
	 * @param queryExecutor
	 * @return List
	 * @throws CustomException
	 */
	private List<Map<String, Object>> getDataList(String tableName, ConditionBuilder condition,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("getDataList method starts...");
		List<Map<String, Object>> dataList = new ArrayList<>();
		try {
			if (Objects.isNull(queryExecutor)) {
				queryExecutor = new QueryBuilder().btSchema().getQueryExecutor();
			}
			dataList = queryExecutor.queryBuilder().select().skipTenantId(true).from(tableName).where(condition)
					.build(false).execute();
		} catch (Exception exception) {
			DataDefinitionCommonUtils.executeRollback(queryExecutor);
			logger.error("Exception in getting data list " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("getDataList method ends...");
		return dataList;
	}

	/**
	 * validateAutoNumberUpsertData used to validate auto number data.
	 * 
	 * @param upsertDataMap
	 * @param dataMap
	 * @param upsertPrimaryKeyMap
	 * @param upsertErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateAutoNumberUpsertData(Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Object>> upsertErrorMap,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateAutoNumberUpsertData method starts...");
		List<Object> errorAutoNumberList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		List<Map<String, Object>> autoNumberList = dataMap.get(DataDefinitionConstants.AUTONUMBER_DEFINITION);
		autoNumberList.stream().forEach(action -> {
			try {
				String autoNumberDefId = String.valueOf(action.get("autonumber_definition.autonumber_def_id"));
				ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_FORMAT,
						autoNumberDefId);
				boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.DATA_FORMAT_DEFINITION,
						condition, queryExecutor);
				if (!isDataPresent) {
					isDataPresent = checkInInsertList(autoNumberDefId, upsertPrimaryKeyMap,
							DataDefinitionConstants.DATA_FORMAT_DEFINITION);
					if (!isDataPresent) {
						errorAutoNumberList.add(action.get(DataDefinitionConstants.AUTONUMBER_DEF_ID));
					}
				}
			} catch (CustomException exception) {
				error.set(true);
				logger.error("Exception in validate auto number upsert data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException("Exception in validate auto number upsert data.");
		}
		if (CollectionUtils.isNotEmpty(errorAutoNumberList)) {
			upsertErrorMap.put(DataDefinitionConstants.AUTONUMBER_DEFINITION, errorAutoNumberList);
		}
		logger.info("validateAutoNumberUpsertData method ends...");
	}

	/**
	 * validateDivisionUpsertData used to validate division data.
	 * 
	 * @param upsertDataMap
	 * @param dataMap
	 * @param upsertPrimaryKeyMap
	 * @param upsertErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDivisionUpsertData(Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Object>> upsertErrorMap,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDivisionUpsertData method starts...");
		List<Object> errorDivisionList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		List<Map<String, Object>> divisionList = dataMap.get(DataDefinitionConstants.DIVISION_DEFINITION);
		divisionList.stream().forEach(action -> {
			try {
				String dataFormat = String.valueOf(action.get("division_definition.data_format"));
				ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_FORMAT,
						dataFormat);
				boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.DATA_FORMAT_DEFINITION,
						condition, queryExecutor);
				if (!isDataPresent) {
					isDataPresent = checkInInsertList(dataFormat, upsertPrimaryKeyMap,
							DataDefinitionConstants.DATA_FORMAT_DEFINITION);
					if (!isDataPresent) {
						errorDivisionList.add(action.get(DataDefinitionConstants.DATA_FORMAT));
					}
				}
			} catch (CustomException exception) {
				error.set(true);
				logger.error("Exception in validate division upsert data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException("Exception in validate division upsert data.");
		}
		if (CollectionUtils.isNotEmpty(errorDivisionList)) {
			upsertErrorMap.put(DataDefinitionConstants.DIVISION_DEFINITION, errorDivisionList);
		}
		logger.info("validateDivisionUpsertData method ends...");
	}

	/**
	 * validateDataElementUpsertData used to validate data element upsert data.
	 * 
	 * @param upsertDataMap
	 * @param dataMap
	 * @param upsertPrimaryKeyMap
	 * @param upsertErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDataElementUpsertData(Map<String, List<Map<String, Object>>> dataMap,
			Map<String, List<Object>> upsertPrimaryKeyMap, Map<String, List<Object>> upsertErrorMap,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDataElementUpsertData method starts...");
		List<Object> errorMasterList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		List<Map<String, Object>> dataElementList = dataMap.get(DataDefinitionConstants.DATA_ELEMENT_DEFINITION);
		dataElementList.stream().forEach(action -> {
			try {
				String dataFormat = String.valueOf(action.get("data_element_definition.data_format"));
				ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_FORMAT,
						dataFormat);
				boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.DATA_FORMAT_DEFINITION,
						condition, queryExecutor);
				if (!isDataPresent) {
					isDataPresent = checkInInsertList(dataFormat, upsertPrimaryKeyMap,
							DataDefinitionConstants.DATA_FORMAT_DEFINITION);
					if (!isDataPresent) {
						errorMasterList.add(dataFormat);
					}
				}
			} catch (CustomException exception) {
				error.set(true);
				logger.error("Exception in validate data element upsert data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException("Exception in validate data element upsert data.");
		}
		if (CollectionUtils.isNotEmpty(errorMasterList)) {
			upsertErrorMap.put(DataDefinitionConstants.DATA_ELEMENT_DEFINITION, errorMasterList);
		}
		logger.info("validateDataElementUpsertData method ends...");
	}

	/**
	 * validateDeleteData used to validate delete data.
	 * 
	 * @param deleteDataMap
	 * @param deletePrimaryKeyMap
	 * @param dataMap
	 * @param deleteErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDeleteData(Map<String, List<Object>> deletePrimaryKeyMap,
			Map<String, List<Object>> deleteErrorMap, QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDeleteData method starts...");
		if (deletePrimaryKeyMap.containsKey(DataDefinitionConstants.DATA_FORMAT_DEFINITION)
				&& Objects.nonNull(deletePrimaryKeyMap.get(DataDefinitionConstants.DATA_FORMAT_DEFINITION))) {
			validateDataClassDeleteData(deletePrimaryKeyMap, deleteErrorMap, queryExecutor);
		}
		if (deletePrimaryKeyMap.containsKey(DataDefinitionConstants.DATA_ELEMENT_DEFINITION)
				&& Objects.nonNull(deletePrimaryKeyMap.get(DataDefinitionConstants.DATA_ELEMENT_DEFINITION))) {
			validateDataElementDeleteData(deletePrimaryKeyMap, deleteErrorMap, queryExecutor);
		}
		if (deletePrimaryKeyMap.containsKey(DataDefinitionConstants.MASTER_DEFINITION)
				&& Objects.nonNull(deletePrimaryKeyMap.get(DataDefinitionConstants.MASTER_DEFINITION))) {
			validateMasterDeleteData(deletePrimaryKeyMap, deleteErrorMap, queryExecutor);
		}
		logger.info("validateDeleteData method ends...");
	}

	/**
	 * validateMasterDeleteData used to validate master delete
	 * 
	 * @param deletePrimaryKeyMap
	 * @param deleteErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateMasterDeleteData(Map<String, List<Object>> deletePrimaryKeyMap,
			Map<String, List<Object>> deleteErrorMap, QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateMasterDeleteData method starts...");
		List<Object> errorDataClassList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		List<Object> dataFormatList = deletePrimaryKeyMap.get(DataDefinitionConstants.MASTER_DEFINITION);
		dataFormatList.stream().forEach(action -> {
			try {
				String dataFormat = String.valueOf(action);
				ConditionBuilder condition = ConditionBuilder.instance().eq("master_id", dataFormat);
				boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.MASTER_DEFINITION, condition,
						queryExecutor);
				boolean isUsedInTableDefinition = checkDataPresentInTable(
						DataDefinitionConstants.DATA_FORMAT_DEFINITION, condition, queryExecutor);
				if (!isDataPresent && isUsedInTableDefinition) {
					errorDataClassList.add(dataFormat);
				}
			} catch (CustomException exception) {
				error.set(true);
				logger.error("Exception in validate data class delete data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException("Exception in validate data class delete data.");
		}
		if (CollectionUtils.isNotEmpty(errorDataClassList)) {
			deleteErrorMap.put(DataDefinitionConstants.MASTER_DEFINITION, errorDataClassList);
		}
		logger.info("validateMasterDeleteData method ends...");

	}

	/**
	 * validateDataClassDeleteData used to validate data class delete data.
	 * 
	 * @param deleteDataMap
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 * @param deleteErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDataClassDeleteData(Map<String, List<Object>> deletePrimaryKeyMap,
			Map<String, List<Object>> deleteErrorMap, QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDataClassDeleteData method starts...");
		List<Object> errorDataClassList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		List<Object> dataFormatList = deletePrimaryKeyMap.get(DataDefinitionConstants.DATA_FORMAT_DEFINITION);
		dataFormatList.stream().forEach(action -> {
			try {
				String dataFormat = String.valueOf(action);
				ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_FORMAT,
						dataFormat);
				boolean isDataPresent = checkDataPresentInTable(DataDefinitionConstants.DATA_FORMAT_DEFINITION,
						condition, queryExecutor);
				boolean isUsedInTableDefinition = checkUsedInTableDefinition(dataFormat);
				if (!isDataPresent && isUsedInTableDefinition) {
					errorDataClassList.add(dataFormat);
				}
			} catch (CustomException exception) {
				error.set(true);
				logger.error("Exception in validate data class delete data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException("Exception in validate data class delete data.");
		}
		if (CollectionUtils.isNotEmpty(errorDataClassList)) {
			deleteErrorMap.put(DataDefinitionConstants.DATA_FORMAT_DEFINITION, errorDataClassList);
		}
		logger.info("validateDataClassDeleteData method ends...");
	}

	/**
	 * validateDataElementDeleteData used to validate data element delete data
	 * 
	 * @param deleteDataMap
	 * @param dataMap
	 * @param deletePrimaryKeyMap
	 * @param deleteErrorMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private void validateDataElementDeleteData(Map<String, List<Object>> deletePrimaryKeyMap,
			Map<String, List<Object>> deleteErrorMap, QueryExecutor queryExecutor) throws CustomException {
		logger.info("validateDataElementDeleteData method starts...");
		List<Object> errorDataElementList = new ArrayList<>();
		AtomicBoolean error = new AtomicBoolean(false);
		StringBuilder errorMessage = new StringBuilder();
		List<Object> dataElementList = deletePrimaryKeyMap.get(DataDefinitionConstants.DATA_ELEMENT_DEFINITION);
		dataElementList.stream().forEach(action -> {
			try {
				String dataElement = String.valueOf(action);
				ConditionBuilder condition = ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_ELEMENT,
						dataElement);
				if (!checkDataPresentInTable(DataDefinitionConstants.DATA_ELEMENT_DEFINITION, condition, queryExecutor)
						&& checkDataPresentInTable(DataDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS, condition,
								queryExecutor)) {
					errorDataElementList.add(dataElement);
				}

			} catch (CustomException exception) {
				error.set(true);
				errorMessage.append(exception.getMessage());
				logger.error("Exception in validate data element delete data. " + exception);
			}
		});
		if (error.get()) {
			throw new CustomException(errorMessage.toString());
		}
		if (CollectionUtils.isNotEmpty(errorDataElementList)) {
			deleteErrorMap.put(DataDefinitionConstants.DATA_ELEMENT_DEFINITION, errorDataElementList);
		}
		logger.info("validateDataElementDeleteData method ends...");
	}

	/**
	 * checkUsedInTableDefinition used to check whether data element used in table
	 * definition or not
	 * 
	 * @param dataFormat
	 * @return boolean
	 * @throws CustomException
	 */
	private boolean checkUsedInTableDefinition(String dataFormat) throws CustomException {
		logger.info("checkUsedInTableDefinition method starts...");
		boolean isUsedInTableDefinition = false;
		try {
			List<Map<String, Object>> dataFormatList = new QueryBuilder().btSchema().select().skipTenantId(true)
					.from(DataDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_VIEW)
					.where(ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_FORMAT, dataFormat).and()
							.isNull("data_element"))
					.build(false).execute();
			if (CollectionUtils.isNotEmpty(dataFormatList))
				isUsedInTableDefinition = true;
		} catch (Exception exception) {
			logger.error("Exception in checkUsedInTableDefinition method " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("checkUsedInTableDefinition method ends...");
		return isUsedInTableDefinition;
	}

	/**
	 * getChangeRequestHistoryList used to get the change request history list.
	 * 
	 * @param changeReuestId
	 * @return List
	 */
	private List<Map<String, Object>> getChangeRequestHistoryList(String changeReuestId) {
		return ChangeRequestDao.fetchRequestData(changeReuestId, null, SortType.ASC);
	}

	/**
	 * processTableDefinition used to process the table definition data.
	 * 
	 * @param changeReuestId
	 * @param isRevert
	 * @param queryExecutor
	 * @param paramMap
	 * @return Map
	 * @throws CustomException
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> processTableDefinition(List<Map<String, Object>> changeRequestHistoryList,
			boolean isRevert, QueryExecutor queryExecutor, Map<String, Object> paramMap) throws CustomException {
		logger.info("processTableDefinition method starts...");
		JSONParser parser = new JSONParser();
		ObjectMapper mapper = new ObjectMapper();
		List<Object> tableNameList = new ArrayList<>();
		List<Object> productCodeList = new ArrayList<>();
		Map<String, Object> tableDefinitionDetails = new HashMap<>();
		AtomicBoolean notDeleteFlag = new AtomicBoolean(true);

		AtomicReference<String> columnName = new AtomicReference<>("transport_data");
		if (isRevert) {
			columnName.set("revert_data");
		}
		try {
			changeRequestHistoryList.stream().forEach(action -> {
				try {
					List<Map<String, Object>> queryList = new ArrayList<>();
					Object jsonData = parser.parse(String.valueOf(action.get(columnName.get())));
					Map<String, Object> jsonMap = JsonUtils.fromJsonOrThrow(jsonData.toString(), Map.class);
					if (isRevert) {
						if (jsonMap.containsKey(DELETE) || jsonMap.containsKey(UPSERT)) {
							String mapKey = jsonMap.containsKey(UPSERT) ? UPSERT : DELETE;
							Map<String, Object> valueMap = (Map<String, Object>) parser
									.parse(String.valueOf(jsonMap.get(mapKey)));
							queryList = mapper.readValue(valueMap.get(QUERY).toString(),
									new TypeReference<List<Map<String, Object>>>() {
									});
						} else if (jsonMap.containsKey(QUERY)) {
							queryList = mapper.readValue(jsonMap.get(QUERY).toString(),
									new TypeReference<List<Map<String, Object>>>() {
									});
						}
					} else {
						queryList = mapper.readValue(jsonMap.get(QUERY).toString(),
								new TypeReference<List<Map<String, Object>>>() {
								});
					}
					for (Map<String, Object> query : queryList) {
						String tableName = String.valueOf(query.get(DataDefinitionConstants.TABLENAME));
						if (tableName.equalsIgnoreCase(DataDefinitionConstants.TABLE_DEFINITION)) {
							if (query.get("queryType").equals(DELETE)) {
								notDeleteFlag.set(false);
								List<Map<String, Object>> conditionList = (List<Map<String, Object>>) query
										.get("condition");
								if (!conditionList.isEmpty()) {
									List<Object> conditionValues = (List<Object>) conditionList.get(0).get("values");
									List<Object> conditionMap = (List<Object>) conditionList.get(0).get("columnsList");
									for (int iterator = 0; iterator < conditionMap.size(); iterator++) {
										if (conditionMap.get(iterator).equals(PRODUCT_CODE)) {
											productCodeList.add(conditionValues.get(iterator));
										}
										if (conditionMap.get(iterator).equals(TABLE_NAME)) {
											tableNameList.add(conditionValues.get(iterator));
										}
									}
								}
							} else if (query.get("queryType").equals("update")) {
								List<Map<String, Object>> conditionList = (List<Map<String, Object>>) query
										.get("condition");
								if (!conditionList.isEmpty()) {
									List<Object> conditionValues = (List<Object>) conditionList.get(0).get("values");
									List<Object> conditionMap = (List<Object>) conditionList.get(0).get("columnsList");
									for (int iterator = 0; iterator < conditionMap.size(); iterator++) {
										if (conditionMap.get(iterator).equals(PRODUCT_CODE)) {
											productCodeList.add(conditionValues.get(iterator));
										}
										if (conditionMap.get(iterator).equals(TABLE_NAME)) {
											tableNameList.add(conditionValues.get(iterator));
										}
									}
								}
							} else {
								List<Map<String, Object>> dataList = (List<Map<String, Object>>) query.get("data");
								dataList.stream().forEach(data -> {
									if (data.containsKey("tableDefinition.tableName")) {
										tableNameList.add(data.get("tableDefinition.tableName"));
										productCodeList.add(data.get("tableDefinition.productCode"));
									} else if (data.containsKey("table_definition.table_name")) {
										tableNameList.add(data.get("table_definition.table_name"));
										productCodeList.add(data.get("table_definition.product_code"));
									}
								});
							}
						}
					}
				} catch (Exception exception) {
					logger.error("Exception in processing change request history list " + exception);
				}
			});
			if (!tableNameList.isEmpty()) {
				tableDefinitionDetails = getTableDefinitionData(tableNameList, queryExecutor,
						String.valueOf(productCodeList.get(0)));
				if (!((List<Map<String, Object>>) tableDefinitionDetails.get(DataDefinitionConstants.TABLE_DEFINITION))
						.isEmpty()
						&& Objects.nonNull(((List<Map<String, Object>>) tableDefinitionDetails
								.get(DataDefinitionConstants.TABLE_DEFINITION)).get(0).get(STATUS))
						&& ((List<Map<String, Object>>) tableDefinitionDetails
								.get(DataDefinitionConstants.TABLE_DEFINITION)).get(0).get(STATUS)
										.equals(TableTypeEnum.INPROGRESS.name())) {
					throw new CustomException(CacheService.getInstance().getApplicationTextDefinitionData(
							"nn_table_definition_table_inprogress_state", SCREEN_DEF_ID, ContextBean.getLocale()));
				}
				if (notDeleteFlag.get() && !((List<Map<String, Object>>) tableDefinitionDetails
						.get(DataDefinitionConstants.TABLE_DEFINITION)).isEmpty()) {
					if (Objects
							.nonNull(((List<Map<String, Object>>) tableDefinitionDetails
									.get(DataDefinitionConstants.TABLE_DEFINITION)).get(0).get(STATUS))
							&& ((List<Map<String, Object>>) tableDefinitionDetails
									.get(DataDefinitionConstants.TABLE_DEFINITION)).get(0).get(STATUS)
											.equals(TableTypeEnum.INACTIVE.name())) {
						tableDefinitionDetails.put(SOURCE_CODE_GENERATE, true);
					}
					if (paramMap.containsKey(WHOLE_PACKAGING) && (boolean) (paramMap.get(WHOLE_PACKAGING))) {
						logger.info("whole packaging request");
						tableDefinitionDetails.put(WHOLE_PACKAGING, true);
						getTableDetailsForWholePackaging(tableNameList.stream().distinct().collect(Collectors.toList()),
								queryExecutor, tableDefinitionDetails, String.valueOf(productCodeList.get(0)));
					} else {
						tableDefinitionDetails.put("edit", true);
						TableDefinitionUtils.getTableDetails(String.valueOf(tableNameList.get(0)), queryExecutor,
								tableDefinitionDetails, String.valueOf(productCodeList.get(0)));
						dropFromMainTable(String.valueOf(tableNameList.get(0)), queryExecutor,
								String.valueOf(productCodeList.get(0)));
					}
				}
				tableDefinitionDetails.put("tableNameList",
						tableNameList.stream().distinct().collect(Collectors.toList()));
				tableDefinitionDetails.put(DATA_DEFINITION, false);
				tableDefinitionDetails.put(STATUS, true);
				tableDefinitionDetails.put(PRODUCT_CODE2, productCodeList.get(0));
			} else {
				tableDefinitionDetails.put(STATUS, false);
				DataDefinitionCommonUtils.executeRollback(queryExecutor);
				tableDefinitionDetails.put(MESSAGE, "Table name not specified.");
			}
		} catch (Exception exception) {
			DataDefinitionCommonUtils.executeRollback(queryExecutor);
			logger.error("Exception in processTableDefinition " + exception);
			tableDefinitionDetails.put(MESSAGE, exception.getMessage());
			tableDefinitionDetails.put(STATUS, false);
			throw new CustomException(exception.getMessage());
		}
		logger.info("processTableDefinition method ends...");
		return tableDefinitionDetails;
	}

	/**
	 * 
	 * @param tableNameList
	 * @param queryExecutor
	 * @param tableDefinitionDetails
	 * @param productCode
	 * @throws CustomException
	 */
	private void getTableDetailsForWholePackaging(List<Object> tableNameList, QueryExecutor queryExecutor,
			Map<String, Object> tableDefinitionDetails, String productCode) throws CustomException {
		Map<String, Object> wholePackagingMap = new HashMap<>();
		for (Object tableName : tableNameList) {
			Map<String, Object> tableMap = new HashMap<>();
			tableMap.put("edit", true);
			TableDefinitionUtils.getTableDetails(String.valueOf(tableName), queryExecutor, tableMap,
					String.valueOf(productCode));
			dropFromMainTable(String.valueOf(tableName), queryExecutor, String.valueOf(productCode));
			wholePackagingMap.put(String.valueOf(tableName), tableMap);
		}
		tableDefinitionDetails.put("tableDetailList", wholePackagingMap);
	}

	/**
	 * 
	 * @param tableName
	 * @param tableMetaExecutor
	 * @param productCode
	 * @throws CustomException
	 */
	void dropFromMainTable(String tableName, QueryExecutor tableMetaExecutor, String productCode)
			throws CustomException {
		logger.info("dropFromMainTable  method info starts.");
		try {
			tableMetaExecutor.queryBuilder().delete()
					.from(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.build().execute();
			tableMetaExecutor.queryBuilder().delete()
					.from(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.build().execute();
			tableMetaExecutor.queryBuilder().delete().from(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.build().execute();
			tableMetaExecutor.queryBuilder().delete()
					.from(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.build().execute();
			tableMetaExecutor.queryBuilder().delete().from(TableDefinitionConstants.TABLE_DEFINITION_MAIN)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.build().execute();
			tableMetaExecutor.queryBuilder().delete().from("view_object_column_details").where(
					ConditionBuilder.instance().eq("view_object_name", tableName).and().eq(PRODUCT_CODE, productCode))
					.build().execute();
			tableMetaExecutor.queryBuilder().delete().from("view_object_definition").where(
					ConditionBuilder.instance().eq("view_object_name", tableName).and().eq(PRODUCT_CODE, productCode))
					.build().execute();
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("dropFromMainTable  method info ends.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("dropFromMainTable  method info ends.");
	}

	/**
	 * getTableDefinitionData used to get the table definition tables data.
	 * 
	 * @param tableNameList
	 * @param queryExecutor
	 * @param productCode
	 * @returnMap
	 * @throws CustomException
	 */
	private Map<String, Object> getTableDefinitionData(List<Object> tableNameList, QueryExecutor queryExecutor,
			String productCode) throws CustomException {
		logger.info("getTableDefinitionData method starts...");
		Map<String, Object> dataMap = new HashMap<>();
		ConditionBuilder condition = ConditionBuilder.instance();
		condition.inWithList(DataDefinitionConstants.TABLE_NAME, tableNameList);
		condition.and().eq(PRODUCT_CODE, productCode);
		dataMap.put(DataDefinitionConstants.TABLE_DEFINITION,
				getDataList(DataDefinitionConstants.TABLE_DEFINITION, condition, queryExecutor));

		logger.info("getTableDefinitionData method ends...");
		return dataMap;
	}

	/**
	 * processTableDefinitionAfterCrExecution used to process the table definition
	 * data after cr execution.
	 * 
	 * @param tableDefinitionDetails
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> processTableDefinitionAfterCrExecution(Map<String, Object> tableDefinitionDetails) {
		logger.info("processTableDefinitionAfterCrExecution method starts..." + tableDefinitionDetails);
		Map<String, Map<String, Object>> dataMap = new HashMap<>();
		Map<String, Object> resultMap = new HashMap<>();
		QueryExecutor queryExecutor = null;
		QueryExecutor productExecutor = null;
		String changeRequestId = String.valueOf(tableDefinitionDetails.get(CHANGE_REQUEST_ID));
		boolean status = true;
		try {
			queryExecutor = (QueryExecutor) tableDefinitionDetails.get(BT_EXECUTOR);
			List<Object> tableNameList = (List<Object>) tableDefinitionDetails.get("tableNameList");
			String productCode = String.valueOf(tableDefinitionDetails.get(PRODUCT_CODE2));
			if (tableDefinitionDetails.containsKey(WHOLE_PACKAGING)
					&& (boolean) (tableDefinitionDetails.get(WHOLE_PACKAGING))) {
				return processWholePackagingRequest(tableDefinitionDetails, queryExecutor, tableNameList, productCode,
						resultMap);
			} else {
				Map<String, Object> updatedTableDefinitionDetails = getTableDefinitionData(tableNameList, queryExecutor,
						String.valueOf(tableDefinitionDetails.get(PRODUCT_CODE2)));
				compareTableDefinitionData(tableDefinitionDetails, updatedTableDefinitionDetails, dataMap);
				if (dataMap.containsKey(TABLE_DEFINITION)) {
					Map<String, Object> tableDetail = dataMap.get(TABLE_DEFINITION);
					String tableName = tableNameList.get(0).toString();
					if (tableDetail.containsKey(CREATE) && !((List<Object>) tableDetail.get(CREATE)).isEmpty()) {
						logger.info("create cr");
						List<Object> validDataElement = compareDataElements(updatedTableDefinitionDetails,
								queryExecutor);
						List<Object> validDataClass = compareDataClass(updatedTableDefinitionDetails, queryExecutor);
						if (validDataElement.isEmpty() && validDataClass.isEmpty()) {
							resultMap.put(TABLE_NAME2, tableName);
							resultMap.put(PRODUCT_CODE2, productCode);
							resultMap.put("edit", true);
							TableDefinitionUtils.getTableDetails(tableName, queryExecutor, resultMap,
									productCode);
							TableDefinitionUtils.getDataElementAndDataClassSet(resultMap, new HashSet<>(),
									new HashSet<>(), new HashMap<>());
							Map<String, Object> productDetailsMap = TableDefinitionUtils
									.getApplicationDatabaseDetails(productCode,
											String.valueOf(((List<Map<String, Object>>) (updatedTableDefinitionDetails
													.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0)
															.get(DATABASE_HANDLER)));
							if (productDetailsMap.containsKey(TableDefinitionConstants.ERROR_KEY)
									&& (boolean) productDetailsMap.get(TableDefinitionConstants.ERROR_KEY)) {
								logger.info("processTableDefinitionAfterCrExecution method execution ended"
										+ productDetailsMap);
								productDetailsMap.put(STATUS, false);
								DataDefinitionCommonUtils.executeRollback(queryExecutor);
								return productDetailsMap;
							}
							TableDefinitionUtils.getDataDefinitionDetailsFromOnline(queryExecutor, resultMap);
							productExecutor = TableDefinitionUtils.getProductExecutor(productDetailsMap);
							productExecutor.skipChangeRequest(true);
							CreateTableTemplate.createTable(productExecutor, resultMap);
							productExecutor.commit();
							queryExecutor.commit();
//							if (tableDefinitionDetails.containsKey(GENERATE_SOURCE)
//									&& (boolean) tableDefinitionDetails.get(GENERATE_SOURCE)) {
//								resultMap.put(IS_SOURCE_CODE_ONLY, true);
//								resultMap.put(PRODUCT_CODE2, productCode);
//								resultMap.put(VIEW_OBJECT, tableName);
//								new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//										new QueryBuilder());
//								Map<String, Object> repoMap = new HashMap<>();
//								repoMap.put(CREATE_LIST, Arrays.asList(tableName));
//								Map<String, Object> repoListMapMap = new HashMap<>();
//								repoListMapMap.put(String.valueOf(resultMap.get(REPO_NAME)), repoMap);
//								TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(repoListMapMap,
//										changeRequestId);
//							} else {
								resultMap.put(NOCHANGE, true);
								TableDefinitionUtils.releasedStatusMove(Arrays.asList(tableName), productCode,
										new HashMap<>());
//							}
						} else {
							errorMessageForDataDefinition(resultMap, validDataElement, validDataClass);
							status = false;
							queryExecutor.rollBack();
						}
					} else if (tableDetail.containsKey("drop") && !((List<Object>) tableDetail.get("drop")).isEmpty()) {
						logger.info("drop cr");
						Map<String, Object> productDetailsMap = TableDefinitionUtils
								.getApplicationDatabaseDetails(productCode,
										String.valueOf(((List<Map<String, Object>>) (tableDefinitionDetails
												.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0)
														.get(DATABASE_HANDLER)));
						if (productDetailsMap.containsKey(TableDefinitionConstants.ERROR_KEY)
								&& (boolean) productDetailsMap.get(TableDefinitionConstants.ERROR_KEY)) {
							logger.info("processTableDefinitionAfterCrExecution method execution ended."
									+ productDetailsMap);
							productDetailsMap.put(STATUS, false);
							DataDefinitionCommonUtils.executeRollback(queryExecutor);
							return productDetailsMap;
						}
						productExecutor = TableDefinitionUtils.getProductExecutor(productDetailsMap);
						productExecutor.skipChangeRequest(true);
						productExecutor.queryBuilder().table().dropTable(tableName + "_text")
								.setProductCode(productCode).build().execute();
						productExecutor.queryBuilder().table().dropTable(tableName).setProductCode(productCode).build()
								.execute();
//						if (tableDefinitionDetails.containsKey(GENERATE_SOURCE)
//								&& (boolean) tableDefinitionDetails.get(GENERATE_SOURCE)) {
//							resultMap.put(IS_SOURCE_CODE_ONLY, true);
//							resultMap.put("commitType", DELETE);
//							resultMap.put(PRODUCT_CODE2, productCode);
//							resultMap.put(VIEW_OBJECT, tableName);
//							new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//									new QueryBuilder());
//							Map<String, Object> repoMap = new HashMap<>();
//							repoMap.put("deleteList", Arrays.asList(tableName));
//							Map<String, Object> repoListMapMap = new HashMap<>();
//							repoListMapMap.put(String.valueOf(resultMap.get(REPO_NAME)), repoMap);
//							TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(repoListMapMap, changeRequestId);
//						} else {
							resultMap.put(NOCHANGE, true);
//						}
						queryExecutor.commit();
						productExecutor.commit();
						TableDefinitionUtils.updateProgramBusinessObject(Arrays.asList(tableName), true);
					} else if (tableDetail.containsKey(ALTER) && !((List<Object>) tableDetail.get(ALTER)).isEmpty()) {
						logger.info("alter cr");
						List<Object> validDataElement = compareDataElements(updatedTableDefinitionDetails,
								queryExecutor);
						List<Object> validDataClass = compareDataClass(updatedTableDefinitionDetails, queryExecutor);
						if (validDataElement.isEmpty() && validDataClass.isEmpty()) {
							tableDefinitionDetails.put(TABLE_NAME2, tableName);
							tableDefinitionDetails.put(PRODUCT_CODE2, productCode);
							Map<String, Object> alterMap = new HashMap<>();
							Map<String, Object> productDetailsMap = TableDefinitionUtils
									.getApplicationDatabaseDetails(productCode,
											String.valueOf(((List<Map<String, Object>>) (updatedTableDefinitionDetails
													.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0)
															.get(DATABASE_HANDLER)));
							if (productDetailsMap.containsKey(TableDefinitionConstants.ERROR_KEY)
									&& (boolean) productDetailsMap.get(TableDefinitionConstants.ERROR_KEY)) {
								logger.info("processTableDefinitionAfterCrExecution method execution ended."
										+ productDetailsMap);
								productDetailsMap.put(STATUS, false);
								DataDefinitionCommonUtils.executeRollback(queryExecutor);
								return productDetailsMap;
							}
							productExecutor = TableDefinitionUtils.getProductExecutor(productDetailsMap);
							productExecutor.skipChangeRequest(true);
							if (Integer.parseInt(productExecutor.queryBuilder().select().count("*", COUNT)
									.from("information_schema.tables")
									.where(ConditionBuilder.instance().eq(TABLE_NAME, productCode + "_" + tableName)
											.and()
											.eq("table_schema", productDetailsMap.get(TableDefinitionConstants.SCHEMA)))
									.build(false).execute().get(0).get(COUNT).toString()) == 0) {
								logger.info("table not present in this environment" + productCode + "_" + tableName);
								logger.info("create table triggered");
								resultMap.put(TABLE_NAME2, tableName);
								resultMap.put(PRODUCT_CODE2, productCode);
								resultMap.put("edit", true);
								TableDefinitionUtils.getTableDetails(tableName, queryExecutor, resultMap,
										productCode);
								TableDefinitionUtils.getDataElementAndDataClassSet(resultMap, new HashSet<>(),
										new HashSet<>(), new HashMap<>());
								TableDefinitionUtils.getDataDefinitionDetailsFromOnline(queryExecutor, resultMap);
								CreateTableTemplate.createTable(productExecutor, resultMap);
								productExecutor.commit();
								queryExecutor.commit();
//								if (tableDefinitionDetails.containsKey(GENERATE_SOURCE)
//										&& (boolean) tableDefinitionDetails.get(GENERATE_SOURCE)) {
//									resultMap.put(IS_SOURCE_CODE_ONLY, true);
//									resultMap.put(PRODUCT_CODE2, productCode);
//									resultMap.put(VIEW_OBJECT, tableName);
//									new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//											new QueryBuilder());
//									Map<String, Object> repoMap = new HashMap<>();
//									repoMap.put(CREATE_LIST, Arrays.asList(tableName));
//									Map<String, Object> repoListMapMap = new HashMap<>();
//									repoListMapMap.put(String.valueOf(resultMap.get(REPO_NAME)), repoMap);
//									TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(repoListMapMap,
//											changeRequestId);
//								} else {
									resultMap.put(NOCHANGE, true);
									TableDefinitionUtils.releasedStatusMove(Arrays.asList(tableName), productCode,
											new HashMap<>());
//								}
							} else {
								if (tableDefinitionDetails.containsKey(FORCE_TRUNCATE)
										&& (boolean) tableDefinitionDetails.get(FORCE_TRUNCATE)) {
									alterMap.put("forceUpdateKey", true);
								}
								alterMap.put(TABLE_NAME2, tableName);
								alterMap.put(PRODUCT_CODE2, productCode);
								alterMap.put("edit", true);
								TableDefinitionUtils.getTableDetails(tableName, queryExecutor, alterMap,
										productCode);
								TableDefinitionUtils.getDataElementAndDataClassSet(tableDefinitionDetails,
										new HashSet<>(), new HashSet<>(), alterMap);
								if (!((List<Map<String, Object>>) alterMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP)).isEmpty()) {
									for (Map<String, Object> indexDetails : (List<Map<String, Object>>) alterMap
											.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP)) {
										indexDetails.put(
												TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN
														+ ".columnNames",
												JsonUtils.toJsonOrThrow(
														JsonUtils.fromJsonOrThrow(((PGobject) indexDetails.get(
																TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN
																		+ ".columnNames")).getValue(),
																List.class)));
									}
								}

								if (!((List<Map<String, Object>>) alterMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP)).isEmpty()) {
									for (Map<String, Object> uniqueKeyDetailsMap : (List<Map<String, Object>>) alterMap
											.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP)) {
										uniqueKeyDetailsMap.put(
												TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN
														+ ".uniqueColumnDetails",
												JsonUtils.toJsonOrThrow(JsonUtils.fromJsonOrThrow(
														((PGobject) uniqueKeyDetailsMap.get(
																TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN
																		+ ".uniqueColumnDetails")).getValue(),
														List.class)));
									}
								}

								if (!((List<Map<String, Object>>) alterMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP))
												.isEmpty()) {
									for (Map<String, Object> foreignKeyDetails : (List<Map<String, Object>>) alterMap
											.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP)) {
										foreignKeyDetails.put(
												TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
														+ ".foreignKeyColumnDetails",
												JsonUtils.toJsonOrThrow(JsonUtils.fromJsonOrThrow(
														((PGobject) foreignKeyDetails.get(
																TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
																		+ ".foreignKeyColumnDetails")).getValue(),
														Map.class)));
									}
								}

								TableDefinitionUtils.getDataDefinitionDetailsFromOnline(queryExecutor,
										tableDefinitionDetails);

								tableDefinitionDetails.put("secondSystem", true);
								AlterTableTemplate.alterTable(productExecutor, tableDefinitionDetails, alterMap,
										queryExecutor);
								List<String> updateColumns = getUpdateColumnKeys(
										((List<Map<String, Object>>) alterMap
												.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP)).get(0),
										tableName);
								updateColumns.removeAll(
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_PRIMARY_KEY_LIST);
								queryExecutor.queryBuilder().insert().upsertWithKeyList(
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN,
										(List<Map<String, Object>>) alterMap
												.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP),
										true, updateColumns,
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_PRIMARY_KEY_LIST
												.toArray(
														new String[TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_PRIMARY_KEY_LIST
																.size()]));
								if (alterMap.containsKey("alterExecutor")) {
									productExecutor = (QueryExecutor) alterMap.get("alterExecutor");
								}
								productExecutor.commit();
								queryExecutor.commit();
								CacheService.getInstance().removeServerSideValidation(tableName, productCode);
								TableDefinitionUtils.updateProgramBusinessObject(Arrays.asList(tableName),false);
								if (!tableDefinitionDetails.containsKey(SOURCE_CODE_GENERATE)
										&& Integer.parseInt(new QueryBuilder().btSchema().select().count("*", COUNT)
												.from("table_definiton_request_history_details")
												.where(ConditionBuilder.instance()
														.eq("config_type", TableTypeEnum.SOURCE_CODE.name()).and()
														.eq("change_request_id", changeRequestId))
												.build(false).execute().get(0).get(COUNT).toString()) > 0) {
									tableDefinitionDetails.put(SOURCE_CODE_GENERATE, true);
								}
//								if (tableDefinitionDetails.containsKey(GENERATE_SOURCE)
//										&& (boolean) tableDefinitionDetails.get(GENERATE_SOURCE)
//										&& tableDefinitionDetails.containsKey(SOURCE_CODE_GENERATE)) {
//									resultMap.put(IS_SOURCE_CODE_ONLY, true);
//									resultMap.put(PRODUCT_CODE2, productCode);
//									resultMap.put(VIEW_OBJECT, tableName);
//									new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//											new QueryBuilder());
//									Map<String, Object> repoMap = new HashMap<>();
//									repoMap.put(CREATE_LIST, Arrays.asList(tableName));
//									Map<String, Object> repoListMapMap = new HashMap<>();
//									repoListMapMap.put(String.valueOf(resultMap.get(REPO_NAME)), repoMap);
//									TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(repoListMapMap,
//											changeRequestId);
//									if (Objects
//											.isNull(((List<Map<String, Object>>) (updatedTableDefinitionDetails
//													.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0).get(STATUS))
//											|| ((List<Map<String, Object>>) (updatedTableDefinitionDetails
//													.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0).get(STATUS)
//															.equals(TableTypeEnum.SUCCESS.name())) {
//										Map<String, Object> apiMap = new HashMap<>();
//										apiMap.put("tableDefinition.status", TableTypeEnum.INPROGRESS.name());
//										if (Objects
//												.nonNull(((List<Map<String, Object>>) (updatedTableDefinitionDetails
//														.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0)
//																.get("api_flag"))
//												&& (boolean) (((List<Map<String, Object>>) (updatedTableDefinitionDetails
//														.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0)
//																.get("api_flag"))) {
//											apiMap.put("tableDefinition.apiStatus", TableTypeEnum.INPROGRESS.name());
//										}
//										new QueryBuilder().btSchema().update().skipChangeRequest(true)
//												.skipTenantId(true)
//												.updateWithMap(TABLE_DEFINITION, apiMap, ConditionBuilder.instance()
//														.eq(TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode));
//									}
//								} else {
									resultMap.put(NOCHANGE, true);
									TableDefinitionUtils.releasedStatusMove(Arrays.asList(tableName), productCode,
											new HashMap<>());
									ChangeRequest.updateCrRepo(changeRequestId, new HashMap<>(), true, true);
//								}
							}
						} else {
							errorMessageForDataDefinition(resultMap, validDataElement, validDataClass);
							status = false;
							queryExecutor.rollBack();
						}
					} else {
						resultMap.put(NOCHANGE, true);
					}
				}
			}
			queryExecutor.commit();
		} catch (Exception exception) {
			if (tableDefinitionDetails.containsKey("forceUpdateError")) {
				resultMap.put(FORCE_TRUNCATE, true);
			}
			DataDefinitionCommonUtils.executeRollback(productExecutor);
			DataDefinitionCommonUtils.executeRollback(queryExecutor);
			logger.error("Exception in process table definition after cr execution. " + exception);
			resultMap.put(MESSAGE, exception.getMessage());
			status = false;
		}
		resultMap.put(STATUS, status);
		logger.info("processTableDefinitionAfterCrExecution method ends..." + resultMap);
		return resultMap;
	}

	/**
	 * 
	 * @param tableDefinitionDetails
	 * @param queryExecutor
	 * @param tableNameList
	 * @param productCode
	 * @throws CustomException
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> processWholePackagingRequest(Map<String, Object> tableDefinitionDetails,
			QueryExecutor queryExecutor, List<Object> tableNameList, String productCode, Map<String, Object> resultMap)
			throws CustomException {
		logger.info("processWholePackagingRequest method execution starts");
		boolean status = true;
		Map<String, QueryExecutor> productExecutorMap = new HashMap<>();
		try {
			Map<String, QueryExecutor> foreignExecutorMap = new HashMap<>();
			Map<String, List<Map<String, Object>>> foreignCreateMap = new HashMap<>();
			for (Object table : tableNameList) {
				QueryExecutor productExecutor = null;
				String tableName = String.valueOf(table);
				Map<String, Object> updatedTableDefinitionDetails = getTableDefinitionData(Arrays.asList(tableName),
						queryExecutor, productCode);
				logger.info("create cr");
				List<Object> validDataElement = compareDataElements(updatedTableDefinitionDetails, queryExecutor);
				List<Object> validDataClass = compareDataClass(updatedTableDefinitionDetails, queryExecutor);
				if (validDataElement.isEmpty() && validDataClass.isEmpty()) {
					resultMap.put(TABLE_NAME2, tableName);
					resultMap.put(PRODUCT_CODE2, productCode);
					resultMap.put("edit", true);
					TableDefinitionUtils.getTableDetails(tableName, queryExecutor, resultMap, productCode);

					TableDefinitionUtils.getDataElementAndDataClassSet(resultMap, new HashSet<>(),
							new HashSet<>(), new HashMap<>());
					if (productExecutorMap.containsKey(
							productCode + String.valueOf(((List<Map<String, Object>>) (updatedTableDefinitionDetails
									.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0).get(DATABASE_HANDLER)))) {
						productExecutor = productExecutorMap.get(
								productCode + String.valueOf(((List<Map<String, Object>>) (updatedTableDefinitionDetails
										.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0).get(DATABASE_HANDLER)));

					} else {
						Map<String, Object> productDetailsMap = TableDefinitionUtils
								.getApplicationDatabaseDetails(productCode,
										String.valueOf(((List<Map<String, Object>>) (updatedTableDefinitionDetails
												.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0)
														.get(DATABASE_HANDLER)));
						if (productDetailsMap.containsKey(TableDefinitionConstants.ERROR_KEY)
								&& (boolean) productDetailsMap.get(TableDefinitionConstants.ERROR_KEY)) {
							logger.info("processTableDefinitionAfterCrExecution method execution ended"
									+ productDetailsMap);
							productDetailsMap.put(STATUS, false);
							DataDefinitionCommonUtils.executeRollback(queryExecutor);
							return productDetailsMap;
						}
						productExecutor = TableDefinitionUtils.getProductExecutor(productDetailsMap);
						productExecutor.skipChangeRequest(true);
						productExecutorMap.put(
								productCode + String.valueOf(((List<Map<String, Object>>) (updatedTableDefinitionDetails
										.get(DataDefinitionConstants.TABLE_DEFINITION))).get(0).get(DATABASE_HANDLER)),
								productExecutor);
					}
					if (!((List<Map<String, Object>>) resultMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP)).isEmpty()) {
						foreignExecutorMap.put(tableName, productExecutor);
						foreignCreateMap.put(tableName, ((List<Map<String, Object>>) resultMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP)));
					}
					resultMap.put(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP, new ArrayList<>());
					TableDefinitionUtils.getDataDefinitionDetailsFromOnline(queryExecutor, resultMap);
					CreateTableTemplate.createTable(productExecutor, resultMap);

				} else {
					errorMessageForDataDefinition(resultMap, validDataElement, validDataClass);
					status = false;
					queryExecutor.rollBack();
					productExecutorMap.values().stream()
							.forEach(executorList -> TableDefinitionUtils.rollBackExecutor(executorList));
					break;
				}

			}
			if (status) {
				foreignAddForWholePackaging(productCode, foreignExecutorMap, foreignCreateMap);
				productExecutorMap.values().stream().forEach(executorList -> {
					try {
						TableDefinitionUtils.commitExecutor(executorList);
					} catch (CustomException exception) {
						logger.error(exception);
					}
				});
				queryExecutor.commit();
//				if (tableDefinitionDetails.containsKey(GENERATE_SOURCE)
//						&& (boolean) tableDefinitionDetails.get(GENERATE_SOURCE)) {
//					for (Object tableName : tableNameList) {
//						resultMap.put(IS_SOURCE_CODE_ONLY, true);
//						resultMap.put(PRODUCT_CODE2, productCode);
//						resultMap.put(VIEW_OBJECT, tableName);
//						if (noDelete) {
//							noDelete = false;
//						} else {
//							resultMap.put("noDelete", true);
//						}
//						new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//								new QueryBuilder());
//					}
//					Map<String, Object> repoMap = new HashMap<>();
//					repoMap.put(CREATE_LIST, Arrays.asList(tableNameList));
//					Map<String, Object> repoListMapMap = new HashMap<>();
//					repoListMapMap.put(String.valueOf(resultMap.get(REPO_NAME)), repoMap);
//					TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(repoListMapMap, changeRequestId);
//				} else {
					resultMap.put(NOCHANGE, true);
					TableDefinitionUtils.releasedStatusMove(Arrays.asList(tableNameList), productCode,
							new HashMap<>());
//				}
			}
		} catch (Exception exception) {
			productExecutorMap.values().stream()
					.forEach(executorList -> TableDefinitionUtils.rollBackExecutor(executorList));
			TableDefinitionUtils.rollBackExecutor(queryExecutor);
			throw new CustomException(exception.getMessage());
		}

		logger.info("processWholePackagingRequest method execution ends");
		resultMap.put(STATUS, status);
		return resultMap;
	}

	/**
	 * foreignAddForWholePackaging added for whole packaging
	 * 
	 * @param productCode
	 * @param foreignExecutorMap
	 * @param foreignCreateMap
	 * @throws QueryException
	 */
	@SuppressWarnings("unchecked")
	private void foreignAddForWholePackaging(String productCode, Map<String, QueryExecutor> foreignExecutorMap,
			Map<String, List<Map<String, Object>>> foreignCreateMap) throws QueryException {
		for (Entry<String, List<Map<String, Object>>> foreignMap : foreignCreateMap.entrySet()) {
			List<ForeignKeyTableReferenceEntity> foreignKeyTableReferenceEntityList = new ArrayList<>();
			foreignMap.getValue().forEach(foreignKeyDetails -> {
				ForeignKeyTableReferenceEntity foreignKeyTableReferenceEntity = new ForeignKeyTableReferenceEntity();
				List<ForeignKeyColumnReferenceEntity> foreignKeyColumnReferenceEntityList = new ArrayList<>();
				try {
					for (Map.Entry<String, String> entry : ((Map<String, String>) JsonUtils
							.fromJsonOrThrow(((PGobject) foreignKeyDetails
									.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
											+ ".foreignKeyColumnDetails")).getValue(),
									Map.class)).entrySet()) {
						ForeignKeyColumnReferenceEntity foreignKeyColumnReferenceEntity = new ForeignKeyColumnReferenceEntity();
						foreignKeyColumnReferenceEntity.setLocalColumnName(entry.getKey());
						foreignKeyColumnReferenceEntity.setReferenceColumnName(entry.getValue());
						foreignKeyColumnReferenceEntityList.add(foreignKeyColumnReferenceEntity);
					}
				} catch (JsonConversionException exception) {
					logger.error(exception);
				}
				foreignKeyTableReferenceEntity.setcolumnList(foreignKeyColumnReferenceEntityList);
				foreignKeyTableReferenceEntity.setconstraintName(String.valueOf(foreignKeyDetails
						.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".foreignKeyName")));
				foreignKeyTableReferenceEntity.setMatchType(MatchEnum.SIMPLE);
				foreignKeyTableReferenceEntity.setOnDelete(OnchangeActionEnum.NO_ACTION);
				foreignKeyTableReferenceEntity.setOnUpdate(OnchangeActionEnum.NO_ACTION);
				foreignKeyTableReferenceEntity.setreferenceTableName(String.valueOf(foreignKeyDetails
						.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".referenceTable")));
				foreignKeyTableReferenceEntityList.add(foreignKeyTableReferenceEntity);
			});
			QueryExecutor alterExecutor = foreignExecutorMap.get(foreignMap.getKey());
			alterExecutor.queryBuilder().table().alterTable().table(foreignMap.getKey()).setProductCode(productCode)
					.foreignKeyConstraintChange(foreignKeyTableReferenceEntityList).build().execute();
		}
	}

	/**
	 * errorMessageForDataDefinition method used for error method for data format
	 * definition
	 * 
	 * @param resultMap
	 * @param validDataElement
	 * @param validDataClass
	 * @throws QueryException
	 */
	private void errorMessageForDataDefinition(Map<String, Object> resultMap, List<Object> validDataElement,
			List<Object> validDataClass) throws QueryException {
		logger.info("errorMessageForDataDefinition method starts");
		StringBuilder errorMessageString = new StringBuilder("");
		if (!validDataElement.isEmpty()) {
			errorMessageString.append(String.format(
					CacheService.getInstance().getApplicationTextDefinitionData(
							"nn_table_definition_invalid-dataelemennt-details", SCREEN_DEF_ID, ContextBean.getLocale()),
					Arrays.toString(validDataElement.toArray()).replace("[", "").replace("]", "")));
			errorMessageString.append("\n");
		}
		if (!validDataClass.isEmpty()) {
			errorMessageString.append(String.format(
					CacheService.getInstance().getApplicationTextDefinitionData(
							"nn_table_definition_invalid-dataformat-details", SCREEN_DEF_ID, ContextBean.getLocale()),
					Arrays.toString(validDataClass.toArray()).replace("[", "").replace("]", "")));
		}
		resultMap.put(MESSAGE, errorMessageString);
		logger.info("errorMessageForDataDefinition method ends" + resultMap);
	}

	/**
	 * getUpdateColumnKeys used for upsert updateColumnList get
	 * 
	 * @param insertMap contains key for upsert values
	 * @param tableName
	 * @return updateColumnList
	 */
	List<String> getUpdateColumnKeys(Map<String, Object> insertMap, String tableName) {
		logger.info("getUpdateColumnKeys method execution started.");
		List<String> updateColumnList = insertMap.keySet().stream().filter(predicate -> predicate.startsWith(tableName))
				.map(tableKey -> tableKey.split("\\.")[1]).collect(Collectors.toList());
		logger.info("getUpdateColumnKeys method execution ended.");
		return updateColumnList;
	}

	/**
	 * compareTableDefinitionData used to compare the table definition data.
	 * 
	 * @param tableDefinitionDetails
	 * @param updatedTableDefinitionDetails
	 * @param dataMap
	 */
	private void compareTableDefinitionData(Map<String, Object> tableDefinitionDetails,
			Map<String, Object> updatedTableDefinitionDetails, Map<String, Map<String, Object>> dataMap) {
		logger.info("compareTableDefinitionData method starts...");
		processTableDefinitionData(tableDefinitionDetails, updatedTableDefinitionDetails, dataMap,
				DataDefinitionConstants.TABLE_DEFINITION);
		logger.info("compareTableDefinitionData method ends...");
	}

	/**
	 * processTableDefinitionData used to prepare the data based on the operation.
	 * 
	 * @param tableDefinitionDetails
	 * @param updatedTableDefinitionDetails
	 * @param dataMap
	 * @param tableName
	 */
	@SuppressWarnings("unchecked")
	private void processTableDefinitionData(Map<String, Object> tableDefinitionDetails,
			Map<String, Object> updatedTableDefinitionDetails, Map<String, Map<String, Object>> dataMap,
			String tableName) {
		logger.info("processTableDefinitionData method starts...");
		List<Object> dropList = new ArrayList<>();
		List<Object> createList = new ArrayList<>();
		List<Object> alterList = new ArrayList<>();
		Map<String, Object> detailMap = new HashMap<>();
		List<Map<String, Object>> oldTableDefinitionData = (List<Map<String, Object>>) tableDefinitionDetails
				.get(tableName);
		List<Map<String, Object>> newTableDefinitionData = (List<Map<String, Object>>) updatedTableDefinitionDetails
				.get(tableName);
		if (oldTableDefinitionData.isEmpty() && newTableDefinitionData.size() == 1) {
			createList.add(tableName);
		} else if (oldTableDefinitionData.size() == 1 && newTableDefinitionData.size() == 1) {
			alterList.add(tableName);
		} else if ((oldTableDefinitionData.size() == 1 && newTableDefinitionData.isEmpty())) {
			dropList.add(tableName);
		} else if ((oldTableDefinitionData.isEmpty() && newTableDefinitionData.isEmpty())) {
			logger.info("create and delete in same request.");
		}
		detailMap.put(CREATE, createList);
		detailMap.put(ALTER, alterList);
		detailMap.put("drop", dropList);
		logger.info("createList " + createList);
		logger.info("alterList " + alterList);
		logger.info("dropList " + dropList);
		dataMap.put(tableName, detailMap);
		logger.info("processTableDefinitionData method ends...");
	}

	/**
	 * compareDataElements used to compare the data elements before and after the cr
	 * execution.
	 * 
	 * @param updatedTableDefinitionDetails
	 * @param queryExecutor
	 * @param tableNameList
	 * @return boolean
	 * @throws CustomException
	 */
	@SuppressWarnings("unchecked")
	private List<Object> compareDataElements(Map<String, Object> updatedTableDefinitionDetails,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("compareDataElements method starts...");
		List<Map<String, Object>> tableDefinitionData = (List<Map<String, Object>>) updatedTableDefinitionDetails
				.get(DataDefinitionConstants.TABLE_DEFINITION);
		List<Object> tableNameList = tableDefinitionData.stream()
				.map(mapper -> mapper.get(DataDefinitionConstants.TABLE_NAME)).distinct().collect(Collectors.toList());
		ConditionBuilder condition = ConditionBuilder.instance()
				.inWithList(DataDefinitionConstants.TABLE_NAME, tableNameList).and()
				.brackets(ConditionBuilder.instance().isNotNull(DataDefinitionConstants.DATA_ELEMENT));
		List<Map<String, Object>> tableDefinitionColumnDetails = getDataList(
				DataDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS, condition, queryExecutor);
		if (!tableDefinitionColumnDetails.isEmpty()) {
			List<Object> dataElementsFromTableDefinition = tableDefinitionColumnDetails.stream()
					.map(mapper -> mapper.get(DataDefinitionConstants.DATA_ELEMENT)).distinct()
					.collect(Collectors.toList());
			ConditionBuilder dataElementCondition = ConditionBuilder.instance()
					.inWithList(DataDefinitionConstants.DATA_ELEMENT, dataElementsFromTableDefinition);
			List<Map<String, Object>> dataElementList = getDataList(DataDefinitionConstants.DATA_ELEMENT_DEFINITION,
					dataElementCondition, queryExecutor);
			List<Object> dataElements = dataElementList.stream()
					.map(mapper -> mapper.get(DataDefinitionConstants.DATA_ELEMENT)).collect(Collectors.toList());
			logger.info("compareDataElements method ends...");
			if (dataElementsFromTableDefinition.size() == dataElements.size()) {
				return new ArrayList<>();
			} else {
				return dataElementsFromTableDefinition.stream().filter(predicate -> !dataElements.contains(predicate))
						.collect(Collectors.toList());
			}
		} else {
			return new ArrayList<>();
		}
	}

	/**
	 * compareDataClass used to compare the data class before and after the cr
	 * execution.
	 * 
	 * @param updatedTableDefinitionDetails
	 * @param queryExecutor
	 * @param tableNameList
	 * @return boolean
	 * @throws CustomException
	 */
	@SuppressWarnings("unchecked")
	private List<Object> compareDataClass(Map<String, Object> updatedTableDefinitionDetails,
			QueryExecutor queryExecutor) throws CustomException {
		logger.info("compareDataClass method starts...");
		List<Map<String, Object>> tableDefinitionData = (List<Map<String, Object>>) updatedTableDefinitionDetails
				.get(DataDefinitionConstants.TABLE_DEFINITION);
		List<Object> tableNameList = tableDefinitionData.stream()
				.map(mapper -> mapper.get(DataDefinitionConstants.TABLE_NAME)).distinct().collect(Collectors.toList());
		ConditionBuilder condition = ConditionBuilder.instance()
				.inWithList(DataDefinitionConstants.TABLE_NAME, tableNameList).and()
				.brackets(ConditionBuilder.instance().eq(DataDefinitionConstants.DATA_ELEMENT, "").or()
						.isNotNull(DataDefinitionConstants.DATA_ELEMENT));
		List<Map<String, Object>> tableDefinitionColumnDetails = getDataList(
				DataDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS, condition, queryExecutor);
		if (!tableDefinitionColumnDetails.isEmpty()) {
			List<Object> dataFormatFromTableDefinition = tableDefinitionColumnDetails.stream()
					.map(mapper -> mapper.get(DataDefinitionConstants.DATA_FORMAT)).distinct()
					.collect(Collectors.toList());
			ConditionBuilder dataFormatCondition = ConditionBuilder.instance()
					.inWithList(DataDefinitionConstants.DATA_FORMAT, dataFormatFromTableDefinition);
			List<Map<String, Object>> dataFormatList = getDataList(DataDefinitionConstants.DATA_FORMAT_DEFINITION,
					dataFormatCondition, queryExecutor);
			List<Object> dataFormat = dataFormatList.stream()
					.map(mapper -> mapper.get(DataDefinitionConstants.DATA_FORMAT)).collect(Collectors.toList());
			logger.info("compareDataClass method ends...");
			if (dataFormatFromTableDefinition.size() == dataFormat.size())
				return new ArrayList<>();
			else
				return dataFormatFromTableDefinition.stream().filter(predicate -> !dataFormat.contains(predicate))
						.collect(Collectors.toList());
		} else {
			return new ArrayList<>();
		}
	}

	/**
	 * processDataDefinitionAfterCrExecution used to process the data definition
	 * after cr execution.
	 * 
	 * @param dataMap
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> processDataDefinitionAfterCrExecution(Map<String, Object> dataMap) {
		logger.info("processDataDefinitionAfterCrExecution method starts..." + dataMap);
		Map<String, Object> resultMap = new HashMap<>();
		boolean status = true;
		QueryExecutor queryExecutor = null;
		try {
			queryExecutor = (QueryExecutor) dataMap.get(BT_EXECUTOR);
			queryExecutor.skipChangeRequest(true);
			String changeRequestId = String.valueOf(dataMap.get(CHANGE_REQUEST_ID));
			Map<String, List<Map<String, Object>>> oldDataDefinitionList = (Map<String, List<Map<String, Object>>>) dataMap
					.get("dataDefinitionList");
			Map<String, List<Object>> oldPrimaryKeyMap = getPrimaryKeyMap(oldDataDefinitionList);
			Map<String, List<Object>> upsertDataMap = (Map<String, List<Object>>) dataMap.get("upsertDataMap");
			if (dataMap.containsKey(DELETE_PRIMARY_KEY_MAP)) {
				Map<String, List<Object>> deleteDataMap = (Map<String, List<Object>>) dataMap
						.get(DELETE_PRIMARY_KEY_MAP);
				Map<String, List<Object>> deleteErrorMap = new HashMap<>();
				validateDeleteData(deleteDataMap, deleteErrorMap, queryExecutor);
				if (!deleteErrorMap.isEmpty()) {
					queryExecutor.rollBack();
					processResult(resultMap, new HashMap<>(), deleteErrorMap);
					logger.info("processDataDefinitionAfterCrExecution method ends..." + resultMap);
					return resultMap;
				}
			}
			Map<String, List<Map<String, Object>>> newDataDefinitionList = getDataDefinitionList(upsertDataMap,
					queryExecutor);
			queryExecutor.commit();
			Map<String, List<Object>> newPrimaryKeyMap = getPrimaryKeyMap(newDataDefinitionList);
			List<Object> dataElementList = new ArrayList<>();
			List<Object> dataFormatList = new ArrayList<>();
			if (oldPrimaryKeyMap.containsKey(DataDefinitionConstants.DATA_ELEMENT)
					&& newPrimaryKeyMap.containsKey(DataDefinitionConstants.DATA_ELEMENT)) {
				List<Object> oldKeyList = oldPrimaryKeyMap.get(DataDefinitionConstants.DATA_ELEMENT);
				List<Object> newKeyList = newPrimaryKeyMap.get(DataDefinitionConstants.DATA_ELEMENT);
				oldKeyList.stream().forEach(action -> {
					if (newKeyList.contains(action)) {
						dataElementList.add(action);
					}
				});
			}
			if (oldPrimaryKeyMap.containsKey(DataDefinitionConstants.DATA_FORMAT)
					&& newPrimaryKeyMap.containsKey(DataDefinitionConstants.DATA_FORMAT)) {
				List<Object> oldKeyList = oldPrimaryKeyMap.get(DataDefinitionConstants.DATA_FORMAT);
				List<Object> newKeyList = newPrimaryKeyMap.get(DataDefinitionConstants.DATA_FORMAT);
				oldKeyList.stream().forEach(action -> {
					if (newKeyList.contains(action)) {
						dataFormatList.add(action);
					}
				});
			}
			if (CollectionUtils.isNotEmpty(dataElementList)) {
				List<Map<String, Object>> tableDetailList = DataDefinitionCommonUtils
						.getTableNameListByDataElement(dataElementList);
				updateTableDefinitionData(tableDetailList, TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN,
						dataElementList, changeRequestId, dataMap);
			}
			if (CollectionUtils.isNotEmpty(dataFormatList)) {
				List<Map<String, Object>> tableDetailList = DataDefinitionCommonUtils
						.getTableNameListByDataClass(dataFormatList);
				if (dataMap.containsKey(TABLE_PROCESSED_LIST)) {
					List<Object> tableProcessedList = (List<Object>) dataMap.get(TABLE_PROCESSED_LIST);
					tableDetailList = tableDetailList.stream()
							.filter(predicate -> !tableProcessedList
									.contains(predicate.get(TABLE_NAME).toString() + predicate.get(PRODUCT_CODE)))
							.collect(Collectors.toList());
				}
				updateTableDefinitionData(tableDetailList, TableDefinitionConstants.DATA_FORMAT_DEFINTION_MAIN,
						dataFormatList, changeRequestId, dataMap);
			}
			if (dataMap.containsKey(REPO_MAP_DETAILS)) {
				ChangeRequest.updateCrRepo(changeRequestId, (Map<String, Object>) dataMap.get(REPO_DETAILS_MAP), true,
						true);
				Map<String, Object> updateCrMap = new HashMap<>();
				((Map<String, Object>) dataMap.get(REPO_MAP_DETAILS)).forEach((key, value) -> {
					Map<String, Object> createMap = new HashMap<>();
					createMap.put(CREATE_LIST, value);
					updateCrMap.put(key, createMap);
				});
//				TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(updateCrMap, changeRequestId);
			} else {
				ChangeRequest.updateCrRepo(changeRequestId, new HashMap<>(), true, true);
			}
			resultMap.put(NOCHANGE, !dataMap.containsKey("sourceGeneratedKey"));
		} catch (Exception exception) {
			DataDefinitionCommonUtils.executeRollback(queryExecutor);
			logger.error("Exception in data process after cr execution. " + exception);
			resultMap.put(MESSAGE, exception.getMessage());
			status = false;
		}
		resultMap.put(STATUS, status);
		logger.info("processDataDefinitionAfterCrExecution method ends..." + resultMap);
		return resultMap;
	}

	/**
	 * getPrimaryKeyMap used to get the primary key map based on the table name.
	 * 
	 * @param dataDefinitionList
	 * @return Map
	 */
	private Map<String, List<Object>> getPrimaryKeyMap(Map<String, List<Map<String, Object>>> dataDefinitionList) {
		logger.info("getPrimaryKeyMap method starts...");
		Map<String, List<Object>> primaryKeyMap = new HashMap<>();
		dataDefinitionList.entrySet().stream().forEach(action -> {
			String key = getPrimaryKey(action.getKey());
			List<Object> primaryKeyList = action.getValue().stream().map(mapper -> mapper.get(key))
					.collect(Collectors.toList());
			primaryKeyMap.put(key, primaryKeyList);
		});
		logger.info("getPrimaryKeyMap method ends...");
		return primaryKeyMap;
	}

	/**
	 * updateTableDefinitionData used to update the table definition data when data
	 * class of the data element changed or element type, data type, max decimal,
	 * precision changed for data class.
	 * 
	 * @param tableDetailList
	 * @param sourceTable
	 * @param primaryKeyList
	 * @param changeRequestId
	 * @param dataMap
	 */
	@SuppressWarnings("unchecked")
	public static void updateTableDefinitionData(List<Map<String, Object>> tableDetailList, String sourceTable,
			List<Object> primaryKeyList, String changeRequestId, Map<String, Object> dataMap) {
		logger.info("updateTableDefinitionData method starts...");
		List<Object> tableProcessedList = new ArrayList<>();

		List<Map<String, Object>> sourceCodeGenerateTableList = new ArrayList<>();
		tableDetailList.stream().forEach(action -> {
			Map<String, Object> detailMap = new HashMap<>();
			tableProcessedList.add(action.get(TABLE_NAME).toString() + action.get(PRODUCT_CODE));
			detailMap.put(TableDefinitionConstants.TABLENAME, action.get(TABLE_NAME));
			detailMap.put(TableDefinitionConstants.PRODUCT_CODE, action.get(PRODUCT_CODE));
			detailMap.put(sourceTable, primaryKeyList);
			 new DataDefinitionUtils().alterFromDataElements(detailMap);
		});
		dataMap.put(TABLE_PROCESSED_LIST, tableProcessedList);
		List<Map<String, Object>> updateList = new ArrayList<>();
		List<ConditionBuilder> conditionBuilderList = new ArrayList<>();
		if (dataMap.containsKey(GENERATE_SOURCE) && (boolean) dataMap.get(GENERATE_SOURCE)
				&& !sourceCodeGenerateTableList.isEmpty() && !changeRequestId.isEmpty()) {
			dataMap.put("sourceGeneratedKey", true);
			List<String> productCodeList = new ArrayList<>();
			Map<String, Object> repoMap;
			if (dataMap.containsKey(REPO_MAP_DETAILS)) {
				repoMap = (Map<String, Object>) dataMap.get(REPO_MAP_DETAILS);
			} else {
				repoMap = new HashMap<>();
			}
			Map<String, Object> repoDetails;
			if (dataMap.containsKey(REPO_DETAILS_MAP)) {
				repoDetails = (Map<String, Object>) dataMap.get(REPO_DETAILS_MAP);
			} else {
				repoDetails = new HashMap<>();
			}
			sourceCodeGenerateTableList.forEach(sourceMap -> {
				String tableName = String.valueOf(sourceMap.get(TableDefinitionConstants.TABLENAME));
				String productCode = String.valueOf(sourceMap.get(TableDefinitionConstants.PRODUCT_CODE));
				try {
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(IS_SOURCE_CODE_ONLY, true);
					resultMap.put(PRODUCT_CODE2, productCode);
					resultMap.put(VIEW_OBJECT, tableName);
					if (productCodeList.contains(productCode)) {
						resultMap.put("noDelete", true);
					}
//					new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//							new QueryBuilder());
					conditionBuilderList.add(
							ConditionBuilder.instance().eq(TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode));
					Map<String, Object> updateMap = new HashMap<>();
					updateMap.put("tableDefinition.status", TableTypeEnum.INPROGRESS.name());
					updateList.add(updateMap);
//					TableDefinitionCommonUtils.insertClassConfig(String.valueOf(resultMap.get("packageName")),
//							changeRequestId, tableName, productCode);
					productCodeList.add(productCode);
					if (repoDetails.containsKey(productCode)) {
						List<String> repoName = (List<String>) repoDetails.get(productCode);
						if (!repoName.contains(resultMap.get(REPO_NAME))) {
							repoName.add(String.valueOf(resultMap.get(REPO_NAME)));
							repoDetails.put(productCode, repoName);
						}
					} else {
						List<String> repoName = new ArrayList<>();
						repoName.add(String.valueOf(resultMap.get(REPO_NAME)));
						repoDetails.put(productCode, repoName);
					}

					if (repoMap.containsKey(resultMap.get(REPO_NAME))) {
						List<String> tableNameList = (List<String>) repoMap.get(resultMap.get(REPO_NAME));
						tableNameList.add(tableName);
						repoMap.put(String.valueOf(resultMap.get(REPO_NAME)), tableNameList);
					} else {
						List<String> tableNameList = new ArrayList<>();
						tableNameList.add(tableName);
						repoMap.put(String.valueOf(resultMap.get(REPO_NAME)), tableNameList);
					}
				} catch (Exception exception) {
					DataDefinitionCommonUtils.inactiveStateMove(Arrays.asList(tableName), exception.getMessage(), null,
							"", productCode);
				}
			});
			try {
				if (!repoMap.isEmpty()) {
					dataMap.put(REPO_MAP_DETAILS, repoMap);
					dataMap.put(REPO_DETAILS_MAP, repoDetails);
					new QueryBuilder().update().skipChangeRequest(true).batchUpdate(TABLE_DEFINITION, updateList,
							conditionBuilderList);
				}
			} catch (Exception exception) {
				logger.error(exception);
				logger.info("exception at call change request" + exception.getMessage());
			}
		}
		logger.info("updateTableDefinitionData method ends...");
	}
}
