package com.nn.sova.service.dao.wizard;

import java.util.List;
import java.util.Map;

/**
 * WizardDao interface
 * 
 * @author Vivek Kannan E
 */
public interface WizardDao {

	List<Map<String, Object>> getData(String wizardId);

	Map<String, Object> getData(String wizardId, String wizardDialogId);

}