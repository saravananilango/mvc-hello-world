package com.nn.sova.service.jobmanager.dao;

import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_EXTERNAL_JAR;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_VIEW;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_TYPE;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.jobmanager.entity.AbsJobDefinition;
import com.nn.sova.service.jobmanager.entity.JobDefinitionApi;
import com.nn.sova.service.jobmanager.entity.JobDefinitionExternalJar;
import com.nn.sova.service.jobmanager.entity.JobDefinitionFrameworkJar;
import com.nn.sova.utility.jobmanager.constants.JobType;
import com.nn.sova.utility.jobmanager.utils.JobManagerUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;


/**
 * The Interface {@link JobDefinitionDao} for accessing job definition tables.
 *
 * @param <T> the generic type
 * 
 * @author praveen_kumar_nr
 */
public interface JobDefinitionDao<T extends AbsJobDefinition> {

	ApplicationLogger LOGGER = ApplicationLogger
		.create(JobDefinitionDao.class);

	/**
	 * Gets the framework jar dao.
	 *
	 * @return the framework jar dao
	 */
	public static JobDefinitionDao<JobDefinitionFrameworkJar> getFrameworkJarDao() {
		return JobDefinitionDaoFactory.FRAMEWORK_JAR_DAO;
	}

	/**
	 * Gets the external jar dao.
	 *
	 * @return the external jar dao
	 */
	public static JobDefinitionDao<JobDefinitionExternalJar> getExternalJarDao() {
		return JobDefinitionDaoFactory.EXTERNAL_JAR_DAO;
	}

	/**
	 * Gets the api dao.
	 *
	 * @return the api dao
	 */
	public static JobDefinitionDao<JobDefinitionApi> getApiDao() {
		return JobDefinitionDaoFactory.API_DAO;
	}

	/**
	 * A factory for creating JobDefinitionDao objects.
	 */
	static class JobDefinitionDaoFactory {

		/**
		 * Instantiates a new job definition dao factory.
		 */
		private JobDefinitionDaoFactory() {
			// should not use outside this scope
		}

		/** The Constant FRAMEWORK_JAR_DAO. */
		private static final JobDefinitionDao<JobDefinitionFrameworkJar> FRAMEWORK_JAR_DAO
			= new JobDefinitionFrameworkJarDao();

		/** The Constant EXTERNAL_JAR_DAO. */
		private static final JobDefinitionDao<JobDefinitionExternalJar> EXTERNAL_JAR_DAO
			= new JobDefinitionExternalJarDao();

		/** The Constant API_DAO. */
		private static final JobDefinitionDao<JobDefinitionApi> API_DAO
			= new JobDefinitionApiDao();

	}

	/**
	 * Select.
	 *
	 * @param jobDefId the job def id
	 * @return the optional
	 */
	Optional<T> select(String jobDefId);

	/**
	 * Select.
	 *
	 * @param offset the offset
	 * @param limit  the limit
	 * @return the list
	 */
	default List<T> select(int offset, int limit) {
		return select(null, offset, limit);
	}

	/**
	 * Select.
	 *
	 * @param searchKeyWord the search key word
	 * @param offset        the offset
	 * @param limit         the limit
	 * @return the list
	 */
	List<T> select(String searchKeyWord, int offset, int limit);

	/**
	 * Upsert.
	 * 
	 *
	 * @param jobDefinition the job definition
	 * @param isSkipChangeRequest for appGen to skip change request when update record. 
	 * @return the string
	 * @throws QueryException          the query exception
	 * @throws JsonConversionException the json conversion exception
	 */
	String upsert(T jobDefinition, QueryExecutor executor, boolean isSkipChangeRequest) throws QueryException, JsonConversionException;
	
	/**
	 * Upsert.
	 *
	 * @param jobDefinition the job definition
	 * @return the string
	 * @throws QueryException          the query exception
	 * @throws JsonConversionException the json conversion exception
	 */
	default String upsert(T jobDefinition) throws QueryException, JsonConversionException {
		return upsert(jobDefinition, null, true);
	}

	/**
	 * Select.
	 *
	 * @param jobDefId the job def id
	 * @param jobType  the job type
	 * @return the optional
	 */
	static Optional<AbsJobDefinition> select(String jobDefId, JobType jobType) {
		Objects.requireNonNull(jobType, "jobType is required");
		Objects.requireNonNull(jobDefId, "jobDefId is required");
		try {
			return select(ConditionBuilder.instance()
				.eq(JOB_DEF_ID, jobDefId)
				.and().eq(JOB_TYPE, jobType.getValue()))
					.values()
					.stream()
					.findFirst();
		} catch (Exception exception) {
			LOGGER.error("Failed to select job definition for "
				+ "jobDefId={}, jobType={}, error = {}",
				jobDefId, jobType, exception.getMessage());
			return Optional.empty();
		}
	}

	/**
	 * Select from job_definition_view.
	 *
	 * @param jobDefIdList the job def id list
	 * @return the list
	 * @throws QueryException the query exception
	 */
	static Map<String, AbsJobDefinition> select(String... jobDefIds)
		throws QueryException {
		if (jobDefIds == null || jobDefIds.length <= 0) {
			return Collections.emptyMap();
		}
		return select(JobManagerUtils.toList(jobDefIds));
	}

	/**
	 * Select.
	 *
	 * @param jobDefIdList the job def id list
	 * @return the map
	 * @throws QueryException the query exception
	 */
	static Map<String, AbsJobDefinition> select(List<String> jobDefIdList)
		throws QueryException {
		if (CollectionUtils.isEmpty(jobDefIdList)) {
			return Collections.emptyMap();
		}
		List<Object> jobDefIdDistinctList = jobDefIdList.stream()
			.distinct().collect(Collectors.toList());
		return select(ConditionBuilder.instance()
			.inWithList(JOB_DEF_ID, jobDefIdDistinctList));
	}

	/**
	 * Select.
	 *
	 * @param jobType   the job type
	 * @param jobDefIds the job def id list
	 * @return the map
	 * @throws QueryException the query exception
	 */
	static Map<String, AbsJobDefinition> select(JobType jobType, String... jobDefIds)
		throws QueryException {
		Objects.requireNonNull(jobType, "jobType is required");
		if (jobDefIds == null || jobDefIds.length <= 0) {
			return Collections.emptyMap();
		}
		List<Object> jobDefIdDistinctList = JobManagerUtils.toList(jobDefIds)
			.stream().distinct().collect(Collectors.toList());
		return select(ConditionBuilder.instance()
			.inWithList(JOB_DEF_ID, jobDefIdDistinctList)
			.and().eq(JOB_TYPE, jobType.getValue()));
	}

	/**
	 * Select.
	 *
	 * @param whereCondition the where condition
	 * @return the map
	 * @throws QueryException the query exception
	 */
	private static Map<String, AbsJobDefinition> select(ConditionBuilder whereCondition)
		throws QueryException {
		Objects.requireNonNull(whereCondition, "WHERE Condition is required");
		try {
			return new QueryBuilder()
				.select()
				.from(JOB_DEFINITION_VIEW)
				.where(whereCondition)
				.build(false)
				.execute()
				.stream()
				.map(AbsJobDefinition::from)
				.collect(Collectors.toMap(AbsJobDefinition::getJobDefId, Function.identity()));
		} catch (QueryException queryException) {
			LOGGER.error("Failed to select job definition from {} table, error = {}",
				JOB_DEFINITION_EXTERNAL_JAR,
				queryException.getMessage());
			throw queryException;
		}
	}

}
