package com.nn.sova.service.jobmanager.entity;

import static com.nn.sova.utility.jobmanager.JobManagerComponent.toJson;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JAR_FILE_NAME;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_CALLBACK_URLS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_EXTERNAL_JAR;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_MAJOR_VERSION;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_MINOR_VERSION;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_PARAMETERS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_PATCH_VERSION;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.MAIN_CLASS;

import java.util.List;
import java.util.Map;

import com.nn.sova.utility.jobmanager.entity.JobCallbackUrl;
import com.nn.sova.utility.jobmanager.entity.JobParameters;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * The Class {@code JobDefinitionExternalJar} represents a row in
 * {@code job_definiton_external_jar} table.
 *
 * @author praveen_kumar_nr
 */
@Data
@EqualsAndHashCode(of = { "majorVersion", "minorVersion", "patchVersion" }, callSuper = true)
@ToString(callSuper = true)
public final class JobDefinitionExternalJar extends AbsJobDefinition {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The major version. */
	private int majorVersion;

	/** The minor version. */
	private int minorVersion;

	/** The patch version. */
	private int patchVersion;

	/** The main class. */
	private String mainClass;

	/** The job parameters. */
	private JobParameters jobParameters;

	/** The job callback urls. */
	private List<JobCallbackUrl> jobCallbackUrls;

	/** The jar file name. */
	private String jarFileName;

	/**
	 * Instantiates a new job definition external jar.
	 */
	public JobDefinitionExternalJar() {
		super(JOB_DEFINITION_EXTERNAL_JAR);
	}

	/**
	 * Instantiates a new {@code JobDefinitionExternalJar} from a map.
	 *
	 * @param dataMap the data map
	 */
	public JobDefinitionExternalJar(Map<String, Object> dataMap) {
		super(JOB_DEFINITION_EXTERNAL_JAR, dataMap);
		this.majorVersion = (int)dataMap.get(JOB_MAJOR_VERSION);
		this.minorVersion = (int)dataMap.get(JOB_MINOR_VERSION);
		this.patchVersion = (int)dataMap.get(JOB_PATCH_VERSION);
		this.mainClass = (String)dataMap.get(MAIN_CLASS);
		this.jobParameters = JobParameters.from(dataMap.get(JOB_PARAMETERS));
		this.jobCallbackUrls = JobCallbackUrl.from(dataMap.get(JOB_CALLBACK_URLS));
		this.jarFileName = (String)dataMap.get(JAR_FILE_NAME);
	}

	@Override
	public Map<String, Object> toInsertMap() {
		Map<String, Object> insertDataMap = super.toInsertMap();
		insertDataMap.put(getInsertKey(JOB_MAJOR_VERSION), getMajorVersion());
		insertDataMap.put(getInsertKey(JOB_MINOR_VERSION), getMinorVersion());
		insertDataMap.put(getInsertKey(JOB_PATCH_VERSION), getPatchVersion());
		insertDataMap.put(getInsertKey(MAIN_CLASS), getMainClass());
		insertDataMap.put(getInsertKey(JOB_PARAMETERS), toJson(getJobParameters()));
		insertDataMap.put(getInsertKey(JOB_CALLBACK_URLS), toJson(getJobCallbackUrls()));
		insertDataMap.put(getInsertKey(JAR_FILE_NAME), getJarFileName());
		return insertDataMap;
	}

	@Override
	public String getVersion() {
		return String.format("%d.%d.%d",
			this.majorVersion,
			this.minorVersion,
			this.patchVersion);
	}

}
