package com.nn.sova.service.service.helpmaster;

import java.util.Map;

/**
 * helpMasterService interface
 * 
 * @author Sakthivel
 */
public interface HelpMasterService {

	Map<String,Object> getHelpMasterData(String screenId);
	
	Map<String,Object> getHelpMasterData(String screenId, String helpMasterId);
	
    String deleteCacheByKey(String screenId);
   
    String deleteAllCache();

}
