package com.nn.sova.service.controller;

import java.util.List;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.utility.context.ContextBean;

/**
 * ComponentAttributeController class is common controller for component
 * Template.
 *
 * @author Logchand, Vivek Kannan
 * 
 */
public abstract class ComponentAttributeController extends CommonController {

	/**
	 * Gets the component element data.
	 * 
	 * @param screenDefType the screen definition type
	 * @param key              the component key to be appended in cacheKey
	 *
	 * @return the component element data
	 * @throws QueryException the query exception
	 */
	public List<FrontVo> getComponentElementData(String screenDefType, String key) throws QueryException {
		CacheService cacheService = CacheService.getInstance();
		String locale = ContextBean.getLocale();
		List<FrontVo> elementList = frontVoConverter(
				cacheService.getDataElementByScreenDefType(screenDefType, key, locale));
		return elementList;
	}
}
