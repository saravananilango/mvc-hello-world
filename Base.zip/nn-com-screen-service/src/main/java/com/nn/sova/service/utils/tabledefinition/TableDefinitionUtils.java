package com.nn.sova.service.utils.tabledefinition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.UpdateQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.constants.tabledefinition.DataDefinitionConstants;
import com.nn.sova.service.constants.tabledefinition.MessageEntriesConstants;
import com.nn.sova.service.constants.tabledefinition.TableDefinitionConstants;
import com.nn.sova.service.enums.TableTypeEnum;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.util.entity.DropViewEntity;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.helper.TokenManipulation;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;
/**
 * TableDefinitionUtils for table definition common changes
 * @author mohanram
 *
 */
public class TableDefinitionUtils {
	/**
	 * logger for TableDefinitionUtils class
	 */
	private static ApplicationLogger logger = ApplicationLogger.create(TableDefinitionUtils.class);
	private static final String DATA_FORMAT2 = ".dataFormat";
	private static final String DATA_ELEMENT2 = ".dataElement";
	private static final String SERIAL_NUMBER2 = ".serialNumber";
	private static final String SERIAL_NUMBER = "serial_number";
	private static final String COLUMN_NAME = ".columnName";
	private static final String TABLE_NAME = ".tableName";
	private static final String TENANT_ID2 = ".tenantId";
	private static final String TENANT_ID = "tenant_id";
	private static final String PRODUCT_CODE2 = ".productCode";
	private static final String IP_ADDRESS = "ip_address";
	private static final String DATABASE_PASSWORD = "database_password";
	private static final String DATABASE_NAME = "database_name";
	private static final String DATABASE_USERNAME = "database_username";
	private static final String DATABASE_SCHEMA = "database_schema";
	private static final String DATABASE_HANDLER2 = "database_handler";
	private static final String DATABASE_HANDLER = ".databaseHandler";
	private static final String VERSION_NO2 = ".versionNo";
	private static final String VIEW_OBJECT_NAME = "view_object_name";
	private static final String STATUS = "status";
	private static final String CHANGE_REQUEST_ID = "changeRequestId";
	private static final String COUNT = "count";
	private static final String DATA_ELEMENT = "data_element";
	private static final String DATA_FORMAT = "data_format";
	private static final String DATA_TYPE = "data_type";
	private static final String DESCRIPTION = "description";
	private static final String VERSION_NO = "version_no";
	private static final String SUB_PRODUCT_CODE = "sub_product_code";
	private static final String API_NAME = "api_name";
	private static final String PRODUCT_CODE = "product_code";
	private static final String TABLE_DEFINITION = "table_definition";
	private static final String PREVIOUS_REQUEST_ID = ".previousRequestId";
	
	/**
	 * updateProgramBusinessObject program_business_object table update
	 * 
	 * @param tableNameList contains tableNameList to be updated
	 * @throws CustomException
	 */
	public static void updateProgramBusinessObject(List<Object> tableNameList) throws CustomException {
		logger.info("updateProgramBusinessObject method execution started.");
		try {
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put("program_business_object.modified_flag", true);
			updateMap.put("program_business_object.release_flag", true);
			new QueryBuilder().update().skipChangeRequest(true).forceUpdate(true).updateWithMap(
					"program_business_object", updateMap,
					ConditionBuilder.instance().inWithList("business_object_name", tableNameList));
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("updateProgramBusinessObject method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("updateProgramBusinessObject method execution ended.");
	}
	/**
	 * addErrorMessage for all api default error status addition
	 * 
	 * @param returnMap    contains return values for api
	 * @param errorMessage contains error message
	 * @return returnMap
	 */
	public static Map<String, Object> addErrorMessage(Map<String, Object> returnMap, String errorMessage) {
		logger.info("addErrorMessage method execution started.");
		returnMap.put(TableDefinitionConstants.ERROR_KEY, true);
		returnMap.put(TableDefinitionConstants.ERROR_MESSAGE_KEY, errorMessage);
		logger.info("addErrorMessage method execution ended.");
		return returnMap;
	}
	/**
	 * getProductExecutor used for set product executor data base details
	 * 
	 * @param productDetailsMap contains product executor connection details
	 * @return executor that contains details
	 * @throws CustomException
	 */
	public static QueryExecutor getProductExecutor(Map<String, Object> productDetailsMap) throws CustomException {
		logger.info("getProductExecutor method execution started.");
		QueryExecutor tableCreateOrAlterExecutor = null;
		try {
			tableCreateOrAlterExecutor = new QueryBuilder(
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.URL_KEY)),
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.USER)),
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.PASSKEY)),
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.SCHEMA))).getQueryExecutor();
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("getProductExecutor method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("getProductExecutor method execution ended.");
		return tableCreateOrAlterExecutor;
	}

	/**
	 * getApplicationDatabaseDetails used for get database details
	 * 
	 * @param applicationName for which table is to be created
	 * @param databaseHandler contains handler name
	 * @return database details information or error message
	 * @throws CustomException while getting database details
	 */
	public static Map<String, Object> getApplicationDatabaseDetails(String applicationName, String databaseHandler)
			throws CustomException {
		Map<String, Object> databaseDetailsMap = new HashMap<>();
		try {
			logger.info("getApplicationDatabaseDetails method execution started." + applicationName + databaseHandler
					+ EnvironmentReader.getSystemId());
			List<Map<String, Object>> databaseList = new QueryBuilder().btSchema().select()
					.from("system_database_configuration_view")
					.where(ConditionBuilder.instance().eq(PRODUCT_CODE, applicationName).and()
							.eq("handler_name", databaseHandler).and().eq("system_id", EnvironmentReader.getSystemId()))
					.build(false).execute();
			if (databaseList.isEmpty()) {
				logger.info(
						"Database details not found for application name : " + applicationName + ", DatabaseHandler : "
								+ databaseHandler + " and system id : " + EnvironmentReader.getSystemId());
				addErrorMessage(databaseDetailsMap, "Database Details not found.");
				logger.info("getApplicationDatabaseDetails method execution ended");
				return databaseDetailsMap;
			}
			if (!checkMandatoryDatabaseDetails(databaseList.get(0), databaseDetailsMap)) {
				databaseDetailsKeyGenerator(databaseDetailsMap, databaseList);
			}
		} catch (Exception exception) {
			logger.error("Error occured at getProductCodeDetails method " + exception);
			logger.info("getApplicationDatabaseDetails method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("getApplicationDatabaseDetails method execution ended." + databaseDetailsMap);
		return databaseDetailsMap;
	}

	/**
	 * databaseDetailsKeyGenerator for default key getting for database details
	 * 
	 * @param databaseDetailsMap where key value is to be added
	 * @param databaseList       contains database list
	 */
	private static void databaseDetailsKeyGenerator(Map<String, Object> databaseDetailsMap,
			List<Map<String, Object>> databaseList) {
		logger.info("databaseDetailsKeyGenerator method execution started.");
		// need to check postgres db or not
		// will be implemented when key is set
		// now hardcoded
		String dbUrl = TableDefinitionConstants.POSTGRESQL_DB + databaseList.get(0).get(IP_ADDRESS).toString() + ":"
				+ databaseList.get(0).get("port").toString() + "/" + databaseList.get(0).get(DATABASE_NAME).toString();
		databaseDetailsMap.put(TableDefinitionConstants.URL_KEY, dbUrl);
		databaseDetailsMap.put(TableDefinitionConstants.DRIVER_KEY, QueryUtils.getDriver(dbUrl));

		databaseDetailsMap.put(TableDefinitionConstants.USER,
				String.valueOf(databaseList.get(0).get(DATABASE_USERNAME)));
		databaseDetailsMap.put(TableDefinitionConstants.PASSKEY,
				TokenManipulation.decryptToken(String.valueOf(databaseList.get(0).get(DATABASE_PASSWORD))));
		databaseDetailsMap.put(TableDefinitionConstants.SCHEMA,
				String.valueOf(databaseList.get(0).get(DATABASE_SCHEMA)));
		databaseDetailsMap.put(TableDefinitionConstants.DATABASE_NAME,
				String.valueOf(databaseList.get(0).get(DATABASE_NAME)));
		databaseDetailsMap.put(TableDefinitionConstants.HOST, String.valueOf(databaseList.get(0).get(IP_ADDRESS)));
		databaseDetailsMap.put(TableDefinitionConstants.PORT, String.valueOf(databaseList.get(0).get("port")));
		logger.info("databaseDetailsKeyGenerator method execution ended.");
	}

	/**
	 * checkMandatoryDatabaseDetails used database details are present in value from
	 * table
	 * 
	 * @param productDetailsMap  contains database details
	 * @param databaseDetailsMap to put error message
	 * @return true if error or false if all details are present.
	 */
	private static boolean checkMandatoryDatabaseDetails(Map<String, Object> productDetailsMap,
			Map<String, Object> databaseDetailsMap) {
		logger.info("checkMandatoryDatabaseDetails method execution started.");
		if (Objects.isNull(productDetailsMap.get(IP_ADDRESS))
				|| StringUtils.isEmpty(productDetailsMap.get(IP_ADDRESS).toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_ERROR_DB_URL));
			return true;
		}
		if (Objects.isNull(productDetailsMap.get("port"))
				|| StringUtils.isEmpty(productDetailsMap.get("port").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_ERROR_DB_PORT));
			return true;
		}
		if (Objects.isNull(productDetailsMap.get(DATABASE_NAME))
				|| StringUtils.isEmpty(productDetailsMap.get(DATABASE_NAME).toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_ERROR_DB_NAME));
			return true;
		}
		if (Objects.isNull(productDetailsMap.get(DATABASE_USERNAME))
				|| StringUtils.isEmpty(productDetailsMap.get(DATABASE_USERNAME).toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_ERROR_DB_USER_NAME));
			return true;
		}
		if (Objects.isNull(productDetailsMap.get(DATABASE_PASSWORD))
				|| StringUtils.isEmpty(productDetailsMap.get(DATABASE_PASSWORD).toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_ERROR_DB_PASSWORD));
			return true;
		}
		if (Objects.isNull(productDetailsMap.get(DATABASE_SCHEMA))
				|| StringUtils.isEmpty(productDetailsMap.get(DATABASE_SCHEMA).toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_ERROR_DB_SCHEMA_NAME));
			return true;
		}
		logger.info("checkMandatoryDatabaseDetails method execution ended.");
		return false;
	}
	
	/**
	 * addSuccessMessage for all api default success key
	 * 
	 * @param returnMap contains return values for api
	 * @return returnMap
	 */
	public static Map<String, Object> addSuccessMessage(Map<String, Object> returnMap) {
		logger.info("addSuccessMessage method execution started.");
		returnMap.put(TableDefinitionConstants.ERROR_KEY, false);
		logger.info("addSuccessMessage method execution ended.");
		return returnMap;
	}
	
	/**
	 * releasedStatusMove method used for change the status of table to released
	 * 
	 * @param tableNameList   contains table name for which status to be moved
	 * @param changeRequestId contains change request id
	 * @param productCode
	 * @param renameMap
	 */
	public static void releasedStatusMove(List<Object> tableNameList, String productCode,
			Map<String, String> renameMap) {
		logger.info("releasedStatusMove method execution started. ");
		try {
			UpdateQueryBuilder updateQueryBuilder = new QueryBuilder().btSchema().update();
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".errorMessage", "");
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".status", TableTypeEnum.SUCCESS.name());
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".errorStage", "");
			updateQueryBuilder.skipChangeRequest(true).skipTenantId(true).updateWithMap(
					TableDefinitionConstants.TABLE_DEFINITION_MAIN, updateMap,
					ConditionBuilder.instance().inWithList(TableDefinitionConstants.TABLE_NAME, tableNameList).and()
							.eq(PRODUCT_CODE, productCode));
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("Exception occured at releasedStatusMove method" + exception.getMessage());
			logger.info("releasedStatusMove method execution ended. ");
		}
		logger.info("releasedStatusMove method execution ended. ");
	}

	/**
	 * putOfflineToOnlineTableDefinitionColumnDetails used for put offline table
	 * details into map
	 * 
	 * @param tableName                    for which table value fetched
	 * @param tableMetaExecutor            where database connection is maintained.
	 * @param resultMap                    where column details are put
	 * @param productCode
	 * @param tableDefinitionColumnDetails contains table definition column details
	 *                                     name main or meta
	 * @throws CustomException
	 */
	public static void putOfflineToOnlineTableDefinitionColumnDetails(String tableName, QueryExecutor tableMetaExecutor,
			Map<String, Object> resultMap, String tableDefinitionColumnDetailsName, String productCode)
			throws CustomException {
		logger.info("putOfflineToOnlineTableDefinitionColumnDetails method execution started.");
		List<Map<String, Object>> tableDefinitionColumnDetails = new ArrayList<>();
		try {

			tableDefinitionColumnDetails = tableMetaExecutor.queryBuilder().select()
					.getWithAliasName(PRODUCT_CODE,
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRODUCT_CODE2)
					.getWithAliasName(TENANT_ID,
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + TENANT_ID2)
					.getWithAliasName("table_name",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + TABLE_NAME)
					.getWithAliasName("column_name",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)
					.getWithAliasName(DATA_ELEMENT,
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT2)
					.getWithAliasName(DATA_FORMAT,
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT2)
					.getWithAliasName(DATA_TYPE,
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataType")
					.getWithAliasName("length",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".length")
					.getWithAliasName("primary_key",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".primaryKey")
					.getWithAliasName("not_null",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".notNull")
					.getWithAliasName("default_value",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".defaultValue")
					.getWithAliasName("audit_log_flag",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".auditLogFlag")
					.getWithAliasName("lang_dependent_flag",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag")
					.getWithAliasName("data_archive_flag",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataArchiveFlag")
					.getWithAliasName("column_description",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".columnDescription")
					.getWithAliasName("data_encryption_flag",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".dataEncryptionFlag")
					.getWithAliasName("autonumber_flag",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".autonumberFlag")
					.getWithAliasName(SERIAL_NUMBER,
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + SERIAL_NUMBER2)
					.getWithAliasName("translate_flag",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".translateFlag")
					.getWithAliasName("soft_delete_value",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".softDeleteValue")
					.getWithAliasName("meta_data_column",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".metaDataColumn")
					.getWithAliasName("column_value",
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".columnValue")
					.from(tableDefinitionColumnDetailsName).checkIndependentTenant(true).where(ConditionBuilder.instance()
							.eq(TableDefinitionConstants.TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode))
					.orderBy(SERIAL_NUMBER, SortType.ASC).build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in putting offline to online table column details " + exception);
			throw new CustomException(exception.getMessage());
		}
		resultMap.put(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP, tableDefinitionColumnDetails);
		logger.info("putOfflineToOnlineTableDefinitionColumnDetails method execution ended.");
	}

	/**
	 * putOfflineToOnlineTableDefinition method used for put offline Table
	 * definition into map
	 * 
	 * @param tableName         for which table value fetched
	 * @param tableMetaExecutor where database connection is maintained.
	 * @param resultMap         where column details are put
	 * @param tableDefinition   contains table definition name main or meta
	 * @param productCode
	 * @throws CustomException
	 */
	static void putOfflineToOnlineTableDefinition(String tableName, QueryExecutor tableMetaExecutor,
			Map<String, Object> resultMap, String tableDefinition, String productCode) throws CustomException {
		logger.info("putOfflineToOnlineTableDefinition method execution started.");
		List<Map<String, Object>> tableDefinitionDetails = new ArrayList<>();
		try {
			tableDefinitionDetails = tableMetaExecutor.queryBuilder().select()
					.getWithAliasName(PRODUCT_CODE, TableDefinitionConstants.TABLE_DEFINITION_MAIN + PRODUCT_CODE2)
					.getWithAliasName(TENANT_ID, TableDefinitionConstants.TABLE_DEFINITION_MAIN + TENANT_ID2)
					.getWithAliasName(VERSION_NO, TableDefinitionConstants.TABLE_DEFINITION_MAIN + VERSION_NO2)
					.getWithAliasName("table_name", TableDefinitionConstants.TABLE_DEFINITION_MAIN + TABLE_NAME)
					.getWithAliasName("data_archive", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".dataArchive")
					.getWithAliasName("cache_option", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".cacheOption")
					.getWithAliasName("data_capacity", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".dataCapacity")
					.getWithAliasName("table_description",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".tableDescription")
					.getWithAliasName("tenant_id_flag",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".tenantIdFlag")
					.getWithAliasName(DATABASE_HANDLER2,
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + DATABASE_HANDLER)
					.getWithAliasName("lang_dependent_flag",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".langDependentFlag")
					.getWithAliasName("sync_flag", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".syncFlag")
					.getWithAliasName("table_category",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".tableCategory")
					.getWithAliasName("table_type", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".tableType")
					.getWithAliasName("api_flag", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".apiFlag")
					.getWithAliasName(API_NAME, TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".apiName")
					.getWithAliasName("api_option", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".apiOption")
					.getWithAliasName(SUB_PRODUCT_CODE,
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".subProductCode")
					.getWithAliasName("api_url", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".apiUrl")
					.getWithAliasName("api_status", TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".apiStatus")
					.getWithAliasName("data_encryption_flag",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".dataEncryptionFlag")
					.getWithAliasName("soft_delete_flag",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".softDeleteFlag")
					.getWithAliasName("history_column",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".historyColumn")
					.getWithAliasName("previous_request_id",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + PREVIOUS_REQUEST_ID)
					.getWithAliasName("table_secure",
							TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".tableSecure")
					.from(tableDefinition).checkIndependentTenant(true).where(ConditionBuilder.instance()
							.eq(TableDefinitionConstants.TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode))
					.build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in putting offline to online table definition details " + exception);
			throw new CustomException(exception.getMessage());
		}
		resultMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAP, tableDefinitionDetails);
		logger.info("putOfflineToOnlineTableDefinition method execution ended.");
	}

	/**
	 * putOfflineToOnlineIndexDetails used to put offline index key details into map
	 * 
	 * @param tableName                   for which table value fetched
	 * @param tableMetaExecutor           where database connection is maintained.
	 * @param resultMap                   where column details are put
	 * @param tableDefinitionIndexDetails contains index table name main or meta
	 * @param productCode
	 * @throws CustomException when getting index details
	 */
	static void putOfflineToOnlineIndexDetails(String tableName, QueryExecutor tableMetaExecutor,
			Map<String, Object> resultMap, String tableDefinitionIndexDetails, String productCode)
			throws CustomException {
		logger.info("putOfflineToOnlineIndexDetails method execution started.");
		List<Map<String, Object>> tableDefinitionIndexDetailsList = new ArrayList<>();
		try {
			tableDefinitionIndexDetailsList = tableMetaExecutor.queryBuilder().select()
					.getWithAliasName(PRODUCT_CODE,
							TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + PRODUCT_CODE2)
					.getWithAliasName(TENANT_ID,
							TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + TENANT_ID2)
					.getWithAliasName("table_name",
							TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + TABLE_NAME)
					.getWithAliasName(SERIAL_NUMBER,
							TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + SERIAL_NUMBER2)
					.getWithAliasName("index_name",
							TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".indexName")
					.getWithAliasName("column_names",
							TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".columnNames")
					.from(tableDefinitionIndexDetails).checkIndependentTenant(true).where(ConditionBuilder.instance()
							.eq(TableDefinitionConstants.TABLE_NAME, tableName).and().eq(PRODUCT_CODE, productCode))
					.orderBy(SERIAL_NUMBER, SortType.ASC).build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in putting offline to online index details " + exception);
			throw new CustomException(exception.getMessage());
		}
		resultMap.put(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP, tableDefinitionIndexDetailsList);
		logger.info("putOfflineToOnlineIndexDetails method execution ended.");
	}

	/**
	 * putOfflineToOnlineUniqueKeyDetails used to put offline unique key details
	 * into map
	 * 
	 * @param tableName                    for which table value fetched
	 * @param tableMetaExecutor            where database connection is maintained.
	 * @param resultMap                    where column details are put
	 * @param productCode
	 * @param tableDefinitionUniqueDetails contains unique table name main or meta
	 * @throws CustomException
	 */
	static void putOfflineToOnlineUniqueKeyDetails(String tableName, QueryExecutor tableMetaExecutor,
			Map<String, Object> resultMap, String tableDefinitionUniqueDetailsName, String productCode)
			throws CustomException {
		logger.info("putOfflineToOnlineUniqueKeyDetails method execution started.");
		List<Map<String, Object>> tableDefinitionUniqueDetails = new ArrayList<>();
		try {
			tableDefinitionUniqueDetails = tableMetaExecutor.queryBuilder().select()
					.getWithAliasName(PRODUCT_CODE,
							TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + PRODUCT_CODE2)
					.getWithAliasName(TENANT_ID,
							TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + TENANT_ID2)
					.getWithAliasName("table_name",
							TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + TABLE_NAME)
					.getWithAliasName(SERIAL_NUMBER,
							TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + SERIAL_NUMBER2)
					.getWithAliasName("unique_key_name",
							TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + ".uniqueKeyName")
					.getWithAliasName("unique_column_details",
							TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + ".uniqueColumnDetails")
					.from(tableDefinitionUniqueDetailsName).checkIndependentTenant(true)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.orderBy(SERIAL_NUMBER, SortType.ASC).build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in putting offline to online unique key details " + exception);
			throw new CustomException(exception.getMessage());
		}
		resultMap.put(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP, tableDefinitionUniqueDetails);
		logger.info("putOfflineToOnlineUniqueKeyDetails method execution ended.");
	}

	/**
	 * putOfflineToOnlineForeignKeyDetails used to put offline foreign key details
	 * into map
	 * 
	 * @param tableName                     for which table value fetched
	 * @param tableMetaExecutor             where database connection is maintained.
	 * @param resultMap                     where column details are put
	 * @param productCode
	 * @param tableDefinitionForeignDetails contains foreign table name main or meta
	 * @throws CustomException
	 */
	static void putOfflineToOnlineForeignKeyDetails(String tableName, QueryExecutor tableMetaExecutor,
			Map<String, Object> resultMap, String tableDefinitionForeignDetailsName, String productCode)
			throws CustomException {
		logger.info("putOfflineToOnlineForeignKeyDetails method execution started.");
		List<Map<String, Object>> tableDefinitionForeignDetails = new ArrayList<>();
		try {
			tableDefinitionForeignDetails = tableMetaExecutor.queryBuilder().select()
					.getWithAliasName(PRODUCT_CODE,
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + PRODUCT_CODE2)
					.getWithAliasName(TENANT_ID,
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + TENANT_ID2)
					.getWithAliasName("table_name",
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + TABLE_NAME)
					.getWithAliasName("reference_table",
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".referenceTable")
					.getWithAliasName("foreign_key_name",
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".foreignKeyName")
					.getWithAliasName("foreign_key_column_details",
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".foreignKeyColumnDetails")
					.getWithAliasName("constraint_name",
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + ".constraintName")
					.getWithAliasName(SERIAL_NUMBER,
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + SERIAL_NUMBER2)
					.from(tableDefinitionForeignDetailsName).checkIndependentTenant(true)
					.where(ConditionBuilder.instance().eq(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq(PRODUCT_CODE, productCode))
					.orderBy(SERIAL_NUMBER, SortType.ASC).build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in putting offline to online foreign key details " + exception);
			throw new CustomException(exception.getMessage());
		}
		resultMap.put(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP, tableDefinitionForeignDetails);
		logger.info("putOfflineToOnlineForeignKeyDetails method execution ended.");
	}
	/**
	 * 
	 * @param tableName         table name for which offline to online converted
	 * @param tableMetaExecutor database connection to get table values and insert
	 *                          it
	 * @param resultMap         to put values in the map
	 * @param productCode
	 * @throws CustomException exception occurs when getting
	 */
	public static void getTableDetails(String tableName, QueryExecutor tableMetaExecutor, Map<String, Object> resultMap,
			String productCode) throws CustomException {
		try {
			logger.info("getTableDetails method execution started");
			boolean mainTable = resultMap.containsKey(TableDefinitionConstants.EDIT);
			putOfflineToOnlineTableDefinition(tableName, tableMetaExecutor, resultMap,
					mainTable ? TABLE_DEFINITION : "table_definition_offline", productCode);
			putOfflineToOnlineTableDefinitionColumnDetails(tableName, tableMetaExecutor, resultMap,
					mainTable ? "table_definition_column_details" : "table_definition_column_details_offline",
					productCode);
			putOfflineToOnlineForeignKeyDetails(tableName, tableMetaExecutor, resultMap,
					mainTable ? "table_foreign_constraints_details" : "table_foreign_constraints_details_offline",
					productCode);
			putOfflineToOnlineUniqueKeyDetails(tableName, tableMetaExecutor, resultMap,
					mainTable ? "table_unique_constraint_definition" : "table_unique_constraint_definition_offline",
					productCode);
			putOfflineToOnlineIndexDetails(tableName, tableMetaExecutor, resultMap,
					mainTable ? "table_index_definition" : "table_index_definition_offline", productCode);
		} catch (Exception exception) {
			logger.error("Exception occured at getTableDetails method " + exception);
			logger.info("getTableDetails method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("getTableDetails method execution ended.");
	}
	/**
	 * commitExecutor used for commit autocommit false connection
	 * 
	 * @param queryExecutor contains database connection
	 * @throws CustomException when error at commiting
	 */
	public static void commitExecutor(QueryExecutor queryExecutor) throws CustomException {
		logger.info("commitExecutor method exeuction started");
		try {
			if (Objects.nonNull(queryExecutor)) {
				queryExecutor.commit();
				logger.info("commitExecutor commit done");
			}
		} catch (Exception queryException) {
			rollBackExecutor(queryExecutor);
			logger.error(queryException);
			throw new CustomException(queryException.getMessage());
		}
		logger.info("commitExecutor method exeuction ended");
	}
	/**
	 * rollBackExecutor used for rollback connection
	 * 
	 * @param queryExecutor contains database connection
	 */
	public static void rollBackExecutor(QueryExecutor queryExecutor) {
		logger.info("rollBackExecutor method exeuction started");
		try {
			if (Objects.nonNull(queryExecutor)) {
				queryExecutor.rollBack();
				logger.info("rollBackExecutor rollback done");
			}
		} catch (Exception queryException) {
			logger.error(queryException);
		}
		logger.info("rollBackExecutor method exeuction ended");
	}
	/**
	 * getMessageDefintionText for getting message value from cache
	 * 
	 * @param messageId key for message value
	 * @return message entries value
	 */
	public static String getMessageDefintionText(String messageId) {
		MessageDefinitionEntity messageDefinitionEntity;
		String text = messageId;
		try {
			messageDefinitionEntity = CacheService.getInstance().getMessageDefinitionData(messageId,
					ContextBean.getLocale());
			if (Objects.nonNull(messageDefinitionEntity)) {
				text = messageDefinitionEntity.getTextContent();
			}
		} catch (Exception exception) {
			logger.error("Exception in getting message from cache for message id: " + messageId + " Exception: "
					+ exception);
		}
		return text;
	}
	/**
	 * updateMasterDefinitionChangeRequestDetails used to update the cr details of
	 * the master data.
	 * 
	 * @param keyList
	 * @param changeRequestId
	 */
	private static void updateMasterDefinitionChangeRequestDetails(List<Object> keyList, String changeRequestId) {
		logger.info("updateMasterDefinitionChangeRequestDetails method starts...");
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			List<Map<String, Object>> dataList = queryBuilder.btSchema().select()
					.from(DataDefinitionConstants.MASTER_DEFINITION, "master")
					.leftJoin("data_format_definition", "dataFormat",
							ConditionBuilder.instance().eq("master.master_id", "dataFormat.master_id", true))
					.where(ConditionBuilder.instance().inWithList("dataFormat.data_format", keyList)).build(false)
					.execute();
			if (CollectionUtils.isNotEmpty(dataList)) {
				List<Object> masterIdList = dataList.stream().map(mapper -> mapper.get("master_id"))
						.collect(Collectors.toList());
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(TableDefinitionConstants.MASTER_DEFINITION_MAIN + PREVIOUS_REQUEST_ID, changeRequestId);
				queryBuilder.update().setChangeRequestId(changeRequestId).updateWithMap(
						TableDefinitionConstants.MASTER_DEFINITION_MAIN, updateMap,
						ConditionBuilder.instance().inWithList("master_id", masterIdList));
			}
		} catch (QueryException exception) {
			logger.error("Exception in updateMasterDefinitionChangeRequestDetails. " + exception);
		}
		logger.info("updateMasterDefinitionChangeRequestDetails method ends...");
	}
	/**
	 * getDataDefinitionDetailsFromOnline used to get Data Element and Data Class
	 * List
	 * 
	 * @param dataDefinitionExecutor contains data definition connection
	 * @param resultMap              contains dataFormat and Data Element List
	 * @throws CustomException throw custom Exception when data element details not
	 *                         found in online
	 */
	@SuppressWarnings("unchecked")
	public static void getDataDefinitionDetailsFromOnline(QueryExecutor dataDefinitionExecutor,
			Map<String, Object> resultMap) throws CustomException {
		if (resultMap.containsKey(TableDefinitionConstants.ONLINE_DATA_ELEMENT_LIST)) {
			logger.info("getting data element list");
			List<Map<String, Object>> dataElementDetailsList = new ArrayList<>();
			try {
				dataElementDetailsList = dataDefinitionExecutor.queryBuilder().select().skipTenantId(true)
						.from("data_element_data_format_view").checkIndependentTenant(true)
						.where(ConditionBuilder.instance().inWithList(DATA_ELEMENT,
								(List<Object>) resultMap.get(TableDefinitionConstants.ONLINE_DATA_ELEMENT_LIST)))
						.build(false).execute();
			} catch (Exception exception) {
				logger.error("Exception in data element list fetch " + exception);
				throw new CustomException(exception.getMessage());
			}
			if (dataElementDetailsList.isEmpty()) {
				logger.info("Data element details not found in online "
						+ resultMap.get(TableDefinitionConstants.ONLINE_DATA_ELEMENT_LIST));
				throw new CustomException(TableDefinitionUtils
						.getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_DATA_DEFINITION_DETAILS));
			}
			resultMap.put(TableDefinitionConstants.DATA_ELEMENT_DETAILS, dataElementDetailsList.stream()
					.collect(Collectors.groupingBy(mapper -> String.valueOf(mapper.get(DATA_ELEMENT)))));
		}
		if (resultMap.containsKey(TableDefinitionConstants.ONLINE_DATA_FORMAT_LIST)) {
			logger.info("getting data class list");
			List<Map<String, Object>> dataFormatDetailsList = new ArrayList<>();
			try {
				dataFormatDetailsList = dataDefinitionExecutor.queryBuilder().select().checkIndependentTenant(true)
						.getWithAliasName(DATA_FORMAT, "table_data_format").getWithAliasName(DATA_TYPE, DATA_TYPE)
						.getWithAliasName("max_length", "max_length").get("precision")
						.getWithAliasName("default_value", "default_value")
						.getWithAliasName("case when element_type ='Autonumber'then true else false end", "autonumber")
						.getWithAliasName("max_decimal", "decimal_value").from("data_format_definition")
						.skipTenantId(true)
						.where(ConditionBuilder.instance().inWithList(DATA_FORMAT,
								(List<Object>) resultMap.get(TableDefinitionConstants.ONLINE_DATA_FORMAT_LIST)))
						.build(false).execute();
			} catch (Exception exception) {
				logger.error("Exception in data class list fetch " + exception);
				throw new CustomException(exception.getMessage());
			}
			if (dataFormatDetailsList.isEmpty()) {
				logger.info("Data Class details not found in online "
						+ resultMap.get(TableDefinitionConstants.ONLINE_DATA_FORMAT_LIST));
				throw new CustomException(TableDefinitionUtils
						.getMessageDefintionText(MessageEntriesConstants.TABLE_DEFINITION_DATA_FORMAT_INVALID));
			}
			resultMap.put(TableDefinitionConstants.DATA_FORMAT_DETAILS, dataFormatDetailsList.stream()
					.collect(Collectors.groupingBy(mapper -> String.valueOf(mapper.get("table_data_format")))));
		}

	}
	/**
	 * getDataElementAndDataClassSet used for getting data element and data class
	 * used in table
	 * 
	 * @param resultMap       contains table Details
	 * @param dataElementSet  contains dataElement used in column
	 * @param dataFormatSet   contains dataFormat used in column
	 * @param tableDetailsMap
	 */
	@SuppressWarnings("unchecked")
	public static void getDataElementAndDataClassSet(Map<String, Object> resultMap, Set<Object> dataElementSet,
			Set<Object> dataFormatSet, Map<String, Object> tableDetailsMap) {
		List<Map<String, Object>> columnDetailsList;
		if (tableDetailsMap.containsKey(TableDefinitionConstants.EDIT)) {
			columnDetailsList = (List<Map<String, Object>>) tableDetailsMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP);
		} else {
			columnDetailsList = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP);
		}

		Set<Object> onlineDataClassSet = new HashSet<>();
		logger.info("getDataElementAndDataClassSet method execution started.");
		columnDetailsList.forEach(columnDetailsMap -> {
			if (Objects.nonNull(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT2))
					&& !columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT2)
							.toString().isBlank()) {
				dataElementSet.add(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT2));
			} else if (Objects.nonNull(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT2))
					&& !columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT2)
							.toString().isBlank()) {
				onlineDataClassSet.add(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT2));
				dataFormatSet.add(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT2));
			}
		});
		if (!onlineDataClassSet.isEmpty()) {
			logger.info(" onlineDataClassSet :" + onlineDataClassSet);
			resultMap.put(TableDefinitionConstants.ONLINE_DATA_FORMAT_LIST, new ArrayList<>(onlineDataClassSet));
		}
		if (!dataElementSet.isEmpty()) {
			logger.info(" dataElementSet :" + dataElementSet);
			resultMap.put(TableDefinitionConstants.ONLINE_DATA_ELEMENT_LIST, new ArrayList<>(dataElementSet));
		}
		logger.info("getDataElementAndDataClassSet method execution ended.");
	}
	/**
	 * updateChangeRequestForDataDefinitionTables change request id update for data
	 * definition
	 * 
	 * @param changeRequestId contains change request id
	 * @param tablesMap       contains tables to be updated
	 * @throws CustomException error occured while updating
	 */
	@SuppressWarnings("unchecked")
	public static void updateChangeRequestForDataDefinitionTables(String changeRequestId, Map<String, Object> tablesMap)
			throws CustomException {
		logger.info("updateChangeRequestForDataDefinitionTables method execution started.");
		try {
			UpdateQueryBuilder updateQueryBuilder = new QueryBuilder().update().setChangeRequestId(changeRequestId);
			if (tablesMap.containsKey(TableDefinitionConstants.OFFLINE_CHARSET_LIST)) {
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(TableDefinitionConstants.CHARSET_DEFINTION_MAIN + PREVIOUS_REQUEST_ID, changeRequestId);
				updateQueryBuilder.updateWithMap(TableDefinitionConstants.CHARSET_DEFINTION_MAIN, updateMap,
						ConditionBuilder.instance().inWithList("charset_id",
								(List<Object>) (tablesMap.get(TableDefinitionConstants.OFFLINE_CHARSET_LIST))));
			}
			if (tablesMap.containsKey(TableDefinitionConstants.OFFLINE_DATA_FORMAT_LIST)) {
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(TableDefinitionConstants.DATA_FORMAT_DEFINTION_MAIN + PREVIOUS_REQUEST_ID,
						changeRequestId);
				updateQueryBuilder.updateWithMap(TableDefinitionConstants.DATA_FORMAT_DEFINTION_MAIN, updateMap,
						ConditionBuilder.instance().inWithList(DATA_FORMAT,
								(List<Object>) (tablesMap.get(TableDefinitionConstants.OFFLINE_DATA_FORMAT_LIST))));
				updateMasterDefinitionChangeRequestDetails(
						(List<Object>) tablesMap.get(TableDefinitionConstants.OFFLINE_DATA_FORMAT_LIST),
						changeRequestId);
			}
			if (tablesMap.containsKey(TableDefinitionConstants.OFFLINE_DATA_ELEMENT_LIST)) {
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN + PREVIOUS_REQUEST_ID,
						changeRequestId);
				updateQueryBuilder.updateWithMap(TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN, updateMap,
						ConditionBuilder.instance().inWithList(DATA_ELEMENT,
								(List<Object>) (tablesMap.get(TableDefinitionConstants.OFFLINE_DATA_ELEMENT_LIST))));
			}
			if (tablesMap.containsKey(DataDefinitionConstants.MASTER)) {
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(TableDefinitionConstants.MASTER_DEFINITION_MAIN + PREVIOUS_REQUEST_ID, changeRequestId);
				updateQueryBuilder.updateWithMap(TableDefinitionConstants.MASTER_DEFINITION_MAIN, updateMap,
						ConditionBuilder.instance().inWithList("master_id",
								(List<Object>) (tablesMap.get(DataDefinitionConstants.MASTER))));
			}
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("updateChangeRequestForDataDefinitionTables method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("updateChangeRequestForDataDefinitionTables method execution ended.");
	}
	
	/**
	 * get source version
	 * 
	 */
	public static String getSourceVersion() {
		logger.info("getSourceVersion method execution started.");
		String version = "";
		try {
			List<Map<String, Object>> versionList = new QueryBuilder().btSchema().select().from("repo_config")
					.where(ConditionBuilder.instance().eq(PRODUCT_CODE, "sova_core").and()
							.eq(SUB_PRODUCT_CODE, "custom_designer").and().eq("repo_type", "service").and()
							.isNotNull("source_version"))
					.build(false).execute();
			if (!versionList.isEmpty()) {
				version = String.valueOf(versionList.get(0).get("source_version"));
			}
		} catch (Exception exception) {
			logger.info("getSourceVersion method execution ended." + exception.getMessage());
			logger.error(exception);

		}
		logger.info("getSourceVersion method execution ended.");
		return version;
	}
	/**
	 * convertDataType is used to convert the data type based on the postgres format
	 * 
	 * @param dataTypeName contains division entry for data type
	 */
	public static String convertDataType(Object dataTypeName) {
		switch (dataTypeName.toString().toLowerCase(Locale.ENGLISH)) {
		case TableDefinitionConstants.STRING_DATA_TYPE:
			return TableDefinitionConstants.TEXT_DATATYPE;
		case TableDefinitionConstants.NUMBER_DATA_TYPE:
			return TableDefinitionConstants.NUMERIC_DATATYPE;
		case TableDefinitionConstants.BOOLEAN_DATA_TYPE:
			return TableDefinitionConstants.BOOL_DATATYPE;
		case TableDefinitionConstants.TIMESTAMP_DATA_TYPE:
		case TableDefinitionConstants.TIME_DATA_TYPE:
			return TableDefinitionConstants.TIMESTAMP_WITHOUT_TIME_ZONE_DATATYPE;
		case TableDefinitionConstants.VARCHAR_DATATYPE:
			return TableDefinitionConstants.CHARACTER_VARYING_DATATYPE;
		default:
			return String.valueOf(dataTypeName).toLowerCase(Locale.ENGLISH);
		}
	}
	/**
	 * checkAndInactivateDependentView dependent view
	 * 
	 * @param tableCreateOrAlterExecutor
	 * @param tableMetaExecutor
	 * @param tableName
	 * @param productCode
	 * @param changeExecutor
	 * @throws CustomException
	 */
	public static void checkAndInactivateDependentView(QueryExecutor tableCreateOrAlterExecutor,
			QueryExecutor tableMetaExecutor, String tableName, String productCode, boolean changeExecutor,
			List<Object> viewList) throws CustomException {
		try {
			List<Map<String, Object>> dependentViewDrop = tableMetaExecutor.queryBuilder().select()
					.from("view_object_definition")
					.where(ConditionBuilder.instance().ilike("tables_with_alias", "%\"" + tableName + "\"%").and()
							.eq("view_flag", true).and().eq(PRODUCT_CODE, productCode))
					.orderBy("created_at", SortType.ASC).build(true).execute();
			List<ConditionBuilder> conditionBuilderList = new ArrayList<>();
			List<Map<String, Object>> updateList = new ArrayList<>();
			for (Map<String, Object> dependentView : dependentViewDrop) {
				if (!viewList.contains(String.valueOf(dependentView.get(VIEW_OBJECT_NAME)))) {
					viewList.add(String.valueOf(dependentView.get(VIEW_OBJECT_NAME)));
					checkAndInactivateDependentView(tableCreateOrAlterExecutor, tableMetaExecutor,
							String.valueOf(dependentView.get(VIEW_OBJECT_NAME)), productCode, changeExecutor, viewList);
				}
				DropViewEntity dropEntity = new DropViewEntity();
				dropEntity.setProductName(productCode);
				dropEntity.setViewName(String.valueOf(dependentView.get(VIEW_OBJECT_NAME)));
				tableCreateOrAlterExecutor.queryBuilder().table().dropView().setProductCode(productCode)
						.dropView(dropEntity).build().execute();
				conditionBuilderList.add(ConditionBuilder.instance()
						.eq(VIEW_OBJECT_NAME, dependentView.get(VIEW_OBJECT_NAME)).and().eq(PRODUCT_CODE, productCode));
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put("view_object_definition" + ".status_flag", false);
				updateList.add(updateMap);
			}
			if (!updateList.isEmpty()) {
				tableMetaExecutor.skipChangeRequest(true);
				tableMetaExecutor.queryBuilder().update().batchUpdate("view_object_definition",
						updateList, conditionBuilderList);
				if (!changeExecutor) {
					tableMetaExecutor.skipChangeRequest(false);
				}
			}
		} catch (Exception exception) {
			throw new CustomException(exception.getMessage());
		}
	}
	
	/**
	 * updateProgramBusinessObject program_business_object table update
	 * 
	 * @param tableNameList contains tableNameList to be updated
	 * @throws CustomException
	 */
	public static void updateProgramBusinessObject(List<Object> tableNameList,boolean deleteFlag) throws CustomException {
		logger.info("updateProgramBusinessObject method execution started.");
		try {
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put("program_business_object.modified_flag", true);
			updateMap.put("program_business_object.release_flag", true);
			if(deleteFlag) {
				updateMap.put("program_business_object.is_deleted", true);
			}
			new QueryBuilder().update().skipChangeRequest(true).forceUpdate(true).updateWithMap(
					"program_business_object", updateMap,
					ConditionBuilder.instance().inWithList("business_object_name", tableNameList));
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("updateProgramBusinessObject method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("updateProgramBusinessObject method execution ended.");
	}
	/**
	 * getReleaseStatusForTable for freeze
	 * 
	 * @param paramMap
	 * @return
	 */
	public static Map<String, Object> getReleaseStatusForTable(Map<String, Object> paramMap) {
		try {
			if (paramMap.containsKey("changeRequestId") && Objects.nonNull(paramMap.get("changeRequestId"))) {
				paramMap.put("status",
						Integer.parseInt(String.valueOf(new QueryBuilder().btSchema().select().count("*", "count")
								.from("table_definition")
								.where(ConditionBuilder.instance()
										.eq("previous_request_id", paramMap.get("changeRequestId")).and()
										.brackets(ConditionBuilder.instance()
												.inWithList("status",
														Arrays.asList("INPROGRESS",
																"INACTIVE"))
												.or().inWithList("api_status",
														Arrays.asList("INPROGRESS", "false"))))
								.build(false).execute().get(0).get("count"))) > 0 ? false : true);
			} else {
				paramMap.put("status", false);
				paramMap.put("message", "Change request id is null");
			}
		} catch (Exception exception) {
			paramMap.put("status", false);
			paramMap.put("message", exception.getMessage());
		}
		return paramMap;
	}
}
