package com.nn.sova.service.controller.paymentgateway;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;

@SovaMapping("/paymentcommonservice")
public class PaymentGatewayController {

    /** The constant APPLICATION_JSON. */
    private static final String APPLICATION_JSON = "application/json";

    /** The constant PRODUCT_CODE. */
    private static final String PRODUCT_CODE = "productCode";

    /** The constant PAYMENT_TYPE. */
    private static final String PAYMENT_TYPE = "paymentType";

    /** The constant HANDLER_TYPE. */
    private static final String HANDLER_TYPE = "handlerType";

    /** MAP_TYPE_REFERENCE */
    private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE = new TypeReference<Map<String, Object>>() {
    };

    /**
	 * Initiate Payment for Common Service.
	 *
	 * @param paramMap
	 * @return the Map
	 * @throws QueryException
	 * @throws UnsupportedEncodingException
	 */
    @SuppressWarnings("unchecked")
    //post_lambda 
	@SovaMapping(value = "/initiatepayment", method = SovaRequestMethod.POST)
    public Map<String, Object> initiatePayment(SovaHttpRequest request, SovaHttpResponse response) throws UnsupportedEncodingException, QueryException {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        String apiUrl = String.join("/", getRequestUrl(), "payment/gateway/");
        apiUrl = apiUrl + String.join("?", "paymentchargecallback", String.join("=", PRODUCT_CODE, String.valueOf(paramMap.get(PRODUCT_CODE))));
        apiUrl = String.join("&", apiUrl, String.join("=", PAYMENT_TYPE, String.valueOf(paramMap.get(PAYMENT_TYPE))));
        apiUrl = String.join("&", apiUrl, String.join("=", HANDLER_TYPE, String.valueOf(paramMap.get(HANDLER_TYPE))));
        String apiToken = fetchApiToken();
        if (StringUtils.isNotEmpty(apiToken)) {
            apiUrl = String.join("&", apiUrl, String.join("=", "apiToken", apiToken));
        }
        Map<String, Object> paymentMap = (Map<String, Object>) paramMap.get("paymentObject");
        return doPost(apiUrl, JsonUtils.toJsonOrEmpty(paymentMap));
    }

    /**
	 * Verify Signature on Razorpay Payment.
	 *
	 * @param paramMap
	 * @return the Map
	 * @throws QueryException
	 * @throws UnsupportedEncodingException
	 */
    @SuppressWarnings("unchecked")
    //post_lambda 
	@SovaMapping(value = "/verifypaymentsignature", method = SovaRequestMethod.POST)
    public Map<String, Object> verifyPaymentSignature(SovaHttpRequest request, SovaHttpResponse response) throws UnsupportedEncodingException, QueryException {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        String apiUrl = String.join("/", getRequestUrl(), "payment/gateway/");
        apiUrl = apiUrl + String.join("?", "verifypaymentsignature", String.join("=", PRODUCT_CODE, String.valueOf(paramMap.get(PRODUCT_CODE))));
        apiUrl = String.join("&", apiUrl, String.join("=", PAYMENT_TYPE, String.valueOf(paramMap.get(PAYMENT_TYPE))));
        apiUrl = String.join("&", apiUrl, String.join("=", HANDLER_TYPE, String.valueOf(paramMap.get(HANDLER_TYPE))));
        String apiToken = fetchApiToken();
        if (StringUtils.isNotEmpty(apiToken)) {
            apiUrl = String.join("&", apiUrl, String.join("=", "apiToken", apiToken));
        }
        Map<String, Object> signatureMap = (Map<String, Object>) paramMap.get("signatureParam");
        return doPost(apiUrl, JsonUtils.toJsonOrEmpty(signatureMap));
    }

    private String fetchApiToken() {
        String apiToken = ContextBean.getApiToken();
        if (StringUtils.isEmpty(apiToken)) {
            try {
                apiToken = UserContext.getInstance().getUserProfile().getApiToken();
            } catch (NullPointerException exception) {
                apiToken = null;
            }
        }
        return apiToken;
    }

    private String getRequestUrl() throws QueryException {
        String tenantId = ContextBean.getTenantId();
        String requestUrl = StringUtils.EMPTY;
        if (StringUtils.isNotEmpty(tenantId)) {
            Map<String, Object> tenantMap = CacheService.getInstance().getTenantDefinition(tenantId);
            if (MapUtils.isEmpty(tenantMap)) {
                return requestUrl;
            }
            String protocol = "http";
            if (Boolean.parseBoolean(String.valueOf(tenantMap.get("allow_ssl_flag")))) {
                protocol = "https";
            }
            return String.join("/", String.join("://", protocol, String.valueOf(tenantMap.get("domain_name"))), "nn-payment-gateway-service");
        }
        return requestUrl;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> doPost(String apiUrl, String body) throws UnsupportedEncodingException {
        Map<String, Object> returnMap = new HashMap<>();
        /** Creating a HttpPost object */
        HttpPost httpPostRequest = new HttpPost(apiUrl);
        httpPostRequest.setHeader("Content-type", APPLICATION_JSON);
        StringEntity entity = new StringEntity(body);
        httpPostRequest.setEntity(entity);
        try (CloseableHttpClient httpClient = HttpClients.createDefault();
            CloseableHttpResponse response = httpClient.execute(httpPostRequest)) {
            HttpEntity responseEntity = response.getEntity();
            if (responseEntity != null) {
                // return it as a String
                String resultString = EntityUtils.toString(responseEntity);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == HttpStatus.OK.value() || statusCode == HttpStatus.BAD_REQUEST.value()) {
                    returnMap = JsonUtils.fromJsonOrElse(resultString, MAP_TYPE_REFERENCE, new HashMap<>());
                }
            }
        } catch (IOException exception) {
            returnMap = MapUtils.EMPTY_MAP;
        }
        return returnMap;
    }
}
