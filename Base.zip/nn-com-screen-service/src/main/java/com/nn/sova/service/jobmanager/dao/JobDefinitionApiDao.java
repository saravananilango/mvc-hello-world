package com.nn.sova.service.jobmanager.dao;

import java.util.List;
import java.util.Optional;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.service.jobmanager.entity.JobDefinitionApi;
import com.nn.sova.utility.json.exception.JsonConversionException;


/**
 * The DAO for job_definition_api table.
 *
 * @author praveen_kumar_nr
 */
final class JobDefinitionApiDao implements
	JobDefinitionDao<JobDefinitionApi> {

	/**
	 * Instantiates a new job definition framework jar dao.
	 */
	JobDefinitionApiDao() {
		// use singleton instance
	}

	@Override
	public Optional<JobDefinitionApi> select(String jobDefId) {
		throw new UnsupportedOperationException("select method not implemented");
	}

	@Override
	public List<JobDefinitionApi> select(String searchKeyWord, int offset, int limit) {
		throw new UnsupportedOperationException("select method not implemented");
	}

	@Override
	public String upsert(JobDefinitionApi jobDefinition, QueryExecutor executor, boolean skipChangeRequest)
		throws QueryException, JsonConversionException {
		throw new UnsupportedOperationException("upsert method not implemented");
	}

}
