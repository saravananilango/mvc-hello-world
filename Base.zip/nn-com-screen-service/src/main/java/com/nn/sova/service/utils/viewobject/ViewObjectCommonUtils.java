package com.nn.sova.service.utils.viewobject;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.date.DateTimeUtils;
import com.nn.sova.utility.helper.TokenManipulation;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
  * ViewObjectCommonUtils contains common methods
 * 
 * @author Hariprasath Kamaraj
 *
 */
public class ViewObjectCommonUtils {
	/**
	 * logger for ViewObjectCommonUtils class
	 */
	private static ApplicationLogger logger = ApplicationLogger.create(ViewObjectCommonUtils.class);

	
	/**
	 * addSuccessMessage for all api default success key
	 * 
	 * @param returnMap
	 *            contains return values for api
	 * @return returnMap
	 */
	public static Map<String, Object> addSuccessMessage(Map<String, Object> returnMap,String successMessage) {
		logger.info("addSuccessMessage method execution started.");
		returnMap.put(ViewObjectConstants.ERROR, false);
		returnMap.put(ViewObjectConstants.STATUS, true);
		returnMap.put(ViewObjectConstants.MESSAGE, successMessage);
		logger.info("addSuccessMessage method execution ended.");
		return returnMap;
	}

	/**
	 * addErrorMessage for all api default error status addition
	 * 
	 * @param returnMap
	 *            contains return values for api
	 * @param errorMessage
	 *            contains error message
	 * @return returnMap
	 */
	public static Map<String, Object> addErrorMessage(Map<String, Object> returnMap, String errorMessage) {
		logger.info("addErrorMessage method execution started.");
		returnMap.put(ViewObjectConstants.ERROR, true);
		returnMap.put(ViewObjectConstants.STATUS, false);
		returnMap.put(ViewObjectConstants.MESSAGE, errorMessage);
		logger.info("addErrorMessage method execution ended.");
		return returnMap;
	}
	
	
	
	/**
	 * commitExecutor used for commit autocommit false connection
	 * 
	 * @param queryExecutor
	 *            contains database connection
	 * @throws CustomException
	 *             when error at commiting
	 */
	public static void commitExecutor(QueryExecutor queryExecutor) throws CustomException {
		logger.info("commitExecutor method exeuction started");
		try {
			if (Objects.nonNull(queryExecutor)) {
				queryExecutor.commit();
				logger.info("commitExecutor commit done");
			}
		} catch (Exception queryException) {
			rollBackExecutor(queryExecutor);
			logger.error(queryException);
			throw new CustomException(queryException.getMessage());
		}
		logger.info("commitExecutor method exeuction ended");
	}



	/**
	 * rollBackExecutor used for rollback connection
	 * 
	 * @param queryExecutor
	 *            contains database connection
	 * @throws CustomException 
	 */
	public static  void rollBackExecutor(QueryExecutor queryExecutor) throws CustomException {
		logger.info("rollBackExecutor method exeuction started");
		try {
			if (Objects.nonNull(queryExecutor)) {
				queryExecutor.rollBack();
				logger.info("rollBackExecutor rollback done");
			}
		} catch (Exception queryException) {
			logger.error(queryException);
			throw new CustomException(queryException);
		}
		logger.info("rollBackExecutor method exeuction ended");
	}
	
	
	
	/**
	 * getApplicationDatabaseDetails used for get database details
	 * 
	 * @param applicationName
	 *            for which table is to be created
	 * @param databaseHandler
	 *            contains handler name
	 * @param queryBuilder 
	 * @return database details information or error message
	 * @throws CustomException
	 *             while getting database details
	 */
	public static Map<String, Object> getApplicationDatabaseDetails(String applicationName, String databaseHandler, QueryBuilder queryBuilder)
			throws CustomException {
		Map<String, Object> databaseDetailsMap = new HashMap<>();
		try {
			logger.info("getApplicationDatabaseDetails method execution started.");
			List<Map<String, Object>> databaseList = queryBuilder.btSchema().select()
					.from("system_database_configuration_view")
					.where(ConditionBuilder.instance().eq("product_code", applicationName).and()
							.eq("handler_name", databaseHandler).and()
							.eq("system_id", EnvironmentReader.getSystemId()))
					.build(false).execute();
			
			logger.info("getApplicationDatabaseDetails db datalist" + databaseList);
			if (databaseList.isEmpty()) {
				logger.info(
						"Database details not found for application name : " + applicationName + ", DatabaseHandler : "
								+ databaseHandler + " and system id : " + EnvironmentReader.getSystemId());
				addErrorMessage(databaseDetailsMap, "Database Details not found.");
				logger.info("getApplicationDatabaseDetails method execution ended.");
				return databaseDetailsMap;
			}
			if (!checkMandatoryDatabaseDetails(databaseList.get(0), databaseDetailsMap)) {
				databaseDetailsKeyGenerator(databaseDetailsMap, databaseList);
			}
		} catch (Exception exception) {
			logger.error("Error occured at getProductCodeDetails method " + exception.getMessage());
			logger.info("getApplicationDatabaseDetails method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("getApplicationDatabaseDetails method execution ended."+databaseDetailsMap);
		return databaseDetailsMap;
		
	}


	
	/**
	 * databaseDetailsKeyGenerator for default key getting for database details
	 * 
	 * @param databaseDetailsMap
	 *            where key value is to be added
	 * @param databaseList
	 *            contains database list
	 */
	private static void databaseDetailsKeyGenerator(Map<String, Object> databaseDetailsMap,
			List<Map<String, Object>> databaseList) {
		logger.info("databaseDetailsKeyGenerator method execution started.");
		String dbUrl = ViewObjectConstants.POSTGRESQL_DB + databaseList.get(0).get("ip_address").toString()
				+ ":" + databaseList.get(0).get("port").toString() + "/"
				+ databaseList.get(0).get("database_name").toString();
		databaseDetailsMap.put(ViewObjectConstants.URL_KEY, dbUrl);
		databaseDetailsMap.put(ViewObjectConstants.DRIVER_KEY, QueryUtils.getDriver(dbUrl));
		databaseDetailsMap.put(ViewObjectConstants.USER,
				String.valueOf(databaseList.get(0).get("database_username")));
		databaseDetailsMap.put(ViewObjectConstants.PASSKEY,
				TokenManipulation.decryptToken(String.valueOf(databaseList.get(0).get("database_password"))));
		databaseDetailsMap.put(ViewObjectConstants.SCHEMA,
				String.valueOf(databaseList.get(0).get("database_schema")));
		databaseDetailsMap.put(ViewObjectConstants.DATABASE_NAME,
				String.valueOf(databaseList.get(0).get("database_name")));
		databaseDetailsMap.put(ViewObjectConstants.HOST, String.valueOf(databaseList.get(0).get("ip_address")));
		databaseDetailsMap.put(ViewObjectConstants.PORT, String.valueOf(databaseList.get(0).get("port")));
		logger.info("databaseDetailsKeyGenerator method execution ended.");
	}

	/**
	 * checkMandatoryDatabaseDetails used database details are present in value from
	 * table
	 * 
	 * @param productDetailsMap
	 *            contains database details
	 * @param databaseDetailsMap
	 *            to put error message
	 * @return true if error or false if all details are present.
	 */
	public static boolean checkMandatoryDatabaseDetails(Map<String, Object> productDetailsMap,
			Map<String, Object> databaseDetailsMap) {
		if (Objects.isNull(productDetailsMap.get("ip_address"))
				|| StringUtils.isEmpty(productDetailsMap.get("ip_address").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(""));
			return true;
		} else if (Objects.isNull(productDetailsMap.get("port"))
				|| StringUtils.isEmpty(productDetailsMap.get("port").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(""));
			return true;
		} else if (Objects.isNull(productDetailsMap.get("database_name"))
				|| StringUtils.isEmpty(productDetailsMap.get("database_name").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(""));
			return true;
		} else if (Objects.isNull(productDetailsMap.get("database_username"))
				|| StringUtils.isEmpty(productDetailsMap.get("database_username").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(""));
			return true;
		} else if (Objects.isNull(productDetailsMap.get("database_password"))
				|| StringUtils.isEmpty(productDetailsMap.get("database_password").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(""));
			return true;
		} else if (Objects.isNull(productDetailsMap.get("database_schema"))
				|| StringUtils.isEmpty(productDetailsMap.get("database_schema").toString().trim())) {
			addErrorMessage(databaseDetailsMap,
					getMessageDefintionText(""));
			return true;
		}
		return false;
	}

	/**
	 * getMessageDefintionText for getting message value from cache
	 * 
	 * @param messageId
	 *            key for message value
	 * @return message entries value
	 */
	public static String getMessageDefintionText(String messageId) {
		
		return messageId;
	}

	
	
	/**
	 * bindConfigTableWithColumn binds the column name with configuration table.
	 * @param objectData
	 * @return
	 */
	public static String bindConfigTableWithColumn(String columnName) {
		return ViewObjectConstants.VIEW_OBJECT_DEFINITION+"."+columnName;
	}
	
	
	/**
	 * bindDetailTableWithColumnDetails binds the column name with column details table
	 * @param objectData
	 * @return
	 */
	public static String bindDetailTableWithColumnDetails(String columnName) {
		return ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS+"."+columnName;
	
	}
	
	
	/**
	 * bindHistoryTableWithColumn binds the column name with history details table
	 * @param objectData
	 * @return
	 */
	public static String bindHistoryTableWithColumn(String columnName) {
		return ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS+"."+columnName;
	
	}
	
	
	/**
	 * prepareDataForConfiguraton prepares the data for the configuration/definition table
	 * @param viewObjectMap
	 * @param configurationMap
	 */
	public static void prepareDataForConfiguraton(Map<String,Object> viewObjectMap ,Map<String,Object> configurationMap) {
		Map<String,Object> bufferViewMap = new HashMap<String, Object>();
		for (Entry<String, Object> dataEntry : configurationMap.entrySet()) {
			if(StringUtils.contains(ViewObjectConstants.VIEW_OBJECT_DEFINITION, dataEntry.getKey())) {
				bufferViewMap.put(bindConfigTableWithColumn(dataEntry.getKey()), dataEntry.getValue());         			
			}
		}
		viewObjectMap.put(ViewObjectConstants.CONFIG_TABLE_DATA, bufferViewMap);
		
	}
	
	/**
	 * prepareDataForColumnDetails prepares the data for the column details table
	 * @param viewObjectMap
	 * @param configurationMap
	 */
	public static void prepareDataForColumnDetails(Map<String,Object> viewObjectMap ,List<Map<String,Object>> configurationList) {
		List<Map<String,Object>> bufferViewList = new ArrayList<Map<String,Object>>();
		for (Map<String,Object> configMap : configurationList) {
			Map<String,Object> bufferViewMap = new HashMap<String, Object>();
			for (Entry<String, Object> dataEntry : configMap.entrySet()) {
				if(StringUtils.contains(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS, dataEntry.getKey())) {
					bufferViewMap.put(bindDetailTableWithColumnDetails(dataEntry.getKey()), dataEntry.getValue());         			
				}
			}
			bufferViewList.add(bufferViewMap);
		}
		viewObjectMap.put(ViewObjectConstants.COLUMN_DETAILS, bufferViewList);
		
	}
	
	
	/**
	 * addErrorList for all errors in occuring in creation/recreation process
	 * @param returnMap
	 * @param errorMessage
	 */
	public static void addErrorList(Map<String, Object> returnMap, String errorMessage) {
		logger.info("addErrorList method execution started.");
	    List<String> errorList = new ArrayList<String>();
		if(returnMap.containsKey("errorList") && Objects.nonNull(returnMap.get("errorList"))) {
			errorList = (List<String>) returnMap.get("errorList");
		}
		errorList.add(errorMessage);
		returnMap.put("errorList", errorList);
		logger.info("addErrorList method execution ended.");
	}
	
	
	 /**
	  * prepareSourceDataForChangeRequest prepares data for changerequest
	 * @param paramMap
	 * @return
	 */
	public static Map<String,Object> prepareSourceDataForChangeRequest(Map<String, Object> paramMap){
		 ObjectMapper mapper = new ObjectMapper();
	     mapper.setDateFormat(DateTimeUtils.DEFAULT_TIME_STAMP_FORMATTER);
	     try{
	    	 paramMap.put("changeRequestType", "2");
	         if(!paramMap.containsKey("username") && !paramMap.containsKey("ownername")  && !paramMap.containsKey("ownerDomainName") ) {
	        	 paramMap.put("username", ContextBean.getUserId()) ;
	        	 paramMap.put("ownername", ContextBean.getUserId()) ;
	        	 paramMap.put("ownerDomainName", ContextBean.getUserId()) ;
	         }
	         return paramMap;
	     }catch(Exception e){
	    	 logger.error(e);
	     }
		 return paramMap;
	 }
	 
	/**
	 * checkForOnlySourceCode return whether the process to only generate source code or not
	 * @param viewObjectMap
	 * @return boolean
	 */
	public static boolean checkForOnlySourceCode(Map<String,Object> viewObjectMap) { 
		 return Boolean.parseBoolean(Objects.toString(viewObjectMap.get("status_flag"),"false")) && 
				 !StringUtils.equals("RELEASED", Objects.toString(viewObjectMap.get("source_status"),"")) ;
			
	}
	
	
	
	/**
	 * getConfigConstraintKeys method returns constraint columns for the corresponding columns
	 * 
	 * @return updateConstraintList
	 */
	public static String[] getConfigConstraintKeys() {
		String[] updateConstraintList = {ViewObjectConstants.VIEW_OBJECT_NAME,ViewObjectConstants.VERSION_NO,ViewObjectConstants.PRODUCT_CODE_COL,"tenant_id"};
		return updateConstraintList;
	}

	/**
	 * getConfigUpdateKeys method returns  columns to be updated for the corresponding columns
	 * 
	 * @return updateColumnList
	 */

	public static List<String> getConfigUpdateKeys() {
		List<String> updateColumnList = Arrays.asList("product_code","view_object_name","main_table","description",
				"object_details","condition_details","tables_with_alias","updated_at","updated_by","concat_column_details","multiple_schema_flag","status_flag","expression_columns","source_status","view_flag","error_message","version_no","tenant_id","keyword_flag","mat_view_flag","manual_flag","active_flag");
		return updateColumnList;
	}

	
	/**
	 * getColumnConstraintKeys method returns constraint columns for the corresponding columns
	 * 
	 * @return updateColumnList
	 */
	public static String[] getColumnConstraintKeys() {
		String[] updateConstraintList = {"tenant_id","version_no","view_object_name","table_name","column_name","table_alias_name","alias_name","product_code"};
		return updateConstraintList;
	}

	
	/**
	 * getColumnUpdateKeys method returns  columns to be updated for the corresponding columns
	 * 
	 * @return updateColumnList
	 */
	public static List<String> getColumnUpdateKeys() {
		List<String> updateColumnList = Arrays.asList("product_code","view_object_name","table_name","column_name","alias_name","table_alias_name","updated_at","updated_by","tenant_id","encrypt_flag");
		return updateColumnList;
	}
	
	
	
	/**
	 * appendUserDetails method is used to get the insert username and
	 * the inserted date.
	 * 
	 * @param valuesMap
	 * @param userName
	 */
	public static void appendUserDetails(Map<String, Object> valuesMap,
			String tableName, String userName) {
		valuesMap.put(tableName + ".created_by", userName);
		valuesMap.put(tableName + ".created_at",
				new Timestamp(new Date().getTime()));
		valuesMap.put(tableName + ".updated_by", userName);
		valuesMap.put(tableName + ".updated_at",
				new Timestamp(new Date().getTime()));
	}
	
	
	
	/**
	 * setRequestId returns the request id from the changerequest 
	 * @param dataMap
	 * @return
	 */
	public static String setRequestId(Map<String, Object> dataMap) {
		logger.info("*** setRequestId Method Execution started ***");
		Map<String, Object> requestDataMap = (Map<String, Object>) dataMap.get(ViewObjectConstants.REQUEST_DATA);
		if(Objects.nonNull(requestDataMap) && !requestDataMap.isEmpty()) {
		if(Objects.nonNull(requestDataMap.get(ViewObjectConstants.ADD_TO_EXISTING)) && !StringUtils.isEmpty(String.valueOf(requestDataMap.get(ViewObjectConstants.ADD_TO_EXISTING)))){
			return String.valueOf(requestDataMap.get(ViewObjectConstants.ADD_TO_EXISTING));
		}else{
			return StringUtils.EMPTY;
		}
		}else {
			return StringUtils.EMPTY;
		}
	}

	/**
	 * setRequestDescription returns the description from the changerequest 
	 * @param dataMap
	 * @return
	 */
	public static String setRequestDescription(Map<String, Object> dataMap) {
		logger.info("*** setRequestDescription Method Execution started ***");
		Map<String, Object> requestDataMap = (Map<String, Object>) dataMap.get(ViewObjectConstants.REQUEST_DATA);
		if(Objects.nonNull(requestDataMap) && !requestDataMap.isEmpty()) {
		if(Objects.nonNull(requestDataMap.get(ViewObjectConstants.REQUEST_DESCRIPTION)) && !StringUtils.isEmpty(String.valueOf(requestDataMap.get(ViewObjectConstants.REQUEST_DESCRIPTION)))){
			return Objects.toString(requestDataMap.get(ViewObjectConstants.REQUEST_DESCRIPTION),"");
		}else{
			return StringUtils.EMPTY;
		}
		}else {
			return StringUtils.EMPTY;
		}
	}
	
	
	
	 /**
	  * getUpperCamelCase is to retrieve upper camel case of a String
	 * @param key
	 * @return
	 */
	public static String getUpperCamelCase(String key) {
		logger.info("*** getUpperCamelCase Method Excuetion started ***");
			StringBuilder result = new StringBuilder("");
			result.append(String.valueOf(key.charAt(0)).toUpperCase());
			int index = 1; 
			 while (index < key.length()) {
				String character = String.valueOf(key.charAt(index));
				if("_".equals(character)){
					character = String.valueOf(key.charAt(++index)).toUpperCase();
				}
				 index++;
				result.append(character);
			}
			 logger.info("*** getUpperCamelCase Method Excuetion ended ***");
			return result.toString();
		}
	

	/**
	 * checkForExistingRequest method checks for the existing change request
	 * @param paramMap
	 * @return
	 */
	public static Boolean checkForExistingRequest(Map<String, Object> paramMap) {
		logger.info("*** checkForExistingRequest Method Excuetion started ***");
		if(paramMap.containsKey(ViewObjectConstants.REQUEST_DATA)){
			Map<String, Object> requestDataMap = (Map<String, Object>) paramMap.get(ViewObjectConstants.REQUEST_DATA);
			if(Objects.nonNull(requestDataMap) && Objects.nonNull(requestDataMap.get(ViewObjectConstants.ADD_TO_EXISTING)) && !requestDataMap.get(ViewObjectConstants.ADD_TO_EXISTING).toString().isEmpty()){
				paramMap.put("existingRequestId", requestDataMap.get(ViewObjectConstants.ADD_TO_EXISTING).toString());
				logger.info("*** checkForExistingRequest Method Excuetion completed ***");
				return true;
			}else{
				logger.info("*** checkForExistingRequest Method Excuetion completed ***");
				return false;
			}
		}
		logger.info("*** checkForExistingRequest Method Excuetion completed ***");
		return false;
	}	
	
	/**
	 * getVersion method is to retrieve version from change request
	 * @param changeRequestId
	 * @return
	 * @throws CustomException 
	 */
	public static String getVersion(String changeRequestId,QueryBuilder queryBuilder) throws CustomException {
        List<Map<String, Object>> resultList;
		try {
			resultList = queryBuilder.select().from("change_request").where(ConditionBuilder.instance().eq("change_request_id", changeRequestId)
			        .and().eq("data_system_id", "1")).build(false).execute();
        if(!resultList.isEmpty()) {
            return Objects.isNull(resultList.get(0).get("product_version")) ? null : String.valueOf(resultList.get(0).get("product_version"));
        }
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
        return null;
    }
	
	
	 /**
	    * getChangeRequestStage method is used to get the stage of current change
	    * request
	    * 
	    * @param changeRequestId
	    * @return
	 * @throws CustomException 
	    */
	   public static Boolean isSourceCodeGeneration(String viewObject,QueryBuilder queryBuilder,String versionNumber,String productCode) throws CustomException {
		   logger.info("isSourceCodeGeneration method started"+ viewObject);
		   boolean isSource = false;
	       List<Map<String, Object>> deploymentStatusList;
		try {
			deploymentStatusList = queryBuilder.select().checkIndependentTenant(true).from(ViewObjectConstants.VIEW_OBJECT_DEFINITION).where(ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.VERSION_NO, versionNumber).and().eq(ViewObjectConstants.PRODUCT_CODE, productCode)).build(false).execute();
	       if (CollectionUtils.isEmpty(deploymentStatusList)) {
	    	   isSource= true;
	       } else {
	    	   Map<String,Object> releaseStatusMap = deploymentStatusList.get(0);
	           if(!StringUtils.equalsIgnoreCase(Objects.toString(releaseStatusMap.get("source_status"), ""),"FAILURE")){
	        	   isSource= true;   
	           }else{
	        	   isSource= false;
	           }
	       }
	       logger.info("isSourceCodeGeneration method ends with condition"+ isSource);
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
	       return isSource;
	   }

	   
	   
	   /**
	    * updateSourceCodeStatus method is to update source code status after deployment process
	 * @param viewObject
	 * @param status
	 * @param queryBuilder
	 * @throws CustomException
	 */
	public static void updateSourceCodeStatus(String viewObject,boolean status,QueryBuilder queryBuilder,String versionNumber) throws CustomException {
			try{
				 logger.info("updateSourceCodeStatus method started"+ viewObject);
	 				 Map<String,Object> updateMap = new HashMap<>();
	 				 if(status){
	 					 updateMap.put(bindConfigTableWithColumn("source_status"), "INPROGRESS");
	 				 }else{
	 					 updateMap.put(bindConfigTableWithColumn("source_status"), "FAILURE");
	 				 }
	 				updateViewObject(viewObject, updateMap, queryBuilder,versionNumber);
			} catch (Exception exception) {
				logger.error(exception);
				throw new CustomException(exception);
			}
		} 
	
	

	public static void updateGitFailureStatus(String viewObject,boolean status,String versionNumber) throws CustomException {
		try{
			 logger.info("updateGitFailureStatus method started"+ viewObject);
				 Map<String,Object> updateMap = new HashMap<>();
				 QueryBuilder queryBuilder = new QueryBuilder();
					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("source_status"), "GIT_FAILURE");
					 updateViewObject(viewObject, updateMap, queryBuilder,versionNumber);
				 logger.info("updateGitFailureStatus method ends");
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}
	
	
	/**
	 * updateViewObject method is to update the View object data in the table
	 * @param viewObject
	 * @param updateMap
	 * @param queryBuilder
	 * @throws CustomException
	 */
	public static void updateViewObject(String viewObject,Map<String,Object> updateMap,QueryBuilder queryBuilder,String versionNumber) throws CustomException {
		try{
			 logger.info("updateViewObject method started"+ viewObject);
					 queryBuilder.update().skipTenantId(true).skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.VERSION_NO, versionNumber));
				 logger.info("updateViewObject method ends");
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}
	
	
	/**
	 * setCrDataToExecutor method is to set change request to the executor
	 * @param viewObjectMap
	 * @param configDataMap
	 * @param requestMap
	 * @param queryExecutor
	 * @throws CustomException
	 */
	public static void setCrDataToExecutor(Map<String,Object> viewObjectMap,Map<String,Object> configDataMap,Map<String,Object> requestMap,QueryExecutor queryExecutor) throws CustomException {
		try{
			 logger.info("updateViewObject method started");
			 queryExecutor.setDatabaseHandler(String.valueOf(configDataMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("database_handler"))));
			 queryExecutor.setChangeRequestTitle(ViewObjectCommonUtils.setRequestDescription(viewObjectMap));
		     requestMap.put("productVersion", EnvironmentReader.getPropertyValue("product.version"));
		     queryExecutor.setChangeRequestDetails(requestMap);
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
		}

	
	/**
	 * getFolderPath is used to form folder path to commit the file
	 * @param packageName
	 * @return
	 */
	public static String getFolderPath(String packageName) {
		return packageName.indexOf('.') != -1 ? packageName.replace(".",
				File.separator) : "";
	}
	
	
	
	/**
	 * getFolderPath is used to form folder path to commit the file
	 * @param packageName
	 * @return
	 */
	public static String formSourceCodePath(String sourceBranchId,String repoName,String sourcePath) {
		return  System.getProperty("catalina.home") + File.separator + "Users" + File.separator
				+ ContextBean.getUserId() + File.separator  + sourceBranchId + File.separator+ repoName + File.separator + "src" + File.separator + "main"
				+ File.separator + "java" + File.separator + sourcePath + File.separator;
	}

	/**
	 * prepareDataForGitProcess prepare data for the GIT operations
	 * @param sourceCodeMap
	 * @param repoName
	 * @param tagName
	 * @return
	 */
	public static Map<String, String> prepareDataForGitProcess(Map<String, Object> sourceCodeMap, String repoName,
			String tagName) {
		 Map<String, String> gitUtilsMap= new  HashMap<String, String>();
		gitUtilsMap.put("gitUrl", Objects.toString(sourceCodeMap.get(ViewObjectConstants.GIT_URL)));
         gitUtilsMap.put("userToken", Objects.toString(sourceCodeMap.get("userToken")));
         gitUtilsMap.put("nameSpace",Objects.toString(sourceCodeMap.get("nameSpace")));
         gitUtilsMap.put("projectName",repoName );
         gitUtilsMap.put("branchName", tagName);
		return gitUtilsMap;
	}	
	

	/**
	 * upsertConfigWithMap upserts data with map in the database
	 * @param viewObjectMap
	 * @param configDataMap
	 * @param metaQueryExecutor
	 * @throws CustomException
	 */
	public static void upsertConfigWithMap(Map<String,Object> viewObjectMap,Map<String,Object> configDataMap,QueryExecutor metaQueryExecutor) throws CustomException{
		try {
			metaQueryExecutor.queryBuilder().insert().skipTenantId(true).setChangeRequestId(ViewObjectCommonUtils.setRequestId(viewObjectMap))
			.setChangeRequestTitle(ViewObjectCommonUtils.setRequestDescription(viewObjectMap)).upsertWithKeyList(ViewObjectConstants.VIEW_OBJECT_DEFINITION, Arrays.asList(configDataMap), true,ViewObjectCommonUtils.getConfigUpdateKeys(),ViewObjectCommonUtils.getConfigConstraintKeys());
		} catch (Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}
	
	
	
	

	/**
	 * @param viewName
	 * @param metaQueryExecutor
	 * @return
	 * @throws CustomException 
	 */
	public static String getConditionForLangDependent(String viewName, QueryExecutor metaQueryExecutor) throws CustomException {
		logger.info("getConditionForLangDependent method started  for condition");
		String conditionValue = "";
		ConditionBuilder viewConditionBuilder = ConditionBuilder.instance();
		viewConditionBuilder.eq("objCol.view_object_name", viewName);
		ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq("objCol.table_name","conCol.table_name",true).and().eq("objCol.column_name","conCol.column_name",true).and().eq("objCol.product_code","conCol.product_code",true).and().eq("conCol.lang_dependent_flag", true);
		List<Map<String, Object>> langDependentTables;
		try {
			langDependentTables = metaQueryExecutor.queryBuilder().select().checkIndependentTenant(true).distinct().get("objCol.table_name","objCol.table_alias_name").from(ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS,"objCol").join("table_definition_column_details", "conCol", conditionBuilder).where(viewConditionBuilder).build(false).execute();
		
		Set<String> langDepAliasNames = langDependentTables.stream().map(action-> String.valueOf(action.get("table_alias_name"))).collect(Collectors.toSet());
		if(!langDepAliasNames.isEmpty()){
			AtomicBoolean atCheck = new AtomicBoolean(false);
			StringBuilder conditionBuilderString = new StringBuilder();
			for (String langTable : langDepAliasNames) {
				if(atCheck.get()){
					conditionBuilderString.append(".and()");
				}
				conditionBuilderString.append(".brackets(ConditionBuilder.instance().eq(\""+langTable+"_locale\",ContextBean.getLocale()).or().eq(\""+langTable+"_locale\",\"\").or().isNull(\""+langTable+"_locale\"))");
				atCheck.set(true);
			}
			conditionValue = conditionBuilderString.toString();
		}
		logger.info("getConditionForLangDependent method compelted and condition value is" +conditionValue);
		} catch (Exception exp) {
			throw new CustomException(exp);
		}
		return conditionValue;
	}
	
	/**
	 * commitProductExecutor commits the product executor
	 * @param productExecutorMap
	 * @throws CustomException
	 */
	public static void commitProductExecutor(Map<String,Object> viewObjectMap) throws CustomException{
		try {
			if(viewObjectMap.containsKey("productExecutorMap") && Objects.nonNull(viewObjectMap.get("productExecutorMap"))) {
				Map<String,Object> productExecutorMap = (Map<String, Object>) viewObjectMap.get("productExecutorMap");
				if(Objects.nonNull(productExecutorMap)){
					for(Entry<String,Object> prodExe :productExecutorMap.entrySet()){
						if(Objects.nonNull(prodExe.getValue())){
							QueryExecutor prodExecutor = (QueryExecutor) prodExe.getValue();
								prodExecutor.commit();
						}
					}
				}
			}
		} catch (Exception exp) {
			throw new CustomException(exp);
		}
	}
	
	/**
	 * rollBackProductExecutor method is to rollback the product executor
	 * @param viewObjectMap
	 * @throws CustomException
	 */
	public static void rollBackProductExecutor(Map<String,Object> viewObjectMap) throws CustomException{
		try {
			if(viewObjectMap.containsKey("productExecutorMap") && Objects.nonNull(viewObjectMap.get("productExecutorMap"))) {
				Map<String,Object> productExecutorMap = (Map<String, Object>) viewObjectMap.get("productExecutorMap");
				if(Objects.nonNull(productExecutorMap)){
					for(Entry<String,Object> prodExe :productExecutorMap.entrySet()){
						if(Objects.nonNull(prodExe.getValue())){
							QueryExecutor prodExecutor = (QueryExecutor) prodExe.getValue();
								prodExecutor.rollBack();
						}
					}
				}
			}
		} catch (Exception exp) {
			throw new CustomException(exp);
		}
	}
	
	public static SelectQueryBuilder buildQueryBuilderForView(Map<String,Object> paramMap, QueryBuilder queryBuilder){
		Map<String, Object> objectDetailsMap = new HashMap<>();
		ObjectMapper objMapper = new ObjectMapper();
		SelectQueryBuilder selectQueryBuilder =  queryBuilder.select();
		 Map<String, Object> configDataMap = (Map<String, Object>)paramMap.get(ViewObjectConstants.CONFIG_TABLE_DATA);
	try {
		if(Objects.nonNull(configDataMap) && !configDataMap.isEmpty() ){
			List<Map<String,Object>> configDataList = (List<Map<String,Object>>)paramMap.get(ViewObjectConstants.COLUMN_DETAILS);
			Map<String,Object> tableObjectConfig = configDataMap;
		objectDetailsMap = objMapper.readValue(String.valueOf(tableObjectConfig.get(ViewObjectCommonUtils.bindConfigTableWithColumn("object_details"))), Map.class);
		String mainTable = String.valueOf(objectDetailsMap.get("mainTableName"));
		String aliasName =  String.valueOf(objectDetailsMap.get("mainTableAliasName"));
		boolean isDistinct = Boolean.parseBoolean(String.valueOf(objectDetailsMap.get("isDistinct")));
		if(isDistinct) {
			selectQueryBuilder.distinct();
		}
	   setColumnNames(selectQueryBuilder,configDataList);
	   selectQueryBuilder.skipPropertyFlag(true).from(mainTable,aliasName);
	   ConditionBuilder conditionBuilder =ConditionBuilder.instance();
	   if(objectDetailsMap.containsKey(ViewObjectConstants.JOINS) && Objects.nonNull(objectDetailsMap.get(ViewObjectConstants.JOINS))){
        List<Map<String,Object>>joinArrayList = (List<Map<String, Object>>) objectDetailsMap.get(ViewObjectConstants.JOINS);
        boolean join = false;
        String joinTableName = "";
        String joinTableAliasName = "";
        String joinType = "";
        ConditionBuilder joinConditionBuilder =ConditionBuilder.instance();
        for (int index = 0; index < joinArrayList.size(); index++) {
        	Map<String,Object> joinObjectMap = joinArrayList.get(index);
        	Map<String,Object>groupConditionsMap  = (Map<String, Object>) joinObjectMap.get("group");
        	  joinConditionBuilder = buildGroup(groupConditionsMap, false, joinConditionBuilder);
        	  joinTableName = String.valueOf(joinObjectMap.get("tableName"));
              joinTableAliasName = String.valueOf(joinObjectMap.get("aliasName"));
        	  getForJoinType(selectQueryBuilder,String.valueOf(joinObjectMap.get("joinType")),joinTableName,joinTableAliasName,joinConditionBuilder);
        	  joinConditionBuilder =ConditionBuilder.instance();
        }
	   }
        
	   if(objectDetailsMap.containsKey(ViewObjectConstants.WHERE_CONDITIION) && Objects.nonNull(objectDetailsMap.get(ViewObjectConstants.WHERE_CONDITIION))){
		   conditionBuilder = ConditionBuilder.instance();
		   List<Map<String,Object>>whereArrayList = (List<Map<String, Object>>) objectDetailsMap.get(ViewObjectConstants.WHERE_CONDITIION);
		   for (int index = 0; index < whereArrayList.size(); index++) {
	        	Map<String,Object> whereGroupMap = whereArrayList.get(index);
	        	Map<String,Object>groupConditionsMap = (Map<String, Object>) whereGroupMap.get("group");
	        	  conditionBuilder = buildGroup(groupConditionsMap, false, conditionBuilder);
		   }
		   selectQueryBuilder.where(ConditionBuilder.instance(conditionBuilder));
	   }
	    }
	}catch (IOException e) {
		e.printStackTrace();
	    }
 	    return selectQueryBuilder;
	   }
	
	private static void setColumnNames(SelectQueryBuilder selectQueryBuilder,List<Map<String, Object>> columnDataList) {
		if(Objects.nonNull(columnDataList) && !columnDataList.isEmpty() ){
		for (Map<String,Object> columnData : columnDataList) {
			selectQueryBuilder.getWithAliasName(String.valueOf(columnData.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_alias_name"))) +"."+String.valueOf(columnData.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("column_name"))), String.valueOf(columnData.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("alias_name"))));
		}
		}
	}

	private static void getForJoinType(SelectQueryBuilder selectQueryBuilder,
			String joinType, String joinTableName, String joinTableAliasName, ConditionBuilder conditionBuilder) {
		switch(joinType){
		case ViewObjectConstants.LEFT_JOIN:
			selectQueryBuilder.join(joinTableName, joinTableAliasName, ConditionBuilder.instance(conditionBuilder));
			break;
		case ViewObjectConstants.RIGHT_JOIN:
			selectQueryBuilder.rightJoin(joinTableName, joinTableAliasName, ConditionBuilder.instance(conditionBuilder));
			break;
		case ViewObjectConstants.INNER_JOIN:	
		default:	
			selectQueryBuilder.join(joinTableName, joinTableAliasName, ConditionBuilder.instance(conditionBuilder));
			break;
		}
	}
	 private static ConditionBuilder buildGroup(Map<String, Object> groupMap, boolean isWhere,ConditionBuilder conditionBuilder) {
		 if(groupMap.containsKey("conditions") && Objects.nonNull(groupMap.containsKey("conditions"))) {
			 List<Map<String,Object>> conditionList =  (List<Map<String, Object>>) groupMap.get("conditions");
			 if(!conditionList.isEmpty()) {
			for(Map<String,Object> conditionMap : conditionList) {
			if(!conditionBuilder.getQuery().isEmpty()){
				  appendAndOrCondition(conditionBuilder, String.valueOf(groupMap.get("operator"))); 
			  }
			buildCondition(conditionBuilder, conditionMap, false);
			 }
		 } 
		 }
		 if(groupMap.containsKey("childGroup") && Objects.nonNull(groupMap.containsKey("childGroup"))) {
			 List<Map<String, Object>> childGroupList =  (List<Map<String, Object>>) groupMap.get("childGroup");
			 if(!childGroupList.isEmpty()) {
				 for(int i = 0; i < childGroupList.size(); i++) {
					 ConditionBuilder tempConditionBuilder = ConditionBuilder.instance();
					 if(!conditionBuilder.getQuery().isEmpty()){
						 Map<String, Object> childGroupMap = childGroupList.get(i);
						 appendAndOrCondition(conditionBuilder, String.valueOf(groupMap.get("operator"))); 
						 tempConditionBuilder = buildGroup(childGroupMap, isWhere, tempConditionBuilder);
				       conditionBuilder.brackets(ConditionBuilder.instance(tempConditionBuilder)); 
					 }
				 }
			 }
		 } 
		return conditionBuilder;
	}
	 
	 
	 private static ConditionBuilder buildChildGroup(List<Map<String, Object>> childGroupList, boolean isWhere, ConditionBuilder conditionBuilder) {
		 for (int i = 0; i < childGroupList.size(); i++) {
			 Map<String, Object> childGroupMap = childGroupList.get(i);
			 if(!childGroupMap.isEmpty()) {
				 if(!conditionBuilder.getQuery().isEmpty()){
					 appendAndOrCondition(conditionBuilder, String.valueOf(childGroupMap.get("operator"))); 
				 }
				 conditionBuilder = buildGroup(childGroupMap, isWhere, conditionBuilder) ;
			 } 
		}
		 return conditionBuilder;
	 }
	 private static void buildCondition(ConditionBuilder conditionBuilder,Map<String, Object> groupMap,boolean isWhere) {
			String opertorCondition = String.valueOf(groupMap.get("operator"));
			if(!isWhere){
			switch(opertorCondition){
			case "<>":
			case "!=":
				conditionBuilder.notEq(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)),true);
				break;
			case ">":	
				conditionBuilder.gt(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)),true);
				break;
			case "<":	
				conditionBuilder.lt(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)),true);
				break;
			case ">=":	
				conditionBuilder.gte(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)),true);
				break;	
				
			case "<=":	
				conditionBuilder.lte(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)),true);
				break;
			
			case "is":	
				if(StringUtils.equals(String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)).toLowerCase(),"null")){
					conditionBuilder.isNull(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)));
				}else if (StringUtils.equals(String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)).toLowerCase(),"not null")){
					conditionBuilder.isNotNull(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)));
				}
				
				break;
			
			case "like":	
				conditionBuilder.like(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)));
				break;
			
			case "ilike":	
				conditionBuilder.ilike(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)));
				break;	
				
				
			case "=":
				default:
				conditionBuilder.eq(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)),true);
				break;	
			}
			}else{
			switch(opertorCondition){
			case "<>":
			case "!=":
				conditionBuilder.notEq(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), QueryUtils.toQuotedString(Objects.toString(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION),"")),true);
				break;
			case ">":	
				conditionBuilder.gt(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), QueryUtils.toQuotedString(Objects.toString(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION),"")),true);
				break;
			case "<":	
				conditionBuilder.lt(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), QueryUtils.toQuotedString(Objects.toString(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION),"")),true);
				break;
			case ">=":	
				conditionBuilder.gte(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), QueryUtils.toQuotedString(Objects.toString(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION),"")),true);
				break;	
				
			case "<=":	
				conditionBuilder.lte(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)),QueryUtils.toQuotedString(Objects.toString(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION),"")),true);
				break;
				
			case "is":	
				if(StringUtils.equals(String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)).toLowerCase(),"null")){
					conditionBuilder.isNull(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)));
				}else if (StringUtils.equals(String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)).toLowerCase(),"not null")){
					conditionBuilder.isNotNull(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)));
				}
				
				break;
				
			case "like":	
				conditionBuilder.like(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)));
				break;
				
			case "ilike":	
				conditionBuilder.ilike(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), String.valueOf(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION)));
				break;	
				
			case "=":
				default:
				conditionBuilder.eq(String.valueOf(groupMap.get(ViewObjectConstants.LEFT_CONDITIION)), QueryUtils.toQuotedString(Objects.toString(groupMap.get(ViewObjectConstants.RIGHT_CONDITIION),"")),true);
				break;
				
			}
			}
		};
		
		private static void appendAndOrCondition(ConditionBuilder tempBuilder,String cond){
			if(cond.equalsIgnoreCase(ViewObjectConstants.AND_CONDITION)){
				tempBuilder.and();
			}else{
				tempBuilder.or();
			}
		}
		 /**
		  * prepareSourceDataForChangeRequest prepares data for changerequest
		 * @param paramMap
		 * @return
		 */
		public static Map<String,Object> prepareChangeRequestDetailsMap(Map<String, Object> paramMap){
		        Map<String,Object> changeRequestMap = new HashMap<>(); 
			try{
				changeRequestMap.put("productVersion", getSourceVersion()) ;
				changeRequestMap.put("versionNumber",StringUtils.isEmpty(Objects.toString(paramMap.get("currentVersion"))) ? Objects.toString(paramMap.get("versionNumber")) : Objects.toString(paramMap.get("currentVersion")));
				changeRequestMap.put("artifactType",ViewObjectEnum.BUSINESS_OBJECT.name());
				changeRequestMap.put("isNotReleased",true);
		     }catch(Exception e){
		    	 logger.error(e);
		     }
			 return changeRequestMap;
		 }
		
		

		/**
		 * get source version
		 * 
		 */
		public static String getSourceVersion() {
			logger.info("getSourceVersion method execution started.");
			String version = "";
			try {
				List<Map<String, Object>> versionList = new QueryBuilder().btSchema().select().from("repo_config")
						.where(ConditionBuilder.instance().eq("product_code", "sova_core").and()
								.eq("sub_product_code", "custom_designer").and().eq("repo_type", "service").and()
								.isNotNull("source_version"))
						.build(false).execute();
				if (!versionList.isEmpty()) {
					version = String.valueOf(versionList.get(0).get("source_version"));
				}
			} catch (Exception exception) {
				logger.info("getSourceVersion method execution ended." + exception.getMessage());
				logger.error(exception);

			}
			logger.info("getSourceVersion method execution ended.");
			return version;
		}


		
		/**
		 * getStatusLabel is to form the data status for the status button
		 * @param tableObjectMap
		 * @param locale
		 * @return
		 * @throws CustomException 
		 */
		public static Map<String,Object> getStatusLabel(Map<String, Object> tableObjectMap, String locale) throws CustomException{
			Map<String,Object> dataMap = new HashMap<>();
			try {
		String activeString = CacheService.getInstance().getApplicationTextDefinitionData("nn_table_definition_table_active_status", "ViewObjectDetail", ContextBean.getLocale());
		String inActiveString = CacheService.getInstance().getApplicationTextDefinitionData("nn_table_definition_table_inactive_status", "ViewObjectDetail", ContextBean.getLocale());
		String progress = CacheService.getInstance().getApplicationTextDefinitionData("nn_table_definition_table_inprogress_status", "ViewObjectDetail", ContextBean.getLocale());
		 boolean viewStatus = Objects.nonNull(tableObjectMap.get("status_flag")) ? Boolean.parseBoolean(Objects.toString(tableObjectMap.get("status_flag"),"false")) : true;
		 String sourceStatus = Objects.nonNull(tableObjectMap.get("source_status")) ? String.valueOf(tableObjectMap.get("source_status")) : "RELEASED";
		 boolean softDelete = Objects.nonNull(tableObjectMap.get("delete_flag")) ? Boolean.parseBoolean(Objects.toString(tableObjectMap.get("delete_flag"),"false")) : false;
		 String errorMessage = Objects.nonNull(tableObjectMap.get("error_message")) ? Objects.toString(tableObjectMap.get("error_message"),"") : "";
		 String statusLabel = "";
		 String icon = "inactive";
		 String buttonType;
	     String statusString;
	     if(viewStatus && StringUtils.isEmpty(sourceStatus)){
	     	statusString = "RELEASED";
	     	statusLabel= activeString;
	     	buttonType = "var(--nn-warning-lighter)";
	     	viewStatus = true;
	     	icon ="nn_active";
	     }else if(viewStatus && !StringUtils.isEmpty(sourceStatus)){
	     	if(StringUtils.equals(sourceStatus,"RELEASED")){
	     		statusString = "RELEASED";
	     		statusLabel= activeString;
	         	buttonType = "var(--nn-warning-lighter)";
	         	viewStatus = true;
	         	icon ="nn_active";
	     	}else if(StringUtils.equals(sourceStatus,"INPROGRESS")){
	     		  statusString = "INPROGRESS";
	     		 statusLabel=progress;
				  buttonType = "var(--nn-text-disabled)";
				  icon ="nn_inactive";
				  viewStatus = true;
	     	}else{
	     		statusString = "NOT_RELEASED";
	     		buttonType = "var(--nn-text-disabled)";
	     		statusLabel=inActiveString;
	     		viewStatus = false;
	     		icon ="nn_inactive";
	     	}
	     } else{
	    	 if(softDelete && !StringUtils.isEmpty(sourceStatus)){
	    		 if(StringUtils.equals(sourceStatus,"INPROGRESS")){
	        	    statusString = "INPROGRESS";
	        	    statusLabel=progress;
	   			    buttonType = "var(--nn-text-disabled)";
	   			    viewStatus = true;
	   			 icon ="nn_inactive";
	    		 }else{
	    			 statusString = "NOT_RELEASED";
	        		 buttonType = "var(--nn-text-disabled)";
	        		 statusLabel=inActiveString;
	        		 viewStatus = false;
	        		 icon ="nn_inactive";
	    		 }
	    	 }else{
	    		 statusString = "NOT_RELEASED";
	    		 buttonType = "var(--nn-text-disabled)";
	    		 statusLabel=inActiveString;
	    		 viewStatus = false;
	    		 icon ="nn_inactive";
	    	 }
	    	 
	    }
		 dataMap.put("statusLabel", Objects.toString(statusLabel, ""));
		 dataMap.put("viewStatus", viewStatus);
		 dataMap.put("statusString", statusString);
		 dataMap.put("buttonType",buttonType);
		 dataMap.put("icon",icon);
		 dataMap.put("errorMessage",errorMessage);
		 return dataMap;
			} catch (Exception exp) {
				throw new CustomException(exp.getMessage());
			}
		}
		
		/**
		 * getReleaseStatusForViewObject for freeze
		 * @param paramMap
		 * @return
		 */
		//freeze
		public static Map<String,Object> getReleaseStatusForViewObject(Map<String,Object> paramMap){
			logger.info("getReleaseStatusForViewObject method execution started.");
			try {
				if(paramMap.containsKey("changeRequestId") && Objects.nonNull(paramMap.get("changeRequestId"))) {
					paramMap.put("status", Integer.parseInt(String.valueOf(new QueryBuilder().btSchema().select().count("*", "count").from("view_object_definition").where(ConditionBuilder.instance().eq("change_request_id", paramMap.get("changeRequestId")).and()
							.brackets(ConditionBuilder.instance().inWithList("source_status", Arrays.asList(ViewObjectTypeEnum.INPROGRESS.name(), ViewObjectTypeEnum.INACTIVE.name()))
							.or().eq("status_flag", false))).build(false).execute().get(0).get("count"))) > 0 ? false : true);
				}else {
					paramMap.put("status", false);
					paramMap.put("message", "Change request id is null");
				}
			}catch(Exception exception) {
				logger.error(exception);
				paramMap.put("status", false);
				paramMap.put("message", exception.getMessage());
			}
			logger.info("getReleaseStatusForViewObject method execution ended.");
			return paramMap;
		}
	
		/**
		 * upsertTableConfiguration table_configuration table used for inserting in
		 * table configuration table
		 * 
		 * @param tableMetaExecutor contains table meta connection
		 * @param tableDetailsMap   contains table details
		 * @param editFlag          contrains edit or not
		 */
		public static void upsertTableConfiguration(QueryExecutor tableMetaExecutor, Map<String, Object> tableDetailsMap) throws CustomException {
			logger.info("upsertTableConfiguration method execution started.");
			try {
				Map<String, Object> upsertMap = new HashMap<>();
				upsertMap.put("tableConfiguration.product_code",
						tableDetailsMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("product_code")));
				upsertMap.put("tableConfiguration.table_name",
						tableDetailsMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("view_object_name")));
				upsertMap.put("tableConfiguration.database_handler",
						tableDetailsMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("database_handler")));
				upsertMap.put("tableConfiguration.table_type",
						"Transaction");
				upsertMap.put("tableConfiguration.description",
						tableDetailsMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("description")));
					upsertMap.put("tableConfiguration.cr_enable_flag", false);
					upsertMap.put("tableConfiguration.query_browser_flag", true);
				tableMetaExecutor.queryBuilder().insert().upsertWithKeyList(
						"tableConfiguration", Arrays.asList(upsertMap), true,
						Arrays.asList("product_code", "database_handler", "description"), "table_name", "product_code");
			} catch (Exception exception) {
				logger.info("upsertTableConfiguration method execution ended.");
				logger.error(exception);
				throw new CustomException(exception.getMessage());
			}
			logger.info("upsertTableConfiguration method execution ended.");
		}	
		/**
		 * insertToTableRequestDetails is used to maintain table details for the request id
		 * @param string
		 * @param changeRequestId
		 * @param paramMap
		 * @throws IvFrameworkException 
		 */
		public static void insertToTableRequestDetails(String type, String changeRequestId, Map<String, Object> paramMap) throws CustomException {
			logger.info("## insertToTableRequestDetails method execution started " + " type " + type + " changeRequestId " + changeRequestId);
			QueryExecutor historyQueryExecutor = null;
			try {
				QueryBuilder queryBuilder = new QueryBuilder();
				historyQueryExecutor = queryBuilder.getQueryExecutor();
				List<Map<String,Object>> insertRows = new ArrayList<>();
				String[] keys = {"change_request_id","table_uuid"};
				Map<String, Object> tableMap = new HashMap<>();
				tableMap.put(ViewObjectCommonUtils.bindHistoryTableWithColumn("change_request_id"), changeRequestId);
				tableMap.put(ViewObjectCommonUtils.bindHistoryTableWithColumn("table_uuid"), UUID.randomUUID());
	              if(ViewObjectTypeEnum.VIEW.name().equalsIgnoreCase(type)) {
					tableMap.put(ViewObjectCommonUtils.bindHistoryTableWithColumn("config_type") , ViewObjectTypeEnum.VIEW.name());
					tableMap.put(ViewObjectCommonUtils.bindHistoryTableWithColumn("table_json"),Objects.toString(paramMap.get("viewData")));
				}
			       ViewObjectCommonUtils.appendUserDetails(tableMap, ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS ,ContextBean.getUserId());
			       historyQueryExecutor.skipChangeRequest(true);
					historyQueryExecutor.queryBuilder().insert().upsertWithKeyList(ViewObjectConstants.TABLE_DEFINITON_REQUEST_HISTORY_DETAILS, Arrays.asList(tableMap), true,Arrays.asList("table_json","updated_by","updated_at"),keys);
				    historyQueryExecutor.commit();
				logger.info("## insertToTableRequestDetails method execution completed ");
			} catch (Exception exception) {
				if(Objects.nonNull(historyQueryExecutor)) {
					try {
						historyQueryExecutor.rollBack();
					} catch (QueryException e) {
						e.printStackTrace();
					}
				}
				logger.info("## insertToTableRequestDetails method execution failed " + exception.getMessage());
				paramMap.put("error", exception.getMessage());
				throw new CustomException("Error occured while updating table request details " + exception.getMessage());
			}
		}
		
		/**
		 * updateViewObjectStatus method is to update the View object data in the table
		 * @param viewObject
		 * @param updateMap
		 * @param queryBuilder
		 * @throws CustomException
		 */
		public static void updateViewObjectStatus(String viewObject,Map<String,Object> updateMap,QueryBuilder queryBuilder,String versionNumber,String productCode) throws CustomException {
			try{
				 logger.info("updateViewObject method started"+ viewObject);
						 queryBuilder.update().skipTenantId(true).skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.VERSION_NO, versionNumber).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
					 logger.info("updateViewObject method ends");
			} catch (Exception exception) {
				logger.error(exception);
				throw new CustomException(exception);
			}
		}
		
		/**
		 * updateProgramBusinessObject program_business_object table update
		 * 
		 * @param tableNameList contains tableNameList to be updated
		 * @throws CustomException
		 */
		public static void updateProgramBusinessObject(List<Object> tableNameList,boolean deleteFlag) throws CustomException {
			logger.info("updateProgramBusinessObject method execution started.");
			try {
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put("program_business_object.modified_flag", true);
				updateMap.put("program_business_object.release_flag", true);
				if(deleteFlag) {
					updateMap.put("program_business_object.is_deleted", true);
				}
				new QueryBuilder().update().skipChangeRequest(true).forceUpdate(true).updateWithMap(
						"program_business_object", updateMap,
						ConditionBuilder.instance().inWithList("business_object_name", tableNameList));
			} catch (Exception exception) {
				logger.error(exception);
				logger.info("updateProgramBusinessObject method execution ended.");
				throw new CustomException(exception.getMessage());
			}
			logger.info("updateProgramBusinessObject method execution ended.");
		}

		/**
		 * updateViewObject method is to update the View object data in the table
		 * @param viewObject
		 * @param updateMap
		 * @param queryBuilder
		 * @throws CustomException
		 */
		public static void updateViewObjectStatus(String viewObject,String versionNumber,String productCode,boolean successFlag,String message) throws CustomException {
			try{
				 logger.info("updateViewObject method started"+ viewObject);
				 QueryBuilder queryBuilder= new QueryBuilder();
				 Map<String,Object> updateMap = new HashMap();
				 Map<String,Object> activeMap = new HashMap();
				 if(successFlag) {
	 					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("source_status"), "RELEASED");
	 					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("error_message"), "");
	 					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("status_flag"), true);
	 				 }else{
	 					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("source_status"), "FAILURE");
	 					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("status_flag"), true);
	 					 updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("error_message"), message);
	 				 }
	 				updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("active_flag"), true);
	 				queryBuilder.update().skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, updateMap, ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().eq(ViewObjectConstants.VERSION_NO, versionNumber).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
	 				activeMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("active_flag"), false);
				    queryBuilder.update().skipTenantId(true).skipChangeRequest(true).updateWithMap(ViewObjectConstants.VIEW_OBJECT_DEFINITION, activeMap, ConditionBuilder.instance().eq(ViewObjectConstants.VIEW_OBJECT_NAME, viewObject).and().not().eq(ViewObjectConstants.VERSION_NO, versionNumber).and().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode));
					logger.info("updateViewObject method ends");
			} catch (Exception exception) {
				logger.error(exception);
				throw new CustomException(exception);
			}
		}
		
		
}
