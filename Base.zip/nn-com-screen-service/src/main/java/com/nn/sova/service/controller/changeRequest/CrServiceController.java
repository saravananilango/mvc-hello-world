package com.nn.sova.service.controller.changeRequest;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.dao.changeRequest.ChangeRequestDao;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;

@SovaMapping("/changerequest")
public class CrServiceController {

    //post_lambda 
	@SovaMapping(value = "/searchAndFilerCr", method = SovaRequestMethod.POST)
    public List<Map<String, Object>> searchAndFilerCr(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, Object> filterCondition = (Map<String, Object>) paramMap.get("filterCondition");
        String searchKey = String.valueOf(paramMap.get("searchKey"));
        return ChangeRequestDao.getAddToExistingMaster(ChangeRequestDao.filterChangeRequest(searchKey, filterCondition, 50));
    }

    //post_lambda 
	@SovaMapping(value = "/loadRecentRequest", method = SovaRequestMethod.POST)
    public List<Map<String, Object>> loadRecentRequest(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, Object> filterCondition = (Map<String, Object>) paramMap.get("filterCondition");
        int limit = Objects.nonNull(paramMap.get("limit")) ? Integer.parseInt(String.valueOf(paramMap.get("limit"))) : 5;
        return ChangeRequestDao.getRecentRequestInboxData(ChangeRequestDao.filterChangeRequest("", filterCondition, limit));
    }

    //post_lambda 
	@SovaMapping(value = "/getVersionMaster", method = SovaRequestMethod.POST)
    public Map<String, Object> getVersionMaster(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        return ChangeRequestDao.getVersionMaster(paramMap);
    }
}
