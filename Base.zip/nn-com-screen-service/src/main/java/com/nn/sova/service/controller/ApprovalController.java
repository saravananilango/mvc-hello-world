package com.nn.sova.service.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.service.workflow.entity.ApplicationClientEntity;
import com.nn.sova.service.workflow.entity.ApplicationDataEntity;
import com.nn.sova.service.workflow.entity.ApplicationStepEntity;
import com.nn.sova.service.workflow.entity.ApplicationStepMemberEntity;
import com.nn.sova.service.workflow.entity.ApplicationTransitionEntity;
import com.nn.sova.service.workflow.enums.ApprovalStatusEnum;
import com.nn.sova.utility.api.WebServiceUtils;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * ApprovalController is a abstract controller which holds the workflow operation API
 * and supporting function which interacts with the application.
 * @extends ApplicationController
 * 
 * @author Punithan Antony Das(punithanantony.d@vaken.cloud)
 *
 */
public abstract class ApprovalController extends ApplicationController {

    private static final String SUBMIT_BUTTON = "showSubmitButton";

    private static final String RESUBMIT_BUTTON = "showResubmitButton";

    private static final String DRAFT_BUTTON = "showDraftButton";

    private static final String WITHDRAWN_BUTTON = "showWithdrawButton";

    private static final String APPROVE_BUTTON = "showApproveButton";

    private static final String REJECT_BUTTON = "showRejectButton";

    private static final String SENTBACK_BUTTON = "showSendbackButton";

    private static final String VERIFY_BUTTON = "showVerifyButton";

    private static final String CONFIRM_BUTTON = "showConfirmButton";

    private static final String DISCARD_BUTTON = "showDiscardButton";

    private static final String URGENT_BUTTON = "showUrgentButton";

    private static final String URGENT_BUTTON_VALUE = "urgentButtonValue";

    private static final String APPLICATION_NAME = "applicationName";

    private static final String APPLICATION_UID = "applicationUniqueId";

    private static final String SHOW_HISTORY = "showHistory";

    private static final String SHOW_UNMARK_URGENT = "2";

    private static final String SHOW_MARK_URGENT = "1";

    private static final String APP_SAVED_AS_DRAFT_TEXT = "framework_approval_application_drafted";

    private static final String APP_DRAFT_TEXT = "framework_approval_application_draft";

    private static final String APP_SUBMITTED_TEXT = "framework_approval_application_submitted";

    private static final String APP_RESUBMITTED_TEXT = "framework_approval_application_resubmitted";

    private static final String APP_CREATE_TEXT = "framework_approval_create_application";

    private static final String APP_AWAITING_APPROVAL_TEXT = "framework_approval_awaiting_for_approval";

    private static final String APP_APPROVED_TEXT = "framework_approval_application_approved";

    private static final String APP_REQUEST_APPROVED_TEXT = "framework_approval_approved_the_request";

    private static final String APP_REJECTED_TEXT = "framework_approval_application_rejected";

    private static final String APP_REQUEST_REJETED_TEXT = "framework_approval_rejected_the_request";

    private static final String APP_SENTBACK_TEXT = "framework_approval_application_sentback";

    private static final String APP_REQUEST_SENTBACK_TEXT = "framework_approval_sentback_the_request";

    private static final String APP_WITHDRAWN_TEXT = "framework_approval_application_withdrawn";

    private static final String APP_VERIFIED_TEXT = "framework_approval_application_verified";

    private static final String APP_REQUEST_VERIFIED_TEXT = "framework_approval_verified_the_request";

    private static final String APP_AWAITING_VERIFY_TEXT = "framework_approval_awaiting_for_verify";

    private static final String APP_NO_WF_CONFIG = "framework_approval_no_config_label";

    private static final String APP_NO_WF_FLOW = "framework_approval_no_flow_label";

    private static final String APP_MULTIPLE_WF_CONFIG = "framework_approval_multiple_flow_label";

    private static final String APP_WF_CONFIG_OFF = "framework_approval_config_off_label";
    
    private static final String APP_WF_NO_STEPS = "framework_approval_no_steps_present";

    private static final String APP_NO_WF_CONFIG_DESC = "framework_approval_no_config_description";

    private static final String APP_ERROR_WF_CONFIG_DESC = "framework_approval_error_config_description";

    private static final String APP_ERROR_WF_OFF_DESC = "framework_approval_config_off_description";

    private static final String STRING_EMPTY = StringUtils.EMPTY;

    private static final Integer START_INDEX = 0;

    private static final Integer CONST_ONE = 1;

    private static final String APPLICATION_ID = "appid";
    
    private static final String APP_UNIQUE_ID = "appuid";
    
    private static final String PROP_APP_ID = "appId";
    
    private static final String PROP_VERSION = "version";
    
    private static final String VERSION = "ver";

    private static final String KEY_ADMIN = "adminApproval";

    private static final String KEY_STATUS = "status";

    private static final String KEY_LABEL = "label";

    private static final String KEY_HISTORY_BREAKER = "historyBreaker";

    private static final String KEY_ICON = "icon";

    private static final String KEY_COLOR = "color";

    private static final String KEY_COMPLETED = "completed";

    private static final String KEY_ACTIVE = "active";

    private static final String KEY_USER_LIST = "userList";

    private static final String KEY_USER_ID = "userId";

    private static final String KEY_UPLOAD_PATH = "uploadPath";

    private static final String KEY_SUB_LABEL = "subLabel";

    private static final String KEY_COMMENT = "comment";

    private static final String KEY_DISPLAY = "display";

    private static final String KEY_STEP_ENTITY_LIST = "stepEntityList";

    private static final String KEY_PROXY = "proxy";

    private static final String KEY_PROXY_LABEL = "proxyLabel";

    private static final String KEY_VALUE = "value";

    private static final String KEY_EMPTY_DATA_LABEL = "emptyDataLabel";

    private static final String KEY_EMPTY_DATA_DESC = "emptyDataDescription";

    private static final String KEY_EMPTY_DATA_ICON = "emptyDataIcon";

    private static final String TRANSIION_ENTITY = "transitionEntity";

    private static final String ICON_SUCCESS = "done";

    private static final String ICON_WARN = "reply";

    private static final String ICON_ERROR = "close";

    private static final String ICON_REPORT = "report";

    private static final String ICON_AUTO_APPROVED = "done_all";

    private static final String COLOR_SUCCESS = "success";

    private static final String COLOR_WARN = "warning";

    private static final String COLOR_ERROR = "error";

    private static final String PAGINATING_INDEX = "index";

    private static final String COMP_STEPPER_ID = "stepper-component-id";

    private static final String COMP_HEADER_ID = "header-component-id";

    private static final String ICON_START = "lens";
    
    private static final String STATUS_FAILED = "FAILED";

    private static final String STATUS_EMPTY_CONFIG = "NO_CONFIGURATIONS_PRESENT";

    private static final String STATUS_ORG_PROBLEM = "ORG_USER_PROBLEM";

    private static final String MULTIPLE_FLOWS_PRESENT = "MULTIPLE_FLOWS_PRESENT";

    private static final String NO_FLOWS_PRESENT = "NO_FLOWS_PRESENT";

    private static final String WORKFLOW_SWITCHED_OFF = "WORKFLOW_SWITCHED_OFF";
    
    private static final String KEY_DESIGNATION = "designation";

    /** CacheGetService class to get common text resource from cache service */
    private CacheService cacheService = CacheService.getInstance();

    /** logger class */
    private static ApplicationLogger logger = ApplicationLogger.create(ApprovalController.class);
    
    /**
     * initial method while creating application in workflow, application should have only
     * abstract method of this index
     * @param request
     * @param response
     * @throws QueryException
     * @throws CustomException
     */
	@SovaMapping(value = "/index", method = SovaRequestMethod.POST)
    public void index(SovaHttpRequest request, SovaHttpResponse response) throws QueryException, CustomException {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        response.withBody(index(clientEntity, postParamMap, request, response));
    }
	
	/**
	 * getApplication method used to get application data from workflow service,
	 * for both approval stepper and header component
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/getApplication", method = SovaRequestMethod.POST)
    public void getApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        List<FrontVo> voList = new ArrayList<>();
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        formApprovalComponents(clientEntity, postParamMap, voList, request, response);
        response.withBody(JsonUtils.toPrettyJsonOrNull(voList));
    }
	
	/** 
	 * onValueChange  method used to update the stepper based on flow value
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/onValueChange", method = SovaRequestMethod.POST)
    public void onValueChange(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        List<FrontVo> voList = new ArrayList<>();
        onValueChange(postParamMap, voList);
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        if(postParamMap.containsKey("flowValue") && Objects.nonNull(postParamMap.get("flowValue"))) {
        	clientEntity.setFlowValue(postParamMap.get("flowValue"));
        }
        if(postParamMap.containsKey("skipValue") && Objects.nonNull(postParamMap.get("skipValue"))) {
        	clientEntity.setSkipValue(postParamMap.get("skipValue"));
        }
        formApprovalComponents(clientEntity, postParamMap, voList, request, response);
        response.withBody(JsonUtils.toPrettyJsonOrNull(voList));
    }
	
	/**
	 * getApplicationStepper method used to get application stepper component data only
	 * @param request
	 * @param response
	 */
	@SovaMapping(value = "/getApplicationStepper", method = SovaRequestMethod.POST)
    public void getApplicationStepper(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        List<FrontVo> voList = new ArrayList<>();
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        ApplicationDataEntity appliationDataEntity = getApplicationStepper("approval/getApplication", clientEntity);
        String stepperCompId = objectToString(postParamMap, COMP_STEPPER_ID);
        if (StringUtils.isNotEmpty(stepperCompId)) {
            addMultipleAttribute(stepperCompId, getStepperAttributeMap(appliationDataEntity), voList);
        }
        response.withBody(JsonUtils.toPrettyJsonOrNull(voList));
    }
	
	/**
	 * getApplicationHistory method used to get application history of all versions for SENTABCK applications
	 * @param request
	 * @param response
	 */
	@SovaMapping(value = "/getApplicationHistory", method = SovaRequestMethod.POST)
    public void getApplicationHistory(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        List<FrontVo> voList = new ArrayList<>();
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        String stepperCompId = objectToString(postParamMap, COMP_STEPPER_ID);
        if (StringUtils.isEmpty(stepperCompId)) {
        	response.withBody(JsonUtils.toPrettyJsonOrNull(voList));
        }
        List<ApplicationDataEntity> appliationDataEntityList = getApplicationHistory(clientEntity);
        if (CollectionUtils.isNotEmpty(appliationDataEntityList)) {
            Map<String, Object> stepperAttributeMap = getStepperAttributeMap(appliationDataEntityList);
            addMultipleAttribute(stepperCompId, stepperAttributeMap, voList);
        }
        response.withBody(JsonUtils.toPrettyJsonOrNull(voList));
    }
	
	/**
	 * submitApplication method used to submit application, returns transition entity
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/submitApplication", method = SovaRequestMethod.POST)
    public void submitApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(submissionProcess(postParamMap, ApprovalStatusEnum.SUBMITTED.getValue(), false, request, response));
    }
	
	/**
	 * draftApplication method used to draft application, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/draftApplication", method = SovaRequestMethod.POST)
    public void draftApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(submissionProcess(postParamMap, ApprovalStatusEnum.DRAFT.getValue(), true, request, response));
    }
	
	/**
	 * approveApplication method used to approve application step, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/approveApplication", method = SovaRequestMethod.POST)
    public void approveApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.APPROVED.getValue(), request, response));
    }
	
	/**
	 * rejectApplication method used to reject application step, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/rejectApplication", method = SovaRequestMethod.POST)
    public void rejectApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.REJECTED.getValue(), request, response));
    }
	
	/**
	 * sendbackApplication method used to sendback application step, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/sendbackApplication", method = SovaRequestMethod.POST)
    public void sendbackApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.SENTBACK.getValue(), request, response));
    }
	
	/**
	 * verifyApplication method used to verify application step, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/verifyApplication", method = SovaRequestMethod.POST)
    public void verifyApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.VERIFIED.getValue(), request, response));
    }
	
	/**
	 * withdrawApplication method used to withdraw application, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/withdrawApplication", method = SovaRequestMethod.POST)
    public void withdrawApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.WITHDRAWN.getValue(), request, response));
    }
	
	/**
	 * confirmApplication method used to confirm application step, returns transition entity in response
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@SovaMapping(value = "/confirmApplication", method = SovaRequestMethod.POST)
    public void confirmApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.CONFIRMED.getValue(), request, response));
    }

    /**
     * discardApplication method used to discard application, returns transition entity in response
     * @param request
     * @param response
     * @throws Exception
     */
	@SovaMapping(value = "/discardApplication", method = SovaRequestMethod.POST)
    public void discardApplication(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(approvalProcess(postParamMap, ApprovalStatusEnum.DISCARD.getValue(), request, response));
    }
	
	/**
	 * getTargetApplication method used to find the next appliacation appId and version while pagination
	 * @param request
	 * @param response
	 */
	@SovaMapping(value = "/getTargetApplication", method = SovaRequestMethod.POST)
    public void getTargetApplication(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
        response.withBody(getTargetApplication(postParamMap));
    }

    public abstract List<FrontVo> index(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap, SovaHttpRequest request, SovaHttpResponse response) throws QueryException, CustomException;
    
    /** onValueChange get called while onValueChange in client side - override this method if needed for server side changes */
    public void onValueChange(Map<String, Object> postParamMap, List<FrontVo> voList) {
    }

    /**
	 * eventListener get called on bulk approval process from tray,
	 * 
	 * @param transitionEntityList
     * @throws Exception 
	 */
	@SovaMapping(value = "/eventListener", method = SovaRequestMethod.POST)
    public void eventListener(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
		try {			
			List<ApplicationTransitionEntity> transitionEntityList = JsonUtils.getObjectMapper().convertValue(request.getBody(), 
					new TypeReference<List<ApplicationTransitionEntity>>() {});
			transitionEntityList.stream().forEach(transitionEntity -> afterBulkApproval(transitionEntity, request, response));
		}catch(Exception exc) {
			logger.error("ERROR OCCURS ON PASSING TRANSITION ENTITY WHILE BULK APPROVE", exc);
		}
    }
	
	/**
	 * eventListener get called on bulk approval process from tray,
	 * 
	 * @param transitionEntityList
     * @throws Exception 
	 */
	@SovaMapping(value = "/eventListenerList", method = SovaRequestMethod.POST)
    public void eventListenerList(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        try {			
			List<ApplicationTransitionEntity> transitionEntityList = JsonUtils.getObjectMapper().convertValue(request.getBody(), 
					new TypeReference<List<ApplicationTransitionEntity>>() {});
			afterBulkApproval(transitionEntityList, request, response);
		}catch(Exception exc) {
			logger.error("ERROR OCCURS ON PASSING TRANSITION ENTITY WHILE BULK APPROVE", exc);
		}
    }
	
	/**
	 * afterBulkApproval method called after bulk approval in tray or batch
	 * override this method to change application side data based on workflow
	 * @param transitionEntity
	 */
    public void afterBulkApproval(ApplicationTransitionEntity transitionEntity, SovaHttpRequest request, SovaHttpResponse response){
        logger.debug("CALLED DEFAULT AFTER BULK APPROVAL METHOD{}", transitionEntity.toString());
    }

    /**
	 * afterBulkApproval method called after bulk approval in tray or batch
	 * override this method to change application side data based on workflow
	 * @param transitionEntityList
	 */
    public void afterBulkApproval(List<ApplicationTransitionEntity> transitionEntityList, SovaHttpRequest request, SovaHttpResponse response) throws Exception{
        logger.debug("CALLED DEFAULT AFTER BULK APPROVAL LIST METHOD{}", transitionEntityList.toString());
    }

    public boolean beforeApplicationDraft(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap, List<FrontVo> voList, 
    		SovaHttpRequest request, SovaHttpResponse response) throws Exception{
        logger.debug("CALLED DEFAULT BEFORE APPLICATION DRAFT{}", clientEntity.toString() + postParamMap.toString() + voList.toString());
        return true;
    }

    public void afterApplicationDraft(ApplicationTransitionEntity transitionEntity, Map<String, Object> postParamMap, List<FrontVo> voList, 
    		SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        logger.debug("CALLED DEFAULT AFTER APPLICATION DRAFT{}", transitionEntity.toString() + postParamMap.toString() + voList.toString());
    }

    public boolean beforeApplicationSubmit(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap, List<FrontVo> voList, 
    		SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        logger.debug("CALLED DEFAULT BEFORE APPLICATION SUBMIT{}", clientEntity.toString() + postParamMap.toString() + voList.toString());
        return true;
    }

    public void afterApplicationSubmit(ApplicationTransitionEntity transitionEntity, Map<String, Object> postParamMap, List<FrontVo> voList, 
    		SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        logger.debug("CALLED DEFAULT AFTER APPLICATION SUBMIT{}", transitionEntity.toString() + postParamMap.toString() + voList.toString());
    }

    public boolean beforeApprovalAction(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap, List<FrontVo> voList, 
    		SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        logger.debug("CALLED DEFAULT BEFORE APPROVAL ACTION{}", clientEntity.toString() + postParamMap.toString() + voList.toString());
        return true;
    }

    public void afterApprovalAction(ApplicationTransitionEntity transitionEntity, Map<String, Object> postParamMap, List<FrontVo> voList, 
    		SovaHttpRequest request, SovaHttpResponse response)  throws Exception{
        logger.debug("CALLED DEFAULT AFTER APPROVAL ACTION{}", transitionEntity.toString() + postParamMap.toString() + voList.toString());
    }

    public void setApplicationSpecificStep(ApplicationDataEntity appliationDataEntity, Map<String, Object> postParamMap, 
    		SovaHttpRequest request, SovaHttpResponse response)  throws Exception{
        logger.debug("CALLED SET APPLICATION STEP ENTITY METHOD{}", appliationDataEntity.toString() + postParamMap.toString());
    }

    private void setStepEntityList(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap) {
    	/** checking whether the step details get passed from front to controller, if value present, then it get casted to List of ApplicationStepEntity*/
        if (postParamMap.containsKey(KEY_STEP_ENTITY_LIST) && Objects.nonNull(postParamMap.get(KEY_STEP_ENTITY_LIST))) {
            try {
                List<ApplicationStepEntity> stepEntityList = (List<ApplicationStepEntity>) postParamMap.get(KEY_STEP_ENTITY_LIST);
                clientEntity.setStepEntityList(stepEntityList);
            } catch (Exception exception) {
                logger.info("ERROR WHILE SETTING STEP ENTITY LIST IN CLIENT ENTITY", exception);
            }
        }
    }

    private String submissionProcess(Map<String, Object> postParamMap, String status, boolean isDraft, SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        List<FrontVo> voList = new ArrayList<>();
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        clientEntity.setComment(objectToString(postParamMap, KEY_COMMENT));
        boolean isNewApplication = Objects.isNull(clientEntity.getApplicationId());
        /** if new application generate app id*/
        if (isNewApplication) {
            clientEntity.setApplicationId(generateApplication());
        }
        clientEntity.setStatus(status);
        clientEntity.setUrgent(Boolean.parseBoolean(objectToString(postParamMap, "urgent")));
        if(postParamMap.containsKey("flowValue") && Objects.nonNull(postParamMap.get("flowValue"))) {
        	clientEntity.setFlowValue(postParamMap.get("flowValue"));
        }
        if(postParamMap.containsKey("skipValue") && Objects.nonNull(postParamMap.get("skipValue"))) {
        	clientEntity.setSkipValue(postParamMap.get("skipValue"));
        }
        if(postParamMap.containsKey(APPLICATION_UID) && Objects.nonNull(postParamMap.get(APPLICATION_UID))) {
        	clientEntity.setApplicationUniqueId(objectToString(postParamMap, APPLICATION_UID));
        }
        if(postParamMap.containsKey("description") && Objects.nonNull(postParamMap.get("description"))) {
        	clientEntity.setDescription(objectToString(postParamMap, "description"));
        }
        setStepEntityList(clientEntity, postParamMap);
        boolean proceedSubmission;
        if (isDraft) {
            proceedSubmission = beforeApplicationDraft(clientEntity, postParamMap, voList, request, response);
        } else {
            proceedSubmission = beforeApplicationSubmit(clientEntity, postParamMap, voList, request, response);
        }
        if (!proceedSubmission) {
            return JsonUtils.toPrettyJsonOrNull(voList);
        }
        ApplicationTransitionEntity transitionEntity = submitApplication(clientEntity, isDraft);
        if (isDraft) {
            afterApplicationDraft(transitionEntity, postParamMap, voList, request, response);
        } else {
            afterApplicationSubmit(transitionEntity, postParamMap, voList, request, response);
        }
        addData(TRANSIION_ENTITY, transitionEntity, voList);
        clientEntity.setApplicationId(transitionEntity.getApplicationId());
        clientEntity.setVersion(transitionEntity.getVersion());
        if (!transitionEntity.isSuccess() && !isDraft) {
            clientEntity.setApplicationId(null);
            clientEntity.setVersion(START_INDEX);
        }
        formApprovalComponents(clientEntity, postParamMap, voList, request, response);
        return JsonUtils.toPrettyJsonOrNull(voList);
    }

    private String approvalProcess(Map<String, Object> postParamMap, String status, SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        List<FrontVo> voList = new ArrayList<>();
        ApplicationClientEntity clientEntity = getApplicationKeys(postParamMap);
        clientEntity.setAdmin(Boolean.parseBoolean(objectToString(postParamMap, KEY_ADMIN)));
        clientEntity.setComment(objectToString(postParamMap, KEY_COMMENT));
        clientEntity.setStatus(status);
        if (beforeApprovalAction(clientEntity, postParamMap, voList, request, response)) {
            ApplicationTransitionEntity transitionEntity = approvalProcess(clientEntity);
            afterApprovalAction(transitionEntity, postParamMap, voList, request, response);
            addData(TRANSIION_ENTITY, transitionEntity, voList);
        }
        if (ApprovalStatusEnum.DISCARD.getValue().equals(status)) {
            afterDiscardProcess(postParamMap, voList);
        } else {
            formApprovalComponents(clientEntity, postParamMap, voList, request, response);
        }
        return JsonUtils.toPrettyJsonOrNull(voList);
    }

    private void afterDiscardProcess(Map<String, Object> postParamMap, List<FrontVo> voList) {
        String headerCompId = objectToString(postParamMap, COMP_HEADER_ID);
        String stepperCompId = objectToString(postParamMap, COMP_STEPPER_ID);
        if (StringUtils.isNotEmpty(headerCompId) && StringUtils.isNotEmpty(stepperCompId)) {
            addAttribute(headerCompId, KEY_DISPLAY, false, voList);
            addAttribute(stepperCompId, KEY_DISPLAY, false, voList);
        }
    }

    private ApplicationClientEntity getApplicationKeys(Map<String, Object> parameterMap) {
        ApplicationClientEntity clientEntity = new ApplicationClientEntity();
        clientEntity.setScreenId(objectToString(parameterMap, "sid"));
        String applicationId = objectToString(parameterMap, APPLICATION_ID);
        String version = objectToString(parameterMap, VERSION);
        if (StringUtils.isEmpty(applicationId)) {
            return clientEntity;
        }
        clientEntity.setApplicationId(UUID.fromString(applicationId));
        clientEntity.setVersion( StringUtils.isEmpty(version) ? START_INDEX : Integer.parseInt(version));
        setPaginationDetails(clientEntity, parameterMap);
        return clientEntity;
    }

    private List<FrontVo> formApprovalComponents(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap, List<FrontVo> voList,
    		SovaHttpRequest request, SovaHttpResponse response) throws Exception {
        boolean isNewApplication = Objects.isNull(clientEntity.getApplicationId());
        if (isNewApplication) {
            clientEntity.setApplicationId(generateApplication());
        }
        String apiMappingPath = isNewApplication ? "approval/createApplications" : "approval/getApplication";
        ApplicationDataEntity appliationDataEntity = getApplicationStepper(apiMappingPath, clientEntity);
        logger.info("ApplicationDAtaEntity {}", appliationDataEntity);
        boolean isSpecificAndDraftApp = appliationDataEntity.isDraftedApplication() && appliationDataEntity.isApplicationSpecific();
        if (isSpecificAndDraftApp || appliationDataEntity.isApplicationSpecific()) {
            setApplicationSpecificStep(appliationDataEntity, postParamMap, request, response);
        }
        String headerCompId = objectToString(postParamMap, COMP_HEADER_ID);
        String stepperCompId = objectToString(postParamMap, COMP_STEPPER_ID);
        if (StringUtils.isNotEmpty(headerCompId) && StringUtils.isNotEmpty(stepperCompId)) {
            Map<String, Object> headerAttributeMap = isNewApplication ? 
            		getNewHeaderAttributeMap(appliationDataEntity) : getHeaderAttributeMap(appliationDataEntity, clientEntity.isMaster());
            addMultipleAttribute(headerCompId, headerAttributeMap, voList);
            Map<String, Object> stepperAttributeMap = getStepperAttributeMap(appliationDataEntity);
            addMultipleAttribute(stepperCompId, stepperAttributeMap, voList);
        }
        return voList;
    }

    private Map<String, Object> getNewHeaderAttributeMap(ApplicationDataEntity appliationDataEntity) {
        Map<String, Object> attributeMap = new HashMap<>();
        attributeMap.put(APPLICATION_NAME, getScreenName(appliationDataEntity.getScreenId()));
        attributeMap.put(APPLICATION_UID, appliationDataEntity.getApplicationUniqueId());
        attributeMap.put(SUBMIT_BUTTON, true);
        attributeMap.put(DRAFT_BUTTON, true);
        attributeMap.put(URGENT_BUTTON, true);
        attributeMap.put(KEY_STEP_ENTITY_LIST, appliationDataEntity.getApplicationStepEntityList());
        return attributeMap;
    }

    private Map<String, Object> getHeaderAttributeMap(ApplicationDataEntity appliationDataEntity, boolean fromMasterTray) {
        Map<String, Object> attributeMap = new HashMap<>();
        attributeMap.put(PROP_APP_ID, appliationDataEntity.getApplicationId());
        attributeMap.put(PROP_VERSION, appliationDataEntity.getVersion());
        attributeMap.put(APPLICATION_NAME, getScreenName(appliationDataEntity.getScreenId()));
        attributeMap.put(APPLICATION_UID, appliationDataEntity.getApplicationUniqueId());
        attributeMap.put(SHOW_HISTORY, appliationDataEntity.isActualApprover() && (CONST_ONE != appliationDataEntity.getVersion()));
        attributeMap.put(KEY_STEP_ENTITY_LIST, appliationDataEntity.getApplicationStepEntityList());
        /** checking whether the current logged in user is approver or not
         * NOTE: if user present as both approver and applicant then issue present while application process - Need to fix*/
        if (appliationDataEntity.isActualApprover() && !ApprovalStatusEnum.WITHDRAWN.getValue().equals(appliationDataEntity.getApplicationStatus())) {
            List<ApplicationStepMemberEntity> stepMemberEntityList = appliationDataEntity.getApplicationStepEntityList().stream().flatMap(stepEntity -> stepEntity.getStepMemberEntityList().stream().filter(ApplicationStepMemberEntity::isCurrentUser)).collect(Collectors.toList());
            stepMemberEntityList.sort(Comparator.comparing(ApplicationStepMemberEntity::getStepOrder));
            stepMemberEntityList.stream().forEach(memberEntity -> vaidateHeaderButtons(appliationDataEntity, memberEntity, attributeMap, fromMasterTray));
        } else if (appliationDataEntity.isActualApplicant()) {
            validateApplicant(appliationDataEntity, attributeMap);
        } else {
            attributeMap.put(KEY_DISPLAY, false);
        }
        setPaginationDetails(appliationDataEntity, attributeMap);
        String applicationStatus = appliationDataEntity.getApplicationStatus();
        attributeMap.put("applicationStatus", applicationStatus);
        if(ApprovalStatusEnum.SUBMITTED.getValue().equals(applicationStatus) || 
        		ApprovalStatusEnum.INPROGRESS.getValue().equals(applicationStatus)) {        	
        	attributeMap.put("currentStep", appliationDataEntity.getApplicationState() + 1);
        }else {
        	attributeMap.put("currentStep", appliationDataEntity.getApplicationState());
        }
        attributeMap.put("totalSteps", appliationDataEntity.getTotalSteps());
        attributeMap.put("showHistoryValue", "1");
        return attributeMap;
    }

    private void setPaginationDetails(ApplicationDataEntity appliationDataEntity, Map<String, Object> attributeMap) {
        BigInteger page = appliationDataEntity.getPage();
        BigInteger total = appliationDataEntity.getTotal();
        boolean isNullValue = Objects.isNull(page) || Objects.isNull(total);
        boolean isZeroValue = BigInteger.ZERO.equals(page) || BigInteger.ZERO.equals(total);
        /** checks page and total is not null and not zero*/
        if (isNullValue || isZeroValue) {
            attributeMap.put("showPagination", false);
            return;
        }
        attributeMap.put("page", page);
        attributeMap.put("total", total);
        attributeMap.put("showPagination", true);
    }

    private void vaidateHeaderButtons(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, 
    		Map<String, Object> attributeMap, boolean fromMasterTray) {
        String approverStatus = memberEntity.getApproverStatus();
        if (ApprovalStatusEnum.APPROVED.getValue().equals(approverStatus)) {
            validateApprove(appliationDataEntity, memberEntity, attributeMap);
        } else if (ApprovalStatusEnum.SUBMITTED.getValue().equals(approverStatus)) {
            validateSubmitted(appliationDataEntity, memberEntity, attributeMap);
        } else if (ApprovalStatusEnum.REJECTED.getValue().equals(approverStatus)) {
            validateRejected(appliationDataEntity, memberEntity, attributeMap);
        } else if (ApprovalStatusEnum.SENTBACK.getValue().equals(approverStatus)) {
            validateSentBack(appliationDataEntity, memberEntity, attributeMap);
        } else if (ApprovalStatusEnum.WITHDRAWN.getValue().equals(approverStatus)) {
            validateWithdrawn(appliationDataEntity, memberEntity, attributeMap);
        } else if (fromMasterTray && memberEntity.isMaster()) {
            validateSubmitted(appliationDataEntity, memberEntity, attributeMap);
        } else if (ApprovalStatusEnum.VERIFY.getValue().equals(approverStatus) || ApprovalStatusEnum.VERIFIED.getValue().equals(approverStatus)) {
            validateVerify(appliationDataEntity, memberEntity, attributeMap);
        } else if (ApprovalStatusEnum.NOT_SUBMITTED.getValue().equals(approverStatus)) {
            attributeMap.put(URGENT_BUTTON, false);
            attributeMap.put(SUBMIT_BUTTON, false);
            attributeMap.put(DRAFT_BUTTON, false);
            attributeMap.put(RESUBMIT_BUTTON, false);
        }
    }

    private void validateApplicant(ApplicationDataEntity appliationDataEntity, Map<String, Object> attributeMap) {
        String applicationStatus = appliationDataEntity.getApplicationStatus();
        boolean isUrgent = ApprovalStatusEnum.URGENT.getValue().equals(appliationDataEntity.getPriority());
        boolean isSentBack = ApprovalStatusEnum.SENTBACK.getValue().equals(applicationStatus) && !appliationDataEntity.isResubmitted();
        boolean isEnable = isSentBack || ApprovalStatusEnum.DRAFT.getValue().equals(applicationStatus);
        boolean isWithdrawable = ApprovalStatusEnum.SUBMITTED.getValue().equals(applicationStatus) || ApprovalStatusEnum.INPROGRESS.getValue().equals(applicationStatus) || ApprovalStatusEnum.APPROVED.getValue().equals(applicationStatus);
        Map<String, Object> validationMap = new HashMap<>();
        validationMap.put(WITHDRAWN_BUTTON, appliationDataEntity.isActualApplicant() && isWithdrawable);
        validationMap.put(SUBMIT_BUTTON, appliationDataEntity.isDraftedApplication());
        validationMap.put(DRAFT_BUTTON, appliationDataEntity.isDraftedApplication());
        validationMap.put(DISCARD_BUTTON, appliationDataEntity.isDraftedApplication());
        validationMap.put(RESUBMIT_BUTTON, isSentBack && !appliationDataEntity.isResubmitted());
        validationMap.put(URGENT_BUTTON, isEnable);
        attributeMap.put(URGENT_BUTTON_VALUE, isUrgent ? SHOW_UNMARK_URGENT : SHOW_MARK_URGENT);
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private void validateApprove(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, Map<String, Object> attributeMap) {
        Map<String, Object> validationMap = new HashMap<>();
        boolean isUrgent = ApprovalStatusEnum.URGENT.getValue().equals(appliationDataEntity.getPriority());
        String applicationStatus = appliationDataEntity.getApplicationStatus();
        boolean isWithdrawable = ApprovalStatusEnum.SUBMITTED.getValue().equals(applicationStatus) || ApprovalStatusEnum.INPROGRESS.getValue().equals(applicationStatus) || ApprovalStatusEnum.APPROVED.getValue().equals(applicationStatus);
        if (memberEntity.isNeedToConfirm()) {
            validationMap.put(CONFIRM_BUTTON, true);
        }
        validationMap.put(WITHDRAWN_BUTTON, appliationDataEntity.isActualApplicant() && isWithdrawable);
        attributeMap.put(URGENT_BUTTON_VALUE, isUrgent ? SHOW_UNMARK_URGENT : SHOW_MARK_URGENT);
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private void validateSubmitted(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, Map<String, Object> attributeMap) {
        Map<String, Object> validationMap = new HashMap<>();
        boolean isUrgent = ApprovalStatusEnum.URGENT.getValue().equals(appliationDataEntity.getPriority());
        if (memberEntity.isNeedToConfirm()) {
            validationMap.put(CONFIRM_BUTTON, true);
        } else if (!memberEntity.isConfirmed()) {
            validationMap.put(APPROVE_BUTTON, true);
            validationMap.put(REJECT_BUTTON, true);
            validationMap.put(SENTBACK_BUTTON, true);
            validationMap.put(WITHDRAWN_BUTTON, appliationDataEntity.isActualApplicant());
        }
        attributeMap.put(URGENT_BUTTON_VALUE, isUrgent ? SHOW_UNMARK_URGENT : SHOW_MARK_URGENT);
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private void validateRejected(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, Map<String, Object> attributeMap) {
        Map<String, Object> validationMap = new HashMap<>();
        boolean isUrgent = ApprovalStatusEnum.URGENT.getValue().equals(appliationDataEntity.getPriority());
        if (memberEntity.isNeedToConfirm()) {
            validationMap.put(CONFIRM_BUTTON, true);
        }
        attributeMap.put(URGENT_BUTTON_VALUE, isUrgent ? SHOW_UNMARK_URGENT : SHOW_MARK_URGENT);
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private void validateSentBack(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, Map<String, Object> attributeMap) {
        Map<String, Object> validationMap = new HashMap<>();
        boolean isUrgent = ApprovalStatusEnum.URGENT.getValue().equals(appliationDataEntity.getPriority());
        boolean isResubmit = appliationDataEntity.isActualApplicant() && !appliationDataEntity.isResubmitted();
        if (memberEntity.isNeedToConfirm()) {
            validationMap.put(CONFIRM_BUTTON, true);
        }
        validationMap.put(RESUBMIT_BUTTON, isResubmit);
        validationMap.put(URGENT_BUTTON, isUrgent && isResubmit);
        attributeMap.put(URGENT_BUTTON_VALUE, isUrgent ? SHOW_UNMARK_URGENT : SHOW_MARK_URGENT);
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private void validateWithdrawn(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, Map<String, Object> attributeMap) {
        Map<String, Object> validationMap = new HashMap<>();
        if (memberEntity.isNeedToConfirm()) {
            validationMap.put(CONFIRM_BUTTON, true);
        }
        if (ApprovalStatusEnum.DRAFT.getValue().equals(appliationDataEntity.getApplicationStatus()) && appliationDataEntity.isActualApplicant()) {
            validationMap.put(DRAFT_BUTTON, true);
            validationMap.put(DISCARD_BUTTON, true);
        }
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private void validateVerify(ApplicationDataEntity appliationDataEntity, ApplicationStepMemberEntity memberEntity, Map<String, Object> attributeMap) {
        Map<String, Object> validationMap = new HashMap<>();
        boolean isUrgent = ApprovalStatusEnum.URGENT.getValue().equals(appliationDataEntity.getPriority());
        if (memberEntity.isNeedToConfirm()) {
            validationMap.put(CONFIRM_BUTTON, true);
        } else if (memberEntity.isVerify() && !memberEntity.isConfirmed()) {
            validationMap.put(VERIFY_BUTTON, true);
            validationMap.put(REJECT_BUTTON, true);
        }
        attributeMap.put(URGENT_BUTTON_VALUE, isUrgent ? SHOW_UNMARK_URGENT : SHOW_MARK_URGENT);
        attributeMap.putAll(setButtonAttributes(validationMap));
    }

    private Map<String, Object> getStepperAttributeMap(ApplicationDataEntity appliationDataEntity) {
        Map<String, Object> attributeMap = new HashMap<>();
        LinkedList<Map<String, Object>> stepperValue = formStepperComponentData(appliationDataEntity, false);
        setStepperValue(attributeMap, stepperValue, appliationDataEntity.getMessage());
        attributeMap.put(PROP_APP_ID, appliationDataEntity.getApplicationId());
        attributeMap.put(PROP_VERSION, appliationDataEntity.getVersion());
        attributeMap.put("viewPath", appliationDataEntity.getScreenViewUrl());
        return attributeMap;
    }

    private Map<String, Object> getStepperAttributeMap(List<ApplicationDataEntity> appliationDataEntityList) {
        Map<String, Object> attributeMap = new HashMap<>();
        LinkedList<Map<String, Object>> aggregatedDataList = new LinkedList<>();
        appliationDataEntityList.stream().forEach(appliationDataEntity -> aggregatedDataList.addAll(formStepperComponentData(appliationDataEntity, appliationDataEntity.isResubmitted())));
        ApplicationDataEntity appliationDataEntity = appliationDataEntityList.get(START_INDEX);
        setStepperValue(attributeMap, aggregatedDataList, appliationDataEntity.getMessage());
        attributeMap.put(PROP_APP_ID, appliationDataEntity.getApplicationId());
        attributeMap.put(PROP_VERSION, appliationDataEntity.getVersion());
        attributeMap.put("viewPath", appliationDataEntity.getScreenViewUrl());
        return attributeMap;
    }

    private void setStepperValue(Map<String, Object> attributeMap, LinkedList<Map<String, Object>> stepperValue, String message) {
        String locale = UserContext.getInstance().locale();
    	if(STATUS_FAILED.equals(message)) {
    		attributeMap.put(KEY_VALUE, CollectionUtils.emptyCollection());
            attributeMap.put(KEY_EMPTY_DATA_LABEL, getWfFrameworktext(APP_WF_NO_STEPS, locale));
            attributeMap.put(KEY_EMPTY_DATA_DESC, "");
            attributeMap.put(KEY_EMPTY_DATA_ICON, ICON_REPORT);
    	}else if (STATUS_EMPTY_CONFIG.equals(message)) {
            attributeMap.put(KEY_VALUE, CollectionUtils.emptyCollection());
            attributeMap.put(KEY_EMPTY_DATA_LABEL, getWfFrameworktext(APP_NO_WF_CONFIG, locale));
            attributeMap.put(KEY_EMPTY_DATA_DESC, getWfFrameworktext(APP_NO_WF_CONFIG_DESC, locale));
            attributeMap.put(KEY_EMPTY_DATA_ICON, ICON_REPORT);
        } else if (MULTIPLE_FLOWS_PRESENT.equals(message)) {
            attributeMap.put(KEY_VALUE, CollectionUtils.emptyCollection());
            attributeMap.put(KEY_EMPTY_DATA_LABEL, getWfFrameworktext(APP_MULTIPLE_WF_CONFIG, locale));
            attributeMap.put(KEY_EMPTY_DATA_DESC, "");
            attributeMap.put(KEY_EMPTY_DATA_ICON, ICON_REPORT);
        } else if (NO_FLOWS_PRESENT.equals(message) || STATUS_ORG_PROBLEM.equals(message)) {
            attributeMap.put(KEY_VALUE, CollectionUtils.emptyCollection());
            attributeMap.put(KEY_EMPTY_DATA_LABEL, getWfFrameworktext(APP_NO_WF_FLOW, locale));
            attributeMap.put(KEY_EMPTY_DATA_DESC, getWfFrameworktext(APP_ERROR_WF_CONFIG_DESC, locale));
            attributeMap.put(KEY_EMPTY_DATA_ICON, ICON_REPORT);
        } else if (WORKFLOW_SWITCHED_OFF.equals(message)) {
            attributeMap.put(KEY_VALUE, CollectionUtils.emptyCollection());
            attributeMap.put(KEY_EMPTY_DATA_LABEL, getWfFrameworktext(APP_WF_CONFIG_OFF, locale));
            attributeMap.put(KEY_EMPTY_DATA_DESC, getWfFrameworktext(APP_ERROR_WF_OFF_DESC, locale));
            attributeMap.put(KEY_EMPTY_DATA_ICON, ICON_AUTO_APPROVED);
        } else {
            attributeMap.put(KEY_VALUE, stepperValue);
        }
    }

    private Map<String, Object> setButtonAttributes(Map<String, Object> validationMap) {
        Map<String, Object> attributeMap = new HashMap<>();
        attributeMap.put(URGENT_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(URGENT_BUTTON))));
        attributeMap.put(SUBMIT_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(SUBMIT_BUTTON))));
        attributeMap.put(DRAFT_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(DRAFT_BUTTON))));
        attributeMap.put(DISCARD_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(DISCARD_BUTTON))));
        attributeMap.put(RESUBMIT_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(RESUBMIT_BUTTON))));
        attributeMap.put(WITHDRAWN_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(WITHDRAWN_BUTTON))));
        attributeMap.put(APPROVE_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(APPROVE_BUTTON))));
        attributeMap.put(REJECT_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(REJECT_BUTTON))));
        attributeMap.put(SENTBACK_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(SENTBACK_BUTTON))));
        attributeMap.put(VERIFY_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(VERIFY_BUTTON))));
        attributeMap.put(CONFIRM_BUTTON, Boolean.parseBoolean(String.valueOf(validationMap.get(CONFIRM_BUTTON))));
        return attributeMap;
    }

    private ApplicationDataEntity getApplicationStepper(String apiMappingPath, ApplicationClientEntity clientEntity) {
        ApplicationDataEntity appliationDataEntity = new ApplicationDataEntity();
        try {
            appliationDataEntity = (ApplicationDataEntity) exchangeForWorkflow(apiMappingPath, HttpMethod.POST, ApplicationDataEntity.class, clientEntity);
        } catch (Exception exception) {
            logger.error("ERROR OCCURED WHILE GETTING APPLICATION STEPPER DATA FROM WORKFLOW SERVICE", exception);
            appliationDataEntity.setScreenId(clientEntity.getScreenId());
            appliationDataEntity.setApplicationId(clientEntity.getApplicationId());
            appliationDataEntity.setVersion(clientEntity.getVersion());
            appliationDataEntity.setApplicantId(clientEntity.getUserId());
            appliationDataEntity.setMessage(STATUS_ORG_PROBLEM);
        }
        return appliationDataEntity;
    }

    public ApplicationTransitionEntity submitApplication(ApplicationClientEntity clientEntity, boolean isDraft) {
        try {
            List<ApplicationTransitionEntity> transitionEntityList = submitMultipleApplication(Arrays.asList(clientEntity), isDraft);
            if (CollectionUtils.isNotEmpty(transitionEntityList)) {
                return transitionEntityList.get(START_INDEX);
            }
        } catch (Exception exception) {
            logger.error("ERROR OCCURED WHILE SUBMITTING APPLICATION", exception);
        }
        return setFailedTransitionEntity(clientEntity);
    }

    private List<ApplicationDataEntity> getApplicationHistory(ApplicationClientEntity clientEntity) {
        try {
            Object resultObject = exchangeForWorkflow("approval/getApplicationHistory", HttpMethod.POST, String.class, clientEntity);
            return JsonUtils.fromJsonOrThrow(String.valueOf(resultObject), new TypeReference<List<ApplicationDataEntity>>() {
            });
        } catch (Exception exception) {
            logger.error("ERROR OCCURED WHILE GETTING APPLICATION HISTORY", exception);
            return new ArrayList<>();
        }
    }

    public List<ApplicationTransitionEntity> submitMultipleApplication(List<ApplicationClientEntity> clientEntityList, boolean isDraft) throws JsonConversionException {
        String apiMapping = isDraft ? "/approval/draftApplications" : "/approval/submitApplications";
        Object resultObject = exchangeForWorkflow(apiMapping, HttpMethod.POST, String.class, clientEntityList);
        return JsonUtils.fromJsonOrThrow(String.valueOf(resultObject), new TypeReference<List<ApplicationTransitionEntity>>() {
        });
    }

    public ApplicationTransitionEntity approvalProcess(ApplicationClientEntity clientEntity) {
        try {
            return (ApplicationTransitionEntity) exchangeForWorkflow("approval/processApprovalFlow", HttpMethod.POST, ApplicationTransitionEntity.class, clientEntity);
        } catch (Exception exception) {
            logger.error("ERROR OCCURED WHILE PROCESS APPLICATION - CLIENT CONTROLLER", exception);
        }
        return setFailedTransitionEntity(clientEntity);
    }

    public List<ApplicationTransitionEntity> approvalBulkProcess(ApplicationClientEntity clientEntity) throws JsonConversionException {
        Object resultObject = exchangeForWorkflow("approval/processBulkApprovalFlow", HttpMethod.POST, String.class, clientEntity);
        return JsonUtils.fromJsonOrThrow(String.valueOf(resultObject), new TypeReference<List<ApplicationTransitionEntity>>() {
        });
    }

    private String getTargetApplication(Map<String, Object> parameterMap) {
        ApplicationClientEntity clientEntity = getApplicationKeys(parameterMap);
        ApplicationDataEntity applicationDataEntity = getApplicationStepper("approval/getPaginationData", clientEntity);
        return JsonUtils.toPrettyJsonOrNull(applicationDataEntity);
    }

    /**
	 * exchangeForWorkflow method used to call workflow service
	 * 
	 * @param apiMapping
	 * @param methodName
	 * @param returnType
	 * @param data
	 * @return Object
	 */
    private Object exchangeForWorkflow(String apiMapping, HttpMethod methodName, Class<?> returnType, Object data) {
        apiMapping = getExpandedApiPath(apiMapping);
        WebServiceUtils apiUtils = WebServiceUtils.getInstance();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.ALL));
        ResponseEntity<?> resultEntity = apiUtils.exchangeForResponseEntity(apiMapping, methodName, returnType, data, headers);
        return resultEntity.getBody();
    }

    private String getExpandedApiPath(String apiUrl) {
    	String serverDomain = EnvironmentReader.getServerDomain();
        return serverDomain.concat("/nn-workflow-service/").concat(apiUrl);
    }

    private LinkedList<Map<String, Object>> formStepperComponentData(ApplicationDataEntity appliationDataEntity, boolean showBreaker) {
        LinkedList<Map<String, Object>> stepperDataList = new LinkedList<>();
        if (!appliationDataEntity.isUseApproval()) {
            return stepperDataList;
        }
        String applicationStatus = appliationDataEntity.getApplicationStatus();
        boolean isResubmitted = CONST_ONE != appliationDataEntity.getVersion();
        Map<String, Object> firstStepDataMap = getStepMainData(applicationStatus, applicationStatus, false, false, isResubmitted, false, null);
        firstStepDataMap.put(KEY_USER_LIST, Arrays.asList(getApplicantMap(appliationDataEntity)));
        stepperDataList.add(firstStepDataMap);
        boolean isLastStepVerify = setStepApprovers(appliationDataEntity, stepperDataList);
        Map<String, Object> finalStepMap = getStepMainData(applicationStatus, applicationStatus, false, true, isResubmitted, isLastStepVerify, null);
        finalStepMap.put(KEY_HISTORY_BREAKER, showBreaker);
        stepperDataList.add(finalStepMap);
        return stepperDataList;
    }

    private boolean setStepApprovers(ApplicationDataEntity appliationDataEntity, LinkedList<Map<String, Object>> stepperDataList) {
        String applicationStatus = appliationDataEntity.getApplicationStatus();
        List<ApplicationStepEntity> stepEntityList = appliationDataEntity.getApplicationStepEntityList();
        if (CollectionUtils.isEmpty(stepEntityList)) {
            return false;
        }
        stepEntityList.sort(Comparator.comparing(ApplicationStepEntity::getStepOrder));
        stepEntityList.stream().forEach(stepEntity -> setStepData(stepEntity, applicationStatus, stepperDataList));
        int totalSteps = appliationDataEntity.getApplicationStepEntityList().size();
        ApplicationStepEntity stepEntity = stepEntityList.get(totalSteps - CONST_ONE);
        return stepEntity.isVerificationStep();
    }

    private void setStepData(ApplicationStepEntity stepEntity, String applicationStatus, LinkedList<Map<String, Object>> stepperDataList) {
        Map<String, Object> stepDataMap = getStepMainData(stepEntity.getStepStatus(), applicationStatus, true, false, false, false, stepEntity);
        List<ApplicationStepMemberEntity> stepMemberEntityList = stepEntity.getStepMemberEntityList();
        if (CollectionUtils.isEmpty(stepMemberEntityList)) {
            return;
        }
        stepMemberEntityList.sort(Comparator.comparing(ApplicationStepMemberEntity::getApproverOrder));
        stepDataMap.put(KEY_USER_LIST, setStepMemberData(stepMemberEntityList));
        stepperDataList.add(stepDataMap);
    }

    private Map<String, Object> getApplicantMap(ApplicationDataEntity appliationDataEntity) {
        Map<String, Object> applicantMap = new HashMap<>();
        applicantMap.put(KEY_USER_ID, appliationDataEntity.getApplicantId());
        applicantMap.put(KEY_LABEL, getUserProfileName(appliationDataEntity.getApplicantId()));
        applicantMap.put(KEY_DESIGNATION, appliationDataEntity.getApplicantDesignation());
        applicantMap.put(KEY_UPLOAD_PATH, getUserImagePath(appliationDataEntity.getApplicantId()));
        applicantMap.put(KEY_SUB_LABEL, appliationDataEntity.getSubmissionDate());
        applicantMap.put(KEY_COMMENT, appliationDataEntity.getComment());
        return applicantMap;
    }

    private List<Map<String, Object>> setStepMemberData(List<ApplicationStepMemberEntity> stepMemberEntityList) {
        return stepMemberEntityList.stream().map(memberEntity -> {
            Map<String, Object> stepMemberMap = new HashMap<>();
            stepMemberMap.put(KEY_USER_ID, memberEntity.getApproverId());
            stepMemberMap.put(KEY_LABEL, getUserProfileName(memberEntity.getApproverId()));
            stepMemberMap.put(KEY_DESIGNATION, memberEntity.getApproverdesignation());
            stepMemberMap.put(KEY_UPLOAD_PATH, getUserImagePath(memberEntity.getApproverId()));
            stepMemberMap.put(KEY_SUB_LABEL, memberEntity.getStatusUpdatedTime());
            stepMemberMap.put(KEY_COMMENT, memberEntity.getComment());
            stepMemberMap.put(KEY_PROXY, memberEntity.isProxyApproved());
            if (StringUtils.isNotEmpty(memberEntity.getProxyApproverId())) {
                stepMemberMap.put(KEY_PROXY_LABEL, getUserProfileName(memberEntity.getProxyApproverId()));
            }
            return stepMemberMap;
        }).collect(Collectors.toList());
    }

    private Map<String, Object> getStepMainData(String status, String applicationStatus, boolean isApproverStep, boolean isLastStep, boolean isResubmitted, boolean isLastStepVerify, ApplicationStepEntity stepEntity) {
        String locale = UserContext.getInstance().locale();
        boolean isFirstStep = !isApproverStep && !isLastStep;
        Map<String, Object> stepDataMap = getStepperComponentLabel(status, applicationStatus, isFirstStep, isLastStep, isResubmitted, isLastStepVerify, stepEntity);
        String stepIcon = objectToString(stepDataMap, KEY_ICON);
        String stepColor = objectToString(stepDataMap, KEY_COLOR);
        stepDataMap.put(KEY_LABEL, getWfFrameworktext(objectToString(stepDataMap, KEY_LABEL), locale));
        stepDataMap.put(KEY_COMPLETED, StringUtils.isNotEmpty(stepIcon));
        stepDataMap.put(KEY_ACTIVE, ICON_START.equals(stepIcon));
        stepDataMap.put(KEY_STATUS, Arrays.asList(COLOR_SUCCESS, COLOR_WARN, COLOR_ERROR).contains(stepColor) ? stepColor : STRING_EMPTY);
        return stepDataMap;
    }

    private Map<String, Object> getStepperComponentLabel(String status, String applicationStatus, boolean isFirstStep, boolean isLastStep, boolean isResubmitted, boolean isLastStepVerify, ApplicationStepEntity stepEntity) {
        Map<String, Object> stepDataMap = new HashMap<>();
        boolean isWarningStatus = ApprovalStatusEnum.WITHDRAWN.getValue().equals(applicationStatus);
        switch(ApprovalStatusEnum.getEnum(status)) {
            case SUBMITTED:
                setSubmittedStepData(stepDataMap, isFirstStep, isLastStep, isResubmitted, isLastStepVerify);
                break;
            case DRAFT:
                setDraftStepData(stepDataMap, isLastStep);
                break;
            case NOT_SUBMITTED:
                setNotSubmittedStepData(stepDataMap, isFirstStep, isLastStep, isWarningStatus);
                break;
            case INPROGRESS:
                setInprogressStepData(stepDataMap, isFirstStep, isResubmitted, isLastStepVerify);
                break;
            case APPROVED:
                setApprovedStepData(stepDataMap, isFirstStep, isLastStep, stepEntity);
                break;
            case REJECTED:
                setRejectedStepData(stepDataMap, isFirstStep, isLastStep);
                break;
            case SENTBACK:
                setSentbackStepData(stepDataMap, isFirstStep, isLastStep);
                break;
            case WITHDRAWN:
                setWithdrawnStepData(stepDataMap, isFirstStep);
                break;
            case VERIFY:
                setVerifyStepData(stepDataMap);
                break;
            case NOT_VERIFIED:
                setNotVerifiedStepData(stepDataMap, isFirstStep);
                break;
            case VERIFIED:
                setVerifiedStepData(stepDataMap, isFirstStep, isLastStep);
                break;
            default:
                break;
        }
        return stepDataMap;
    }

    private void setSubmittedStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isLastStep, boolean isResubmitted, boolean isLastStepVerify) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, isResubmitted ? APP_RESUBMITTED_TEXT : APP_SUBMITTED_TEXT);
            stepDataMap.put(KEY_ICON, ICON_SUCCESS);
            stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
        } else if (isLastStep) {
            stepDataMap.put(KEY_LABEL, isLastStepVerify ? APP_VERIFIED_TEXT : APP_APPROVED_TEXT);
            stepDataMap.put(KEY_ICON, STRING_EMPTY);
            stepDataMap.put(KEY_COLOR, STRING_EMPTY);
        } else {
            stepDataMap.put(KEY_LABEL, APP_AWAITING_APPROVAL_TEXT);
            stepDataMap.put(KEY_ICON, ICON_START);
            stepDataMap.put(KEY_COLOR, STRING_EMPTY);
        }
    }

    private void setInprogressStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isResubmitted, boolean isLastStepVerify) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, isResubmitted ? APP_RESUBMITTED_TEXT : APP_SUBMITTED_TEXT);
            stepDataMap.put(KEY_ICON, ICON_SUCCESS);
            stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
        } else {
            stepDataMap.put(KEY_LABEL, isLastStepVerify ? APP_VERIFIED_TEXT : APP_APPROVED_TEXT);
            stepDataMap.put(KEY_ICON, STRING_EMPTY);
            stepDataMap.put(KEY_COLOR, STRING_EMPTY);
        }
    }

    private void setNotSubmittedStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isLastStep, boolean isWarningStatus) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, APP_CREATE_TEXT);
            stepDataMap.put(KEY_ICON, ICON_START);
        } else if (isLastStep) {
            stepDataMap.put(KEY_LABEL, APP_APPROVED_TEXT);
            stepDataMap.put(KEY_ICON, STRING_EMPTY);
        } else {
            stepDataMap.put(KEY_LABEL, APP_AWAITING_APPROVAL_TEXT);
            stepDataMap.put(KEY_ICON, STRING_EMPTY);
        }
        stepDataMap.put(KEY_COLOR, isWarningStatus ? COLOR_WARN : STRING_EMPTY);
    }

    private void setDraftStepData(Map<String, Object> stepDataMap, boolean isLastStep) {
        stepDataMap.put(KEY_LABEL, isLastStep ? APP_SAVED_AS_DRAFT_TEXT : APP_DRAFT_TEXT);
        stepDataMap.put(KEY_ICON, ICON_SUCCESS);
        stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
    }

    private void setApprovedStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isLastStep, ApplicationStepEntity stepEntity) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, APP_SUBMITTED_TEXT);
        } else {
            stepDataMap.put(KEY_LABEL, isLastStep ? APP_APPROVED_TEXT : isMinimumApprovalReached(stepEntity) ? APP_REQUEST_APPROVED_TEXT : APP_AWAITING_APPROVAL_TEXT );
        }
        stepDataMap.put(KEY_ICON, stepEntity == null ? ICON_SUCCESS : (isMinimumApprovalReached(stepEntity) ? ICON_SUCCESS : ICON_START));
        stepDataMap.put(KEY_COLOR, stepEntity == null ? COLOR_SUCCESS : (isMinimumApprovalReached(stepEntity) ? COLOR_SUCCESS : STRING_EMPTY));
    }

    private void setRejectedStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isLastStep) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, APP_SUBMITTED_TEXT);
            stepDataMap.put(KEY_ICON, ICON_SUCCESS);
            stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
        } else {
            stepDataMap.put(KEY_LABEL, isLastStep ? APP_REJECTED_TEXT : APP_REQUEST_REJETED_TEXT);
            stepDataMap.put(KEY_ICON, ICON_ERROR);
            stepDataMap.put(KEY_COLOR, COLOR_ERROR);
        }
    }

    private void setSentbackStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isLastStep) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, APP_SUBMITTED_TEXT);
            stepDataMap.put(KEY_ICON, ICON_SUCCESS);
            stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
        } else {
            stepDataMap.put(KEY_LABEL, isLastStep ? APP_SENTBACK_TEXT : APP_REQUEST_SENTBACK_TEXT);
            stepDataMap.put(KEY_ICON, ICON_WARN);
            stepDataMap.put(KEY_COLOR, COLOR_WARN);
        }
    }

    private void setVerifyStepData(Map<String, Object> stepDataMap) {
        stepDataMap.put(KEY_LABEL, APP_AWAITING_VERIFY_TEXT);
        stepDataMap.put(KEY_ICON, ICON_START);
        stepDataMap.put(KEY_COLOR, STRING_EMPTY);
    }

    private void setVerifiedStepData(Map<String, Object> stepDataMap, boolean isFirstStep, boolean isLastStep) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, APP_SUBMITTED_TEXT);
        } else {
            stepDataMap.put(KEY_LABEL, isLastStep ? APP_VERIFIED_TEXT : APP_REQUEST_VERIFIED_TEXT);
        }
        stepDataMap.put(KEY_ICON, ICON_SUCCESS);
        stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
    }

    private void setNotVerifiedStepData(Map<String, Object> stepDataMap, boolean isFirstStep) {
        stepDataMap.put(KEY_LABEL, APP_AWAITING_VERIFY_TEXT);
        stepDataMap.put(KEY_ICON, isFirstStep ? ICON_START : STRING_EMPTY);
        stepDataMap.put(KEY_COLOR, STRING_EMPTY);
    }

    private void setWithdrawnStepData(Map<String, Object> stepDataMap, boolean isFirstStep) {
        if (isFirstStep) {
            stepDataMap.put(KEY_LABEL, APP_SUBMITTED_TEXT);
            stepDataMap.put(KEY_ICON, ICON_SUCCESS);
            stepDataMap.put(KEY_COLOR, COLOR_SUCCESS);
        } else {
            stepDataMap.put(KEY_LABEL, APP_WITHDRAWN_TEXT);
            stepDataMap.put(KEY_ICON, ICON_WARN);
            stepDataMap.put(KEY_COLOR, COLOR_WARN);
        }
    }

    private String getWfFrameworktext(String textId, String locale) {
        try {
            return cacheService.getFrameworkTextDefinitionData(textId, locale);
        } catch (QueryException exception) {
            logger.error("ERROR OCCURS WHILE GETTING FRAMEWORK TEXT FROM CACHE", exception);
            return textId;
        }
    }

    /**
	 * objectToString common function used to converts object to string  from passed map
	 * @param paramMap
	 * @param mapKey
	 * @return result string
	 */
    private String objectToString(Map<String, Object> paramMap, String mapKey) {
        String resultString = STRING_EMPTY;
        if (Objects.nonNull(paramMap.get(mapKey))) {
            resultString = paramMap.get(mapKey).toString();
        }
        return resultString;
    }

    /**
	 * getUserProfileName method  is used to get user profile name for given user id from cache.
	 * 
	 * @param paramMap
	 * 
	 * @return profile name
	 */
    private String getUserProfileName(String userId) {
        try {
            Map<String, Object> userProfileDataMap = cacheService.getUserDataByTenantId(userId);
            return userProfileDataMap.get("first_name").toString().concat(" ").concat(userProfileDataMap.get("last_name").toString());
        } catch (Exception exception) {
            logger.warn("ERROR OCCURS WHILE GETTING FIRST NAME OR LAST NAME FOR USER - " + userId + " FROM CACHE", exception);
            return StringUtils.EMPTY;
        }
    }

    private String getUserImagePath(String userId) {
        String imagePath = STRING_EMPTY;
        try {
            Map<String, Object> userData = cacheService.getUserDataByTenantId(userId);
            if (StringUtils.isNotEmpty(objectToString(userData, "user_image_path"))) {
                imagePath = userData.get("user_image_path").toString();
            }
        } catch (Exception exception) {
            logger.error("IMAGE PATH NOT FOUND FOR USER ID " + userId, exception);
            return imagePath;
        }
        return imagePath;
    }

    /**
	 * getScreenName method is used to get screen name from cache
	 * 
	 * @param screenId
	 * 
	 * @return screen name from cache
	 */
    private String getScreenName(String screenId) {
        String locale = UserContext.getInstance().locale();
        try {
            Map<String, Object> screenConfigurationData = cacheService.getScreenConfigurationDataByLocale(screenId, locale);
            return objectToString(screenConfigurationData, "screenConfigurationText.screenName");
        } catch (Exception exception) {
            logger.error("ERROR OCCURS WHILE GETTING SCREEN NAME FOR SCREEN ID - " + screenId + " FROM CACHE", exception);
            return StringUtils.EMPTY;
        }
    }

    private void setPaginationDetails(ApplicationClientEntity clientEntity, Map<String, Object> parameterMap) {
        if (parameterMap.containsKey("sts") && StringUtils.isNotEmpty("sts")) {
            clientEntity.setPaginationStatus(decideStatusByCode(objectToString(parameterMap, "sts")));
            clientEntity.setMaster(ApprovalStatusEnum.MASTER.getValue().equals(clientEntity.getPaginationStatus()));
        }
        if (parameterMap.containsKey("scol") && StringUtils.isNotEmpty("scol")) {
            clientEntity.setPaginationSortColumn(decideSortColumnByCode(clientEntity, objectToString(parameterMap, "scol")));
        }
        if (parameterMap.containsKey("skey") && StringUtils.isNotEmpty("skey")) {
            clientEntity.setPaginationSearchKey(objectToString(parameterMap, "skey"));
        }
        if (parameterMap.containsKey(PAGINATING_INDEX) && Objects.nonNull(parameterMap.get(PAGINATING_INDEX))) {
            clientEntity.setPaginationIndex(new BigInteger(objectToString(parameterMap, PAGINATING_INDEX)));
        }
        if (parameterMap.containsKey(APP_UNIQUE_ID) && StringUtils.isNotEmpty(APP_UNIQUE_ID)) {
        	clientEntity.setApplicationUniqueId(objectToString(parameterMap, APP_UNIQUE_ID));
        }
        clientEntity.setApplicantTray(parameterMap.containsKey("apt") && StringUtils.isNotEmpty("apt"));
        clientEntity.setPaginationPriority(parameterMap.containsKey("urg") && StringUtils.isNotEmpty("urg"));
    }

    private String decideStatusByCode(String statusCode) {
        String status;
        switch(statusCode) {
            case "1":
                status = ApprovalStatusEnum.APPROVED.getValue();
                break;
            case "2":
                status = ApprovalStatusEnum.SENTBACK.getValue();
                break;
            case "3":
                status = ApprovalStatusEnum.REJECTED.getValue();
                break;
            case "4":
                status = ApprovalStatusEnum.CONFIRM.getValue();
                break;
            case "5":
                status = ApprovalStatusEnum.VERIFY.getValue();
                break;
            case "6":
                status = ApprovalStatusEnum.MASTER.getValue();
                break;
            case "7":
                status = ApprovalStatusEnum.PROXY.getValue();
                break;
            case "8":
                status = ApprovalStatusEnum.WITHDRAWN.getValue();
                break;
            case "9":
                status = ApprovalStatusEnum.DRAFT.getValue();
                break;
            default:
                status = ApprovalStatusEnum.SUBMITTED.getValue();
                break;
        }
        return status;
    }

    private String decideSortColumnByCode(ApplicationClientEntity clientEntity, String sortCode) {
        String sortingColumn;
        int orderIndex = sortCode.indexOf('0');
        if (START_INDEX == orderIndex) {
            clientEntity.setPaginationSortOrder(SortType.ASC);
        } else {
            clientEntity.setPaginationSortOrder(SortType.DESC);
        }
        String sortColumnCode = sortCode.replace("0", "");
        switch(sortColumnCode) {
            case "2":
                sortingColumn = "screenName";
                break;
            case "3":
                sortingColumn = "userName";
                break;
            case "4":
                sortingColumn = "dueDateTime";
                break;
            case "5":
                sortingColumn = "description";
                break;
            case "6":
                sortingColumn = "priority";
                break;
            case "7":
                sortingColumn = APPLICATION_UID;
                break;
            default:
                sortingColumn = "submitDateTime";
                break;
        }
        return sortingColumn;
    }

    private ApplicationTransitionEntity setFailedTransitionEntity(ApplicationClientEntity clientEntity) {
        ApplicationTransitionEntity transitionEntity = new ApplicationTransitionEntity();
        transitionEntity.setApplicationId(clientEntity.getApplicationId());
        transitionEntity.setScreenId(clientEntity.getScreenId());
        transitionEntity.setVersion(clientEntity.getVersion());
        transitionEntity.setMessage("FAILED");
        transitionEntity.setSuccess(false);
        return transitionEntity;
    }

    public UUID generateApplication() {
        return UUID.randomUUID();
    }
    
    /**
	 * isMinimumApprovalReached checks whether the minimal approval count reached
	 * 
	 * @param stepEntity
	 * @return boolean
	 */
	private boolean isMinimumApprovalReached(ApplicationStepEntity stepEntity) {
		if (stepEntity == null) {
			return false;
		}
		int minApprovalCount = stepEntity.getMinimumApprovalCount();
		int membersCount = stepEntity.getStepMemberList().size();
		if( (Objects.isNull(minApprovalCount) || stepEntity.getMinimumApprovalCount() < 1) || (minApprovalCount > membersCount) ) {
			logger.info("MinApprovalCount is null, <0, MinApprovalCount > MembersCount");
			if(membersCount == stepEntity.getActualApprovalCount()) {
				logger.info("MembersCount{} = ActualApprovalCount{}", membersCount, stepEntity.getActualApprovalCount());
				return true;
			}
			return false;
		}
		else {
			logger.info("MinApprovalCount {} <= ActualApprovalCount {}", minApprovalCount, stepEntity.getActualApprovalCount());
			return stepEntity.getMinimumApprovalCount() <= stepEntity.getActualApprovalCount();
		}
	}
}
