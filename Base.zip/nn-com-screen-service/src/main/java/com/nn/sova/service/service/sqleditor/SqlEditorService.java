package com.nn.sova.service.service.sqleditor;

import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * SqlEditorService interface
 * 
 * @author Vivek Kannan E
 */
public interface SqlEditorService {

	/**
	 * loadSuggestion.
	 *
	 * @param requestMap the request param entity has info about search information
	 *                   and product key
	 * @throws QueryException
	 */
	public Map<String, Object> loadSuggestion(Map<String, Object> requestMap) throws QueryException;

}
