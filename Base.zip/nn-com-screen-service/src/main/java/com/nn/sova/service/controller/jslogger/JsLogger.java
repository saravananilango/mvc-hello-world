package com.nn.sova.service.controller.jslogger;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.service.utils.flowlog.AppgenFlowLog;
import com.nn.sova.utility.context.ContextBean;

@SovaMapping("/jslogger")
public class JsLogger {

    /**
     * Js logger.
     *
     * @param paramMap the param map
     */
    //post_lambda 
    @SovaMapping(value = "/logger", method = SovaRequestMethod.POST)
    public void jsLogger(SovaHttpRequest request, SovaHttpResponse response) {
        try {
        	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        	List<Map<String, Object>> logList = CommonUtils.getNonNullList(paramMap.get("logList"));
        	String requestId = ContextBean.getRequestId();
        	logList.stream().forEach(action -> {
        		String eventRequestId = Objects.toString(action.get("requestId"), requestId);
        		ContextBean.setRequestId(eventRequestId);
        		String blockId = Objects.toString(action.get("blockId"), StringUtils.EMPTY);
        		String componentId = Objects.toString(action.get("componentId"), StringUtils.EMPTY);
        		String eventName = Objects.toString(action.get("eventName"), StringUtils.EMPTY);
        		String componentLabel = Objects.toString(action.get("componentLabel"), StringUtils.EMPTY);
        		String componentTagName = Objects.toString(action.get("componentTagName"), StringUtils.EMPTY);
        		String parentId = Objects.toString(action.get("parentId"), StringUtils.EMPTY);
        		String appGenLoopIndex = Objects.toString(action.get("appGenLoopIndex"), StringUtils.EMPTY);
        		AppgenFlowLog.log(blockId, componentId, eventName, action.get("blockOutput"), componentLabel, componentTagName, parentId,appGenLoopIndex);
        	});
        	ContextBean.setRequestId(requestId);
        }
        finally {
        	AppgenFlowLog.pushLogs();
        }
    }
}
