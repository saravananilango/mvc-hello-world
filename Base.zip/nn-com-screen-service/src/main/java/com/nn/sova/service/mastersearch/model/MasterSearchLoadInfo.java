package com.nn.sova.service.mastersearch.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MasterSearchLoadInfo class is used to load the master table data.
 * 
 * @author Logchand
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterSearchLoadInfo {

	/** The data class. */
	private String dataFormat;

	/** The table name. */
	private String tableName;

	/** The set column name. */
	private String setColumnName;

	/** The show column name. */
	private String showColumnName;

	/** The max matches. */
	private int maxMatches;

	/** The master id. */
	private String masterId;

	/** The filter fields. */
	private String filterFields;

	/** The extra fields. */
	private String extraFields;

	/** The sort by. */
	private String sortBy;

	/** The is distinct. */
	private boolean isDistinct;

	/** The product name. */
	private String productName;

	/** The key column name. */
	private String keyColumnName;
	
	/** The independent tenant flag. */
	private boolean independentTenantFlag;
	
	/** The sort type.*/
  	private String sortType;
}
