package com.nn.sova.service.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.context.EventsLogBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.EventLogHelper;

@SovaMapping("/frameworkController")
public class FrameworkController {

    private Logger clientSideLogger = LogManager.getLogger("eventlog");

    /**
	 * getMessageDefinitionData is to get the message
	 *
	 * @param messageMap contains the messageId
	 * @return the string
	 * @throws QueryException 
	 */
    //post_lambda 
	@SovaMapping(value = "/getMessageDefinitionData", method = SovaRequestMethod.POST)
    public String getMessageDefinitionData(SovaHttpRequest request, SovaHttpResponse response) throws QueryException {
        Map<String, Object> messageMap = (Map<String, Object>) request.getBody();
        String messageId = messageMap.get("messageId").toString();
        MessageDefinitionEntity messageData = CacheService.getInstance().getMessageDefinitionData(messageId, ContextBean.getLocale());
        return JsonUtils.toPrettyJsonOrNull(messageData);
    }

    /**
	 * getBusinessPageUpdates method is used to handle chat/notification on business load
	 * and also updates the screen performance time
	 * @param paramData
	 * @return
	 * @throws JsonConversionException 
	 */
	@SovaMapping(value = "/getBusinessPageUpdates", method = { SovaRequestMethod.POST })
    public void getBusinessPageUpdates(SovaHttpRequest request, SovaHttpResponse response) throws JsonConversionException {
		Map<String, Object> paramData = (Map<String, Object>) request.getBody();
        if (Objects.nonNull(paramData)) {
            updateEventsLog(paramData);
        }
    }

    @SuppressWarnings("unchecked")
	private void updateEventsLog(Map<String, Object> dataMap) throws JsonConversionException {
        String pageLoadTime = dataMap.get("pageLoadTime").toString();
        String renderTime = dataMap.get("renderTime").toString();
        EventsLogBean.setEventType("onPageLoad");
        EventLogHelper.doUpdateEventsLog(Long.parseLong(pageLoadTime), "page_load");
        EventLogHelper.doUpdateEventsLog(Long.parseLong(renderTime), "page_render");
    }

    /**
	 * getPhoneInputData is to get the phone input data
	 *
	 * @param messageMap contains the messageId
	 * @return the string
	 * @throws QueryException 
	 */
    @SuppressWarnings("unchecked")
    //post_lambda 
	@SovaMapping(value = "/getPhoneInputData", method = SovaRequestMethod.POST)
    public Map<String, Object> getPhoneInputData(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> messageMap = (Map<String, Object>) request.getBody();
        Map<String, Object> phoneData;
        try {
            phoneData = (Map<String, Object>) CacheService.getInstance().getCountriesPhonePrefixInfo();
            if (Objects.nonNull(phoneData) && Objects.nonNull(phoneData.get("countrySelect"))) {
                return Collections.singletonMap("data", phoneData.get("countrySelect"));
            } else {
                return Collections.singletonMap("data", new ArrayList<>());
            }
        } catch (QueryException e) {
            clientSideLogger.error("Error occured while getting phone data", e);
            return Collections.singletonMap("data", new ArrayList<>());
        }
    }

    /**
	 * getLocaleInputData is to get the locale input data
	 *
	 * @param parameterMap contains the messageId
	 * @return the string
	 * @throws QueryException 
	 */
    @SuppressWarnings("unchecked")
    //post_lambda 
	@SovaMapping(value = "/getLocaleInputData", method = SovaRequestMethod.POST)
    public Map<String, Object> getLocaleInputData(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> parameterMap = (Map<String, Object>) request.getBody();
        List<Map<String, Object>> localeData;
        try {
            localeData = (List<Map<String, Object>>) CacheService.getInstance().getLocaleBusinessObject();
            if (Objects.nonNull(localeData) && CollectionUtils.isNotEmpty(localeData)) {
                return Collections.singletonMap("data", localeData.stream().filter(predicate -> Objects.nonNull(predicate.get("locale")) && predicate.get("locale").toString().equals(ContextBean.getLocale())).collect(Collectors.toList()));
            } else {
                return Collections.singletonMap("data", new ArrayList<>());
            }
        } catch (QueryException e) {
            clientSideLogger.error("Error occured while getting locale data", e);
            return Collections.singletonMap("data", new ArrayList<>());
        }
    }

    /**
	 * readFileFromCommonSpace is to read file from common space
	 *
	 * @param dataMap
	 * @return file
	 * @throws QueryException 
	 */
    //post_lambda 
	@SovaMapping(value = "/readFileFromCommonSpace", method = SovaRequestMethod.POST)
    public Map<String, Object> readFileFromCommonSpace(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String serviceID = Objects.nonNull(dataMap.get("serviceId")) ? dataMap.get("serviceId").toString() : "";
        String fileName = Objects.nonNull(dataMap.get("fileName")) ? dataMap.get("fileName").toString() : "";
        Map<String, Object> returnMap = new HashMap<String, Object>();
        try {
            return readFile(serviceID, fileName, returnMap);
        } catch (IOException e) {
            e.printStackTrace();
            clientSideLogger.error("Error occured while reading file", e);
            return new HashMap<String, Object>();
        }
    }

    /**
	 * readFile
	 * @param serviceId
	 * @param fileName
	 * @param returnMap
	 * @return
	 * @throws IOException
	 */
    private Map<String, Object> readFile(String serviceId, String fileName, Map<String, Object> returnMap) throws IOException {
        String folderPath = getUploadPath() + "/" + serviceId;
        File folder = new File(folderPath);
        File[] files = folder.listFiles();
        File file = null;
        if (Objects.nonNull(files)) {
            for (int i = 0; i < files.length; i++) {
                if (files[i].isFile()) {
                    String filename = files[i].getName();
                    int lastPeriodSos = filename.lastIndexOf(".");
                    if (lastPeriodSos > 0) {
                        filename = filename.substring(0, lastPeriodSos);
                        if (filename.contentEquals(fileName)) {
                            file = files[i];
                        }
                    }
                }
            }
        }
        if (Objects.nonNull(file)) {
            Path path = file.toPath();
            String fileType = Files.probeContentType(path);
            byte[] bytes = null;
            try {
                bytes = loadFile(file);
                byte[] encoded = Base64.encodeBase64(bytes);
                String encodedString = new String(encoded, StandardCharsets.US_ASCII);
                returnMap.put("fileString", encodedString);
                returnMap.put("contentType", fileType);
                returnMap.put("status", true);
            } catch (IOException e) {
                returnMap.put("status", false);
                clientSideLogger.error("Error occured while loading file", e);
            }
        }
        return returnMap;
    }

    /**
	 * loadFile
	 * @param file
	 * @return
	 * @throws IOException
	 */
    private byte[] loadFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
        long length = file.length();
        if (length > Integer.MAX_VALUE) {
            clientSideLogger.error("File is too large");
        }
        byte[] bytes = new byte[(int) length];
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
            offset += numRead;
        }
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file " + file.getName());
        }
        is.close();
        return bytes;
    }

    /**
	 * getUploadPath method is used to get the uploadpath
	 * 
	 * @return
	 */
    private String getUploadPath() {
        try {
            return CacheService.getInstance().getEnvironmentPropertiesByKey("upload_path");
        } catch (Exception execption) {
            clientSideLogger.info("Exception occured while get Upload Path");
        }
        return StringUtils.EMPTY;
    }
}
