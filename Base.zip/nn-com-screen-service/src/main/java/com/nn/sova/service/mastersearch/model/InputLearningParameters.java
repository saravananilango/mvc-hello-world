package com.nn.sova.service.mastersearch.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * InputLearningParameters class is used to get and set the data of input
 * learning.
 *
 * @author Logchand
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InputLearningParameters {

	/** The screen id. */
	private String screenId;

	/** The user id. */
	private String userId;

	/** The component id. */
	private String componentId;

	/** The learning value. */
	private String learningValue;
}
