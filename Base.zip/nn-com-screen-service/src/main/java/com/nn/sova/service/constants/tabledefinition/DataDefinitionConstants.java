package com.nn.sova.service.constants.tabledefinition;

import java.util.Arrays;
import java.util.List;

/**
 * DataDefinitionConstants contains the constants for data manipulation.
 * 
 * @author Sakthivel
 */
public class DataDefinitionConstants {

	/**
	 * charset primary keys
	 */
	public static final String[] CHARSET_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS = { "charset_id" };

	/**
	 * charset primary keys
	 */
	public static final String[] CHARSET_DEFINITION_PRIMARY_CONSTRAINTS = { "charset_id" };

	/**
	 * constant for charset offline table
	 */
	public static final String CHARSET_DEFINITION_OFFLINE = "charset_definition_offline";

	/**
	 * constant for charset table
	 */
	public static final String CHARSET_DEFINITION = "charset_definition";

	/**
	 * constant for value list which are used in upsert operation
	 */
	public static final String VALUE_LIST = "valueList";

	/**
	 * constant for changed columns
	 */
	public static final String UPDATE_COLUMNS = "updateColumns";

	/**
	 * constant for error which returned in db operations
	 */
	public static final String ERROR = "error";

	/**
	 * constant for error message returned in db operations 
	 */
	public static final String MESSAGE = "message";

	/**
	 * constant for data class offline table
	 */
	public static final String DATA_FORMAT_DEFINITION_OFFLINE = "data_format_definition_offline";

	/**
	 * data class primary keys
	 */
	public static final String[] DATA_FORMAT_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS = { "data_format" };

	/**
	 * constant for data class table
	 */
	public static final String DATA_ELEMENT_DEFINITION_OFFLINE = "data_element_definition_offline";

	/**
	 * data class primary keys
	 */
	public static final String[] DATA_ELEMENT_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS = { "data_element" };

	/**
	 * charset columns
	 */
	public static final List<String> CHARSET_DEFINITION_COLUMNS = Arrays.asList("charset_id", "full_katakana",
			"half_katakana", "upper_case", "lower_case", "full_hiragana", "digits", "symbols",
			"tab", "line_separator", "all_char", "description", "enable_characters", "disable_characters",
			"space", "charset_name", "product_code","version_no");

	/**
	 * constant for charset id
	 */
	public static final String CHARSET_ID = "charset_id";

	/**
	 * auto number columns
	 */
	public static final List<String> AUTONUMBER_DEFINITION_COLUMNS = Arrays.asList("autonumber_def_id",
			"reset_cycle", "starting_number", "number_of_digits", "prefix_text", "customer_code_flag",
			"system_id_flag", "date_format", "separator", "increment_by", "tenant_dependent");
	
	/**
	 * auto number tenant columns
	 */
	public static final List<String> AUTONUMBER_TENANT_DEFINITION_COLUMNS = Arrays.asList("autonumber_def_id",
			"reset_cycle", "starting_number", "number_of_digits", "prefix_text", "customer_code_flag",
			"system_id_flag", "date_format", "separator", "increment_by");

	/**
	 * auto number primary key
	 */
	public static final String[] AUTONUMBER_DEFINITION_PRIMARY_CONSTRAINTS = { "autonumber_def_id" };

	/**
	 * auto number primary key
	 */
	public static final String[] AUTONUMBER_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS = { "autonumber_def_id" };
	
	/**
	 * auto number tenant primary key
	 */
	public static final String[] AUTONUMBER_TENANT_DEFINITION_PRIMARY_CONSTRAINTS = { "autonumber_def_id", "tenant_id" };

	/**
	 * data class columns
	 */
	public static final List<String> DATA_FORMAT_DEFINITION_COLUMNS = Arrays.asList("data_format", "charset_id",
			"min_length", "max_length", "data_type", "element_type", "min_value", "max_value",
			"max_decimal", "precision", "regex_pattern", "input_method", "password_flag", "max_date",
			"min_date", "default_value", "master_id", "data_range", "in_condition",
			"not_in_condition", "product_code","version_no");

	/**
	 * data class primary keys
	 */
	public static final String[] DATA_FORMAT_DEFINITION_PRIMARY_CONSTRAINTS = { "data_format" };

	/**
	 * constant for data class table
	 */
	public static final String DATA_FORMAT_DEFINITION = "data_format_definition";

	/**
	 * constant for data class
	 */
	public static final String DATA_FORMAT = "data_format";

	/**
	 * constant for element type
	 */
	public static final String ELEMENT_TYPE = "element_type";

	/**
	 * constant for master
	 */
	public static final String MASTER = "Master";

	/**
	 * constant for division
	 */
	public static final String DIVISION = "Division";

	/**
	 * constant for auto number
	 */
	public static final String AUTONUMBER = "Autonumber";

	/**
	 * constant for auto number id
	 */
	public static final String AUTONUMBER_DEF_ID = "autonumber_def_id";

	/**
	 * master columns
	 */
	public static final List<String> MASTER_DEFINITION_COLUMNS = Arrays.asList("master_id", "table_name",
			"set_column_name", "show_column_name", "max_matches", "filter_fields", "sort_by",
			"extra_fields", "distinct_flag", "key_column_name", "product_code","version_no");

	/**
	 * master primary keys
	 */
	public static final String[] MASTER_DEFINITION_PRIMARY_CONSTRAINTS = { "master_id" };

	/**
	 * master primary keys
	 */
	public static final String[] MASTER_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS = { "master_id" };

	/**
	 * constant for master id
	 */
	public static final String MASTER_ID = "master_id";

	/**
	 * division columns
	 */
	public static final List<String> DIVISION_DEFINITION_COLUMNS = Arrays.asList("data_format", "value",
			"default_value", "display_order");
	
	/**
	 * division primary keys
	 */
	public static final String[] DIVISION_DEFINITION_PRIMARY_CONSTRAINTS = { "data_format", "value" };

	/**
	 * division primary keys
	 */
	public static final String[] DIVISION_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS = { "data_format", "value" };

	/**
	 * constant for master table
	 */
	public static final String MASTER_DEFINITION = "master_definition";

	/**
	 * constant for master table
	 */
	public static final String MASTER_DEFINITION_OFFLINE = "master_definition_offline";

	/**
	 * constant for division table
	 */
	public static final String DIVISION_DEFINITION = "division_definition";

	/**
	 * constant for auto number table
	 */
	public static final String AUTONUMBER_DEFINITION = "autonumber_definition";

	/**
	 * constant for auto number table
	 */
	public static final String AUTONUMBER_DEFINITION_OFFLINE = "autonumber_definition_offline";
	
	/**
	 * constant for auto number tenant offline table
	 */
	public static final String AUTONUMBER_TENANT_DEFINITION_OFFLINE = "autonumber_tenant_definition_offline";
	
	/**
	 * constant for auto number tenant table
	 */
	public static final String AUTONUMBER_TENANT_DEFINITION = "autonumber_tenant_definition";

	/**
	 * constant for data element table
	 */
	public static final String DATA_ELEMENT_DEFINITION = "data_element_definition";

	/**
	 * data element columns
	 */
	public static final List<String> DATA_ELEMENT_DEFINITION_COLUMNS = Arrays.asList("data_element", "data_format",
			"description", "product_code", "short_text", "medium_text", "long_text", "example_text", "hint_text",
			"sample_data", "help_code","version_no","component_name");

	/**
	 * data element primary keys
	 */
	public static final String[] DATA_ELEMENT_DEFINITION_PRIMARY_CONSTRAINTS = { "data_element" };

	/**
	 * constant for division table
	 */
	public static final String DIVISION_DEFINITION_OFFLINE = "division_definition_offline";

	/**
	 * constant for input element type
	 */
	public static final String INPUT = "Input";

	/**
	 * constant for data range element type
	 */
	public static final String DATA_RANGE = "Data Range";

	/**
	 * constant for master list
	 */
	public static final String MASTER_LIST = "masterList";

	/**
	 * constant for auto number list
	 */
	public static final String AUTO_NUMBER_LIST = "autoNumberList";

	/**
	 * constant for division list
	 */
	public static final String DIVISION_LIST = "divisionList";

	/**
	 * constant for data class list
	 */
	public static final String DATA_FORMAT_LIST = "dataFormatList";

	/**
	 * constant for update operation
	 */
	public static final String IS_UPDATE = "isUpdate";

	/**
	 * constant for table definition column details table
	 */
	public static final String TABLE_DEFINITION_COLUMN_DETAILS = "table_definition_column_details";

	/**
	 * constant for table definition column details table
	 */
	public static final String TABLE_DEFINITION_COLUMN_DETAILS_META = "table_definition_column_details_meta";

	/**
	 * constant for data element
	 */
	public static final String DATA_ELEMENT = "data_element";

	/**
	 * constant for data class view
	 */
	public static final String DATA_FORMAT_DEFINITION_VIEW = "data_format_definition_view";

	/**
	 * constant for table definition column details view
	 */
	public static final String TABLE_DEFINITION_COLUMN_DETAILS_VIEW = "table_definition_column_details_view";

	/**
	 * constant for data element view
	 */
	public static final String DATA_ELEMENT_DEFINITION_VIEW = "data_element_definition_view";

	/**
	 * constant for primary key list
	 */
	public static final String PRIMARY_KEY_LIST = "primaryKeyList";

	/**
	 * constant for data type
	 */
	public static final String DATA_TYPE = "data_type";

	/**
	 * constant for table name list
	 */
	public static final String TABLE_NAME_LIST = "tableNameList";

	/**
	 * constant for data class
	 */
	public static final String DATACLASS = "dataFormat";

	/**
	 * constant for current details
	 */
	public static final String CURRENT_DETAILS = "currentDetails";

	/**
	 * constant for previous details
	 */
	public static final String PREVIOUS_DETAILS = "previousDetails";

	/**
	 * constant for max decimal
	 */
	public static final String MAX_DECIMAL = "max_decimal";

	/**
	 * constant for precision
	 */
	public static final String PRECISION = "precision";

	/**
	 * constant for max length
	 */
	public static final String MAX_LENGTH = "max_length";

	/**
	 * constant for table name
	 */
	public static final String TABLENAME = "tableName";

	/**
	 * constant for upsert
	 */
	public static final String UPSERT = "upsert";

	/**
	 * constant for query type
	 */
	public static final String QUERY_TYPE = "queryType";

	/**
	 * constant for delete
	 */
	public static final String DELETE = "delete";

	/**
	 * constant for table definition
	 */
	public static final String TABLE_DEFINITION = "table_definition";

	/**
	 * constant for table unique definition
	 */
	public static final String TABLE_UNIQUE_DEFINITION = "table_unique_constraint_definition";

	/**
	 * constant for table index definition
	 */
	public static final String TABLE_INDEX_DEFINITION = "table_index_definition";

	/**
	 * constant for table foreign constraints table
	 */
	public static final String TABLE_DEFINITION_FOREIGN_CONSTRAINTS_DETAILS = "table_foreign_constraints_details";

	/**
	 * constant for table name
	 */
	public static final String TABLE_NAME = "table_name";

	/**
	 * constant for data definition table list
	 */
	public static final List<String> DATA_DEFINITION_TABLE_LIST = Arrays.asList("charset_definition",
			"data_format_definition", "master_definition", "autonumber_deefinition", "division_definition",
			"data_element_definition");
	
	/**
	 * constant for change request details
	 */
	public static final String CHANGE_REQUEST_DETAILS = "changeRequestDetails";
	
	/**
	 * constant for change request id
	 */
	public static final String CHANGE_REQUEST_ID = "changeRequestId";
	
	/**
	 * constant for charset view
	 */
	public static final String CHARSET_DEFINITION_VIEW = "charset_definition_view";
	
	/**
	 * constant for master view
	 */
	public static final String MASTER_DEFINITION_VIEW = "master_definition_view";
	
	/**
	 * constant for tenant id
	 */
	public static final String TENANT_ID = "tenant_id";
	
	/**
	 * constant for default value
	 */
	public static final String DEFAULT_VALUE = "default_value";
	
	/**
	 * constant for autoNumberTenantList
	 */
	public static final String AUTO_NUMBER_TENANT_LIST = "autoNumberTenantList";

}
