package com.nn.sova.service.workflow.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.nn.sova.service.workflow.enums.ApprovalStatusEnum;

import lombok.Data;

/**
 * ApplicationStepMemberEntity entity class used to holds the step 
 * member index and other details of member in a respective step
 * 
 * @author punithanantony.d@vaken.cloud (Punithan Antony Das)
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationStepMemberEntity{
	
	/** step order*/
	private int stepOrder = 0;
	
	/** Approver order in a step*/
	private int approverOrder;
	
	/** Approver user id in a current step*/
	private String approverId;
	
	/** Approver Full Name */
	private String approverName = "";
	
	/** Approver Image URL */
	private String approverImageUrl = "";
	
	/** PROXY approver user id */
	private String proxyApproverId = "";
	
	/** PROXY Approver Full Name */
	private String proxyApproverName = "";
	
	/** PROXY Approver Image URL */
	private String proxyApproverImageUrl = "";
	
	/**designation code of the role in step */
	private String designationCode = "";
	
	/**position order */
	private Integer posOrder = null;
	
	/**position code */
	private String posCode = "";
	
	/**employee id */
	private String empId = "";
	
	/** employee number of the step user */
	private String empNo = "";

	/**approver status */
	private String approverStatus = ApprovalStatusEnum.NOT_SUBMITTED.getValue();
	
	/** approver confirming status*/
	private String confirmStatus = "";
	
	/** whether the approver in step is current logged in user*/
	private boolean currentUser = false;
	
	/** whether the PROXY approver in step is eligible for approval operation*/
	private boolean proxyApproved = false;
	
	/** whether the confirm status is waiting for noticed confirmation*/
	private boolean needToConfirm = false;
	
	/** whether the confirm status is noticed*/
	private boolean confirmed = false;
	
	/** whether the current step is upcoming and status is NOT VERIFIED */
	private boolean notVerified = false;
	
	/** whether the current step is ready for verification*/
	private boolean verify = false;
	
	/** whether the current step is ready for approval action*/
	private boolean submitted = false;
	
	/** whether the current step index is upcoming and status is NOT SUBMITTED*/
	private boolean notSubmitted = false;
	
	/** whether the current step index is eligible to be a master index*/
	private boolean master = false;
	
	/** approver status updated time*/
	private String statusUpdatedTime;
	
	/** approver status updated time*/
	private Object statusUpdatedTimeStamp;
	
	/** comment given by the approver while approval action*/
	private String comment = "";
	
	/** Actually user id by whom the step is approved*/
	private String approvedBy = "";
	
	/** Approver's Designation */
	private String approverdesignation;
}