package com.nn.sova.service.mastersearch.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MasterInputLearningParameters class is used to get and set the master data of input learning.
 *
 * @author Logchand
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterInputLearningParameters {

	/** The search id. */
	private String searchId;
	
	/** The set text. */
	private String setText;
	
	/** The show text. */
	private String showText;
	
	/** The screen id. */
	private String screenId;
	
	/** The user id. */
	private String userId;
	
}
