package com.nn.sova.service.jobmanager.dao;

import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.ARTIFACT_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.GROUP_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_CALLBACK_URLS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_EXTERNAL_JAR;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEFINITION_VIEW;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_DESCRIPTION;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_DEF_NAME;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_EXCLUSIVITY_TYPE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_PARAMETERS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_STATE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.JOB_TYPE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.MAIN_CLASS;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.PRODUCT_CODE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.SUB_PRODUCT_CODE;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.TENANT_ID;
import static com.nn.sova.utility.jobmanager.constants.JobManagerConstants.VERSION;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.jobmanager.entity.JobDefinitionExternalJar;
import com.nn.sova.utility.jobmanager.constants.JobType;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;


/**
 * The DAO for job_definition_framework_jar table.
 *
 * @author praveen_kumar_nr
 */
final class JobDefinitionExternalJarDao implements
	JobDefinitionDao<JobDefinitionExternalJar> {

	/** The Constant LOGGER. */
	private static final ApplicationLogger LOGGER = ApplicationLogger
		.create(JobDefinitionExternalJarDao.class);

	/** The Constant UPDATE_COLUMNS. */
	private static final List<String> UPDATE_COLUMNS = Arrays.asList(JOB_DEF_NAME,
		JOB_DEF_DESCRIPTION, JOB_TYPE, PRODUCT_CODE,
		SUB_PRODUCT_CODE, GROUP_ID, ARTIFACT_ID,
		VERSION, MAIN_CLASS, JOB_PARAMETERS,
		JOB_STATE, JOB_EXCLUSIVITY_TYPE, JOB_CALLBACK_URLS);

	/** The Constant PRIMARY_KEYS. */
	private static final String[] PRIMARY_KEYS = { TENANT_ID, JOB_DEF_ID };

	/**
	 * Instantiates a new job definition framework jar dao.
	 */
	JobDefinitionExternalJarDao() {
		// use singleton instance
	}

	@Override
	public Optional<JobDefinitionExternalJar> select(String jobDefId) {
		try {
			return new QueryBuilder().btSchema()
				.select().from(JOB_DEFINITION_VIEW)
				.where(ConditionBuilder.instance()
					.eq(JOB_DEF_ID, jobDefId)
					.and().eq(JOB_TYPE, JobType.EXTERNAL_JAR.getValue()))
				.build(false).execute()
				.stream().findFirst()
				.map(JobDefinitionExternalJar::new);
		} catch (Exception queryException) {
			LOGGER.error("Failed to select job definition from {} table, error = {}",
				JOB_DEFINITION_VIEW,
				queryException.getMessage());
		}
		return Optional.empty();
	}

	@Override
	public List<JobDefinitionExternalJar> select(String searchKeyWord, int offset, int limit) {
		try {
			SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema()
				.select().from(JOB_DEFINITION_VIEW);
			ConditionBuilder whereCondition = ConditionBuilder.instance()
				.eq(JOB_TYPE, JobType.EXTERNAL_JAR.getValue());
			if (StringUtils.isNotEmpty(searchKeyWord)) {
				ConditionBuilder.instance()
					.ilike(JOB_DEF_ID, searchKeyWord)
					.or().ilike(JOB_DEF_NAME, searchKeyWord)
					.or().ilike(JOB_DEF_DESCRIPTION, searchKeyWord)
					.or().ilike(JOB_TYPE, searchKeyWord)
					.or().ilike(PRODUCT_CODE, searchKeyWord)
					.or().ilike(SUB_PRODUCT_CODE, searchKeyWord)
					.or().ilike(GROUP_ID, searchKeyWord)
					.or().ilike(ARTIFACT_ID, searchKeyWord)
					.or().ilike(VERSION, searchKeyWord)
					.or().ilike(MAIN_CLASS, searchKeyWord);
				selectQueryBuilder.where(whereCondition);
			}
			return selectQueryBuilder
				.offset(offset)
				.limit(limit)
				.build(false)
				.execute()
				.stream()
				.map(JobDefinitionExternalJar::new)
				.collect(Collectors.toList());
		} catch (Exception queryException) {
			LOGGER.error("Failed to select job definition from {} table, error = {}",
				JOB_DEFINITION_VIEW,
				queryException.getMessage());
		}
		return Collections.emptyList();
	}

	@Override
	public String upsert(JobDefinitionExternalJar jobDefinition, QueryExecutor executor, boolean skipChangeRequest)
		throws QueryException, JsonConversionException {
		Objects.requireNonNull(jobDefinition, "job definition must be non-null");
		try {
			// FIXME : update logic to be added for both
			// JOB_DEFINITION_EXTERNAL_JAR and JOB_EXTERNAL_JAR_FILE_INFO
			if(Objects.isNull(executor)) {
				executor = new QueryBuilder().getQueryExecutor();
			}
			return executor.queryBuilder()
				.btSchema()
				.insert()
				.skipChangeRequest(skipChangeRequest)
				.upsertWithKeyList(JOB_DEFINITION_EXTERNAL_JAR,
					Arrays.asList(jobDefinition.toInsertMap()),
					true, UPDATE_COLUMNS, PRIMARY_KEYS)
				.getPrimaryKeyValue()
				.get(JOB_DEFINITION_EXTERNAL_JAR).stream().findFirst()
				.map(list -> list.stream().findFirst().orElse(Collections.emptyMap()))
				.map(map -> (String)map.get(JOB_DEF_ID))
				.orElse(null);
		} catch (QueryException queryException) {
			LOGGER.error("Failed to upsert {} table, error = {}",
				JOB_DEFINITION_EXTERNAL_JAR,
				queryException.getMessage());
			throw queryException;
		}
	}

}
