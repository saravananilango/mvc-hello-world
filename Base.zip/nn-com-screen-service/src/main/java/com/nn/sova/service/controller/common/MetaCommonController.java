package com.nn.sova.service.controller.common;

import java.util.Map;

import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.service.common.MetaCommonService;
import com.nn.sova.service.service.common.MetaCommonServiceImpl;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * The Class MetaCommonController.
 */
@SovaMapping("metacommon")
public class MetaCommonController {

    private static final ApplicationLogger LOGGER = ApplicationLogger.create(MetaCommonController.class);

    /** The NnComponentDefinitionDetailService */
    private final MetaCommonService metaCommonService;

    /**
     * Instantiates a new meta common controller.
     */
    public MetaCommonController() {
        metaCommonService = new MetaCommonServiceImpl();
    }

    /**
     * checkAndChangeCRStatus is used to get CR status or change CR status screen.
     *
     * @param request  the request
     * @param response the response
     * @return returnMap
     * @throws CustomException the custom exception
     */
    @SovaMapping(value = "/updateChangeCRStatus", method = SovaRequestMethod.POST)
    public void updateChangeCRStatus(SovaHttpRequest request, SovaHttpResponse response) throws CustomException {
        Map<String, Object> paramMap = CommonUtils.getNonNullMap(request.getBody());
        try {
            metaCommonService.updateChangeCRStatus(paramMap);
        } catch (Exception exception) {
            LOGGER.error("Error occured: ", exception);
            throw new CustomException(exception.getMessage());
        }
    }

    /**
     * isReleased method is used to check change request status is released or not
     * screen.
     *
     * @param request  the request
     * @param response the response
     * @return returnMap
     * @throws CustomException the custom exception
     */
    @SovaMapping(value = "/isReleased", method = SovaRequestMethod.POST)
    public Map<String, Object> isReleased(SovaHttpRequest request, SovaHttpResponse response) throws CustomException {
        Map<String, Object> paramMap = CommonUtils.getNonNullMap(request.getBody());
        try {
            return metaCommonService.isReleased(paramMap);
        } catch (Exception exception) {
            LOGGER.error("Error occured: ", exception);
            throw new CustomException(exception.getMessage());
        }
    }
}
