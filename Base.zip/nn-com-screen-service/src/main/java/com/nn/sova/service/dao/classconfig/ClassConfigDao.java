package com.nn.sova.service.dao.classconfig;

import java.util.List;

import com.nn.sova.querybuilder.QueryExecutor;

/**
 * ClassConfigDao class is to perform db operation in class configuration table.
 *
 * @author Sundhar
 */
public interface ClassConfigDao {

    /**
     * To delete data in class configuration table by class id.
     *
     * @param classIds the class ids
     * @param executor the executor
     * @throws Exception the exception
     */
    void deleteByClassId(List<Object> classIds, QueryExecutor executor) throws Exception;

}
