package com.nn.sova.service.controller.iniStorage;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.dao.logger.ApplicationLoggerDao;
import com.nn.sova.service.ini.IniService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;

@SovaMapping("/")
public class IniStorageController {

    /** The IniStorageService */
    private final IniService iniStorageService;

    /**
	 * IniStorageController is a constructor used to initialize the value for
	 * IniStorageService
	 *
	 */
    public IniStorageController() {
        iniStorageService = IniService.getInstance();
    }

    /**
	 * getIniStorage method is used to get the ini storage data
	 * 
	 * @return {List<Object>} value
	 */
    @SovaMapping(value = "/getIniStorage", method = SovaRequestMethod.POST)
    public List<Map<String, Object>> getIniStorage(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        return iniStorageService.getIniDataByKey(paramMap);
    }
    
    /**
	 * getIniStorageForExplorer method is used to get the ini storage data for explorer
	 * 
	 * @return {List<Object>} value
	 */
    public List<Map<String, Object>> getIniStorageForExplorer(Map<String, Object> paramMap) {
        return iniStorageService.getIniDataByKey(paramMap);
    }

    /**
	 * clearIniStorage method is used to clear the ini storage data
	 * 
	 * @return boolean value
	 */
    @SovaMapping(value = "/clearIniStorage", method = SovaRequestMethod.POST)
    public Map<String, Object> clearIniStorage(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        return iniStorageService.clearIniStorage();
    }

    @SovaMapping(value = "/insertServiceIni", method = SovaRequestMethod.POST)
    public Map<String, Object> insertServiceIni(SovaHttpRequest request, SovaHttpResponse response) throws QueryException {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        if (Objects.nonNull(paramMap) && Objects.nonNull(paramMap.get("processId")))
        	ApplicationLoggerDao.updateLastAccessTime(paramMap.get("processId").toString());
        if (StringUtils.isNotEmpty(ContextBean.getUserId()) && StringUtils.isNotEmpty(ContextBean.getSid())) {
            if(Objects.isNull(paramMap.get("ini_data")) || CollectionUtils.isEmpty((Collection<?>) paramMap.get("ini_data")))
            	return paramMap;
            paramMap.put("component_flag", true);
            return iniStorageService.insertIniDataByKeyList(paramMap);
        } else {
            Map<String, Object> dataMap = new HashMap<>();
            dataMap.put("status", false);
            dataMap.put("errorMessage", "Service Id is empty");
            return dataMap;
        }
    }
    
	public Map<String, Object> insertServiceIniForExplorer(Map<String, Object> paramMap) throws QueryException {
		if (StringUtils.isNotEmpty(ContextBean.getUserId()) && StringUtils.isNotEmpty(ContextBean.getSid())) {
			if(Objects.nonNull(ContextBean.getProcessId()))
				ApplicationLoggerDao.updateLastAccessTime(ContextBean.getProcessId());
			paramMap.put("component_flag", true);
			return iniStorageService.insertIniDataByKeyList(paramMap);
		} else {
			Map<String, Object> dataMap = new HashMap<>();
			dataMap.put("status", false);
			dataMap.put("errorMessage", "Service Id is empty");
			return dataMap;
		}
	}


    @SovaMapping(value = "/insertCommonIni", method = SovaRequestMethod.POST)
    public Map<String, Object> insertCommonIni(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        return iniStorageService.insertIniDataByKeyList(paramMap);
    }
}
