package com.nn.sova.service.service.notification;

/**
 * Enum to maintain Notification Api Endpoints .
 * @author saravana
 *
 */
public enum NotificationApiEndPoint {
    NOTIFY_BY_MAIL("/notification/notifyByMail"),
    NOTIFY_BY_SMS("/notification/notifyBySms"),
    NOTIFY_BY_FCM("/notification/notifyByFcm"),
    NOTIFY("/notification/notify");

	private final String endPoint;
	
	NotificationApiEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	
	public String getEndPoint() {
		return this.endPoint;
	}
    
}
