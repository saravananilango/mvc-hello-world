package com.nn.sova.service.service.wizard;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.service.CacheService;
import com.nn.sova.service.dao.wizard.WizardDao;
import com.nn.sova.service.dao.wizard.WizardDaoImpl;
import com.nn.sova.service.enums.ScreenDefTypeEnum;

/**
 * WizardServiceImpl class is used for implementing the functionalities
 * related to wizard component
 * 
 * @author Vivek Kannan E
 *
 */
public class WizardServiceImpl implements WizardService {

	private final WizardDao wizardDao;

	/**
	 * WizardServiceImpl constructor which initialize WizardDaoImpl
	 */
	public WizardServiceImpl() {
		wizardDao = new WizardDaoImpl();
	}

	@Override
	public Map<String,Object> getWizardData(String wizardId) {
		List<Map<String,Object>> wizardDataList = wizardDao.getData(wizardId);
		Map<String,Object> wizardMap = new HashMap<>();
		if(CollectionUtils.isNotEmpty(wizardDataList) ) {
			wizardMap = wizardDataList.stream().collect(Collectors.toMap(map -> map.get("id").toString(), map -> map));
		}
		return wizardMap;
		
	}

	@Override
	public Map<String,Object> getWizardData(String wizardId, String wizardDialogId) {
		return wizardDao.getData(wizardId, wizardDialogId);
	}

	@Override
	public String deleteCacheByKey(String wizardId) {
		boolean status = CacheService.getInstance().deleteCacheByCompDefAndKey(ScreenDefTypeEnum.WIZARD.getValue(), wizardId);
		if(status) {
			return "success";
		}
		return "failure";
	}

	@Override
	public String deleteAllCache() {
		boolean status = CacheService.getInstance().deleteCacheByCompDefType(ScreenDefTypeEnum.WIZARD.getValue());
		if(status) {
			return "success";
		}
		return "failure";
	}

	

}