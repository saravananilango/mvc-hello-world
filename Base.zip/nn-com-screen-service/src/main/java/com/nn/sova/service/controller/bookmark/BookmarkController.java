package com.nn.sova.service.controller.bookmark;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.service.bookmark.BookmarkService;
import com.nn.sova.service.service.bookmark.BookmarkServiceImpl;

/**
 * BookmarkController class is the controller for the bookmark related
 * operations
 * 
 * @author Mohammed Shameer
 */
@SovaMapping("/bookmark")
public class BookmarkController {

	/** The BookmarkService */
	private final BookmarkService bookmarkService;

	/**
	 * IniStorageController is a constructor used to initialize the value for
	 * IniStorageService
	 *
	 */
	public BookmarkController() {
		bookmarkService = new BookmarkServiceImpl();
	}

	/**
	 * getBookmarkData method is used to get the bookmark data.
	 * 
	 * @return the map.
	 */
	@SovaMapping(value = "/getBookmarkData", method = SovaRequestMethod.POST)
	public Map<String, Object> getBookmarkData(SovaHttpRequest request, SovaHttpResponse response) {
		return bookmarkService.getBookmarkData();
	}

	/**
	 * insertBookmarkData is used to get the insert bookmark data.
	 * 
	 * @param paramMap
	 * @return the map
	 */
	@SovaMapping(value = "/insertBookmarkData", method = SovaRequestMethod.POST)
	public Map<String, Object> insertBookmarkData(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		return bookmarkService.insertBookmarkData(paramMap);
	}

	/**
	 * deleteBookmarkData is used to delete the bookmark data.
	 * 
	 * @param paramMap
	 * @return the map
	 */
	@SovaMapping(value = "/deleteBookmarkData", method = SovaRequestMethod.POST)
	public Map<String, Object> deleteBookmarkData(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		return bookmarkService.deleteBookmarkData(paramMap);
	}

	/**
	 * shareBookmarkData is used to share the bookmark data.
	 * 
	 * @param paramMap
	 * @return the map
	 */
	@SovaMapping(value = "/shareBookmarkData", method = SovaRequestMethod.POST)
	public Map<String, Object> shareBookmarkData(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		return bookmarkService.shareBookmarkData(paramMap);
	}

	/**
	 * markDefaultBookmarkData is used to mark the bookmark data as default.
	 * 
	 * @param paramMap
	 * @return the map
	 */
	@SovaMapping(value = "/markDefaultBookmarkData", method = SovaRequestMethod.POST)
	public Map<String, Object> markDefaultBookmarkData(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		return bookmarkService.markDefaultBookmarkData(paramMap);
	}

	/**
	 * getBookmarkDataByName is used to get the bookmark data by the name.
	 * 
	 * @param paramMap
	 * @return the map
	 */
	@SovaMapping(value = "/getBookmarkDataByName", method = SovaRequestMethod.POST)
	public Map<String, Object> getBookmarkDataByName(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		return bookmarkService.getBookmarkDataByName(paramMap);
	}

	/**
	 * removeDefaultBookmarkData is used to remove the bookmark data as default.
	 * 
	 * @param paramMap
	 * @return the map
	 */
	@SovaMapping(value = "/removeDefaultBookmarkData", method = SovaRequestMethod.POST)
	public Map<String, Object> removeDefaultBookmarkData(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		return bookmarkService.removeDefaultBookmarkData(paramMap);
	}
}