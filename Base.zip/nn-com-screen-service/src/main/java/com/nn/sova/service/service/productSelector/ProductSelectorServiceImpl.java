package com.nn.sova.service.service.productSelector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.postgresql.util.PGobject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.service.dao.productSelector.ProductSelectorDao;
import com.nn.sova.service.dao.productSelector.ProductSelectorDaoImpl;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.utility.json.JsonUtils;

/**
 * productSelectorService class is used for implementing the functionalities 
 * for productCode, subProductCode custom search and IniStorage for productCode and subProductCode  
 * 
 * @author Inigo Raj V
 *
 */
public class ProductSelectorServiceImpl implements ProductSelectorService {

	private final ProductSelectorDao productSelectorDao;

	public ProductSelectorServiceImpl() {
		productSelectorDao = new ProductSelectorDaoImpl();
	}
	
	@Override
	public String getProductDetails(Map<String, Object> dataMap) throws IOException {
		ObjectMapper object = new ObjectMapper();
		List<Map<String, String>> resultList= new ArrayList<>();
		Map<String, Object> requestMap = new HashMap<>();
		String productText = dataMap.get("keyword").toString().trim();
		List<String> roleIds = UserContext.getInstance().getUserProfile().getRoleList();
		List<Map<String, Object>> productList= productSelectorDao.getProductDetails(productText,roleIds);
		resultList = productList.stream().filter(predicate-> Objects.nonNull(predicate.get("product_name")) && 
				Objects.nonNull(predicate.get("product_code"))).map(record -> {
			Map<String, String> rowMap = new HashMap<>();
			rowMap.put("showText", record.get("product_name").toString());
			rowMap.put("subText", record.get("product_name").toString());
			rowMap.put("keyText", record.get("product_code").toString());
			rowMap.put("setText", record.get("product_name").toString());
			return rowMap;
		}).collect(Collectors.toList());
		requestMap.put("result", resultList);
		return object.writeValueAsString(requestMap);
	}

	@Override
	public String getSubProductDetails(Map<String, Object> dataMap) throws IOException {
		ObjectMapper object = new ObjectMapper();
		List<Map<String, String>> resultList= new ArrayList<>();
		Map<String, Object> requestMap = new HashMap<>();
		String subProductText = dataMap.get("keyword").toString().trim();
		if(!dataMap.containsKey("repoType") || !dataMap.containsKey("productCode")) {
			requestMap.put("result", resultList);
			return object.writeValueAsString(requestMap);
		}
		List<Object> repoType = new ArrayList<>();
		Object repoTypeObject = dataMap.get("repoType");
		if(repoTypeObject instanceof List) {
			repoType = (List<Object>) dataMap.get("repoType");
		}else {
			repoType.add(dataMap.get("repoType").toString().trim());
		}
		String productCode = dataMap.get("productCode").toString().trim();
		boolean externalDevelop = (boolean)dataMap.get("externalDevelop");
		boolean isExternalDevelop = (boolean)dataMap.get("isExternalDevelop");
		List<Map<String, Object>> subProductList= productSelectorDao.getSubProductDetails(subProductText,productCode,repoType, isExternalDevelop, externalDevelop);
		resultList = subProductList.stream().filter(predicate -> Objects.nonNull(predicate.get("sub_product_name")) && Objects.nonNull(predicate.get("sub_product_code"))).map(record -> {
			Map<String, String> rowMap = new HashMap<>();
			rowMap.put("showText", record.get("sub_product_name").toString());
			rowMap.put("subText", record.get("sub_product_code").toString());
			rowMap.put("keyText", record.get("sub_product_code").toString());
			rowMap.put("setText", record.get("sub_product_name").toString());
			return rowMap;
		}).collect(Collectors.toList());
		requestMap.put("result", resultList);
		return object.writeValueAsString(requestMap);
	}

	@Override
	public void saveProductDetailsAsIni(Map<String, Object> dataMap) {
		Map<String, String> paramMap = new HashMap<>();
		if(dataMap.containsKey("productCode")) {
			paramMap.put("productCode", String.valueOf(dataMap.get("productCode")));
			paramMap.put("productName", String.valueOf(dataMap.get("productName")));
			if(dataMap.containsKey("subProductCode")) {				
				paramMap.put("subProductCode", String.valueOf(dataMap.get("subProductCode")));
				paramMap.put("subProductName", String.valueOf(dataMap.get("subProductName")));
			}
			productSelectorDao.saveProductDetailsAsIni(this.getPgObject(paramMap), "product_details");
		}

	}
	/**
	 * To get PGObject from JSON
	 * 
	 * @param key
	 * @param dataMap
	 * @return
	 */
	PGobject getPgObject(Object encodeObject) {
		ObjectMapper mapper = new ObjectMapper();
		PGobject pgObject = new PGobject();
		pgObject.setType("json");
		try {
			pgObject.setValue(mapper.writeValueAsString(encodeObject));
		} catch (Exception e) {
		}
		return pgObject;
	}

	@Override
	public String getIniDetails() throws IOException {
		Map<String, String> detailMap = new HashMap<>();
		ObjectMapper object = new ObjectMapper();
		List<String> roleIds = UserContext.getInstance().getUserProfile().getRoleList();
		List<Map<String, Object>> productIniDetails = productSelectorDao.getIniDetails("product_details");
		List<Map<String, Object>> productdetail = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(productIniDetails) && Objects.nonNull(productIniDetails.get(0).get("ini_object"))) {
			detailMap = JsonUtils.fromJsonOrElse(((PGobject) productIniDetails.get(0).get("ini_object")).getValue(), Map.class,
					new HashMap<>());
			productdetail = productSelectorDao.getProduct(detailMap.get("productCode"), roleIds);
			if (CollectionUtils.isNotEmpty(productdetail)) {
				detailMap.put("productName", String.valueOf(productdetail.get(0).get("product_name")));
			} else {
				detailMap.clear();
			}
		}
		return object.writeValueAsString(detailMap);
	}


}