package com.nn.sova.service.mastersearch.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.json.JSONArray;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.DeleteQueryBuilder;
import com.nn.sova.querybuilder.InsertQueryBuilder;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.UpdateQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.mastersearch.model.InputLearningParameters;
import com.nn.sova.service.mastersearch.model.MasterInputLearningParameters;
import com.nn.sova.service.mastersearch.model.MasterSearchLoadInfo;
import com.nn.sova.utility.cache.CacheGetService;
import com.nn.sova.utility.cache.CachePutService;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * InputLearningDao class is used to load suggestions by inputs of user.
 * 
 * @author Logchand
 *
 */
public class InputLearningDao {

	/** The Constant LOGGER. */
	private static final ApplicationLogger LOGGER = ApplicationLogger.create(InputLearningDao.class);

	/** The Constant MAX_COUNT. */
	private static final int MAX_COUNT = 5;

	/** The Constant INITIAL_ITEM. */
	private static final int INITIAL_ITEM = 0;

	/** The Constant INCREMENT_INDEX. */
	private static final int INCREMENT_INDEX = 1;

	/** The Constant SET_TEXT. */
	private static final String SET_TEXT = "setText";

	/** The Constant COMPONENT_ID. */
	private static final String COMPONENT_ID = "component_id";

	/** The Constant USER_ID. */
	private static final String USER_ID = "user_id";

	/** The Constant SCREEN_ID. */
	private static final String SCREEN_ID = "screen_id";

	/** The Constant LEARN_VALUE. */
	private static final String LEARN_VALUE = "learn_value";

	/** The Constant MASTER_HISTORY_DETAIL. */
	private static final String MASTER_HISTORY_DETAIL = "master_history_detail";

	/**
	 * Instantiates a new input learning dao.
	 */
	private InputLearningDao() {
	}

	/**
	 * processData method is used to process the incoming data.
	 *
	 * @param rows     the rows
	 * @param current  the current
	 * @param cacheKey the cache key
	 * @return List
	 */
	public static List<Object> processData(List<Map<String, Object>> rows, String current, String cacheKey) {
		JSONArray array = new JSONArray();
		if (CollectionUtils.isNotEmpty(rows)) {
			Optional<Map<String, Object>> value = rows.stream().findFirst();
			if (value.isPresent()) {
				array.put((String) value.get().get(LEARN_VALUE));
			}
			if (!array.toString().contains("\"" + current + "\"")) {
				array.put(current);
			}
			CachePutService.getInstance().putCustomRedisCacheData(cacheKey, array.toString());
			return array.toList();
		}
		return array.toList();
	}

	/**
	 * loadLearnValue method will load the data from cache.
	 *
	 * @param parameters the parameters
	 * @param cacheKey   the cache key
	 * @return List
	 */
	public static List<Object> loadLearnValue(InputLearningParameters parameters, String cacheKey) {
		SelectQueryBuilder selectBuilder = new QueryBuilder().btSchema().select();
		SelectQueryBuilder queryBuilder = selectBuilder.get(LEARN_VALUE).from(MASTER_HISTORY_DETAIL)
				.where(ConditionBuilder.instance().eq(SCREEN_ID, parameters.getScreenId()).and()
						.eq(USER_ID, parameters.getUserId()).and().eq(COMPONENT_ID, parameters.getComponentId()));
		List<Map<String, Object>> rows = new ArrayList<>();
		try {
			rows = queryBuilder.build(false).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		if (rows.isEmpty()) {
			insertHistory(parameters, cacheKey);
			ObjectMapper object = new ObjectMapper();
			object.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			return object.convertValue(CacheGetService.getInstance().getCustomCacheData(cacheKey), List.class);
		} else {
			return processData(rows, parameters.getLearningValue(), cacheKey);
		}
	}

	/**
	 * removeHistory method will remove the loaded history content.
	 *
	 * @param serviceId   the service id
	 * @param userId      the user id
	 * @param componentId the component id
	 * @param cacheKey    the cache key
	 */
	public static void removeHistory(String serviceId, String userId, String componentId, String cacheKey) {
		DeleteQueryBuilder deleteBuider = new QueryBuilder().btSchema().delete().isMaster(true);
		try {
			deleteBuider.from(MASTER_HISTORY_DETAIL).where(ConditionBuilder.instance().eq(SCREEN_ID, serviceId).and()
					.eq(USER_ID, userId).and().eq(COMPONENT_ID, componentId)).build().execute();
			CacheService.getInstance().removeCacheByKey(cacheKey);
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
	}

	/**
	 * checkHistory method will check for any existing history.
	 *
	 * @param parameters the parameters
	 * @param cacheKey   the cache key
	 * @return String
	 */
	public static String checkHistory(InputLearningParameters parameters, String cacheKey) {
		SelectQueryBuilder queryBuilder = new QueryBuilder().btSchema().select();
		queryBuilder.get(LEARN_VALUE).from(MASTER_HISTORY_DETAIL)
				.where(ConditionBuilder.instance().eq(SCREEN_ID, parameters.getScreenId()).and()
						.eq(USER_ID, parameters.getUserId()).and().eq(COMPONENT_ID, parameters.getComponentId()));
		List<Map<String, Object>> rows = new ArrayList<>();
		try {
			rows = queryBuilder.build(false).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		if (rows.isEmpty()) {
			insertHistory(parameters, cacheKey);
		} else {
			updateHistory(rows, parameters, cacheKey);
		}
		return Objects.toString(CacheGetService.getInstance().getCustomCacheData(cacheKey), "");
	}

	/**
	 * insertHistory method will insert a new history.
	 *
	 * @param parameters the parameters
	 * @param cacheKey   the cache key
	 */
	public static void insertHistory(InputLearningParameters parameters, String cacheKey) {
		JSONArray array = new JSONArray();
		array.put(parameters.getLearningValue());
		InsertQueryBuilder insertQueryBuilder = new QueryBuilder().btSchema().insert().isMaster(true);
		try {
			insertQueryBuilder.into(MASTER_HISTORY_DETAIL, SCREEN_ID, USER_ID, COMPONENT_ID, LEARN_VALUE).build()
					.execute(parameters.getScreenId(), parameters.getUserId(), parameters.getComponentId(),
							array.toString());
			CachePutService.getInstance().putCustomRedisCacheData(cacheKey, array.toString());
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
	}

	/**
	 * updateHistory method will be used to update the record.
	 *
	 * @param rows       the rows
	 * @param parameters the parameters
	 * @param cacheKey   the cache key
	 */
	public static void updateHistory(List<Map<String, Object>> rows, InputLearningParameters parameters,
			String cacheKey) {
		if (CollectionUtils.isNotEmpty(rows)) {
			Optional<Map<String, Object>> value = rows.stream().findFirst();
			JSONArray array = null;
			if (value.isPresent()) {
				array = new JSONArray((String) value.get().get(LEARN_VALUE));
			} else {
				array = new JSONArray();
			}
			array.put(parameters.getLearningValue());
			QueryBuilder queryBuilder = new QueryBuilder().btSchema();
			try {
				UpdateQueryBuilder updateQuery = queryBuilder.update().isMaster(true);
				updateQuery.into(MASTER_HISTORY_DETAIL, LEARN_VALUE)
						.where(ConditionBuilder.instance().eq(SCREEN_ID, parameters.getScreenId()).and()
								.eq(USER_ID, parameters.getUserId()).and()
								.eq(COMPONENT_ID, parameters.getComponentId()));
				updateQuery.build().execute(array.toString());
				CacheService.getInstance().removeCacheByKey(cacheKey);
				CachePutService.getInstance().putCustomRedisCacheData(cacheKey, array.toString());
			} catch (QueryException exception) {
				LOGGER.error(exception);
			}
		}
	}

	/**
	 * learnMasterData method is used to add the data to a pattern.
	 *
	 * @param masterLearningData the master learning data
	 * @param cacheKey           the cache key
	 * @return String
	 */
	public static String learnMasterData(MasterInputLearningParameters masterLearningData, String cacheKey) {
		QueryBuilder selectBuilder = new QueryBuilder().btSchema();
		SelectQueryBuilder queryBuilder = selectBuilder.select().get(LEARN_VALUE).from(MASTER_HISTORY_DETAIL)
				.where(ConditionBuilder.instance().eq(SCREEN_ID, masterLearningData.getScreenId()).and()
						.eq(USER_ID, masterLearningData.getUserId()).and()
						.eq(COMPONENT_ID, masterLearningData.getSearchId()));
		List<Map<String, Object>> rows = new ArrayList<>();
		try {
			rows = queryBuilder.build(false).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		if (rows.isEmpty()) {
			insertMasterData(masterLearningData, cacheKey);
		} else {
			updatemasterData(rows, masterLearningData, cacheKey);
		}
		return Objects.toString(CacheGetService.getInstance().getCustomCacheData(cacheKey), "");
	}

	/**
	 * updatemasterData method is used to update the update the master table.
	 *
	 * @param rows               the rows
	 * @param masterLearningData the master learning data
	 * @param cacheKey           the cache key
	 */
	@SuppressWarnings("unchecked")
	private static void updatemasterData(List<Map<String, Object>> rows,
			MasterInputLearningParameters masterLearningData, String cacheKey) {
		if (CollectionUtils.isNotEmpty(rows)) {
			Optional<Map<String, Object>> value = rows.stream().findFirst();
			JSONArray array = null;
			if (value.isPresent()) {
				array = new JSONArray((String) value.get().get(LEARN_VALUE));
			} else {
				array = new JSONArray();
			}
			JSONObject jsonObject = new JSONObject();
			jsonObject.put(SET_TEXT, masterLearningData.getSetText());
			jsonObject.put("showText", masterLearningData.getShowText());
			if (!array.toString().contains(jsonObject.toString())) {
				if (array.length() == MAX_COUNT) {
					array.remove(INITIAL_ITEM);
				}
				array.put(jsonObject);
				QueryBuilder queryBuilder = new QueryBuilder().btSchema();
				try {
					UpdateQueryBuilder updateQuery = queryBuilder.update().into(MASTER_HISTORY_DETAIL, LEARN_VALUE)
							.where(ConditionBuilder.instance().eq(SCREEN_ID, masterLearningData.getScreenId()).and()
									.eq(USER_ID, masterLearningData.getUserId()).and()
									.eq(COMPONENT_ID, masterLearningData.getSearchId()));
					updateQuery.build().execute(array.toString());
					CacheService.getInstance().removeCacheByKey(cacheKey);
					CachePutService.getInstance().putCustomRedisCacheData(cacheKey, array.toString());
				} catch (QueryException exception) {
					LOGGER.error(exception);
				}
			}
		}
	}

	/**
	 * insertMasterData method is used to insert master data.
	 *
	 * @param masterLearningData the master learning data
	 * @param cacheKey           the cache key
	 */
	@SuppressWarnings("unchecked")
	private static void insertMasterData(MasterInputLearningParameters masterLearningData, String cacheKey) {
		JSONArray dataArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(SET_TEXT, masterLearningData.getSetText());
		jsonObject.put("showText", masterLearningData.getShowText());
		dataArray.put(jsonObject);
		InsertQueryBuilder insertQuery = new QueryBuilder().btSchema().insert();
		try {
			insertQuery.into(MASTER_HISTORY_DETAIL, SCREEN_ID, USER_ID, COMPONENT_ID, LEARN_VALUE);
			insertQuery.build().execute(masterLearningData.getScreenId(), masterLearningData.getUserId(),
					masterLearningData.getSearchId(), dataArray.toString());
			CachePutService.getInstance().putCustomRedisCacheData(cacheKey, dataArray.toString());
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
	}

	/**
	 * loadMasterDataFromDatabase will retrieve data from DB.
	 *
	 * @param masterLearningData the master learning data
	 * @param cacheKey           the cache key
	 * @return String
	 */
	public static String loadMasterDataFromDatabase(MasterInputLearningParameters masterLearningData, String cacheKey) {
		QueryBuilder selectBuilder = new QueryBuilder().btSchema();
		SelectQueryBuilder queryBuilder = selectBuilder.select();
		queryBuilder.get(LEARN_VALUE);
		queryBuilder.from(MASTER_HISTORY_DETAIL);
		queryBuilder.where(ConditionBuilder.instance().eq(SCREEN_ID, masterLearningData.getScreenId()).and()
				.eq(USER_ID, masterLearningData.getUserId()).and().eq(COMPONENT_ID, masterLearningData.getSearchId()));
		List<Map<String, Object>> rows = new ArrayList<>();
		try {
			rows = queryBuilder.build(false).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		if (CollectionUtils.isNotEmpty(rows)) {
			JSONArray array = new JSONArray((String) rows.get(INITIAL_ITEM).get(LEARN_VALUE));
			CachePutService.getInstance().putCustomRedisCacheData(cacheKey, array.toString());
			return validateHistory(array.toString(), masterLearningData, cacheKey);
		} else {
			return null;
		}
	}

	/**
	 * validateHistory will validate the data in history.
	 *
	 * @param historyData        the history data
	 * @param masterLearningData the master learning data
	 * @param cacheKey           the cache key
	 * @return String
	 */
	public static String validateHistory(String historyData, MasterInputLearningParameters masterLearningData,
			String cacheKey) {
		JSONArray array = new JSONArray(historyData);
		QueryBuilder builder = new QueryBuilder().btSchema();
		MasterSearchLoadInfo masterInfo = MasterSearchDao.loadInfo(masterLearningData.getSearchId());
		List<Object> queryStrings = new ArrayList<>();
		String targetColumn = masterInfo.getSetColumnName();
		boolean changeFlag = false;
		for (int index = INITIAL_ITEM; index < array.length(); index++) {
			queryStrings.add(array.getJSONObject(index).optString(SET_TEXT));
		}
		SelectQueryBuilder queryBuilder = builder.select().get(targetColumn).from(masterInfo.getTableName())
				.where(ConditionBuilder.instance().inWithList(targetColumn, queryStrings));
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.build(false).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		if (result.isEmpty()) {
			array = new JSONArray(new ArrayList<String>());
			changeFlag = true;
		} else if (queryStrings.size() != result.size()) {
			List<String> validatedStrings;
			validatedStrings = result.stream().map(row -> Objects.toString(row.get(targetColumn), ""))
					.collect(Collectors.toList());
			for (int index = INITIAL_ITEM; index < array.length(); index++) {
				if (!validatedStrings.contains(array.getJSONObject(index).optString(SET_TEXT))) {
					array.remove(index);
					changeFlag = true;
				}
			}
		}
		if (changeFlag) {
			QueryBuilder historyBuilder = new QueryBuilder().btSchema();
			try {
				if (array.length() == INITIAL_ITEM) {
					String userId = cacheKey.substring(cacheKey.lastIndexOf('_') + INCREMENT_INDEX, cacheKey.length());
					removeHistory(masterLearningData.getScreenId(), userId, masterLearningData.getSearchId(), cacheKey);
				} else {
					UpdateQueryBuilder updateQuery = historyBuilder.update().into(MASTER_HISTORY_DETAIL, LEARN_VALUE)
							.where(ConditionBuilder.instance().eq(SCREEN_ID, masterLearningData.getScreenId()).and()
									.eq(USER_ID, masterLearningData.getUserId()).and()
									.eq(COMPONENT_ID, masterLearningData.getSearchId()));
					updateQuery.build().execute(array.toString());
					CacheService.getInstance().removeCacheByKey(cacheKey);
					CachePutService.getInstance().putCustomRedisCacheData(cacheKey, array.toString());
				}
			} catch (QueryException exception) {
				LOGGER.error(exception);
			}
		}
		return array.toString();
	}
}
