package com.nn.sova.service.mastersearch.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.mastersearch.builder.MasterSearchQueryBuilder;
import com.nn.sova.service.mastersearch.dao.MasterSearchDao;
import com.nn.sova.service.mastersearch.model.MasterSearchLoadInfo;
import com.nn.sova.service.mastersearch.model.MasterSearchRequestParam;
import com.nn.sova.utility.json.JsonUtils;

/**
 * MasterSearchController class is to build the search query and get the data
 * from the database used by master input components.
 *
 * @author Logchand
 */
@SovaMapping("/function/master")
public class MasterSearchController {

    /** The Constant SEARCH_ID. */
    private static final String SEARCH_ID = "searchId";

    /**
	 * masterData method is to search for master data.
	 *
	 * @param dataMap the data map
	 * @return String
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/search", method = SovaRequestMethod.POST)
    public String masterData(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        ObjectMapper object = new ObjectMapper();
        String keyword = dataMap.get("keyword").toString().trim();
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        Map<String, Object> filterFields = object.convertValue(dataMap.get("filterValue"), Map.class);
        Map<String, Object> filterConditions = object.convertValue(dataMap.get("filterConditionMap"), Map.class);
        int offset = Integer.parseInt(dataMap.get("offset").toString());
        boolean countFlag = Boolean.parseBoolean(dataMap.get("countFlag").toString());
        Map<String, Object> customConditionKeyMap = Objects.nonNull(dataMap.get("customConditionKeyMap")) ? ((Map<String, Object>) dataMap.get("customConditionKeyMap")) : new HashMap<>();
        MasterSearchRequestParam param = new MasterSearchRequestParam(Arrays.asList(keyword.trim()), searchId, filterFields, filterConditions);
        MasterSearchLoadInfo masterInfo;
        if (Objects.nonNull(dataMap.get("masterData"))) {
            masterInfo = object.convertValue(dataMap.get("masterData"), MasterSearchLoadInfo.class);
        } else {
            masterInfo = MasterSearchDao.loadInfo(searchId);
        }
        Map<String, Object> searchType = new HashMap<>();
        searchType.put("searchTypeElement", dataMap.get("searchType"));
        searchType.put("filterTagsValue", dataMap.get("filterTagsValue"));
        MasterSearchQueryBuilder builder = new MasterSearchQueryBuilder();
        List<List<Map<String, Object>>> query = new ArrayList<>();
        if (dataMap.containsKey("customCondition") && !Boolean.parseBoolean(dataMap.get("customCondition").toString())) {
            query = builder.getSearchResult(param, masterInfo, offset, countFlag, searchType);
        } else {
            query = builder.getCustomConditionSearchResult(param, masterInfo, offset, countFlag, searchType, customConditionKeyMap);
        }
        List<Map<String, String>> result = MasterSearchDao.processData(query.get(0), masterInfo);
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("result", result);
        requestMap.put("requestId", dataMap.get("requestId"));
        if (countFlag) {
            requestMap.put("count", query.get(1).get(0).get("count"));
        }
        return object.writeValueAsString(requestMap);
    }

    /**
	 * validate method is used to validate the typed data.
	 *
	 * @param dataMap the data map
	 * @return String
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/validate", method = SovaRequestMethod.POST)
    public String validateMasterData(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        ObjectMapper object = new ObjectMapper();
        String keyword = dataMap.get("keyword").toString().trim();
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        String landDependent = dataMap.get("landDependent").toString().trim();
        Map<String, Object> filterFields = object.convertValue(dataMap.get("filterValue"), Map.class);
        Map<String, Object> filterConditions = object.convertValue(dataMap.get("filterConditionMap"), Map.class);
        Boolean customCondition = Objects.nonNull(dataMap.get("customCondition")) ? Boolean.parseBoolean(dataMap.get("customCondition").toString()) : false;
        com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        Map<String, Object> customConditionKeyMap = Objects.nonNull(dataMap.get("customConditionKeyMap")) ? mapper.readValue(dataMap.get("customConditionKeyMap").toString(), new TypeReference<Map<String, Object>>() {
        }) : new HashMap<>();
        MasterSearchRequestParam param = new MasterSearchRequestParam(Arrays.asList(keyword.trim()), searchId, filterFields, filterConditions);
        MasterSearchLoadInfo masterInfo;
        if (Objects.nonNull(dataMap.get("masterData"))) {
            masterInfo = object.convertValue(dataMap.get("masterData"), MasterSearchLoadInfo.class);
        } else {
            masterInfo = MasterSearchDao.loadInfo(searchId);
        }
        if (Objects.nonNull(masterInfo)) {
            List<Map<String, Object>> query = MasterSearchDao.fetchSingleData(param, masterInfo, landDependent, customCondition, customConditionKeyMap);
            List<Map<String, String>> result = MasterSearchDao.processData(query, masterInfo);
            return object.writeValueAsString(result);
        } else {
            return JSONObject.valueToString("");
        }
    }
    
    /**
	 * validate method is used to validate the typed data.
	 *
	 * @param dataMap the data map
	 * @return String
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/validateMasters", method = SovaRequestMethod.POST)
    public String validateMasterList(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        ObjectMapper object = new ObjectMapper();
        Map<String, Object> componentMap = object.convertValue(paramMap.get("parameterMap"), Map.class);
        Map<String, Object> returnMap = new HashMap<>();
        componentMap.entrySet().stream().forEach(action -> {
        	String componentId = action.getKey();
        	Map<String, Object> dataMap = object.convertValue(action.getValue(), Map.class);
        	String keyword = dataMap.get("keyword").toString().trim();
        	String searchId = dataMap.get(SEARCH_ID).toString().trim();
        	String landDependent = dataMap.get("landDependent").toString().trim();
        	Map<String, Object> filterFields = object.convertValue(dataMap.get("filterValue"), Map.class);
        	Map<String, Object> filterConditions = object.convertValue(dataMap.get("filterConditionMap"), Map.class);
        	Boolean customCondition = Objects.nonNull(dataMap.get("customCondition")) ? Boolean.parseBoolean(dataMap.get("customCondition").toString()) : false;
        	com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        	Map<String, Object> customConditionKeyMap = new HashMap<>();
			try {
				customConditionKeyMap = Objects.nonNull(dataMap.get("customConditionKeyMap")) ? mapper.readValue(dataMap.get("customConditionKeyMap").toString(), new TypeReference<Map<String, Object>>() {
				}) : new HashMap<>();
			} catch (JsonProcessingException e) {
			}
        	MasterSearchRequestParam param = new MasterSearchRequestParam(Arrays.asList(keyword.trim()), searchId, filterFields, filterConditions);
        	MasterSearchLoadInfo masterInfo;
        	if (Objects.nonNull(dataMap.get("masterData"))) {
        		masterInfo = object.convertValue(dataMap.get("masterData"), MasterSearchLoadInfo.class);
        	} else {
        		masterInfo = MasterSearchDao.loadInfo(searchId);
        	}
        	if (Objects.nonNull(masterInfo)) {
        		List<Map<String, Object>> query = MasterSearchDao.fetchSingleData(param, masterInfo, landDependent, customCondition, customConditionKeyMap);
        		List<Map<String, String>> result = MasterSearchDao.processData(query, masterInfo);
        		returnMap.put(componentId, result);
        	} else {
        		returnMap.put(componentId, Collections.emptyList());
        	}
        });
        return JSONObject.valueToString(returnMap);
    }
    
    /**
	 * validate method is used to validate the typed data.
	 *
	 * @param dataMap the data map
	 * @return String
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/validateTags", method = SovaRequestMethod.POST)
    public String validateTags(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        ObjectMapper object = new ObjectMapper();
        List<String> keyword = object.convertValue(dataMap.get("keyword"), List.class);
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        String landDependent = dataMap.get("landDependent").toString().trim();
        Map<String, Object> filterFields = object.convertValue(dataMap.get("filterValue"), Map.class);
        Map<String, Object> filterConditions = object.convertValue(dataMap.get("filterConditionMap"), Map.class);
        Boolean customCondition = Objects.nonNull(dataMap.get("customCondition")) ? Boolean.parseBoolean(dataMap.get("customCondition").toString()) : false;
        com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        Map<String, Object> customConditionKeyMap = Objects.nonNull(dataMap.get("customConditionKeyMap")) ? mapper.readValue(dataMap.get("customConditionKeyMap").toString(), new TypeReference<Map<String, Object>>() {
        }) : new HashMap<>();
        MasterSearchRequestParam param = new MasterSearchRequestParam(keyword, searchId, filterFields, filterConditions);
        MasterSearchLoadInfo masterInfo;
        if (Objects.nonNull(dataMap.get("masterData"))) {
            masterInfo = object.convertValue(dataMap.get("masterData"), MasterSearchLoadInfo.class);
        } else {
            masterInfo = MasterSearchDao.loadInfo(searchId);
        }
        if (Objects.nonNull(masterInfo)) {
            List<Map<String, Object>> query = MasterSearchDao.fetchSingleData(param, masterInfo, landDependent, customCondition, customConditionKeyMap);
            List<Map<String, String>> result = MasterSearchDao.processData(query, masterInfo);
            return object.writeValueAsString(result);
        } else {
            return JSONObject.valueToString("");
        }
    }

    /**
	 * loadGridHeader method will be useful in getting the headers from the db and
	 * load in vo.
	 *
	 * @param key      the key
	 * @param response the response
	 * @return String
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/search/headers/{key}", method = SovaRequestMethod.POST)
    public String loadGridHeader(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        String key = request.getPathVariables().get("key");
        MasterSearchLoadInfo masterInfo = MasterSearchDao.loadInfo(key);
        ObjectMapper object = new ObjectMapper();
        String[] columnNames = masterInfo.getShowColumnName().split(",");
        Map<String, String> headerMap = new HashMap<>();
        String columnList = object.writeValueAsString(columnNames);
        headerMap.put("headers", columnList);
        headerMap.put("setColumn", masterInfo.getSetColumnName());
        return object.writeValueAsString(headerMap);
    }

    /**
	 * loadGridData method is used to fetch data from table and form grid vo.
	 *
	 * @param key      the key
	 * @param id       the id
	 * @param response the response
	 * @return String
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/grid/{key}/{id}", method = SovaRequestMethod.POST)
    public String loadGridData(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        String key = request.getPathVariables().get("key");
        String id = request.getPathVariables().get("id");
        MasterSearchRequestParam param = new MasterSearchRequestParam(Arrays.asList(key.trim()), id);
        MasterSearchLoadInfo masterInfo = MasterSearchDao.loadInfo(param.getMasterKey());
        MasterSearchQueryBuilder builder = new MasterSearchQueryBuilder();
        Map<String, Object> searchType = new HashMap<>();
        List<List<Map<String, Object>>> query = builder.getSearchResult(param, masterInfo, 0, false, searchType);
        ObjectMapper object = new ObjectMapper();
        return object.writeValueAsString(query.get(0));
    }

    /**
	 * Gets the master entry data.
	 *
	 * @param dataMap the data map
	 * @return the master entry data
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
    @SovaMapping(value = "/getMasterValues", method = SovaRequestMethod.POST)
    public String getMasterEntryData(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        String searchId = dataMap.get(SEARCH_ID).toString().trim();
        MasterSearchLoadInfo masterInfo = MasterSearchDao.loadInfo(searchId);
        return JsonUtils.toJsonOrElse(masterInfo, "");
    }
}
