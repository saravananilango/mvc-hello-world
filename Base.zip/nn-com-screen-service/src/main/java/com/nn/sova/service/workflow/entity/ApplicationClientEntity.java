package com.nn.sova.service.workflow.entity;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.service.user.UserContext;

import lombok.Data;

/**
 * ApplicationClientEntity class used as data holder of application
 * while request happens from other front end's, API or batch
 * 
 * @author punithanantony.d@vaken.cloud (Punithan Antony Das)
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationClientEntity {
	
	/** submitting and status changing user id, can be modified */
	private String userId = UserContext.getInstance().getUserName();
	
	/** unique id of the individual application */
	private UUID applicationId;
	
	/**The current version of the application */
	private int version = 1;
	
	/**The previous version of the application */
	private int submittedVersion = 1;
	
	/**The application is whether resubmitting application */
	private boolean resubmittingApplication = false;
	
	/**The application is whether saved as draft */
	private boolean draftApplication = false;
	
	/** The screen id, approval process will set service id automatically*/
	private String screenId;
	
	/** The description of the submitting application. */
	private String description;
	
	/** The description of the submitting application. */
	private String comment;
	
	/** The computed value to compare with default value in database for including flows and skipping units. */
	private Object flowValue = StringUtils.EMPTY;
	
	/** The skip value to compare with default value in database for skipping units. */
	private Object skipValue = StringUtils.EMPTY;
	
	/** The application's unique id. */
	private String applicationUniqueId = StringUtils.EMPTY;

	/** set true if application is urgent/hurry */
	private boolean urgent = false;
	
	/** The Due Date & time. */
	private Timestamp dueDateTime;
	
	/** whether the process is batch */
	private boolean batchProcess = false;
	
	/** Default false for if not action by master approver */
	private boolean master = false;
	
	/** Default false for if not action by master approver */
	private boolean admin = false;
	
	/** Approval Status to get updated in approval flow */ 
	private String status;
	
	/** Approval configuration flow id */ 
	private String flowId;
	
	/** current paginating applications status */
	private String paginationStatus;
	
	/** current paginating applications sorting column */
	private String paginationSortColumn = "application.submission_date_time";
	
	/** current paginating applications sorting order */
	private SortType paginationSortOrder = SortType.DESC;
	
	/** current paginating applications search key*/
	private String paginationSearchKey = StringUtils.EMPTY;
	
	/** current paginating applications priority*/
	private boolean paginationPriority = false;
	
	/** current paginating application's index*/
	private BigInteger paginationIndex = BigInteger.ZERO;
	
	/** current paginating action (previous or next)*/
	private String paginationAction = StringUtils.EMPTY;
	
	/** current paginating applications from applicant tray*/
	private boolean applicantTray = false;
	
	/** the approval flow steps of external user id which required at first */ 
	private String firstExternalUserId = StringUtils.EMPTY;
	
	/** the approval flow steps of external user id which required at second */ 
	private String secondExternalUserId = StringUtils.EMPTY;
	
	/** the approval flow steps of external user id which required at third */ 
	private String thirdExternalUserId = StringUtils.EMPTY;
	
	/** the approval flow steps of external user id which required at fourth */ 
	private String fourthExternalUserId = StringUtils.EMPTY;
	
	/** the approval flow steps of external user id which required at fifth */ 
	private String fifthExternalUserId = StringUtils.EMPTY;
	
	/** Application step entity list from the stepper component */
	private List<ApplicationStepEntity> stepEntityList = new ArrayList<>();
}
