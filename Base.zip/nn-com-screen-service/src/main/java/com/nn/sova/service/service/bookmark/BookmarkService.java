package com.nn.sova.service.service.bookmark;

import java.util.Map;

/**
 * Bookmarkservice is used to control bookmark related operations.
 * 
 * @author Mohammed Shameer Ummer Koya.
 */
public interface BookmarkService {

	/**
	 * getBookmarkDatais used to get the user related bookmark data.
	 * 
	 * @return
	 */
	Map<String, Object> getBookmarkData();

	/**
	 * insertBookmarkData is used to insert the bookmark data.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> insertBookmarkData(Map<String, Object> paramMap);

	/**
	 * deleteBookmarkData is used to delete the bookmark data.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> deleteBookmarkData(Map<String, Object> paramMap);

	/**
	 * shareBookmarkData is used to share the bookmark data.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> shareBookmarkData(Map<String, Object> paramMap);

	/**
	 * markDefaultBookmarkData is used to mark the bookmark data as default.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> markDefaultBookmarkData(Map<String, Object> paramMap);

	/**
	 * getBookmarkDataByName is used to get the bookmark data by name.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> getBookmarkDataByName(Map<String, Object> paramMap);

	/**
	 * removeDefaultBookmarkData is used to remove the bookmark data as default.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> removeDefaultBookmarkData(Map<String, Object> paramMap);

}
