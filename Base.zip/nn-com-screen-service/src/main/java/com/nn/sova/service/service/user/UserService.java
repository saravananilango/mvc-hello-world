package com.nn.sova.service.service.user;

import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * UserService is used to change the user account data.
 * 
 * @author Mohammed Shameer Ummer Koya.
 */
public interface UserService {

	/**
	 * changeUserImage is used to change the user image data of the user.
	 * 
	 * @param paramMap
	 * @return
	 */
	Map<String, Object> changeUserImage(Map<String, Object> paramMap);
	
	/**
	 * getUserPreferenceData is used to get the preference data of the user.
	 * 
	 * @return
	 */
	Map<String, Object> getUserPreferenceData() throws QueryException;
	
 	/**
 	 * 
 	 * @param isDebug
 	 * @return
 	 */
 	boolean updateDebugMode(boolean isDebug);

	/**
	 * get the target screen url based on 
	 * @param sourceScreenId
	 * @param targetScreenDefId
	 * @return
	 */
	Map<String, Object> getTargetScreenIdData(String sourceScreenId, String targetScreenDefId);
	
	/**
	 * get the user's higher order sid
	 * @param screenId
	 * @return
	 */
	String getUserHigherOrderSid(String screenId);

}