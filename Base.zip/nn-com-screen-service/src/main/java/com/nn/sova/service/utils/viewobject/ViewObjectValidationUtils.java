package com.nn.sova.service.utils.viewobject;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * ViewObjectValidationUtils used for view object freeze validation
 * 
 * @author Hariprasath Kamaraj
 *
 */
public class ViewObjectValidationUtils {
	

	/**
	 * getReleaseStatusForViewObject for freeze
	 * @param paramMap
	 * @return
	 */
	//freeze
	public static Map<String,Object> getReleaseStatusForViewObject(Map<String,Object> paramMap){
		try {
			if(paramMap.containsKey("changeRequestId") && Objects.nonNull(paramMap.get("changeRequestId"))) {
				paramMap.put("status", Integer.parseInt(String.valueOf(new QueryBuilder().btSchema().select().count("*", "count").from("view_object_definition").where(ConditionBuilder.instance().eq("change_request_id", paramMap.get("changeRequestId")).and()
						.brackets(ConditionBuilder.instance().inWithList("source_status", Arrays.asList(ViewObjectEnum.INPROGRESS.name(), ViewObjectEnum.INACTIVE.name()))
						.or().eq("status_flag", false))).build(false).execute().get(0).get("count"))) > 0 ? false : true);
			}else {
				paramMap.put("status", false);
				paramMap.put("message", "Change request id is null");
			}
		}catch(Exception exception) {
			paramMap.put("status", false);
			paramMap.put("message", exception.getMessage());
		}
		return paramMap;
	}
	
	
}