package com.nn.sova.service.controller.sqleditor;

import java.util.HashMap;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.service.sqleditor.SqlEditorService;
import com.nn.sova.service.service.sqleditor.SqlEditorServiceImpl;
import com.nn.sova.utility.logger.ApplicationLogger;

@SovaMapping("/sqleditor")
public class SqlEditorController {

    /** The logger. */
    private static ApplicationLogger logger = ApplicationLogger.create(SqlEditorController.class);

    /** The SqlEditorService */
    private final SqlEditorService sqlEditorService;

    /**
	 * SqlEditorController is a constructor used to initialize the value for
	 * SqlEditorService
	 *
	 */
    public SqlEditorController() {
        sqlEditorService = new SqlEditorServiceImpl();
    }

    /**
	 * loadSuggestion is to return the result the searched suggestion
	 *
	 * @param requestMap
	 * @return the map
	 */
    //post_lambda 
	@SovaMapping(value = "loadSuggestion", method = SovaRequestMethod.POST)
    public Map<String, Object> loadSuggestion(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> requestMap = (Map<String, Object>) request.getBody();
        Map<String, Object> resultMap = new HashMap<>();
        try {
            resultMap = sqlEditorService.loadSuggestion(requestMap);
        } catch (QueryException exception) {
            logger.error(exception);
        }
        return resultMap;
    }
}
