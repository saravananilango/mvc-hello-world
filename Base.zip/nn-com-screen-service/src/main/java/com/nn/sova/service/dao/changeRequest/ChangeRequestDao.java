package com.nn.sova.service.dao.changeRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import com.nn.sova.changerequest.ChangeRequestStatusEnum;
import com.nn.sova.changerequest.ColumnName;
import com.nn.sova.changerequest.TableName;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;

public class ChangeRequestDao {
	/**
	 * filterChangeRequest method is used to delete CrData based on cr id and table
	 * name data or not current environment
	 *
	 * @param filterConditionMap- crId
	 * 
	 * @return true/false
	 */
	public static List<Map<String, Object>> filterChangeRequest(String searchKey,
			Map<String, Object> filterConditionMap, int limit) {
		SelectQueryBuilder selectQueryBuilder = new QueryBuilder().btSchema().select();

		ConditionBuilder filterCondition = ConditionBuilder.instance();
		AtomicBoolean filter = new AtomicBoolean(false);
		if (Objects.nonNull(filterConditionMap)) {
			filterConditionMap.forEach((key, value) -> {
				if (!filter.get()) {
					setCondition(filterCondition, key, value);
					filter.set(true);
				} else {
					filterCondition.and();
					setCondition(filterCondition, key, value);
				}
			});
		}
		ConditionBuilder condition = ConditionBuilder.instance().eq(ColumnName.OWNER, ContextBean.getUserId());
		condition.and().eq(ColumnName.PARENT_SYSTEM_ID, EnvironmentReader.getSystemId());
		condition.and().eq(ColumnName.TENANT_ID, ContextBean.getTenantId());
		condition.and().eq(ColumnName.PARENT_STATUS, ChangeRequestStatusEnum.NOT_RELEASED.name());
		ConditionBuilder searchCondition = ConditionBuilder.instance()
				.ilike(ColumnName.REQUEST_ID, "%" + searchKey + "%").or()
				.ilike(ColumnName.TITLE, "%" + searchKey + "%");

		condition.and().brackets(searchCondition);
		if (filter.get()) {
			condition.and().brackets(filterCondition);
		}
		if (limit != 0) {
			selectQueryBuilder.limit(limit);
		}

		try {
			return selectQueryBuilder.getWithAliasName(ColumnName.REQUEST_ID, ColumnName.REQUEST_ID)
					.getWithAliasName(ColumnName.TITLE, ColumnName.TITLE)
					.getWithAliasName(ColumnName.DESCRIPTION, ColumnName.DESCRIPTION)
					.getWithAliasName(ColumnName.VERSION_NO, ColumnName.VERSION_NO).from(TableName.CR_TABLE)
					.where(condition).orderBy(ColumnName.PARENT_UPDATED_DATE, SortType.DESC).build(false).execute();
		} catch (QueryException e) {
			return new ArrayList<>();
		}
	}

	private static void setCondition(ConditionBuilder condition, String key, Object value) {
		if (value instanceof List) {
			condition.inWithList(key, (List<Object>) value);
		} else {
			condition.eq(key, value);
		}
	}

	public static List<Map<String, Object>> getRecentRequestInboxData(List<Map<String, Object>> request) {
		return request.stream().map(cr -> {
			Map<String, Object> inboxData = new HashMap<>();
			inboxData.put("requestId", cr.get(ColumnName.REQUEST_ID));
			inboxData.put("title", cr.get(ColumnName.TITLE));
			inboxData.put("version", cr.get(ColumnName.VERSION_NO));
			inboxData.put("description", cr.get(ColumnName.DESCRIPTION));
			return inboxData;
		}).collect(Collectors.toList());
	}

	public static List<Map<String, Object>> getAddToExistingMaster(List<Map<String, Object>> request) {
		return request.stream().map(cr -> {
			Map<String, Object> masterData = new HashMap<>();
			masterData.put("showText", cr.get(ColumnName.REQUEST_ID) + "  " + cr.get(ColumnName.TITLE));
			masterData.put("keyText", cr.get(ColumnName.REQUEST_ID));
			masterData.put("setText", cr.get(ColumnName.REQUEST_ID));

			Map<String, Object> extraDetails = new HashMap<>();
			extraDetails.put("requestId", cr.get(ColumnName.REQUEST_ID));
			extraDetails.put("title", cr.get(ColumnName.TITLE));
			extraDetails.put("description", cr.get(ColumnName.DESCRIPTION));
			extraDetails.put("version", cr.get(ColumnName.VERSION_NO));
			masterData.put("extraFields", extraDetails);

			return masterData;
		}).collect(Collectors.toList());
	}

	public static Map<String, Object> getVersionMaster(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		try {
			QueryBuilder queryBuilder = new QueryBuilder();
			Map<String, Object> masterDetail = getMasterDetails(paramMap);
			String keyword = "%" + paramMap.get("keyword") + "%";

			ConditionBuilder versionCondition = ConditionBuilder.instance().ilike(getString(masterDetail, "key_column_name"), keyword);
			versionCondition.and().eq("version_status", "open");
			if(paramMap.containsKey("productCode") &&Objects.nonNull(paramMap.get("productCode"))){
				versionCondition.and().eq("product_code", Objects.toString(paramMap.get("productCode")));
			}
			List<Map<String, Object>> resultDataList = queryBuilder.btSchema().select().checkIndependentTenant(true).distinct()
					.getWithAliasName(getString(masterDetail, "show_column_name"), "showText")
					.getWithAliasName(getString(masterDetail, "set_column_name"), "setText")
					.getWithAliasName(getString(masterDetail, "key_column_name"), "keyText")
					.getWithAliasName(getString(masterDetail, "key_column_name"), "subText")
					.getWithAliasName("version_status", "extraFields")
					.distinct()
					.from(getString(masterDetail, "table_name"))
					.where(versionCondition).orderBy("combined_version", SortType.ASC)
					.build(false).limit(5).execute();
			addStatusColor(resultDataList);
			resultMap.put("result", resultDataList);
		} catch (Exception exception) {

		}
		return resultMap;
	}

	private static Map<String, Object> getMasterDetails(Map<String, Object> paramMap) {
		if(paramMap.containsKey("customMasterId")){
			ConditionBuilder condition = ConditionBuilder.instance().eq("master_id", paramMap.get("masterSearchId"));
			List<Map<String, Object>> masterDef = com.nn.sova.changerequest.ChangeRequestDao.fetchRecords("master_definition", condition);
			if(!masterDef.isEmpty()){
				return masterDef.get(0);
			}
		}
		Map<String, Object> masterDetail = new HashMap<>();
		masterDetail.put("table_name", "version_master");
		masterDetail.put("set_column_name", "combined_version");
		masterDetail.put("key_column_name", "combined_version");
		masterDetail.put("show_column_name", "combined_version");
		return masterDetail;
	}

	public static void addStatusColor(List<Map<String, Object>> resultDataList) {
		if(!resultDataList.isEmpty()){
			resultDataList.forEach(record -> {
				String versionStatus = getString(record, "extraFields");
				record.put("tagText", versionStatus);
				record.put("tagTextColor", getVersionStatusColor(versionStatus));
			});

		}
	}
	private static String getVersionStatusColor(String versionStatus) {
		if(stringEqual(versionStatus, "open")){
			return "primary";
		} else if(stringEqual(versionStatus, "released")){
			return "success";
		} else {
			return "default";
		}
	}

	/**
	 * get string from map
	 * @param conditionMap
	 * @param key
	 * @return String
	 */
	private static String getString(Map<String, Object> conditionMap, Object key) {
		return String.valueOf(conditionMap.get(String.valueOf(key)));
	}

	public static boolean stringEqual(Object left, Object right) {
		return String.valueOf(left).equalsIgnoreCase(String.valueOf(right));
	}

}