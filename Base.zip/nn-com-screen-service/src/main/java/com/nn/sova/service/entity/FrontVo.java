package com.nn.sova.service.entity;

import lombok.Data;

/**
 * The Class FrontVo.
 * @author Logchand
 * 
 */
@Data
public class FrontVo {
	String id;
	String method;
	Object params; 
}
