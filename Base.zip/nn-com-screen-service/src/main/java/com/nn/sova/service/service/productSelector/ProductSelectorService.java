package com.nn.sova.service.service.productSelector;

import java.io.IOException;
import java.util.Map;

/**
 * productSelectorService interface
 * 
 * @author Inigo Raj V
 */
public interface ProductSelectorService {

	String getProductDetails(Map<String, Object> dataMap) throws IOException;

	String getSubProductDetails(Map<String, Object> dataMap) throws IOException;
 
	void saveProductDetailsAsIni(Map<String,Object> dataMap); 

	String getIniDetails() throws IOException;
}
