package com.nn.sova.service.dao.wizard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * WizardDaoImpl class used to make DB operation related to wizard component
 * 
 * @implments WizardDao
 * @author Vivek Kannan E
 */

public class WizardDaoImpl implements WizardDao {

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(WizardDaoImpl.class);

	/** Constant **/
	private static final String WIZARD = "wizard";

	/** Constant **/
	private static final String WIZARD_ID = "wizard_id";

	/** Constant **/
	private static final String WIZARD_DIALOG_ID = "wizard_dialog_id";
	
	/** Constant **/
	private static final String WIZARD_TEMPLATE = "wizard_template";
	
	/** Constant **/
	private static final String WIZARD_TEMPLATE_DATA = "wizard_template_data";
	
	/** Constant **/
	private static final String WIZARD_TEMPLATE_METHODS = "wizard_template_methods";
	
	/** Constant **/
	private static final String WIZARD_DIALOG_ATTRIBUTE = "wizard_dialog_attribute";

	/**
	 * getData method used to get the wizard values stored in the database
	 * 
	 * @param {String} wizardId
	 * @return {List<Object>} wizardList
	 */
	@Override
	public List<Map<String, Object>> getData(String wizardId) {
		logger.info("getData method started for wizardId={}.", wizardId);
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		try {
			selectedDataList= queryBuilder.select()
					.getWithAliasName(WIZARD_DIALOG_ID, "id")
					.getWithAliasName(WIZARD_TEMPLATE, "template")
					.getWithAliasName(WIZARD_TEMPLATE_DATA, "templateData")
					.getWithAliasName(WIZARD_TEMPLATE_METHODS, "templateMethods")
					.getWithAliasName(WIZARD_DIALOG_ATTRIBUTE, "wizardAttribute")
					.from(WIZARD)
					.where(ConditionBuilder.instance().eq(WIZARD_ID, wizardId))
					.build(false).execute();
		} catch (QueryException exception) {
			logger.error(exception);
		}
		
		logger.info("getData end");
		return selectedDataList;
	}

	/**
	 * getData method used to get the wizard values stored in the database
	 * 
	 * @param {String} wizardId
	 * @param {String} wizardDialogId
	 * @return {Object} wizardObject
	 */
	@Override
	public Map<String, Object> getData(String wizardId, String wizardDialogId) {
		logger.info("getData method started for wizardId={}, wizardDialogId={}.", wizardId, wizardDialogId);
		QueryBuilder queryBuilder = new QueryBuilder();
		Map<String, Object> wizardMap = new HashMap<>();
		List<Map<String, Object>> selectedDataList = new ArrayList<>();
		try {
			selectedDataList= queryBuilder.select()
					.getWithAliasName(WIZARD_DIALOG_ID, "id")
					.getWithAliasName(WIZARD_TEMPLATE, "template")
					.getWithAliasName(WIZARD_TEMPLATE_DATA, "templateData")
					.getWithAliasName(WIZARD_TEMPLATE_METHODS, "templateMethods")
					.getWithAliasName(WIZARD_DIALOG_ATTRIBUTE, "wizardAttribute")
					.from(WIZARD)
					.where(ConditionBuilder.instance().eq(WIZARD_ID, wizardId).and().eq(WIZARD_DIALOG_ID, wizardDialogId))
					.build(false).execute();
		} catch (QueryException exception) {
			logger.error(exception);
		}
		if(CollectionUtils.isNotEmpty(selectedDataList)) {
			wizardMap = selectedDataList.get(0);
		}
		logger.info("getData end");
		return wizardMap;
	}
}