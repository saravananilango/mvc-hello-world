package com.nn.sova.service.service.notification;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.nn.sova.utility.api.WebServiceUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * Notification Client service class to access notification api.
 * @author saravana
 *
 */
public class NotificationService {

	private static ApplicationLogger logger = ApplicationLogger.create(NotificationService.class);
	
	private static final String INVALID_PARAMETER_ERROR_MSG = "Process aborted because given request parameter is null or empty - {}";
	
	/**
	 * Used to maintain singleton instance.
	 */
	private static NotificationService instance = null;
	

	/**
	 * Instantiates NotificationService.
	 */
	private NotificationService() {

	}
	
	/**
	 * Gets instance of NotificationService class.
	 *
	 * @return the instance
	 */
	public static NotificationService getInstance() {
		if (instance == null) {
			instance = new NotificationService();
		}
		return instance;
	}
	
	/**
	 * Action based api - Send mail notification to the users . 
	 * 
	 * @param notificationData
	 */
	public void notifyByMail(List<Map<String,Object>> notificationData) {
		if(Objects.isNull(notificationData) || notificationData.isEmpty()) {
			logger.error(INVALID_PARAMETER_ERROR_MSG, notificationData);
		}
		WebServiceUtils.getInstance().exchangeCallForNotification(NotificationApiEndPoint.NOTIFY_BY_MAIL.getEndPoint(), HttpMethod.POST,
				Object.class, notificationData, MediaType.APPLICATION_JSON);
	}
	
	/**
	 * Action based api - Send sms notification to the users .
	 * @param notificationData
	 */
	public void notifyBySms(List<Map<String,Object>> notificationData) {
		if(Objects.isNull(notificationData) || notificationData.isEmpty()) {
			logger.error(INVALID_PARAMETER_ERROR_MSG, notificationData);
		}
		WebServiceUtils.getInstance().exchangeCallForNotification(NotificationApiEndPoint.NOTIFY_BY_SMS.getEndPoint(), HttpMethod.POST,
				Object.class, notificationData, MediaType.APPLICATION_JSON);
	}
	
	/**
	 * Action based api - Send mobile push notification to the registered fcm id .
	 * @param notificationData
	 */
	public void notifyByFcm(List<Map<String,Object>> notificationData) {
		if(Objects.isNull(notificationData) || notificationData.isEmpty()) {
			logger.error(INVALID_PARAMETER_ERROR_MSG, notificationData);
		}
		WebServiceUtils.getInstance().exchangeCallForNotification(NotificationApiEndPoint.NOTIFY_BY_FCM.getEndPoint(), HttpMethod.POST,
				Object.class, notificationData, MediaType.APPLICATION_JSON);
	}
	
	/**
	 * Action based api - Send email/sms/mobile_push_notification to the userids if the user subscribed.
	 * @param notificationData
	 */
	public void notify(List<Map<String,Object>> notificationData) {
		if(Objects.isNull(notificationData) || notificationData.isEmpty()) {
			logger.error(INVALID_PARAMETER_ERROR_MSG, notificationData);
		}
		WebServiceUtils.getInstance().exchangeCallForNotification(NotificationApiEndPoint.NOTIFY.getEndPoint(), HttpMethod.POST,
				Object.class, notificationData, MediaType.APPLICATION_JSON);
	}
}
