package com.nn.sova.service.utils.viewobject;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;
import com.nn.sova.validation.QueryValidation;

import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Alias;
import net.sf.jsqlparser.expression.CaseExpression;
import net.sf.jsqlparser.expression.CastExpression;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.Function;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.Parenthesis;
import net.sf.jsqlparser.expression.StringValue;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.create.table.ColDataType;
import net.sf.jsqlparser.statement.select.GroupByElement;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.select.SelectBody;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;
import net.sf.jsqlparser.statement.select.SetOperation;
import net.sf.jsqlparser.statement.select.SetOperationList;
import net.sf.jsqlparser.statement.select.SubSelect;
import net.sf.jsqlparser.statement.select.WithItem;
import net.sf.jsqlparser.util.deparser.ExpressionDeParser;
import net.sf.jsqlparser.util.deparser.SelectDeParser;


/**
 * ViewObjectLanguageUtils for language dependent utilities
 * 
 * @author Hariprasath Kamaraj
 *
 */
public class ViewObjectLanguageUtils {
	


	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(ViewObjectLanguageUtils.class);

	
	
		
	/**
	 * getFromSelect method is to get values from select query
	 * @param plainSelect
	 * @param paramMap
	 * @throws CustomException
	 */
	private void getFromSelect(PlainSelect plainSelect,String productCode, QueryExecutor queryExecutor,Map<String,Object> paramMap) throws CustomException {
		List<SelectItem> selectitems=plainSelect.getSelectItems();
		try{
		if(!paramMap.containsKey("columnDataList")){
			formColumnList(selectitems, paramMap);
		}else{
			formSubQueryColumnList(selectitems, paramMap);
		}
		if(plainSelect.getFromItem() instanceof Table){
		Table fromTable= (Table) plainSelect.getFromItem();
		getTablesWithAlias(paramMap, fromTable);
		if(!paramMap.containsKey("main_table")){
			paramMap.put("main_table", fromTable.getName());
		}
		buildJoinTables(plainSelect, productCode, queryExecutor, paramMap);
		}else if(plainSelect.getFromItem() instanceof SubSelect){

			SubSelect subSelect = (SubSelect) plainSelect.getFromItem();
			if(subSelect.getSelectBody() instanceof PlainSelect){
			PlainSelect subPlainSelect=(PlainSelect)subSelect.getSelectBody();
			buildJoinTables(subPlainSelect,productCode,queryExecutor, paramMap);
			getFromSelect(subPlainSelect, productCode,queryExecutor,paramMap);
			}else if(subSelect.getSelectBody() instanceof SetOperationList){
				SetOperationList setOperationList = (SetOperationList) subSelect.getSelectBody();
				 appendLangForOperation(setOperationList, productCode, queryExecutor, paramMap);
			}		
	
		}
		buildJoinTables(plainSelect, productCode,queryExecutor,paramMap);
		
		}catch(Exception exception){
			throw new CustomException(exception);
		}
	}
	
	
	
	/**
	 * formColumnList acquires select columns from the query
	 * @param selectitems
	 * @param paramMap
	 * @throws CustomException
	 */
	private void formColumnList(List<SelectItem> selectitems,Map<String,Object> paramMap) throws CustomException{
		Map<String,Object> columnDataDetailsMap = new HashMap<>();
		Map<String,Object> expressionColumnMap = new HashMap<>();
		Map<String,Object> expressionColumnDetailsMap = new HashMap<>();
		try{
		if(!selectitems.isEmpty()){
            buildColumns(selectitems, paramMap,columnDataDetailsMap,expressionColumnMap,expressionColumnDetailsMap);			
			paramMap.put("columnDataList", columnDataDetailsMap);
			paramMap.put("expressionColumns", expressionColumnMap);
			paramMap.put("expressionColumnDetailsMap",expressionColumnDetailsMap);
			}
		}catch(Exception exception){
			throw new CustomException(exception);
		}
		
	}
	
	
	/**
	 * formColumnList acquires select columns from the query
	 * @param selectitems
	 * @param paramMap
	 * @throws CustomException
	 */
	private void formSubQueryColumnList(List<SelectItem> selectitems,Map<String,Object> paramMap) throws CustomException{
		Map<String,Object> columnDataDetailsMap = new HashMap<>();
		Map<String,Object> expressionColumnMap = new HashMap<>();
		Map<String,Object> expressionColumnDetailsMap= new HashMap<>();
		try{
			if(paramMap.containsKey("subQueryColumnMap") && Objects.nonNull(paramMap.get("subQueryColumnMap"))){
				columnDataDetailsMap = (Map<String, Object>) paramMap.get("subQueryColumnMap");
			}
		if(!selectitems.isEmpty()){
            buildColumns(selectitems, paramMap,columnDataDetailsMap,expressionColumnMap,expressionColumnDetailsMap);			
			paramMap.put("subQueryColumnMap", columnDataDetailsMap);
			paramMap.put("subQueryexpressionColumns", expressionColumnMap);
			paramMap.put("subExpColumnDetailsMap",expressionColumnDetailsMap);
			}
		}catch(Exception exception){
			throw new CustomException(exception);
		}
		
	}
	
	
	
	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param paramMap
	 * @param table
	 * @throws CustomException
	 */
	private void getTablesWithAlias(Map<String,Object> paramMap , Table table) throws CustomException{
		LinkedHashMap<String,Object> tableAliasNameMap = new LinkedHashMap<>();
		try{
			if(paramMap.containsKey("tableAliasMap") && Objects.nonNull(paramMap.get("tableAliasMap"))){
				tableAliasNameMap = (LinkedHashMap<String, Object>) paramMap.get("tableAliasMap");
			}
			if(Objects.nonNull(table)){
			
			tableAliasNameMap.put(Objects.isNull(table.getAlias()) ? table.getName() : table.getAlias().getName(),table.getName());
			paramMap.put("tableAliasMap", tableAliasNameMap);
			}
		}catch(Exception exception){
			throw new CustomException(exception);
		}
	}
	
	
	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param paramMap
	 * @param expressionColumnDetailsMap 
	 * @param expressionColumnMap2 
	 * @param columnDataDetailsMap2 
	 * @param table
	 * @throws CustomException
	 */
	private void buildColumns(List<SelectItem> selectitems,Map<String,Object> paramMap, Map<String, Object> columnDataDetailsMap, Map<String, Object> expressionColumnMap, Map<String, Object> expressionColumnDetailsMap) throws CustomException{
		try{
			if(!selectitems.isEmpty()){
				for(int i=0;i<selectitems.size();i++){
					Alias aliasName = ((SelectExpressionItem) selectitems.get(i)).getAlias();
					Expression expression=((SelectExpressionItem) selectitems.get(i)).getExpression();  
					if(expression instanceof Column){
						Column col=(Column)expression;
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							columnDataDetailsMap.put(aliasName.getName(), col.getName(false));
						}else{
							columnDataDetailsMap.put(col.getColumnName(), col.getName(false));
						}
					}else if(expression instanceof Function){
						Function fun = (Function) expression;
						ExpressionList parameterList = fun.getParameters();
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnDetailsMap.put(aliasName.getName(), parameterList.getExpressions());
							expressionColumnMap.put(aliasName.getName(),((Function) expression).getName());
						}else{
							expressionColumnDetailsMap.put(((Function) expression).getName(), parameterList.getExpressions());
							expressionColumnMap.put(((Function) expression).getName(),((Function) expression).getName());
						}
					}else if(expression instanceof CaseExpression){
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(),"CASE");
					}
					}else if(expression instanceof StringValue){
						StringValue column = (StringValue)expression;
						if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
							expressionColumnMap.put(aliasName.getName(), column.getValue());
						}else{
							expressionColumnMap.put(column.getValue(), column.getValue());
						}
					}else if(expression instanceof CastExpression){
						CastExpression  castExp = (CastExpression)expression;
						Expression leftElement = castExp.getLeftExpression();
						ColDataType colDataType =  castExp.getType();
						if(leftElement instanceof CaseExpression){
							if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
								expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
							}else{
								expressionColumnMap.put("CASE", colDataType.getDataType());
							}
							}else if(leftElement instanceof Parenthesis){
								if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
									expressionColumnMap.put(aliasName.getName(), colDataType.getDataType());
								}	
						}else if(leftElement instanceof StringValue){
							StringValue column = (StringValue)leftElement;
							if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
								expressionColumnMap.put(aliasName.getName(), column.getValue());
							}else{
								expressionColumnMap.put(column.getValue(), column.getValue());
							}
				      }else if(leftElement instanceof LongValue){
				    	  LongValue column = (LongValue)leftElement;
							if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
								expressionColumnMap.put(aliasName.getName(), column.getValue());
							}else{
								expressionColumnMap.put(Long.toString(column.getValue()), column.getValue());
							}
				      }else if(leftElement instanceof Column){
				    	     Column col=(Column)leftElement;
							if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
								columnDataDetailsMap.put(aliasName.getName(), col.getName(false));
							}else{
								columnDataDetailsMap.put(col.getColumnName(), col.getName(false));
							}
				       }else if(leftElement instanceof Function){
							if(Objects.nonNull(aliasName) && !StringUtils.isEmpty(aliasName.getName())){
								expressionColumnMap.put(aliasName.getName(),((Function) leftElement).getName());
							}else{
								expressionColumnMap.put(((Function) leftElement).getName(),((Function) leftElement).getName());
							}
						}
		         }
				}
			}
			}catch(Exception exception){
			throw new CustomException(exception);
			}
		}
	

	/**
	 * getTablesWithAlias get tablename and its alias name from query
	 * @param queryExecutor 
	 * @param productCode 
	 * @param paramMap
	 * @param expressionColumnMap2 
	 * @param columnDataDetailsMap2 
	 * @param table
	 * @throws CustomException
	 */
	private void buildJoinTables(PlainSelect plainSelect,String productCode, QueryExecutor queryExecutor, Map<String,Object> paramMap) throws CustomException{
		List<Join> joinTablesList =plainSelect.getJoins();
		if(Objects.nonNull(joinTablesList) && !joinTablesList.isEmpty()){
		for(int i=0;i<joinTablesList.size();i++){
			if(joinTablesList.get(i).getRightItem() instanceof Table){
			Table tempTable = (Table) joinTablesList.get(i).getRightItem();
			getTablesWithAlias(paramMap, tempTable);
			tempTable.getName().format("sova_core_%s", tempTable.getName().toString());
			}else if(joinTablesList.get(i).getRightItem() instanceof SubSelect){
				SubSelect subSelect = (SubSelect) joinTablesList.get(i).getRightItem();
				if(subSelect.getSelectBody() instanceof PlainSelect){
				PlainSelect subPlainSelect=(PlainSelect)subSelect.getSelectBody();
				buildJoinTables(subPlainSelect, productCode,queryExecutor,paramMap);
				getFromSelect(subPlainSelect, productCode,queryExecutor,paramMap);
				}
			}else  if(joinTablesList.get(i).getRightItem() instanceof PlainSelect){
				PlainSelect subPlainSelect = (PlainSelect) joinTablesList.get(i).getRightItem();
				buildJoinTables(subPlainSelect,productCode,queryExecutor,paramMap);
				getFromSelect(subPlainSelect,productCode,queryExecutor,paramMap);
			}
		}
		}
	}
	
	
	
	/**
	 * getLangJoinQuery appends lang addon condition query
	 * @param paramMap
	 * @param langTableSet
	 * @param ivQueryExecutor 
	 * @param langTableWithAliasMap 
	 * @return
	 * @throws IOException
	 * @throws CustomException 
	 */
	public String getLangJoinQuery(Map<String,Object> paramMap, QueryExecutor queryExecutor) throws IOException, CustomException{
		logger.debug("## getLangJoinQuery method execution started.");
		String productCode = String.valueOf(paramMap.get(ViewObjectConstants.PRODUCT_CODE));
		ObjectMapper objectMapper = new ObjectMapper();
		Map configDataMap = (Map)paramMap.get(ViewObjectConstants.CONFIG_TABLE_DATA);
		String query = Objects.toString(configDataMap.get(ViewObjectConstants.VIEW_OBJECT_DEFINITION+".condition_details"),"");
		String parsedQuery = query.replace(";", "");
		StringBuilder langDependentQuery = new StringBuilder("");
		CCJSqlParserManager parserManager = new CCJSqlParserManager();
		ViewObjectParserUtils parserUtils = new ViewObjectParserUtils();
		Select select;
		String buffQueryString="";
		try {
			select = (Select) parserManager.parse(new StringReader(parsedQuery));
		if (select.getSelectBody() instanceof PlainSelect) {
			Map<String,Object> queryMap = new HashMap<>();
			PlainSelect plainSelect=(PlainSelect)select.getSelectBody(); 
			queryMap.putAll(paramMap);
			if(plainSelect.toString().toLowerCase().contains(" ilike ")) {
				parserUtils.checkForLikeExpression(plainSelect);
			}
			getFromSelect(plainSelect,  productCode, queryExecutor,queryMap);
			if(Objects.nonNull(select.getWithItemsList())) {
			List<WithItem> withItemList = select.getWithItemsList();
			if(!withItemList.isEmpty()) {
				Select tempSelect = (Select)CCJSqlParserUtil.parse(plainSelect.toString());
				List<String> removeTableList = removeTableName(tempSelect);
				paramMap.put("removeTableList", removeTableList);
				queryMap.put("removeTableList", removeTableList);
			}
			}
			buffQueryString = appendLangJoinCondition(queryMap, plainSelect, productCode, queryExecutor,paramMap);
			if(Objects.nonNull(select.getWithItemsList())) {
				List<WithItem> withItemList = select.getWithItemsList();
				for(WithItem itemObj : withItemList) {
					if(itemObj.isRecursive()) {
						langDependentQuery.append("WITH RECURSIVE ");
						if(Objects.nonNull(itemObj.getName())){
							langDependentQuery.append(itemObj.getName()+" ");
						}
						langDependentQuery.append(" AS ( ");
					}
					if(itemObj.getSelectBody() instanceof SetOperationList) {
						SetOperationList setOperationList = (SetOperationList) itemObj.getSelectBody();
						langDependentQuery.append(appendLangForOperation(setOperationList, productCode, queryExecutor, paramMap));
					}
					langDependentQuery.append(" ) ");
			}
				if(StringUtils.isNotEmpty(langDependentQuery.toString().trim())) {
					buffQueryString = langDependentQuery+" "+buffQueryString;
				}
			}
			return buffQueryString;
		} else if (select.getSelectBody() instanceof SetOperationList) {
			SetOperationList setOperationList = (SetOperationList) select.getSelectBody();
			return appendLangForOperation(setOperationList, productCode, queryExecutor, paramMap);
		} else {
			return query;
		}
		} catch (Exception exception) {
			logger.debug("## getLangJoinQuery method exception occured.");
			throw new CustomException(exception);
		}
	}
	
	
	

	/**
	 * getLangJoinQuery appends lang addon condition query
	 * @param paramMap
	 * @param langTableSet
	 * @param queryExecutor 
	 * @param paramMap2 
	 * @param langTableWithAliasMap 
	 * @return
	 * @throws CustomException 
	 * @throws IOException
	 */
	private String appendLangForOperation(SetOperationList setOperationList,String productCode,QueryExecutor queryExecutor, Map<String, Object> paramMap) throws CustomException{
		ViewObjectParserUtils parserUtils = new ViewObjectParserUtils();
		StringBuilder buffLangBuilder = new StringBuilder();
	List<SelectBody> selectList = setOperationList.getSelects();
	 List<SetOperation> operatorList = setOperationList.getOperations();
	for(int i=0;i<selectList.size();i++){
		if(selectList.get(i) instanceof PlainSelect){
			PlainSelect plainSelecta = (PlainSelect) selectList.get(i);
			if(plainSelecta.toString().toLowerCase().contains(" ilike ")) {
				parserUtils.checkForLikeExpression(plainSelecta);
			}
			if(Objects.nonNull(plainSelecta)){
				Map<String,Object> queryMasp = new HashMap<>();
				queryMasp.putAll(paramMap);
				getFromSelect(plainSelecta,productCode, queryExecutor, queryMasp);
				buffLangBuilder.append(appendLangJoinCondition(queryMasp, plainSelecta, productCode, queryExecutor,paramMap));
				if(operatorList.size() > i && Objects.nonNull(operatorList.get(i))){
					buffLangBuilder.append(" "+String.valueOf(operatorList.get(i))+" ");	
				}
			} 
		}
	  }
	   return String.valueOf(buffLangBuilder);
	}
	
	
	
	
	
	/**
	 * getLangJoinQuery appends lang addon condition query
	 * @param paramMap
	 * @param langTableSet
	 * @param queryExecutor 
	 * @param paramMap2 
	 * @param langTableWithAliasMap 
	 * @return
	 * @throws CustomException 
	 * @throws IOException
	 */
	private String appendLangJoinCondition(Map<String,Object> paramMap, PlainSelect plainSelect,String productCode,QueryExecutor queryExecutor, Map<String, Object> dataMap) throws CustomException{
		logger.debug("appendLangJoinCondition method started");
		String finalQuery = String.valueOf(plainSelect);
		try{
		LinkedHashMap<String, Object> tableAliasMap = (LinkedHashMap<String, Object>) paramMap.get("tableAliasMap");
		Set<String> keySets = tableAliasMap.entrySet().stream().map(mapper-> String.valueOf(mapper.getValue())).collect(Collectors.toSet());
		Map<String, List<LinkedHashMap<String, Object>>> groupAliasMap = groupTableByName(tableAliasMap);
		formColumnDetails(paramMap);
		formExpressionColumns(paramMap);
		StringBuilder conditionBuilderString = new StringBuilder();
		List<Map<String,Object>> columnDetailsData = (List)paramMap.get(ViewObjectConstants.COLUMN_DETAILS);
		List<Map<String,Object>> expColumnDetailsDataList = (List)paramMap.get("expColumnDetailsData");
		ConditionBuilder conditionBuilder = ConditionBuilder.instance();
		AtomicBoolean atBoolean = new AtomicBoolean(false);
		columnDetailsData.forEach(action->{
		     try {
		    String tableAliasName = getLangAliasToNormalAlias(String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_alias_name"))), String.valueOf(action.get(ViewObjectCommonUtils.bindConfigTableWithColumn("table_name"))), groupAliasMap);
			String tableName = convertLangToNormal(String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_name"))));
			action.put(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_name"), tableName);
			action.put(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_alias_name"), tableAliasName);
			if(Objects.nonNull(conditionBuilder.getQuery()) && StringUtils.isNotEmpty(conditionBuilder.getQuery())){
				conditionBuilder.or();
			}
			conditionBuilder.brackets(ConditionBuilder.instance().eq("table_definition_column_details.table_name", tableName).and()
					.eq("table_definition_column_details.column_name", String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("column_name")))).and()
					.eq("table_definition_column_details."+ViewObjectConstants.LANG_DEPENDENT, true));
		     } catch (Exception e) {
		    	logger.error("Error occured while iterating columnDetailsData in appendLangJoinCondition method" + e.getMessage());
		    	atBoolean.set(true);
		     }
		});
		
		if(atBoolean.get()){
			throw new CustomException("Error occured while iterating columnDetailsData in appendLangJoinCondition method");
		}
		atBoolean.set(false);
		if(!expColumnDetailsDataList.isEmpty()){
			expColumnDetailsDataList.forEach(action->{
		     try {
		    String tableAliasName = getLangAliasToNormalAlias(String.valueOf(action.get(ViewObjectCommonUtils.bindConfigTableWithColumn("table_alias_name"))), String.valueOf(action.get(ViewObjectCommonUtils.bindConfigTableWithColumn("table_name"))), groupAliasMap);
			String tableName = convertLangToNormal(String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_name"))));
			action.put("table_name", tableName);
			action.put("table_alias_name", tableAliasName);
			if(Objects.nonNull(conditionBuilder.getQuery()) && StringUtils.isNotEmpty(conditionBuilder.getQuery())){
				conditionBuilder.or();
			}
			conditionBuilder.brackets(ConditionBuilder.instance().eq("table_definition_column_details.table_name", tableName).and()
					.eq("table_definition_column_details.column_name", String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("column_name")))).and()
					.eq("table_definition_column_details.lang_dependent_flag", true));
		     } catch (Exception e) {
		    	logger.error("Error occured while iterating expColumnDetailsDataList in appendLangJoinCondition method" + e.getMessage());
		    	atBoolean.set(true);
		     }
		});
		}
		if(atBoolean.get()){
			throw new CustomException("Error occured while iterating expColumnDetailsDataList in appendLangJoinCondition method");
		}
		
		
		List<Map<String,Object>> langDependentColumns = queryExecutor.queryBuilder().select().get(ViewObjectConstants.TABLE_NAME,ViewObjectConstants.COLUMN_NAME,ViewObjectConstants.PRODUCT_CODE_COL).from(ViewObjectConstants.TABLE_DEFINITION_COLUMN_DETAILS)
				.where(conditionBuilder).build(false).execute();
		
		if(!langDependentColumns.isEmpty()){
			List<String> langDeptSets = langDependentColumns.stream().map(mapper-> String.valueOf(mapper.get("table_name"))).collect(Collectors.toList());
			List<Map<String,Object>> primaryKeyList = queryExecutor.queryBuilder().select().get(ViewObjectConstants.TABLE_NAME,ViewObjectConstants.COLUMN_NAME,ViewObjectConstants.PRODUCT_CODE_COL).from(ViewObjectConstants.TABLE_DEFINITION_COLUMN_DETAILS)
					.where(ConditionBuilder.instance().eq(ViewObjectConstants.PRODUCT_CODE_COL, productCode).and().in(ViewObjectConstants.TABLE_NAME,langDeptSets.toArray()).and().eq("primary_key", true)).build(false).execute();
			Set<String> addedList = new HashSet<>();
			
			List<Join> joinList = new ArrayList<>();
			Set<String> langJoinTables = new HashSet<>();
			List<Map<String,Object>> iterateList = new ArrayList<Map<String,Object>>();
			iterateList.addAll(columnDetailsData);
			iterateList.addAll(expColumnDetailsDataList);
				for(Map<String,Object>action : iterateList){
					String tableAliasName = String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_alias_name")));
					String tableName = String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("table_name")));
					String columnName = String.valueOf(action.get(ViewObjectCommonUtils.bindDetailTableWithColumnDetails("column_name")));
					if(equalsForLangTable(langDependentColumns,action)){
						if(!langJoinTables.contains(tableAliasName)){
						Join join = new Join();
						join.setLeft(true);
						Table table = new Table();
						table.setAlias(new Alias(tableAliasName+"_text",true));
						table.setName(tableName+"_text");
						join.setRightItem(table);
						join.setOnExpression(setOnExpression(paramMap, primaryKeyList, tableName, tableAliasName, columnName));
						joinList.add(join);
						paramMap.remove("expression");
					}
						if(!addedList.contains(tableAliasName+"_"+columnName)){
							List<SelectItem> selectitems=plainSelect.getSelectItems();
							for(int i=0;i<selectitems.size();i++){
								Expression expression=((SelectExpressionItem) selectitems.get(i)).getExpression();  
								if(expression instanceof Column){
									Column col=(Column)expression;
									String aliasName = Objects.nonNull(col.getTable().getAlias()) ? col.getTable().getAlias().toString() :col.getTable().toString(); 
									if(aliasName.contains("_text")){
										aliasName = getLangAliasToNormalAlias(aliasName, aliasName, groupAliasMap);
									}
									if(col.getColumnName().equals(columnName) && StringUtils.equals(tableAliasName,aliasName)){
										col.getTable().setAlias(new Alias(tableAliasName+"_text"));
												changeLangGroupColumn(plainSelect, tableAliasName,columnName);
										}
									}else if(expression instanceof Function){
										Function fun = (Function) expression;
										if(Objects.nonNull(fun.getParameters())){
										ExpressionList parameterList = fun.getParameters();
										List<Expression> expressionList = parameterList.getExpressions();
										for (Expression exp  : expressionList) {
											if(exp instanceof Column){
												Column col=(Column)exp;
												String aliasName = Objects.nonNull(col.getTable().getAlias()) ? col.getTable().getAlias().toString() :col.getTable().toString();
												if(aliasName.contains("_text")){
										            aliasName = getLangAliasToNormalAlias(aliasName, aliasName, groupAliasMap);
								                }
												if(col.getColumnName().equals(columnName) && StringUtils.equals(tableAliasName,aliasName)){
													col.getTable().setAlias(new Alias(tableAliasName+"_text"));
															changeLangGroupColumn(plainSelect, tableAliasName,columnName);
													}
											}
										}
										}
										
										
									}
						}
							if(!langJoinTables.contains(tableAliasName)){
								Column col = new Column();
								col.setColumnName("locale");
								col.setTable(new Table(tableAliasName+"_text"));
								SelectExpressionItem sel = new SelectExpressionItem(col);
								sel.setAlias(new Alias(tableAliasName+"_locale"));
								if(Objects.nonNull(paramMap.get("expressionColumns"))){
								Map<String,Object> expressionColumnMap =(Map<String, Object>) paramMap.get("expressionColumns");
								if(checkForAggregateFunction(expressionColumnMap) || Objects.nonNull(plainSelect.getGroupBy())){
									formGroupByColumns(plainSelect,col);
								}
								}
								selectitems.add(sel);
							}
					}
						langJoinTables.add(tableAliasName);
						}
				}
				List<Join> defaultJoins = plainSelect.getJoins();
				if(Objects.isNull(defaultJoins)){
					plainSelect.setJoins(joinList);
				}else{
					defaultJoins.addAll(joinList);
				}
					AtomicBoolean atCheck = new AtomicBoolean(false);
					for (String langAlias : langJoinTables) {
						if(atCheck.get()){
							conditionBuilderString.append(".and()");
						}
						conditionBuilderString.append(".brackets(ConditionBuilder.instance().eq(\""+langAlias+"_locale\",ContextBean.getLocale()).or().eq(\""+langAlias+"_locale\",\"\").or().isNull(\""+langAlias+"_locale\"))");
						atCheck.set(true);
					}
				if(StringUtils.isEmpty(Objects.toString(dataMap.get("condition"),""))){
					dataMap.put("condition", conditionBuilderString.toString());
				}
				finalQuery = plainSelect.toString();
			}
		boolean isGroupBy = false;
		if(Objects.nonNull(paramMap.get("expressionColumns"))){
			Map<String,Object> expressionColumnMap =(Map<String, Object>) paramMap.get("expressionColumns");
			if(checkForAggregateFunction(expressionColumnMap) || Objects.nonNull(plainSelect.getGroupBy())){
				isGroupBy = true;
			}
		}
		   List<String> tableNameList = tableAliasMap.entrySet().stream().map(action->action.getValue().toString()).collect(Collectors.toList());
				ViewObjectTenantUtils parserUtils = new ViewObjectTenantUtils(productCode);
			logger.debug("addTenantToQuery method ended" + finalQuery);
			finalQuery = checkForTenantColumns(finalQuery,tableAliasMap,columnDetailsData,productCode,plainSelect,isGroupBy);
			finalQuery = checkForEncryptKey(finalQuery,tableAliasMap,columnDetailsData,productCode,plainSelect,isGroupBy);
			finalQuery = deparseQueryWithProduct(productCode, finalQuery,paramMap);
			finalQuery = parserUtils.addTenantToQuery(finalQuery);
		}catch(Exception exception){
			logger.debug("##Exception occured in  getLangJoinQuery method ended.");
			throw new CustomException(exception);
		}
		logger.debug("## getLangJoinQuery method execution ended."+String.valueOf(plainSelect));
		return finalQuery;
	}
	
	



	private void formColumnDetails(Map<String, Object> paramMap) throws CustomException {
		logger.debug("formColumnDetails method started");
		try {
		Map<String,Object> columnAliasMap = (Map<String, Object>) paramMap.get("columnDataList");
		Map<String,Object> tableAliasMap=(Map<String, Object>) paramMap.get("tableAliasMap");
		String viewObject = String.valueOf(paramMap.get(ViewObjectConstants.VIEW_OBJECT));
		String productCode = String.valueOf(paramMap.get(ViewObjectConstants.PRODUCT_CODE));
		List<Map<String,Object>> columnDetailList = new ArrayList<>();
		for (Entry<String,Object> aliasEntry :columnAliasMap.entrySet()) {
			Map<String,Object> columnDataMap = new HashMap<>();
			columnDataMap.put(bindTableWithColumn("alias_name"), aliasEntry.getKey());
			columnDataMap.put(bindTableWithColumn(ViewObjectConstants.VIEW_OBJECT_NAME), viewObject);
			columnDataMap.put(bindTableWithColumn("product_code"), productCode);
			columnDataMap.put(bindTableWithColumn("data_element"), "");
			String[] columnNameArray = String.valueOf(aliasEntry.getValue()).split("\\.");
			if(columnNameArray.length > 1){
				String columnName = Objects.nonNull(columnNameArray[1]) && !StringUtils.isEmpty(columnNameArray[1]) ? columnNameArray[1] : "";
				String tableAliasName = Objects.nonNull(columnNameArray[0]) && !StringUtils.isEmpty(columnNameArray[0]) ? columnNameArray[0] : "";
				String tableName =!StringUtils.isEmpty(tableAliasName) && tableAliasMap.containsKey(tableAliasName) ? String.valueOf(tableAliasMap.get(tableAliasName)) :"";
				if(StringUtils.isEmpty(tableName)){
					if(Objects.nonNull(tableAliasName) && tableAliasName.endsWith("_text")){
						columnDataMap.put(bindTableWithColumn("column_name"), columnName);
						columnDataMap.put(bindTableWithColumn("table_name"), tableAliasName);
					}else{
					Map<String,String> columnTableMap = new HashMap<>();
					columnTableMap = getProperTableName(columnName,paramMap,tableAliasMap,columnTableMap);
					if(Objects.nonNull(columnTableMap) && !columnTableMap.isEmpty()){
					columnDataMap.put(bindTableWithColumn("column_name"), columnTableMap.get("columnName"));
					columnDataMap.put(bindTableWithColumn("table_name"), columnTableMap.get("tableName"));
					}else{
						columnDataMap.put(bindTableWithColumn("column_name"), columnName);
						columnDataMap.put(bindTableWithColumn("table_name"), tableAliasName);
					}
					}
				}else{
					columnDataMap.put(bindTableWithColumn("column_name"), columnName);
					columnDataMap.put(bindTableWithColumn("table_name"), tableName);
				}
				columnDataMap.put(bindTableWithColumn("table_alias_name"),  tableAliasName);
				columnDetailList.add(columnDataMap);
			}
		}
		paramMap.put(ViewObjectConstants.COLUMN_DETAILS, columnDetailList);
		paramMap.put("tableSet", tableAliasMap.entrySet().stream().map(obj-> String.valueOf(obj.getValue())).collect(Collectors.toSet()));
		paramMap.put("queryTableSet", paramMap.get("tableSet"));
		}catch(Exception exp) {
			throw new CustomException(exp);
		}
		logger.debug("formColumnDetails method ended");
	}
	
	
	/**
	 * @param columnName
	 * @param paramMap
	 * @param tableAliasMap 
	 * @param columnTableMap 
	 * @return
	 * @throws CustomException 
	 */
	public Map<String,String> getProperTableName(String columnName,
			Map<String, Object> paramMap, Map<String, Object> tableAliasMap, Map<String, String> columnTableMap) throws CustomException {
		logger.debug("getProperTableName method started");
		try {
		Map<String,Object> subQueryMap = new HashMap();
		if(paramMap.containsKey("subQueryColumnMap") &&  Objects.nonNull(paramMap.get("subQueryColumnMap"))){
		subQueryMap = (Map<String, Object>) paramMap.get("subQueryColumnMap");
		for(Entry<String,Object> entry : subQueryMap.entrySet()){
			if(entry.getKey().equals(columnName)){
				if(entry.getValue().toString().contains(".")){
					String[] columnNameArray = entry.getValue().toString().split("\\.");
					String tableName= tableAliasMap.containsKey(columnNameArray[0]) && Objects.nonNull(tableAliasMap.get(columnNameArray[0])) ? String.valueOf(tableAliasMap.get(columnNameArray[0])): "";
					if(!StringUtils.isEmpty(tableName)){
					columnTableMap.put("tableName", tableName);
					columnTableMap.put("columnName", columnNameArray[1]);
					break;
					}
				}
			}
		}
		}
		}catch(Exception exp) {
			throw new CustomException(exp);
		}
		logger.debug("getProperTableName method ended");
	return columnTableMap;	
	}	
	
	
	
	/**
	 * @param columnName
	 * @param paramMap
	 * @param tableAliasMap 
	 * @param columnTableMap 
	 * @return
	 */
	public String convertLangToNormal(String tableName) {
		logger.debug("convertLangToNormal method started:"+tableName);
		String properTableName = "";
		if(StringUtils.contains(tableName, "_text")){
			properTableName = tableName.split("_text")[0];
		} else{
			properTableName = tableName;
		}
		logger.debug("convertLangToNormal method ended:"+tableName);
		return properTableName;
	}
	
	
	/**
	 * @param columnName
	 * @param paramMap
	 * @param tableAliasMap 
	 * @param columnTableMap 
	 * @return
	 */
	private boolean equalsForLangTable(List<Map<String, Object>> langDependentColumns, Map<String,Object> columnDataMap ) {
		logger.debug("equalsForLangTable method started:"+langDependentColumns);
		boolean isLang  = false;
		for(Map langDependentData : langDependentColumns){
			if((StringUtils.equals(String.valueOf(langDependentData.get("table_name")), String.valueOf(columnDataMap.get(bindTableWithColumn("table_name")))))
					&& (StringUtils.equals(String.valueOf(langDependentData.get("column_name")), String.valueOf(columnDataMap.get(bindTableWithColumn("column_name")))))
					&& (StringUtils.equals(String.valueOf(langDependentData.get("product_code")), String.valueOf(columnDataMap.get(bindTableWithColumn("product_code")))))){
				isLang= true;
			}
		}
		logger.debug("equalsForLangTable method ended:"+langDependentColumns);
		return isLang;
	}
	
	
	
	/**
	 * @param columnName
	 * @param paramMap
	 * @param tableAliasMap 
	 * @param columnTableMap 
	 * @return
	 */
	private Expression setOnExpression(Map<String,Object> queryMap ,List<Map<String,Object>> primaryKeyList,String tableName,String tableAliasName,String columnName) {
		logger.debug("setOnExpression method started for table :"+tableName);
		AtomicInteger at = new AtomicInteger(0);
		primaryKeyList.stream().forEach(primaryKeyData->{
		if(StringUtils.equals(String.valueOf(primaryKeyData.get("table_name")), tableName)){
		EqualsTo equalToExp = new EqualsTo();
		Table tempTable = new Table();
		tempTable.setAlias(new Alias(tableAliasName,true));
		tempTable.setName(tableName);
		Table langTable = new Table();
		langTable.setAlias(new Alias(tableAliasName+"_text",true));
		langTable.setName(tableName+"_text");
		Column tempCol  = new Column();
		tempCol.setColumnName(String.valueOf(primaryKeyData.get("column_name")));
		tempCol.setTable(tempTable);
		Column langCol  = new Column();
		langCol.setColumnName(String.valueOf(primaryKeyData.get("column_name")));
		langCol.setTable(langTable);
		equalToExp.setLeftExpression(tempCol);
		equalToExp.setRightExpression(langCol);
		if(at.get()>0){
			Expression tempExp = (Expression) queryMap.get("expression");
			AndExpression andExp = new AndExpression(tempExp, equalToExp);
			queryMap.put("expression", andExp);
		}else{
			queryMap.put("expression", equalToExp);
		}
		at.incrementAndGet();
		}
	});
		Expression returnExpresson = (Expression) queryMap.get("expression");
		logger.debug("setOnExpression method ended for table :"+tableName);
		return returnExpresson;
		}
	
	/**
	 * @param columnName
	 * @param paramMap
	 * @param tableAliasMap 
	 * @param columnTableMap 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<LinkedHashMap<String,Object>>> groupTableByName(LinkedHashMap<String,Object> tableAliasMap) {
		logger.debug("groupTableByName method started for map :"+tableAliasMap);
		Map<String, List<LinkedHashMap<String,Object>>> groupAliasMap = new HashMap<>();
		Iterator iterObj = tableAliasMap.entrySet().iterator();
        while (iterObj.hasNext()) {
             Entry next = (Entry) iterObj.next();
              if (groupAliasMap.get(next.getValue()) != null) {
                   List tempAliasMap= groupAliasMap.get(next.getValue());
                   tempAliasMap.add(next);
                   groupAliasMap.put(String.valueOf(next.getValue()), tempAliasMap);
              }else{
                    List tempAliasMap=new ArrayList<>();
                    tempAliasMap.add(next);
                    groupAliasMap.put(String.valueOf(next.getValue()), tempAliasMap);

              }
        }
        logger.debug("groupTableByName method ended for map :"+tableAliasMap); 
        return groupAliasMap;
	}


	/**
	 * @param columnName
	 * @param paramMap
	 * @param tableAliasMap 
	 * @param columnTableMap 
	 * @return
	 * @throws CustomException 
	 */
	public String getLangAliasToNormalAlias(String aliasName,String tableName,Map<String, List<LinkedHashMap<String,Object>>> groupAliasMap) throws CustomException {
		logger.debug("getLangAliasToNormalAlias method started for table :"+tableName);
		String properAliasName = "";
		try {
		if(tableName.contains("_text")){
			String[] tempTableName = tableName.split("_text");
			String[] tempAliasName = aliasName.split(tempTableName[0]+"_text");
			int tableNameIndex = tempAliasName.length > 1 && StringUtils.isNotEmpty(tempAliasName[1]) ? Integer.parseInt(tempAliasName[1]) : 0;
			List<LinkedHashMap<String, Object>> tableNameList = new ArrayList(groupAliasMap.entrySet());
			if(!tableNameList.isEmpty()){
			for(int i=0;i<tableNameList.size();i++){
				Entry<String, Object> groupKeyEntry  = (Entry<String, Object>) tableNameList.get(i);
				if(Objects.nonNull(groupKeyEntry) && groupKeyEntry.getKey().equals(tempTableName[0])){
					List tableAliasList = (List) groupKeyEntry.getValue();
					Entry<String, Object> tempAliasMap = (Entry<String, Object>) tableAliasList.get(tableNameIndex);
					properAliasName =String.valueOf(tempAliasMap.getKey());
					break;
				}
			}
				if(StringUtils.isEmpty(properAliasName)){
					properAliasName = aliasName;
				}
			}else{
				 properAliasName = aliasName;
			}
		}else{
			 properAliasName = aliasName;
		}
		return properAliasName;
		}catch(Exception exp){
			exp.printStackTrace();
			logger.error("Exception occured in getLangAliasToNormalAlias method" + exp.getMessage());
			throw new CustomException(exp);
		}
	}
	
	
	
	/**
	 * formGroupByColumns is check form group by columns
	 * @param plainSelect
	 * @param column
	 */
	private void formGroupByColumns(PlainSelect plainSelect, Column column) {
		logger.debug("formGroupByColumns method started"+column);
		if(Objects.nonNull(plainSelect.getGroupBy())){
			GroupByElement groupByElement = plainSelect.getGroupBy();
			    List groupByList = groupByElement.getGroupByExpressions();
			    if(!groupByList.isEmpty()){
			    	groupByList.add(column);
			    }else{
			    	groupByElement.addGroupByExpression(column);
			    }
		}else{
			GroupByElement groupByElement = new GroupByElement();
			groupByElement.addGroupByExpression(column);
			plainSelect.setGroupByElement(groupByElement);
		}
		logger.debug("formGroupByColumns method ended"+column);
	}
	
	
	
	/**
	 * changeLangGroupColumn is check for lang group column
	 * @param plainSelect
	 * @param tableAliasName
	 * @param columnName
	 */
	private void changeLangGroupColumn(PlainSelect plainSelect, String tableAliasName,String columnName) {
		logger.debug("changeLangGroupColumn method started"+columnName);
		if(Objects.nonNull(plainSelect.getGroupBy())){
			GroupByElement groupByElement = plainSelect.getGroupBy();
			    List<Expression> groupByList = groupByElement.getGroupByExpressions();
			    for (Expression groupByColumn:groupByList) {
			    	Column grpColumn = (Column) groupByColumn;
			    	if(Objects.nonNull(grpColumn.getTable())){
			    	String aliasName = Objects.nonNull(grpColumn.getTable().getAlias()) ? String.valueOf(grpColumn.getTable().getAlias()):Objects.nonNull(grpColumn.getTable()) ? String.valueOf(grpColumn.getTable()) : "";
			    	if(grpColumn.getColumnName().equals(columnName) && StringUtils.equals(tableAliasName,aliasName)){
			    		grpColumn.getTable().setAlias(new Alias(tableAliasName+"_text"));
			    	}
				}
			    }
		}
		logger.debug("changeLangGroupColumn method ended"+columnName);
	}
	
	
	/**
	 * changeLangGroupColumn is check for lang group column
	 * @param plainSelect
	 * @param tableAliasName
	 * @param columnName
	 */
	private boolean checkForAggregateFunction(Map<String,Object> expressionColumnMap) {
		logger.debug("checkForAggregateFunction method started"+expressionColumnMap);
		List<String> aggregateFunctionList = Arrays.asList("array_agg","avg","bit_and","bit_or","bool_and","bool_or","count","every","json_agg","jsonb_agg",
				         "json_object_agg","jsonb_object_agg","max","min","string_agg","sum","xmlagg");
		boolean isAggregate = false;
		if(!expressionColumnMap.isEmpty()){
		for (Entry<String, Object> expression : expressionColumnMap.entrySet()) {
			if(aggregateFunctionList.contains(String.valueOf(expression.getValue()))){
				isAggregate = true;
				break;
			}
		}
		}else{
			isAggregate = false;
		}
		logger.debug("checkForAggregateFunction method ended"+isAggregate);
		return isAggregate;
		
	}


	
	
	/**
	 * formExpressionColumns is check for lang group column
	 * @param paramMap
	 * @throws CustomException 
	 */
	private void formExpressionColumns(Map<String,Object> paramMap) throws CustomException {	
	logger.debug("formExpressionColumns method started");
	try {
	List<Map<String,Object>> columnDetailList = new ArrayList<>();
	if(Objects.nonNull(paramMap.get("expressionColumnDetailsMap"))){
	logger.debug("expressionColumnDetailsMap map is not empty");
	Map<String,Object> expressionColumnDetailsMap = (Map<String, Object>) paramMap.get("expressionColumnDetailsMap");
	Map<String,Object> tableAliasMap=(Map<String, Object>) paramMap.get("tableAliasMap");
	String viewObject = String.valueOf(paramMap.get("table_object"));
	String productCode = String.valueOf(paramMap.get("product_code"));
	if(!expressionColumnDetailsMap.isEmpty()){
		logger.debug("iterating expression map" + expressionColumnDetailsMap);
	for (Entry<String,Object> aliasEntry :expressionColumnDetailsMap.entrySet()) {
		if( aliasEntry.getValue() instanceof List){
			List<Expression> parameterList = (List<Expression>) aliasEntry.getValue();
			for (Expression expCol : parameterList) {
				if(expCol instanceof Column){
					Map<String,Object> columnDataMap = new HashMap<>();
					columnDataMap.put(bindTableWithColumn("view_object_name"), viewObject);
					columnDataMap.put(bindTableWithColumn("product_code"), productCode);
					columnDataMap.put(bindTableWithColumn("data_element"), "");
						String columnName = Objects.nonNull(((Column) expCol).getColumnName()) && !StringUtils.isEmpty(((Column) expCol).getColumnName()) ? ((Column) expCol).getColumnName() : "";
						String tableAliasName = Objects.nonNull(((Column) expCol).getTable())  ? ((Column) expCol).getTable().toString() : "";
						String tableName =!StringUtils.isEmpty(tableAliasName) && tableAliasMap.containsKey(tableAliasName) ? String.valueOf(tableAliasMap.get(tableAliasName)) :"";
						if(StringUtils.isEmpty(tableName)){
							if(Objects.nonNull(tableAliasName) && tableAliasName.endsWith("_text")){
								columnDataMap.put(bindTableWithColumn("column_name"), columnName);
								columnDataMap.put(bindTableWithColumn("table_name"), tableAliasName);
							}else{
							Map<String,String> columnTableMap = new HashMap<>();
							columnTableMap = getProperTableName(columnName,paramMap,tableAliasMap,columnTableMap);
							if(Objects.nonNull(columnTableMap) && !columnTableMap.isEmpty()){
							columnDataMap.put(bindTableWithColumn("column_name"), columnTableMap.get("columnName"));
							columnDataMap.put(bindTableWithColumn("table_name"), columnTableMap.get("tableName"));
							}else{
								columnDataMap.put(bindTableWithColumn("column_name"), columnName);
								columnDataMap.put(bindTableWithColumn("table_name"), tableAliasName);
							}
							}
						}else{
							columnDataMap.put(bindTableWithColumn("column_name"), columnName);
							columnDataMap.put(bindTableWithColumn("table_name"), tableName);
						}
						columnDataMap.put(bindTableWithColumn("table_alias_name"),  tableAliasName);
						columnDetailList.add(columnDataMap);
				}
			}
		}		
	}
	}
	}
	paramMap.put("expColumnDetailsData", columnDetailList);
	}catch(Exception exp) {
		throw new CustomException(exp);
	}
	logger.debug("formExpressionColumns method ended");
	}
	
	
	/**
	 * @param langJoinData
	 * @param configDataMap
	 * @param columnDetailsData
	 * @param productCode 
	 * @param plainSelect 
	 * @param isGroupBy 
	 * @return
	 * @throws CustomException 
	 */
public String checkForTenantColumns(String langJoinData,
	Map<String, Object> configDataMap, List<Map<String, Object>> columnDetailsData,
	String productCode, PlainSelect plainSelect, boolean isGroupBy) throws CustomException {
logger.debug("checkForTenantColumns method started" + langJoinData);
try{
	String tenantAddableQuery = plainSelect.toString();
	logger.debug("checkForTenantColumns after  lowercase" + tenantAddableQuery);
boolean isTenantPresent = columnDetailsData.stream().filter(predicate -> 
StringUtils.equals(String.valueOf(predicate.get(bindTableWithColumn("alias_name"))),"tenant_id")).findAny().isPresent();
String tenantAddedQuery = "";
QueryValidation queryValidator =  new QueryValidation();
if (!isTenantPresent) {
//	List<String> tempTenantList = productCode.stream().map(map-> Objects.toString(map.get("table_name"))).collect(Collectors.toList());
	String alias = "";
	for (Entry<String,Object> entity : configDataMap.entrySet()) {
		Map<String, Object> retrunValueMap = queryValidator.getTableDetails(Objects.toString(entity.getValue()),productCode);
		Boolean isTenant = Boolean.valueOf(String.valueOf(retrunValueMap.get("isTenant")));
		if(isTenant) {
		alias = entity.getKey();
			break;
		}			
	}
	if(isGroupBy){
	Column tenantCol = new Column();
	tenantCol.setTable(new Table(alias));
	tenantCol.setColumnName("tenant_id");
		if(Objects.nonNull(plainSelect.getGroupBy())){
			GroupByElement groupByElement = plainSelect.getGroupBy();
			    List groupByList = groupByElement.getGroupByExpressions();
			    if(!groupByList.isEmpty()){
			    	groupByList.add(tenantCol);
			    }else{
			    	groupByElement.addGroupByExpression(tenantCol);
			    }
		}else{
			GroupByElement groupByElement = new GroupByElement();
			groupByElement.addGroupByExpression(tenantCol);
			plainSelect.setGroupByElement(groupByElement);
		}
	}
		tenantAddableQuery = plainSelect.toString();
	if(!StringUtils.isEmpty(alias)){
		List<SelectItem> selectitems=plainSelect.getSelectItems();
		Column col = new Column();
		col.setColumnName("tenant_id");
		col.setTable(new Table(alias));
		SelectExpressionItem sel = new SelectExpressionItem(col);
		sel.setAlias(new Alias("tenant_id"));
		selectitems.add(sel);
		logger.debug("checkForTenantColumns tenanttable alias" + alias);
	    tenantAddedQuery = plainSelect.toString();
	}else{
		tenantAddedQuery = tenantAddableQuery;
	}
} else {
	tenantAddedQuery = tenantAddableQuery;
}
return tenantAddedQuery;
}catch(Exception e){
	logger.debug("checkForTenantColumns method ended with exception" + e.getMessage());
	throw new CustomException(e);
}

}


/**
 * @param QueryExecutor
 * @param keySets
 * @return
 * @throws CustomException 
 */
public List<Map<String, Object>> checkForTenantExists(QueryExecutor queryExecutor,List<String> keySets) throws CustomException{
	List<Map<String,Object>> tenantDataList = new ArrayList<>();
	 try {
		 tenantDataList= queryExecutor.queryBuilder().select().from("table_definition").where(ConditionBuilder.instance().in("table_name", keySets.toArray()).and().eq("tenant_id_flag", true)).build(true).execute();
	} catch (Exception exception) {
		throw new CustomException(exception);
	}
	 return tenantDataList;
 }

/**
 * @param objectData
 * @return
 */
private String bindTableWithColumn(String columnName) {
	return ViewObjectConstants.VIEW_OBJECT_COLUMN_DETAILS+"."+columnName;
}


public String deparseQueryWithProduct(String productCode, String query, Map<String, Object> paramMap) throws CustomException {
	try {
		if (query.trim().toLowerCase().startsWith("select")) {
			Select select;
			select = (Select) CCJSqlParserUtil.parse(query);

			StringBuilder buffer = new StringBuilder();
			ExpressionDeParser expressionDeParser = new ExpressionDeParser();
			SelectDeParser deparser = new SelectDeParser(expressionDeParser, buffer) {
				@Override
				public void visit(Table tableName) {
					if(paramMap.containsKey("removeTableList") && Objects.nonNull(paramMap.get("removeTableList") )) {
						List<String> removeTableList = (List<String>) paramMap.get("removeTableList");
						if(Objects.nonNull(tableName.getAlias())){
							if(removeTableList.contains(tableName.getName())) {
								getBuffer().append(tableName.getName()).append(" as ").append(tableName.getAlias().getName());
							}else {
								getBuffer().append(productCode+"_").append(tableName.getName()).append(" as ").append(tableName.getAlias().getName());
							}
						}else {
							if(removeTableList.contains(tableName.getName())) {
								getBuffer().append(tableName.getName());
							}else {
								getBuffer().append(productCode+"_").append(tableName.getName());
							}
						}
					}else {
						if(Objects.nonNull(tableName.getAlias())){
								getBuffer().append(productCode+"_"+tableName.getName()).append(" as ").append(tableName.getAlias().getName());
						}else {
								getBuffer().append(productCode+"_").append(tableName.getName());
						}
					}
				}
			};
			expressionDeParser.setSelectVisitor(deparser);
			expressionDeParser.setBuffer(buffer);
			select.getSelectBody().accept(deparser);
			return buffer.toString();
		} else if (query.trim().toLowerCase().startsWith("with")) {
			Select select;
			select = (Select) CCJSqlParserUtil.parse(query);
			List<String> removeTableNameList = removeTableName(select);
			List<WithItem> withItemList = select.getWithItemsList();
			SelectBody selectBody = withItemList.get(0).getSelectBody();
			String newQuery = recursiveDeparseQuery(productCode, selectBody.toString(), removeTableNameList);
			SelectBody selectBodyNew = getSelectBody(newQuery);
			withItemList.get(0).setSelectBody(selectBodyNew);
			select.setWithItemsList(withItemList);
			return select.toString();
		}
	} catch (Exception exp) {
		throw new CustomException(exp);
	}
	return query;
}

/**
 * Gets the select body.
 *
 * @param query the query
 * @return the select body
 * @throws JSQLParserException the JSQL parser exception
 */
private SelectBody getSelectBody(String query) throws JSQLParserException {
	Select select;
	select = (Select)CCJSqlParserUtil.parse(query);
	return select.getSelectBody();
}


/**
 * Removes the table name.
 *
 * @param select the select
 * @return the list
 */
private List<String> removeTableName(Select select) {
	StringBuilder buffer = new StringBuilder();
	ExpressionDeParser expressionDeParser = new ExpressionDeParser();
	List<String> removeTableNameList = new ArrayList<>();
	SelectDeParser deparser = new SelectDeParser(expressionDeParser,buffer ) {
		@Override
		public void visit(Table tableName) {
			if(Objects.nonNull(tableName.getAlias())){
				getBuffer().append(tableName.getName()).append(" as ").append(tableName.getAlias().getName());
				removeTableNameList.add(tableName.getName());
			}else {
				getBuffer().append(tableName.getName());
				removeTableNameList.add(tableName.getName());
			}
		}
	};
	expressionDeParser.setSelectVisitor(deparser);
	expressionDeParser.setBuffer(buffer);
	select.getSelectBody().accept(deparser);
	return removeTableNameList;
}

/**
 * Recursive deparse query.
 *
 * @param requestParamEntity the request param entity
 * @param query the query
 * @param removeTableNameList the remove table name list
 * @return the string
 * @throws CustomException the custom exception
 * @throws JSQLParserException the JSQL parser exception
 */
public String recursiveDeparseQuery(String productCode,String query,List<String> removeTableNameList) throws JSQLParserException {
	if(query.trim().toLowerCase().startsWith("select")) {
		Select select;
		select = (Select)CCJSqlParserUtil.parse(query);
		StringBuilder buffer = new StringBuilder();
		ExpressionDeParser expressionDeParser = new ExpressionDeParser();

		SelectDeParser deparser = new SelectDeParser(expressionDeParser,buffer ) {
			@Override
			public void visit(Table tableName) {
				if(Objects.nonNull(tableName.getAlias())){
					if(removeTableNameList.contains(tableName.getName())) {
						getBuffer().append(tableName.getName()).append(" as ").append(tableName.getAlias().getName());
					}else {
						getBuffer().append(productCode+"_").append(tableName.getName()).append(" as ").append(tableName.getAlias().getName());
					}
				}else {
					if(removeTableNameList.contains(tableName.getName())) {
						getBuffer().append(tableName.getName());
					}else {
						getBuffer().append(productCode+"_").append(tableName.getName());
					}
				}
			}
		};
		expressionDeParser.setSelectVisitor(deparser);
		expressionDeParser.setBuffer(buffer);
		select.getSelectBody().accept(deparser);

		return buffer.toString();
	}
	return query;
}


/**
 * @param langJoinData
 * @param tableAliasMap
 * @param columnDetailsData
 * @param productCode 
 * @param plainSelect 
 * @param isGroupBy 
 * @return
 * @throws CustomException 
 */
public String checkForEncryptKey(String langJoinData,
Map<String, Object> tableAliasMap, List<Map<String, Object>> columnDetailsData,
String productCode, PlainSelect plainSelect, boolean isGroupBy) throws CustomException {
logger.debug("checkForEncryptKey method started" + langJoinData);
try{
String tenantAddableQuery = plainSelect.toString();
String tenantAddedQuery = "";
QueryValidation queryValidator =  new QueryValidation();
List<SelectItem> encryptColumns = new ArrayList<>();
String alias = "";
for (Entry<String,Object> entity : tableAliasMap.entrySet()) {
	Map<String, Object> retrunValueMap = queryValidator.getTableDetails(Objects.toString(entity.getValue()),productCode);
	Boolean isEncrypt = Boolean.valueOf(String.valueOf(retrunValueMap.get("dataEncryptionFlag")));
	Map<String, Object> tableEncryptMap = (Map<String, Object>)retrunValueMap.get("tableEncryptMap");
	alias = entity.getKey();
	if(isEncrypt) {
	if(isGroupBy){
		Column encryptCol = new Column();
		encryptCol.setTable(new Table(alias));
		encryptCol.setColumnName("encrypt___key");
		if(Objects.nonNull(plainSelect.getGroupBy())){
			GroupByElement groupByElement = plainSelect.getGroupBy();
			List groupByList = groupByElement.getGroupByExpressions();
			if(!groupByList.isEmpty()){
				groupByList.add(encryptCol);
			}else{
				groupByElement.addGroupByExpression(encryptCol);
			}
		}else{
			GroupByElement groupByElement = new GroupByElement();
			groupByElement.addGroupByExpression(encryptCol);
			plainSelect.setGroupByElement(groupByElement);
		}
	}
	Column col = new Column();
	col.setColumnName("encrypt___key");
	col.setTable(new Table(alias));
	SelectExpressionItem sel = new SelectExpressionItem(col);
	sel.setAlias(new Alias(alias+"_encrypt___key"));
	encryptColumns.add(sel);
	}else if(Objects.nonNull(tableEncryptMap) && !tableEncryptMap.isEmpty()) {
		for (Entry<String,Object> encryptEntity : tableEncryptMap.entrySet()) {
			if(!StringUtils.isEmpty(encryptEntity.getKey())) {
				if(isGroupBy){
					Column encryptCol = new Column();
					encryptCol.setTable(new Table(alias));
					encryptCol.setColumnName(Objects.toString(encryptEntity.getValue()));
					if(Objects.nonNull(plainSelect.getGroupBy())){
						GroupByElement groupByElement = plainSelect.getGroupBy();
						List groupByList = groupByElement.getGroupByExpressions();
						if(!groupByList.isEmpty()){
							groupByList.add(encryptCol);
						}else{
							groupByElement.addGroupByExpression(encryptCol);
						}
					}else{
						GroupByElement groupByElement = new GroupByElement();
						groupByElement.addGroupByExpression(encryptCol);
						plainSelect.setGroupByElement(groupByElement);
					}
				}
				Column col = new Column();
				col.setColumnName(Objects.toString(encryptEntity.getValue()));
				col.setTable(new Table(alias));
				SelectExpressionItem sel = new SelectExpressionItem(col);
				sel.setAlias(new Alias(alias+"_"+Objects.toString(encryptEntity.getValue())));
				encryptColumns.add(sel);
			}
		}
		
	}
}
	tenantAddableQuery = plainSelect.toString();
	logger.debug("checkForEncryptKey tenanttable alias" + alias);
if(!encryptColumns.isEmpty()){
	List<SelectItem> selectitems=plainSelect.getSelectItems();
	selectitems.addAll(encryptColumns);
	logger.debug("checkForEncryptKey after appending encrypt columns" + selectitems);
    tenantAddedQuery = plainSelect.toString();
}else{
	tenantAddedQuery = tenantAddableQuery;
}
return tenantAddedQuery;
}catch(Exception e){
logger.debug("checkForTenantColumns method ended with exception" + e.getMessage());
throw new CustomException(e);
}

}



}
