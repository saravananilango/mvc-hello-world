package com.nn.sova.service.utils.tabledefinition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.changerequest.ChangeRequest;
import com.nn.sova.changerequest.ChangeRequestFromEnum;
import com.nn.sova.service.constants.tabledefinition.DataDefinitionConstants;
import com.nn.sova.service.constants.tabledefinition.MessageEntriesConstants;
import com.nn.sova.service.constants.tabledefinition.TableDefinitionConstants;
import com.nn.sova.service.enums.TableTypeEnum;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.UpdateQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.cache.CacheGetServiceImpl;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * DataDefinitionCommonUtils is common class for data definition manipulations
 * 
 * @author Sakthivel
 */
public class DataDefinitionCommonUtils {

	private static ApplicationLogger logger = ApplicationLogger.create(DataDefinitionCommonUtils.class);

	/**
	 * activateData used migrate the data from meta table to their corresponding
	 * table
	 * 
	 * @param primaryKeyList
	 * @param tableName
	 * @param dataFormatMap
	 * @param versionMap
	 * @param changeRequestDetails
	 * @throws CustomException
	 */
	public static void activateData(List<Object> primaryKeyList, String tableName, Map<String, Object> dataFormatMap,
			Map<String, String> versionMap, Map<String, Object> changeRequestDetails) throws CustomException {
		logger.info("activateData method starts...");
		switch (tableName) {
		case "charsetDefinition":
			activateCharsetDefinition(primaryKeyList, versionMap, changeRequestDetails);
			break;
		case "dataFormatDefinition":
			activateDataClassDefinition(primaryKeyList, dataFormatMap, versionMap, changeRequestDetails);
			break;
		case "dataElementDefinition":
			activateDataElementDefinition(primaryKeyList, versionMap, changeRequestDetails);
			break;
		case "masterDefinition":
			activateMasterDefinition(primaryKeyList, versionMap, changeRequestDetails);
			break;
		default:
			break;
		}
		logger.info("activateData method ends...");
	}

	/**
	 * activateDataElementDefinition used to migrate the data element
	 * 
	 * @param primaryKeyList
	 * @param versionMap
	 * @param changeRequestDetails
	 * @throws CustomException
	 */
	private static void activateDataElementDefinition(List<Object> primaryKeyList, Map<String, String> versionMap,
			Map<String, Object> changeRequestDetails) throws CustomException {
		logger.info("activateDataElementDefinition method starts...");
		Map<String, Object> tablesMap = new HashMap<>();
		QueryBuilder queryBuilder = new QueryBuilder();
		QueryExecutor queryExecutor = null;
		try {
			queryExecutor = queryBuilder.getQueryExecutor();
			List<Map<String, Object>> dataElementDataList = getDataElementDataList(primaryKeyList, queryExecutor);
			dataElementDataList = processDataElementDataList(dataElementDataList);
			String versionNumber = dataElementDataList.stream().findFirst().get()
					.get("data_element_definition.version_no").toString();
			if (versionMap.containsKey(versionNumber)) {
				String changeRequestId = versionMap.get(versionNumber);
				queryExecutor.setChangeRequestId(changeRequestId);
			} else {
				changeRequestDetails.put("versionNumber", versionNumber);
				setChangeRequestDetails(queryExecutor, changeRequestDetails);
			}
			queryExecutor.queryBuilder().insert().lang(true).skipTenantId(true).upsertWithKeyList(
					DataDefinitionConstants.DATA_ELEMENT_DEFINITION, dataElementDataList, true,
					DataDefinitionConstants.DATA_ELEMENT_DEFINITION_COLUMNS,
					DataDefinitionConstants.DATA_ELEMENT_DEFINITION_PRIMARY_CONSTRAINTS);
			queryExecutor.queryBuilder().delete().lang(true).skipTenantId(true)
					.from(DataDefinitionConstants.DATA_ELEMENT_DEFINITION_OFFLINE)
					.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_ELEMENT, primaryKeyList))
					.build().execute();
			queryExecutor.commit();
			if (!queryExecutor.getChangeRequestId().isBlank()) {
				String changeRequestId = queryExecutor.getChangeRequestId();
				tablesMap.put(TableDefinitionConstants.OFFLINE_DATA_ELEMENT_LIST, primaryKeyList);
				TableDefinitionUtils.updateChangeRequestForDataDefinitionTables(changeRequestId, tablesMap);
				versionMap.put(versionNumber, changeRequestId);
			}
		} catch (Exception exception) {
			executeRollback(queryExecutor);
			logger.error("Exception in activating data element data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateDataElementDefinition method ends...");
	}

	/**
	 * getDataElementDataList used to data element list.
	 * 
	 * @param primaryKeyList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	private static List<Map<String, Object>> getDataElementDataList(List<Object> primaryKeyList,
			QueryExecutor queryExecutor) throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true)
				.getWithAliasName("data_element", "data_element_definition.data_element")
				.getWithAliasName("auto_flag", "data_element_definition.auto_flag")
				.getWithAliasName("data_format", "data_element_definition.data_format")
				.getWithAliasName("description", "data_element_definition.description")
				.getWithAliasName("locale", "data_element_definition.locale")
				.getWithAliasName("short_text", "data_element_definition.short_text")
				.getWithAliasName("long_text", "data_element_definition.long_text")
				.getWithAliasName("hint_text", "data_element_definition.hint_text")
				.getWithAliasName("example_text", "data_element_definition.example_text")
				.getWithAliasName("medium_text", "data_element_definition.medium_text")
				.getWithAliasName("version_no", "data_element_definition.version_no")
				.getWithAliasName("product_code", "data_element_definition.product_code")
				.getWithAliasName("created_at", "data_element_definition.created_at")
				.getWithAliasName("created_by", "data_element_definition.created_by")
				.getWithAliasName("previous_request_id", "data_element_definition.previous_request_id")
				.getWithAliasName("auto_flag", "data_element_definition.auto_flag")
				.getWithAliasName("active_flag", "data_element_definition.active_flag")
				.getWithAliasName("locked_flag", "data_element_definition.locked_flag")
				.getWithAliasName("tenant_id", "data_element_definition.tenant_id")
				.getWithAliasName("sample_data", "data_element_definition.sample_data")
				.getWithAliasName("help_code", "data_element_definition.help_code")
				.getWithAliasName("component_name", "data_element_definition.component_name")
				.from(DataDefinitionConstants.DATA_ELEMENT_DEFINITION_OFFLINE)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_ELEMENT, primaryKeyList))
				.skipLanguage(true).lang(true).build(false).execute();
	}
	/**
	 * getDataElementDataList used to data element list.
	 * 
	 * @param primaryKeyList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	public static List<Map<String, Object>> getDataElementDataListMain(List<Object> primaryKeyList,
			QueryExecutor queryExecutor) throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true)
				.getWithAliasName("data_element", "data_element_definition.data_element")
				.getWithAliasName("auto_flag", "data_element_definition.auto_flag")
				.getWithAliasName("data_format", "data_element_definition.data_format")
				.getWithAliasName("description", "data_element_definition.description")
				.getWithAliasName("locale", "data_element_definition.locale")
				.getWithAliasName("short_text", "data_element_definition.short_text")
				.getWithAliasName("long_text", "data_element_definition.long_text")
				.getWithAliasName("hint_text", "data_element_definition.hint_text")
				.getWithAliasName("example_text", "data_element_definition.example_text")
				.getWithAliasName("medium_text", "data_element_definition.medium_text")
				.getWithAliasName("version_no", "data_element_definition.version_no")
				.getWithAliasName("product_code", "data_element_definition.product_code")
				.getWithAliasName("created_at", "data_element_definition.created_at")
				.getWithAliasName("created_by", "data_element_definition.created_by")
				.getWithAliasName("previous_request_id", "data_element_definition.previous_request_id")
				.getWithAliasName("auto_flag", "data_element_definition.auto_flag")
				.getWithAliasName("active_flag", "data_element_definition.active_flag")
				.getWithAliasName("locked_flag", "data_element_definition.locked_flag")
				.getWithAliasName("tenant_id", "data_element_definition.tenant_id")
				.getWithAliasName("sample_data", "data_element_definition.sample_data")
				.getWithAliasName("help_code", "data_element_definition.help_code")
				.from(DataDefinitionConstants.DATA_ELEMENT_DEFINITION)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_ELEMENT, primaryKeyList))
				.skipLanguage(true).lang(true).build(false).execute();
	}

	/**
	 * processDataElementDataList used to prepare data element list.
	 * 
	 * @param dataElementDataList
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public static List<Map<String, Object>> processDataElementDataList(List<Map<String, Object>> dataElementDataList) {
		logger.info("processDataElementDataList method starts...");
		List<Map<String, Object>> dataList = new ArrayList<>();
		Map<Object, List<Map<String, Object>>> groupedData = dataElementDataList.stream().collect(Collectors
				.groupingBy(action -> action.get("data_element_definition." + DataDefinitionConstants.DATA_ELEMENT)));
		List<String> localeColumnList = Arrays.asList("data_element_definition.short_text",
				"data_element_definition.long_text", "data_element_definition.hint_text",
				"data_element_definition.example_text", "data_element_definition.medium_text");
		groupedData.entrySet().stream().forEach(action -> {
			Map<String, Object> dataMap = new HashMap<>();
			List<Map<String, Object>> valueList = action.getValue();
			valueList.stream().forEach(item -> {
				item.entrySet().stream().forEach(data -> {
					if (localeColumnList.contains(data.getKey())) {
						Map<String, Object> localeMap = new HashMap<>();
						if (dataMap.containsKey(data.getKey())) {
							localeMap = (Map<String, Object>) dataMap.get(data.getKey());
						}
						localeMap.put(item.get("data_element_definition.locale").toString(), data.getValue());
						dataMap.put(data.getKey(), localeMap);
					} else if (!"data_element_definition.locale".equals(data.getKey())) {
						dataMap.put(data.getKey(), data.getValue());
					}
				});
			});
			dataList.add(dataMap);
		});
		logger.info("processDataElementDataList method ends...");
		return dataList;
	}

	/**
	 * activateDataClassDefinition used to migrate the data class
	 * 
	 * @param primaryKeyList
	 * @param dataFormatMap
	 * @param versionMap
	 * @param changeRequestDetails
	 * @throws CustomException
	 */
	@SuppressWarnings("unchecked")
	private static void activateDataClassDefinition(List<Object> primaryKeyList, Map<String, Object> dataFormatMap,
			Map<String, String> versionMap, Map<String, Object> changeRequestDetails) throws CustomException {
		logger.info("activateDataClassDefinition method starts...");
		Map<String, Object> tablesMap = new HashMap<>();
		QueryBuilder queryBuilder = new QueryBuilder();
		QueryExecutor queryExecutor = null;
		try {
			queryExecutor = queryBuilder.getQueryExecutor();
			List<Map<String, Object>> dataFormatList = getDataFormatList(primaryKeyList, queryExecutor);
			String versionNumber = dataFormatList.stream().findFirst().get().get("data_format_definition.version_no")
					.toString();
			if (versionMap.containsKey(versionNumber)) {
				String changeRequestId = versionMap.get(versionNumber);
				queryExecutor.setChangeRequestId(changeRequestId);
			} else {
				changeRequestDetails.put("versionNumber", versionNumber);
				setChangeRequestDetails(queryExecutor, changeRequestDetails);
			}
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.DATA_FORMAT_DEFINITION,
					dataFormatList, true, DataDefinitionConstants.DATA_FORMAT_DEFINITION_COLUMNS,
					DataDefinitionConstants.DATA_FORMAT_DEFINITION_OFFLINE_PRIMARY_CONSTRAINTS);
			processDataClassList(dataFormatList, queryExecutor, dataFormatMap);
			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.DATA_FORMAT_DEFINITION_OFFLINE)
					.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_FORMAT, primaryKeyList))
					.build().execute();
			queryExecutor.commit();
			if (!queryExecutor.getChangeRequestId().isBlank()) {
				String changeRequestId = queryExecutor.getChangeRequestId();
				tablesMap.put(TableDefinitionConstants.OFFLINE_DATA_FORMAT_LIST, primaryKeyList);
				TableDefinitionUtils.updateChangeRequestForDataDefinitionTables(changeRequestId, tablesMap);
				versionMap.put(versionNumber, changeRequestId);
			}
			if (dataFormatMap.containsKey(DataDefinitionConstants.MASTER)) {
				List<Object> masterIdList = (List<Object>) dataFormatMap.get(DataDefinitionConstants.MASTER);
				activateMasterDefinition(masterIdList, versionMap, changeRequestDetails);
			}
		} catch (Exception exception) {
			executeRollback(queryExecutor);
			logger.error("Exception in activating data class data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateDataClassDefinition method ends...");
	}

	/**
	 * getDataFormatList used to get data class list.
	 * 
	 * @param primaryKeyList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	private static List<Map<String, Object>> getDataFormatList(List<Object> primaryKeyList, QueryExecutor queryExecutor)
			throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true)
				.getWithAliasName("data_format", "data_format_definition.data_format")
				.getWithAliasName("charset_id", "data_format_definition.charset_id")
				.getWithAliasName("auto_flag", "data_format_definition.auto_flag")
				.getWithAliasName("min_length", "data_format_definition.min_length")
				.getWithAliasName("max_length", "data_format_definition.max_length")
				.getWithAliasName("data_type", "data_format_definition.data_type")
				.getWithAliasName("element_type", "data_format_definition.element_type")
				.getWithAliasName("min_value", "data_format_definition.min_value")
				.getWithAliasName("max_value", "data_format_definition.max_value")
				.getWithAliasName("max_decimal", "data_format_definition.max_decimal")
				.getWithAliasName("precision", "data_format_definition.precision")
				.getWithAliasName("regex_pattern", "data_format_definition.regex_pattern")
				.getWithAliasName("input_method", "data_format_definition.input_method")
				.getWithAliasName("password_flag", "data_format_definition.password_flag")
				.getWithAliasName("max_date", "data_format_definition.max_date")
				.getWithAliasName("min_date", "data_format_definition.min_date")
				.getWithAliasName("default_value", "data_format_definition.default_value")
				.getWithAliasName("master_id", "data_format_definition.master_id")
				.getWithAliasName("data_range", "data_format_definition.data_range")
				.getWithAliasName("in_condition", "data_format_definition.in_condition")
				.getWithAliasName("not_in_condition", "data_format_definition.not_in_condition")
				.getWithAliasName("version_no", "data_format_definition.version_no")
				.getWithAliasName("product_code", "data_format_definition.product_code")
				.getWithAliasName("created_at", "data_format_definition.created_at")
				.getWithAliasName("created_by", "data_format_definition.created_by")
				.getWithAliasName("previous_request_id", "data_format_definition.previous_request_id")
				.getWithAliasName("auto_flag", "data_format_definition.auto_flag")
				.getWithAliasName("active_flag", "data_format_definition.active_flag")
				.getWithAliasName("locked_flag", "data_format_definition.locked_flag")
				.getWithAliasName("tenant_id", "data_format_definition.tenant_id")
				.from(DataDefinitionConstants.DATA_FORMAT_DEFINITION_OFFLINE)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_FORMAT, primaryKeyList))
				.build(false).execute();
	}
	/**
	 * getDataFormatList used to get data class list.
	 * 
	 * @param primaryKeyList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	public static List<Map<String, Object>> getDataFormatListMain(List<Object> primaryKeyList, QueryExecutor queryExecutor)
			throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true)
				.getWithAliasName("data_format", "data_format_definition.data_format")
				.getWithAliasName("charset_id", "data_format_definition.charset_id")
				.getWithAliasName("auto_flag", "data_format_definition.auto_flag")
				.getWithAliasName("min_length", "data_format_definition.min_length")
				.getWithAliasName("max_length", "data_format_definition.max_length")
				.getWithAliasName("data_type", "data_format_definition.data_type")
				.getWithAliasName("element_type", "data_format_definition.element_type")
				.getWithAliasName("min_value", "data_format_definition.min_value")
				.getWithAliasName("max_value", "data_format_definition.max_value")
				.getWithAliasName("max_decimal", "data_format_definition.max_decimal")
				.getWithAliasName("precision", "data_format_definition.precision")
				.getWithAliasName("regex_pattern", "data_format_definition.regex_pattern")
				.getWithAliasName("input_method", "data_format_definition.input_method")
				.getWithAliasName("password_flag", "data_format_definition.password_flag")
				.getWithAliasName("max_date", "data_format_definition.max_date")
				.getWithAliasName("min_date", "data_format_definition.min_date")
				.getWithAliasName("default_value", "data_format_definition.default_value")
				.getWithAliasName("master_id", "data_format_definition.master_id")
				.getWithAliasName("data_range", "data_format_definition.data_range")
				.getWithAliasName("in_condition", "data_format_definition.in_condition")
				.getWithAliasName("not_in_condition", "data_format_definition.not_in_condition")
				.getWithAliasName("version_no", "data_format_definition.version_no")
				.getWithAliasName("product_code", "data_format_definition.product_code")
				.getWithAliasName("created_at", "data_format_definition.created_at")
				.getWithAliasName("created_by", "data_format_definition.created_by")
				.getWithAliasName("previous_request_id", "data_format_definition.previous_request_id")
				.getWithAliasName("auto_flag", "data_format_definition.auto_flag")
				.getWithAliasName("active_flag", "data_format_definition.active_flag")
				.getWithAliasName("locked_flag", "data_format_definition.locked_flag")
				.getWithAliasName("tenant_id", "data_format_definition.tenant_id")
				.from(DataDefinitionConstants.DATA_FORMAT_DEFINITION)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_FORMAT, primaryKeyList))
				.build(false).execute();
	}

	/**
	 * processDataClassList used to segregate the data class list based on element
	 * type
	 * 
	 * @param dataFormatList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	private static void processDataClassList(List<Map<String, Object>> dataFormatList, QueryExecutor queryExecutor,
			Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("processDataClassList method starts...");
		Map<Object, List<Map<String, Object>>> groupedData = dataFormatList.stream().collect(Collectors
				.groupingBy(action -> action.get("data_format_definition." + DataDefinitionConstants.ELEMENT_TYPE)));
		if (groupedData.containsKey(DataDefinitionConstants.MASTER)
				&& CollectionUtils.isNotEmpty(groupedData.get(DataDefinitionConstants.MASTER))) {
			List<Map<String, Object>> masterList = groupedData.get(DataDefinitionConstants.MASTER);
			List<Object> masterIdList = masterList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.MASTER_ID))
					.collect(Collectors.toList());
			dataFormatMap.put(DataDefinitionConstants.MASTER, masterIdList);
		}
		if (groupedData.containsKey(DataDefinitionConstants.DIVISION)
				&& CollectionUtils.isNotEmpty(groupedData.get(DataDefinitionConstants.DIVISION))) {
			List<Map<String, Object>> divisionList = groupedData.get(DataDefinitionConstants.DIVISION);
			activateDivisionDefinition(divisionList, queryExecutor, dataFormatMap);
		}
		if (groupedData.containsKey(DataDefinitionConstants.AUTONUMBER)
				&& CollectionUtils.isNotEmpty(groupedData.get(DataDefinitionConstants.AUTONUMBER))) {
			List<Map<String, Object>> autoNumberList = groupedData.get(DataDefinitionConstants.AUTONUMBER);
			activateAutoNumberMasterDefinition(autoNumberList, queryExecutor, dataFormatMap);
			activateAutoNumberTenantDefinition(autoNumberList, queryExecutor, dataFormatMap);
			deleteAutoNumberData(autoNumberList, queryExecutor);
		}
		logger.info("processDataClassList method ends...");
	}

	/**
	 * deleteAutoNumberData used to delete auto number data after activate.
	 * 
	 * @param autoNumberList
	 * @param queryExecutor
	 * @throws CustomException
	 */
	private static void deleteAutoNumberData(List<Map<String, Object>> autoNumberList, QueryExecutor queryExecutor) throws CustomException {
		logger.info("deleteAutoNumberData method starts...");
		try {
			List<Object> autoNumberDataClass = autoNumberList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.AUTONUMBER_DEFINITION_OFFLINE)
			.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID,
					autoNumberDataClass))
			.build().execute();
		} catch (Exception exception) {
			logger.error("Exception in deleteAutoNumberData " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("deleteAutoNumberData method ends...");
	}

	/**
	 * activateAutoNumberMasterDefinition used to migrate the auto number data
	 * 
	 * @param autoNumberList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	private static void activateAutoNumberMasterDefinition(List<Map<String, Object>> autoNumberList,
			QueryExecutor queryExecutor, Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("activateAutoNumberMasterDefinition method starts...");
		try {
			List<Object> autoNumberDataClass = autoNumberList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
			QueryBuilder queryBuilder = new QueryBuilder();
			List<Map<String, Object>> autoNumberDataList = queryBuilder.select().checkIndependentTenant(true)
					.getWithAliasName("autonumber_def_id", "autonumber_definition.autonumber_def_id")
					.getWithAliasName("reset_cycle", "autonumber_definition.reset_cycle")
					.getWithAliasName("starting_number", "autonumber_definition.starting_number")
					.getWithAliasName("number_of_digits", "autonumber_definition.number_of_digits")
					.getWithAliasName("prefix_text", "autonumber_definition.prefix_text")
					.getWithAliasName("date_format", "autonumber_definition.date_format")
					.getWithAliasName("customer_code_flag", "autonumber_definition.customer_code_flag")
					.getWithAliasName("system_id_flag", "autonumber_definition.system_id_flag")
					.getWithAliasName("separator", "autonumber_definition.separator")
					.getWithAliasName("increment_by", "autonumber_definition.increment_by")
					.getWithAliasName("tenant_dependent", "autonumber_definition.tenant_dependent")
					.getWithAliasName("tenant_id", "autonumber_definition.tenant_id")
					.from(DataDefinitionConstants.AUTONUMBER_DEFINITION_OFFLINE).where(ConditionBuilder.instance()
							.inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID, autoNumberDataClass))
					.build(false).execute();
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.AUTONUMBER_DEFINITION,
					autoNumberDataList, true, DataDefinitionConstants.AUTONUMBER_DEFINITION_COLUMNS,
					DataDefinitionConstants.AUTONUMBER_DEFINITION_PRIMARY_CONSTRAINTS);
			dataFormatMap.put(DataDefinitionConstants.AUTONUMBER, autoNumberDataClass);
		} catch (Exception exception) {
			logger.error("Exception in activating autonumber data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateAutoNumberMasterDefinition method ends...");
	}
	
	/**
	 * activateAutoNumberTenantDefinition used to migrate the auto number data
	 * 
	 * @param autoNumberList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	private static void activateAutoNumberTenantDefinition(List<Map<String, Object>> autoNumberList,
			QueryExecutor queryExecutor, Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("activateAutoNumberTenantDefinition method starts...");
		try {
			List<Object> autoNumberDataClass = autoNumberList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
			QueryBuilder queryBuilder = new QueryBuilder();
			List<Map<String, Object>> autoNumberDataList = queryBuilder.select().checkIndependentTenant(true)
					.getWithAliasName("autonumber_def_id", "autonumber_tenant_definition.autonumber_def_id")
					.getWithAliasName("reset_cycle", "autonumber_tenant_definition.reset_cycle")
					.getWithAliasName("starting_number", "autonumber_tenant_definition.starting_number")
					.getWithAliasName("number_of_digits", "autonumber_tenant_definition.number_of_digits")
					.getWithAliasName("prefix_text", "autonumber_tenant_definition.prefix_text")
					.getWithAliasName("date_format", "autonumber_tenant_definition.date_format")
					.getWithAliasName("customer_code_flag", "autonumber_tenant_definition.customer_code_flag")
					.getWithAliasName("system_id_flag", "autonumber_tenant_definition.system_id_flag")
					.getWithAliasName("separator", "autonumber_tenant_definition.separator")
					.getWithAliasName("increment_by", "autonumber_tenant_definition.increment_by")
					.getWithAliasName("tenant_id", "autonumber_tenant_definition.tenant_id")
					.from(DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_OFFLINE).where(ConditionBuilder.instance()
							.inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID, autoNumberDataClass))
					.build(false).execute();
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION,
					autoNumberDataList, true, DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_COLUMNS,
					DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_PRIMARY_CONSTRAINTS);
			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_OFFLINE)
					.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID,
							autoNumberDataClass))
					.build().execute();
		} catch (Exception exception) {
			logger.error("Exception in activating autonumber data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateAutoNumberMasterDefinition method ends...");
	}
	
	
	/**
	 * activateAutoNumberMasterDefinition used to migrate the auto number data
	 * 
	 * @param autoNumberList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	public static void activateAutoNumberMasterDefinitionMain(List<Map<String, Object>> autoNumberList,
			QueryExecutor queryExecutor, Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("activateAutoNumberMasterDefinition method starts...");
		try {
			List<Object> autoNumberDataClass = autoNumberList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
//			QueryBuilder queryBuilder = new QueryBuilder();
			List<Map<String, Object>> autoNumberDataList = queryExecutor.queryBuilder().select().checkIndependentTenant(true)
					.getWithAliasName("autonumber_def_id", "autonumber_definition.autonumber_def_id")
					.getWithAliasName("reset_cycle", "autonumber_definition.reset_cycle")
					.getWithAliasName("starting_number", "autonumber_definition.starting_number")
					.getWithAliasName("number_of_digits", "autonumber_definition.number_of_digits")
					.getWithAliasName("prefix_text", "autonumber_definition.prefix_text")
					.getWithAliasName("date_format", "autonumber_definition.date_format")
					.getWithAliasName("customer_code_flag", "autonumber_definition.customer_code_flag")
					.getWithAliasName("system_id_flag", "autonumber_definition.system_id_flag")
					.getWithAliasName("separator", "autonumber_definition.separator")
					.getWithAliasName("increment_by", "autonumber_definition.increment_by")
					.getWithAliasName("tenant_dependent", "autonumber_definition.tenant_dependent")
					.getWithAliasName("tenant_id", "autonumber_definition.tenant_id")
					.from(DataDefinitionConstants.AUTONUMBER_DEFINITION).where(ConditionBuilder.instance()
							.inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID, autoNumberDataClass))
					.build(false).execute();
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.AUTONUMBER_DEFINITION,
					autoNumberDataList, true, DataDefinitionConstants.AUTONUMBER_DEFINITION_COLUMNS,
					DataDefinitionConstants.AUTONUMBER_DEFINITION_PRIMARY_CONSTRAINTS);
//			dataFormatMap.put(DataDefinitionConstants.AUTONUMBER, autoNumberDataClass);
		} catch (Exception exception) {
			logger.error("Exception in activating autonumber data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateAutoNumberMasterDefinition method ends...");
	}
	
	/**
	 * activateAutoNumberTenantDefinition used to migrate the auto number data
	 * 
	 * @param autoNumberList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	public static void activateAutoNumberTenantDefinitionMain(List<Map<String, Object>> autoNumberList,
			QueryExecutor queryExecutor, Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("activateAutoNumberTenantDefinition method starts...");
		try {
			List<Object> autoNumberDataClass = autoNumberList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
//			QueryBuilder queryBuilder = new QueryBuilder();
			List<Map<String, Object>> autoNumberDataList = queryExecutor.queryBuilder().select().checkIndependentTenant(true)
					.getWithAliasName("autonumber_def_id", "autonumber_tenant_definition.autonumber_def_id")
					.getWithAliasName("reset_cycle", "autonumber_tenant_definition.reset_cycle")
					.getWithAliasName("starting_number", "autonumber_tenant_definition.starting_number")
					.getWithAliasName("number_of_digits", "autonumber_tenant_definition.number_of_digits")
					.getWithAliasName("prefix_text", "autonumber_tenant_definition.prefix_text")
					.getWithAliasName("date_format", "autonumber_tenant_definition.date_format")
					.getWithAliasName("customer_code_flag", "autonumber_tenant_definition.customer_code_flag")
					.getWithAliasName("system_id_flag", "autonumber_tenant_definition.system_id_flag")
					.getWithAliasName("separator", "autonumber_tenant_definition.separator")
					.getWithAliasName("increment_by", "autonumber_tenant_definition.increment_by")
					.getWithAliasName("tenant_id", "autonumber_tenant_definition.tenant_id")
					.from(DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION).where(ConditionBuilder.instance()
							.inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID, autoNumberDataClass))
					.build(false).execute();
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION,
					autoNumberDataList, true, DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_COLUMNS,
					DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_PRIMARY_CONSTRAINTS);
//			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.AUTONUMBER_TENANT_DEFINITION_OFFLINE)
//					.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.AUTONUMBER_DEF_ID,
//							autoNumberDataClass))
//					.build().execute();
		} catch (Exception exception) {
			logger.error("Exception in activating autonumber data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateAutoNumberMasterDefinition method ends...");
	}

	/**
	 * activateDivisionDefinition used to migrate division data
	 * 
	 * @param divisionList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	private static void activateDivisionDefinition(List<Map<String, Object>> divisionList, QueryExecutor queryExecutor,
			Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("activateDivisionDefinition method starts...");
		try {
			List<Object> divisionDataClass = divisionList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
			QueryBuilder queryBuilder = new QueryBuilder();
			List<Map<String, Object>> divisionDataList = queryBuilder.select().checkIndependentTenant(true)
					.getWithAliasName("data_format", "division_definition.data_format")
					.getWithAliasName("value", "division_definition.value")
					.getWithAliasName("default_value", "division_definition.default_value")
					.getWithAliasName("display_order", "division_definition.display_order")
					.getWithAliasName("locale", "division_definition.locale")
					.getWithAliasName("text_content", "division_definition.text_content")
					.getWithAliasName("tenant_id", "division_definition.tenant_id")
					.from(DataDefinitionConstants.DIVISION_DEFINITION_OFFLINE).where(ConditionBuilder.instance()
							.inWithList(DataDefinitionConstants.DATA_FORMAT, divisionDataClass))
					.lang(true).skipLanguage(true).build(false).execute();
			divisionDataList = processDivisionDataList(divisionDataList);
			queryExecutor.queryBuilder().insert().lang(true).skipTenantId(true).upsertWithKeyList(
					DataDefinitionConstants.DIVISION_DEFINITION, divisionDataList, true,
					DataDefinitionConstants.DIVISION_DEFINITION_COLUMNS,
					DataDefinitionConstants.DIVISION_DEFINITION_PRIMARY_CONSTRAINTS);
			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.DIVISION_DEFINITION_OFFLINE).where(
					ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_FORMAT, divisionDataClass))
					.lang(true).build().execute();
			dataFormatMap.put(DataDefinitionConstants.DIVISION, divisionDataClass);
		} catch (Exception exception) {
			logger.error("Exception in activating division data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateDivisionDefinition method ends...");
	}
	
	/**
	 * activateDivisionDefinition used to migrate division data
	 * 
	 * @param divisionList
	 * @param queryExecutor
	 * @param dataFormatMap
	 * @throws CustomException
	 */
	public static void activateDivisionDefinitionMain(List<Map<String, Object>> divisionList, QueryExecutor queryExecutor,
			Map<String, Object> dataFormatMap) throws CustomException {
		logger.info("activateDivisionDefinition method starts...");
		try {
			List<Object> divisionDataClass = divisionList.stream()
					.map(mapper -> mapper.get("data_format_definition." + DataDefinitionConstants.DATA_FORMAT))
					.collect(Collectors.toList());
//			QueryBuilder queryBuilder = new QueryBuilder();
			List<Map<String, Object>> divisionDataList = queryExecutor.queryBuilder().select().checkIndependentTenant(true)
					.getWithAliasName("data_format", "division_definition.data_format")
					.getWithAliasName("value", "division_definition.value")
					.getWithAliasName("default_value", "division_definition.default_value")
					.getWithAliasName("display_order", "division_definition.display_order")
					.getWithAliasName("locale", "division_definition.locale")
					.getWithAliasName("text_content", "division_definition.text_content")
					.getWithAliasName("tenant_id", "division_definition.tenant_id")
					.from(DataDefinitionConstants.DIVISION_DEFINITION).where(ConditionBuilder.instance()
							.inWithList(DataDefinitionConstants.DATA_FORMAT, divisionDataClass))
					.lang(true).skipLanguage(true).build(false).execute();
			divisionDataList = processDivisionDataList(divisionDataList);
			queryExecutor.queryBuilder().insert().lang(true).skipTenantId(true).upsertWithKeyList(
					DataDefinitionConstants.DIVISION_DEFINITION, divisionDataList, true,
					DataDefinitionConstants.DIVISION_DEFINITION_COLUMNS,
					DataDefinitionConstants.DIVISION_DEFINITION_PRIMARY_CONSTRAINTS);
//			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.DIVISION_DEFINITION_OFFLINE).where(
//					ConditionBuilder.instance().inWithList(DataDefinitionConstants.DATA_FORMAT, divisionDataClass))
//					.lang(true).build().execute();
//			dataFormatMap.put(DataDefinitionConstants.DIVISION, divisionDataClass);
		} catch (Exception exception) {
			logger.error("Exception in activating division data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateDivisionDefinition method ends...");
	}

	@SuppressWarnings("unchecked")
	private static List<Map<String, Object>> processDivisionDataList(List<Map<String, Object>> divisionDataList) {
		logger.info("processDivisionDataList method starts...");
		List<Map<String, Object>> dataList = new ArrayList<>();
		Map<Object, Map<Object, List<Map<String, Object>>>> groupMap = divisionDataList.stream()
				.collect(Collectors.groupingBy(
						mapper -> mapper.get("division_definition." + DataDefinitionConstants.DATA_FORMAT),
						Collectors.groupingBy(mappers -> mappers.get("division_definition.value"))));
		groupMap.entrySet().stream().forEach(action -> {
			Map<Object, List<Map<String, Object>>> groupData = action.getValue();
			groupData.entrySet().stream().forEach(params -> {
				Map<String, Object> dataMap = new HashMap<>();
				List<Map<String, Object>> valueList = params.getValue();
				valueList.stream().forEach(item -> {
					item.entrySet().stream().forEach(data -> {
						if ("division_definition.text_content".equals(data.getKey().toString())) {
							Map<String, Object> localeMap = new HashMap<>();
							if (dataMap.containsKey(data.getKey())) {
								localeMap = (Map<String, Object>) dataMap.get(data.getKey());
							}
							localeMap.put(item.get("division_definition.locale").toString(), data.getValue());
							dataMap.put(data.getKey(), localeMap);
						} else if (!"division_definition.locale".equals(data.getKey())) {
							dataMap.put(data.getKey(), data.getValue());
						}
					});
				});
				dataList.add(dataMap);
			});
		});
		logger.info("processDivisionDataList method ends...");
		return dataList;
	}

	/**
	 * activateMasterDefinition used to migrate master data
	 * 
	 * @param masterIdList
	 * @param versionMap
	 * @param changeRequestDetails
	 * @throws CustomException
	 */
	private static void activateMasterDefinition(List<Object> masterIdList, Map<String, String> versionMap,
			Map<String, Object> changeRequestDetails) throws CustomException {
		logger.info("activateMasterDefinition method starts...");
		Map<String, Object> tablesMap = new HashMap<>();
		QueryBuilder queryBuilder = new QueryBuilder();
		QueryExecutor queryExecutor = null;
		try {
			queryExecutor = queryBuilder.getQueryExecutor();
			List<Map<String, Object>> masterDataList = getMasterDataList(masterIdList, queryExecutor);
			if (CollectionUtils.isNotEmpty(masterDataList)) {
				String versionNumber = masterDataList.stream().findFirst().get().get("master_definition.version_no")
						.toString();
				if (versionMap.containsKey(versionNumber)) {
					String changeRequestId = versionMap.get(versionNumber);
					queryExecutor.setChangeRequestId(changeRequestId);
				} else {
					changeRequestDetails.put("versionNumber", versionNumber);
					setChangeRequestDetails(queryExecutor, changeRequestDetails);
				}
				queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.MASTER_DEFINITION,
						masterDataList, true, DataDefinitionConstants.MASTER_DEFINITION_COLUMNS,
						DataDefinitionConstants.MASTER_DEFINITION_PRIMARY_CONSTRAINTS);
				queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.MASTER_DEFINITION_OFFLINE)
						.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.MASTER_ID, masterIdList))
						.build().execute();
				queryExecutor.commit();
				if (!queryExecutor.getChangeRequestId().isBlank()) {
					String changeRequestId = queryExecutor.getChangeRequestId();
					tablesMap.put(DataDefinitionConstants.MASTER, masterIdList);
					TableDefinitionUtils.updateChangeRequestForDataDefinitionTables(changeRequestId, tablesMap);
					versionMap.put(versionNumber, changeRequestId);
				}
			}
		} catch (Exception exception) {
			executeRollback(queryExecutor);
			logger.error("Exception in activating master data " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateMasterDefinition method ends...");
	}

	/**
	 * getMasterDataList used to get master data.
	 * 
	 * @param masterIdList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	private static List<Map<String, Object>> getMasterDataList(List<Object> masterIdList, QueryExecutor queryExecutor)
			throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true)
				.getWithAliasName("master_id", "master_definition.master_id")
				.getWithAliasName("table_name", "master_definition.table_name")
				.getWithAliasName("set_column_name", "master_definition.set_column_name")
				.getWithAliasName("show_column_name", "master_definition.show_column_name")
				.getWithAliasName("max_matches", "master_definition.max_matches")
				.getWithAliasName("filter_fields", "master_definition.filter_fields")
				.getWithAliasName("sort_by", "master_definition.sort_by")
				.getWithAliasName("extra_fields", "master_definition.extra_fields")
				.getWithAliasName("distinct_flag", "master_definition.distinct_flag")
				.getWithAliasName("key_column_name", "master_definition.key_column_name")
				.getWithAliasName("product_code", "master_definition.product_code")
				.getWithAliasName("version_no", "master_definition.version_no")
				.getWithAliasName("created_at", "master_definition.created_at")
				.getWithAliasName("created_by", "master_definition.created_by")
				.getWithAliasName("previous_request_id", "master_definition.previous_request_id")
				.getWithAliasName("active_flag", "master_definition.active_flag")
				.getWithAliasName("locked_flag", "master_definition.locked_flag")
				.getWithAliasName("tenant_id", "master_definition.tenant_id")
				.from(DataDefinitionConstants.MASTER_DEFINITION_OFFLINE)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.MASTER_ID, masterIdList))
				.build(false).execute();
	}
	/**
	 * getMasterDataList used to get master data.
	 * 
	 * @param masterIdList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	public static List<Map<String, Object>> getMasterDataListMain(List<Object> masterIdList, QueryExecutor queryExecutor)
			throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true)
				.getWithAliasName("master_id", "master_definition.master_id")
				.getWithAliasName("table_name", "master_definition.table_name")
				.getWithAliasName("set_column_name", "master_definition.set_column_name")
				.getWithAliasName("show_column_name", "master_definition.show_column_name")
				.getWithAliasName("max_matches", "master_definition.max_matches")
				.getWithAliasName("filter_fields", "master_definition.filter_fields")
				.getWithAliasName("sort_by", "master_definition.sort_by")
				.getWithAliasName("extra_fields", "master_definition.extra_fields")
				.getWithAliasName("distinct_flag", "master_definition.distinct_flag")
				.getWithAliasName("key_column_name", "master_definition.key_column_name")
				.getWithAliasName("product_code", "master_definition.product_code")
				.getWithAliasName("version_no", "master_definition.version_no")
				.getWithAliasName("created_at", "master_definition.created_at")
				.getWithAliasName("created_by", "master_definition.created_by")
				.getWithAliasName("previous_request_id", "master_definition.previous_request_id")
				.getWithAliasName("active_flag", "master_definition.active_flag")
				.getWithAliasName("locked_flag", "master_definition.locked_flag")
				.getWithAliasName("tenant_id", "master_definition.tenant_id")
				.from(DataDefinitionConstants.MASTER_DEFINITION)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.MASTER_ID, masterIdList))
				.build(false).execute();
	}

	/**
	 * activateCharsetDefinition used to migrate the charset data
	 * 
	 * @param primaryKeyList
	 * @param versionMap
	 * @param changeRequestDetails
	 * @throws CustomException
	 */
	private static void activateCharsetDefinition(List<Object> primaryKeyList, Map<String, String> versionMap,
			Map<String, Object> changeRequestDetails) throws CustomException {
		logger.info("activateCharsetDefinition method starts...");
		Map<String, Object> tablesMap = new HashMap<>();
		QueryBuilder queryBuilder = new QueryBuilder();
		QueryExecutor queryExecutor = null;
		try {
			queryExecutor = queryBuilder.getQueryExecutor();
			List<Map<String, Object>> charsetList = getCharsetDataList(primaryKeyList, queryExecutor);
			String versionNumber = charsetList.stream().findFirst().get().get("charset_definition.version_no")
					.toString();
			if (versionMap.containsKey(versionNumber)) {
				String changeRequestId = versionMap.get(versionNumber);
				queryExecutor.setChangeRequestId(changeRequestId);
			} else {
				changeRequestDetails.put("versionNumber", versionNumber);
				setChangeRequestDetails(queryExecutor, changeRequestDetails);
			}
			queryExecutor.queryBuilder().insert().skipTenantId(true).upsertWithKeyList(DataDefinitionConstants.CHARSET_DEFINITION,
					charsetList, true, DataDefinitionConstants.CHARSET_DEFINITION_COLUMNS,
					DataDefinitionConstants.CHARSET_DEFINITION_PRIMARY_CONSTRAINTS);
			queryExecutor.queryBuilder().delete().skipTenantId(true).from(DataDefinitionConstants.CHARSET_DEFINITION_OFFLINE)
					.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.CHARSET_ID, primaryKeyList))
					.build().execute();
			queryExecutor.commit();
			if (!queryExecutor.getChangeRequestId().isBlank()) {
				String changeRequestId = queryExecutor.getChangeRequestId();
				tablesMap.put(TableDefinitionConstants.OFFLINE_CHARSET_LIST, primaryKeyList);
				TableDefinitionUtils.updateChangeRequestForDataDefinitionTables(changeRequestId, tablesMap);
				versionMap.put(versionNumber, changeRequestId);
			}
		} catch (Exception exception) {
			executeRollback(queryExecutor);
			logger.error("Exception in activating charset data. " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("activateCharsetDefinition method ends...");
	}

	/**
	 * getCharsetDataList used to get the charset data list.
	 * 
	 * @param primaryKeyList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	private static List<Map<String, Object>> getCharsetDataList(List<Object> primaryKeyList,
			QueryExecutor queryExecutor) throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true).getWithAliasName("charset_id", "charset_definition.charset_id")
				.getWithAliasName("charset_name", "charset_definition.charset_name")
				.getWithAliasName("full_katakana", "charset_definition.full_katakana")
				.getWithAliasName("half_katakana", "charset_definition.half_katakana")
				.getWithAliasName("upper_case", "charset_definition.upper_case")
				.getWithAliasName("lower_case", "charset_definition.lower_case")
				.getWithAliasName("full_hiragana", "charset_definition.full_hiragana")
				.getWithAliasName("digits", "charset_definition.digits")
				.getWithAliasName("symbols", "charset_definition.symbols")
				.getWithAliasName("tab", "charset_definition.tab")
				.getWithAliasName("line_separator", "charset_definition.line_separator")
				.getWithAliasName("all_char", "charset_definition.all_char")
				.getWithAliasName("description", "charset_definition.description")
				.getWithAliasName("enable_characters", "charset_definition.enable_characters")
				.getWithAliasName("disable_characters", "charset_definition.disable_characters")
				.getWithAliasName("space", "charset_definition.space")
				.getWithAliasName("version_no", "charset_definition.version_no")
				.getWithAliasName("product_code", "charset_definition.product_code")
				.getWithAliasName("created_at", "charset_definition.created_at")
				.getWithAliasName("created_by", "charset_definition.created_by")
				.getWithAliasName("previous_request_id", "charset_definition.previous_request_id")
				.getWithAliasName("active_flag", "charset_definition.active_flag")
				.getWithAliasName("locked_flag", "charset_definition.locked_flag")
				.getWithAliasName("tenant_id", "charset_definition.tenant_id")
				.from(DataDefinitionConstants.CHARSET_DEFINITION_OFFLINE)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.CHARSET_ID, primaryKeyList))
				.build(false).execute();
	}

	
	/**
	 * getCharsetDataList used to get the charset data list.
	 * 
	 * @param primaryKeyList
	 * @param queryExecutor
	 * @return
	 * @throws QueryException
	 */
	public static List<Map<String, Object>> getCharsetDataListFromMain(List<Object> primaryKeyList,
			QueryExecutor queryExecutor) throws QueryException {
		return queryExecutor.queryBuilder().select().checkIndependentTenant(true).getWithAliasName("charset_id", "charset_definition.charset_id")
				.getWithAliasName("charset_name", "charset_definition.charset_name")
				.getWithAliasName("full_katakana", "charset_definition.full_katakana")
				.getWithAliasName("half_katakana", "charset_definition.half_katakana")
				.getWithAliasName("upper_case", "charset_definition.upper_case")
				.getWithAliasName("lower_case", "charset_definition.lower_case")
				.getWithAliasName("full_hiragana", "charset_definition.full_hiragana")
				.getWithAliasName("digits", "charset_definition.digits")
				.getWithAliasName("symbols", "charset_definition.symbols")
				.getWithAliasName("tab", "charset_definition.tab")
				.getWithAliasName("line_separator", "charset_definition.line_separator")
				.getWithAliasName("all_char", "charset_definition.all_char")
				.getWithAliasName("description", "charset_definition.description")
				.getWithAliasName("enable_characters", "charset_definition.enable_characters")
				.getWithAliasName("disable_characters", "charset_definition.disable_characters")
				.getWithAliasName("space", "charset_definition.space")
				.getWithAliasName("version_no", "charset_definition.version_no")
				.getWithAliasName("product_code", "charset_definition.product_code")
				.getWithAliasName("created_at", "charset_definition.created_at")
				.getWithAliasName("created_by", "charset_definition.created_by")
				.getWithAliasName("previous_request_id", "charset_definition.previous_request_id")
				.getWithAliasName("active_flag", "charset_definition.active_flag")
				.getWithAliasName("locked_flag", "charset_definition.locked_flag")
				.getWithAliasName("tenant_id", "charset_definition.tenant_id")
				.from(DataDefinitionConstants.CHARSET_DEFINITION)
				.where(ConditionBuilder.instance().inWithList(DataDefinitionConstants.CHARSET_ID, primaryKeyList))
				.build(false).execute();
	}

	/**
	 * executeRollback used to roll back
	 * 
	 * @param queryExecutor
	 */
	public static void executeRollback(QueryExecutor queryExecutor) {
		logger.info("executeRollback method starts...");
		if (Objects.nonNull(queryExecutor)) {
			try {
				queryExecutor.rollBack();
			} catch (Exception exception) {
				logger.error("Exception in rollback " + exception);
			}
		}
		logger.info("executeRollback method ends...");
	}

	/**
	 * updateTableDefinitionData used to update the table definition data when data
	 * class of the data element changed or element type, data type, max decimal,
	 * precision changed for data class.
	 * 
	 * @param tableDetailList
	 * @param sourceTable
	 * @param primaryKeyList
	 * @param changeRequestId
	 */
	public static void updateTableDefinitionData(List<Map<String, Object>> tableDetailList, String sourceTable,
			List<Object> primaryKeyList, String changeRequestId) {
		logger.info("updateTableDefinitionData method starts...");
//		List<Map<String, Object>> sourceCodeGenerateTableList = new ArrayList<>();
		tableDetailList.stream().forEach(action -> {
			Map<String, Object> detailMap = new HashMap<>();
			detailMap.put(TableDefinitionConstants.TABLENAME, action.get("table_name"));
			detailMap.put(TableDefinitionConstants.PRODUCT_CODE, action.get("product_code"));
			detailMap.put(sourceTable, primaryKeyList);
//			Map<String, Object> returnMap;
//			try {
//				 new TableDefinitionServiceImpl().alterFromDataElements(detailMap);
//				if (returnMap.containsKey("setSourceCodeGenerate")) {
//					sourceCodeGenerateTableList.add(detailMap);
//				}
//			} catch (CustomException exception) {
//				exception.printStackTrace();
//			}
		});
//		List<Map<String, Object>> updateList = new ArrayList<>();
//		List<ConditionBuilder> conditionBuilderList = new ArrayList<>();
//		if (!sourceCodeGenerateTableList.isEmpty() && !changeRequestId.isEmpty()) {
//			List<String> productCodeList = new ArrayList<>();
//			Map<String, Object> repoMap = new HashMap<>();
//			Map<String, Object> repoDetails = new HashMap<>();
//			sourceCodeGenerateTableList.forEach(sourceMap -> {
//				String tableName = String.valueOf(sourceMap.get(TableDefinitionConstants.TABLENAME));
//				String productCode = String.valueOf(sourceMap.get(TableDefinitionConstants.PRODUCT_CODE));
//				try {
//					Map<String, Object> resultMap = new HashMap<>();
//					resultMap.put("isSourceCodeOnly", true);
//					resultMap.put("productCode", productCode);
//					resultMap.put("viewObject", tableName);
//					if (productCodeList.contains(productCode)) {
//						resultMap.put("noDelete", true);
//					}
//					new SourceGenerationUtils().generateSourceCode(resultMap, changeRequestId, false,
//							new QueryBuilder());
//					conditionBuilderList.add(ConditionBuilder.instance().eq("table_name", tableName).and()
//							.eq("product_code", productCode));
//					Map<String, Object> updateMap = new HashMap<>();
//					updateMap.put("tableDefinition.status", TableTypeEnum.INPROGRESS.name());
//					updateList.add(updateMap);
//					TableDefinitionCommonUtils.insertClassConfig(String.valueOf(resultMap.get("packageName")),
//							changeRequestId, tableName, productCode);
//					productCodeList.add(productCode);
//					if (repoDetails.containsKey(productCode)) {
//						List<String> repoName = (List<String>) repoDetails.get(productCode);
//						if (!repoName.contains(resultMap.get("repoName"))) {
//							repoName.add(String.valueOf(resultMap.get("repoName")));
//							repoDetails.put(productCode, repoName);
//						}
//					} else {
//						List<String> repoName = new ArrayList<>();
//						repoName.add(String.valueOf(resultMap.get("repoName")));
//						repoDetails.put(productCode, repoName);
//					}
//
//					if (repoMap.containsKey(resultMap.get("repoName"))) {
//						List<String> tableNameList = (List<String>) repoMap.get(resultMap.get("repoName"));
//						tableNameList.add(tableName);
//						repoMap.put(String.valueOf(resultMap.get("repoName")), tableNameList);
//					} else {
//						List<String> tableNameList = new ArrayList<>();
//						tableNameList.add(tableName);
//						repoMap.put(String.valueOf(resultMap.get("repoName")), tableNameList);
//					}
//				} catch (Exception exception) {
//					inactiveStateMove(Arrays.asList(tableName), exception.getMessage(), null, "", productCode);
//				}
//			});
//			try {
//				if (!repoMap.isEmpty()) {
//					ChangeRequest.updateCrRepo(changeRequestId, repoDetails, true, true);
//					Map<String, Object> updateCrMap = new HashMap<>();
//					repoMap.forEach((key, value) -> {
//						Map<String, Object> createMap = new HashMap<>();
//						createMap.put("createList", value);
//						updateCrMap.put(key, createMap);
//					});
//					TableDefinitionCommonUtils.insertRepoDetailsInRequestTable(updateCrMap, changeRequestId);
//					Map<String, Object> changeRequestMap = new HashMap<>();
//					changeRequestMap.put("changeRequestId", changeRequestId);
//					changeRequestMap.put("deleteHistory", true);
//					TableDefinitionCommonUtils.callChangeRequestCurrentSystem(changeRequestMap);
//					new QueryBuilder().update().skipChangeRequest(true).batchUpdate("table_definition", updateList,
//							conditionBuilderList);
//				}
//			} catch (Exception exception) {
//				logger.error(exception);
//				logger.info("exception at call change request" + exception.getMessage());
//			}
//		}
		logger.info("updateTableDefinitionData method ends...");
	}

	/**
	 * updateOfflineTable used to update offline table
	 * 
	 * @param sourceTable
	 * @param primaryKeyList
	 */
	public static void updateOfflineTable(String sourceTable, List<Object> primaryKeyList) {
		logger.info("updateOfflineTable method execution starts");
		try {
			if (sourceTable.equals(TableDefinitionConstants.DATA_ELEMENT_DEFINTION_MAIN)) {
				List<Map<String, Object>> dataFormatList = new QueryBuilder().btSchema().select().checkIndependentTenant(true)
						.from("data_element_definition_view", "deview")
						.join("data_format_definition_view", "dfview",
								ConditionBuilder.instance().eq("deview.data_format", "dfview.data_format", true))
						.where(ConditionBuilder.instance().inWithList("deview.data_element", primaryKeyList))
						.build(false).execute();
				if (!dataFormatList.isEmpty()) {
					Map<String, Object> updateMap = new HashMap<>();
					updateMap.put("table_definition_column_details_offline.data_format",
							dataFormatList.get(0).get("data_format"));
					updateMap.put("table_definition_column_details_offline.data_type",
							dataFormatList.get(0).get("data_type"));
					updateMap.put("table_definition_column_details_offline.length",
							dataFormatList.get(0).get("max_length"));
					updateMap.put("table_definition_column_details_offline.default_value",
							dataFormatList.get(0).get("default_value"));
					new QueryBuilder().btSchema().update().updateWithMap("table_definition_column_details_offline",
							updateMap, ConditionBuilder.instance().inWithList("data_element", primaryKeyList));
				}
			} else {
				List<Map<String, Object>> dataFormatList = new QueryBuilder().btSchema().select().checkIndependentTenant(true)
						.from("data_format_definition_view")
						.where(ConditionBuilder.instance().inWithList("data_format", primaryKeyList)).build(false)
						.execute();
				if (!dataFormatList.isEmpty()) {
					Map<String, Object> updateMap = new HashMap<>();
					updateMap.put("table_definition_column_details_offline.data_type",
							dataFormatList.get(0).get("data_type"));
					updateMap.put("table_definition_column_details_offline.length",
							dataFormatList.get(0).get("max_length"));
					updateMap.put("table_definition_column_details_offline.default_value",
							dataFormatList.get(0).get("default_value"));
					new QueryBuilder().btSchema().update().updateWithMap("table_definition_column_details_offline",
							updateMap, ConditionBuilder.instance().inWithList("data_format", primaryKeyList));
				}
			}

		} catch (Exception exception) {
			logger.error(exception);
			logger.info("updateOfflineTable method execution ends");
		}
		logger.info("updateOfflineTable method execution ends");
	}

	/**
	 * getTableNameListByDataElement used to get the table name list
	 * 
	 * @param dataElementList
	 * @return List
	 * @throws CustomException
	 */
	public static List<Map<String, Object>> getTableNameListByDataElement(List<Object> dataElementList)
			throws CustomException {
		logger.info("getTableNameListByDataElement method starts...");
		List<Map<String, Object>> tableList = new ArrayList<>();
		try {
			tableList = new QueryBuilder().select().checkIndependentTenant(true)
					.distinctOn(Arrays.asList("tableDefinition.table_name", "tableDefinition.product_code"))
					.from("table_definition_column_details", "columnDetails")
					.join("table_definition", "tableDefinition",
							ConditionBuilder.instance().eq("columnDetails.table_name", "tableDefinition.table_name",
									true))
					.where(ConditionBuilder.instance().inWithList("columnDetails.data_element", dataElementList).and()
							.brackets(ConditionBuilder.instance().isNull("tableDefinition.status").or()
									.eq("tableDefinition.status", TableTypeEnum.SUCCESS.name())))
					.build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in getting live table list by data element list. " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("getTableNameListByDataElement method ends...");
		return tableList;
	}

	/**
	 * getTableNameListByDataClass used to get the table name list
	 * 
	 * @param dataFormatList
	 * @return List
	 * @throws CustomException
	 */
	public static List<Map<String, Object>> getTableNameListByDataClass(List<Object> dataFormatList)
			throws CustomException {
		logger.info("getTableNameListByDataClass method starts...");
		List<Map<String, Object>> tableList = new ArrayList<>();
		try {
			tableList = new QueryBuilder().select().checkIndependentTenant(true)
					.distinctOn(Arrays.asList("tableDefinition.table_name", "tableDefinition.product_code"))
					.from("table_definition_column_details", "columnDetails")
					.join("table_definition", "tableDefinition",
							ConditionBuilder.instance().eq("columnDetails.table_name", "tableDefinition.table_name",
									true))
					.where(ConditionBuilder.instance()
							.brackets(ConditionBuilder.instance().in("columnDetails.data_element",
									new QueryBuilder().select().checkIndependentTenant(true).get("data_element").from("data_element_definition")
											.where(ConditionBuilder
													.instance().inWithList("data_format", dataFormatList))
											.build(false))
									.or()
									.brackets(ConditionBuilder.instance().inWithList("columnDetails.data_format",
											dataFormatList)))
							.and()
							.brackets(ConditionBuilder.instance().isNull("tableDefinition.status").or()
									.eq("tableDefinition.status", TableTypeEnum.SUCCESS.name())))
					.build(false).execute();
		} catch (Exception exception) {
			logger.error("Exception in getting live table list by data class. " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("getTableNameListByDataClass method ends...");
		return tableList;
	}

	/**
	 * setChangeRequestDetails used to set the change request details.
	 * 
	 * @param queryExecutor
	 * @param paramMap
	 */
	public static void setChangeRequestDetails(QueryExecutor queryExecutor, Map<String, Object> changeRequestDetails) {
		logger.info("setChangeRequestDetails method starts...");
		if (changeRequestDetails.containsKey("changeRequestId")
				&& Objects.nonNull(changeRequestDetails.get("changeRequestId"))
				&& StringUtils.isNotEmpty(changeRequestDetails.get("changeRequestId").toString())) {
			String changeRequestId = changeRequestDetails.get("changeRequestId").toString();
			String crVersion = getCrVersionNumber(changeRequestId);
			if (crVersion.equals(changeRequestDetails.get("versionNumber").toString())) {
				queryExecutor.setChangeRequestId(changeRequestId);
			} else {
				queryExecutor.setChangeRequestTitle(String.valueOf(changeRequestDetails.get("title")));
				changeRequestDetails.put("artifactType", ChangeRequestFromEnum.DATA_DEFINITION.name());
				changeRequestDetails.put("productVersion", TableDefinitionUtils.getSourceVersion());
				changeRequestDetails.put("isDelivered", true);
				if (changeRequestDetails.containsKey("dependentRequestId") && Objects.nonNull(changeRequestDetails.get("dependentRequestId"))) {
					changeRequestDetails.put("updateDependent", changeRequestDetails.get("dependentRequestId"));
				}
				queryExecutor.setChangeRequestDetails(changeRequestDetails);
			}
		} else {
			queryExecutor.setChangeRequestTitle(String.valueOf(changeRequestDetails.get("title")));
			changeRequestDetails.put("artifactType", ChangeRequestFromEnum.DATA_DEFINITION.name());
			changeRequestDetails.put("productVersion", TableDefinitionUtils.getSourceVersion());
			changeRequestDetails.put("isDelivered", true);
			if (changeRequestDetails.containsKey("dependentRequestId") && Objects.nonNull(changeRequestDetails.get("dependentRequestId"))) {
				changeRequestDetails.put("updateDependent", changeRequestDetails.get("dependentRequestId"));
			}
			queryExecutor.setChangeRequestDetails(changeRequestDetails);
		}
		logger.info("setChangeRequestDetails method ends...");
	}

	/**
	 * getCrVersionNumber used to get the version number of cr.
	 * 
	 * @param changeRequestId
	 * @return String
	 */
	private static String getCrVersionNumber(String changeRequestId) {
		String versionNo = StringUtils.EMPTY;
		Map<String, Object> crDetails = ChangeRequest.getCrDetails(changeRequestId);
		if (MapUtils.isNotEmpty(crDetails)) {
			versionNo = String.valueOf(crDetails.get("versionNumber"));
		}
		return versionNo;
	}

	/**
	 * prepareChangeRequestDetails used to set the change request details.
	 * 
	 * @param key
	 * @return Map
	 */
	public static Map<String, Object> prepareChangeRequestDetails(String key) {
		logger.info("prepareChangeRequestDetails method starts...");
		Map<String, Object> changeRequestDetails = new HashMap<>();
		String title = TableDefinitionUtils.getMessageDefintionText(MessageEntriesConstants.NN_DATA_DEF_CR_TITLE);
		title = title.replace("%1$s", key);
		String description = TableDefinitionUtils
				.getMessageDefintionText(MessageEntriesConstants.NN_DATA_DEF_CR_DESCRIPTION);
		description = description.replace("%1$s", key);
		changeRequestDetails.put("title", title);
		changeRequestDetails.put("description", description);
		changeRequestDetails.put("productVersion", TableDefinitionUtils.getSourceVersion());
		changeRequestDetails.put("artifactType", ChangeRequestFromEnum.DATA_DEFINITION.name());
		logger.info("prepareChangeRequestDetails method ends...");
		return changeRequestDetails;
	}

	/**
	 * inactiveStateMove method used for move to table to inactive stage
	 * 
	 * @param tableName    contains which table name to moved
	 * @param errorMessage contains error message
	 * @param errorStage   contains change request error stage
	 * @param string
	 */
	public static void inactiveStateMove(List<Object> tableName, String errorMessage, String errorStage,
			String changeRequestId, String productCode) {
		logger.info("inactiveStateMove method execution started. ");
		try {
			UpdateQueryBuilder updateQueryBuilder = new QueryBuilder().btSchema().update();
			if (!changeRequestId.isEmpty()) {
				updateQueryBuilder = updateQueryBuilder.setChangeRequestId(changeRequestId);
			}
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".errorStage",
					Objects.nonNull(errorStage) ? errorStage : "");
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".status", TableTypeEnum.INACTIVE.name());
			updateMap.put(TableDefinitionConstants.TABLE_DEFINITION_MAIN + ".errorMessage",
					Objects.nonNull(errorMessage) ? errorMessage : "");
			updateQueryBuilder.skipChangeRequest(true).updateWithMap(TableDefinitionConstants.TABLE_DEFINITION_MAIN, updateMap,
					ConditionBuilder.instance().inWithList(TableDefinitionConstants.TABLE_NAME, tableName).and()
							.eq("product_code", productCode));
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("Exception occured at inactiveStateMove method" + exception.getMessage());
			logger.info("inactiveStateMove method execution ended. ");
		}
		logger.info("inactiveStateMove method execution ended. ");
	}
	
	/**
	 * getTenantId used to get the tenant id.
	 * 
	 * @param isOffline
	 * @param valueList
	 * @param viewName
	 * @return String
	 * @throws CustomException
	 */
	public static String getTenantId(boolean isOffline, List<Map<String, Object>> valueList, String viewName)
			throws CustomException {
		logger.info("getTenantId method starts...");
		String tenantId = null;
		try {
			Optional<Map<String, Object>> optionalData = valueList.stream().findFirst();
			Map<String, Object> dataMap = new HashMap<>();
			if (optionalData.isPresent()) {
				dataMap = optionalData.get();
			}
			Map<String, String> primaryKeyMap = getPrimaryKey(isOffline, dataMap, viewName);
			List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().checkIndependentTenant(true).from(viewName)
					.where(ConditionBuilder.instance().eq(primaryKeyMap.get("key"), primaryKeyMap.get("value")))
					.build(false).execute();
			if (CollectionUtils.isNotEmpty(dataList)) {
				Optional<Map<String, Object>> optionalViewData = dataList.stream().findFirst();
				if (optionalViewData.isPresent()) {
					Map<String, Object> viewData = optionalViewData.get();
					tenantId = viewData.get("tenant_id").toString();
				}
			} else {
				tenantId = ContextBean.getTenantId();
			}
		} catch (Exception exception) {
			logger.error("Exception in getting tenant id. " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("getTenantId method ends...");
		return tenantId;
	}

	/**
	 * getPrimaryKey used to get the primary key.
	 * 
	 * @param isOffline
	 * @param dataMap
	 * @param viewName
	 * @return Map
	 */
	static Map<String, String> getPrimaryKey(boolean isOffline, Map<String, Object> dataMap, String viewName) {
		logger.info("getPrimaryKey method starts...");
		Map<String, String> primaryKeyMap = new HashMap<>();
		String primaryValue = null;
		String tableName = null;
		if (MapUtils.isNotEmpty(dataMap)) {
			String replaceString = isOffline ? "_offline" : StringUtils.EMPTY;
			switch (viewName) {
			case DataDefinitionConstants.DATA_ELEMENT_DEFINITION_VIEW:
				tableName = DataDefinitionConstants.DATA_ELEMENT_DEFINITION_VIEW.replace("_view", replaceString);
				primaryValue = dataMap.get(tableName+".data_element").toString();
				primaryKeyMap.put("key", DataDefinitionConstants.DATA_ELEMENT);
				break;
			case DataDefinitionConstants.DATA_FORMAT_DEFINITION_VIEW:
				tableName = DataDefinitionConstants.DATA_FORMAT_DEFINITION_VIEW.replace("_view", replaceString);
				primaryValue = dataMap.get(tableName+".data_format").toString();
				primaryKeyMap.put("key", DataDefinitionConstants.DATA_FORMAT);
				break;
			case DataDefinitionConstants.CHARSET_DEFINITION_VIEW:
				tableName = DataDefinitionConstants.CHARSET_DEFINITION_VIEW.replace("_view", replaceString);
				primaryValue = dataMap.get(tableName+".charset_id").toString();
				primaryKeyMap.put("key", DataDefinitionConstants.CHARSET_ID);
				break;
			case DataDefinitionConstants.MASTER_DEFINITION_VIEW:
				tableName = DataDefinitionConstants.MASTER_DEFINITION_VIEW.replace("_view", replaceString);
				primaryValue = dataMap.get(tableName+".master_id").toString();
				primaryKeyMap.put("key", DataDefinitionConstants.MASTER_ID);
				break;
			default:
				break;
			}
			primaryKeyMap.put("value", primaryValue);
		}
		logger.info("getPrimaryKey method ends...");
		return primaryKeyMap;
	}

	/**
	 * setTenantId used to set the tenant id.
	 * 
	 * @param isOffline
	 * @param valueList
	 * @param viewName
	 * @throws CustomException
	 */
	public static void setTenantId(boolean isOffline, List<Map<String, Object>> valueList, String viewName) throws CustomException {
		String tenantId = getTenantId(isOffline, valueList, viewName);
		AtomicReference<String> keyName = new AtomicReference<String>(null);
		String replaceString = isOffline ? "_offline" : StringUtils.EMPTY;
		switch (viewName) {
		case DataDefinitionConstants.DATA_ELEMENT_DEFINITION_VIEW:
			keyName.set(DataDefinitionConstants.DATA_ELEMENT_DEFINITION_VIEW.replace("_view", replaceString).concat(".tenant_id"));
			break;
		case DataDefinitionConstants.DATA_FORMAT_DEFINITION_VIEW:
			keyName.set(DataDefinitionConstants.DATA_FORMAT_DEFINITION_VIEW.replace("_view", replaceString).concat(".tenant_id"));
			break;
		case DataDefinitionConstants.CHARSET_DEFINITION_VIEW:
			keyName.set(DataDefinitionConstants.CHARSET_DEFINITION_VIEW.replace("_view", replaceString).concat(".tenant_id"));
			break;
		case DataDefinitionConstants.MASTER_DEFINITION_VIEW:
			keyName.set(DataDefinitionConstants.MASTER_DEFINITION_VIEW.replace("_view", replaceString).concat(".tenant_id"));
			break;
		default:
			break;
		}
		valueList.stream().forEach(action -> action.put(keyName.get(), tenantId));
	}
	
	/**
	 * checkOperationRestriction used to get the restriction key
	 * 
	 * @return boolean
	 */
	public static boolean checkOperationRestriction() {
		return Objects
				.isNull((CacheGetServiceImpl.getInstance().getConfigurationProperty().get("save_restrict"))) ? false
						: (boolean) (CacheGetServiceImpl.getInstance().getConfigurationProperty()
								.get("save_restrict"));
	}
	
	/**
	 * getDependentRequestId used to get the dependent request id.
	 * 
	 * @param viewName
	 * @param primaryKey
	 * @param value
	 * @return String
	 * @throws CustomException
	 */
	public static String getDependentRequestId(String viewName, String primaryKey, String value)
			throws CustomException {
		logger.info("getDependentRequestId method starts...");
		String dependentRequestId = null;
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			List<Map<String, Object>> dataList = queryBuilder.btSchema().select().from(viewName)
					.where(ConditionBuilder.instance().eq(primaryKey, value)).build(false).execute();
			Optional<Map<String, Object>> optionalData = dataList.stream().findFirst();
			if (optionalData.isPresent()) {
				Map<String, Object> dataMap = optionalData.get();
				dependentRequestId = (Objects.nonNull(dataMap.get("previous_request_id"))
						&& StringUtils.isNotEmpty(dataMap.get("previous_request_id").toString()))
								? dataMap.get("previous_request_id").toString()
								: null;
			}
		} catch (Exception exception) {
			logger.error("Exception in getDependentRequestId. " + exception);
			throw new CustomException(exception.getMessage());
		}
		logger.info("getDependentRequestId method ends...");
		return dependentRequestId;
	}
}
