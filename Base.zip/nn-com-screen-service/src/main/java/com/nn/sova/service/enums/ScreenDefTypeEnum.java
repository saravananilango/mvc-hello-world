package com.nn.sova.service.enums;

import java.util.Arrays;

import lombok.Getter;

/**
 * ScreenDefTypeEnum is for the Screen Definition Type
 * 
 * @author Vivek Kannan E, Sakthivel
 */
public enum ScreenDefTypeEnum {

	/** Screen Definition Type as SCREEN */
	SCREEN("screen"),

	/** Screen Definition Type as WIZARD */
	WIZARD("wizard"),

	/**Screen Definition Type as INPUT_DIALOG */
	INPUT_DIALOG("inputdialog"),
	
	/** Screen Definition Type as HELP_MASTER */
	HELP_MASTER("helpmaster");

	@Getter
	private String value;

	/**
	 * ComponentDefTypeEnum class return string value of enum.
	 * 
	 * @param value
	 */
	private ScreenDefTypeEnum(String name) {
		value = name;
	}

	/**
	 * getEnum method is used to get the enum value of ScreenDefTypeEnum
	 * 
	 * @param screenDefTypeEnum
	 * @return value of ScreenDefTypeEnum
	 */
	public static ScreenDefTypeEnum getEnum(String screenDefTypeEnum) {
		return Arrays.stream(ScreenDefTypeEnum.values())
				.filter(instance -> instance.value.equals(screenDefTypeEnum)).findFirst().orElse(SCREEN);
	}
}
