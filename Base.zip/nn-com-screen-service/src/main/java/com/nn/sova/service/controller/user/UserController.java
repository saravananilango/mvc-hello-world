package com.nn.sova.service.controller.user;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.collections.MapUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.nn.sova.entity.ScreenDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.screen.ScreenDefinitionCacheService;
import com.nn.sova.service.service.user.UserService;
import com.nn.sova.service.service.user.UserServiceImpl;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.utility.api.WebServiceUtils;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

@SovaMapping("/user")
public class UserController {

    private static UserService userService;

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(UserController.class);
	
    /**
	 * UserController constructor
	 */
    public UserController() {
        userService = new UserServiceImpl();
    }

    /**
	 * changeUserImage method is to change the user image of the logged user.
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
    @SovaMapping(value = "/changeUserImage", method = SovaRequestMethod.POST)
    public Map<String, Object> changeUserImage(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        return userService.changeUserImage(paramMap);
    }

    /**
	 * getServiceData method is to get the service data(Screen URL for next navigation).
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
    @SovaMapping(value = "/getServiceData", method = SovaRequestMethod.POST)
	public Map<String, Object> getServiceData(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		Map<String, Object> resultMap = new HashMap<>();
		// actually it is screenDef Id . From Client side it is sent as screenId.
		String screenDefId = String.valueOf(paramMap.get("screenId"));
		String screenId = request.getQueryParameters().containsKey("sid") ? String.valueOf(request.getQueryParameters().get("sid")) : null;
		 return userService.getTargetScreenIdData(screenId, screenDefId);
	}



	/**
	 * getUserPreferenceData method is to get the user preference data
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
    @SovaMapping(value = "/getUserPreferenceData", method = SovaRequestMethod.POST)
    public Map<String, Object> getUserPreferenceData(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        try {
            Map<String, Object> resultMap = new HashMap<>();
            if (Objects.nonNull(paramMap.get("preference"))) {
                resultMap.put("preference", userService.getUserPreferenceData());
                resultMap.put("themeData", CacheService.getInstance().getTemplateCacheData(UserContext.getInstance().getUserProfile().getThemeCode()));
            }
            return resultMap;
        } catch (QueryException e) {
            return Collections.emptyMap();
        }
    }

    /**
	 * getUserPreferenceData method is to reset the user data in the cache
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
    @SovaMapping(value = "/resetUserData", method = SovaRequestMethod.POST)
    public Map<String, Object> resetUserData(SovaHttpRequest request, SovaHttpResponse response) {
        try {
            Map<String, Object> resultMap = new HashMap<>();
            Map<String, Object> userPreferenceData = userService.getUserPreferenceData();
            if (MapUtils.isNotEmpty(userPreferenceData)) {
            	String accessToken = UserContext.getInstance().getUserToken();
                Map<String, Object> userTokenCacheData = (Map<String, Object>) CacheService.getInstance().getCacheData(accessToken);
                userTokenCacheData.put("locale", userPreferenceData.get("locale"));
                userTokenCacheData.put("userData", userPreferenceData);
                CacheService.getInstance().saveToCache(accessToken, userTokenCacheData);
            }
            String themeCode = UserContext.getInstance().getUserProfile().getThemeCode();
			Map<String,Object> userThemeCacheData = CacheService.getInstance().getTemplateCacheData(themeCode);
			if (MapUtils.isNotEmpty(userThemeCacheData)) {
				resultMap.put("themeData", userThemeCacheData);
			}
            resultMap.put("userData", userPreferenceData);
            resultMap.put("status", true);
            return resultMap;
        } catch (QueryException e) {
            return Collections.emptyMap();
        }
    }

    /**
	 * getUserPreferenceData method is to get the user preference data
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
    //post_lambda 
    @SovaMapping(value = "/changeUserPassword")
    public Map<String, Object> changeUserPassword(SovaHttpRequest request, SovaHttpResponse response) {
        Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, Object> resultMap = new HashMap<>();
        try {
            if (Objects.isNull(paramMap.get("currentPassword")) || Objects.isNull(paramMap.get("newPassword"))) {
                resultMap.put("status", false);
            } else {
                paramMap.put("tenantId", ContextBean.getTenantId());
                paramMap.put("userId", ContextBean.getUserId());
                paramMap.put("passwordValue", String.valueOf(paramMap.get("newPassword")));
                return (Map<String, Object>) WebServiceUtils.getInstance().callAuth("/changeUserPassword", HttpMethod.POST, Map.class, paramMap, MediaType.ALL);
            }
        } catch (Exception e) {
            resultMap.put("status", false);
            resultMap.put("error", "nn_login_reset_error_while_changing_password");
        }
        return resultMap;
    }
    
    /**
     * getTemplateData is used to get the template data.
     *
     * @param returnList
     * @param productCode
     */
    @SovaMapping(value = "/getTemplateData")
    public Map<String, Object> getTemplateData(SovaHttpRequest request) {
    	CacheService instance = CacheService.getInstance();
    	Map<String, Object> resultMap = new HashMap<>();
    	try {
    		String sid = request.getParameter("sid");
        	sid = Objects.isNull(sid) ? ScreenDefinitionCacheService.getInstance().getScreenByDefId("Home"):sid;
        	ScreenDefinitionEntity screenDefEntity = CacheService.getInstance().getScreenDefinitionDataByLocale(sid, ContextBean.getLocale());
    		//Map<String, Object> templateData = instance.getTemplateCacheData();
    		Map<String, Object> templateData = instance.getTemplateCacheData(UserContext.getInstance().getUserProfile().getThemeCode());
    		UUID randomUUID = UUID.randomUUID();
    		//instance.saveToCache(CacheKeyHelper.getUserThemeKey(ContextBean.getTenantId(), ContextBean.getUserId()+":theme_key"), randomUUID);
    		//resultMap.put("templateKey", randomUUID);
    		resultMap.put("templateData", templateData);
    		
    		return resultMap;
    	} catch (Exception e) {
    		// logger.error(e.getMessage(),e);
    		return resultMap;
    	}
    }
    
    /**
     * update the debug mode of an user.
     * @param request
     * @return
     */
    @SovaMapping(value = "/updateDebugMode", method = SovaRequestMethod.POST)
    public Map<String, Object> updateUserDebugMode(SovaHttpRequest request) {
    	Map<String, Object> resultMap = new HashMap<>();
    	try {
    		Map<String,Boolean> requestBody = (Map<String, Boolean>) request.getBody();
    		boolean isDebug = requestBody.get("isDebug");
    		boolean updateStatus = userService.updateDebugMode(isDebug);
    		if(updateStatus) {
    			resultMap.put("status", true);
    		}
    	} catch(Exception ex) {
    		resultMap.put("status", false);
    		resultMap.put("error_message", "Failed to update debug mode"+ex.getMessage());
    	}
		return resultMap;
    }    
    
    /**
     * getUserHigherOrderSid method used to fetch the user's higher order sid with urlpath
     * @param servletRequest
     * @param servletResponse
     * @return urlpath
     */
    @SovaMapping(value = "/getUserHigherOrderSid", method = SovaRequestMethod.POST)
	public String getUserHigherOrderSid(SovaHttpRequest servletRequest, SovaHttpResponse servletResponse) {
    	Map<String, Object> paramMap = (Map<String, Object>) servletRequest.getBody();
		return userService.getUserHigherOrderSid(String.valueOf(paramMap.get("screenId")));
	}
}
