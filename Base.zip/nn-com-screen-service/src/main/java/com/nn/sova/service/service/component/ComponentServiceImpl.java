package com.nn.sova.service.service.component;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.dao.component.ComponentServiceDao;
import com.nn.sova.service.dao.component.ComponentServiceDaoImpl;

/**
 * ComponentServiceImpl class is used to access demo table information.
 *
 * @author Vignesh Palanisamy
 */
public class ComponentServiceImpl implements ComponentService {

	private final ComponentServiceDao componentServiceDao;

	/**
	 * ComponentServiceImpl is a constructor used to initialize the value for
	 * componentServiceDao
	 *
	 */
	public ComponentServiceImpl() {
		componentServiceDao = new ComponentServiceDaoImpl();
	}

	/**
	 * getComponents will get components data
	 * 
	 */
	@Override
	public Map<String, Object> getComponents() throws Exception {
		return componentServiceDao.getComponents();
	}

	/**
	 * upsertComponentInlineStyleV3 will upsert components data v3
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> upsertComponentInlineStyleV3(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.upsertComponentInlineStyleV3(updateList);
	}

	/**
	 * upsertInlineStylePropsDataV3 will upsert inline component props data v3
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> upsertInlineStylePropsDataV3(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.upsertInlineStylePropsDataV3(updateList);
	}
	
	/**
	 * upsertTenantThemeDetails will upsert tenant theme details
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> upsertTenantThemeDetails(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.upsertTenantThemeDetails(updateList);
	}
	
	/**
	 * insertThemeDetails will insert theme details
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> insertThemeDetails(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.insertThemeDetails(updateList);
	}
	
	/**
	 * upsertThemeDetails will update theme details
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> upsertThemeDetails(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.upsertThemeDetails(updateList);
	}
	
	/**
	 * insertTemplate will insert template name
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> insertTemplate(List<Map<String, Object>> insertList) throws Exception {
		return componentServiceDao.insertTemplate(insertList);
	}
	
	/**
	 * copyTemplate will insert template name
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> copyTemplate(List<Map<String, Object>> copyList, String compName, String newTemplateName, String existingTemplateName) throws Exception {
		return componentServiceDao.copyTemplate(copyList, compName, newTemplateName, existingTemplateName);
	}
	
	/**
	 * insertVariants will insert Variant for the component
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> insertVariants(List<Map<String, Object>> insertList) throws Exception {
		return componentServiceDao.insertVariants(insertList);
	}
	
	/**
	 * copyVariants will insert existing Variant for the component
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> copyVariants(List<Map<String, Object>> copyList, String compName, String selectedTemplate, String existedVariantText) throws Exception {
		return componentServiceDao.copyVariants(copyList, compName, selectedTemplate, existedVariantText);
	}
	
	/**
	 * deleteTemplate will delete template name
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> deleteTemplate(String templateName) throws Exception {
		return componentServiceDao.deleteTemplate(templateName);
	}
	
	/**
	 * deleteVariant will delete Variant for the component
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> deleteVariant(String styleType, String templateType) throws Exception {
		return componentServiceDao.deleteVariant(styleType, templateType);
	}
	
	/**
	 * makeDefaultVariant will make Variant as default for the component
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> makeDefaultVariant(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.makeDefaultVariant(updateList);
	}
	
	/**
	 * removeDefaultVariant will make Variant as default for the component
	 * 
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> removeDefaultVariant(List<Map<String, Object>> updateList) throws Exception {
		return componentServiceDao.removeDefaultVariant(updateList);
	}

	/**
	 * updateTemplate will update template data
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> updateTemplate(List<Map<String, Object>> updateList) throws QueryException {
		return componentServiceDao.updateTemplate(updateList);
	}
	
	/**
	 * updateVariant will update variant data
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> updateVariant(List<Map<String, Object>> updateList) throws QueryException {
		return componentServiceDao.updateVariant(updateList);
	}

	@Override
	public boolean validateIsTemplateExist(String templateName) throws QueryException {
		return componentServiceDao.validateIsTemplateExist(templateName);
	}
	
	@Override
	public boolean validateIsThemeExist(String themeName) throws QueryException {
		return componentServiceDao.validateIsThemeExist(themeName);
	}
	
	/**
	 * defaultThemeForTenant will insert theme data for tenant
	 * 
	 * @throws QueryException 
	 */
	@Override
	public Map<String, Object> defaultThemeForTenant(String themeName) throws QueryException {
		return componentServiceDao.defaultThemeForTenant(themeName);
	}
}
