package com.nn.sova.service.workflow.enums;

import java.util.Arrays;

import lombok.Getter;

/**
 * ApprovalStatusEnum class provides approval business status.
 * @author punithanantony.d@vaken.cloud (Punithan Antony Das)
 *
 */
public enum ApprovalStatusEnum {
	
	
	/** The application submitted status */
	SUBMITTED("SUBMITTED", true),
	
	/** The application not submitted status */
	NOT_SUBMITTED("NOT SUBMITTED", true),
	
	/** The application approved status */
	APPROVED("APPROVED", true),
	
	/** The application rejected status */
	REJECTED("REJECTED", false),
	
	/** The application rejected confirmation status */
	REJECTED_CONFIRM("REJECTED CONFIRM", false),
	
	/** The application sent back status */
	SENTBACK("SENTBACK", false),
	
	/** The application sent back confirmation status */
	SENTBACK_CONFIRM("SENTBACK CONFIRM", false),
	
	/** The application withdraw status */
	WITHDRAWN("WITHDRAWN", false),
	
	/** The application withdraw confirmation status */
	WITHDRAWN_CONFIRM("WITHDRAWN CONFIRM", false),
	
	/** The application to confirm status */
	CONFIRM("CONFIRM", false),
	
	/** The application confirmed status */
	CONFIRMED("CONFIRMED", false),
	
	/** The application in progress status */
	INPROGRESS("INPROGRESS", true),
	
	/** The VOID status*/
	NONE("NEW", true),
	
	/** The urgent status */
	URGENT("URGENT", true),
	
	/** The application need to submit */
	SUBMIT("SUBMIT", true),
	
	/** The application verify status */
	VERIFY("VERIFY", true),
	
	/** The application verified status */
	VERIFIED("VERIFIED", true),
	
	/** The application verified status */
	NOT_VERIFIED("NOT VERIFIED", false),
	
	/** The DRAFT status */
	DRAFT("DRAFT", true),
	
	/** The DISCARD status */
	DISCARD("DISCARD", false),
	
	/** The master status */
	MASTER("MASTER", true),
	
	/** The master status */
	PROXY("PROXY", true),
	
	/** The approver menu status */
	AWAITING("AWAITING", true),
	
	/** The failed status */
	FAILED("FAILED", false),
	
	/** The duplicate status */
	DUPLICATE("DUPLICATE", false);
	
	@Getter
	private String value;
	
	@Getter
	private boolean isPostiveAction;
	
	/**
	 * ApprovalStatusEnum class return value of enum.
	 * @param value
	 */
	private ApprovalStatusEnum(String value, boolean type) {
		this.value = value;
		isPostiveAction = type;
	}
	
	/**
	 * ApprovalStatusEnum class return enum of value.
	 * @param enum
	 */
	public static ApprovalStatusEnum getEnum(String value) {
        return Arrays.stream(ApprovalStatusEnum.values()).filter(t -> t.value.equals(value)).findFirst().orElse(NONE);
    }
	
}
