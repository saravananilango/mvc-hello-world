package com.nn.sova.service.dao.tablequery;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * TableQueryDao interface
 * 
 * @author Vivek Kannan E
 */
public interface TableQueryDao {

	public List<Map<String, Object>> getSuggestion(String productCode, String targetText) throws QueryException;

}