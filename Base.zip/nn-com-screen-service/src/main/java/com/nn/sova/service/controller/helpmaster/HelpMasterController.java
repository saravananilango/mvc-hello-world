package com.nn.sova.service.controller.helpmaster;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.controller.ComponentAttributeController;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.ScreenDefTypeEnum;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.service.helpmaster.HelpMasterService;
import com.nn.sova.service.service.helpmaster.HelpMasterServiceImpl;

@SovaMapping("/helpMaster")
public class HelpMasterController extends ComponentAttributeController {

    /** The HelpMasterService */
    private final HelpMasterService helpMasterService;

    /**
	 * HelpMasterController is a constructor used to initialize the value for
	 * helpMasterService
	 *
	 */
    public HelpMasterController() {
        helpMasterService = new HelpMasterServiceImpl();
    }

    /**
	 * getHelpMasterData method is to get help data from the screen
	 * 
	 * @param paramMap
	 * @return Map of data
	 */
	@SovaMapping(value = "/getData", method = SovaRequestMethod.GET)
    public Map<String, Object> getHelpMasterData(SovaHttpRequest request, SovaHttpResponse response) throws IOException, QueryException {
		Map<String, String> paramMap = request.getQueryParameters();
//		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, Object> returnMap = new HashMap<>();
        String screenId = String.valueOf(paramMap.get("screenId"));
        String helpMasterId = String.valueOf(paramMap.get("helpMasterId"));
        Map<String, Object> helpMasterDataMap = helpMasterService.getHelpMasterData(screenId, helpMasterId);
        List<FrontVo> dataElementList = getComponentElementData(ScreenDefTypeEnum.HELP_MASTER.getValue(), helpMasterId);
        returnMap.put("helpMasterTemplate", helpMasterDataMap);
        returnMap.put("helpMasterDataElement", dataElementList);
        return returnMap;
    }

    /**
	 * deleteCacheByKey method is to delete the cache data by screen key
	 * 
	 * @param paramMap
	 * @return
	 * @throws IOException 
	 */
    @SovaMapping(value = "/deleteCacheByKey", method = SovaRequestMethod.GET)
    public String deleteCacheByKey(SovaHttpRequest request, SovaHttpResponse response) {
		Map<String, String> paramMap = request.getQueryParameters();
//		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        String screenId = String.valueOf(paramMap.get("screenId"));
        return helpMasterService.deleteCacheByKey(screenId);
    }

    /**
	 * deleteAllCache method is to delete all the screenId cache
	 * 
	 * @param paramMap
	 * @return
	 */
    @SovaMapping(value = "/deleteAllCache", method = SovaRequestMethod.GET)
    public String deleteAllCache(SovaHttpRequest request, SovaHttpResponse response) {
        return helpMasterService.deleteAllCache();
    }

    /**
	 * convertToTitleCase method is to convert hyphen separated string to Title case
	 * 
	 * @param hyhenSeperatedString
	 * @return String
	 */
    private String convertToTitleCase(String hyhenSeperatedString) {
        if (StringUtils.isEmpty(hyhenSeperatedString)) {
            return StringUtils.EMPTY;
        }
        String[] splittedArray = hyhenSeperatedString.split("-");
        StringBuilder stringBuilder = new StringBuilder();
        for (String currentString : splittedArray) {
            stringBuilder.append(currentString.substring(0, 1).toUpperCase() + currentString.substring(1).toLowerCase());
        }
        return stringBuilder.toString();
    }
}
