package com.nn.sova.service.constants.tabledefinition;

import java.util.Arrays;
import java.util.List;

/**
 * TableDefinitionConstants contains constant entry for table definition
 * 
 * @author MOHAN RAM
 *
 */
public class TableDefinitionConstants {
	/**
	 * Default error message key for all apis
	 */
	public static final String ERROR_KEY = "error";
	/**
	 * camel case for table configuration table
	 */
	public static final String TABLE_CONFIGURATION_TABLE ="tableConfiguration";
	/**
	 * camel case for table class configuration table
	 * 
	 */
	public static final String CLASS_CONFIGURATION_TABLE ="class_configuration";
	/**
	 * Default error message content key for all apis
	 */
	public static final String ERROR_MESSAGE_KEY = "message";
	/**
	 * PrimaryKey List for table_definition_table It will be removed when cache
	 * is implemented
	 */
	public static final List<String> TABLE_DEFINITION_PRIMARY_KEY_LIST = Arrays.asList("table_name","product_code","tenant_id");
	/**
	 * PrimaryKey List for table_definition_column_details It will be removed
	 * when cache is implemented
	 */
	public static final List<String> TABLE_DEFINITION_COLUMN_DETAILS_PRIMARY_KEY_LIST = Arrays.asList("table_name",
			"column_name","product_code","tenant_id");
	/**
	 * PrimaryKey List for table_unique_definition It will be removed when cache
	 * is implemented
	 */
	public static final List<String> TABLE_DEFINITION_UNIQUE_DEFINITION_PRIMARY_KEY_LIST = Arrays
			.asList("table_name", "unique_key_name","product_code","tenant_id");
	/**
	 * PrimaryKey List for table_definition_foreign_constraints_details It will
	 * be removed when cache is implemented
	 */
	public static final List<String> TABLE_DEFINITION_FOREIGN_KEY_DEFINITION_PRIMARY_KEY_LIST = Arrays
			.asList("table_name", "foreign_key_name","product_code","tenant_id");
	/**
	 * PrimaryKey List for table_index_definition It will be removed when cache
	 * is implemented
	 */
	public static final List<String> TABLE_DEFINITION_INDEX_DEFINITION_PRIMARY_KEY_LIST = Arrays.asList("table_name",
			"index_name","product_code","tenant_id");
	/**
	 * Key for offline table_definition table contains Map<?String,?Object>
	 */
	public static final String TABLE_DEFINITION_MAP = "tableMap";
	/**
	 * Key for offline table_definition_column_details table contains
	 * List<Map<?String,?Object>>
	 */
	public static final String TABLE_DEFINITION_DETAILS_MAP = "tableDetailsMap";
	/**
	 * Key for offline table_definition_foreign_constraints_details table
	 * contains List<Map<?String,?Object>>
	 * 
	 */
	public static final String TABLE_DEFINITION_FOREIGN_DETAILS_MAP = "tableDetailsForeignMap";
	/**
	 * Key for offline table_unique_definition table contains
	 * List<Map<?String,?Object>>
	 */
	public static final String TABLE_DEFINITION_UNIQUE_DETAILS_MAP = "tableDetailsUniqueMap";
	/**
	 * Key for offline table_index_definition table contains
	 * List<Map<?String,?Object>>
	 */
	public static final String TABLE_DEFINITION_INDEX_DETAILS_MAP = "tableDetailsIndexMap";
	/**
	 * Key for Edit table_definition table contains Map<?String,?Object>
	 */
	public static final String TABLE_DEFINITION_EDITED_MAP = "tableEditMap";
	/**
	 * Key for Edit table_definition_column_details table contains
	 * List<Map<?String,?Object>>
	 */
	public static final String TABLE_DEFINITION_EDITED_DETAILS_MAP = "tableDetailsEditMap";
	/**
	 * Key for Edit table_definition_foreign_constraints_details table contains
	 * List<Map<?String,?Object>>
	 * 
	 */
	public static final String TABLE_DEFINITION_EDITED_FOREIGN_DETAILS_MAP = "tableDetailsEditForeignMap";
	/**
	 * Key for Edit table_unique_definition table contains
	 * List<Map<?String,?Object>>
	 */
	public static final String TABLE_DEFINITION_EDITED_UNIQUE_DETAILS_MAP = "tableDetailsEditUniqueMap";
	/**
	 * Key for Edit table_index_definition table contains
	 * List<Map<?String,?Object>>
	 */
	public static final String TABLE_DEFINITION_EDITED_INDEX_DETAILS_MAP = "tableDetailsEditIndexMap";
	/**
	 * Table for table_definition_meta in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_META = "tableDefinitionOffline";
	/**
	 * Table for table_definition in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_MAIN = "tableDefinition";
	/**
	 * Table for table_definition_column_details_meta in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_COLUMN_DETAILS_META = "tableDefinitionColumnDetailsOffline";
	/**
	 * Table for table_definition_column_details in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_COLUMN_DETAILS_MAIN = "tableDefinitionColumnDetails";
	/**
	 * Table for table_index_definition_meta in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_INDEX_DETAILS_META = "tableIndexDefinitionOffline";
	/**
	 * Table for table_definition_foreign_constraints_details_meta in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_FOREIGN_DETAILS_META = "tableForeignConstraintsDetailsOffline";
	/**
	 * Table for table_index_definition in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_INDEX_DETAILS_MAIN = "tableIndexDefinition";
	/**
	 * Table for table_definition_foreign_constraints_details in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_FOREIGN_DETAILS_MAIN = "tableForeignConstraintsDetails";
	/**
	 * Table for table_unique_definition_meta in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_UNIQUE_DETAILS_META = "tableUniqueConstraintDefinitionOffline";
	/**
	 * Table for table_unique_definition in camel case
	 * 
	 */
	public static final String TABLE_DEFINITION_UNIQUE_DETAILS_MAIN = "tableUniqueConstraintDefinition";
	/**
	 * Key for table name
	 */
	public static final String TABLE_NAME = "table_name";
	/**
	 * Key for table name
	 */
	public static final String TABLENAME = "tableName";
	/**
	 * key for application name
	 */
	public static final String PRODUCT_CODE = "productCode";
	/**
	 * key for database handler
	 */
	public static final String DATABASE_HANDLER = "databaseHandler";
	/**
	 * key for system id
	 */
	public static final String SYSTEM_ID = "systemId";
	/**
	 * key for table count
	 */
	public static final String COUNT = "count";
	/**
	 * column name for count query
	 */
	public static final String COUNT_SELECT_COLUMN = "*";
	/**
	 * POSTGRESQL_DB for drive starts with
	 */
	public static final String POSTGRESQL_DB = "jdbc:postgresql://";
	/**
	 * database password key
	 */
	public static final String PASSKEY = "password";
	/**
	 * database schema key
	 */
	public static final String SCHEMA = "schema";
	/**
	 * database user key
	 */
	public static final String USER = "user";
	/**
	 * database url key
	 */
	public static final String URL_KEY = "url";
	/**
	 * databse drive key
	 */
	public static final String DRIVER_KEY = "driver";
	/**
	 * database name key
	 */
	public static final String DATABASE_NAME = "database_name";
	/**
	 * database host key
	 */
	public static final String HOST = "host";
	/**
	 * database port key
	 */
	public static final String PORT = "port";
	/**
	 * table name for master definition main
	 */
	public static final String MASTER_DEFINITION_MAIN = "masterDefinition";
	/**
	 * table name for data element definition meta
	 */
	public static final String DATA_ELEMENT_DEFINTION_META = "dataElementDefinitionMeta";
	/**
	 * table name for data element definition main
	 */
	public static final String DATA_ELEMENT_DEFINTION_MAIN = "dataElementDefinition";
	/**
	 * table name for data class definition main
	 */
	public static final String DATA_FORMAT_DEFINTION_MAIN = "dataFormatDefinition";
	/**
	 * table name for data class definition meta
	 */
	public static final String DATA_FORMAT_DEFINTION_META = "dataFormatDefinitionMeta";
	/**
	 * table name for charset definition main
	 */
	public static final String CHARSET_DEFINTION_MAIN = "charsetDefinition";
	/**
	 * table name for charset definition meta
	 */
	public static final String CHARSET_DEFINTION_META = "charsetDefinitionMeta";
	/**
	 * key for getting offline data element list
	 */
	public static final String OFFLINE_DATA_ELEMENT_LIST = "offlineDataElementList";
	/**
	 * key for getting offline data class list
	 */
	public static final String OFFLINE_DATA_FORMAT_LIST = "offlineDataClassList";
	/**
	 * key for getting offline charset list
	 */
	public static final String OFFLINE_CHARSET_LIST = "offlineCharsetList";
	/**
	 * key for getting online data element list
	 */
	public static final String ONLINE_DATA_ELEMENT_LIST = "onlineDataElementList";
	/**
	 * key for getting online data class list
	 */
	public static final String ONLINE_DATA_FORMAT_LIST = "onlineDataClassList";
	/**
	 * key for data class details
	 */
	public static final String DATA_FORMAT_DETAILS = "dataFormatDetails";
	/**
	 * key for data element details
	 */
	public static final String DATA_ELEMENT_DETAILS = "dataElementDetails";
	/**
	 * key for string data type
	 */
	public static final String STRING_DATA_TYPE = "string";
	/**
	 * online key
	 */
	public static final String ONLINE ="online";
	/**
	 * offline key
	 */
	public static final String OFFLINE ="offline";
	/**
	 * key for time data type
	 */
	public static final String TIME_DATA_TYPE = "time";
	/**
	 * key for timestamp data type
	 */
	public static final String TIMESTAMP_DATA_TYPE = "timestamp";
	/**
	 * key for boolean data type
	 */
	public static final String BOOLEAN_DATA_TYPE = "boolean";
	/**
	 * key for number data type
	 */
	public static final String NUMBER_DATA_TYPE = "number";
	/**
	 * NUMERIC_DATATYPE FOR POSTGRES
	 */
	public static final String NUMERIC_DATATYPE = "numeric";
	/**
	 * TEXT_DATATYPE FOR POSTGRES
	 */
	public static final String TEXT_DATATYPE = "text";
	/**
	 * BOOL_DATATYPE FOR POSTGRES
	 */
	public static final String BOOL_DATATYPE = "bool";
	/**
	 * TIMESTAMP_WITHOUT_TIME_ZONE_DATATYPE FOR POSTGRES
	 */
	public static final String TIMESTAMP_WITHOUT_TIME_ZONE_DATATYPE = "timestamp without time zone";
	/**
	 * Edit key
	 */
	public static final String EDIT = "edit";
	/**
	 * key for offline index details change
	 */
	public static final String TABLE_INDEX_COLUMN_DETAILS_OFFLINE_CHANGE = "tableIndexColumnDetailsOfflineChange";
	/**
	 * key for unique offline changes
	 */
	public static final String TABLE_UNIQUE_DETAILS_OFFLINE_CHANGE = "tableUniqueDetailsOfflineChange";
	/**
	 * key for foreign key offline changes
	 */
	public static final String TABLE_FOREIGN_KEY_DETAILS_OFFLINE_CHANGE = "tableForeignKeyDetailsOfflineChange";
	/**
	 * key for column details changes
	 */
	public static final String TABLE_COLUMN_DETAILS_OFFLINE_CHANGE = "tableColumnDetailsOfflineChange";
	/**
	 * REPO_NAME key for repo name
	 */
	public static final String REPO_NAME = "repoName";
	/**
	 * CHANGE_REQUEST_ID key for changeRequestId
	 */
	public static final String CHANGE_REQUEST_ID = "changeRequestId";
	/**
	 * repoStatus for change request repo status
	 */
	public static final String REPO_STATUS ="repoStatus";
	/**
	 * errorMessage for change request error message
	 */
	public static final String ERROR_MESSAGE ="errorMessage";
	/**
	 * errorStage used for change request stage
	 */
	public static final String ERROR_STAGE ="errorStage";
	/**
	 * var char data type postgres value value
	 */
	public static final String CHARACTER_VARYING_DATATYPE = "character varying";
	/**
	 * var char data type division key
	 */
	public static final String VARCHAR_DATATYPE = "varchar";
	/**
	 * key for max length
	 */
	public static final String MAX_LENGTH = "max_length";
	/**
	 * key for decimal value
	 */
	public static final String DECIMAL_VALUE = "decimal_value";
	/**
	 * key for default value
	 */
	public static final String DEFAULT_VALUE = "default_value";
	/**
	 * PRIMARY_VALUE VALUE LOCK
	 */
	public static final String PRIMARY_VALUE = "primaryValue";
	/**
	 * MASTER_PRIMARY_KEY_LIST contains master primary key list
	 */
	public static final List<String> MASTER_PRIMARY_KEY_LIST = Arrays.asList("master_id");
	/**
	 * CHARSET_PRIMARY_KEY_LIST contains charset primary key list
	 */
	public static final List<String> CHARSET_PRIMARY_KEY_LIST = Arrays.asList("charset_id");
	/**
	 * DATA_FORMAT_PRIMARY_KEY_LIST contains data class primary key list
	 */
	public static final List<String> DATA_FORMAT_PRIMARY_KEY_LIST = Arrays.asList("data_format");
	/**
	 * DATA_ELEMENT_PRIMARY_KEY_LISTcontains data element primary key list
	 */
	public static final List<String> DATA_ELEMENT_PRIMARY_KEY_LIST = Arrays.asList("data_element");
	/**
	 * table_definiton_request_history_details table name in camel case
	 */
	public static final String TABLE_DEFINITION_REQUEST_HISTORY_DETAILS = "tableDefinitonRequestHistoryDetails";
	/**encrypt column 
	 */
	public static final String TABLE_DEFINITION_ENCRYPT_KEY = "encrypt___key";
}

