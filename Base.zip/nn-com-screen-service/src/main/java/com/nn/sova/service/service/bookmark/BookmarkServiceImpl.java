package com.nn.sova.service.service.bookmark;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.core.CacheManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.dao.bookmark.BookmarkDao;
import com.nn.sova.service.dao.bookmark.BookmarkDaoImpl;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * BookmarkServiceImpl class is to do operations regarding bookmarks.
 * 
 * @author Mohammed Shameer U
 *
 */
public class BookmarkServiceImpl implements BookmarkService {

	/** The logger */
	private static final ApplicationLogger logger = ApplicationLogger.create(BookmarkServiceImpl.class);
	
	/** The STATUS */
	private static final String STATUS = "status";
	
	/** The BOOKMARK_NAME */
	private static final String BOOKMARK_NAME = "bookmarkName";
	
	/** The IS_PRIVATE */
	private static final String IS_PRIVATE = "isPrivate";
	
	/** The COMPONENT_ID */
	private static final String COMPONENT_ID = "component_id";
	
	/** The DEFAULT_FLAG */
	private static final String DEFAULT_FLAG = "default_flag";
	
	/** The SHARED_USER */
	private static final String SHARED_USER = "sharedUser";
	
	/** The SHARED_BY_USER */
	private static final String SHARED_BY_USER = "shared_by_user";
	
	/** The SHARED */
	private static final String SHARED = "shared";

	/** The Constant BookmarkDao **/
	private BookmarkDao bookmarkDao;

	/**
	 * BookmarkServiceImpl constructor
	 */
	public BookmarkServiceImpl() {
		bookmarkDao = new BookmarkDaoImpl();
	}

	@Override
	public Map<String, Object> getBookmarkData() {
		String cacheKey = getBookmarkKey(ContextBean.getUserId());
		Map<String, Object> resultList = (Map<String, Object>) CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.nonNull(resultList)) {
			return resultList;
		}
		return updateUserBookmarkData(cacheKey);
	}
	
	/**
	 * getBookmarkKey is used to get the bookmark key
	 * 
	 * @param userId
	 * @return
	 */
	private String getBookmarkKey(String userId) {
		return CacheKeyHelper.getUserBookmarkKey(userId, ContextBean.getSid());
	}

	/**
	 * updateUserBookmarkData is used to update the bookmark data.
	 * 
	 * @param cacheKey
	 * @return
	 */
	private Map<String, Object> updateUserBookmarkData(String cacheKey) {
		Map<String, Object> resultMap = new HashMap<>();
		if (Objects.nonNull(ContextBean.getSid())) {
			try {
				resultMap.put(STATUS, true);
				resultMap.put("data",
						formBookmarkEntity(bookmarkDao.getUserBookmarkData(), bookmarkDao.getSharedBookmarkData()));
				CacheManager.getInstance().saveAsObject(cacheKey, resultMap);
			} catch (QueryException e) {
				logger.error("Error while getting bookmark data of the screen", e);
				resultMap.put(STATUS, false);
			}
		} else {
			resultMap.put(STATUS, false);
		}
		return resultMap;
	}

	private List<Map<String, Object>> formBookmarkEntity(List<Map<String, Object>> bookmarkData,
			List<Map<String, Object>> bookmarkSharedData) {
		List<Map<String, Object>> bookmarkCompleteData = new ArrayList<>();
		String userId = ContextBean.getUserId();
		bookmarkCompleteData.addAll(bookmarkData.stream().map(mapper -> {
			Map<String, Object> dataMap = new HashMap<>();
			dataMap.put(BOOKMARK_NAME, mapper.get("bookmark_name"));
			dataMap.put("componentId", JsonUtils.fromJsonOrNull(String.valueOf(mapper.get(COMPONENT_ID)), Map.class));
			dataMap.put("userId", userId);
			dataMap.put(IS_PRIVATE, true);
			dataMap.put("isDefault",
					Objects.nonNull(mapper.get(DEFAULT_FLAG)) ? Boolean.valueOf(mapper.get(DEFAULT_FLAG).toString())
							: false);
			return dataMap;
		}).collect(Collectors.toList()));
		bookmarkCompleteData.addAll(bookmarkSharedData.stream().map(mapper -> {
			Map<String, Object> dataMap = new HashMap<>();
			dataMap.put(BOOKMARK_NAME, mapper.get("bookmark_name"));
			dataMap.put(SHARED_USER, mapper.get(SHARED_BY_USER));
			dataMap.put("componentId", JsonUtils.fromJsonOrNull(String.valueOf(mapper.get(COMPONENT_ID)), Map.class));
			Map<String, Object> userDataByTenantId;
			try {
				userDataByTenantId = CacheService.getInstance()
						.getUserDataByTenantId(String.valueOf(mapper.get(SHARED_BY_USER)));
				dataMap.put("sharedUserName",
						String.join(" ", String.valueOf(userDataByTenantId.get("first_name")),
								Objects.nonNull(userDataByTenantId.get("last_name"))
										? String.valueOf(userDataByTenantId.get("last_name"))
										: StringUtils.EMPTY));
			} catch (QueryException e) {
				dataMap.put("sharedUserName", mapper.get(SHARED_BY_USER));
			}
			dataMap.put("userId", userId);
			dataMap.put(IS_PRIVATE, false);
			dataMap.put("isDefault",
					Objects.nonNull(mapper.get(DEFAULT_FLAG)) ? Boolean.valueOf(mapper.get(DEFAULT_FLAG).toString())
							: false);
			return dataMap;
		}).collect(Collectors.toList()));
		return bookmarkCompleteData;
	}

	@Override
	public Map<String, Object> insertBookmarkData(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		try {
			if (StringUtils.isNotEmpty(ContextBean.getSid())) {
				bookmarkDao.insertBookmarkData(paramMap);
				clearCacheBookmarkData(Arrays.asList(ContextBean.getUserId()));
				resultMap.put(STATUS, true);
			} else {
				resultMap.put(STATUS, false);
				logger.info("Exception occured while inserting bookmark data because service id is not present");
			}
		} catch (QueryException e) {
			logger.error("Exception occured while inserting bookmark data", e);
			resultMap.put(STATUS, false);
		}
		return resultMap;
	}

	@Override
	public Map<String, Object> deleteBookmarkData(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		String bookmarkName = String.valueOf(paramMap.get(BOOKMARK_NAME));
		boolean status = paramMap.containsKey(SHARED) && Boolean.valueOf(String.valueOf(paramMap.get(SHARED)));
		try {
			if (status) {
				bookmarkDao.deleteSharedBookmarkData(bookmarkName, String.valueOf(paramMap.get(SHARED_USER)));
			} else {
				bookmarkDao.deleteBookmarkData(bookmarkName);
			}
			CacheService.getInstance().removeCacheByKey(getBookmarkKey(ContextBean.getUserId()));
			resultMap.put(STATUS, true);
		} catch (QueryException e) {
			logger.error("Exception occured while deleting bookmark data", e);
			resultMap.put(STATUS, true);
		}
		return resultMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> shareBookmarkData(Map<String, Object> paramMap) {
		Map<String, Object> dataMap = new HashMap<>();
		Map<String, Object> bookmarkData = getBookmarkData(paramMap);
		List<Object> usersList = (List<Object>) paramMap.get("userList");
		try {
			bookmarkDao.shareBookmarkData(bookmarkData, usersList);
			clearCacheBookmarkData(usersList);
			dataMap.put(STATUS, true);
		} catch (QueryException e) {
			logger.error("Error occured while sharing bookmark data", e);
			dataMap.put(STATUS, false);
		}
		return dataMap;
	}
	
	/**
	 * clearCacheBookmarkData is used to clear the cache bookmark data.
	 * 
	 * @param usersList
	 */
	private void clearCacheBookmarkData(List<Object> usersList) {
		usersList.stream().forEach(action-> 
			CacheService.getInstance().removeCacheByKey(getBookmarkKey(String.valueOf(action))));
	}

	@Override
	public Map<String, Object> markDefaultBookmarkData(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		String bookmarkName = String.valueOf(paramMap.get(BOOKMARK_NAME));
		try {
			if ((boolean)paramMap.get(IS_PRIVATE)) {
				bookmarkDao.markPrivateDefaultBookmarkData(bookmarkName);
			} else {
				bookmarkDao.markSharedDefaultBookmarkData(bookmarkName, String.valueOf(paramMap.get(SHARED_USER)));
			}
			CacheService.getInstance().removeCacheByKey(getBookmarkKey(ContextBean.getUserId()));
			resultMap.put(STATUS, true);
		} catch (QueryException e) {
			logger.error("Exception occured while making default bookmark data", e);
			resultMap.put(STATUS, false);
		}
		return resultMap;
	}

	@Override
	public Map<String, Object> getBookmarkDataByName(Map<String, Object> paramMap) {
		Map<String, Object> bookmarkData = getBookmarkData(paramMap);
		Map<String, Object> resultMap = new HashMap<>();
		if (MapUtils.isNotEmpty(bookmarkData)) {
			resultMap.put(STATUS, true);
			resultMap.put("data",
					JsonUtils.fromJsonOrNull(String.valueOf(bookmarkData.get(COMPONENT_ID)), Map.class));
		}
		return resultMap;
	}

	/**
	 * getBookmarkData is used to get the bookmark data by name
	 * 
	 * @param paramMap
	 * @return
	 */
	private Map<String, Object> getBookmarkData(Map<String, Object> paramMap) {
		List<Map<String, Object>> dataList = new ArrayList<>();
		try {
			if (Objects.nonNull(paramMap.get(SHARED)) && (boolean)paramMap.get(SHARED)) {
				dataList.addAll(bookmarkDao.getSharedBookmarkDataByName(String.valueOf(paramMap.get(BOOKMARK_NAME)),
						String.valueOf(paramMap.get(SHARED_USER))));
			} else {
				dataList.addAll(bookmarkDao.getPrivateBookmarkDataByName(String.valueOf(paramMap.get(BOOKMARK_NAME))));
			}
			if (CollectionUtils.isNotEmpty(dataList)) {
				return dataList.get(0);
			}
		} catch (QueryException e) {
			logger.error("Error occured while getting bookmark data by name", e);
			return new HashMap<>();
		}
		return new HashMap<>();
	}

	@Override
	public Map<String, Object> removeDefaultBookmarkData(Map<String, Object> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		String bookmarkName = String.valueOf(paramMap.get(BOOKMARK_NAME));
		try {
			if ((boolean)paramMap.get(IS_PRIVATE)) {
				bookmarkDao.removePrivateDefaultBookmarkData(bookmarkName);
			} else {
				bookmarkDao.removeSharedDefaultBookmarkData(bookmarkName, String.valueOf(paramMap.get(SHARED_USER)));
			}
			CacheService.getInstance().removeCacheByKey(getBookmarkKey(ContextBean.getUserId()));
			resultMap.put(STATUS, true);
		} catch (QueryException e) {
			logger.error("Exception occured while making default bookmark data", e);
			resultMap.put(STATUS, false);
		}
		return resultMap;
	}
}