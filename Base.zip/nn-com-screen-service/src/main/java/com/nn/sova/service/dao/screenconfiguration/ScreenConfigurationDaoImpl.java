package com.nn.sova.service.dao.screenconfiguration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Iterables;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * ScreenConfigurationDaoImpl class if for screen_configuration table database
 * operations.
 * 
 * @author johnpeje
 *
 */
public class ScreenConfigurationDaoImpl implements ScreenConfigurationDao {

    /** The Constant LOGGER **/
    private static final ApplicationLogger LOGGER = ApplicationLogger.create(ScreenConfigurationDaoImpl.class);
    
    /** SCREEN_CONFIGURATION_TEXT Details Constants */
	private static final String SCREEN_CONFIGURATION = "screen_configuration";
	private static final String ALIAS_CONF = "conf";
	private static final String CONF_SCREEN_ID = "conf.screen_id";

    /**
     * Gets the screen configuration data.
     *
     * @param screenId the screen id
     * @return the screen configuration data
     */
	@Override
	public Map<String, Object> getScreenConfigurationData(String screenId) {
		if (StringUtils.isEmpty(screenId)) {
			return new HashMap<>();
		}
		QueryBuilder queryBuilder = new QueryBuilder().btSchema();

		ConditionBuilder condition = ConditionBuilder.instance();
		condition.eq("screen_id", screenId);

		SelectQueryBuilder selectBuilder = queryBuilder.select().from("screen_configuration").where(condition);
		try {
			List<Map<String, Object>> fetchedData = selectBuilder.build(false).execute();
			return Iterables.getFirst(fetchedData, new HashMap<>());
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}

		return new HashMap<>();
	}

    /**
     * To delete screen configuration by screen definitions id.
     *
     * @param dataMap  the data map
     * @param executor the executor
     * @throws Exception the exception
     */
    @Override
    public void deleteByScreenIds(Map<String, Object> dataMap, QueryExecutor executor) throws Exception {
        List<Object> screenDefintionIds = CommonUtils.getListForReference(dataMap.get("data"),
                new TypeReference<Object>() {
                });
        boolean skipChangeRequest = true;
        if (dataMap.containsKey("skipChangeRequest")) {
            skipChangeRequest = CommonUtils.getNonNullBoolean(dataMap.get("skipChangeRequest"));
        }
        if (CollectionUtils.isNotEmpty(screenDefintionIds)) {
            ConditionBuilder condition = ConditionBuilder.instance().inWithList("screen_id", screenDefintionIds);
            executor.queryBuilder().delete().skipTenantId(true).skipChangeRequest(skipChangeRequest)
                    .from("screen_configuration").where(condition).build().execute();
        }
    }

    @Override
	public String getScreenDefId(String screenId) throws QueryException {
		try {
			QueryBuilder queryBuilder = new QueryBuilder();
			ConditionBuilder conditionBuilder = ConditionBuilder.instance().eq(CONF_SCREEN_ID, screenId);
			List<Map<String, Object>> returnList = queryBuilder.select().from(SCREEN_CONFIGURATION, ALIAS_CONF)
					.where(conditionBuilder).build(false).execute();
			if (CollectionUtils.isNotEmpty(returnList)) {
				Map<String, Object> dataMap = returnList.get(0);
				return String.valueOf(dataMap.get("screen_definition_id"));
			}
		} catch (QueryException exception) {
			LOGGER.error("ERROR OCCURES WHILE FETCHING SCREEN DEF ID", exception);
			throw exception;
		}
		return null;
	}
}