package com.nn.sova.service.controller.roboticImport;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.postgresql.util.PGobject;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.file.CsvTextUtils;
import com.nn.sova.file.ExcelUtils;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.utility.jobmanager.exception.JobManagerJsonConversionException;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * RoboticImport Controller is used to control Robotic Import related operations.
 * 
 * @author Abhijith	
 */
@SovaMapping("/roboticImport")
public class RoboticImport {
	
	public static final String CSV = "csv";
	public static final String EXCEL = "xlsx";
	public static final String DEFAULT_DATATYPE = "string";
	
	/** logger class */
	private static ApplicationLogger logger = ApplicationLogger.create(RoboticImport.class);
	
	
	/**
	 * reads the data from param file and sents back data
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@SovaMapping(value = "/roboticImportProcess", method = SovaRequestMethod.POST)
	public void process(SovaHttpRequest request, SovaHttpResponse response) throws IOException
	{
		List<Object> gridData = new ArrayList<>();
		try{
			Map<String, Object> postParamMap = (Map<String, Object>) request.getBody();
			ObjectMapper objectMapper = JsonUtils.getObjectMapper();
			Map<String, String> headerMap = objectMapper.readValue(String.valueOf(postParamMap.get("headerMap")), new TypeReference<Map<String, String>>() {});
			Map<String, String> dataTypeMap = objectMapper.readValue(String.valueOf(postParamMap.get("dataTypeMap")), new TypeReference<Map<String, String>>() {});
			Boolean loadEmptyRows = Boolean.parseBoolean(String.valueOf(postParamMap.get("loadEmptyRows")));
			final List<MultipartFile> files = (List<MultipartFile>) postParamMap.get("importFile");
			File convertedFile = convert(files.get(0));
			gridData = formGridData(convertedFile, headerMap, null, dataTypeMap, loadEmptyRows);
 			FileUtils.deleteQuietly(convertedFile);
		}catch(Exception exception){
			logger.error("ERROR OCCURS WHILE PROCESSING FILE", exception);
			response.withBody("file_processing_failed: ".concat(exception.toString()));
			return;
		}
		response.withBody(JsonUtils.toPrettyJsonOrNull(gridData));
	}
	
	/**
	* To json string.
	*
	* @param json the json
	* @return the string
	*/
	public static String toJsonString(Object json) {
		String jsonString = null;
		if (json instanceof PGobject) {
			jsonString = ((PGobject)json).getValue();
		} else if (json instanceof String) {
			jsonString = ((String)json);
		} else {
		try {
			jsonString = JsonUtils.toJsonOrThrow(json);
		} catch (JsonConversionException exception) {
			throw new JobManagerJsonConversionException(exception);
		}
		}
		return jsonString;
	}
	
	/**
	 * formGridData
	 * 
	 * @param csv
	 * @param columnHeaderDataMap
	 * @param encodingFormat
	 * @param dataTypeMap 
	 * @param loadEmptyRows 
	 */
	public List<Object> formGridData(File file,
			Map<String, String> columnHeaderDataMap, Charset encodingFormat, Map<String, String> dataTypeMap, Boolean loadEmptyRows) {
		
		List<Object> gridDataList = new ArrayList<Object>();
		
		if(FilenameUtils.getExtension(file.getName()).equalsIgnoreCase(CSV)){
			try {
				List<Map<String, String>> sheetDataList = CsvTextUtils.readCsvwithHeaderKeyData(file, columnHeaderDataMap, null);
				beforeProcess(sheetDataList);
				gridDataList = sheetDataList.stream().map(sheetData -> {
					Map<String, Map<String, Object>> gridMap = new HashMap();
					Map<String, Object> columnMap = new HashMap();
					AtomicBoolean isEmpty = new AtomicBoolean(true);
					sheetData.entrySet().stream().forEach(columnData->{
						String dataType= dataTypeMap.containsKey(columnData.getKey())?dataTypeMap.get(columnData.getKey()):DEFAULT_DATATYPE;
						if(!ObjectUtils.isEmpty(columnData.getValue())){
							isEmpty.set(false);
						}
						columnMap.put(columnData.getKey(), processColumnData(columnData.getValue(), dataType));
					});
					validateRowData(columnMap);
					/** this logic is to avoid empty rows in grid data*/
					if(!loadEmptyRows) {
						 if(!isEmpty.get()) {
							 gridMap.put("data", columnMap);
						 }
		
					}else {
						gridMap.put("data", columnMap);
					}
				    return gridMap;
						}).collect(Collectors.toList());
				return gridDataList;
			} catch (Exception e) {
				e.printStackTrace();
				return new ArrayList<Object>();
			}
			
		}else if(FilenameUtils.getExtension(file.getName()).equalsIgnoreCase(EXCEL)) {
			try {
				Map<String, List<Map<String, Object>>> resultExcel = ExcelUtils.readExcel(file);				
				for (Map.Entry<String, List<Map<String, Object>>> entry : resultExcel.entrySet()) {
					List<Object> dataList = new ArrayList<>();
					entry.getValue().stream().forEach(sheetData -> {
						Map<String, Map<String, Object>> gridMap = new HashMap();
						Map<String, Object> columnMap = new HashMap();
						AtomicBoolean isEmpty = new AtomicBoolean(true);
						sheetData.entrySet().stream().forEach(columnData->{
							String dataType= dataTypeMap.containsKey(columnData.getKey())?dataTypeMap.get(columnData.getKey()):DEFAULT_DATATYPE;
							if(!ObjectUtils.isEmpty(columnData.getValue())){
								isEmpty.set(false);
							}
							if(!columnData.getKey().equals(columnData.getValue())) {								
								columnMap.put(columnData.getKey(), processColumnData(columnData.getValue(), dataType));
							}
						});
						validateRowData(columnMap);
						/** this logic is to avoid empty rows in grid data*/
						if(MapUtils.isNotEmpty(columnMap)) {
							if(!loadEmptyRows) {
								if(!isEmpty.get()) {
									gridMap.put("data", columnMap);
								}
								
							}else {
								gridMap.put("data", columnMap);
							}
							dataList.add(gridMap);
						}
					});
					gridDataList.addAll(dataList);
			    }
				return gridDataList;
			} catch (IOException e) {
				e.printStackTrace();
				return new ArrayList<>();
			}
			
		}
		return new ArrayList<>();
		
	}
	
	/**
	 * processColumnData
	 * @param colValue
	 * @param dataType
	 * @return
	 */
	 public Object processColumnData(Object colValue, String dataType) {
		if (!ObjectUtils.isEmpty(colValue) && !StringUtils.isEmpty(dataType)) {
			/** checking for data type as boolean or date to map data in grid*/
			if (dataType.equals("boolean")) {
				colValue = Boolean.valueOf(colValue.toString());
			} else if (dataType.equals("date") && colValue instanceof Date){
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date date = (Date)colValue;
				colValue = formatter.format(date.getTime());
			} else {
				colValue = String.valueOf(colValue);
			}
		}
		return colValue;
	}
	
	 /**
     * convert a MultipartFile file to java.io.File
     *
     * @param file of type MultipartFile
     * @return File
     */
    private File convert(MultipartFile file) throws IOException {
        File convertedFile = new File("/tmp/" + file.getOriginalFilename());
        convertedFile.createNewFile();
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(convertedFile);
            fileOutputStream.write(file.getBytes());
        } catch (Exception exception) {
            logger.error(exception.getMessage());
        } 
        if(Objects.nonNull(fileOutputStream)) {
            fileOutputStream.close();
        }
        
        return convertedFile;
    }

	/**
	 * beforeProcess
	 * 
	 * @return
	 */
	void beforeProcess(List<Map<String, String>> sheetDataList) {};
	
	
	/**
	 * validateRowData
	 * @return 
	 */
	void validateRowData(Map<String, Object> columnMap) {};
}
