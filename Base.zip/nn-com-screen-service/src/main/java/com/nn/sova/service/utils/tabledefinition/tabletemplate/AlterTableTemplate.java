package com.nn.sova.service.utils.tabledefinition.tabletemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.postgresql.util.PGobject;
import org.springframework.dao.DataIntegrityViolationException;

import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.alter.AlterTableQueryBuilder;
import com.nn.sova.service.constants.tabledefinition.TableDefinitionConstants;
import com.nn.sova.service.utils.tabledefinition.TableDefinitionUtils;
import com.nn.sova.util.entity.DropColumnEntity;
import com.nn.sova.util.entity.DropForeignKeyConstraintEntity;
import com.nn.sova.util.entity.ForeignKeyColumnReferenceEntity;
import com.nn.sova.util.entity.ForeignKeyTableReferenceEntity;
import com.nn.sova.util.entity.ForeignKeyTableReferenceEntity.MatchEnum;
import com.nn.sova.util.entity.IndexTableColumnDefinitionEntity;
import com.nn.sova.util.entity.TableColumnDefinitionEntity;
import com.nn.sova.util.entity.UniqueConstraintEntity;
import com.nn.sova.util.enums.OnchangeActionEnum;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.json.exception.JsonConversionException;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * AlterTableTemplate used for table alter for both main and lang dependent
 * table
 * 
 * @author MOHAN RAM
 *
 */
public class AlterTableTemplate {

	private static final String ADD_COLUMN_ENTITY_LIST = "addColumnEntityList";
	private static final String ALTER_COLUMN_ENTITY_LIST = "alterColumnEntityList";
	private static final String SET_SOURCE_CODE_GENERATE = "setSourceCodeGenerate";
	private static final String DEFAULT_VALUE = ".defaultValue";
	private static final String PRIMARY_KEY_CHANGE = "primaryKeyChange";
	private static final String FOREIGN_KEY_COLUMN_DETAILS = ".foreignKeyColumnDetails";
	private static final String LENGTH = ".length";
	private static final String PRIMARY_KEY_COLUMN = "primaryKeyColumn";
	private static final String DATA_TYPE3 = "data_type";
	private static final String COLUMN_NAME = ".columnName";
	private static final String DATA_TYPE2 = ".dataType";
	private static final String NOT_NULL = ".notNull";
	private static final String ORDERCHANGE = "orderchange";
	private static final String DATA_FORMAT = ".dataFormat";
	private static final String UNIQUE_COLUMN_DETAILS = ".uniqueColumnDetails";
	private static final String ENCRYPTION_COLUMN_CHANGES = "encryptionColumnChanges";
	private static final String DATA_ENCRYPTION_FLAG = ".dataEncryptionFlag";
	private static final String FOREIGN_KEY_NAME = ".foreignKeyName";
	private static final String DATA_ELEMENT = ".dataElement";
	private static final String DATA_TYPE = "dataType";
	private static final String REFERENCE_TABLE = ".referenceTable";
	private static final String TABLE_CHANGE_TO_LANG_DEPENDENT = "tableChangeToLangDependent";
	private static final String ALTER_DONE = "alterDone";
	private static final String AUTONUMBER_FLAG = ".autonumberFlag";
	private static final String AUTONUMBER = "autonumber";
	private static final String UNIQUE_KEY_NAME = ".uniqueKeyName";
	private static final String PRIMARY_KEY = ".primaryKey";
	private static final String SECOND_SYSTEM = "secondSystem";
	/**
	 * logger for AlterTableTemplate class
	 */
	private static ApplicationLogger logger = ApplicationLogger.create(AlterTableTemplate.class);

	/**
	 * alterTable method used for table creation
	 * 
	 * @param alterTableQueryExecutor contains table alter connection
	 * @param resultMap               contains table details
	 * @param tableDetailsMap         contains grid details
	 * @param tableMetaExecutor
	 * @throws CustomException when exception occurs at table alter
	 */
	public static void alterTable(QueryExecutor alterTableQueryExecutor, Map<String, Object> resultMap,
			Map<String, Object> tableDetailsMap, QueryExecutor tableMetaExecutor) throws CustomException {
		logger.info("alterTable method execution started.");
		try {
			alterColumnCheckUsingOfflineData(resultMap, tableDetailsMap, alterTableQueryExecutor, tableMetaExecutor);
		} catch (Exception exception) {
			logger.error("Exception occured at alterTable method" + exception);
			logger.info("alterTable method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("alterTable method execution ended.");
	}

	/**
	 * alterColumnCheckUsingOfflineData check difference between offline and online
	 * datas
	 * 
	 * @param resultMap               contains main table data
	 * @param tableDetailsMap         contains screen table data
	 * @param alterTableQueryExecutor
	 * @param tableMetaExecutor
	 * @throws CustomException when error occurred at get alter table template
	 */
	@SuppressWarnings({ "unchecked" })
	private static void alterColumnCheckUsingOfflineData(Map<String, Object> resultMap,
			Map<String, Object> tableDetailsMap, QueryExecutor alterTableQueryExecutor, QueryExecutor tableMetaExecutor)
			throws CustomException {
		logger.info("alterColumnCheckUsingOfflineData method execution started.");
		try {
			List<String> columnsList = new ArrayList<>();
			AtomicBoolean setSourceCodeGenerate = new AtomicBoolean(false);
			AtomicBoolean setPrimaryKeyAddedOrRemoved = new AtomicBoolean(false);
			AtomicBoolean setLangDependentChange = new AtomicBoolean(false);
			boolean mainEncryptColumn = resultMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_MAP)
					&& resultMap.get(TableDefinitionConstants.TABLE_DEFINITION_MAP) instanceof List
					&& !((List<Map<String, Object>>) (resultMap.get(TableDefinitionConstants.TABLE_DEFINITION_MAP)))
							.isEmpty()
					&& (boolean) (((List<Map<String, Object>>) (resultMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_MAP))).get(0)
									.get(TableDefinitionConstants.TABLE_DEFINITION_MAIN + DATA_ENCRYPTION_FLAG));
			boolean offlineEncryptColumn = tableDetailsMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_MAP)
					&& ((tableDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_MAP) instanceof List
							&& !((List<Map<String, Object>>) (tableDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_MAP))).isEmpty()
							&& (boolean) (((List<Map<String, Object>>) (tableDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_MAP))).get(0).get(
											TableDefinitionConstants.TABLE_DEFINITION_MAIN + DATA_ENCRYPTION_FLAG)))
							|| (tableDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_MAP) instanceof Map
									&& !((Map<String, Object>) (tableDetailsMap
											.get(TableDefinitionConstants.TABLE_DEFINITION_MAP))).isEmpty()
									&& (boolean) (((Map<String, Object>) (tableDetailsMap
											.get(TableDefinitionConstants.TABLE_DEFINITION_MAP)))
													.get(TableDefinitionConstants.TABLE_DEFINITION_MAIN
															+ DATA_ENCRYPTION_FLAG))));

			List<TableColumnDefinitionEntity> addTableColumnEntity = new ArrayList<>();
			List<TableColumnDefinitionEntity> alterTableColumnEntity = new ArrayList<>();
			List<TableColumnDefinitionEntity> langDependentColumnEntity = new ArrayList<>();
			List<String> mainTableDropColumnList = new ArrayList<>();
			List<String> langDependentDropColumnList = new ArrayList<>();
			List<DropColumnEntity> dropColumnEntityList = new ArrayList<>();
			List<DropForeignKeyConstraintEntity> dropForeignKeyList = new ArrayList<>();
			List<String> uniqueDropList = new ArrayList<>();
			List<UniqueConstraintEntity> uniqueConstraintList = new ArrayList<>();
			List<ForeignKeyTableReferenceEntity> foreignTableReferenceList = new ArrayList<>();
			List<String> primaryKeyList = new ArrayList<>();
			List<Map<String, Object>> gridColumnDetailsList = (List<Map<String, Object>>) tableDetailsMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP);
			Map<String, List<Map<String, Object>>> onlineTableColumnMap = ((List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP)).stream()
							.collect(Collectors.groupingBy(mapper -> String.valueOf(mapper.get(
									TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME))));
			boolean mainLangDependentTable = !gridColumnDetailsList.stream().filter(langDependentColumnCheck -> Objects
					.nonNull(langDependentColumnCheck
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
					&& (Boolean.parseBoolean(String.valueOf(langDependentColumnCheck.get(
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag")))))
					.collect(Collectors.toList()).isEmpty();
			boolean onlineLangDependentTable = !((List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP))
							.stream()
							.filter(langDependentColumnCheck -> (Objects
									.nonNull(langDependentColumnCheck
											.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
													+ ".langDependentFlag"))
									&& (Boolean.parseBoolean(String.valueOf(langDependentColumnCheck
											.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
													+ ".langDependentFlag"))))))
							.collect(Collectors.toList()).isEmpty();
			for (Map<String, Object> columnDetailsMap : gridColumnDetailsList) {
				columnsList.add(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
				if (onlineTableColumnMap.containsKey(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME))) {
					logger.info("Only data type, length, primary,not null check:" + columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME));
					checkAlterChange(resultMap, primaryKeyList, columnDetailsMap, setLangDependentChange,
							onlineTableColumnMap.get(columnDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME))
									.get(0), tableDetailsMap);
					if (resultMap.containsKey(ADD_COLUMN_ENTITY_LIST)) {
						addNewColumnList(resultMap, addTableColumnEntity, langDependentColumnEntity,
								mainTableDropColumnList, langDependentDropColumnList, mainLangDependentTable,
								onlineLangDependentTable, columnDetailsMap, setLangDependentChange);

					} else if (resultMap.containsKey(ALTER_COLUMN_ENTITY_LIST)) {
						addAlterColumnList(resultMap, setSourceCodeGenerate, alterTableColumnEntity);
					} else {
						logger.info("No alter  changes in column Name :" + columnDetailsMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME));
					}

				} else {
					logger.info("new columns added." + columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME));
					setSourceCodeGenerate.set(true);
					TableColumnDefinitionEntity tableColumnEntity = addColumnDetails(resultMap, primaryKeyList,
							columnDetailsMap, setLangDependentChange);
					addNewColumnList(resultMap, addTableColumnEntity, langDependentColumnEntity, mainLangDependentTable,
							onlineLangDependentTable, tableColumnEntity, setLangDependentChange);
				}
			}
			getDropColumnList(columnsList, mainTableDropColumnList, langDependentDropColumnList, dropColumnEntityList,
					onlineTableColumnMap, mainLangDependentTable && onlineLangDependentTable);
			if (offlineEncryptColumn && !mainEncryptColumn) {
				logger.info("encrypt column added." + resultMap.get(TableDefinitionConstants.TABLENAME));
				TableColumnDefinitionEntity tableColumnDefinitionEntity = new TableColumnDefinitionEntity();
				tableColumnDefinitionEntity.setcolumnName(TableDefinitionConstants.TABLE_DEFINITION_ENCRYPT_KEY);
				tableColumnDefinitionEntity.setdataType(
						TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
				addTableColumnEntity.add(tableColumnDefinitionEntity);
			} else if (!offlineEncryptColumn && mainEncryptColumn) {
				logger.info("encrypt column removed." + resultMap.get(TableDefinitionConstants.TABLENAME));
				DropColumnEntity dropColumnEntity = new DropColumnEntity();
				dropColumnEntity.setColumnNames(TableDefinitionConstants.TABLE_DEFINITION_ENCRYPT_KEY);
				dropColumnEntity.setLangDependent(false);
				dropColumnEntityList.add(dropColumnEntity);
			}
			List<String> onlinePrimaryKeyList = new ArrayList<>(
					((List<Map<String, Object>>) resultMap.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP))
							.stream()
							.filter(columnDetails -> Objects
									.nonNull(columnDetails
											.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
													+ PRIMARY_KEY))
									&& (Boolean.parseBoolean(String.valueOf(columnDetails
											.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
													+ PRIMARY_KEY)))))
							.collect(Collectors.groupingBy(mapper -> String.valueOf(mapper
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME))))
							.keySet());
			setPrimaryKeyAddedOrRemoved(setPrimaryKeyAddedOrRemoved, mainTableDropColumnList,
					langDependentDropColumnList, primaryKeyList, onlinePrimaryKeyList);
			if (!setPrimaryKeyAddedOrRemoved.get()) {
				mainTableDropColumnList.stream()
						.filter(predicate -> !setPrimaryKeyAddedOrRemoved.get() && primaryKeyList.contains(predicate))
						.forEach(action -> setPrimaryKeyAddedOrRemoved.set(true));
				langDependentDropColumnList.stream()
						.filter(predicate -> !setPrimaryKeyAddedOrRemoved.get() && primaryKeyList.contains(predicate))
						.forEach(action -> setPrimaryKeyAddedOrRemoved.set(true));
				addTableColumnEntity.stream()
						.filter(predicate -> !setPrimaryKeyAddedOrRemoved.get()
								&& primaryKeyList.contains(predicate.getcolumnName()))
						.forEach(actions -> setPrimaryKeyAddedOrRemoved.set(true));
			}
			checkForeignKeyChange(resultMap, tableDetailsMap, dropForeignKeyList, foreignTableReferenceList);
			checkUniqueKeyChange(resultMap, tableDetailsMap, uniqueConstraintList, uniqueDropList);
			alterTableExecute(resultMap, tableDetailsMap, alterTableQueryExecutor, tableMetaExecutor,
					setSourceCodeGenerate, setPrimaryKeyAddedOrRemoved, setLangDependentChange, addTableColumnEntity,
					alterTableColumnEntity, dropColumnEntityList, dropForeignKeyList, uniqueDropList,
					uniqueConstraintList, foreignTableReferenceList, primaryKeyList, gridColumnDetailsList,
					mainLangDependentTable, onlineLangDependentTable);
		} catch (Exception exception) {
			logger.error("Exception occured at alterTable method" + exception);
			logger.info("alterColumnCheckUsingOfflineData method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("alterColumnCheckUsingOfflineData method execution ended.");
	}

	@SuppressWarnings("unchecked")
	private static void alterTableExecute(Map<String, Object> resultMap, Map<String, Object> tableDetailsMap,
			QueryExecutor alterTableQueryExecutor, QueryExecutor tableMetaExecutor, AtomicBoolean setSourceCodeGenerate,
			AtomicBoolean setPrimaryKeyAddedOrRemoved, AtomicBoolean setLangDependentChange,
			List<TableColumnDefinitionEntity> addTableColumnEntity,
			List<TableColumnDefinitionEntity> alterTableColumnEntity, List<DropColumnEntity> dropColumnEntityList,
			List<DropForeignKeyConstraintEntity> dropForeignKeyList, List<String> uniqueDropList,
			List<UniqueConstraintEntity> uniqueConstraintList,
			List<ForeignKeyTableReferenceEntity> foreignTableReferenceList, List<String> primaryKeyList,
			List<Map<String, Object>> gridColumnDetailsList, boolean mainLangDependentTable,
			boolean onlineLangDependentTable) throws CustomException {
		try {
			String tableName = String.valueOf(resultMap.get(TableDefinitionConstants.TABLENAME));
			String applicationName = String.valueOf(resultMap.get(TableDefinitionConstants.PRODUCT_CODE));
			if (resultMap.containsKey("forceUpdateKey")) {
				alterTableQueryExecutor = getProductExecutor(
						(Map<String, Object>) tableDetailsMap.get("productDetailsMap"));
				alterTableQueryExecutor.skipChangeRequest(true);
				alterTableQueryExecutor.setProductCode(applicationName);
				alterTableQueryExecutor.queryBuilder().delete().setProductCode(applicationName).skipInactiveStatus(true)
						.from(tableName).build().execute();
				tableDetailsMap.put("alterExecutor", alterTableQueryExecutor);
			}
			alterTableQueryExecutor.setProductCode(applicationName);
			List<TableColumnDefinitionEntity> langDependentColumnEntity;
			List<String> alterColumnList = new ArrayList<>();
			List<String> foreignConstraintChange = new ArrayList<>();
			List<String> dropForeignConstrainChange = new ArrayList<>();
			List<String> uniqueConstraintChange = new ArrayList<>();
			List<String> dropColumnList = new ArrayList<>();
			boolean deactivateTrigger = false;
			if (onlineLangDependentTable && !mainLangDependentTable) {
				resultMap.put(ALTER_DONE, true);
				deactivateTrigger = true;
				TableDefinitionUtils.checkAndInactivateDependentView(alterTableQueryExecutor, tableMetaExecutor,
						tableName, applicationName, resultMap.containsKey(SECOND_SYSTEM), new ArrayList<>());
				alterTableQueryExecutor.queryBuilder().table().dropTable(tableName + "_text")
						.setProductName(applicationName).build().execute();
			}
			if (!alterTableColumnEntity.isEmpty() || !addTableColumnEntity.isEmpty() || !dropForeignKeyList.isEmpty()
					|| !uniqueDropList.isEmpty() || !uniqueConstraintList.isEmpty()
					|| !foreignTableReferenceList.isEmpty() || !dropColumnEntityList.isEmpty()) {
				logger.info("table changes are there");
				if (!deactivateTrigger && (!alterTableColumnEntity.isEmpty() || !addTableColumnEntity.isEmpty()
						|| !dropColumnEntityList.isEmpty())) {
					logger.info("view drop triggerted" + tableName);
					deactivateTrigger = true;
					TableDefinitionUtils.checkAndInactivateDependentView(alterTableQueryExecutor,
							tableMetaExecutor, tableName, applicationName, resultMap.containsKey(SECOND_SYSTEM),
							new ArrayList<>());
				}
				alterTableColumnEntity.forEach(alterList -> alterColumnList.add(alterList.getcolumnName()));
				addTableColumnEntity.forEach(alterList -> alterColumnList.add(alterList.getcolumnName()));
				dropColumnEntityList.forEach(alterList -> dropColumnList.add(alterList.getColumnNames()));
				foreignTableReferenceList
						.forEach(alterList -> foreignConstraintChange.add(alterList.getconstraintName()));
				dropForeignKeyList
						.forEach(alterList -> dropForeignConstrainChange.add(alterList.getForeignKeyConstraint()));
				uniqueConstraintList.forEach(alterList -> uniqueConstraintChange.add(alterList.getConstraintName()));
				resultMap.put(ALTER_DONE, true);
				AlterTableQueryBuilder alterExecutor = alterTableQueryExecutor.queryBuilder().table().alterTable()
						.table(tableName).setProductCode(applicationName);
				if (setLangDependentChange.get() && onlineLangDependentTable && mainLangDependentTable) {
					DropForeignKeyConstraintEntity entity = new DropForeignKeyConstraintEntity();
					entity.setForeignKeyConstraint(tableName + "_lang_fkey_lang");
					entity.setLangDependent(true);
					alterExecutor.lang(true).dropForeignKeyConstraint(Arrays.asList(entity));
				}
				alterExecutor.dropForeignKeyConstraint(dropForeignKeyList).dropUniqueConstraint(uniqueDropList)
						.dropColumn(dropColumnEntityList).addColumns(addTableColumnEntity)
						.alterColumns(alterTableColumnEntity).foreignKeyConstraintChange(foreignTableReferenceList)
						.uniqueConstraintChange(uniqueConstraintList);
				if (setLangDependentChange.get() && onlineLangDependentTable && mainLangDependentTable) {
					ForeignKeyTableReferenceEntity langForeignList = new ForeignKeyTableReferenceEntity();
					addingForeignKeyContraintsForLangDependent(tableName, langForeignList, primaryKeyList);
					alterExecutor.foreignKeyConstraintChange(Arrays.asList(langForeignList));
				}
				if (setPrimaryKeyAddedOrRemoved.get()) {
					alterExecutor.primaryKeyConstraintChange(primaryKeyList);
				}
				alterExecutor.build().execute();
			}
			if (!onlineLangDependentTable && mainLangDependentTable) {
				resultMap.put(ALTER_DONE, true);
				List<Map<String, Object>> langDependentColumnList = gridColumnDetailsList.stream()
						.filter(langDependentColumnCheck -> (Objects.nonNull(langDependentColumnCheck.get(
								TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
								&& (Boolean.parseBoolean(String.valueOf(langDependentColumnCheck
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
												+ ".langDependentFlag")))))
								|| (Objects.nonNull(langDependentColumnCheck.get(
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))
										&& (Boolean.parseBoolean(String.valueOf(langDependentColumnCheck
												.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
														+ PRIMARY_KEY))))))
						.collect(Collectors.toList());
				langDependentColumnEntity = CreateTableTemplate.landependentAddTableList(langDependentColumnList,
						resultMap);
				addLocaleColumnDetails(langDependentColumnEntity);
				ForeignKeyTableReferenceEntity langForeignList = new ForeignKeyTableReferenceEntity();
				addingForeignKeyContraintsForLangDependent(tableName, langForeignList, primaryKeyList);
				primaryKeyList.add("locale");
				if (!deactivateTrigger) {
					TableDefinitionUtils.checkAndInactivateDependentView(alterTableQueryExecutor,
							tableMetaExecutor, tableName, applicationName, resultMap.containsKey(SECOND_SYSTEM),
							new ArrayList<>());
				}
				alterTableQueryExecutor.queryBuilder().table().createtable().tableName(tableName + "_text")
						.productCode(applicationName).setProductCode(applicationName).columns(langDependentColumnEntity)
						.primaryKeyConstraint(primaryKeyList).foreignKeyConstraint(Arrays.asList(langForeignList))
						.build().execute();
				langDependentColumnEntity.forEach(alterList -> alterColumnList.add(alterList.getcolumnName()));
			}
			List<String> indexDrop = new ArrayList<>();
			if (resultMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP)) {
				List<Map<String, Object>> onlineIndexList = (List<Map<String, Object>>) resultMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP);
				if (onlineIndexList.isEmpty()) {
					logger.info("index list not present in online table");
				} else {
					onlineIndexList.forEach(action -> indexDrop.add(String.valueOf(
							action.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".indexName"))));
				}
			}
			if (!indexDrop.isEmpty()) {
				alterTableQueryExecutor.queryBuilder().table().dropIndexes(indexDrop).setProductCode(applicationName)
						.build().execute();
			}
			List<IndexTableColumnDefinitionEntity> indexEntityList = new ArrayList<>();
			if (tableDetailsMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP)) {
				logger.info("checkIndexKeyList method execution started.");
				try {
					List<Map<String, Object>> indexKeyDetailsList = (List<Map<String, Object>>) tableDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAP);
					if (indexKeyDetailsList.isEmpty()) {
						logger.info("No index entries");
					} else {
						for (Map<String, Object> indexDetails : indexKeyDetailsList) {
							IndexTableColumnDefinitionEntity indexEntity = new IndexTableColumnDefinitionEntity();
							indexEntity.setIndexColumnNames((List<String>) JsonUtils.fromJsonOrThrow(indexDetails
									.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".columnNames")
									.toString(), List.class));
							indexEntity.setIndexName(String.valueOf(indexDetails
									.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".indexName")));
							indexEntity.setTableName(String.valueOf(indexDetails
									.get(TableDefinitionConstants.TABLE_DEFINITION_INDEX_DETAILS_MAIN + ".tableName")));
							indexEntityList.add(indexEntity);
						}
					}
				} catch (Exception exception) {
					logger.error("Exception occured at checkForeignKeyList method" + exception);
					logger.info("checkIndexKeyList method execution ended.");
					throw new CustomException(exception.getMessage());
				}
				logger.info("checkIndexKeyList method execution ended.");
			}
			if (!indexEntityList.isEmpty()) {
				alterTableQueryExecutor.queryBuilder().table().createIndex().setProductCode(applicationName)
						.indexTablesDetails(indexEntityList).build().execute();
			}
			if (!alterColumnList.isEmpty()) {
				resultMap.put("alterColumnList", alterColumnList);
			}

			if (!foreignConstraintChange.isEmpty()) {
				resultMap.put("foreignConstraintChange", foreignConstraintChange);
			}

			if (!dropForeignConstrainChange.isEmpty()) {
				resultMap.put("dropForeignConstrainChange", dropForeignConstrainChange);
			}
			if (!uniqueConstraintChange.isEmpty()) {
				resultMap.put("uniqueConstraintChange", uniqueConstraintChange);
			}
			if (!dropColumnList.isEmpty()) {
				resultMap.put("dropColumnList", dropColumnList);
				resultMap.put("sourceCodeGenerate", true);
			}
			if (!uniqueDropList.isEmpty()) {
				resultMap.put("uniqueDropList", uniqueDropList);
			}
			if (setSourceCodeGenerate.get()) {
				resultMap.put("sourceCodeGenerate", true);
			}
		} catch (Exception exception) {
			logger.info("exception at alter query " + exception.getMessage());
			try {
				alterTableQueryExecutor.rollBack();
			} catch (Exception rollbackException) {
				logger.error(rollbackException);
			}
			logger.error(exception);
			if (exception.getCause() instanceof DataIntegrityViolationException) {

				if (!tableDetailsMap.containsKey("forceUpdateKey") || resultMap.containsKey("forceUpdateKey")) {
					if (!tableDetailsMap.containsKey("forceUpdateKey")) {
						resultMap.put("forceUpdateError", true);
					}
					throw new CustomException(exception.getMessage());
				} else {
					resultMap.put("forceUpdateKey", true);
					alterTableExecute(resultMap, tableDetailsMap, alterTableQueryExecutor, tableMetaExecutor,
							setSourceCodeGenerate, setPrimaryKeyAddedOrRemoved, setLangDependentChange,
							addTableColumnEntity, alterTableColumnEntity, dropColumnEntityList, dropForeignKeyList,
							uniqueDropList, uniqueConstraintList, foreignTableReferenceList, primaryKeyList,
							gridColumnDetailsList, mainLangDependentTable, onlineLangDependentTable);
				}
			} else {
				throw new CustomException(exception.getMessage());
			}
		}
	}

	private static void addLocaleColumnDetails(List<TableColumnDefinitionEntity> langTableColumnDefinitionList) {
		TableColumnDefinitionEntity localeColumnDefinitionEntity = new TableColumnDefinitionEntity();
		localeColumnDefinitionEntity.setcolumnName("locale");
		localeColumnDefinitionEntity
				.setdataType(TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
		localeColumnDefinitionEntity.setisNotNull(true);
		langTableColumnDefinitionList.add(localeColumnDefinitionEntity);
	}

	/**
	 * addingForeignKeyContraintsForLangDependent method is used to add foreign
	 * constraint by default for lang table
	 * 
	 * @param tableName                      table for foreign key constraint
	 * @param foreignKeyTableReferenceEntity set foreign key details for lang
	 *                                       dependent
	 */
	public static void addingForeignKeyContraintsForLangDependent(String tableName,
			ForeignKeyTableReferenceEntity foreignKeyTableReferenceEntity, List<String> primaryKeyColumns) {
		logger.info("addingForeignKeyContraintsForLangDependent method execution started.");
		foreignKeyTableReferenceEntity.setconstraintName(tableName.concat("_lang_fkey_lang"));
		foreignKeyTableReferenceEntity.setreferenceTableName(tableName);
		foreignKeyTableReferenceEntity.setMatchType(MatchEnum.SIMPLE);
		foreignKeyTableReferenceEntity.setOnDelete(OnchangeActionEnum.NO_ACTION);
		foreignKeyTableReferenceEntity.setOnUpdate(OnchangeActionEnum.NO_ACTION);
		foreignKeyTableReferenceEntity.setLangDependent(true);
		List<ForeignKeyColumnReferenceEntity> foreignKeyColumnReferenceList = new ArrayList<>();
		primaryKeyColumns.forEach(columnName -> {
			ForeignKeyColumnReferenceEntity foreignKeyColumnReference = new ForeignKeyColumnReferenceEntity();
			foreignKeyColumnReference.setLocalColumnName(columnName);
			foreignKeyColumnReference.setReferenceColumnName(columnName);
			foreignKeyColumnReferenceList.add(foreignKeyColumnReference);
		});
		foreignKeyTableReferenceEntity.setcolumnList(foreignKeyColumnReferenceList);
		logger.info("addingForeignKeyContraintsForLangDependent method execution ended.");
	}

	/**
	 * @param setPrimaryKeyAddedOrRemoved
	 * @param mainTableDropColumnList
	 * @param langDependentDropColumnList
	 * @param primaryKeyList
	 * @param onlinePrimaryKeyList
	 */
	private static void setPrimaryKeyAddedOrRemoved(AtomicBoolean setPrimaryKeyAddedOrRemoved,
			List<String> mainTableDropColumnList, List<String> langDependentDropColumnList, List<String> primaryKeyList,
			List<String> onlinePrimaryKeyList) {
		if (mainTableDropColumnList.containsAll(primaryKeyList)
				|| langDependentDropColumnList.containsAll(primaryKeyList)) {
			logger.info("primary key column removed and added.");
			setPrimaryKeyAddedOrRemoved.set(true);
		} else if (primaryKeyList.size() == onlinePrimaryKeyList.size()
				&& primaryKeyList.containsAll(onlinePrimaryKeyList)) {
			logger.info("no primary key change");
		} else {
			logger.info("primary key changed");
			setPrimaryKeyAddedOrRemoved.set(true);
		}
	}

	/**
	 * @param resultMap
	 * @param addTableColumnEntity
	 * @param langDependentColumnEntity
	 * @param mainLangDependentTable
	 * @param onlineLangDependentTable
	 * @param tableColumnEntity
	 * @param setLangDependentChange
	 */
	private static void addNewColumnList(Map<String, Object> resultMap,
			List<TableColumnDefinitionEntity> addTableColumnEntity,
			List<TableColumnDefinitionEntity> langDependentColumnEntity, boolean mainLangDependentTable,
			boolean onlineLangDependentTable, TableColumnDefinitionEntity tableColumnEntity,
			AtomicBoolean setLangDependentChange) {
		if (tableColumnEntity.isLangDependent()) {
			if (onlineLangDependentTable && mainLangDependentTable) {
				addTableColumnEntity.add(tableColumnEntity);
			} else if (onlineLangDependentTable) {
				langDependentColumnEntity.add(tableColumnEntity);
			}
		} else {
			addTableColumnEntity.add(tableColumnEntity);
		}
		resultMap.remove("langDependentColumnAdded");
		if (resultMap.containsKey(PRIMARY_KEY_COLUMN)) {
			resultMap.remove(PRIMARY_KEY_COLUMN);
			setLangDependentChange.set(true);
			if (onlineLangDependentTable && mainLangDependentTable) {
				tableColumnEntity.setLangDependent(true);
				addTableColumnEntity.add(tableColumnEntity);
			} else if (onlineLangDependentTable) {
				langDependentColumnEntity.add(tableColumnEntity);
			}
		}
	}

	/**
	 * @param resultMap
	 * @param setSourceCodeGenerate
	 * @param alterTableColumnEntity
	 */
	private static void addAlterColumnList(Map<String, Object> resultMap, AtomicBoolean setSourceCodeGenerate,
			List<TableColumnDefinitionEntity> alterTableColumnEntity) {
		alterTableColumnEntity.add((TableColumnDefinitionEntity) resultMap.get(ALTER_COLUMN_ENTITY_LIST));
		resultMap.remove(ALTER_COLUMN_ENTITY_LIST);
		if (resultMap.containsKey(SET_SOURCE_CODE_GENERATE)) {
			setSourceCodeGenerate.set(true);
			resultMap.remove(SET_SOURCE_CODE_GENERATE);
		}
	}

	/**
	 * addNewColumnList method used for adding new columns
	 * 
	 * @param resultMap                   contains table details
	 * @param addTableColumnEntity        contains table column entity
	 * @param langDependentColumnEntity   contains lang dependent column entity
	 * @param mainTableDropColumnList     contains main table drop column list
	 * @param langDependentDropColumnList contains lang table drop column list
	 * @param mainLangDependentTable      contains flag for main lang dependent or
	 *                                    not
	 * @param onlineLangDependentTable    contains online table lang dependent or
	 *                                    not
	 * @param columnDetailsMap            contains column details
	 */
	private static void addNewColumnList(Map<String, Object> resultMap,
			List<TableColumnDefinitionEntity> addTableColumnEntity,
			List<TableColumnDefinitionEntity> langDependentColumnEntity, List<String> mainTableDropColumnList,
			List<String> langDependentDropColumnList, boolean mainLangDependentTable, boolean onlineLangDependentTable,
			Map<String, Object> columnDetailsMap, AtomicBoolean setLangDependentChange) {
		logger.info("addNewColumnList method execution started.");
		logger.info("Lang dependent change or column order is changed(Column removed and added).");
		TableColumnDefinitionEntity tableColumnEntity = (TableColumnDefinitionEntity) resultMap
				.get(ADD_COLUMN_ENTITY_LIST);
		if (tableColumnEntity.isLangDependent()) {
			if (onlineLangDependentTable && mainLangDependentTable) {
				addTableColumnEntity.add(tableColumnEntity);
			} else if (onlineLangDependentTable) {
				langDependentColumnEntity.add(tableColumnEntity);
			}
		} else {
			addTableColumnEntity.add(tableColumnEntity);
		}
		resultMap.remove(ADD_COLUMN_ENTITY_LIST);
		if (resultMap.containsKey(ORDERCHANGE)) {
			resultMap.remove(ORDERCHANGE);
			if (tableColumnEntity.isLangDependent()) {
				if (onlineLangDependentTable && mainLangDependentTable) {
					langDependentDropColumnList.add(String.valueOf(columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
				}
			} else {
				mainTableDropColumnList.add(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
			}
		} else if (resultMap.containsKey(TABLE_CHANGE_TO_LANG_DEPENDENT)) {
			resultMap.remove(TABLE_CHANGE_TO_LANG_DEPENDENT);
			if (!tableColumnEntity.isLangDependent()) {
				if (onlineLangDependentTable && mainLangDependentTable) {
					langDependentDropColumnList.add(String.valueOf(columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
				}
			} else {
				mainTableDropColumnList.add(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
			}
		}
		if (resultMap.containsKey(PRIMARY_KEY_COLUMN)) {
			resultMap.remove(PRIMARY_KEY_COLUMN);
			setLangDependentChange.set(true);
			if (onlineLangDependentTable && mainLangDependentTable) {
				tableColumnEntity.setLangDependent(true);
				addTableColumnEntity.add(tableColumnEntity);
			} else if (onlineLangDependentTable) {
				langDependentColumnEntity.add(tableColumnEntity);
			}
		}
		logger.info("addNewColumnList method execution ended.");
	}

	/**
	 * checkUniqueKeyChange used for check unique key present or not
	 * 
	 * @param resultMap            contains table column details
	 * @param tableDetailsMap      contains table details map
	 * @param uniqueConstraintList contains unique constraint list
	 * @param dropUniQueKeyList    contains drop constraint list
	 */
	@SuppressWarnings("unchecked")
	private static void checkUniqueKeyChange(Map<String, Object> resultMap, Map<String, Object> tableDetailsMap,
			List<UniqueConstraintEntity> uniqueConstraintList, List<String> dropUniQueKeyList) {
		logger.info("checkUniqueKeyChange method execution started.");
		List<Map<String, Object>> mainUniqueKeyList = new ArrayList<>();
		List<Map<String, Object>> onlineUniqueKeyList = new ArrayList<>();
		List<String> mainUniqueKeyConstraintList = new ArrayList<>();
		if (resultMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP)) {
			onlineUniqueKeyList = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP);
		}
		if (tableDetailsMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP)) {
			mainUniqueKeyList = (List<Map<String, Object>>) tableDetailsMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAP);
		}
		if (onlineUniqueKeyList.isEmpty() && mainUniqueKeyList.isEmpty()) {
			logger.info("No unique key changes");
		} else if (onlineUniqueKeyList.isEmpty()) {
			addUniqueList(mainUniqueKeyList, uniqueConstraintList);
		} else if (mainUniqueKeyList.isEmpty()) {
			onlineUniqueKeyList.forEach(onlineUniqueMap -> dropUniQueKeyList.add(String.valueOf(onlineUniqueMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME))));
		} else {
			Map<String, List<Map<String, Object>>> onlineUniqueKeyMap = onlineUniqueKeyList.stream()
					.collect(Collectors.groupingBy(mapper -> String.valueOf(mapper
							.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME))));
			mainUniqueKeyList.forEach(mainUniqueMap -> {
				mainUniqueKeyConstraintList.add(String.valueOf(mainUniqueMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME)));
				if (onlineUniqueKeyMap.containsKey(mainUniqueMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME))) {
					Map<String, Object> onlineUniqueKeyDetails = onlineUniqueKeyMap
							.get(mainUniqueMap.get(
									TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME))
							.get(0);
					List<String> mainColumnList;
					List<String> onlineColumnList;
					try {
						mainColumnList = JsonUtils.fromJsonOrThrow(mainUniqueMap.get(
								TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_COLUMN_DETAILS)
								.toString(), List.class);
						onlineColumnList = JsonUtils.fromJsonOrThrow(((PGobject) onlineUniqueKeyDetails.get(
								TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_COLUMN_DETAILS))
										.getValue(),
								List.class);
						if (mainColumnList.size() == onlineColumnList.size()
								&& onlineColumnList.containsAll(mainColumnList)) {
							logger.info("no unique key changed");
						} else {
							dropUniQueKeyList.add(String.valueOf(mainUniqueMap.get(
									TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME)));
							addUniqueList(Arrays.asList(mainUniqueMap), uniqueConstraintList);
						}
					} catch (JsonConversionException e) {
						e.printStackTrace();
					}
				} else {
					addUniqueList(Arrays.asList(mainUniqueMap), uniqueConstraintList);
				}
			});
			List<String> onlineConstrainList = new ArrayList<>(onlineUniqueKeyMap.keySet());
			onlineConstrainList.removeAll(mainUniqueKeyConstraintList);
			dropUniQueKeyList.addAll(onlineConstrainList);
		}
		logger.info("checkUniqueKeyChange method execution ended.");
	}

	/**
	 * addUniqueList used to add unique key list
	 * 
	 * @param mainUniqueKeyList    contains main unique key list
	 * @param uniqueConstraintList contains unique constraint list
	 */
	@SuppressWarnings("unchecked")
	private static void addUniqueList(List<Map<String, Object>> mainUniqueKeyList,
			List<UniqueConstraintEntity> uniqueConstraintList) {
		logger.info("addUniqueList method execution started.");
		mainUniqueKeyList.forEach(unikeyMap -> {
			UniqueConstraintEntity uniqueConstraintEntity = new UniqueConstraintEntity();
			try {
				uniqueConstraintEntity.setConstraintColumns(JsonUtils.fromJsonOrThrow(unikeyMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_COLUMN_DETAILS)
						.toString(), List.class));
				uniqueConstraintEntity.setConstraintName(String.valueOf(unikeyMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_UNIQUE_DETAILS_MAIN + UNIQUE_KEY_NAME)));
				uniqueConstraintList.add(uniqueConstraintEntity);
			} catch (JsonConversionException e) {
				logger.error(e);
				e.printStackTrace();
			}
		});
		logger.info("addUniqueList method execution ended.");
	}

	/**
	 * checkForeignKeyChange used for foreign constraint change
	 * 
	 * @param resultMap                 contains table details
	 * @param tableDetailsMap           contains column details
	 * @param dropForeignKeyList        contains drop foreign key list
	 * @param foreignTableReferenceList contains foreign table reference list
	 * @throws CustomException when adding exception
	 */
	@SuppressWarnings("unchecked")
	private static void checkForeignKeyChange(Map<String, Object> resultMap, Map<String, Object> tableDetailsMap,
			List<DropForeignKeyConstraintEntity> dropForeignKeyList,
			List<ForeignKeyTableReferenceEntity> foreignTableReferenceList) throws CustomException {
		logger.info("checkForeignKeyChange method execution started.");
		List<Map<String, Object>> mainForeingKeyList = new ArrayList<>();
		List<Map<String, Object>> onlineForeignKeyList = new ArrayList<>();
		if (resultMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP)) {
			onlineForeignKeyList = (List<Map<String, Object>>) resultMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP);
		}
		if (tableDetailsMap.containsKey(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP)) {
			mainForeingKeyList = (List<Map<String, Object>>) tableDetailsMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAP);
		}
		if (onlineForeignKeyList.isEmpty() && mainForeingKeyList.isEmpty()) {
			logger.info("No foreign key changes");
		} else if (onlineForeignKeyList.isEmpty()) {
			addForeignKeyList(mainForeingKeyList, foreignTableReferenceList);
		} else if (mainForeingKeyList.isEmpty()) {
			onlineForeignKeyList.forEach(foreignDetails -> {
				DropForeignKeyConstraintEntity dropContrainst = new DropForeignKeyConstraintEntity();
				dropContrainst.setForeignKeyConstraint(String.valueOf(foreignDetails
						.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_NAME)));
				dropContrainst.setLangDependent(false);
				dropForeignKeyList.add(dropContrainst);
			});
		} else {
			checkForeignConstraintTableOrColumnChanged(dropForeignKeyList, foreignTableReferenceList,
					mainForeingKeyList, onlineForeignKeyList);

		}
		logger.info("checkForeignKeyChange method execution ended.");
	}

	/**
	 * checkForeignConstraintTableOrColumnChanged used for foreign constraint table
	 * column added or removed
	 * 
	 * @param dropForeignKeyList        contains drop foreign key list
	 * @param foreignTableReferenceList contains foreign table reference list
	 * @param mainForeingKeyList        contains main foreign key
	 * @param onlineForeignKeyList      contains online foreign key
	 */
	@SuppressWarnings("unchecked")
	private static void checkForeignConstraintTableOrColumnChanged(
			List<DropForeignKeyConstraintEntity> dropForeignKeyList,
			List<ForeignKeyTableReferenceEntity> foreignTableReferenceList,
			List<Map<String, Object>> mainForeingKeyList, List<Map<String, Object>> onlineForeignKeyList) {
		logger.info("checkForeignConstraintTableOrColumnChanged method execution started.");
		List<String> foreignConstraintName = new ArrayList<>();
		Map<String, List<Map<String, Object>>> onlineForeignKeyMap = onlineForeignKeyList.stream()
				.collect(Collectors.groupingBy(mapper -> String.valueOf(mapper
						.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_NAME))));
		mainForeingKeyList.forEach(foreignDetails -> {
			try {
				foreignConstraintName.add(String.valueOf(foreignDetails
						.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_NAME)));
				if (onlineForeignKeyMap.containsKey(foreignDetails
						.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_NAME))) {
					Map<String, Object> onlineForeignKeyDetails = onlineForeignKeyMap
							.get(foreignDetails.get(
									TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_NAME))
							.get(0);
					if (onlineForeignKeyDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + REFERENCE_TABLE)
							.equals(foreignDetails.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
									+ REFERENCE_TABLE))) {
						logger.info("no reference table changed");
						Map<String, String> mainReferenceColumnMap = JsonUtils.fromJsonOrThrow(
								foreignDetails.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
										+ FOREIGN_KEY_COLUMN_DETAILS).toString(),
								Map.class);

						Map<String, String> onlineReferenceColumnMap = (JsonUtils
								.fromJsonOrThrow(((PGobject) onlineForeignKeyDetails
										.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN
												+ FOREIGN_KEY_COLUMN_DETAILS)).getValue(),
										Map.class));
						if (mainReferenceColumnMap.equals(onlineReferenceColumnMap)) {
							logger.info("No changes in foreign key column");
						} else {
							DropForeignKeyConstraintEntity dropForeignConstraint = new DropForeignKeyConstraintEntity();
							dropForeignConstraint.setForeignKeyConstraint(String.valueOf(foreignDetails.get(
									TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + REFERENCE_TABLE)));
							dropForeignConstraint.setLangDependent(false);
							dropForeignKeyList.add(dropForeignConstraint);
							addForeignKeyList(Arrays.asList(foreignDetails), foreignTableReferenceList);
						}
					} else {
						DropForeignKeyConstraintEntity dropForeignConstraint = new DropForeignKeyConstraintEntity();
						dropForeignConstraint.setForeignKeyConstraint(String.valueOf(foreignDetails.get(
								TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + REFERENCE_TABLE)));
						dropForeignConstraint.setLangDependent(false);
						dropForeignKeyList.add(dropForeignConstraint);
						addForeignKeyList(Arrays.asList(foreignDetails), foreignTableReferenceList);
					}
				} else {
					addForeignKeyList(Arrays.asList(foreignDetails), foreignTableReferenceList);
				}
			} catch (CustomException | JsonConversionException exception) {
				logger.error("Exception occured at adding foreign Key details." + exception);
			}
		});
		List<String> onlineForeignConstrainList = new ArrayList<>(onlineForeignKeyMap.keySet());
		onlineForeignConstrainList.removeAll(foreignConstraintName);
		if (!onlineForeignConstrainList.isEmpty()) {
			onlineForeignConstrainList.forEach(foreignKeyName -> {
				DropForeignKeyConstraintEntity dropForeignConstraint = new DropForeignKeyConstraintEntity();
				dropForeignConstraint.setForeignKeyConstraint(foreignKeyName);
				dropForeignConstraint.setLangDependent(false);
				dropForeignKeyList.add(dropForeignConstraint);
			});
		}
		logger.info("checkForeignConstraintTableOrColumnChanged method execution ended.");
	}

	/**
	 * addForeignKeyList used for check foreign constraint details present
	 * 
	 * @param foreignKeyList                     contains foreign constraint details
	 * @param foreignKeyTableReferenceEntityList contains foreign key details
	 * @throws CustomException when getting foreign constraint details
	 */
	@SuppressWarnings("unchecked")
	private static void addForeignKeyList(List<Map<String, Object>> foreignKeyList,
			List<ForeignKeyTableReferenceEntity> foreignKeyTableReferenceEntityList) throws CustomException {
		logger.info("addForeignKeyList method execution started.");
		try {
			foreignKeyList.forEach(foreignKeyDetails -> {
				ForeignKeyTableReferenceEntity foreignKeyTableReferenceEntity = new ForeignKeyTableReferenceEntity();
				List<ForeignKeyColumnReferenceEntity> foreignKeyColumnReferenceEntityList = new ArrayList<>();
				Map<String, String> columnMap;
				try {
					columnMap = JsonUtils.fromJsonOrThrow(foreignKeyDetails.get(
							TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_COLUMN_DETAILS)
							.toString(), Map.class);

					for (Map.Entry<String, String> entry : columnMap.entrySet()) {
						ForeignKeyColumnReferenceEntity foreignKeyColumnReferenceEntity = new ForeignKeyColumnReferenceEntity();
						foreignKeyColumnReferenceEntity.setLocalColumnName(entry.getKey());
						foreignKeyColumnReferenceEntity.setReferenceColumnName(entry.getValue());
						foreignKeyColumnReferenceEntityList.add(foreignKeyColumnReferenceEntity);
					}
					foreignKeyTableReferenceEntity.setcolumnList(foreignKeyColumnReferenceEntityList);
					foreignKeyTableReferenceEntity.setconstraintName(String.valueOf(foreignKeyDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + FOREIGN_KEY_NAME)));
					foreignKeyTableReferenceEntity.setMatchType(MatchEnum.SIMPLE);
					foreignKeyTableReferenceEntity.setOnDelete(OnchangeActionEnum.NO_ACTION);
					foreignKeyTableReferenceEntity.setOnUpdate(OnchangeActionEnum.NO_ACTION);
					foreignKeyTableReferenceEntity.setreferenceTableName(String.valueOf(foreignKeyDetails
							.get(TableDefinitionConstants.TABLE_DEFINITION_FOREIGN_DETAILS_MAIN + REFERENCE_TABLE)));
					foreignKeyTableReferenceEntityList.add(foreignKeyTableReferenceEntity);
				} catch (JsonConversionException e) {
					e.printStackTrace();
				}
			});
		} catch (Exception exception) {
			logger.error("Exception occured at checkForeignKeyList method" + exception.getMessage());
			logger.info("checkForeignKeyList method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("checkForeignKeyList method execution ended.");
	}

	/**
	 * getDropColumnList method used for drop column list
	 * 
	 * @param columnsList                 contains columns list
	 * @param mainTableDropColumnList     contains main table drop column list
	 * @param langDependentDropColumnList contains lang dependent drop column list
	 * @param dropColumnEntityList        contains drop column entity list
	 * @param onlineTableColumnMap        contains online table column
	 * @param langDepedentTablePresent    contains lang dependent present or not
	 */
	private static void getDropColumnList(List<String> columnsList, List<String> mainTableDropColumnList,
			List<String> langDependentDropColumnList, List<DropColumnEntity> dropColumnEntityList,
			Map<String, List<Map<String, Object>>> onlineTableColumnMap, boolean langDepedentTablePresent) {
		logger.info("getDropColumnList method execution started.");
		List<String> previousOnlineColumns = new ArrayList<>(onlineTableColumnMap.keySet());
		previousOnlineColumns.removeAll(columnsList);
		if (previousOnlineColumns.isEmpty()) {
			logger.info("No drop columns");
		} else {
			previousOnlineColumns.forEach(columnName -> {
				Map<String, Object> onlineColumnMap = onlineTableColumnMap.get(columnName).get(0);
				if (Objects
						.nonNull(onlineColumnMap.get(
								TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
						&& (Boolean.parseBoolean(String.valueOf(
								onlineColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
										+ ".langDependentFlag"))))) {
					langDependentDropColumnList.add(columnName);
				} else {
					mainTableDropColumnList.add(columnName);
				}
			});
		}
		if (mainTableDropColumnList.isEmpty()) {
			logger.info("no drop column in main table");
		} else {
			new HashSet<String>(mainTableDropColumnList).forEach(mainDropColumn -> {
				DropColumnEntity dropColumnEntity = new DropColumnEntity();
				dropColumnEntity.setColumnNames(mainDropColumn);
				dropColumnEntity.setLangDependent(false);
				dropColumnEntityList.add(dropColumnEntity);
			});
		}
		if (langDependentDropColumnList.isEmpty()) {
			logger.info("no drop column in lang table");
		} else if (langDepedentTablePresent) {
			new HashSet<String>(langDependentDropColumnList).forEach(langDropColumn -> {
				DropColumnEntity dropColumnEntity = new DropColumnEntity();
				dropColumnEntity.setColumnNames(langDropColumn);
				dropColumnEntity.setLangDependent(true);
				dropColumnEntityList.add(dropColumnEntity);
			});
		}
		logger.info("getDropColumnList method execution ended.");
	}

	/**
	 * checkAlterChange method used check whether changes in column alter or not
	 * 
	 * @param resultMap              contains dataclass & data element details
	 * @param primaryKeyList         contains primary key details
	 * @param columnDetailsMap       contains grid column details
	 * @param setLangDependentChange set lang dependent change
	 * @param onlineTableColumnMap   contains table details
	 * @param tableDetailsMap
	 */
	@SuppressWarnings("unchecked")
	private static void checkAlterChange(Map<String, Object> resultMap, List<String> primaryKeyList,
			Map<String, Object> columnDetailsMap, AtomicBoolean setLangDependentChange,
			Map<String, Object> onlineTableColumnMap, Map<String, Object> tableDetailsMap) {
		logger.info("checkAlterChange method execution started.");
		if (!columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".serialNumber")
				.equals(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".serialNumber"))) {
			logger.info("column removed and ordered so drop and adding columns");
			resultMap.put(ORDERCHANGE, true);
			resultMap.put(ADD_COLUMN_ENTITY_LIST,
					addColumnDetails(resultMap, primaryKeyList, columnDetailsMap, setLangDependentChange));
		} else if (checkLangDepenDentChange(columnDetailsMap, onlineTableColumnMap)) {
			setLangDependentChange.set(true);
			resultMap.put(TABLE_CHANGE_TO_LANG_DEPENDENT, true);
			// need to check data type change for source code generation
			resultMap.put(ADD_COLUMN_ENTITY_LIST,
					addColumnDetails(resultMap, primaryKeyList, columnDetailsMap, setLangDependentChange));
		} else {
			Map<String, Object> changesMap = new HashMap<>();
			logger.info("primary key changes check");
			checkPrimaryKeyChanges(primaryKeyList, columnDetailsMap, onlineTableColumnMap, changesMap);
			if (!changesMap.containsKey(PRIMARY_KEY_CHANGE)
					|| (Boolean.parseBoolean(String.valueOf((changesMap.get(PRIMARY_KEY_CHANGE)))))) {
				logger.info("Not Null check.");
				checkNotNullChanges(columnDetailsMap, onlineTableColumnMap, changesMap);
			}
			logger.info("Encrytion change check");
			checkEncrytionChange(columnDetailsMap, onlineTableColumnMap, changesMap);
			Map<String, Object> dataElementDetailsMap = new HashMap<>();
			Map<String, Object> dataFormatDetailsMap = new HashMap<>();
			if (Objects.nonNull(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
					&& !columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT)
							.toString().isEmpty()) {
				dataElementDetailsMap = ((Map<String, List<Map<String, Object>>>) resultMap
						.get(TableDefinitionConstants.DATA_ELEMENT_DETAILS))
								.get(columnDetailsMap.get(
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
								.get(0);
				if (Objects.nonNull(dataElementDetailsMap.get(AUTONUMBER))
						&& (boolean) dataElementDetailsMap.get(AUTONUMBER)) {
					columnDetailsMap
							.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG, true);
				} else {
					columnDetailsMap.put(
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG, false);
				}
			} else if (Objects.nonNull(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
					&& !columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT).toString()
							.isEmpty()) {
				dataFormatDetailsMap = ((Map<String, List<Map<String, Object>>>) resultMap
						.get(TableDefinitionConstants.DATA_FORMAT_DETAILS))
								.get(columnDetailsMap.get(
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
								.get(0);
				if (Objects.nonNull(dataFormatDetailsMap.get(AUTONUMBER))
						&& (boolean) dataFormatDetailsMap.get(AUTONUMBER)) {
					columnDetailsMap
							.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG, true);
				} else {
					columnDetailsMap.put(
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG, false);
				}
			}
			if (Objects
					.nonNull(columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))
					&& (Boolean.parseBoolean(String.valueOf(columnDetailsMap.get(
							TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))))) {
				if (changesMap.containsKey(ENCRYPTION_COLUMN_CHANGES) && !TableDefinitionUtils
						.convertDataType(onlineTableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2))
						.equals(TableDefinitionUtils
								.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE))) {
					changesMap.put(DATA_TYPE, true);
				}
			} else if (!dataElementDetailsMap.isEmpty()) {
				checkDataTypeLengthPrecisionChanges(dataElementDetailsMap, onlineTableColumnMap, changesMap);
			} else if (!dataFormatDetailsMap.isEmpty()) {
				checkDataTypeLengthPrecisionChanges(dataFormatDetailsMap, onlineTableColumnMap, changesMap);
			} else {
				dataTypeChangeForNotUsedDataElement(columnDetailsMap, onlineTableColumnMap, changesMap);
			}
			if (changesMap.isEmpty() || (changesMap.size() == 1 && changesMap.containsKey(ENCRYPTION_COLUMN_CHANGES))) {
				logger.info("No change alter in this column or only encryption key is added.");
			} else {
				TableColumnDefinitionEntity columnDefinitionEntity = new TableColumnDefinitionEntity();
				columnDefinitionEntity.setcolumnName(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
				if (changesMap.containsKey(PRIMARY_KEY_CHANGE)
						&& (Boolean.parseBoolean(String.valueOf(changesMap.get(PRIMARY_KEY_CHANGE))))) {
					columnDefinitionEntity.setisNotNull(true);
				} else if (changesMap.containsKey("notNullChanges")) {
					columnDefinitionEntity
							.setisNotNull((Boolean.parseBoolean(String.valueOf(changesMap.get("notNullChanges")))));
				} else if (Objects.nonNull(
						columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))
						&& (Boolean.parseBoolean(String.valueOf(columnDetailsMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))))) {
					columnDefinitionEntity.setisNotNull(true);
				}

				if (changesMap.containsKey(ENCRYPTION_COLUMN_CHANGES)) {
					if (changesMap.containsKey(DATA_TYPE)) {
						columnDefinitionEntity.setdataType(
								TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
					}
				} else if (changesMap.containsKey(DATA_TYPE)) {
					logger.info("data type change is set");
					alterDataTypeChange(columnDetailsMap, changesMap, columnDefinitionEntity);
					if (!changesMap.containsKey("nosourcecodegenerate"))
						resultMap.put(SET_SOURCE_CODE_GENERATE, true);
				} else {
					setDefaultAndLength(changesMap, columnDefinitionEntity);
					if (changesMap.containsKey(TableDefinitionConstants.MAX_LENGTH)
							|| changesMap.containsKey(TableDefinitionConstants.DECIMAL_VALUE)) {
						columnDefinitionEntity.setdataType(TableDefinitionUtils
								.convertDataType(columnDetailsMap.get("tableDefinitionColumnDetails.dataType")));
						columnDefinitionEntity.setAlterDataTypeUsingNull(false);
						if (tableDetailsMap.containsKey("forceUpdateKey")) {
							columnDefinitionEntity.setAlterDataTypeUsingNull(true);
						}
					}
				}
				if (changesMap.containsKey(TableDefinitionConstants.DEFAULT_VALUE)) {
					columnDetailsMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE,
							changesMap.get(TableDefinitionConstants.DEFAULT_VALUE));
				} else if (!changesMap.containsKey(TableDefinitionConstants.DEFAULT_VALUE)
						&& Objects.nonNull(columnDetailsMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
						&& !String
								.valueOf(columnDetailsMap.get(
										TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
								.isEmpty()) {
					columnDefinitionEntity.setdefaultValue(String.valueOf(columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE)));
				}
				if (Objects
						.nonNull(columnDetailsMap.get(
								TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
						&& (Boolean.parseBoolean(String.valueOf(
								columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
										+ ".langDependentFlag"))))) {
					columnDefinitionEntity.setLangDependent(true);
				}
				resultMap.put(ALTER_COLUMN_ENTITY_LIST, columnDefinitionEntity);
			}

		}
		logger.info("checkAlterChange method execution ended.");
	}

	/**
	 * alterDataTypeChange method used for alter data type
	 * 
	 * @param resultMap              contains table details
	 * @param columnDetailsMap       contains column details map
	 * @param changesMap             contains changes map
	 * @param columnDefinitionEntity contains column definition entity
	 */
	private static void alterDataTypeChange(Map<String, Object> columnDetailsMap, Map<String, Object> changesMap,
			TableColumnDefinitionEntity columnDefinitionEntity) {
		logger.info("alterDataTypeChange method execution started.");
		columnDefinitionEntity.setdataType(String.valueOf(changesMap.get(DATA_TYPE)));
		if ((Objects
				.isNull(columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))
				|| !(Boolean.parseBoolean(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL)))))) {
			columnDefinitionEntity.setAlterDataTypeUsingNull(true);
		}
		setDefaultAndLength(changesMap, columnDefinitionEntity);
		logger.info("alterDataTypeChange method execution ended.");
	}

	/**
	 * setDefaultAndLength method set default length and value
	 * 
	 * @param changesMap             method changes details
	 * @param columnDefinitionEntity contains column definition entity
	 */
	private static void setDefaultAndLength(Map<String, Object> changesMap,
			TableColumnDefinitionEntity columnDefinitionEntity) {
		logger.info("setDefaultAndLength method execution started.");
		if (changesMap.containsKey(TableDefinitionConstants.DEFAULT_VALUE)) {
			if (Objects.nonNull(changesMap.get(TableDefinitionConstants.DEFAULT_VALUE))) {

				columnDefinitionEntity
						.setdefaultValue(String.valueOf(changesMap.get(TableDefinitionConstants.DEFAULT_VALUE)));
			} else {
				columnDefinitionEntity.setdefaultValue(null);
			}
		}
		if (changesMap.containsKey(TableDefinitionConstants.MAX_LENGTH)) {
			if (Objects.nonNull(changesMap.get(TableDefinitionConstants.MAX_LENGTH))) {
				columnDefinitionEntity.setLength(
						Integer.parseInt(String.valueOf(changesMap.get(TableDefinitionConstants.MAX_LENGTH))));
			} else {
				columnDefinitionEntity.setLength(null);
			}
		}
		if (changesMap.containsKey(TableDefinitionConstants.DECIMAL_VALUE)) {
			if (Objects.nonNull(changesMap.get(TableDefinitionConstants.DECIMAL_VALUE))) {

				columnDefinitionEntity.setPrecision(
						Integer.parseInt(String.valueOf(changesMap.get(TableDefinitionConstants.DECIMAL_VALUE))));
			} else {
				columnDefinitionEntity.setPrecision(null);
			}
		}
		logger.info("setDefaultAndLength method execution ended.");
	}

	/**
	 * dataTypeChangeForNotUsedDataElement method used for data type change for not
	 * used data element
	 * 
	 * @param columnDetailsMap     contains column details map
	 * @param onlineTableColumnMap contains online table column map
	 * @param changesMap           contains changes map
	 */
	private static void dataTypeChangeForNotUsedDataElement(Map<String, Object> columnDetailsMap,
			Map<String, Object> onlineTableColumnMap, Map<String, Object> changesMap) {
		logger.info("dataTypeChangeForNotUsedDataElement method execution started.");
		logger.info("Check data type and data class for *** column");
		String currentDataType = TableDefinitionUtils.convertDataType(String.valueOf(
				columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)));
		String onlineDataType = TableDefinitionUtils.convertDataType(String.valueOf(
				onlineTableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)));
		if (!currentDataType.equals(onlineDataType)) {
			logger.info("Data type changed.");
			changesMap.put(DATA_TYPE, currentDataType);
			if (Objects.nonNull(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
					&& !StringUtils.isEmpty(columnDetailsMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE)
							.toString().trim())) {
				changesMap.put(TableDefinitionConstants.DEFAULT_VALUE, columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE));
			}
			if (currentDataType.equals(TableDefinitionConstants.NUMERIC_DATATYPE)
					|| currentDataType.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)) {
				if (Objects.nonNull(
						columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						&& !String
								.valueOf(columnDetailsMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
								.isEmpty()) {
					changesMap.put(TableDefinitionConstants.MAX_LENGTH,
							String.valueOf(columnDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
									.split(",")[0]);
					if (currentDataType.equals(TableDefinitionConstants.NUMERIC_DATATYPE) && String
							.valueOf(columnDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
							.contains(",")) {
						changesMap.put(TableDefinitionConstants.DECIMAL_VALUE,
								String.valueOf(columnDetailsMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
										.split(",")[1]);
					}
				}
			}
		} else {
			logger.info("check default value lenght and precision change ");

			String defaultValueChanged = String.valueOf(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
					.trim();
			String onlineDefaultValue = String.valueOf(onlineTableColumnMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE)).trim();
			if (!defaultValueChanged.equals(onlineDefaultValue)) {
				changesMap.put(TableDefinitionConstants.DEFAULT_VALUE, columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE));
			}
			if (currentDataType.equals(TableDefinitionConstants.NUMERIC_DATATYPE)
					|| currentDataType.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)) {
				if ((Objects.isNull(
						columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						|| String
								.valueOf(columnDetailsMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
								.isEmpty())
						&& (Objects
								.isNull(onlineTableColumnMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
								|| String
										.valueOf(onlineTableColumnMap.get(
												TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
										.isEmpty())) {
					logger.info("no length changes");
				} else {
					String lengthValueChanged = String
							.valueOf(columnDetailsMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
							.trim();
					String onlineLengthValue = String
							.valueOf(onlineTableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
							.trim();
					if (!lengthValueChanged.split(",")[0].equals(onlineLengthValue.split(",")[0])) {
						logger.info("length changed.");
						changesMap.put(TableDefinitionConstants.MAX_LENGTH, lengthValueChanged.split(",")[0]);
						if (Objects.isNull(columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))) {
							changesMap.put(TableDefinitionConstants.MAX_LENGTH, null);
						}
					}
					if (currentDataType.equals(TableDefinitionConstants.NUMERIC_DATATYPE)) {
						if (onlineLengthValue.contains(",")) {
							if (lengthValueChanged.contains(",")) {
								if (!lengthValueChanged.split(",")[1].equals(onlineLengthValue.split(",")[1])) {
									changesMap.put(TableDefinitionConstants.DECIMAL_VALUE,
											lengthValueChanged.split(",")[1]);
								}
							} else {
								changesMap.put(TableDefinitionConstants.DECIMAL_VALUE, null);
							}
						} else if (lengthValueChanged.contains(",")) {
							changesMap.put(TableDefinitionConstants.DECIMAL_VALUE, lengthValueChanged.split(",")[1]);
						}
					}
				}
			}

		}
		logger.info("dataTypeChangeForNotUsedDataElement method execution ended.");
	}

	/**
	 * checkDataTypeLengthPrecisionChanges check used for alter key changes
	 * 
	 * @param dataElementDetailsMap
	 * @param columnDetailsMap
	 * @param onlineTableColumnMap
	 * @param changesMap
	 */
	private static void checkDataTypeLengthPrecisionChanges(Map<String, Object> dataElementDetailsMap,
			Map<String, Object> onlineTableColumnMap, Map<String, Object> changesMap) {
		logger.info("checkDataTypeLengthPrecisionChanges method execution started.");
		String dataTypeChanged = TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE3));
		String onlineDataType = TableDefinitionUtils.convertDataType(
				onlineTableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2));
		if (!dataTypeChanged.equals(onlineDataType)) {
			onlineTableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2,
					dataElementDetailsMap.get(DATA_TYPE3));
			logger.info("Data type changed.");
			changesMap.put(DATA_TYPE, dataTypeChanged);
			if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE)) && !StringUtils
					.isEmpty(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE).toString().trim())) {
				changesMap.put(TableDefinitionConstants.DEFAULT_VALUE,
						String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE)));
			}
			if (dataTypeChanged.equals(TableDefinitionConstants.NUMERIC_DATATYPE)) {
				if (Objects.nonNull(dataElementDetailsMap.get("precision"))
						&& !String.valueOf(dataElementDetailsMap.get("precision")).isEmpty()) {
					String precision = String.valueOf(dataElementDetailsMap.get("precision"));
					changesMap.put(TableDefinitionConstants.MAX_LENGTH, dataElementDetailsMap.get("precision"));
					if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE)) && !String
							.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE)).isEmpty()) {
						precision = precision + "," + dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE);
						changesMap.put(TableDefinitionConstants.DECIMAL_VALUE,
								dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE));
					}
					onlineTableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH,
							precision);
				}
			} else if (dataTypeChanged.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)
					&& Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH))
					&& !String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH)).isEmpty()) {
				changesMap.put(TableDefinitionConstants.MAX_LENGTH,
						dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH));
			}
		} else {
			String defaultValueChanged = String
					.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE)).trim();
			String onlineDefaultValue = String.valueOf(onlineTableColumnMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE)).trim();
			if (!defaultValueChanged.equals(onlineDefaultValue)) {
				changesMap.put(TableDefinitionConstants.DEFAULT_VALUE,
						dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE));
			}
			if (dataTypeChanged.equals(TableDefinitionConstants.NUMERIC_DATATYPE)
					|| dataTypeChanged.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)) {
				if ((Objects.isNull(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH))
						|| String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH)).isEmpty())
						&& (Objects
								.isNull(onlineTableColumnMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
								|| String
										.valueOf(onlineTableColumnMap.get(
												TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
										.isEmpty()) && (Objects.isNull(dataElementDetailsMap.get("precision"))
						|| String.valueOf(dataElementDetailsMap.get("precision")).isEmpty())) {
					logger.info("no length changes");
				} else {

					if (dataTypeChanged.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)) {
						String lengthValueChanged = String
								.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH)).trim();
						String onlineLengthValue = String
								.valueOf(onlineTableColumnMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
								.trim();
						if (!lengthValueChanged.equals(onlineLengthValue.split(",")[0])) {
							if (!changesMap.containsKey(DATA_TYPE)) {
								changesMap.put("nosourcecodegenerate", true);
							}
//							changesMap.put(DATA_TYPE, dataTypeChanged);
							logger.info("length changed.");
							changesMap.put(TableDefinitionConstants.MAX_LENGTH,
									dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH));
						}
					} else {
						String lengthValueChanged = String.valueOf(dataElementDetailsMap.get("precision")).trim();
						String onlineLengthValue = String
								.valueOf(onlineTableColumnMap
										.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
								.trim();
						if (!lengthValueChanged.equals(onlineLengthValue.split(",")[0])) {
							if (!changesMap.containsKey(DATA_TYPE)) {
								changesMap.put("nosourcecodegenerate", true);
							}
//							changesMap.put(DATA_TYPE, dataTypeChanged);
							logger.info("length changed.");
							if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))
									){
								changesMap.put(TableDefinitionConstants.DECIMAL_VALUE,
										dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE));
							}
							changesMap.put(TableDefinitionConstants.MAX_LENGTH, dataElementDetailsMap.get("precision"));
						}

						if (onlineLengthValue.contains(",")) {
							if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))
									&& !String
											.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))
											.equals(onlineLengthValue.split(",")[1])) {
								changesMap.put(TableDefinitionConstants.MAX_LENGTH,
										dataElementDetailsMap.get("precision"));
								if (!changesMap.containsKey(DATA_TYPE)) {
									changesMap.put("nosourcecodegenerate", true);
								}
								changesMap.put(TableDefinitionConstants.MAX_LENGTH,
										dataElementDetailsMap.get("precision"));
//								changesMap.put(DATA_TYPE, dataTypeChanged);
								changesMap.put(TableDefinitionConstants.DECIMAL_VALUE,
										dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE));
							} else if(Objects.isNull(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))) {
								if (!changesMap.containsKey(DATA_TYPE)) {
									changesMap.put("nosourcecodegenerate", true);
								}
//								changesMap.put(DATA_TYPE, dataTypeChanged);
								if(!changesMap.containsKey(TableDefinitionConstants.DECIMAL_VALUE)) {
								changesMap.put(TableDefinitionConstants.DECIMAL_VALUE, null);
								}
							}
						} else if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))
								&& !String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))
										.isEmpty()) {
							changesMap.put(TableDefinitionConstants.MAX_LENGTH, dataElementDetailsMap.get("precision"));
							if (!changesMap.containsKey(DATA_TYPE)) {
								changesMap.put("nosourcecodegenerate", true);
							}
//							changesMap.put(DATA_TYPE, dataTypeChanged);
							changesMap.put(TableDefinitionConstants.DECIMAL_VALUE,
									dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE));
						}
					}
				}
			}
		}
		logger.info("checkDataTypeLengthPrecisionChanges method execution ended.");
	}

	/**
	 * checkEncrytionChange method used to check encryption changes
	 * 
	 * @param columnDetailsMap     contains column details map
	 * @param onlineTableColumnMap contains online table column map
	 * @param changesMap           contains changes map
	 */
	private static void checkEncrytionChange(Map<String, Object> columnDetailsMap,
			Map<String, Object> onlineTableColumnMap, Map<String, Object> changesMap) {
		logger.info("checkEncrytionChange method execution started");
		Boolean mainEncryptionKeyColumn = Objects
				.nonNull(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))
				&& (Boolean.parseBoolean(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))));
		Boolean onlineEncryptionKeyColumn = Objects
				.nonNull(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))
				&& (Boolean.parseBoolean(String.valueOf(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))));
		if (!mainEncryptionKeyColumn.equals(onlineEncryptionKeyColumn)) {
			changesMap.put(ENCRYPTION_COLUMN_CHANGES, mainEncryptionKeyColumn);
		}
		logger.info("checkEncrytionChange method execution ended");
	}

	/**
	 * checkNotNullChanges method used for not null changes
	 * 
	 * @param columnDetailsMap     contains column details
	 * @param onlineTableColumnMap contains online table column map
	 * @param changesMap           contains changes map
	 */
	private static void checkNotNullChanges(Map<String, Object> columnDetailsMap,
			Map<String, Object> onlineTableColumnMap, Map<String, Object> changesMap) {
		logger.info("checkNotNullChanges method execution started.");
		Boolean notNullKeyColumn = Objects
				.nonNull(columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))
				&& (Boolean.parseBoolean(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))));
		Boolean onlineNotNullKeyColumn = Objects.nonNull(
				onlineTableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))
				&& (Boolean.parseBoolean(String.valueOf(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))));
		if (!notNullKeyColumn.equals(onlineNotNullKeyColumn)) {
			changesMap.put("notNullChanges", notNullKeyColumn);
		}
		logger.info("checkNotNullChanges method execution ended.");
	}

	/**
	 * checkPrimaryKeyChanges used for check primary key changes
	 * 
	 * @param primaryKeyList       contains primary key list
	 * @param columnDetailsMap     contains column details map
	 * @param onlineTableColumnMap contains online table column map
	 * @param changesMap           contains changes details
	 */
	private static void checkPrimaryKeyChanges(List<String> primaryKeyList, Map<String, Object> columnDetailsMap,
			Map<String, Object> onlineTableColumnMap, Map<String, Object> changesMap) {
		logger.info("checkPrimaryKeyChanges method execution started.");
		boolean primaryKeyColumn = Objects.nonNull(
				columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))
				&& (Boolean.parseBoolean(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))));
		Boolean onlineKeyColumn = Objects.nonNull(
				onlineTableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))
				&& (Boolean.parseBoolean(String.valueOf(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))));
		if (primaryKeyColumn) {
			logger.info("primary key column column ");
			primaryKeyList.add(String.valueOf(
					columnDetailsMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
		}
		if (!onlineKeyColumn.equals(primaryKeyColumn)) {
			changesMap.put(PRIMARY_KEY_CHANGE, primaryKeyColumn);
		}
		logger.info("checkPrimaryKeyChanges method execution ended.");
	}

	/**
	 * checkLangDepenDentChange method used for checking lang dependent column
	 * change to non lang dependent column & vice versa
	 * 
	 * @param columnDetailsMap     contains grid column details
	 * @param onlineTableColumnMap contains main table column details
	 * @return langDependent change or not
	 */
	private static boolean checkLangDepenDentChange(Map<String, Object> columnDetailsMap,
			Map<String, Object> onlineTableColumnMap) {
		logger.info("checkLangDepenDentChange method started.");
		Boolean gridColumnLangDependet = Objects
				.nonNull(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
				&& (Boolean.parseBoolean(String.valueOf(columnDetailsMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))));
		Boolean onlineLangDependent = Objects
				.nonNull(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
				&& (Boolean.parseBoolean(String.valueOf(onlineTableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))));
		if (onlineLangDependent.equals(gridColumnLangDependet)) {
			logger.info("No changes in lang dependent");
			logger.info("checkLangDepenDentChange method ended.");
			return false;
		}
		logger.info("Lang Dependent column changes.");
		logger.info("checkLangDepenDentChange method ended.");
		return true;
	}

	/**
	 * addColumnDetails method used for setting primary and adding column details
	 * 
	 * @param resultMap                  contains data class details
	 * @param langDependentColumnList    contains lang dependent details
	 * @param primaryKeyList             contains primary key details
	 * @param tableColumnDefintionEntity contains table column details entity
	 * @param tableColumnMap             contains table column details map
	 * @param setLangDependentChange     status for lang dependent change
	 */
	@SuppressWarnings("unchecked")
	private static TableColumnDefinitionEntity addColumnDetails(Map<String, Object> resultMap,
			List<String> primaryKeyList, Map<String, Object> tableColumnMap, AtomicBoolean setLangDependentChange) {
		logger.info("addColumnDetails method execution started.");
		TableColumnDefinitionEntity tableColumnDefintionEntity = new TableColumnDefinitionEntity();
		Map<String, Object> dataElementDetailsMap = new HashMap<>();
		Map<String, Object> dataFormatDetailsMap = new HashMap<>();
		if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
				&& !tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT)
						.toString().isBlank()) {
			dataElementDetailsMap = ((Map<String, List<Map<String, Object>>>) resultMap
					.get(TableDefinitionConstants.DATA_ELEMENT_DETAILS))
							.get(tableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
							.get(0);
			if (Objects.nonNull(dataElementDetailsMap.get(AUTONUMBER))
					&& (boolean) dataElementDetailsMap.get(AUTONUMBER)) {
				tableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
						true);
			} else {
				tableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
						false);
			}
		} else if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
				&& !tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT)
						.toString().isBlank()) {
			dataFormatDetailsMap = ((Map<String, List<Map<String, Object>>>) resultMap
					.get(TableDefinitionConstants.DATA_FORMAT_DETAILS))
							.get(tableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
							.get(0);
			if (Objects.nonNull(dataFormatDetailsMap.get(AUTONUMBER))
					&& (boolean) dataFormatDetailsMap.get(AUTONUMBER)) {
				tableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
						true);
			} else {
				tableColumnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
						false);
			}
		}

		setPrimaryKeyAndNotNull(primaryKeyList, tableColumnMap, tableColumnDefintionEntity, resultMap);
		if (Objects
				.nonNull(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))
				&& (Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))))) {
			tableColumnDefintionEntity
					.setdataType(TableDefinitionUtils.convertDataType(TableDefinitionConstants.STRING_DATA_TYPE));
		} else if (!dataElementDetailsMap.isEmpty()) {
			setDataTypeAndLength(tableColumnDefintionEntity, dataElementDetailsMap);
		} else if (!dataFormatDetailsMap.isEmpty()) {
			setDataTypeAndLength(tableColumnDefintionEntity, dataFormatDetailsMap);
		} else {
			dataElementAndDataTypeNotMentioned(tableColumnMap, tableColumnDefintionEntity);
		}
		setLangDependentColumn(tableColumnMap, tableColumnDefintionEntity, setLangDependentChange, resultMap);
		tableColumnDefintionEntity.setcolumnName(String.valueOf(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
		logger.info("addColumnDetails method execution ended.");
		return tableColumnDefintionEntity;
	}

	/**
	 * setLangDependentColumn method used for lang dependent change
	 * 
	 * @param tableColumnMap             contains column details
	 * @param tableColumnDefintionEntity contains column entity
	 * @param setLangDependentChange     status for lang dependent
	 */
	private static void setLangDependentColumn(Map<String, Object> tableColumnMap,
			TableColumnDefinitionEntity tableColumnDefintionEntity, AtomicBoolean setLangDependentChange,
			Map<String, Object> resultMap) {
		logger.info("setLangDependentColumn method execution started.");
		if (Objects
				.nonNull(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))
				&& (Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + ".langDependentFlag"))))) {
			tableColumnDefintionEntity.setLangDependent(true);
			resultMap.put("langDependentColumnAdded", true);
			setLangDependentChange.set(true);
		}
		logger.info("setLangDependentColumn method execution ended.");
	}

	/**
	 * dataElementAndDataTypeNotMentioned method used when *** for data element and
	 * data class
	 * 
	 * @param tableColumnMap              contains data type details
	 * @param tableColumnDefinitionEntity when data type is set
	 */
	private static void dataElementAndDataTypeNotMentioned(Map<String, Object> tableColumnMap,
			TableColumnDefinitionEntity tableColumnDefinitionEntity) {
		logger.info("dataElementAndDataTypeNotMentioned method execution started.");
		if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
				&& !StringUtils.isEmpty(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE).toString()
						.trim())) {
			tableColumnDefinitionEntity.setdefaultValue(String.valueOf(
					tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE)));
		}
		if (String
				.valueOf(TableDefinitionUtils.convertDataType(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)))
				.equals(TableDefinitionConstants.NUMERIC_DATATYPE)) {
			if (Objects
					.nonNull(tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
					&& !String
							.valueOf(tableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
							.isEmpty()) {
				tableColumnDefinitionEntity.setLength(Integer.parseInt(String
						.valueOf(tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						.split(",")[0]));
				if (String
						.valueOf(tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						.contains(",")) {
					tableColumnDefinitionEntity.setPrecision(Integer.parseInt(String
							.valueOf(tableColumnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
							.split(",")[1]));
				}
			}
		} else if (String
				.valueOf(TableDefinitionUtils.convertDataType(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)))
				.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)
				&& Objects.nonNull(
						tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
				&& !String
						.valueOf(tableColumnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))
						.isEmpty()) {
			tableColumnDefinitionEntity.setLength(Integer.parseInt(String.valueOf(
					tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH))));
		}
		tableColumnDefinitionEntity.setdataType(TableDefinitionUtils.convertDataType(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_TYPE2)));
		logger.info("dataElementAndDataTypeNotMentioned method execution ended.");
	}

	/**
	 * setDataTypeAndLength method used for set datatype and length
	 * 
	 * @param tableColumnDefinitionEntity contains table column definition entity
	 * @param dataElementDetailsMap       contains data element details map
	 */
	private static void setDataTypeAndLength(TableColumnDefinitionEntity tableColumnDefinitionEntity,
			Map<String, Object> dataElementDetailsMap) {
		logger.info("setDataTypeAndLength method execution started.");
		tableColumnDefinitionEntity
				.setdataType(TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE3)));
		if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE)) && !StringUtils
				.isEmpty(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE).toString().trim())) {
			tableColumnDefinitionEntity
					.setdefaultValue(String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DEFAULT_VALUE)));
		}
		if (String.valueOf(TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE3)))
				.equals(TableDefinitionConstants.NUMERIC_DATATYPE)) {
			if (Objects.nonNull(dataElementDetailsMap.get("precision"))
					&& !String.valueOf(dataElementDetailsMap.get("precision")).isEmpty()) {
				tableColumnDefinitionEntity
						.setLength(Integer.parseInt(String.valueOf(dataElementDetailsMap.get("precision"))));
			}
			if (Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))
					&& !String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE)).isEmpty()) {
				tableColumnDefinitionEntity.setPrecision(Integer
						.parseInt(String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.DECIMAL_VALUE))));
			}
		} else if (String.valueOf(TableDefinitionUtils.convertDataType(dataElementDetailsMap.get(DATA_TYPE3)))
				.equals(TableDefinitionConstants.CHARACTER_VARYING_DATATYPE)
				&& Objects.nonNull(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH))
				&& !String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH)).isEmpty()) {
			tableColumnDefinitionEntity.setLength(
					Integer.parseInt(String.valueOf(dataElementDetailsMap.get(TableDefinitionConstants.MAX_LENGTH))));
		}
		logger.info("setDataTypeAndLength method execution ended.");
	}

	/**
	 * setPrimaryKeyAndNotNull method used set primary key details
	 * 
	 * @param primaryKeyList              contains primaryKey list
	 * @param tableColumnMap              contains table column details
	 * @param tableColumnDefinitionEntity contains table column entity
	 * @param resultMap                   contains primary key added or not check
	 */
	private static void setPrimaryKeyAndNotNull(List<String> primaryKeyList, Map<String, Object> tableColumnMap,
			TableColumnDefinitionEntity tableColumnDefinitionEntity, Map<String, Object> resultMap) {
		logger.info("setPrimaryKeyAndNotNull method execution started.");
		if (Objects.nonNull(
				tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))
				&& (Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + PRIMARY_KEY))))) {
			logger.info("primary key column column ");
			primaryKeyList.add(String.valueOf(
					tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
			tableColumnDefinitionEntity.setisNotNull(true);
			resultMap.put(PRIMARY_KEY_COLUMN, true);
		} else if (Objects
				.nonNull(tableColumnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))
				&& (Boolean.parseBoolean(String.valueOf(tableColumnMap
						.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))))) {
			logger.info("Non Null column ");
			tableColumnDefinitionEntity.setisNotNull(true);
		}
		logger.info("setPrimaryKeyAndNotNull method execution ended.");
	}

	/**
	 * alterFromDataClassmethod used for alter from data class and data elements
	 * 
	 * @param productExecutor   contains table connection
	 * @param processMap        contains dataclass and column details
	 * @param tableMetaExecutor
	 * @param tempColumnList 
	 * @throws CustomException contains error
	 */
	@SuppressWarnings("unchecked")
	public static void alterFromDataClass(QueryExecutor productExecutor, Map<String, Object> processMap,
			QueryExecutor tableMetaExecutor, List<Map<String, Object>> tempColumnList) throws CustomException {
		try {
			List<TableColumnDefinitionEntity> columnDefinitionEntityList = new ArrayList<>();
			Map<String, List<Map<String, Object>>> dataElementMap = new HashMap<>();
			Map<String, List<Map<String, Object>>> dataFormatMap = new HashMap<>();
			if (processMap.containsKey(TableDefinitionConstants.DATA_ELEMENT_DETAILS)) {
				dataElementMap = ((Map<String, List<Map<String, Object>>>) processMap
						.get(TableDefinitionConstants.DATA_ELEMENT_DETAILS));
			}
			if (processMap.containsKey(TableDefinitionConstants.DATA_FORMAT_DETAILS)) {
				dataFormatMap = ((Map<String, List<Map<String, Object>>>) processMap
						.get(TableDefinitionConstants.DATA_FORMAT_DETAILS));
			}
			List<Map<String, Object>> columnList = (List<Map<String, Object>>) processMap
					.get(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP);
			
			tableMetaExecutor = new QueryBuilder().btSchema().getQueryExecutor();
			tableMetaExecutor.skipChangeRequest(true);
			
			if (processMap.containsKey("forceUpdateKey")) {
				productExecutor = getProductExecutor(
						(Map<String, Object>) processMap.get("productDetailsMap"));
				productExecutor.skipChangeRequest(true);
				productExecutor.setProductCode(String.valueOf(processMap.get(TableDefinitionConstants.PRODUCT_CODE)));
				productExecutor.queryBuilder().delete()
						.setProductCode(String.valueOf(processMap.get(TableDefinitionConstants.PRODUCT_CODE)))
						.skipInactiveStatus(true)
						.from(String.valueOf(processMap.get(TableDefinitionConstants.TABLENAME))).build().execute();
			}
			
			for (Map<String, Object> columnMap : columnList) {
				Map<String, Object> changesMap = new HashMap<>();
				Map<String, Object> dataDefinitionMap;
				if (dataElementMap.containsKey(
						columnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))) {
					dataDefinitionMap = dataElementMap
							.get(columnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ELEMENT))
							.get(0);
					columnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT,
							dataDefinitionMap.get("table_data_format"));
				} else {
					dataDefinitionMap = dataFormatMap
							.get(columnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_FORMAT))
							.get(0);
				}
				if (Objects.nonNull(dataDefinitionMap.get(AUTONUMBER)) && (boolean) dataDefinitionMap.get(AUTONUMBER)) {
					columnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
							true);
				} else {
					columnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + AUTONUMBER_FLAG,
							false);
				}
				if (Objects
						.isNull(columnMap.get(
								TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DATA_ENCRYPTION_FLAG))
						|| !(Boolean.parseBoolean(String
								.valueOf(columnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
										+ DATA_ENCRYPTION_FLAG))))) {
					checkDataTypeLengthPrecisionChanges(dataDefinitionMap, columnMap, changesMap);
				}
				if (!changesMap.isEmpty()) {
					TableColumnDefinitionEntity columnDefinitionEntity = new TableColumnDefinitionEntity();
					if (Objects.nonNull(
							columnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))
							&& (Boolean.parseBoolean(String.valueOf(columnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + NOT_NULL))))) {
						columnDefinitionEntity.setisNotNull(true);
					}
					columnDefinitionEntity.setcolumnName(String.valueOf(columnMap
							.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + COLUMN_NAME)));
					if (changesMap.containsKey(DATA_TYPE)) {
						logger.info("data type change is set");
						alterDataTypeChange(columnMap, changesMap, columnDefinitionEntity);
						if (!changesMap.containsKey("nosourcecodegenerate"))
							processMap.put(SET_SOURCE_CODE_GENERATE, true);
					} else {
						setDefaultAndLength(changesMap, columnDefinitionEntity);
						if (changesMap.containsKey(TableDefinitionConstants.MAX_LENGTH)
								|| changesMap.containsKey(TableDefinitionConstants.DECIMAL_VALUE)) {
							columnDefinitionEntity.setdataType(TableDefinitionUtils.convertDataType(dataDefinitionMap.get(DATA_TYPE3)));
							columnDefinitionEntity.setAlterDataTypeUsingNull(false);
							if (processMap.containsKey("forceUpdateKey")) {
								columnDefinitionEntity.setAlterDataTypeUsingNull(true);
							}
						}
					}
					if (changesMap.containsKey(TableDefinitionConstants.MAX_LENGTH)
							&& Objects.nonNull(changesMap.get(TableDefinitionConstants.MAX_LENGTH))) {
						String maxLength = String.valueOf(changesMap.get(TableDefinitionConstants.MAX_LENGTH));
						if (changesMap.containsKey(TableDefinitionConstants.DECIMAL_VALUE)
								&& Objects.nonNull(changesMap.get(TableDefinitionConstants.DECIMAL_VALUE))) {
							maxLength = maxLength + ","
									+ String.valueOf(changesMap.get(TableDefinitionConstants.DECIMAL_VALUE));
						}
						columnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH,
								maxLength);
					} else {
						columnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + LENGTH, null);
					}

					if (changesMap.containsKey(TableDefinitionConstants.DEFAULT_VALUE)) {
						columnMap.put(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE,
								changesMap.get(TableDefinitionConstants.DEFAULT_VALUE));
					} else if (!changesMap.containsKey(TableDefinitionConstants.DEFAULT_VALUE)
							&& Objects.nonNull(columnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
							&& !String.valueOf(columnMap
									.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE))
									.isEmpty()) {
						columnDefinitionEntity.setdefaultValue(String.valueOf(columnMap
								.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN + DEFAULT_VALUE)));
					}
					if (Objects
							.nonNull(columnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
									+ ".langDependentFlag"))
							&& (Boolean.parseBoolean(String
									.valueOf(columnMap.get(TableDefinitionConstants.TABLE_DEFINITION_COLUMN_DETAILS_MAIN
											+ ".langDependentFlag"))))) {
						columnDefinitionEntity.setLangDependent(true);
					}
					columnDefinitionEntityList.add(columnDefinitionEntity);
				}
			}
			if (!columnDefinitionEntityList.isEmpty()) {
				TableDefinitionUtils.checkAndInactivateDependentView(productExecutor, tableMetaExecutor,
						String.valueOf(processMap.get(TableDefinitionConstants.TABLENAME)),
						String.valueOf(processMap.get(TableDefinitionConstants.PRODUCT_CODE)), true, new ArrayList<>());
				productExecutor.queryBuilder().table().alterTable()
						.table(String.valueOf(processMap.get(TableDefinitionConstants.TABLENAME)))
						.setProductCode(String.valueOf(processMap.get(TableDefinitionConstants.PRODUCT_CODE)))
						.alterColumns(columnDefinitionEntityList).build().execute();
				logger.info("Alter done from alterFromDataClass method.");
				productExecutor.commit();
				processMap.put(ALTER_DONE, true);
			} else {
				logger.info("Nothing to alter in table structure.");
			}
		} catch (Exception exception) {
			logger.error("Exception in alterFromDataClass method. " + exception);
			try {
				productExecutor.rollBack();
				logger.info("rollback done for productExecutor.");
				tableMetaExecutor.rollBack();
				logger.info("rollback done for tableMetaExecutor.");
			} catch (Exception rollbackException) {
				logger.error("rollbackexception in alterFromDataClass method. " + rollbackException);
			}
			if (exception.getCause() instanceof DataIntegrityViolationException) {
				logger.info("Data integrity exception in alterFromDataClass method...");
				if (processMap.containsKey("forceUpdateKey")) {
					if (!processMap.containsKey("forceUpdateError")) {
						processMap.put("forceUpdateError", true);
					}
					throw new CustomException(exception.getMessage());
				} else {
					processMap.put("forceUpdateKey", true);
					processMap.put(TableDefinitionConstants.TABLE_DEFINITION_DETAILS_MAP, tempColumnList);
					logger.info("Force update trigger from alterFromDataClass method.");
					alterFromDataClass(productExecutor, processMap, tableMetaExecutor, tempColumnList);
				}
			} else {
				throw new CustomException(exception.getMessage());
			}
		}
	}

	/**
	 * getProductExecutor used for set product executor data base details
	 * 
	 * @param productDetailsMap contains product executor connection details
	 * @return executor that contains details
	 * @throws CustomException
	 */
	static QueryExecutor getProductExecutor(Map<String, Object> productDetailsMap) throws CustomException {
		logger.info("getProductExecutor method execution started.");
		QueryExecutor tableCreateOrAlterExecutor = null;
		try {
			tableCreateOrAlterExecutor = new QueryBuilder(
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.URL_KEY)),
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.USER)),
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.PASSKEY)),
					String.valueOf(productDetailsMap.get(TableDefinitionConstants.SCHEMA))).getQueryExecutor();
		} catch (Exception exception) {
			logger.error(exception);
			logger.info("getProductExecutor method execution ended.");
			throw new CustomException(exception.getMessage());
		}
		logger.info("getProductExecutor method execution ended.");
		return tableCreateOrAlterExecutor;
	}
}
