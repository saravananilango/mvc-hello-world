package com.nn.sova.service.utils.viewobject;

/**
 * BusinessObjectConstants contains constant entry for business object
 * 
 * @author Hariprasath Kamaraj
 *
 */
public class ViewObjectConstants {
	
public static final String EXCEPTION = "exception";

/** The Constant DRIVER_KEY. */
public static final String DRIVER_KEY = "driver";

/** The Constant PRODUCT_CONFIGURATION_TABLE. */
public static final String PRODUCT_CONFIGURATION_TABLE = "product_configuration";

/** The Constant PRODUCT_CONFIGURATION_DB_URL COLUMN. */
public static final String PRODUCT_DB_URL = "database_url";

/** The Constant PRODUCT_CONFIGURATION_PORT COLUMN. */
public static final String PRODUCT_PORT = "database_port";

/** The Constant PRODUCT_CONFIGURATION_DATABASE_NAME COLUMN. */
public static final String PRODUCT_DATABASE_NAME = "database_name";

/** The Constant PRODUCT_CONFIGURATION_USER_NAME COLUMN. */
public static final String PRODUCT_USER_NAME = "database_username";

/** The Constant PRODUCT_CONFIGURATION_PASSKEY COLUMN. */
public static final String PRODUCT_PASSKEY = "database_password";

/** The Constant PRODUCT_CONFIGURATION_SCHEMA_NAME  COLUMN. */
public static final String PRODUCT_SCHEMA_NAME = "database_schema";

/** The Constant PASSWORD. */
public static final String PASSKEY = "password";

/** The Constant SCHEMA. */
public static final String SCHEMA = "schema";

/** The Constant USER. */
public static final String USER = "user";

/** The Constant URL_KEY. */
public static final String URL_KEY = "url";

/** The Constant DATABASE_NAME. */
public static final String DATABASE_NAME = "database_name";

/** The Constant PRODUCT_CODE. */
public static final String PRODUCT_CODE_COL = "product_code";

/** The Constant BUSINESS_OBJECT_NAME. */
public static final String VIEW_OBJECT_NAME = "view_object_name";

/** The Constant TABLE_NAME. */
public static final String TABLE_NAME = "table_name";

/** The Constant COLUMN_NAME. */
public static final String COLUMN_NAME = "column_name";

/** The Constant VIEW_OBJECT_DEFINITION. */
public static final String VIEW_OBJECT_DEFINITION = "view_object_definition";

/** The Constant VIEW_OBJECT_COLUMN_DETAILS. */
public static final String VIEW_OBJECT_COLUMN_DETAILS = "view_object_column_details";

/** The Constant STATUS. */

public static final String STATUS = "status";

/** The Constant SORTMAP. */
public static final String SORTMAP = "sortMap";

/** The Constant SEARCH_DATA. */
public static final String SEARCH_DATA = "searchData";

/** The Constant KEY_LIST. */
public static final String KEY_LIST = "keyList";

/** The Constant COUNT. */
public static final String COUNT = "count";

/** The Constant FETCH_LIMIT. */
public static final int FETCH_LIMIT = 20;

/** The Constant DATA_COUNT. */
public static final String DATA_COUNT = "dataCount";

/** The Constant FIRST_INDEX. */
public static final int FIRST_INDEX = 0;

/** The Constant TEXT_TABLE. */
public static final String TEXT_TABLE = "data_elements_text";

/** The Constant TEXT_ID. */
public static final String TEXT_ID = "text_id";

/** The Constant LOCALE. */
public static final String LOCALE = "lang_cd";

/** The Constant LABELS. */
public static final String LABELS = "labels";

/** The Constant LABEL. */
public static final String LABEL = "Label";

/** The Constant SHORT_TEXT. */
public static final String SHORT_TEXT = "Short Text";

/** The Constant MEDIUM_TEXT. */
public static final String MEDIUM_TEXT = "Medium Text";

/** The Constant LONG_TEXT. */
public static final String LONG_TEXT = "Long Text";

/** The Constant LONG_TEXT. */
public static final String EXAMPLE_TEXT = "Example Text";

/** The Constant LONG_TEXT. */
public static final String HINT_TEXT = "Hint Text";

/** The Constant TEXTID. */
public static final String TEXTID = "textId";

/** The Constant TEXT_INFO_TEXTID. */
public static final String TEXT_INFO_PRODUCT_CODE = "textDef.productCode";

/** The Constant TEXT_INFO_TEXTID. */
public static final String TEXT_INFO_TEXTID = "textDef.textId";

/** The Constant TEXT_INFO_LOCALE. */
public static final String TEXT_INFO_LANG_CODE = "textDef.langCd";

/** The Constant TEXT_INFO_TEXT. */
public static final String TEXT_INFO_TEXT_CONTENT = "textDef.textContent";

/** The Constant TEXT_INFO_TEXT. */
public static final String TEXT_INFO_TYPE = "textDef.type";



/** The Constant ERROR. */
public static final String ERROR  = "error";


/** The Constant CONFIG_TABLE_DATA. */
public static final String CONFIG_TABLE_DATA  = "configTableData";

/** The Constant LANG_DEPENDENT. */
public static final String LANG_DEPENDENT  = "lang_dependent_flag";


/** The Constant CREATE_DATE. */
public static final String CREATE_DATE = "view_object_definition.create_date";

/** The Constant UPDATE_DATE. */
public static final String UPDATE_DATE = "view_object_definition.update_date";

/** The Constant TABLE_OBJECT_VIEW. */
public static final String TABLE_OBJECT_VIEW = "view_object_definition.view";


/** The Constant LOCALE_ID. */
public static final String LOCALE_ID = "lang_cd";

/** The Constant LOCALE_TEXT. */
public static final String LOCALE_TEXT = "lang_text";


/** The Constant UNDERSCORE_TEXT. */
public static final String UNDERSCORE_TEXT = "_text";

/** The Constant TABLE_CONFIG_COLUMN_DETAILS. */
public static final String TABLE_DEFINITION_COLUMN_DETAILS = "table_definition_column_details";

/** The Constant ADD_TO_EXISTING. */
public static final String ADD_TO_EXISTING = "addToExisting";

/** The Constant ADD_TO_EXISTING. */
public static final String REQUEST_DESCRIPTION = "title";

/** The Constant REQUEST_DATA. */
public static final String REQUEST_DATA = "requestData";

/** The Constant MESSAGE. */
public static final String MESSAGE = "message";



/** The Constant DAO_NAME. */
public static final String DAO_NAME = "dao_name";

/** The Constant DAO_PKG_NAME. */
public static final String DAO_PKG_NAME = "dao_package_name";


/** The Constant GIT_URL. */
public static final String GIT_URL = "git_url";

/** The Constant PRODUCT_DETAILS_ERROR. */
public static final String PRODUCT_DETAILS_ERROR = "productDetailsError";

/** The Constant POSTGRESQL_DB. */
public static final String POSTGRESQL_DB = "jdbc:postgresql://";


/** The Constant DEFAULT_SYSTEM. */
	public static final String DEFAULT_SYSTEM_NOT_AVAILABLE = "default_system";
	
	/**
	 *The Constant IS_REQUEST_DIALOG. 
	 */
	public static final String IS_REQUEST_DIALOG = "isRequestDialog";
	
	/**
	 *The Constant IS_REQUEST_DIALOG. 
	 */
public static final String DIALOG_PRODUCT_CODE = "dialogProductCode";


/** The Constant COLUMN_DESCRIPTION. */
public static final String COLUMN_DESCRIPTION = "tbConfig.column_description";

/**
 * The string constants LEFT_JOIN
 */
public static final String LEFT_JOIN = "LEFT JOIN";

/**
 *  The string constants RIGHT_JOIN
 */
public static final String RIGHT_JOIN = "RIGHT JOIN";

/**
 * The string constants INNER_JOIN
 */
public static final String INNER_JOIN = "INNER JOIN";

/**
 * The string constants AND_CONDITION
 */
public static final String AND_CONDITION = "AND";

/**
 * The string constants OR_CONDITION
 */
public static final String OR_CONDITION = "OR";

/**
 * The string constants JOIN_CONDITIION
 */
public static final String JOINS = "joins";

/**
 * The string constants WHERE_CONDITIION
 */
public static final String WHERE_CONDITIION ="where";

/**
 * The string constants LEFT_CONDITIION
 */
public static final  String LEFT_CONDITIION ="leftCol";

/**
 * The string constants RIGHT_CONDITIION
 */
public static final String RIGHT_CONDITIION ="rightCol";


/**
 * The string constants APPLICATION_CODE
 */
public static final  String PRODUCT_CODE ="productCode";

/**
 * The string constants APPLICATION_CODE
 * 
 */
public static final  String VIEW_OBJECT ="viewObject";

/**
 * The string constants APPLICATION_CODE
 */
public static final  String COLUMN_DETAILS ="columnDetails";

/**
 * The string constants DB_DETAILS
 */
public static final String DB_DETAILS = "dbDetails";

/**
 * The string constants HOST
 */
public static final String HOST = "host";

/**
 * The string constants HOST
 */
public static final String PORT = "PORT";

/**
 * The string constants TABLE_DEFINITON_REQUEST_HISTORY_DETAILS
 */
public static final String TABLE_DEFINITON_REQUEST_HISTORY_DETAILS	= "table_definiton_request_history_details";

/** The Constant PRODUCT_DETAILS_ERROR. */
public static final String REPO_DETAILS_ERROR = "repoDetailsError";

/**
 * The Constant ROW_DETAILS_MAP.
 */
public static final String ROW_DETAILS_MAP = "rowDetailParamMap";

/**
 * The Constant SORTCOLUMN.
 */
public static final String SORTCOLUMN = "sortColumn";

/**
 * The Constant SORTTYPE.
 */
public static final String SORTTYPE = "sortType";

public static final String VERSION_NO = "version_no";

public static final String VERSION_NUMBER = "versionNumber";

public static final String CHANGE_REQUEST_ID = "changeRequestId";

public static final String WHOLE_PACKAGING = "wholePackaging";





}
