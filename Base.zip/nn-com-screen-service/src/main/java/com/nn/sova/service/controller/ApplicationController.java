package com.nn.sova.service.controller;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.postgresql.util.PGobject;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.entity.ScreenDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.entity.useraccount.UserProfileEntity;
import com.nn.sova.service.enums.SovaResponseStatus;
import com.nn.sova.service.screen.ScreenDefinitionCacheService;
import com.nn.sova.service.service.bookmark.BookmarkServiceImpl;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.service.utils.ContextUtils;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.date.DateStyle;
import com.nn.sova.utility.date.TimeStyle;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * ApplicationController class is common controller for controllers.
 *
 * @author Logchand
 */

public abstract class ApplicationController extends CommonController{

	/** The Constant USER_DATA. */
	private static final String USER_DATA = "userData";

	/** The Constant LANG_CD. */
	private static final String LANG_CODE = "langCode";

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(ApplicationController.class);

	/** The object mapper. */
	private ObjectMapper objectMapper = new ObjectMapper();

	/**
	 * setScreenId is need to set by page controller.
	 *
	 * @return the screen def id
	 */
	public abstract String getScreenDefinitionId();


	/**
	 * showViewPage is used to get the Object of the screen.
	 *
	 * @param request the request
	 * @param returnList the param list
	 * @return Object
	 * @throws QueryException the query exception
	 */
	public List<FrontVo> showViewPage(SovaHttpRequest request, List<FrontVo> returnList) throws QueryException {
		return showViewPage(request, returnList, null);
	}
	//Getprogramname method is used to get value of program name from screenconfiguration cache data.  
	 private String getProgramName() {
	        String locale = UserContext.getInstance().locale();
	        try {
	        	//String s = ContextBean.getSid();
	        	//string b ="NnUserSettingEmpty";
	            Map<String, Object> screenConfigurationData = CacheService.getInstance().getScreenConfigurationDataByLocale(ContextBean.getSid(), locale);
	            //System.out.println(screenConfigurationData.get("screenConfigurationText.programname"));
	            return Objects.toString(screenConfigurationData.get("screenConfiguration.programName"),"");
	        } catch (Exception exception) {
	            return StringUtils.EMPTY;
	        }
	    }
	

	/**
	 * showViewPage is used to get the Object of the screen.
	 *
	 * @param request the request
	 * @param returnList the param list
	 * @param valueMap the value map
	 * @return Object
	 * @throws QueryException the query exception
	 */
	public List<FrontVo> showViewPage(SovaHttpRequest request, List<FrontVo> returnVoList, Map<String, Object> valueMap) throws QueryException {
		List<FrontVo> returnList = new ArrayList<>();
		List<FrontVo> valueList = new ArrayList<>(returnVoList);
//		insertWindowId(request,returnList);
		long start = System.currentTimeMillis();
		getHolidays(returnList);
		logger.debug("showViewPage method starts");
//		getFrameworkDataFromView(returnList);
		String locale = StringUtils.EMPTY;
		if (StringUtils.isNotEmpty(UserContext.getInstance().locale())) {
			locale = UserContext.getInstance().locale();
		}
		if (StringUtils.isEmpty(locale)) {
			locale = "en";
		}
		String sid = request.getParameter("sid");
		sid = Objects.isNull(sid)?ScreenDefinitionCacheService.getInstance().getScreenByDefId(getScreenDefinitionId()):sid;
		getElementBtDataFromCache(locale, returnList, request,sid);
		ScreenDefinitionEntity screenMap = getScreenMap(sid,locale, request);
		if(Objects.isNull(screenMap)) {
			logger.error("Invalid Screen Id : "+String.valueOf(sid));
		}else {
			addData("screenName", screenMap.getScreenName(), returnList);
			addData("screenId", sid, returnList);
			addData("vuePath", screenMap.getVuePath(), returnList);
			getApplicationData(screenMap.getScreenDefinitionId(),returnList);
		}
		if (StringUtils.isEmpty(ContextBean.getAppUserId())) {
			buildMenuAttributes(returnList);
		} else {
			addAttribute("global-side-menu", "display", false, returnList);
		}
		buildGlobalUserData(returnList);
		//buildTemplateCacheData(returnList);
		addData("user_preference_random_key", CacheService.getInstance().getCacheData(
				CacheKeyHelper.getUserPreferenceRandomKey(ContextBean.getTenantId(), ContextBean.getUserId())), returnList);
		addData("fwTextCacheKey", CacheService.getInstance().getCacheData("sova_lang_fw_text_data_key"), returnList);
		try {
			addData(USER_DATA, objectMapper.writeValueAsString(getUserData()), returnList);
		} catch (JsonProcessingException jsonProcessingException) {
			addData(USER_DATA, null, returnList);
			logger.error(jsonProcessingException.getMessage(),jsonProcessingException);
		}
		buildApplicationSearch(returnList);
		long elapsedTime = System.currentTimeMillis() - start;
		logger.debug("showViewPage method executed in :" + elapsedTime);
		returnList.addAll(valueList);
		return returnList;
	}
	
	private void buildApplicationSearch(List<FrontVo> returnList) {
		UserProfileEntity UserProfile = UserContext.getInstance().getUserProfile();
		Map<String, Object> filterValueMap = new HashMap<>();
		filterValueMap.put("lang_code", UserProfile.getLocale());
		filterValueMap.put("tenant_id", UserContext.getInstance().getTenantId());
		Map<String, Object> filterCondMap = new HashMap<>();
		filterCondMap.put("lang_code", "eq");
		filterCondMap.put("tenant_id", "eq");
		if (UserProfile.isFullyAuthorized()) {
			addAttribute("nn-business-page-commonmaster-input", "masterSearchId", "nn_service_full_search_master",returnList);
		}else if(UserProfile.isAdminUser()) {
			addAttribute("nn-business-page-commonmaster-input", "masterSearchId", "nn_service_admin_search_master",returnList);
		}else {
			addAttribute("nn-business-page-commonmaster-input", "masterSearchId", "nn_service_partial_search_master", returnList);
			filterCondMap.put("role_id", "in");
			filterValueMap.put("role_id", UserProfile.getRoleList());
		}
		addAttribute("nn-business-page-commonmaster-input", "filterValueMap", filterValueMap, returnList);
		addAttribute("nn-business-page-commonmaster-input", "filterConditionMap", filterCondMap, returnList);
		
	}
	
	/**
	 * buildGlobalUserData is used to build global user data.
	 * 
	 * @param returnList
	 */
	private void buildGlobalUserData(List<FrontVo> returnList) {
		Map<String, Object> globalUserInfoMap = new HashMap<>();
		try {
		UserProfileEntity userProfileEntity = UserContext.getInstance().getUserProfile();
		globalUserInfoMap.put("userName",
				Objects.nonNull(userProfileEntity) ? userProfileEntity.getName() : StringUtils.EMPTY);
//		globalUserInfoMap.put("userImage", "avatar.png");
		String fileId = userProfileEntity.getUserImage();
		String refId = userProfileEntity.getUserImageFileId();
		if (StringUtils.isNotEmpty(refId)) {
			addAttribute("nn-business-page-common", "fileId", refId, returnList);
		}
		if (StringUtils.isNotEmpty(fileId)) {
			addAttribute("nn-business-page-common", "uploadedSource", fileId, returnList);
		}

			Map<String, Object> userInfoCache = CacheService.getInstance()
					.getUserDataByTenantId(ContextBean.getUserId());
			globalUserInfoMap.put("isDebug", false);
			if (Objects.nonNull(userInfoCache) && !userInfoCache.isEmpty()) {
				globalUserInfoMap.put("isDebug", userInfoCache.getOrDefault("is_debug", false));
			}
			Map<String, Object> lastLoginMap = (Map<String, Object>)CacheService.getInstance().getCacheData(UserContext.getInstance().getTenantId() + ":" + UserContext.getInstance().getUserName() + ":user_login_activity");
			
			if(Objects.nonNull(lastLoginMap) && lastLoginMap.containsKey("lastLoginTime")) {
				globalUserInfoMap.put("lastLogin", lastLoginMap.get("lastLoginTime"));
			}
			globalUserInfoMap.put("programName", getProgramName());
		addMultipleAttribute("global-user-info", globalUserInfoMap, returnList);
		} catch (QueryException exception) {
			logger.error(exception.getMessage(), exception);
		}}

	private void getApplicationData(String screenDefId, List<FrontVo> returnList) {
		if(Objects.nonNull(screenDefId))
		try {
			Map<String, Object> appTextData = CacheService.getInstance().getApplicationTextDefinitionData(screenDefId);
			Map<String, MessageDefinitionEntity> appMessageData = CacheService.getInstance().getApplicationMessageData(screenDefId);
			addData("applicationTextData", appTextData, returnList);
			addData("applicationMessageData", appMessageData, returnList);
		} catch (Exception exception) {
			logger.error(exception.getMessage(),exception);
		}
	}


	/**
	 * Insert window id.
	 *
	 * @param request the request
	 * @param paramList the param list
	 * @throws QueryException the query exception
	 */
	public void insertWindowId(SovaHttpRequest request, List<FrontVo> paramList) throws QueryException {
		String processId = Objects.nonNull(ContextBean.getProcessId()) ? ContextBean.getProcessId() : StringUtils.EMPTY;
		addData("processId", processId, paramList);
//		ApplicationLoggerDao.updateApplicationLog(request, processId);
	}


	

	/**
	 * Gets the holidays.
	 *
	 * @param paramList the param list
	 * @return the holidays
	 * @throws QueryException the query exception
	 */
	private void getHolidays(List<FrontVo> paramList) throws QueryException {
		List<Map<String, Object>> holidayList = CacheService.getInstance().getHolidayDates();
		List<Map<String, Object>> offList = CacheService.getInstance().getFestivalHolidays();
		addData("holidays", offList, paramList);
		if(Objects.nonNull(holidayList) && !holidayList.isEmpty()) {
			addData("all_sunday_off_flag", holidayList.get(0).get("all_sunday_off_flag"), paramList);
			addData("all_saturday_off_flag", holidayList.get(0).get("all_saturday_off_flag"), paramList);
			addData("saturday_first_week_off_flag", holidayList.get(0).get("saturday_first_week_off_flag"), paramList);
			addData("saturday_second_week_off_flag", holidayList.get(0).get("saturday_second_week_off_flag"), paramList);
			addData("saturday_third_week_off_flag", holidayList.get(0).get("saturday_third_week_off_flag"), paramList);
			addData("saturday_fourth_week_off_flag", holidayList.get(0).get("saturday_fourth_week_off_flag"), paramList);
			addData("saturday_fifth_week_off_flag", holidayList.get(0).get("saturday_fifth_week_off_flag"), paramList);
			addData("exclude_days_flag", holidayList.get(0).get("exclude_days_flag"), paramList);
			
			PGobject excludeDays = (PGobject) holidayList.get(0).get("exclude_days");
			addData("exclude_days", Objects.nonNull(excludeDays) ? JsonUtils.fromJsonOrEmptyList(excludeDays.getValue(), new TypeReference<List<String>>() {
			}) : new ArrayList<>(), paramList);
			
		}
	}

	/**
	 * Gets the framework data from view page.
	 *
	 * @param paramList the param list
	 * @return the framework bt data from view page
	 */
	private void getFrameworkDataFromView(List<FrontVo> paramList) {
		try {
			Object commonTextData = CacheService.getInstance().getFrameworkTextDefinitionData();
			Map<String, Object> datas = new HashMap<>();
			List<Object> localeDataList = (List<Object>) CacheService.getInstance().getAllLocaleInfo();
			if (Objects.nonNull(commonTextData)) {
				datas = (Map<String, Object>) commonTextData;
			}
			Map<String, Object> localeMap = new HashMap<>(); 
			localeMap.put(LANG_CODE, localeDataList);
			addData("frameworkCommonTextData", datas, paramList);
			addData("frameworkLocaleData", localeMap, paramList);
		} catch (Exception exception) {
			logger.error(exception.getMessage(),exception);
		}
	}


	/**
	 * Gets the element bt data from cache.
	 *
	 * @param locale the locale
	 * @param paramList the param list
	 * @param request the request
	 * @param sid 
	 * @return the element bt data from cache
	 * @throws QueryException the query exception
	 */
	private void getElementBtDataFromCache(String locale, List<FrontVo> paramList, SovaHttpRequest request, String sid) throws QueryException {
		String screenDefId = getScreenDefinitionId();
		List<FrontVo> elementList = getScreenElementData(locale, screenDefId, sid);
		paramList.addAll(elementList);
	}


	/**
	 * Gets the screen element data.
	 *
	 * @param locale the locale
	 * @param screenDefId the screen def id
	 * @param sid the sid
	 * @return the screen element data
	 * @throws QueryException the query exception
	 */
	public List<FrontVo> getScreenElementData(String locale, String screenDefId, String sid) throws QueryException {
		CacheService cacheService = CacheService.getInstance();
		List<FrontVo> elementList = frontVoConverter(cacheService.getDataElementByScreenInfo(screenDefId,sid,locale));
		return elementList;
	}

	/**
	 * Gets the screen map.
	 *
	 * @param locale the locale
	 * @param screenId 
	 * @param request the request
	 * @return the screen map
	 * @throws QueryException the query exception
	 */
	public ScreenDefinitionEntity getScreenMap(String screenId, String locale, SovaHttpRequest request) throws QueryException {
		ScreenDefinitionEntity screenDefEntity = CacheService.getInstance().getScreenDefinitionDataByLocale(screenId, locale);
		return screenDefEntity;
	}

	/**
	 * Gets the user data.
	 *
	 * @return the user data
	 */
	public Object getUserData() {
		long start = System.currentTimeMillis();
		logger.debug("getUserData method starts");
		ContextUtils utils = ContextUtils.getInstance();
		Map<String, Object> userDataMap = new HashMap<>();
		//		UserProfileEntity userProfile = UserContext.getInstance().getUserProfile();
		UserProfileEntity userProfile =null;
		String currentLocale = UserContext.getInstance().locale();
		if (Objects.nonNull(userProfile)) {
			userDataMap.put("userName", userProfile.getName());
			userDataMap.put("userId", userProfile.getUserName());
			userDataMap.put("userImage", userProfile.getUserImage());
			userDataMap.put("empNo", userProfile.getEmpNo());
			userDataMap.put("homeContext", utils.getContext());
			userDataMap.put("locale", userProfile.getLocale());
			userDataMap.put("currentLocale", currentLocale);
			ZoneId zone = ZoneId.of(userProfile.getTimeZone());
			ZoneOffset currentOffsetForMyZone = zone.getRules().getOffset(Instant.now());
			userDataMap.put("timeZone", userProfile.getTimeZone());
			userDataMap.put("offset", currentOffsetForMyZone);
			String dateFormat = DateStyle.getPattern(ContextBean.getLocaleHolder(),
					DateStyle.valueOf(userProfile.getDateFormat()));
			String timeFormat = TimeStyle.getPatternWithSeccond(ContextBean.getLocaleHolder(),
					TimeStyle.valueOf(userProfile.getTimeFormat()));
			userDataMap.put("dateFormat", dateFormat);
			userDataMap.put("timeFormat", timeFormat);
			userDataMap.put("tenantId", ContextBean.getTenantId());
			userDataMap.put("adminUser", userProfile.isAdminUser());
		}
		logger.debug("getUserData method executed in :" + (System.currentTimeMillis() - start));
		return userDataMap;

	}
	
	@ExceptionHandler(Exception.class)
	public void handleException(Exception exception, SovaHttpRequest request, SovaHttpResponse response) {
		logger.error((Throwable)exception);
		String stackTrace = logAfterThrowing(exception);
		Map<String, String> stackMap = new HashMap<>();
		stackMap.put("stackTrace", stackTrace);
		stackMap.put("message", exception.getMessage());
	    response.withStatusCode(SovaResponseStatus.INTERNAL_SERVER_ERROR.value()).withBody(stackMap);
	}
	
	@ExceptionHandler(CustomException.class)
	public void handleException(CustomException exception, SovaHttpRequest request, SovaHttpResponse response) {
		logger.error((Throwable)exception);
		String stackTrace = logAfterThrowing(exception);
		Map<String, String> stackMap = new HashMap<>();
		stackMap.put("stackTrace", stackTrace);
		stackMap.put("message", exception.getMessage());
		if(Objects.nonNull(exception.getErrorCode())) {
			response.withBody(stackMap).withStatusCode(exception.getErrorCode().value());
		}else {
			response.withBody(stackMap).withStatusCode(SovaResponseStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
	
	public String logAfterThrowing(Throwable exception) {
		StringBuilder stackTrace = new StringBuilder();
		stackTrace.append(exception.getClass().toString().replace("class", StringUtils.EMPTY));
		stackTrace.append(": ");
		if (StringUtils.isNotEmpty(exception.getMessage())) {
			stackTrace.append(exception.getMessage());
		}
		for(StackTraceElement element : exception.getStackTrace()){
			stackTrace.append("\r\n\t\t"+"at ");
			stackTrace.append(element.toString());
		}
		return stackTrace.toString();
	}

	/**
	 * buildMenuAttributes is used to build menu attributes for the business page
	 * 
	 * @param returnList
	 */
	private void buildMenuAttributes(List<FrontVo> returnList) {
		LinkedHashMap<String, Object> userMenuData = new LinkedHashMap<>();
		CacheService instance = CacheService.getInstance();
		UserProfileEntity userContext = UserContext.getInstance().getUserProfile();
		try {
			if (userContext.isFullyAuthorized()) {
				List<String> roleList = userContext.getRoleList();
				userMenuData.putAll(instance.getUserFullAuthorityMenuData("Full_Auth", ContextBean.getLocale(), ContextBean.getTenantId(), roleList));
			} else if (userContext.isAdminUser()) {
				userMenuData.putAll(instance.getUserAdminAuthorityMenuData("Admin_Auth", ContextBean.getLocale(), ContextBean.getTenantId()));
			} else {
				List<String> roleList = userContext.getRoleList();
				if (CollectionUtils.isNotEmpty(roleList)) {
					userMenuData.putAll(instance.getUserRoleAuthorityMenuData(roleList, ContextBean.getLocale(), ContextBean.getTenantId()));
				}
			}
			userMenuData.put("componentData", userMenuData.get("menuData"));
			userMenuData.put("componentRoots", userMenuData.get("menuRoots"));
			userMenuData.put("activeDefId",getScreenDefinitionId());
			userMenuData.put("menuRecentRoots", instance.getUserRecentsByTenantAndUserId());
			userMenuData.put("favouriteList", instance.getUserFavouritesByTenantAndUserId());
		} catch (QueryException e) {
			logger.error("Error while getting menu data from cache.");
		}
		addMultipleAttribute("global-side-menu", userMenuData, returnList);
	}
	
	/**
	 * buildTemplateCacheData is used to get the template data.
	 * 
	 * @param returnList
	 * @param productCode 
	 */
	private void buildTemplateCacheData(List<FrontVo> returnList) {
		String themeCode = UserContext.getInstance().getUserProfile().getThemeCode();
		Map<String, Object> templateData = CacheService.getInstance().getTemplateCacheData(themeCode);
		addData("theme_data", templateData, returnList);
		addData("theme_cache_key", CacheService.getInstance().getCacheData(
				CacheKeyHelper.getUserThemeKey(ContextBean.getTenantId(), ContextBean.getUserId() + ":theme_key")),
				returnList);
	}


	/**
	 * getScreenRelatedIniData is used to get the ini data of the screen.
	 * 
	 * @param returnList
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected void getScreenRelatedIniAndBookmarkData(List<FrontVo> returnList, Map<String,Object> appgenParamMap) {
		List<Map<String, Object>> iniList = CacheService.getInstance().getUserScreenIniData(ContextBean.getTenantId(), 
				ContextBean.getUserId(), ContextBean.getSid());
		if(CollectionUtils.isNotEmpty(iniList)) {
			List<Map<String, Object>> collectList = iniList.stream().filter(predicate->Objects.nonNull(predicate.get("is_autoset_field")) 
					&& String.valueOf(predicate.get("is_autoset_field")).equals("true") && Objects.nonNull(predicate.get("ini_value")))
					.collect(Collectors.toList());
			if(CollectionUtils.isNotEmpty(collectList)) {
				collectList.stream().forEach(action-> {
					Map<String, Object> parsedMap = JsonUtils.fromJsonOrEmptyMap(String.valueOf(action.get("ini_value")),
							new TypeReference<Map<String, Object>>() {
							});
					if(Objects.nonNull(appgenParamMap)) {
						appgenParamMap.put(action.get("component_id").toString(), parsedMap.get("value"));
					}					
					addMultipleAttribute(String.valueOf(action.get("component_id")), parsedMap, returnList);
				});
			}
		}
		addData("iniData", iniList, returnList);
		getBookmarkData(returnList, appgenParamMap);
	}

	/**
	 * getBookmarkData is used to get the bookmark data.
	 * 
	 * @param returnList
	 */
	private void getBookmarkData(List<FrontVo> returnList, Map<String,Object> appgenParamMap) {
		Map<String, Object> bookmarkData = new BookmarkServiceImpl().getBookmarkData();
		if (String.valueOf(bookmarkData.get("status")).equals("true")) {
			List<Map<String, Object>> bookmarkList = (List<Map<String, Object>>) bookmarkData.get("data");
			if (CollectionUtils.isNotEmpty(bookmarkList)) {
				addAttribute("businesspage-bookmark", "value", bookmarkList, returnList);
				try {
					List<Map<String, Object>> defaultList = bookmarkList.stream()
							.filter(predicate -> String.valueOf(predicate.get("isDefault")).equals("true"))
							.collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(defaultList)) {
						Map<String, Object> bookmarkMap = (Map<String, Object>) defaultList.get(0).get("componentId");
						if (MapUtils.isNotEmpty(bookmarkMap)) {
							bookmarkMap.entrySet().stream().forEach(action -> {
								addAttribute(action.getKey(), "value", action.getValue(), returnList);
								if(Objects.nonNull(appgenParamMap)) {
									appgenParamMap.put(action.getKey().toString(), action.getValue());
								}
							});
						}
					}
				} catch (Exception e) {
					logger.error("Exception occured while loading bookmark data", e);
				}
			}
		}
	}
}
