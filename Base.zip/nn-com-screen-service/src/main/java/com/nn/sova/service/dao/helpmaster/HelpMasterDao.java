package com.nn.sova.service.dao.helpmaster;

import java.util.List;
import java.util.Map;

/**
 * HelpMasterDao interface
 * 
 * @author Sakthivel
 */
public interface HelpMasterDao {

	List<Map<String, Object>> getData(String screenId);

	Map<String, Object> getData(String screenId, String helpMasterId);

}