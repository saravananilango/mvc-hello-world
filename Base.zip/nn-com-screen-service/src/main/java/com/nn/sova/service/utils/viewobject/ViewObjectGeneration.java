package com.nn.sova.service.utils.viewobject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.util.entity.CreateMatViewEntity;
import com.nn.sova.util.entity.CreateViewEntity;
import com.nn.sova.util.entity.DropMaterializedViewEntity;
import com.nn.sova.util.entity.DropViewEntity;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;


/**
 * ViewObjectGeneration contains methods for the transportation process in next system
 * @author Hariprasath Kamaraj
 *
 */
public class ViewObjectGeneration {

  
	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(ViewObjectGeneration.class);

	
	
	/**
	   * Instantiates a new ViewObjectGeneration.
	   */
	     public ViewObjectGeneration() {
	    
		}

	     
	
	/**
	 * getLangDependentTables to reteive lang dependent tables
	 * @param paramMap
	 * @param ivQueryExecutor 
	 * @return
	 * @throws IOException
	 * @throws CustomException 
	 */
	public Set<String> getLangDependentTables(Map<String,Object> paramMap, QueryExecutor ivQueryExecutor) throws IOException, CustomException{
		logger.debug("## getLangDependentTables method execution started.");
		String productCode = String.valueOf(paramMap.get(ViewObjectConstants.PRODUCT_CODE));
		ObjectMapper objectMapper = new ObjectMapper();
		Set<String> langTableSet = new HashSet<>();
		try {
		Map configDataMap = (Map)paramMap.get(ViewObjectConstants.CONFIG_TABLE_DATA);
		Map<String,Object> tableAliasMap = objectMapper.readValue(String.valueOf(configDataMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("tables_with_alias"))), new TypeReference<Map<String, Object>>() {});
		Set<String> keySets = new HashSet<>();
	    for(Entry<String, Object> entry : tableAliasMap.entrySet()){
	    	keySets.add(entry.getValue().toString());
	    }	
	    if(!keySets.isEmpty()){
		List<Map<String, Object>> langDependentTables;
			langDependentTables = ivQueryExecutor.queryBuilder().select().checkIndependentTenant(true).get(ViewObjectConstants.TABLE_NAME,ViewObjectConstants.COLUMN_NAME).from("table_definition_column_details")
					.where(ConditionBuilder.instance().in(ViewObjectConstants.TABLE_NAME,keySets.toArray()).and().eq(ViewObjectConstants.LANG_DEPENDENT, true)).build(false).execute();
		
		langDependentTables.stream().forEach(action->langTableSet.add(action.get(ViewObjectConstants.TABLE_NAME).toString()+ViewObjectConstants.UNDERSCORE_TEXT));
		logger.debug("## keySets"+keySets);
	    }
		logger.debug("## getLangDependentTables method execution ended.");
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
		return langTableSet;
	}

	
	
	protected String getString(Object obj) {
		return Objects.toString(obj,"");
	}
	
	
	/**
	 * validateRequestId is used to get the requestId and validate it
	 * @param objectString
	 * @param paramMap
	 * @param sourceBranchId
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private boolean validateChangeRequestId(String objectString, Map<String, Object> paramMap) throws JsonParseException, JsonMappingException, IOException {
		if(objectString!=null && !StringUtils.isEmpty(objectString)){
			logger.debug("## validateChangeRequestId from BO method execution started.");
			  Map<String,Object> requestMap = new ObjectMapper().readValue(objectString,Map.class);
			  if(requestMap.containsKey("status") && Objects.nonNull(requestMap.get("status")) && !MapUtils.getBooleanValue(requestMap, "status")) {
				  formErrorKey(paramMap, false, String.valueOf(requestMap.get("message")));
				  logger.debug("## validateChangeRequestId from BO method execution ended.  result: false");
				  return false;
			  }
			  if(Objects.nonNull(requestMap)){
				  paramMap.put("sourceBranchId", Objects.toString(requestMap.get("requestId"), ""));
				  logger.debug("## validateChangeRequestId from BO method execution ended.  result: true");
				  return true;
			  } else{
				  formErrorKey(paramMap, false, "Change Request for source data is not created.");
				  logger.debug("## validateChangeRequestId from BO method execution ended.  result: false");
				  return false;
			  }
		} else{
			  formErrorKey(paramMap, false, "System Id or Request Id is null");
			  paramMap.put(ViewObjectConstants.ERROR, "System Id or Request Id is null");
			  logger.debug("## validateChangeRequestId from BO method execution ended.  result: false");
			  return false;
		}
	}
	
	/**
	 * formErrorKey is used to put the error content and status to display in the screen
	 * @param paramMap
	 * @param status
	 * @param messageContent
	 */
	private void formErrorKey(Map<String,Object> paramMap,boolean status, String messageContent) {
		paramMap.put(ViewObjectConstants.ERROR, messageContent);
		paramMap.put(ViewObjectConstants.MESSAGE, messageContent);
		paramMap.put(ViewObjectConstants.STATUS, status);
	}
			
	 /**
		 * @param queryExecutor
		 * @param keySets
		 * @return
	 * @throws CustomException 
		 */
		public List<Map<String, Object>> checkForTenantExists(QueryExecutor queryExecutor,List<String> keySets) throws CustomException{
			List <Map<String,Object>> tenantDataList = new ArrayList<>();
			 try {
				 tenantDataList= queryExecutor.queryBuilder().select().checkIndependentTenant(true).from("table_definition").where(ConditionBuilder.instance().in("table_name", keySets.toArray()).and().eq("tenant_id_flag", true)).build(true).execute();
			} catch (Exception exception) {
				throw new CustomException(exception);
			}
			return tenantDataList;
		 }	
		
			


	
	public String getVersion(String changeRequestId) throws CustomException {
		List<Map<String, Object>> resultList;
		String productVersion = "";
		try {
			resultList = new QueryBuilder().select().from("change_request").where(ConditionBuilder.instance().eq("change_request_id", changeRequestId)
					.and().eq("code_status", true)).build(false).execute();
		if(!resultList.isEmpty()) {
			productVersion = Objects.isNull(resultList.get(0).get("product_version")) ? null : String.valueOf(resultList.get(0).get("product_version"));
		}
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
		return productVersion;
	}


	
	/**
	 * dropViewForviewObject to drop views for view object
	 * @param viewObjectMap
	 * @param metaQueryExecutor
	 * @param productExecutorMap 
	 * @param newQueryExecutor2 
	 * @return
	 * @throws IvFrameworkException
	 */
	public Map<String,Object> dropDependentViewObject(Map<String,Object> viewObjectMap, QueryExecutor metaQueryExecutor, Map<String, Object> productExecutorMap) throws CustomException {
	  String viewObject = String.valueOf(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT));
	  logger.debug("dropDependentViewObject method started---"+viewObject);
	  String versionNumber = String.valueOf(viewObjectMap.get(ViewObjectConstants.VERSION_NUMBER));
	Set<String> viewObjectSet = new LinkedHashSet();
	QueryExecutor viewObjectExecutor = getViewObjectExecutor(viewObjectMap, metaQueryExecutor.queryBuilder());
	List<Map<String,Object>> viewDetailsList = new ArrayList<Map<String,Object>>();
	if(viewObjectMap.containsKey("dependentViews") && Objects.nonNull(viewObjectMap.get("dependentViews"))){
		viewDetailsList = (List<Map<String, Object>>) viewObjectMap.get("dependentViews");
	}
	viewObjectMap.put("dependentViews", viewDetailsList);
	viewObjectMap.put("queryType","alter");
	
	try {
		for (Map<String,Object> viewDataMap : viewDetailsList) {
			String innerViewObject = String.valueOf(viewDataMap.get(ViewObjectConstants.VIEW_OBJECT_NAME));
			String innerVersionNumber = String.valueOf(viewDataMap.get(ViewObjectConstants.VERSION_NO));
			if(viewObjectMap.containsKey("viewObjectSet") && Objects.nonNull(viewObjectMap.get("viewObjectSet"))){
				viewObjectSet = (LinkedHashSet<String>) viewObjectMap.get("viewObjectSet");
			}
			if((viewObjectSet.isEmpty() || !viewObjectSet.contains(innerViewObject)) && !StringUtils.equals(viewObject, innerViewObject) ){
				List<Map<String,Object>> subQueryDataList= getDependentViewObjects(innerViewObject, metaQueryExecutor.queryBuilder(),innerVersionNumber);
				if(!subQueryDataList.isEmpty()){
					Map<String,Object> tempViewMap = new HashMap<String, Object>();
					tempViewMap.putAll(viewObjectMap);
					tempViewMap.put(ViewObjectConstants.VIEW_OBJECT, innerViewObject);
					tempViewMap.put("dependentViews", subQueryDataList);
					dropDependentViewObject(tempViewMap, metaQueryExecutor,productExecutorMap);
					if(tempViewMap.containsKey("viewObjectSet") && Objects.nonNull(tempViewMap.get("viewObjectSet"))){
					  Set<String> tempViewObjectSet = (LinkedHashSet<String>) tempViewMap.get("viewObjectSet");
					  if(Objects.nonNull(tempViewObjectSet)&& !tempViewObjectSet.isEmpty()){
						  viewObjectMap.put("viewObjectSet", viewObjectSet);
					  }
					}
				}
				dropViewObjectView(viewObjectMap, viewObjectExecutor);
				logger.debug("View Dropped for " + innerViewObject);
				viewObjectSet.add(innerViewObject);
				viewObjectMap.put("viewObjectSet", viewObjectSet);
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("status_flag"), false);
				metaQueryExecutor.skipChangeRequest(true);
				ViewObjectCommonUtils.upsertConfigWithMap(viewObjectMap, updateMap, metaQueryExecutor);
				metaQueryExecutor.skipChangeRequest(false);
			}
		}
		
		logger.info("dropDependentviewObject method execution completed for" + String.valueOf(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT)));
	} catch (Exception exception) {
		logger.info("dropDependentviewObject method execution failed  " , exception.getMessage());
		try {
			rollBackMultipleExecutor(viewObjectMap);
			ViewObjectCommonUtils.rollBackExecutor(metaQueryExecutor);
			ViewObjectCommonUtils.rollBackExecutor(viewObjectExecutor);
			ViewObjectCommonUtils.addErrorMessage(viewObjectMap, exception.getMessage());
			throw new CustomException(exception);
		} catch (Exception exq) {
			logger.info("dropDependentviewObject method excpetion handler failed  " , exq.getMessage());
			viewObjectMap.put("error", exception.getMessage());
			throw new CustomException(exq);
		}

	}
	return viewObjectMap;
	}
	
	/**
	 * rollBackMultipleExecutor method is to multiple executor for the product
	 * @param viewObjectMap
	 * @throws CustomException
	 */
	public static void rollBackMultipleExecutor(Map<String,Object> viewObjectMap) throws CustomException{
		try {
				if(Objects.nonNull(viewObjectMap)){
					for(Entry<String,Object> prodExe :viewObjectMap.entrySet()){
						if(Objects.nonNull(prodExe.getValue())){
							QueryExecutor prodExecutor = (QueryExecutor) prodExe.getValue();
								prodExecutor.rollBack();
						}
					}
				}
		} catch (Exception exp) {
			throw new CustomException(exp);
		}
	}
	
	/**
	 * dropViewInDatabase is delete/drop view from database
	 * @param viewObjectMap
	 * @param productExecutor
	 * @throws CustomException
	 */
	public void dropViewInDatabase(Map<String, Object> viewObjectMap,QueryExecutor metaQueryExecutor) throws CustomException {
		String viewObject = getString(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT));
		String versionNumber = getString(viewObjectMap.get(ViewObjectConstants.VERSION_NUMBER));
		logger.debug("## createTableObjectView method execution started");
		QueryExecutor viewObjectExecutor = getViewObjectExecutor(viewObjectMap, metaQueryExecutor.queryBuilder());
		try {
				viewObjectMap.put("dependentViews",getDependentViewObjects(viewObject, metaQueryExecutor.queryBuilder(),versionNumber));
				dropDependentViews(viewObjectMap, metaQueryExecutor,viewObjectExecutor);
				dropViewObjectView(viewObjectMap, viewObjectExecutor);
				viewObjectExecutor.commit();
			logger.debug("## dropViewInDatabase method execution ended");
		} catch (Exception exception) {
			logger.debug("## dropViewInDatabase method execution failed due to " ,exception.getMessage());
			viewObjectMap.put(ViewObjectConstants.EXCEPTION, exception);
				try {
					ViewObjectCommonUtils.rollBackExecutor(viewObjectExecutor);
					ViewObjectCommonUtils.rollBackExecutor(metaQueryExecutor);
				} catch (Exception exp) {
					logger.debug("## dropViewInDatabase method exception handling failed--- ",exception.getMessage());
					throw new CustomException(exp);
				}
			}
	}
	
	/**
	 * dropviewObjectView is delete/drop view from database
	 * @param viewObjectMap
	 * @param productExecutor
	 * @throws CustomException
	 */
	public void dropViewObjectView(Map<String, Object> viewObjectMap,QueryExecutor productExecutor) throws CustomException {
		String viewObject = Objects.toString(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT));
		String productCode = Objects.toString(viewObjectMap.get(ViewObjectConstants.PRODUCT_CODE));
		Map configDataMap = (Map)viewObjectMap.get(ViewObjectConstants.CONFIG_TABLE_DATA);
		try {
			boolean matViewFlag = Boolean.parseBoolean(Objects.toString(configDataMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("mat_view_flag"))));
			if(!matViewFlag) {
				logger.debug("View Dropped for " , viewObject);
				DropViewEntity dropEntity  = new DropViewEntity();
				dropEntity.setProductName(productCode);
				dropEntity.setViewName(viewObject);
				productExecutor.queryBuilder().table().dropView().setProductCode(productCode).skipChangeRequest(true)
				.dropView(dropEntity).build().execute();
			}else {
				logger.debug("View Dropped for  materialize view " , viewObject);
				DropMaterializedViewEntity dropEntity  = new DropMaterializedViewEntity();
				dropEntity.setProductCode(productCode);
				dropEntity.setViewName(viewObject);
				productExecutor.queryBuilder().table().dropMaterializedView().setProductCode(productCode).skipChangeRequest(true)
				.dropView(dropEntity).build().execute();
			}
			logger.debug("View Dropped successfully " , viewObject);
		} catch (Exception exception) {
			logger.debug("View Dropped method got exception" , viewObject);
			ViewObjectCommonUtils.rollBackExecutor(productExecutor);
			exception.printStackTrace();
			throw new CustomException(exception);
		}
	}
	
	
	/**
	 * getProductExecutor is returns the corresponding executors for the viewobject
	 * @param viewObjectMap
	 * @param productExecutorMap 
	 * @param queryBuilder 
	 * @throws CustomException 
	 */
	public QueryExecutor getProductExecutor(Map<String, Object> viewObjectMap, Map<String, Object> productExecutorMap, QueryBuilder queryBuilder) throws CustomException {
		logger.debug("## getProductExecutor from method execution started.");
		String productCode = Objects.toString(viewObjectMap.get(ViewObjectConstants.PRODUCT_CODE));
		String handlerName = Objects.toString(viewObjectMap.get("databaseHandler"));
		QueryExecutor viewObjectExecutor = null;
		try {
		Map<String,Object> dbMap = ViewObjectCommonUtils.getApplicationDatabaseDetails(productCode,handlerName,queryBuilder);
		viewObjectMap.put(ViewObjectConstants.DB_DETAILS, dbMap);
		String productKey = getString(dbMap.get(ViewObjectConstants.URL_KEY))+getString(dbMap.get(ViewObjectConstants.SCHEMA));
			if(Objects.nonNull(productExecutorMap)) {
			if( productExecutorMap.containsKey(productKey) && Objects.nonNull(productExecutorMap.get(productKey))){
				viewObjectExecutor = (QueryExecutor) productExecutorMap.get(productKey);
			}else{
				QueryBuilder viewQueryBuilder = new QueryBuilder(getString(dbMap.get(ViewObjectConstants.URL_KEY)),getString(dbMap.get(ViewObjectConstants.USER)),getString(dbMap.get(ViewObjectConstants.PASSKEY)),getString(dbMap.get(ViewObjectConstants.SCHEMA)));
					viewObjectExecutor = viewQueryBuilder.getQueryExecutor();
				
				viewObjectExecutor.skipChangeRequest(true);
				productExecutorMap.put(productKey, viewObjectExecutor);
				viewObjectMap.put("productExecutorMap",productExecutorMap);
			}
			}else {
				productExecutorMap = new HashMap<>();
				QueryBuilder viewQueryBuilder = new QueryBuilder(getString(dbMap.get(ViewObjectConstants.URL_KEY)),getString(dbMap.get(ViewObjectConstants.USER)),getString(dbMap.get(ViewObjectConstants.PASSKEY)),getString(dbMap.get(ViewObjectConstants.SCHEMA)));
				viewObjectExecutor = viewQueryBuilder.getQueryExecutor();
				viewObjectExecutor.skipChangeRequest(true);
				productExecutorMap.put(productKey, viewObjectExecutor);
				viewObjectMap.put("productExecutorMap",productExecutorMap);
			}
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
		return viewObjectExecutor;
		
	}
	
	
	/**
	 * getProductExecutor is returns the corresponding executors for the viewobject
	 * @param viewObjectMap
	 * @param productExecutorMap 
	 * @param queryBuilder 
	 * @throws CustomException 
	 */
	public QueryExecutor getViewObjectExecutor(Map<String, Object> viewObjectMap, QueryBuilder queryBuilder) throws CustomException {
		logger.debug("## getProductExecutor from method execution started.");
		String productCode = Objects.toString(viewObjectMap.get(ViewObjectConstants.PRODUCT_CODE));
		String handlerName = Objects.toString(viewObjectMap.get("databaseHandler"));
		QueryExecutor viewObjectExecutor = null;
		try {
			if(Objects.nonNull(viewObjectMap.get("viewObjectExecutor"))) {
				viewObjectExecutor = (QueryExecutor) viewObjectMap.get("viewObjectExecutor");
			}else {
		    Map<String,Object> dbMap = ViewObjectCommonUtils.getApplicationDatabaseDetails(productCode,handlerName,queryBuilder);
		    logger.debug("## database details retrieve for"+productCode+" and "+handlerName+" after getting details "+dbMap);
		    viewObjectMap.put(ViewObjectConstants.DB_DETAILS, dbMap);
		    QueryBuilder viewQueryBuilder = new QueryBuilder(getString(dbMap.get(ViewObjectConstants.URL_KEY)),getString(dbMap.get(ViewObjectConstants.USER)),getString(dbMap.get(ViewObjectConstants.PASSKEY)),getString(dbMap.get(ViewObjectConstants.SCHEMA)));
		     viewObjectExecutor = viewQueryBuilder.getQueryExecutor();
			}
			viewObjectExecutor.skipChangeRequest(true);
		} catch (Exception exception) {
			throw new CustomException(exception);
		}
		return viewObjectExecutor;
		
	}
	
	
	
	
	
	/**
	 * createviewObjectView method 
	 * creates viewobject(view) in the database in corresponding schema based on product.
	 * @param viewObjectMap
	 * @param metaQueryExecutor
	 * @throws CustomException
	 */
	public void createViewInDatabase(Map<String, Object> viewObjectMap,QueryExecutor metaQueryExecutor) throws CustomException {
		logger.debug("## createviewObjectView method execution started");
		String productCode = getString(viewObjectMap.get(ViewObjectConstants.PRODUCT_CODE));
		String viewObject = getString(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT));
		String versionNumber = getString(viewObjectMap.get(ViewObjectConstants.VERSION_NUMBER));
		String modeType = getString(viewObjectMap.get("modeType"));
		logger.debug("## createTableObjectView method execution started");
		QueryExecutor viewObjectExecutor = getViewObjectExecutor(viewObjectMap, metaQueryExecutor.queryBuilder());
		String langJoinData = "";
		try {
			if(StringUtils.equals(modeType, "EDIT")) {
				logger.debug("## createTableObjectView method execution started");
				Map<String,Object> dependentMap = new HashMap();
				dependentMap.putAll(viewObjectMap);
				dependentMap.put("dependentViews",getDependentViewObjects(viewObject, metaQueryExecutor.queryBuilder(),versionNumber));
				dropDependentViews(dependentMap, metaQueryExecutor,viewObjectExecutor);
			}
			Map configDataMap = (Map)viewObjectMap.get(ViewObjectConstants.CONFIG_TABLE_DATA);
			langJoinData = Objects.toString(configDataMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("condition_details")));
			boolean matViewFlag = Boolean.parseBoolean(Objects.toString(configDataMap.get(ViewObjectCommonUtils.bindConfigTableWithColumn("mat_view_flag"))));
		     langJoinData = langJoinData.replaceAll(" is true", "  = true ").replaceAll(" is false ", "  = false ");
		     ViewObjectLanguageUtils langUtils = new ViewObjectLanguageUtils();
		     langJoinData = langUtils.getLangJoinQuery(viewObjectMap,metaQueryExecutor);
		     if(!matViewFlag) {
		    	 CreateViewEntity viewEntity = new CreateViewEntity();
		    	 viewEntity.setProductCode(productCode);
		    	 viewEntity.setViewName(viewObject);
		    	 viewEntity.setSelectString(langJoinData);
		    	 viewObjectExecutor.queryBuilder().table().createView()
		    	 .skipChangeRequest(true).viewData(viewEntity).setProductCode(productCode).build().execute();
		     }else {
		    	 CreateMatViewEntity viewEntity = new CreateMatViewEntity();
		    	 viewEntity.setProductCode(productCode);
		    	 viewEntity.setViewName(viewObject);
		    	 viewEntity.setSelectString(langJoinData);
		    	 viewObjectExecutor.queryBuilder().table().createMatView()
		    	 .skipChangeRequest(true).viewData(viewEntity).setProductCode(productCode).build().execute();
		     }
			viewObjectExecutor.commit();
			logger.debug("## createviewObjectView method execution ended");
		} catch (Exception exception) {
			logger.debug("## createviewObjectView method execution failed due to " +exception.getMessage());
			viewObjectMap.put(ViewObjectConstants.EXCEPTION, exception);
			ViewObjectCommonUtils.addErrorMessage(viewObjectMap, exception.getMessage());
				try {
				    ViewObjectCommonUtils.rollBackExecutor(viewObjectExecutor);
				    ViewObjectCommonUtils.rollBackExecutor(metaQueryExecutor);
					throw new CustomException(exception);
				} catch (Exception exp) {
					logger.debug("## createviewObjectView method exception while handling" +exp.getMessage());
					throw new CustomException(exp);
				}
			}
	}
	
	/**
	 * getDependentviewObjects get the dependentViews from the table
	 * 
	 * @param viewObjectName denotes the name of view object
	 * @param versionNumber 
	 * @param QueryBuilder to execute the query 
	 * 
	 * @return response for getDependentviewObjects 
	 * @throws CustomException 
	 */
	public List<Map<String, Object>> getDependentViewObjects(String viewObjectName,QueryBuilder queryBuilder, String versionNumber) throws CustomException {
		List <Map<String,Object>> dependentDataList = new ArrayList<>(); 
		try {
			dependentDataList= queryBuilder.select().checkIndependentTenant(true).from(ViewObjectConstants.VIEW_OBJECT_DEFINITION).where(ConditionBuilder.instance().ilike("tables_with_alias","%\""+viewObjectName+"\"%").and().eq(ViewObjectConstants.VERSION_NO, versionNumber).and().eq("view_flag", true)).orderBy("created_at", SortType.ASC).build(true).execute();
		} catch (Exception exception) {
			throw new CustomException(exception);
}
		return dependentDataList;
	}


	/**
	 * convertDataType is used to convert the postgress data type into dataclass type 
	 * @param dataFormatName
	 * @return
	 */
	public String convertDataType(String dataTypeName) {
		switch (dataTypeName.toLowerCase()) {
        case "string":
          return "text";
        case "number":
          return "numeric";
        case "integer":
          return "integer";
        case "autonumbering":
          return "text";
        case "boolean":
          return "bool";
        case "timestamp":  
        	return "timestamp without time zone";
        case "":
          return "text";
        default:
          return dataTypeName;
      }
	}
	
	
	
	
	/**
	 * convertDataType is used to convert the postgress data type into dataclass type 
	 * @param dataFormatName
	 * @return
	 */
	public String convertFunctionDataType(String functionName) {
		switch (functionName.toLowerCase()) {
		 case "string":
	     case "character varying":
	     case "text":
	     case "":
          return "text";
        case "sum":
        case "avg":
          return "float";
        case "integer":
          return "integer";
        case "autonumbering":
          return "text";
        case "boolean":
          return "bool";
        case "json":
        	return "json";  
        case "timestamp":
        case "timestampwithtimezone":
		case "timestampwithzone":
		case "timestampwithouttimezone":
		case "timestampwithoutzone":
        	return "timestamp without time zone";
		 case "date":
			 return "date"; 
		 case "uuid":
			 return "uuid"; 
		 case "bigint":
			 return "bigint";  	
        	
        default:
          return "text";
      }
	}
	
	/**
	 * dropViewForviewObject to drop views for view object
	 * @param viewObjectMap
	 * @param metaQueryExecutor
	 * @param productExecutorMap 
	 * @param newQueryExecutor2 
	 * @return
	 * @throws IvFrameworkException
	 */
	public Map<String,Object> dropDependentViews(Map<String,Object> viewObjectMap, QueryExecutor metaQueryExecutor, QueryExecutor viewObjectExecutor) throws CustomException {
	  String viewObject = String.valueOf(viewObjectMap.get(ViewObjectConstants.VIEW_OBJECT));
	  String productCode = String.valueOf(viewObjectMap.get(ViewObjectConstants.PRODUCT_CODE));
	  logger.info("dropDependentViewObject method started---",viewObject);
	 String versionNumber = String.valueOf(viewObjectMap.get(ViewObjectConstants.VERSION_NUMBER));
	 Set<String> viewObjectSet = new LinkedHashSet();
	List<Map<String,Object>> viewDetailsList = new ArrayList<Map<String,Object>>();
	if(viewObjectMap.containsKey("dependentViews") && Objects.nonNull(viewObjectMap.get("dependentViews"))){
		viewDetailsList = (List<Map<String, Object>>) viewObjectMap.get("dependentViews");
	}
	viewObjectMap.put("dependentViews", viewDetailsList);
	viewObjectMap.put("queryType","alter");
	
	try {
		for (Map<String,Object> viewDataMap : viewDetailsList) {
			String innerViewObject = String.valueOf(viewDataMap.get(ViewObjectConstants.VIEW_OBJECT_NAME));
			String innerVersionNumber = String.valueOf(viewDataMap.get(ViewObjectConstants.VERSION_NO));
			if(viewObjectMap.containsKey("viewObjectSet") && Objects.nonNull(viewObjectMap.get("viewObjectSet"))){
				viewObjectSet = (LinkedHashSet<String>) viewObjectMap.get("viewObjectSet");
			}
			if((viewObjectSet.isEmpty() || !viewObjectSet.contains(innerViewObject)) && !StringUtils.equals(viewObject, innerViewObject) ){
				List<Map<String,Object>> subQueryDataList= getDependentViewObjects(innerViewObject, metaQueryExecutor.queryBuilder(),innerVersionNumber);
				if(!subQueryDataList.isEmpty()){
					Map<String,Object> tempViewMap = new HashMap<String, Object>();
					tempViewMap.putAll(viewObjectMap);
					tempViewMap.put(ViewObjectConstants.VIEW_OBJECT, innerViewObject);
					tempViewMap.put(ViewObjectConstants.VIEW_OBJECT_NAME, innerViewObject);
					tempViewMap.put("dependentViews", subQueryDataList);
					dropDependentViews(tempViewMap, metaQueryExecutor,viewObjectExecutor);
					if(tempViewMap.containsKey("viewObjectSet") && Objects.nonNull(tempViewMap.get("viewObjectSet"))){
					  Set<String> tempViewObjectSet = (LinkedHashSet<String>) tempViewMap.get("viewObjectSet");
					  if(Objects.nonNull(tempViewObjectSet)&& !tempViewObjectSet.isEmpty()){
						  viewObjectMap.put("viewObjectSet", viewObjectSet);
					  }
					}
				}
				viewObjectMap.put(ViewObjectConstants.VIEW_OBJECT, innerViewObject);
				viewObjectMap.put(ViewObjectConstants.VIEW_OBJECT_NAME, innerViewObject);
				logger.info("dropDependentViewObject method started---",viewObject);
				dropViewObjectView(viewObjectMap, viewObjectExecutor);
				logger.debug("View Dropped for " + innerViewObject);
				viewObjectSet.add(innerViewObject);
				viewObjectMap.put("viewObjectSet", viewObjectSet);
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put(ViewObjectCommonUtils.bindConfigTableWithColumn("status_flag"), false);
				metaQueryExecutor.skipChangeRequest(true);
				ViewObjectCommonUtils.updateViewObjectStatus(innerViewObject, updateMap, metaQueryExecutor.queryBuilder(), versionNumber,productCode);
			}
		}
		logger.info("dropDependentviewObject method execution completed for" ,viewObject);
	} catch (Exception exception) {
		logger.info("dropDependentviewObject method execution failed  " , exception.getMessage());
		try {
			ViewObjectCommonUtils.rollBackExecutor(metaQueryExecutor);
			ViewObjectCommonUtils.rollBackExecutor(viewObjectExecutor);
			ViewObjectCommonUtils.addErrorMessage(viewObjectMap, exception.getMessage());
			throw new CustomException(exception);
		} catch (Exception exq) {
			logger.info("dropDependentviewObject method failed excpetion", exq.getMessage());
			ViewObjectCommonUtils.addErrorMessage(viewObjectMap, exception.getMessage());
			throw new CustomException(exq);
		}
	}
	return viewObjectMap;
	}	

	
	
}
