package com.nn.sova.service.dao.screenconfiguration;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryExecutor;

/**
 * ScreenConfigurationDao interface.
 *
 * @author johnpeje
 */
public interface ScreenConfigurationDao {

    /**
     * getScreenConfigurationData method is to get screen configuration data.
     *
     * @param screenId the screen id
     * @return the screen configuration data
     */
    public Map<String, Object> getScreenConfigurationData(String screenId);

    /**
     * To delete screen configuration by screen definitions id.
     *
     * @param dataMap  the data map
     * @param executor the executor
     * @throws Exception the exception
     */
    void deleteByScreenIds(Map<String, Object> dataMap, QueryExecutor executor) throws Exception;
    
    /**
     * get screen definition id using screen id
     * @param screenId
     * @return
     * @throws QueryException
     */
    String getScreenDefId(String screenId) throws QueryException;
}