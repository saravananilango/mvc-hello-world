package com.nn.sova.service.utils.component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import com.nn.sova.service.CacheService;
import com.nn.sova.service.service.component.ComponentService;
import com.nn.sova.service.service.component.ComponentServiceImpl;
import com.nn.sova.service.user.UserContext;

/**
 * ComponentUtils handles all the Demo screen process.
 *
 * @author Vignesh Palanisamy
 */
public class ComponentUtils {

	private final ComponentService componentService;

	/** The Constant SOVA_COMPONENT_LIST_CACHE_KEY. */
	private static final String SOVA_COMPONENT_LIST_CACHE_KEY = "sova_component_list_value";

	/** The Constant COMPONENT_AND_GROUP_MAP. */
	private static final String COMPONENT_AND_GROUP_MAP = "componentAndGroupMap";

	/** The Constant COMPONENT_ATTRIBUTE. */
	private static final String COMPONENT_ATTRIBUTE = "componentAttribute";

	/** The Constant COMPONENT_STYLE_V1. */
	private static final String COMPONENT_STYLE_V1 = "componentStyleV1";

	/** The Constant TAG_NAME. */
	private static final String TAG_NAME = "tag_name";

	/** The Constant COMPONENT_STYLE_MASTER_V3. */
	private static final String COMPONENT_STYLE_MASTER_V3 = "componentStyleMasterV3";
	
	/** The Constant COMPONENT_TEMPLATE_MASTER_V3. */
	private static final String COMPONENT_TEMPLATE_MASTER_V3 = "componentTemplateMasterV3";

	/** The Constant COMPONENT_STYLE_DETAIL_TEMPLATE_V3. */
	private static final String COMPONENT_STYLE_DETAIL_TEMPLATE_V3 = "componentStyleDetailTemplateV3";

	/** The Constant COMPONENT_STYLE_DATA_V3. */
	private static final String COMPONENT_STYLE_DATA_V3 = "componentStyleDataV3";

	/** The Constant COMPONENT_STYLE_INSIDE_COMP_DATA_V3. */
	private static final String COMPONENT_STYLE_INSIDE_COMP_DATA_V3 = "componentStyleInsideComponentDataV3";

	/** The Constant COMPONENT_STYLE_INSIDE_COMP_V3. */
	private static final String COMPONENT_STYLE_INSIDE_COMP_V3 = "componentStyleInsideComponentV3";

	/** The Constant COMPONENT_STYLE_PROPS_DATA_V3. */
	private static final String COMPONENT_STYLE_PROPS_DATA_V3 = "componentStylePropsDataV3";
	
	/** The Constant THEME_DETAIL_DATA. */
	private static final String THEME_DETAIL_DATA = "themeDetailData";
	
	/** COMPONENT_AND_EVENTS_MAP */
	private static final String COMPONENT_AND_EVENTS_MAP = "componentAndEventsMap";

	/**
	 * ComponentUtils is a constructor used to initialize the value for
	 * componentService
	 *
	 */
	public ComponentUtils() {
		componentService = new ComponentServiceImpl();
	}

	/**
	 * component will load component data.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<Object, List<Map<String, Object>>> getComponent() throws Exception {
		return formAllComponentsData();
	}

	/**
	 * formAllComponentsData will return data for all components
	 * 
	 * @param dataMap
	 * @throws Exception
	 */
	public Map<Object, List<Map<String, Object>>> formAllComponentsData() throws Exception {
		Map<String, Object> cacheMap = cacheServiceHandler("getAll");

		Map<Object, List<Map<String, Object>>> componentAndGroupMap = (Map<Object, List<Map<String, Object>>>) cacheMap
				.get(COMPONENT_AND_GROUP_MAP);
		Map<String, Map<String, Object>> componentAttributeMap = (Map<String, Map<String, Object>>) cacheMap
				.get(COMPONENT_ATTRIBUTE);
		Map<String, Map<String, Object>> componentEventMap = (Map<String, Map<String, Object>>) cacheMap
				.get(COMPONENT_AND_EVENTS_MAP);
		Map<Object, Map<Object, List<Map<String, Object>>>> componentStyleV1 = (Map<Object, Map<Object, List<Map<String, Object>>>>) cacheMap
				.get(COMPONENT_STYLE_V1);
		LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>> insideComponent = (LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>) cacheMap
				.get(COMPONENT_STYLE_INSIDE_COMP_V3);

		componentAndGroupMap.keySet().stream().forEach(groupName -> {
			List<Map<String, Object>> componentList = componentAndGroupMap.get(groupName);
			componentList.stream().forEach(componentDataMap -> {
				String componentName = (String) componentDataMap.get(TAG_NAME);
				Map<String, Object> attributeMap = (Map<String, Object>) componentAttributeMap.get(componentName);
				List<Map<String, Object>> eventMap = (List<Map<String, Object>>) componentEventMap.get(componentName);
				Map<Object, List<Map<String, Object>>> styleV1Map = (Map<Object, List<Map<String, Object>>>) componentStyleV1
						.get(componentName);
				componentDataMap.put("attributes", attributeMap);
				componentDataMap.put("events", eventMap);
				componentDataMap.put("styleHandler", styleV1Map);
				componentDataMap.put("insideComponent", insideComponent.get(insideComponent));
			});
		});
		return componentAndGroupMap;
	}

	/**
	 * loadDataToCacheService will load component to cache.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> cacheServiceHandler(String type) throws Exception {

		Map<String, Object> componentRetrunMap = new HashMap<>();
		String userLocale = UserContext.getInstance().locale();
		String cacheKey = SOVA_COMPONENT_LIST_CACHE_KEY + "_" + userLocale;

		String componentAndGroupMapKey = cacheKey + "_group_data";
		String componentAttributeMapKey = cacheKey + "_attribute_data";
		String componentStyleV1Key = cacheKey + "_inline_v1";

		String inlineStyleMstV3Key = cacheKey + "_inline_mst_v3";
		String inlineStyleTemplateV3Key = cacheKey + "_inline_template_v3";
		String inlineStyleDataV3Key = cacheKey + "_inline_data_v3";
		String inlineStyleInsideCompDataV3Key = cacheKey + "_inline_inside_comp_data_v3";
		String inlineStyleInsideCompV3Key = cacheKey + "_inline_inside_comp_v3";
		String inlineStylePropsDataV3Key = cacheKey + "_inline_props_data_v3";
		String themeDetailDataKey = cacheKey + "_theme_detail_data";
		String compTemplateMstKey = cacheKey + "_template_mst";
		String componentAndEventsKey = cacheKey+"_event_data";
		List<String> cacheKeyList = Arrays.asList(componentAndGroupMapKey, componentAttributeMapKey,
				componentStyleV1Key, inlineStyleMstV3Key, inlineStyleTemplateV3Key, inlineStyleDataV3Key,
				inlineStyleInsideCompDataV3Key, inlineStyleInsideCompV3Key, inlineStylePropsDataV3Key, themeDetailDataKey, 
				compTemplateMstKey, componentAndEventsKey);

		if (isCacheDataNotExists(cacheKeyList)) {
			Map<String, Object> dataMap = componentService.getComponents();
			CacheService.getInstance().saveToCache(componentAndGroupMapKey, dataMap.get(COMPONENT_AND_GROUP_MAP));
			CacheService.getInstance().saveToCache(componentAttributeMapKey, dataMap.get(COMPONENT_ATTRIBUTE));
			CacheService.getInstance().saveToCache(componentAndEventsKey, dataMap.get(COMPONENT_AND_EVENTS_MAP));
			CacheService.getInstance().saveToCache(componentStyleV1Key, dataMap.get(COMPONENT_STYLE_V1));
			CacheService.getInstance().saveToCache(inlineStyleMstV3Key, dataMap.get(COMPONENT_STYLE_MASTER_V3));
			CacheService.getInstance().saveToCache(inlineStyleTemplateV3Key,
					dataMap.get(COMPONENT_STYLE_DETAIL_TEMPLATE_V3));
			CacheService.getInstance().saveToCache(inlineStyleDataV3Key, dataMap.get(COMPONENT_STYLE_DATA_V3));
			CacheService.getInstance().saveToCache(inlineStyleInsideCompDataV3Key,
					dataMap.get(COMPONENT_STYLE_INSIDE_COMP_DATA_V3));
			CacheService.getInstance().saveToCache(inlineStyleInsideCompV3Key,
					dataMap.get(COMPONENT_STYLE_INSIDE_COMP_V3));
			CacheService.getInstance().saveToCache(inlineStylePropsDataV3Key,
					dataMap.get(COMPONENT_STYLE_PROPS_DATA_V3));
			CacheService.getInstance().saveToCache(themeDetailDataKey,
					dataMap.get(THEME_DETAIL_DATA));
			CacheService.getInstance().saveToCache(compTemplateMstKey,
					dataMap.get(COMPONENT_TEMPLATE_MASTER_V3));
			
		}

		if (type.equals("getGroup")) {
			componentRetrunMap.put(COMPONENT_AND_GROUP_MAP,
					CacheService.getInstance().getCacheData(componentAndGroupMapKey));
		} else if (type.equals("getGroupAndInlineTemplate")) {
			componentRetrunMap.put(COMPONENT_AND_GROUP_MAP,
					CacheService.getInstance().getCacheData(componentAndGroupMapKey));
			componentRetrunMap.put(COMPONENT_STYLE_DETAIL_TEMPLATE_V3,
					CacheService.getInstance().getCacheData(inlineStyleTemplateV3Key));
		} else if (type.equals("getAll") || type.equals("getAllOtherThanGroup")) {
			if (type.equals("getAll"))
				componentRetrunMap.put(COMPONENT_AND_GROUP_MAP,
						CacheService.getInstance().getCacheData(componentAndGroupMapKey));
			componentRetrunMap.put(COMPONENT_ATTRIBUTE,
					CacheService.getInstance().getCacheData(componentAttributeMapKey));
			componentRetrunMap.put(COMPONENT_AND_EVENTS_MAP,
					CacheService.getInstance().getCacheData(componentAndEventsKey));
			componentRetrunMap.put(COMPONENT_STYLE_V1, CacheService.getInstance().getCacheData(componentStyleV1Key));
			componentRetrunMap.put(COMPONENT_STYLE_INSIDE_COMP_V3,
					CacheService.getInstance().getCacheData(inlineStyleInsideCompV3Key));
		} else if (type.equals("getInlineV3")) {
			componentRetrunMap.put(COMPONENT_STYLE_MASTER_V3,
					CacheService.getInstance().getCacheData(inlineStyleMstV3Key));
			componentRetrunMap.put(COMPONENT_STYLE_DETAIL_TEMPLATE_V3,
					CacheService.getInstance().getCacheData(inlineStyleTemplateV3Key));
			componentRetrunMap.put(COMPONENT_STYLE_DATA_V3,
					CacheService.getInstance().getCacheData(inlineStyleDataV3Key));
			componentRetrunMap.put(COMPONENT_STYLE_INSIDE_COMP_DATA_V3,
					CacheService.getInstance().getCacheData(inlineStyleInsideCompDataV3Key));
			componentRetrunMap.put(COMPONENT_STYLE_INSIDE_COMP_V3,
					CacheService.getInstance().getCacheData(inlineStyleInsideCompV3Key));
			componentRetrunMap.put(COMPONENT_STYLE_PROPS_DATA_V3,
					CacheService.getInstance().getCacheData(inlineStylePropsDataV3Key));
			componentRetrunMap.put(THEME_DETAIL_DATA,
					CacheService.getInstance().getCacheData(themeDetailDataKey));
			componentRetrunMap.put(COMPONENT_TEMPLATE_MASTER_V3,
					CacheService.getInstance().getCacheData(compTemplateMstKey));
			
		} else if (type.equals("getInlineMst")) {
			componentRetrunMap.put(COMPONENT_STYLE_MASTER_V3,
					CacheService.getInstance().getCacheData(inlineStyleMstV3Key));
			componentRetrunMap.put(COMPONENT_TEMPLATE_MASTER_V3,
					CacheService.getInstance().getCacheData(compTemplateMstKey));
		} else if (type.equals("getInlineTemplate")) {
			componentRetrunMap.put(COMPONENT_STYLE_DETAIL_TEMPLATE_V3,
					CacheService.getInstance().getCacheData(inlineStyleTemplateV3Key));
		} else if (type.equals("getInlineData")) {
			componentRetrunMap.put(COMPONENT_STYLE_DATA_V3,
					CacheService.getInstance().getCacheData(inlineStyleDataV3Key));
		} else if (type.equals("getInlineInideCompData")) {
			componentRetrunMap.put(COMPONENT_STYLE_INSIDE_COMP_DATA_V3,
					CacheService.getInstance().getCacheData(inlineStyleInsideCompDataV3Key));
		} else if (type.equals("getInsideComponent")) {
			componentRetrunMap.put(COMPONENT_STYLE_INSIDE_COMP_V3,
					CacheService.getInstance().getCacheData(inlineStyleInsideCompV3Key));
		} else if (type.equals("getInlinePropsData")) {
			componentRetrunMap.put(COMPONENT_STYLE_PROPS_DATA_V3,
					CacheService.getInstance().getCacheData(inlineStylePropsDataV3Key));
		} else if (type.equals("getThemeData")) {
			componentRetrunMap.put(THEME_DETAIL_DATA,
					CacheService.getInstance().getCacheData(themeDetailDataKey));
		} else if (type.equals("clearAll")) {
			cacheKeyList.stream().forEach(cacheKey_ -> {
				CacheService.getInstance().removeCacheByKey(cacheKey_);
			});
			CacheService.getInstance().removeCacheByKey("appgen_component_lang_attributes");
		}
		return componentRetrunMap;
	}

	/**
	 * isCacheKeyExists will check cache data for that key exists.
	 * 
	 * @return object
	 */
	public boolean isCacheDataNotExists(List<String> cacheList) {
		return (cacheList.stream().filter(cache -> Objects.isNull(CacheService.getInstance().getCacheData(cache)))
				.collect(Collectors.toList()).size() > 0);
	}

	/**
	 * getInlinePropsData will load inline style props data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInlinePropsData() throws Exception {
		return cacheServiceHandler("getInlinePropsData");
	}

	/**
	 * getInlineMst will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInlineMst() throws Exception {
		return cacheServiceHandler("getInlineMst");
	}

	/**
	 * getInlineTemplate will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInlineTemplate() throws Exception {
		return cacheServiceHandler("getInlineTemplate");
	}

	/**
	 * getInlineData will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInlineData() throws Exception {
		return cacheServiceHandler("getInlineData");
	}

	/**
	 * getInsideComponentInlineData will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInsideComponentInlineData() throws Exception {
		return cacheServiceHandler("getInlineInideCompData");
	}

	/**
	 * getInsideComponent will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInsideComponent() throws Exception {
		return cacheServiceHandler("getInsideComponent");
	}

	/**
	 * getAllInlineDataMap will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getAllInlineDataMap() throws Exception {
		return cacheServiceHandler("getInlineV3");
	}
	
	/**
	 * getAllThemeDataMap will load theme data.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getAllThemeDataMap() throws Exception {
		return cacheServiceHandler("getThemeData");
	}

	/**
	 * getInlineDataMap will load inline style data of version 3.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getInlineDataForTagNameList(List<String> tagNameList) throws Exception {
		Map<String, Object> cacheMap = cacheServiceHandler("getInlineV3");
		Map<String, Object> componentRetrunMap = new HashMap<>();
		LinkedHashMap<Object, Object> inlineMst = (LinkedHashMap<Object, Object>) cacheMap
				.get(COMPONENT_STYLE_MASTER_V3);
		LinkedHashMap<Object, Object> inlineTemplate = (LinkedHashMap<Object, Object>) cacheMap
				.get(COMPONENT_STYLE_DETAIL_TEMPLATE_V3);
		LinkedHashMap<Object, Object> inlineData = (LinkedHashMap<Object, Object>) cacheMap
				.get(COMPONENT_STYLE_DATA_V3);
		LinkedHashMap<Object, Object> inlineInsideCompData = (LinkedHashMap<Object, Object>) cacheMap
				.get(COMPONENT_STYLE_INSIDE_COMP_DATA_V3);
		LinkedHashMap<Object, Object> insideComponent = (LinkedHashMap<Object, Object>) cacheMap
				.get(COMPONENT_STYLE_INSIDE_COMP_V3);
		LinkedHashMap<Object, Object> inlinePropsData = (LinkedHashMap<Object, Object>) cacheMap
				.get(COMPONENT_STYLE_PROPS_DATA_V3);

		tagNameList.stream().forEach(tagName -> {
			Map<String, Object> attributeMap = new HashMap<>();
			attributeMap.put(COMPONENT_STYLE_MASTER_V3, inlineMst.get(tagName));
			attributeMap.put(COMPONENT_STYLE_DETAIL_TEMPLATE_V3, inlineTemplate.get(tagName));
			attributeMap.put(COMPONENT_STYLE_DATA_V3, inlineData.get(tagName));
			attributeMap.put(COMPONENT_STYLE_INSIDE_COMP_DATA_V3, inlineInsideCompData.get(tagName));
			attributeMap.put(COMPONENT_STYLE_INSIDE_COMP_V3, insideComponent.get(tagName));
			attributeMap.put(COMPONENT_STYLE_PROPS_DATA_V3, inlinePropsData.get(tagName));
			componentRetrunMap.put(tagName, attributeMap);
		});
		return componentRetrunMap;

	}

	/**
	 * getComponentMainMap will load only main table component with its group data.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<Object, List<Map<String, Object>>> getComponentMainMap() throws Exception {
		Map<String, Object> cacheMap = cacheServiceHandler("getGroup");
		return (Map<Object, List<Map<String, Object>>>) cacheMap.get(COMPONENT_AND_GROUP_MAP);
	}

	/**
	 * getComponentMainMapWithInlineTemplate will load only main table component
	 * with its group data with inline Template.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<Object, List<Map<String, Object>>> getComponentMainMapWithInlineTemplate() throws Exception {
		Map<String, Object> cacheMap = cacheServiceHandler("getGroupAndInlineTemplate");
		return (Map<Object, List<Map<String, Object>>>) cacheMap.get(COMPONENT_AND_GROUP_MAP);
	}

	/**
	 * getComponentMainMap will load only main table component with its group data.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getComponentAttributesByTagName(String tagName) throws Exception {
		return formComponentsAttributeDataByTagName(Arrays.asList(tagName));
	}

	/**
	 * getComponentMainMap will load only main table component with its group data.
	 *
	 * @return the object
	 * @throws Exception
	 */
	public Map<String, Object> getComponentAttributesByTagName(List<String> tagNameList) throws Exception {
		return formComponentsAttributeDataByTagName(tagNameList);
	}

	/**
	 * formComponentsAttributeDataByTagName will return data for all components
	 * 
	 * @param dataMap
	 * @throws Exception
	 */
	public Map<String, Object> formComponentsAttributeDataByTagName(List<String> tagNameList) throws Exception {
		Map<String, Object> cacheMap = cacheServiceHandler("getAllOtherThanGroup");
		Map<String, Object> componentRetrunMap = new HashMap<>();
		Map<String, Map<String, Object>> componentAttributeMap = (Map<String, Map<String, Object>>) cacheMap
				.get(COMPONENT_ATTRIBUTE);
		Map<String, Map<String, Object>> componentEventMap = (Map<String, Map<String, Object>>) cacheMap.get(COMPONENT_AND_EVENTS_MAP);
		Map<Object, Map<Object, List<Map<String, Object>>>> componentStyleV1 = (Map<Object, Map<Object, List<Map<String, Object>>>>) cacheMap
				.get(COMPONENT_STYLE_V1);
		LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>> insideComponent = (LinkedHashMap<Object, LinkedHashMap<Object, List<Map<String, Object>>>>) cacheMap
				.get(COMPONENT_STYLE_INSIDE_COMP_V3);

		tagNameList.stream().forEach(tagName -> {
			Map<String, Object> attributeMap = new HashMap<>();
			attributeMap.put("attributes", componentAttributeMap.get(tagName));
			attributeMap.put("styleHandler", componentStyleV1.get(tagName));
			attributeMap.put("insideComponent", insideComponent.get(tagName));
			attributeMap.put("events", componentEventMap.get(tagName));
			componentRetrunMap.put(tagName, attributeMap);
		});
		return componentRetrunMap;
	}

	/**
	 * upsertComponentInlineStyleV3 will upsert style property of the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	public Map<String, Object> upsertComponentInlineStyleV3(List<Map<String, Object>> paramList) throws Exception {
		return componentService.upsertComponentInlineStyleV3(paramList);
	}

	/**
	 * upsertInlineStylePropsDataV3 will upsert style props property of the
	 * component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	public Map<String, Object> upsertInlineStylePropsDataV3(List<Map<String, Object>> propsList, List<Map<String, Object>> styleList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		if(propsList.size() > 0) {
			returnMap.putAll(componentService.upsertInlineStylePropsDataV3(propsList));
		}
		if(styleList.size() > 0) {
			returnMap.putAll(componentService.upsertComponentInlineStyleV3(styleList));
		}
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * upsertTenantThemeDetails will upsert theme details of tenant and product code
	 * 
	 * @param paramList
	 * @throws Exception
	 */
	public Map<String, Object> upsertTenantThemeDetails(List<Map<String, Object>> paramList) throws Exception {
		return componentService.upsertTenantThemeDetails(paramList);
	}
	
	/**
	 * insertThemeDetails will insert theme details of theme code
	 * 
	 * @param paramList
	 * @throws Exception
	 */
	public Map<String, Object> insertThemeDetails(List<Map<String, Object>> paramList) throws Exception {
		return componentService.insertThemeDetails(paramList);
	}
	
	/**
	 * upsertThemeDetails will update theme details
	 * 
	 * @param paramList
	 * @throws Exception
	 */
	public Map<String, Object> upsertThemeDetails(List<Map<String, Object>> paramList) throws Exception {
		return componentService.upsertThemeDetails(paramList);
	}
	
	/**
	 * insertTemplate will insert template name
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> insertTemplate(List<Map<String, Object>> paramList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.insertTemplate(paramList));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * copyTemplate will copy template name
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> copyTemplate(List<Map<String, Object>> paramList, String compName, String newTemplateName, String existingTemplateName) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.copyTemplate(paramList, compName, newTemplateName, existingTemplateName));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * copyVariants will copy existing Variant for the component
	 * @param existedVariantText 
	 * @param selectedTemplate 
	 * @param compName 
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> copyVariants(List<Map<String, Object>> paramList, String compName, String selectedTemplate, String existedVariantText) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.copyVariants(paramList, compName, selectedTemplate, existedVariantText));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * insertVariants will insert Variant for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> insertVariants(List<Map<String, Object>> paramList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.insertVariants(paramList));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * deleteTemplate will delete template name
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> deleteTemplate(String templateName) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.deleteTemplate(templateName));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * deleteVariant will delete Variant for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> deleteVariant(String styleType, String templateType) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.deleteVariant(styleType, templateType));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * makeDefaultVariant will make Variant as default for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> makeDefaultVariant(List<Map<String, Object>> updateList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.makeDefaultVariant(updateList));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}

	/**
	 * clearCache will clear cache for component list cache key
	 * 
	 * @throws Exception
	 */
	public Boolean clearCache() throws Exception {
		cacheServiceHandler("clearAll");
		return true;
	}
	
	/**
	 * updateTemplate will update template name data
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> updateTemplate(List<Map<String, Object>> updateList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.updateTemplate(updateList));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * updateVariant will update variant name data
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> updateVariant(List<Map<String, Object>> updateList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.updateVariant(updateList));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * check whether template name already exist.
	 * 
	 * @throws Exception
	 */
	public boolean validateIsTemplateExist(String templateName) throws Exception {
		return componentService.validateIsTemplateExist(templateName);
	}
	
	/**
	 * check whether theme name already exist.
	 * 
	 * @throws Exception
	 */
	public boolean validateIsThemeExist(String themeName) throws Exception {
		return componentService.validateIsThemeExist(themeName);
	}

	/**
	 * removeDefaultVariant will remove Variant as default for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> removeDefaultVariant(List<Map<String, Object>> updateList) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.removeDefaultVariant(updateList));
		returnMap.put("componentDetail",getComponent());
		returnMap.put("componentInlineData",getAllInlineDataMap());
		return returnMap;
	}
	
	/**
	 * defaultThemeForTenant will map default theme for tenant
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> defaultThemeForTenant(String themeName) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.putAll(componentService.defaultThemeForTenant(themeName));
		return returnMap;
	}
	

}
