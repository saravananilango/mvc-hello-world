package com.nn.sova.service.constants;

import java.util.Map;

import com.google.common.collect.ImmutableMap;

/**
 * The Class Constants.
 */
public class Constants {
    public final static String RELEASE_STATUS = "release_status";
    public final static String UPDATED_AT = "updated_at";
    public final static String CHANGE_REQUEST_ID = "change_request_id";
    public final static String PROGRAM_DETAIL = "program_detail";
    public final static String PROGRAM_ID = "program_id";
    public final static String API_DETAIL = "api_detail";
    public final static String STATUS = "status";
    public final static String API_FLOW_LOGIC_DATA = "api_flow_logic_data";
    public final static String VARIABLE_LIST = "variable_list";
    public final static String MESSAGE_LIST = "message_list";
    public final static String TABLE_OBJECT_RESPONSE = "table_object_response";
    public final static String ESCAPE_ROUTE_DATA = "escape_route_data";
    public final static String API_DETAIl_ID = "api_detail_id";
    public final static String METHOD_TYPE = "method_type";
    public final static String METHOD_NAME = "method_name";
    public final static String METHOD_URL = "method_url";
    public final static String FLOW_LOGIC_TEMPLATE_NAME = "flow_logic_template_name";
    public final static String DESCRIPTION = "description";
    public final static String PATH_LIST = "path_list";
    public final static String INPUT_OUTPUT_PARAMETER = "input_output_parameter";
    public final static String PRODUCT_CODE = "product_code";
    public final static String SUB_PRODUCT_CODE = "sub_product_code";
    public final static String CODE_GENERATION_STATUS = "code_generation_status";
    public final static String COMBINED_URL = "combined_url";
    public final static String TEXT_MAP = "text_map";
    public static final String FLOW_LOG = "flow_log";
    public final static String MAJOR_VERSION = "major_version";
    public final static String MINOR_VERSION = "minor_version";
    public final static String PATCH_VERSION = "patch_version";
    public final static String TENANT_ID = "tenant_id";
    public final static String USER_NAME = "user_name";
    public final static String SCREEN_DEFINITION_ID = "screen_definition_id";
    public final static String SCREEN_DEFINITION = "screen_definition";
    public final static String CLASS_CONFIG_ID = "class_config_id";
    public final static String DELETED_PROGRAM_DESIGN_DETAIL = "deleted_program_design_detail";
    public final static String PROGRAM_TYPE = "program_type";
    public final static String REPO_NAME = "repo_name";
    public final static String DELETE_FLAG = "delete_flag";
    public final static String PROGRAM_DESIGN_DETAIL = "program_design_detail";
    public final static String PROGRAM_METHOD_DETAIL = "program_method_detail";
    public final static String CLASS_CONFIGURATION = "class_configuration";
    public static final String COMPONENT_DEFINITION = "component_definition";
    public final static String PROGRAM_BUSINESS_OBJECT = "program_business_object";
    public final static String HISTORY_VERSION = "history_version";
    public final static String PROGRAM_DATA = "program_data";

    // Program Business Object table constants
    public final static String BUSINESS_OBJECT_NAME = "business_object_name";
    public final static String TARGET_MODULE = "target_module";

    // program_logic_detail table related constants
    public final static String PROGRAM_LOGIC_DETAIL = "program_logic_detail";
    public final static String PROGRAM_LOGIC_EVENT_DETAIL = "program_logic_event_detail";
    public final static String FIELD_ID = "field_id";
    public final static String EVENT = "event";

    public final static Map<String, String[]> PROGRAM_PK_KEYS = ImmutableMap.<String, String[]>builder()
            .put(PROGRAM_DETAIL, new String[] { PROGRAM_ID, MAJOR_VERSION, TENANT_ID })
            .put(API_DETAIL,
                    new String[] { PROGRAM_ID, API_DETAIl_ID, MAJOR_VERSION, MINOR_VERSION, PATCH_VERSION, TENANT_ID })
            .put(PROGRAM_METHOD_DETAIL,
                    new String[] { PROGRAM_ID, SCREEN_DEFINITION_ID, PRODUCT_CODE, METHOD_NAME, MAJOR_VERSION,
                            MINOR_VERSION, PATCH_VERSION, TENANT_ID })
            .put(PROGRAM_BUSINESS_OBJECT,
                    new String[] { PROGRAM_ID, SCREEN_DEFINITION_ID, BUSINESS_OBJECT_NAME, TARGET_MODULE, TENANT_ID })
            .put(PROGRAM_LOGIC_DETAIL, new String[] { PROGRAM_ID, SCREEN_DEFINITION_ID, TENANT_ID })
            .put(PROGRAM_LOGIC_EVENT_DETAIL,
                    new String[] { PROGRAM_ID, SCREEN_DEFINITION_ID, FIELD_ID, EVENT, TENANT_ID })
            .put(PROGRAM_DESIGN_DETAIL, new String[] { SCREEN_DEFINITION_ID, TENANT_ID })
            .put(DELETED_PROGRAM_DESIGN_DETAIL, new String[] { SCREEN_DEFINITION_ID, PROGRAM_ID, MAJOR_VERSION,
                    MINOR_VERSION, PATCH_VERSION, TENANT_ID })
            .build();

}
