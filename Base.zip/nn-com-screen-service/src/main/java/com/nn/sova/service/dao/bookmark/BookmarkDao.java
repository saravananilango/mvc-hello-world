package com.nn.sova.service.dao.bookmark;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * BookmarkDao interface is to do database operations of Bookmark controller
 * 
 * @author Mohammed Shameer
 *
 */
public interface BookmarkDao {

	/**
	 * getUserBookmarkData is used to get the user bookmark data.
	 * 
	 * @return
	 * @throws QueryException
	 */
	List<Map<String, Object>> getUserBookmarkData() throws QueryException;

	/**
	 * getSharedBookmarkData is used to get the shared bookmark data.
	 * 
	 * @return
	 * @throws QueryException
	 */
	List<Map<String, Object>> getSharedBookmarkData() throws QueryException;

	/**
	 * insertBookmarkData is used to insert the bookmark data.
	 * 
	 * @param paramMap
	 * @throws QueryException
	 */
	void insertBookmarkData(Map<String, Object> paramMap) throws QueryException;

	/**
	 * deleteBookmarkData is used to delete the bookmark data.
	 * 
	 * @param bookmarkName
	 * @throws QueryException
	 */
	void deleteBookmarkData(String bookmarkName) throws QueryException;

	/**
	 * deleteSharedBookmarkData is used to delete the shared bookmark data.
	 * 
	 * @param bookmarkName
	 * @param sharedUser
	 * @throws QueryException
	 */
	void deleteSharedBookmarkData(String bookmarkName, String sharedUser) throws QueryException;

	/**
	 * markPrivateDefaultBookmarkData is used to mark private bookmark default.
	 * 
	 * @param bookmarkName
	 * @throws QueryException
	 */
	void markPrivateDefaultBookmarkData(String bookmarkName) throws QueryException;

	/**
	 * markSharedDefaultBookmarkData is used to mark shared bookmark default.
	 * 
	 * @param bookmarkName
	 * @param sharedUser
	 * @throws QueryException
	 */
	void markSharedDefaultBookmarkData(String bookmarkName, String sharedUser) throws QueryException;

	/**
	 * getSharedBookmarkDataByName is used to get the bookmark data by name
	 * 
	 * @param bookmarkName
	 * @param sharedUser
	 * @return
	 * @throws QueryException
	 */
	List<Map<String, Object>> getSharedBookmarkDataByName(String bookmarkName, String sharedUser) throws QueryException;

	/**
	 * getSharedBookmarkDataByName is used to get the bookmark data by name.
	 * 
	 * @param bookmarkName
	 * @return
	 * @throws QueryException
	 */
	List<Map<String, Object>> getPrivateBookmarkDataByName(String bookmarkName) throws QueryException;

	/**
	 * shareBookmarkData is used to share the bookmark data
	 * 
	 * @param bookmarkData
	 * @param usersList
	 * @throws QueryException
	 */
	void shareBookmarkData(Map<String, Object> bookmarkData, List<Object> usersList) throws QueryException;

	/**
	 * removePrivateDefaultBookmarkData is used to remove private bookmark default.
	 * 
	 * @param bookmarkName
	 * @throws QueryException
	 */
	void removePrivateDefaultBookmarkData(String bookmarkName) throws QueryException;

	/**
	 * removeSharedDefaultBookmarkData is used to remove private bookmark default.
	 * 
	 * @param bookmarkName
	 * @param sharedUser
	 * @throws QueryException
	 */
	void removeSharedDefaultBookmarkData(String bookmarkName, String sharedUser) throws QueryException;
}