package com.nn.sova.service.service.component;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * ComponentService class is used to access demo table information.
 *
 * @author Vignesh Palanisamy
 */
public interface ComponentService {
	/**
	 * getComponents will get components data
	 * 
	 * @throws Exception
	 */
	public  Map<String, Object> getComponents() throws Exception;
	
	/**
	 * upsertComponentInlineStyleV3 will upsert components data v3
	 * 
	 * @throws Exception
	 */
	public  Map<String, Object> upsertComponentInlineStyleV3(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * upsertInlineStylePropsDataV3 will upsert inline component props data v3
	 * 
	 * @throws Exception
	 */
	public  Map<String, Object> upsertInlineStylePropsDataV3(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * upsertTenantThemeDetails will upsert tenant theme details
	 * 
	 * @throws Exception
	 */
	public  Map<String, Object> upsertTenantThemeDetails(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * insertThemeDetails will insert theme details
	 * 
	 * @throws Exception
	 */
	public  Map<String, Object> insertThemeDetails(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * upsertThemeDetails will update theme details
	 * 
	 * @throws Exception
	 */
	public  Map<String, Object> upsertThemeDetails(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * insertTemplate will insert template name
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> insertTemplate(List<Map<String, Object>> insertList) throws Exception;
	
	/**
	 * copyTemplate will insert template name
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> copyTemplate(List<Map<String, Object>> copyList, String compName, String newTemplateName, String existingTemplateName) throws Exception;
	
	/**
	 * insertVariants will insert Variant for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> insertVariants(List<Map<String, Object>> insertList) throws Exception;
	
	/**
	 * copyVariants will insert Variant for the component
	 * @param existedVariantText 
	 * @param selectedTemplate 
	 * @param compName 
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> copyVariants(List<Map<String, Object>> copyList, String compName, String selectedTemplate, String existedVariantText) throws Exception;
	
	/**
	 * deleteTemplate will delete template name
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> deleteTemplate(String templateName) throws Exception;
	
	/**
	 * deleteVariant will delete Variant for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> deleteVariant(String styleType, String templateType) throws Exception;
	
	/**
	 * makeDefaultVariant will make Variant as default for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> makeDefaultVariant(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * removeDefaultVariant will remove Variant as default for the component
	 * 
	 * @throws Exception
	 */
	public Map<String, Object> removeDefaultVariant(List<Map<String, Object>> updateList) throws Exception;
	
	/**
	 * updateTemplate will update template data
	 * 
	 * @throws QueryException 
	 */
	Map<String, Object> updateTemplate(List<Map<String, Object>> updateList) throws QueryException;

	/**
	 * updateVariant will update variant data
	 * 
	 * @throws QueryException 
	 */
	Map<String, Object> updateVariant(List<Map<String, Object>> updateList) throws QueryException;
	
    /**
     * check whether Template name already exist.
     * @param templateName
     * @return
     * @throws QueryException
     */
	boolean validateIsTemplateExist(String templateName) throws QueryException;
	
    /**
     * check whether Theme name already exist.
     * @param themeName
     * @return
     * @throws QueryException
     */
	boolean validateIsThemeExist(String themeName) throws QueryException;
	
	/**
	 * defaultThemeForTenant will insert theme for tenant
	 * 
	 * @throws QueryException 
	 */
	Map<String, Object> defaultThemeForTenant(String themeName) throws QueryException;
}
