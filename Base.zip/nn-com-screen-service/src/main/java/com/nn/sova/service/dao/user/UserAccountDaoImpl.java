package com.nn.sova.service.dao.user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * UserAccountDaoImpl is used to do database related operations of useraccount.
 * 
 * @author Mohammed Shameer
 *
 */
public class UserAccountDaoImpl implements UserAccountDao {
	
	private static ApplicationLogger LOGGER = ApplicationLogger.create(UserAccountDaoImpl.class);

	/** The USER_ACCOUNT */
	private static final String USER_ACCOUNT = "user_account";

	@Override
	public void changeUserImage(String fileId, String referenceId) throws QueryException {
		new QueryBuilder().btSchema()
				.update().into(USER_ACCOUNT, "user_image_file_id", "user_image_path").where(ConditionBuilder.instance()
						.eq("tenant_id", ContextBean.getTenantId()).and().eq("user_id", ContextBean.getUserId()))
				.build().execute(referenceId, fileId);
	}

	@Override
	public List<Map<String, Object>> getUserAccountDetails(List<String> userIds) {
		QueryBuilder queryBuilder = new QueryBuilder().btSchema();
		List<Map<String, Object>> resultList = new ArrayList<>();
		try {
			ConditionBuilder condition = ConditionBuilder.instance();
			condition.in("user_id", userIds.toArray());
			SelectQueryBuilder selectQueryBuilder = queryBuilder.select().from(USER_ACCOUNT);
			selectQueryBuilder.where(condition);

			resultList = selectQueryBuilder.build(false).execute()
					.stream()
					.map(mapper -> transformData(mapper))
					.collect(Collectors.toList());
		} catch (Exception exception) {
			LOGGER.error(exception);
		}
		return resultList;
	}

	/**
	 * transformData method is to convert data.
	 * 
	 * @param mapper
	 * @return
	 */
	private Map<String, Object> transformData(Map<String, Object> mapper) {
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("userId", mapper.get("user_id"));
		returnMap.put("firstName", mapper.get("first_name"));
		returnMap.put("lastName", mapper.get("last_name"));
		returnMap.put("employeeNo", mapper.get("employee_no"));
		returnMap.put("emailId", mapper.get("email_id"));
		returnMap.put("personalMailId", mapper.get("personal_mail_id"));
		returnMap.put("userLocale", mapper.get("user_locale"));
		returnMap.put("address", mapper.get("address"));
		returnMap.put("bloodGroup", mapper.get("blood_group"));
		returnMap.put("country", mapper.get("country"));
		returnMap.put("timeZone", mapper.get("time_zone"));
		returnMap.put("userCalendar", mapper.get("user_calendar"));
		returnMap.put("dateFormat", mapper.get("date_format"));
		returnMap.put("timeFormat", mapper.get("time_format"));
		returnMap.put("currencyFormat", mapper.get("currency_format"));
		returnMap.put("userImagePath", mapper.get("user_image_path"));
		returnMap.put("userImageFileId", mapper.get("user_image_file_id"));
		return returnMap;
	}
}