package com.nn.sova.service.mastersearch.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.cache.CacheGetManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.mastersearch.model.MasterSearchLoadInfo;
import com.nn.sova.service.mastersearch.model.MasterSearchRequestParam;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.utility.cache.CacheGetService;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * MasterSearchDao is used to execute the search query and process the data.
 * 
 * @author Logchand
 *
 */
public class MasterSearchDao {

	/** The Constant LOGGER. */
	private static final ApplicationLogger LOGGER = ApplicationLogger.create(MasterSearchDao.class);

	/** The Constant CONST_DOT. */
	private static final String CONST_DOT = ".";

	/**
	 * Instantiates a new master search dao.
	 */
	private MasterSearchDao() {
	}

	/**
	 * getMasterInfo method is to process the query results.
	 *
	 * @param rows the rows
	 * @return masterInfo
	 */
	public static MasterSearchLoadInfo getMasterInfo(List<Map<String, Object>> rows) {
		MasterSearchLoadInfo masterInfo = new MasterSearchLoadInfo();
		if (!CollectionUtils.isEmpty(rows)) {
			Map<String, Object> row = new HashMap<>();
			Optional<Map<String, Object>> value = rows.stream().findFirst();
			if (value.isPresent()) {
				row = value.get();
			}
			masterInfo.setTableName((String) row.get("table_name"));
			masterInfo.setShowColumnName((String) row.get("show_column_name"));
			masterInfo.setSetColumnName((String) row.get("set_column_name"));
			if (Objects.nonNull(row.get("max_matches"))) {
				masterInfo.setMaxMatches((Integer) row.get("max_matches"));
			} else {
				masterInfo.setMaxMatches(0);
			}
			masterInfo.setMasterId((String) row.get("master_id"));
			masterInfo.setFilterFields((String) row.get("filter_fields"));
			masterInfo.setExtraFields((String) row.get("extra_fields"));
			masterInfo.setSortBy((String) row.get("sort_by"));
			masterInfo.setSortType((String) row.get("sort_type"));
			
			if (Objects.isNull(row.get("distinct_flag"))) {
				masterInfo.setDistinct(false);
			} else {
				masterInfo.setDistinct((boolean) row.get("distinct_flag"));
			}
			masterInfo.setProductName((String) row.get("product_code"));
			if (Objects.isNull(row.get("key_column_name"))) {
				masterInfo.setKeyColumnName(null);
			} else {
				masterInfo.setKeyColumnName((String) row.get("key_column_name"));
			}
			if (Objects.nonNull(row.get("independent_tenant_flag")) && Boolean.valueOf(String.valueOf(row.get("independent_tenant_flag")))) {
				masterInfo.setIndependentTenantFlag(true);
			} else {
				masterInfo.setIndependentTenantFlag(false);
			}
		}
		return masterInfo;
	}

	/**
	 * loadInfo method is used to execute the query and get master data table.
	 *
	 * @param masterKey the master key
	 * @return masterInfo
	 */
	public static MasterSearchLoadInfo loadInfo(String masterKey) {
		SelectQueryBuilder queryBuilder = new QueryBuilder().btSchema().select();
		List<Map<String, Object>> rows = new ArrayList<>();
		try {
			rows = queryBuilder.from("master_definition").checkIndependentTenant(true)
					.where(ConditionBuilder.instance().eq("master_id", masterKey)).build(true).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		if (!rows.isEmpty()) {
			return getMasterInfo(rows);
		} else {
			return null;
		}
	}

	/**
	 * processData method is used to arrange the processed data for autocomplete.
	 *
	 * @param rows       the rows
	 * @param masterInfo the master info
	 * @return resultList
	 */
	public static List<Map<String, String>> processData(List<Map<String, Object>> rows,
			MasterSearchLoadInfo masterInfo) {
		List<Map<String, String>> resultList;
		Set<String> showColumnSet = new LinkedHashSet<>();
		Set<String> setTextColumns = new LinkedHashSet<>();
		Set<String> extraColumns = new LinkedHashSet<>();
		if (Objects.nonNull(masterInfo.getShowColumnName()) && masterInfo.getShowColumnName().trim().length() > 0) {
			String[] columns = masterInfo.getShowColumnName().split(",");
			showColumnSet.addAll(Arrays.asList(columns));
		}
		if (Objects.nonNull(masterInfo.getSetColumnName()) && masterInfo.getSetColumnName().trim().length() > 0) {
			String[] columns = masterInfo.getSetColumnName().split(",");
			setTextColumns.addAll(Arrays.asList(columns));
		}
		if (StringUtils.isNotEmpty(masterInfo.getExtraFields())) {
			String[] extraFields = masterInfo.getExtraFields().split(",");
			extraColumns.addAll(Arrays.asList(extraFields));
		}
		String keyColumnName;
		if (Objects.nonNull(masterInfo.getKeyColumnName())) {
			keyColumnName = masterInfo.getKeyColumnName();
		} else {
			keyColumnName = null;
		}
		resultList = rows.stream().map(row -> {
			Map<String, String> tempMap = new HashMap<>();
			StringBuilder buffer = new StringBuilder();
			StringBuilder setBuffer = new StringBuilder();
			JSONObject extraColumnObject = new JSONObject();
			JSONObject subtextObject = new JSONObject();
			processSetColumn(setTextColumns, row, setBuffer, tempMap, keyColumnName);
			processShowColumn(showColumnSet, buffer, setTextColumns, subtextObject, row);
			try {
				subtextObject.put(keyColumnName, String.valueOf(row.get(keyColumnName)));
			} catch (JSONException exception) {
				LOGGER.error(exception);
			}
			tempMap.put("showText", buffer.toString());
			tempMap.put("subText", subtextObject.toString());
			processExtraColumns(extraColumns, extraColumnObject, row);
			tempMap.put("extraFields", extraColumnObject.toString());
			return tempMap;
		}).collect(Collectors.toList());
		return resultList;
	}

	/**
	 * Process extra columns.
	 *
	 * @param extraColumns      the extra columns
	 * @param extraColumnObject the extra column object
	 * @param row               the row
	 */
	private static void processExtraColumns(Set<String> extraColumns, JSONObject extraColumnObject,
			Map<String, Object> row) {
		if (Objects.nonNull(extraColumns)) {
			extraColumns.stream().filter(row::containsKey).forEach(extra -> {
				try {
					String value = Objects.toString(row.get(extra), "");
					extraColumnObject.put(extra, value);
				} catch (JSONException exception) {
					LOGGER.error(exception);
				}
			});
		}
	}

	/**
	 * Process show column.
	 *
	 * @param showColumnSet  the show column set
	 * @param buffer         the buffer
	 * @param setTextColumns the set text columns
	 * @param subtextObject  the subtext object
	 * @param row            the row
	 */
	private static void processShowColumn(Set<String> showColumnSet, StringBuilder buffer, Set<String> setTextColumns,
			JSONObject subtextObject, Map<String, Object> row) {
		showColumnSet.stream().forEach(columnName -> {
			if (Objects.nonNull(row.get(columnName))) {
				buffer.append(row.get(columnName));
				buffer.append(StringUtils.SPACE);
			}
			if (!setTextColumns.contains(columnName)) {
				try {
					subtextObject.put(columnName, String.valueOf(row.get(columnName)));
				} catch (JSONException exception) {
					LOGGER.error(exception);
				}
			}
		});
	}

	/**
	 * Process set column.
	 *
	 * @param setTextColumns the set text columns
	 * @param row            the row
	 * @param setBuffer      the set buffer
	 * @param tempMap        the temp map
	 * @param keyColumnName  the key column name
	 */
	private static void processSetColumn(Set<String> setTextColumns, Map<String, Object> row, StringBuilder setBuffer,
			Map<String, String> tempMap, String keyColumnName) {
		setTextColumns.stream().forEach(setColumn -> {
			if (Objects.nonNull(row.get(setColumn))) {
				setBuffer.append(row.get(setColumn));
				setBuffer.append(StringUtils.SPACE);
			}
		});
		tempMap.put("setText", setBuffer.toString().trim());
		if (Objects.nonNull(keyColumnName)) {
			tempMap.put("keyText", Objects.toString(row.get(keyColumnName), ""));
		}
	}

	/**
	 * fetchSingleData method will get only one data.
	 *
	 * @param param                 the param
	 * @param masterInfo            the master info
	 * @param langDependent         the lang dependent
	 * @param customCondition       the custom condition
	 * @param customConditionKeyMap the custom condition key map
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> fetchSingleData(MasterSearchRequestParam param,
			MasterSearchLoadInfo masterInfo, String langDependent, Boolean customCondition,
			Map<String, Object> customConditionKeyMap) {
		String setColumnName = masterInfo.getSetColumnName();
		String keyColumnName;
		Map<String, Object> filterFields = param.getFilterFields();
		Map<String, Object> filterConditions = param.getFilterConditions();
		String tableName = masterInfo.getTableName();
		if (Objects.nonNull(masterInfo.getKeyColumnName())) {
			keyColumnName = masterInfo.getKeyColumnName();
		} else {
			keyColumnName = setColumnName;
		}
		String[] showColumnNames = masterInfo.getShowColumnName().split(",");
		Set<String> columnSet = new LinkedHashSet<>(Arrays.asList(showColumnNames));
		if (!columnSet.contains(setColumnName)) {
			columnSet.add(setColumnName);
		}
		if (!columnSet.contains(keyColumnName)) {
			columnSet.add(keyColumnName);
		}
		if (StringUtils.isNotEmpty(masterInfo.getExtraFields())) {
			String[] extraFields = masterInfo.getExtraFields().split(",");
			columnSet.addAll(Arrays.asList(extraFields));
		}
		String customConditionKey = Objects.toString(customConditionKeyMap.get("key"), null);
		QueryBuilder searchBuilder;
		String url;
		String user;
		String password;
		String schema;
		String productCode = masterInfo.getProductName();
		if (Objects.nonNull(masterInfo.getProductName()) && masterInfo.getProductName().trim().length() > 0) {
			if (Objects.nonNull(EnvironmentReader
					.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("url")))) {
				url = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("url"));
				user = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("user"));
				password = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("password"));
				schema = EnvironmentReader
						.getGlobalPropertyValue(masterInfo.getProductName().concat(CONST_DOT).concat("schema"));
			} else {
				Map<String, Object> dbDetails = new HashMap<>();
				Object data = CacheGetService.getInstance()
						.getCustomCacheData("sova_product_code_handler_" + productCode);
				if (Objects.nonNull(data) && !CollectionUtils
						.isEmpty((Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>>) data)) {
					Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>> dataMap = (Map<Object, Map<Object, Map<Object, List<Map<String, Object>>>>>) data;
					if (StringUtils.isEmpty(EnvironmentReader.getSystemId())) {
						throw new RuntimeException("Default systemId Not present in Application Properties");
					}
					List<Map<String, Object>> dataList;
					if (StringUtils.isNotEmpty(ContextBean.getMsaName()) && dataMap.entrySet().iterator().next()
							.getValue().get(EnvironmentReader.getSystemId()).containsKey(ContextBean.getMsaName())) {
						dataList = dataMap.entrySet().iterator().next().getValue().get(EnvironmentReader.getSystemId())
								.get(ContextBean.getMsaName());
					} else {
						dataList = dataMap.entrySet().iterator().next().getValue().get(EnvironmentReader.getSystemId())
								.entrySet().iterator().next().getValue();
					}
					if (!CollectionUtils.isEmpty(dataList)) {
						dbDetails = dataList.get(0);
					} else {
						throw new RuntimeException(
								"Error: Database handler details is incorrect/not exist for handler '"
										+ dbDetails.get("handler_name") + "' in Product '" + productCode + "'.");
					}
				}
				try {
					url = QueryUtils.makeDatabaseUrl(dbDetails.get("database_type").toString(),
							dbDetails.get("ip_address").toString(), dbDetails.get("port").toString(),
							dbDetails.get("database_name").toString());
					user = dbDetails.get("database_username").toString();
					password = dbDetails.get("database_password").toString();
					schema = dbDetails.get("database_schema").toString();
				} catch (NullPointerException exception) {
					throw new RuntimeException("Error: Database handler details is incorrect/not exist for handler '"
							+ dbDetails.get("handler_name") + "' in Product '" + productCode + "'.");
				}
			}
			searchBuilder = new QueryBuilder(url, user, password, schema);
		} else {
			searchBuilder = new QueryBuilder();
		}
		SelectQueryBuilder queryBuilder;
		if (masterInfo.isDistinct()) {
			queryBuilder = searchBuilder.select().distinct();
		} else {
			queryBuilder = searchBuilder.select();
		}
		List<String> finalGetColumns = new ArrayList<>(columnSet);
		String[] columnArray = new String[finalGetColumns.size()];
		String[] finalColumnArray = finalGetColumns.toArray(columnArray);
		queryBuilder.get(finalColumnArray);
		ConditionBuilder finalConditionBuilder = null;
		if (Objects.isNull(customCondition) || !customCondition) {
			ConditionBuilder conditionBuilder = ConditionBuilder.instance();
			if(org.apache.commons.collections.CollectionUtils.isNotEmpty(param.getInputKeyword())) {
				conditionBuilder.inWithList(keyColumnName, true, (List)param.getInputKeyword());
			}
			if (StringUtils.isNotEmpty(masterInfo.getFilterFields()) && MapUtils.isNotEmpty(filterFields)) {
				String[] filterColumns = masterInfo.getFilterFields().split(",");
				Arrays.asList(filterColumns).stream().filter(filterFields::containsKey).forEach(column -> {
					if (Objects.nonNull(filterConditions.get(column))
							&& StringUtils.isNotEmpty(Objects.toString(filterConditions.get(column), ""))) {
						String conditions = Objects.toString(filterConditions.get(column), "");
						if (conditions.equalsIgnoreCase("eq")) {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.eq(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						} else if (conditions.equalsIgnoreCase("neq")) {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.notEq(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						} else if (conditions.equalsIgnoreCase("gt")) {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.gt(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						} else if (conditions.equalsIgnoreCase("lt")) {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.lt(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						} else if (conditions.equalsIgnoreCase("gte")) {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.gte(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						} else if (conditions.equalsIgnoreCase("lte")) {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.lte(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						} else if (conditions.equalsIgnoreCase("in")) {
							if (Objects.nonNull(filterFields.get(column))) {
								List<Object> inList = (List<Object>) filterFields.get(column);
								if (!CollectionUtils.isEmpty(inList)) {
									if (!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())) {
										conditionBuilder.and();
									}
									conditionBuilder.inWithList(column, true, inList);
								}
							}
						} else if (conditions.equalsIgnoreCase("notin")) {
							if (Objects.nonNull(filterFields.get(column))) {
								List<Object> inList = (List<Object>) filterFields.get(column);
								if (!CollectionUtils.isEmpty(inList)) {
									if (!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())) {
										conditionBuilder.and();
									}
									conditionBuilder.not().inWithList(column, true, inList);
								}
							}
						} else {
							if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
								conditionBuilder.and();
							}
							conditionBuilder.eq(column,
									QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
						}
					} else {
						if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
							conditionBuilder.and();
						}
						conditionBuilder.eq(column,
								QueryUtils.toQuotedString(Objects.toString(filterFields.get(column), "")), true);
					}
				});
			}
			finalConditionBuilder = conditionBuilder;
			queryBuilder.from(tableName);
		} else if (Objects.nonNull(customCondition) && customCondition && Objects.nonNull(customConditionKey)) {
			ConditionBuilder conditionBuilder = null;
			List<Map<String, Object>> customFilterList = new ArrayList<>();
			try {
				customFilterList = new QueryBuilder().btSchema().select().get("condition")
						.from("appgen_master_filter").where(ConditionBuilder.instance().eq("key", customConditionKey)).build(false).execute();
			} catch (QueryException exception) {
				LOGGER.error(exception);
			}
			if (!customFilterList.isEmpty() && Objects.nonNull(customFilterList.get(0))
					&& customFilterList.get(0).containsKey("condition")
					&& Objects.nonNull(customFilterList.get(0).get("condition"))) {
				ObjectMapper object = new ObjectMapper();
				String conditionString = Objects.toString(customFilterList.get(0).get("condition"), "");
				Map<String, Object> valueMap = Objects.nonNull(customConditionKeyMap.get("valueMap"))
						? (Map<String, Object>) customConditionKeyMap.get("valueMap")
						: new HashMap<>();
				Iterator<Map.Entry<String, Object>> itr = valueMap.entrySet().iterator();
				while (itr.hasNext()) {
					Map.Entry<String, Object> value = itr.next();
					conditionString = conditionString.replaceAll(Pattern.quote(value.getKey()),
							QueryUtils.toQuotedString(Objects.toString(value.getValue(), "")));
				}
				List<Map<String, Object>> conditionList = new ArrayList<>();
				try {
					conditionList = object.readValue(conditionString, new TypeReference<List<Map<String, Object>>>() {
					});
				} catch (Exception exception) {
					LOGGER.error(exception.getMessage());
				}
				conditionBuilder = ConditionBuilder.instance().brackets(ConditionBuilder.instance(conditionList));
			} else {
				conditionBuilder = ConditionBuilder.instance();
			}
			if(!CollectionUtils.isEmpty(param.getInputKeyword())) {
				if(!StringUtils.isAllEmpty(conditionBuilder.getQuery().trim())){
					conditionBuilder.and();
				}
				conditionBuilder.inWithList(keyColumnName, true, (List)param.getInputKeyword());
			}
			finalConditionBuilder = conditionBuilder;
			queryBuilder.from(tableName);
		}
		if(masterInfo.isIndependentTenantFlag()) {
			queryBuilder.checkIndependentTenant(true);
		}
		queryBuilder.checkSoftDelete(true);
		queryBuilder.setProductCode(productCode);
		makeWhereCondition(tableName, queryBuilder, finalConditionBuilder,productCode);
		List<Map<String, Object>> returnList = new ArrayList<>();
		try {
			returnList = queryBuilder.lang(Boolean.valueOf(langDependent)).build(false).execute();
		} catch (QueryException exception) {
			LOGGER.error(exception);
		}
		return returnList;
	}

	/**
	 * Make where condition.
	 *
	 * @param tableName             the table name
	 * @param queryBuilder          the query builder
	 * @param finalConditionBuilder the final condition builder
	 */
	@SuppressWarnings("unchecked")
	private static void makeWhereCondition(String tableName, SelectQueryBuilder queryBuilder,
			ConditionBuilder finalConditionBuilder,String productCode) {
		Set<String> langColumns = new HashSet<>();
		CacheGetManager redisGetManager = CacheGetManager.getInstance();
		Map<String, Object> viewConfig = (Map<String, Object>) redisGetManager.getViewConfig(tableName,productCode);
		if (Objects.nonNull(viewConfig) && !CollectionUtils.isEmpty(viewConfig)) {
			viewConfig.entrySet().stream().forEach(action -> {
				Map<String, Object> tableConfig = (Map<String, Object>) redisGetManager
						.getServerSideValidation(action.getKey(), ContextBean.getLocale(),productCode);
				if (Objects.nonNull(tableConfig) && !CollectionUtils.isEmpty(tableConfig)
						&& tableConfig.containsKey(ContextBean.getLocale())) {
					List<Map<String, Object>> data = (List<Map<String, Object>>) tableConfig
							.get(ContextBean.getLocale());
					List<Map<String, Object>> viewData = (List<Map<String, Object>>) action.getValue();
					Map<String, Object> viewMap = new HashMap<>();
					viewData.stream().forEach(viewDatas -> {
						viewMap.put(viewDatas.get("column_name").toString(),
								viewDatas.get("table_alias_name").toString());
					});
					data.stream()
							.filter(predicate -> Objects.nonNull(predicate.get("lang_dependent"))
									&& "true".equals(predicate.get("lang_dependent").toString()))
							.forEach(langData -> {
								if (viewMap.containsKey(langData.get("column_name"))) {
									langColumns
											.add(viewMap.get(langData.get("column_name")).toString() + "_locale");
								}
							});
				}
			});
			langColumns.stream().forEach(action -> {
				if (!StringUtils.isAllEmpty(finalConditionBuilder.getQuery())) {
					finalConditionBuilder.and();
				}
				finalConditionBuilder.eq(action, ContextBean.getLocale(), false);
			});
		}
		queryBuilder.where(finalConditionBuilder);
	}
}
