package com.nn.sova.service.constants.tabledefinition;

/**
 * MessageEntriesConstants are error message entries for table and data
 * definition
 * 
 * @author MOHAN RAM
 *
 */
public class MessageEntriesConstants {
	/**
	 * key for table definition update issue.
	 */
	public static final String TABLE_DEFINITION_ERROR_UPDATE = "table_definition_error_update";
	/**
	 * error key for offline or online not mentioned.
	 */
	public static final String OFFLINE_ONLINE_KEY = "table_definition_offline_online_key";
	/**
	 * key for table definition invalid application name.
	 */
	public static final String TABLE_DEFINITION_ERROR_APPLICATION_NAME = "table_definition_error_application_name";
	/**
	 * key for table definition database error details.
	 */
	public static final String TABLE_DEFINITION_ERROR_DATABASE_DETAILS = "table_definition_error_database_details";
	/**
	 * key for table definition repo details are not present.
	 */
	public static final String TABLE_DEFINITION_ERROR_REPO_DETAILS_INVALID = "table_definition_error_repo_details_invalid";
	/**
	 * key for invalid git handler
	 */
	public static final String TABLE_DEFINITION_ERROR_GIT_HANDLER_INVALID = "table_definition_error_git_handler_invalid";
	/**
	 * key for repo name not present in view
	 */
	public static final String TABLE_DEFINITION_ERROR_REPO_NAME_INVALID_VIEW = "table_definition_error_repo_name_invalid_view";
	/**
	 * key for package name not valid
	 */
	public static final String TABLE_DEFINITION_ERROR_PACKAGE_NAME_INVALID_VIEW = "table_definition_error_package_name_invalid_view";
	/**
	 * key for git ip invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_GIT_IP_INVALID_VIEW = "table_definition_error_git_ip_invalid_view";
	/**
	 * key for database url invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_DB_URL = "table_definition_error_db_url";
	/**
	 * key for database port invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_DB_PORT = "table_definition_error_db_port";
	/**
	 * key for database name invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_DB_NAME = "table_definition_error_db_name";
	/**
	 * key for database user name invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_DB_USER_NAME = "table_definition_error_db_user_name";
	/**
	 * key for database password invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_DB_PASSWORD = "table_definition_error_db_password";
	/**
	 * key for database schema name invalid
	 */
	public static final String TABLE_DEFINITION_ERROR_DB_SCHEMA_NAME = "table_definition_error_db_schema_name";
	/**
	 * key for table name already in use
	 */
	public static final String TABLE_DEFINITION_TABLENAME_IN_USE = "table_definition_tablename_in_use";
	/**
	 * key for table migration in progress
	 */
	public static final String TABLE_DEFINITION_MESAGE_TABLE_MIGRATION_IN_PROGRESS = "table_definition_mesage_table_migration_in_progress";
	/**
	 * key for data element error
	 */
	public static final String TABLE_DEFINITION_TABLE_DE_ERROR = "table_definition_table_de_error";
	/**
	 * key for table executor error
	 */
	public static final String TABLE_DEFINITION_TABLE_EXECUTOR_ERROR = "table_definition_table_executor_error";
	/**
	 * key for invalid data class error
	 */
	public static final String TABLE_DEFINITION_DATA_FORMAT_INVALID = "table_definition_data_format_invalid";
	/**
	 * key for system id error
	 */
	public static final String TABLE_DEFINITION_SYSTEM_ID_ERROR = "table_definition_system_id_error";
	/**
	 * key for table update error
	 */
	public static final String TABLE_DEFINITION_TABLE_UPDATE_ERROR = "table_definition_table_update_error";
	/**
	 * key for status not present error
	 */
	public static final String TABLE_DEFINITION_STATUS_NOT_PRESENT = "table_definition_status_not_present";
	/**
	 * key for handler details not present error
	 */
	public static final String TABLE_DEFINITION_HANDLER_NOT_PRESENT = "table_definition_handler_not_present";
	/**
	 * key for database details not present error
	 */
	public static final String TABLE_DEFINITION_DB_DETAILS_NOT_PRESENT = "table_definition_db_details_not_present";
	/**
	 * key for table name not present error
	 */
	public static final String TABLE_DEFINITION_TABLE_NAME_NOT_PRESENT = "table_definition_table_name_not_present";
	/**
	 * key for jenkins url not present error
	 */
	public static final String TABLE_DEFINITION_JENKINS_URL_NOT_PRESENT = "table_definition_jenkins_url_not_present";
	/**
	 * key for table definition migration url not present
	 */
	public static final String TABLE_DEFINITION_MIGRATION_URL_NOT_PRESENT = "table_definition_migration_url_not_present";
	/**
	 * key for database name not present
	 */
	public static final String TABLE_DEFINITION_DATABASE_NAME_NOT_PRESENT = "table_definition_database_name_not_present";
	/**
	 * key for table migration
	 */
	public static final String TABLE_DEFINITION_TABLE_MIGRATION = "table_definition_table_migration";
	/**
	 * key for source code generation not present
	 */
	public static final String TABLE_DEFINITION_SOURCE_CODE_GENERATION_NOT_PRESENT = "table_definition_source_code_generation_not_present";
	/**
	 * key for previous request id not present
	 */
	public static final String TABLE_DEFINITION_EXCEPTION_PREVIOUS_REQUEST_ID = "table_definition_exception_previous_request_id";
	/**
	 * key for table message executor error message
	 */
	public static final String TABLE_DEFINITION_TABLE_MESSAGE_EXECUTOR_ERROR = "table_definition_table_message_executor_error";
	/**
	 * key for table definition owner exception
	 */
	public static final String TABLE_DEFINITION_OWNER_EXCEPTION_TABLE = "table_definition_owner_exception_table";
	/**
	 * key for table definition no primary key mentioned
	 */
	public static final String TABLE_DEFINITION_NO_PRIMARY_KEY = "table_definition_no_primary_key";
	/**
	 * key for short text label
	 */
	public static final String TABLE_DEFINITION_SHORT_TEXT_LABEL = "table_definition_short_text_label";
	/**
	 * key for medium text label
	 */
	public static final String TABLE_DEFINITION_MEDIUM_TEXT_LABEL = "table_definition_medium_text_label";
	/**
	 * key for long text label
	 */
	public static final String TABLE_DEFINITION_LONG_TEXT_LABEL = "table_definition_long_text_label";
	/**
	 * key for example text label
	 */
	public static final String TABLE_DEFINITION_EXAMPLE_TEXT_LABEL = "table_definition_example_text_label";
	/**
	 * key for hint text label
	 */
	public static final String TABLE_DEFINITION_HINT_TEXT_LABEL = "table_definition_hint_text_label";
	/**
	 * key for data elements header
	 */
	public static final String TABLE_DEFINITION_DATA_ELEMENTS_HEADER = "table_definition_data_elements_header";
	/**
	 * key for data class header
	 */
	public static final String TABLE_DEFINITION_DATA_FORMAT_HEADER = "table_definition_data_format_header";
	/**
	 * key for table error message header
	 */
	public static final String TABLE_DEFINITION_TABLE_HEADER = "table_definition_table_header";
	/**
	 * key for cr in not ready state
	 */
	public static final String TABLE_DEFINITION_TABLE_ERROR_NOT_READY_STATE_ERROR = "table_definition_table_error_not_ready_state_error";
	/**
	 * key for table already in released state
	 */
	public static final String TABLE_DEFINITION_TABLE_ERROR_RELEASED_ERROR = "table_definition_table_error_released_error";
	/**
	 * key for table inprogress message
	 */
	public static final String TABLE_DEFINITION_TABLE_ERROR_INPROGRESS_TABLE = "table_definition_table_error_inprogress_table";
	/**
	 * key for success message table
	 */
	public static final String TABLE_DEFINITION_TABLE_ERROR_SUCCESS_TABLE = "table_definition_table_error_success_table";
	/**
	 * key for table definition inactive table error
	 */
	public static final String TABLE_DEFINITION_TABLE_ERROR_INACTIVE_TABLE = "table_definition_table_error_inactive_table";
	/**
	 * key for table definition live status
	 */
	public static final String TABLE_DEFINITION_LIVE_STATUS_ERROR = "table_definition_live_status_error";
	/**
	 * key for table definition cr status
	 */
	public static final String TABLE_DEFINITION_CR_STATUS_HANDLER_CHANGE = "table_definition_cr_status_handler_change";
	/**
	 * key for data definition definition details
	 */
	public static final String TABLE_DEFINITION_DATA_DEFINITION_DETAILS = "nn_table_definition_data_definition_details";
	/**
	 * key for charset id used in data class
	 */
	public static final String NN_DATA_DEF_CHARSET_ID_USED_IN_DATA_FORMAT = "nn_data_def_charset_id_used_in_data_format";
	/**
	 * key for data class used in data element
	 */
	public static final String NN_DATA_DEF_DATA_FORMAT_USED_IN_DATA_ELEMENT = "nn_data_def_data_format_used_in_data_element";
	/**
	 * key for data class used in table definition column details
	 */
	public static final String NN_DATA_DEF_DATA_FORMAT_USED_IN_COLUMN_DETAILS = "nn_data_def_data_format_used_in_column_details";
	/**
	 * key for data element used in table definition column details
	 */
	public static final String NN_DATA_DEF_DATA_ELEMENT_USED_IN_COLUMN_DETAILS = "nn_data_def_data_element_used_in_column_details";
	/**
	 * key for master id used data class
	 */
	public static final String NN_DATA_DEF_MASTER_ID_USED_IN_DATA_FORMAT = "nn_data_def_master_id_used_in_data_format";
	/**
	 * Error Message Content for offline table definition is empty.
	 */
	public static final String TABLE_DEFINITION_OFFLINE_ERROR_MESSAGE = "table_definition_offline_error_message";
	/**
	 * Error Message Content for offline table definition column details is empty.
	 */
	public static final String TABLE_DEFINITION_OFFLINE_COLUMN_DETAILS_ERROR_MESSAGE = "table_definition_offline_column_details_error_message";
	/**
	 * Error Message Content for mandatory offline table keys
	 */
	public static final String TABLE_DEFINITION_MANDATORY_OFFLINE_TABLE_KEY_NOT_PRESENT = "table_definition_mandatory_offline_table_key_not_present";
	/**
	 * Error Message Content for online table delete used in master
	 */
	public static final String TABLE_DEFINITION_TABLE_USED_IN_MASTER = "table_definition_table_used_in_master";
	/**
	 * key for cr title
	 */
	public static final String NN_DATA_DEF_CR_TITLE = "nn_data_def_cr_title";
	/**
	 * key for cr description
	 */
	public static final String NN_DATA_DEF_CR_DESCRIPTION = "nn_data_def_cr_description";
	/**
	 * key for data format transport not present
	 */
	public static final String NN_DATA_DEF_DATA_FORMAT_NOT_PRESENT_IN_TRANSPORT = "nn_data_def_data_format_not_present_in_transport";
	/**
	 * key for charset id transport not present
	 */
	public static final String NN_DATA_DEF_CHARSET_ID_NOT_PRESENT_IN_TRANSPORT = "nn_data_def_charset_id_not_present_in_transport";
	/**
	 * key for master id transport not present
	 */
	public static final String NN_DATA_DEF_MASTER_ID_NOT_PRESENT_IN_TRANSPORT = "nn_data_def_master_id_not_present_in_transport";
	/**
	 * key for value not present
	 */
	public static final String NN_DATA_DEF_NO_VALUE_PRESENT = "nn_data_def_no_value_present";
	/**
	 * key for value not present
	 */
	public static final String NN_DATA_DEF_DATA_ELEMENT_NOT_PRESENT_IN_TRANSPORT = "nn_data_def_data_element_not_present_in_transport";
	/**
	 * key for value not present
	 */
	public static final String NN_DATA_DEF_FORMAT_ID_NOT_PRESENT_IN_TRANSPORT = "nn_data_def_format_id_not_present_in_transport";
}
