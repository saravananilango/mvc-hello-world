package com.nn.sova;

import org.springframework.boot.SpringApplication;


/**
 * Start nn-home-service as a spring boot application
 * with context path "/nn-home-service"
 * 
 * WARNING : will be used only in local env.
 *
 * @author praveen_kumar_nr
 */
public class HomeServiceSpringBootApp {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		System.setProperty("server.servlet.context-path", "/nn-home-service");
		System.setProperty("server.port", "8090");
//		SpringApplication.run(HomeServiceApp.class, args);
	}

}
