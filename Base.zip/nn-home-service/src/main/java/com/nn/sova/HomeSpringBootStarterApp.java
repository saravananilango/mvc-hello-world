package com.nn.sova;

import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.quartz.QuartzAutoConfiguration;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nn.sova.service.utils.requestresponse.RequestResponseUtils;

import lombok.Data;


@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, RedisAutoConfiguration.class,
		QuartzAutoConfiguration.class })
@RestController
public class HomeSpringBootStarterApp extends SpringBootServletInitializer {
	HomeServiceApplication serviceApp;// Lambda service class

	public static void main(String[] args) {
		System.setProperty("server.port", "7090");
		System.setProperty("server.servlet.context-path", "/nn-home-service");
		System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		SpringApplication.run(HomeSpringBootStarterApp.class);
	}

	// Default code
	@RequestMapping("/**")
	public ResponseEntity<Object> handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		if (Objects.isNull(serviceApp))
			serviceApp = new HomeServiceApplication();
		request = getUpdatedRequest(request);
		return RequestResponseUtils
				.getResponseEntity(serviceApp.handleRequest(RequestResponseUtils.getRequestEvent(request)));
	}

	@Bean
	public WebSecurityConfigurerAdapter securtiyAdaptor() {
		return new WebSecurityConfigurerAdapter() {
			@Override
			protected void configure(HttpSecurity http) throws Exception {
				http.cors().and().csrf().disable();
			}
		};
	}
	

	private HttpServletRequest getUpdatedRequest(HttpServletRequest request) {
		return new HttpServletRequestWrapper(request) {
			private Set<String> headerNameSet;

			@Override
			public Enumeration<String> getHeaderNames() {
				if (headerNameSet == null) {
					headerNameSet = new HashSet<>();
					Enumeration<String> wrappedHeaderNames = super.getHeaderNames();
					while (wrappedHeaderNames.hasMoreElements()) {
						String headerName = wrappedHeaderNames.nextElement();
						if (!"Accept-Encoding".equalsIgnoreCase(headerName)) {
							headerNameSet.add(headerName);
						}
					}
				}
				return Collections.enumeration(headerNameSet);
			}

			@Override
			public Enumeration<String> getHeaders(String name) {
				if ("Accept-Encoding".equalsIgnoreCase(name)) {
					return Collections.<String>emptyEnumeration();
				}
				return super.getHeaders(name);
			}

			@Override
			public String getHeader(String name) {
				if ("Accept-Encoding".equalsIgnoreCase(name)) {
					return null;
				}
				return super.getHeader(name);
			}
		};
	}

}
