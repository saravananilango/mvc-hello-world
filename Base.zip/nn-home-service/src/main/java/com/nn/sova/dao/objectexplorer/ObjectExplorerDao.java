package com.nn.sova.dao.objectexplorer;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * object explorer dao interface.
 *
 * @author balajimu
 */
public interface ObjectExplorerDao {

    /**
     * Sets the fetch limit.
     *
     * @param value the new fetch limit
     */
    public void setFetchLimit(int value);

    /**
     * getTableObject method is to fetch product details data.
     *
     * @param dataMap the data map
     * @return the table object
     */
    public Map<String, Object> getTableObject(Map<String, Object> dataMap);

    /**
     * getViewObject method is to fetch product details data.
     *
     * @param dataMap the data map
     * @return the view object
     */
    public Map<String, Object> getViewObject(Map<String, Object> dataMap);

    /**
     * filterApplication method is to fetch product details data.
     *
     * @param paramMap the param map
     * @param type     the type
     * @return the map
     */
    public Map<String, Object> filterApplication(Map<String, Object> paramMap, String type);

    /**
     * filterTable filters tables.
     *
     * @param paramMap the param map
     * @return the map
     */
    public Map<String, Object> filterTable(Map<String, Object> paramMap);

    /**
     * Filters views.
     *
     * @param paramMap the param map
     * @return the map
     */
    public Map<String, Object> filterView(Map<String, Object> paramMap);

    /**
     * upserts recent data.
     *
     * @param insertList the insert list
     */
    void upsertRecent(List<Map<String, Object>> insertList);

    /**
     * selects recent data.
     *
     * @param paramMap the param map
     * @return the list
     */
    List<Map<String, Object>> selectRecent(Map<String, Object> paramMap);

    /**
     * filters application by id.
     *
     * @param screenIdList the screen id list
     * @return the list
     */
    List<Map<String, Object>> filterApplicationById(List<String> screenIdList);

    /**
     * filters table by id.
     *
     * @param tableIdList the table id list
     * @return the list
     */
    List<Map<String, Object>> filterTableById(List<String> tableIdList);

    /**
     * filters view by id.
     *
     * @param viewIdList the view id list
     * @return the list
     */
    List<Map<String, Object>> filterViewById(List<String> viewIdList);

    /**
     * getApplicationObject method is to fetch application details data.
     *
     * @param dataMap         the data map
     * @param applicationType the application type
     * @return the application object
     */
    Map<String, Object> getApplicationObject(Map<String, Object> dataMap, String applicationType);

    /**
     * Gets the applications data.
     *
     * @param dataMap         the data map
     * @param applicationType the application type
     * @return the applications data
     * @throws QueryException the query exception
     */
    Map<String, Object> getApplicationsData(Map<String, Object> dataMap, List<String> applicationType)
            throws QueryException;

    /**
     * filterApplication method is to fetch product details data.
     *
     * @param paramMap the param map
     * @param type     the type
     * @return the map
     */
    Map<String, Object> filterApplications(Map<String, Object> paramMap, List<String> type);

    /**
     * Gets the report data.
     *
     * @param dataMap the data map
     * @return the report data
     */
    Map<String, Object> getReportData(Map<String, Object> dataMap);

}
