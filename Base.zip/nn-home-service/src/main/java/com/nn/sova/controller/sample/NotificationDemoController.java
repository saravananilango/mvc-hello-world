package com.nn.sova.controller.sample;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nn.sova.service.annotations.SovaMapping;
//import com.nn.sova.service.api.notification.NotificationService;
import com.nn.sova.service.enums.SovaRequestMethod;

/**
 * Demo controller to test notification service using notification api end
 * point.
 * 
 * @author saravana
 *
 */
@SovaMapping("/sample/notificationapidemo")
public class NotificationDemoController {
//	private final NotificationService ntsApiService;

//	public NotificationDemoController() {
//		this.ntsApiService = NotificationService.getInstance();
//	}
//
//	@SovaMapping(value = "/notify", method = SovaRequestMethod.GET)
//	public void notifyByUserId() {
//		ntsApiService.notify(prepareUserIdData());
//	}
//
//	@SovaMapping(value = "/notifyBySms", method = SovaRequestMethod.GET)
//	public void notifyBySms() {
//		ntsApiService.notifyBySms(prepareSmsData());
//	}
//
//	@SovaMapping(value = "/notifyByMail", method = SovaRequestMethod.GET)
//	public void notifyByMail() {
//		ntsApiService.notifyByMail(prepareMailData());
//	}
//
//	@SovaMapping(value = "/notifyByFcm", method = SovaRequestMethod.GET)
//	public void notifyByFcm() {
//		ntsApiService.notifyByFcm(prepareFcmData());
//	}

	private List<Map<String, Object>> prepareMailData() {
		Map<String, Object> mailnotificationAlertIdData = new HashMap<>();
		mailnotificationAlertIdData.put("email_id", "saravanasrv94@gmail.com");
		mailnotificationAlertIdData.put("alert_id", "nn_approval_alert");
		Map<String, Object> mailnotificationDirectMessageData = new HashMap<>();
		mailnotificationDirectMessageData.put("email_id", "saravanasrv94@gmail.com");
		mailnotificationDirectMessageData.put("mail_subject", "3GB's Detla");
		mailnotificationDirectMessageData.put("mail_body",
				"<p>Hi,<p><p>We are launching brown rice .</p><p>Get your samples from today.</p><br><p>Thanks</p><p>3GB Delta Team</p>\"");
		return Arrays.asList(mailnotificationAlertIdData, mailnotificationDirectMessageData);
	}

	private List<Map<String, Object>> prepareSmsData() {
		Map<String, Object> smsNotificationDirectMessageData = new HashMap<>();
		smsNotificationDirectMessageData.put("phone_number", "8220719200");
		smsNotificationDirectMessageData.put("message", "APP IS UNDER MAINTENANCE .");
		Map<String, Object> smsNotificatioAlertIdnData1 = new HashMap<>();
		smsNotificatioAlertIdnData1.put("phone_number", "8220719200");
		smsNotificatioAlertIdnData1.put("alert_id", "nn_approval_alert");
		return Arrays.asList(smsNotificationDirectMessageData, smsNotificatioAlertIdnData1);
	}

	private List<Map<String, Object>> prepareFcmData() {
		Map<String, Object> fcmNotificatioAlertIdnData = new HashMap<>();
		fcmNotificatioAlertIdnData.put("fcm_id",
				"eCeDNf2GTLCFkJ1MSUMnhY:APA91bFVqt_ok--m_2p8xGrOAvuKRqwBUsNwoA1eSZPGnFH__auWNL0rfVuLamWnFjFaZ-yOI5JXDvHvV2habYalHxme0PaCfZnXXX2GT_AdkVM7ZvX_y7d8AvD1V21DLAhm7VmkooUW");
		fcmNotificatioAlertIdnData.put("alert_id", "nn_approval_alert");
		Map<String, Object> fcmNotificationDirectMessageData1 = new HashMap<>();
		fcmNotificationDirectMessageData1.put("fcm_id",
				"eCeDNf2GTLCFkJ1MSUMnhY:APA91bFVqt_ok--m_2p8xGrOAvuKRqwBUsNwoA1eSZPGnFH__auWNL0rfVuLamWnFjFaZ-yOI5JXDvHvV2habYalHxme0PaCfZnXXX2GT_AdkVM7ZvX_y7d8AvD1V21DLAhm7VmkooUW");
		fcmNotificationDirectMessageData1.put("title", "3GB's Detla");
		fcmNotificationDirectMessageData1.put("text", "We are launching brown rice.Get your samples from today.");
		return Arrays.asList(fcmNotificatioAlertIdnData, fcmNotificationDirectMessageData1);
	}
	
	private List<Map<String, Object>> prepareUserIdData() {
		Map<String, Object> approvalAlertUsers = new HashMap<>();
		approvalAlertUsers.put("userIds", Arrays.asList("approver1", "approver2"));
		approvalAlertUsers.put("alert_id", "nn_approval_alert");
		Map<String, Object> loginAlertUsers = new HashMap<>();
		loginAlertUsers.put("userIds", Arrays.asList("approver1", "approver2"));
		loginAlertUsers.put("alert_id", "nn_login_alert");
		return Arrays.asList(approvalAlertUsers, loginAlertUsers);
	}

}
