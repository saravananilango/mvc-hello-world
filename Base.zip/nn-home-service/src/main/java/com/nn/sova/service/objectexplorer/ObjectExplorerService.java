package com.nn.sova.service.objectexplorer;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * The Interface ObjectExplorerService.
 *
 * @author balajimu
 * 
 *         object Explorer service interface
 */
public interface ObjectExplorerService {

    /**
     * getObjects.
     *
     * @param paramMap the param map
     * @return the objects
     */
    public Map<String, Object> getObjects(Map<String, Object> paramMap);

    /**
     * filterObjects is the main method which perform facet change event, portal
     * search and sorting function.
     *
     * @param paramMap the param map
     * @param fromIndex the from index
     * @return Map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    Map<String, Object> filterObjects(Map<String, Object> paramMap, boolean fromIndex) throws IOException;

    /**
     * To load more data.
     *
     * @param dataMap the data map
     * @return the list
     */
    List<Map<String, Object>> loadMoreData(Map<String, Object> dataMap);

    /**
     * Updates recent Data.
     *
     * @param paramMap the param map
     */
    void updateRecent(Map<String, Object> paramMap);

    /**
     * returns recent.
     *
     * @param paramMap the param map
     * @return the recent
     */
    Map<String, Object> getRecent(Map<String, Object> paramMap);
}
