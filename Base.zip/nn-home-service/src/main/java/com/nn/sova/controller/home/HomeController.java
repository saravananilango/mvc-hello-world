package com.nn.sova.controller.home;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.controller.ApplicationController;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

/**
 * HomeController handles all the Home screen process.
 *
 * @author Logchand
 */
@SovaMapping("/")
public class HomeController extends ApplicationController {

    /** The logger. */
    private static ApplicationLogger logger = ApplicationLogger.create(HomeController.class);

    /**
     * getServiceDefId returns the serviceDefId of the screen.
     *
     * @return the screen definition id
     */
    @Override
    public String getScreenDefinitionId() {
        return "Home";
    }

    /**
     * home
     *
     * @param request  the request
     * @param response the response
     * @return the object
     * @throws IOException    Signals that an I/O exception has occurred.
     * @throws QueryException the query exception
     */
    @SovaMapping(value = "/home", method = SovaRequestMethod.POST)
    public void home(SovaHttpRequest request, SovaHttpResponse response)
			throws QueryException, IOException {
		logger.info("home start");
		List<FrontVo> paramList = new ArrayList<>();
		// When OTP User deliberately hits home page , it should be navigated to
		// UNAUTHORIZED PAGE .
		// To check if the user is OTP USER , AppUserId will be mobileNumber .
		if (StringUtils.isNotEmpty(ContextBean.getAppUserId())) {
			response.addHeader("isotplogin", "true");
			// Need to remove this errorMessage from Header , it should set via sendError(status, text)
			response.addHeader("errormessage", CacheService.getInstance()
					.getFrameworkTextDefinitionData("nn_unathorised_error_for_otp_user", ContextBean.getLocale()));
			response.sendError(HttpStatus.FORBIDDEN.value(), "");
			return;
		}
		response.withBody(showViewPage(request, paramList));
		}
    
}