package com.nn.sova.controller.menu;

import java.util.Map;

import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.menu.NotificationService;
import com.nn.sova.service.menu.NotificationServiceImpl;

@SovaMapping("/notification")
public class NotificationRestController {

	private static NotificationService notificationService = new NotificationServiceImpl();

	/**
	 * ApplicationRestController constructor
	 */
	public NotificationRestController() {
		notificationService = new NotificationServiceImpl();
	}

	/**
	 * save method is to save favorite values.
	 * 
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@SovaMapping(value = "/getNotification", method = SovaRequestMethod.POST)
	public void getNotification(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		response.withBody(notificationService.getNotification(paramMap));
	}

	/**
	 * save method is to save favorite values.
	 * 
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@SovaMapping(value = "/setAllRead", method = SovaRequestMethod.POST)
	public void setAllRead(SovaHttpRequest request) throws Exception {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		notificationService.setAllRead(paramMap);
	}

	/**
	 * save method is to save favorite values.
	 * 
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@SovaMapping(value = "/setReadByFeedId", method = SovaRequestMethod.POST)
	public void setReadByFeedId(SovaHttpRequest request) throws Exception {
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		notificationService.setReadByFeedId(paramMap);
	}

}
