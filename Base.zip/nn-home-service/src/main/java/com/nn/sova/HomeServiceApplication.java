package com.nn.sova;

import com.nn.sova.service.annotations.SovaComponentScan;
import com.nn.sova.service.webapp.SovaWebApplication;

@SovaComponentScan(basePackages = { "com.nn.sova.controller", "com.nn.sova.jobmanager.lib.controller" })
public class HomeServiceApplication extends SovaWebApplication {

	public HomeServiceApplication() {
		super();
	}
}
