package com.nn.sova.controller.sample;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.controller.ApprovalController;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.workflow.entity.ApplicationClientEntity;
import com.nn.sova.service.workflow.entity.ApplicationDataEntity;
import com.nn.sova.service.workflow.entity.ApplicationStepEntity;
import com.nn.sova.service.workflow.entity.ApplicationStepMemberEntity;
import com.nn.sova.service.workflow.entity.ApplicationTransitionEntity;

@SovaMapping("/sample")
public class WorkFlowSampleController extends ApprovalController{
	
	@Override
	public String getScreenDefinitionId() {
		return "WorkflowSample";
	}
	
//	@PostMapping("/index")
//	public List<FrontVo> index(@RequestBody Map<String, Object> postParamMap, HttpServletRequest request, HttpServletResponse response) throws QueryException{
//		List<FrontVo> voList  = new ArrayList<>();
//		return showViewPage(request, voList);
//	}
	
	@Override
	public List<FrontVo> index(ApplicationClientEntity clientEntity, Map<String, Object> postParamMap,
			SovaHttpRequest request, SovaHttpResponse response) throws QueryException {
		List<FrontVo> voList = new ArrayList();
		// TODO Auto-generated method stub
		return showViewPage(request, voList);
	}



	@Override
	public boolean beforeApplicationSubmit(ApplicationClientEntity clientEntity,
			Map<String, Object> postParamMap, List<FrontVo> voList, SovaHttpRequest request, SovaHttpResponse response) {
		if(postParamMap.containsKey("flowValue") && Objects.nonNull(postParamMap.get("flowValue"))) {
			clientEntity.setFlowValue(postParamMap.get("flowValue"));
		}
		if(postParamMap.containsKey("skipValue") && Objects.nonNull(postParamMap.get("skipValue"))) {
			clientEntity.setSkipValue(postParamMap.get("skipValue"));
		}
		try {
			Date newDate = new Date();
			String date = String.valueOf(newDate.getDate()).concat(String.valueOf(newDate.getMonth())).concat(String.valueOf(newDate.getYear()));
			String time = String.valueOf(newDate.getHours()).concat(String.valueOf(newDate.getMinutes())).concat(String.valueOf(newDate.getSeconds()));
			clientEntity.setApplicationUniqueId("SWF"+"-"+date+"-"+time);
			clientEntity.setDescription(clientEntity.getScreenId().concat("~").concat(clientEntity.getApplicationUniqueId()));			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}


	@Override
	public void setApplicationSpecificStep(ApplicationDataEntity appliationDataEntity, Map<String, Object> postParamMap,
			SovaHttpRequest request, SovaHttpResponse response) {
		ApplicationStepMemberEntity stepMemberEntity1 = new ApplicationStepMemberEntity();
		ApplicationStepMemberEntity stepMemberEntity2 = new ApplicationStepMemberEntity();
		ApplicationStepMemberEntity stepMemberEntity3 = new ApplicationStepMemberEntity();
		stepMemberEntity1.setApproverId("punithda");
		stepMemberEntity1.setApproverOrder(1);
		stepMemberEntity1.setStepOrder(1);
		stepMemberEntity2.setApproverId("aswathra");
		stepMemberEntity2.setApproverOrder(2);
		stepMemberEntity2.setStepOrder(1);
		stepMemberEntity3.setApproverId("seelan");
		stepMemberEntity3.setApproverOrder(1);
		stepMemberEntity3.setStepOrder(2);
		ApplicationStepEntity stepEntity1 = new ApplicationStepEntity();
		stepEntity1.setStepOrder(1);
		stepEntity1.setFirstStep(true);
		stepEntity1.setStepMemberEntityList(Arrays.asList(stepMemberEntity1, stepMemberEntity2));
		ApplicationStepEntity stepEntity2 = new ApplicationStepEntity();
		stepEntity2.setStepOrder(2);
		stepEntity2.setLastStep(true);
		stepEntity2.setStepMemberEntityList(Arrays.asList(stepMemberEntity3));
		appliationDataEntity.setApplicationStepEntityList(Arrays.asList(stepEntity1, stepEntity2));
	}

	@Override
	public void afterBulkApproval(List<ApplicationTransitionEntity> transitionEntityList, SovaHttpRequest request, SovaHttpResponse response) {
		return;
	}

}