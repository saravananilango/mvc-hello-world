package com.nn.sova.dao.objectexplorer;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.util.QueryUtils;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * object explorer dao implementation.
 *
 * @author balajimu
 */
public class ObjectExplorerDaoImpl implements ObjectExplorerDao {

    /** The Constant PROGRAM_DETAIL */
    private static final String PROGRAM_DETAIL = "program_detail";

    /** The Constant TABLE_DEFINITION */
    private static final String TABLE_DEFINITION = "table_definition";

    /** The Constant TABLE_DEFINITION_OFFLINE */
    private static final String TABLE_DEFINITION_OFFLINE = "table_definition_offline";

    /** The Constant PRODUCT_CONFIGURATION */
    private static final String PRODUCT_CONFIGURATION = "product_configuration";

    /** The Constant VIEW_OBJECT_DEFINITION */
    private static final String VIEW_OBJECT_DEFINITION = "view_object_definition";

    /** The Constant OBJECT_EXPLORER_RECENT */
    private static final String OBJECT_EXPLORER_RECENT = "object_explorer_recent_detail";

    /** The Constant COUNT. */
    private static final String COUNT = "count";

    /** The Constant CREATED_BY. */
    private static final String CREATED_BY = "created_by";

    /** The Constant CREATED_AT. */
    private static final String CREATED_AT = "created_at";

    /** The Constant UPDATED_BY. */
    private static final String UPDATED_BY = "updated_by";

    /** The Constant UPDATED_AT. */
    private static final String UPDATED_AT = "updated_at";

    /** The Constant FETCH_LIMIT. */
    public int FETCH_LIMIT = 40;

    /** The Constant DATA_COUNT. */
    private static final String DATA_COUNT = "dataCount";

    /** The Constant FIRST_INDEX. */
    private static final int FIRST_INDEX = 0;

    /** The Constant SEARCH_DATA. */
    private static final String SEARCH_DATA = "searchData";

    /** The Constant SORTMAP. */
    private static final String SORTMAP = "sortMap";

    /** The Constant FETCH_LIMIT_KEY. */
    private static final String FETCH_LIMIT_KEY = "fetchLimit";

    /** The Constant CURRENT_COUNT. */
    private static final String CURRENT_COUNT = "currentCount";

    /** The Constant LOGGER. */
    private static ApplicationLogger LOGGER = ApplicationLogger.create(ObjectExplorerDaoImpl.class);

    /**
     * getApplicationObject method is to fetch application details data.
     *
     * @param dataMap         the data map
     * @param applicationType the application type
     * @return the application object
     */
    @Override
    public Map<String, Object> getApplicationObject(Map<String, Object> dataMap, String applicationType) {
        Map<String, Object> objectMap = new HashMap<>();
        QueryBuilder queryBuilder = new QueryBuilder();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select()
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);

            subQueryBuilder = new QueryBuilder().select().get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").checkIndependentTenant(true).build(true);
            SelectQueryBuilder selectQueryBuilder = queryBuilder.select()
                    .getWithAliasName("program.program_id", "program_id")
                    .getWithAliasName("program.product_code", "product_code")
                    .getWithAliasName("program.program_type", "program_type")
                    .getWithAliasName("program.sub_product_code", "sub_product_code")
                    .getWithAliasName("program.program_name", "program_name")
                    .getWithAliasName("program.change_request_id", "change_request_id")
                    .getWithAliasName("program.api_type", "api_type")
                    .getWithAliasName("program.release_status", "release_status")
                    .getWithAliasName("program.created_at", CREATED_AT)
                    .getWithAliasName("program.created_by", CREATED_BY)
                    .getWithAliasName("program.current_version", "current_version")
                    .getWithAliasName("program.major_version", "major_version")
                    .getWithAliasName("program.updated_at", "updated_at")
                    .getWithAliasName("program.updated_by", "updated_by")
                    .getWithAliasName("product.product_name", "product_name")
//                  .getWithAliasName("repo.sub_product_name", "sub_product_name")
                    .from(PROGRAM_DETAIL, "program").leftJoin(PRODUCT_CONFIGURATION, "product",
                            ConditionBuilder.instance().eq("product.product_code", "program.product_code", true))
//                  .leftJoin(REPO_CONFIG, "repo", ConditionBuilder.instance().eq("repo.product_code", "program.product_code", true)
//                          .and().eq("repo.sub_product_code", "program.sub_product_code", true)
//                          .and().eq("repo.repo_type", "screen".equals(applicationType) ? "service" : applicationType, false))
                    .where(ConditionBuilder.instance().eq("program.created_by", dataMap.get("userName")).and()
                            .eq("program.program_type", applicationType).and().notEq("program.delete_flag", true).and()
                            .in("program.product_code", subQueryBuilder))
                    .checkIndependentTenant(true).build(false);
//          SELECT * FROM sova_core.sova_core_product_code_authority_view
            SelectQueryBuilder countSelectQueryBuilder = queryBuilder.select().checkIndependentTenant(true)
                    .count("1", COUNT).from(PROGRAM_DETAIL);
            objectMap.put(DATA_COUNT,
                    countSelectQueryBuilder
                            .where(ConditionBuilder.instance().eq(CREATED_BY, dataMap.get("userName")).and()
                                    .eq("program_type", applicationType).and().notEq("delete_flag", true))
                            .build(false).execute().get(FIRST_INDEX).get(COUNT));
            objectMap.put("data",
                    queryBuilder.select().checkIndependentTenant(true).from(selectQueryBuilder, "subTable").limit(5)
                            .orderBy("subTable.updated_at", SortType.DESC).build(false).execute());
        } catch (QueryException e) {
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return objectMap;
    }

    /**
     * Gets the report data.
     *
     * @param dataMap the data map
     * @return the report data
     */
    @Override
    public Map<String, Object> getReportData(Map<String, Object> dataMap) {
        var objectMap = new HashMap<String, Object>();
        try {

            var countSelectQueryBuilder = new QueryBuilder().select().checkIndependentTenant(true).count("1", COUNT)
                    .from("sova_core_report_creation_data");
            var listOfString = new ArrayList<String>();
            listOfString.add("major_version");
            listOfString.add("minor_version");
            listOfString.add("patch_version");

            var responseObject = new QueryBuilder().select().concatAll("combined_version", ".", listOfString)

                    .getWithAliasName("report_id", "program_id").getWithAliasName("product_code", "product_code")
                    .getWithAliasName("report_name", "program_name").getWithAliasName("created_at", CREATED_AT)
                    .getWithAliasName("created_by", CREATED_BY).getWithAliasName("major_version", "major_version")
                    .getWithAliasName("updated_at", "updated_at").getWithAliasName("updated_by", "updated_by")
                    .getWithAliasName("product_name", "product_name").getWithAliasName("report_active", "report_active")

                    .checkIndependentTenant(true).from("sova_core_report_creation_data");

            Integer fetchLimit = FETCH_LIMIT;
            Integer currentCount = null;
            if (Objects.nonNull(dataMap.get(FETCH_LIMIT_KEY))) {
            	fetchLimit = Integer.valueOf(dataMap.get(FETCH_LIMIT_KEY).toString());
            }
            if (Objects.nonNull(dataMap.get(CURRENT_COUNT))) {
            	currentCount = Integer.valueOf(dataMap.get(CURRENT_COUNT).toString());
            }
            ConditionBuilder aliseCondition = ConditionBuilder.instance();
            ConditionBuilder condition = ConditionBuilder.instance();
            List<Object> columns = Arrays.asList("report_name");
            getFacetCondition(aliseCondition, dataMap, columns, "report", null);
            getFacetCondition(condition, dataMap, columns, "report", null);

            if (dataMap.containsKey(SORTMAP)) {
                Map<String, String> sortDetailsMap = (Map<String, String>) dataMap.get(SORTMAP);
                String columnName = sortDetailsMap.get("columnName");
                columnName = "objectName".equals(columnName) ? "report_name" : columnName;
                SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                responseObject.orderBy(columnName, sortType);
            } else {
                responseObject.orderBy("updated_at", SortType.DESC);
            }
            if (!condition.getQuery().isEmpty()) {
                responseObject.where(aliseCondition);
                countSelectQueryBuilder.where(condition);
            }
            String[] columnArray = columns.toArray(new String[columns.size()]);

            if (Objects.nonNull(dataMap.get(SEARCH_DATA))
                    && StringUtils.isNotEmpty(dataMap.getOrDefault(SEARCH_DATA, "").toString())) {
                condition.and();
                aliseCondition.and();
                countSelectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(dataMap.get(SEARCH_DATA).toString(), columnArray));
                responseObject.where(
                        ConditionBuilder.instance().simpleSearch(dataMap.get(SEARCH_DATA).toString(), columnArray));
            }
            if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
                responseObject.offset(currentCount).limit(fetchLimit);
            } else {
                responseObject.limit(FETCH_LIMIT);
            }

            responseObject.build(true);
            objectMap.put(DATA_COUNT, countSelectQueryBuilder.build(true).execute().get(FIRST_INDEX).get(COUNT));
            objectMap.put("data", responseObject.execute());
        } catch (QueryException e) {
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return objectMap;
    }

    /**
     * Gets the first sub query.
     *
     * @return the first sub query
     * @throws QueryException the query exception
     */
    SelectQueryBuilder getFirstSubQuery() throws QueryException {
        return new QueryBuilder().select().get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                        ContextBean.getUserId()))
                .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);
    }

    /**
     * Gets the second sub query.
     *
     * @param subQueryBuilder1 the sub query builder 1
     * @return the second sub query
     * @throws QueryException the query exception
     */
    SelectQueryBuilder getSecondSubQuery(SelectQueryBuilder subQueryBuilder1) throws QueryException {
        return new QueryBuilder().select().get("productAuthority.product_code")
                .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1)).from("product_code_authority_view","productAuthority")
                .checkIndependentTenant(true).build(true);
    }

    /**
     * Gets the applications data.
     *
     * @param dataMap         the data map
     * @param applicationType the application type
     * @return the applications data
     * @throws QueryException the query exception
     */
    @Override
    public Map<String, Object> getApplicationsData(Map<String, Object> dataMap, List<String> applicationType)
            throws QueryException {
        List<SelectQueryBuilder> listOfBuilders = new ArrayList<SelectQueryBuilder>();
        var resultMap = new HashMap<String, Object>();
        IntStream.range(0, applicationType.size()).forEach(action -> {
            var objectMap = new HashMap<String, Object>();
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            resultMap.put(applicationType.get(action), objectMap);

            SelectQueryBuilder subQueryBuilder;
            SelectQueryBuilder subQueryBuilder1;
            QueryBuilder queryBuilder = new QueryBuilder();
            try {
                subQueryBuilder1 = getFirstSubQuery();
                subQueryBuilder = getSecondSubQuery(subQueryBuilder1);

                SelectQueryBuilder selectQueryBuilder = queryBuilder.select()

                        .getWithAliasName("program.release_version", "combined_version")
                        .getWithAliasName("program.program_id", "program_id")
                        .getWithAliasName("program.product_code", "product_code")
                        .getWithAliasName("program.program_type", "program_type")
                        .getWithAliasName("program.sub_product_code", "sub_product_code")
                        .getWithAliasName("program.program_name", "program_name")
                        .getWithAliasName("program.change_request_id", "change_request_id")
                        .getWithAliasName("program.api_type", "api_type")
                        .getWithAliasName("program.release_status", "release_status")
                        .getWithAliasName("program.created_at", CREATED_AT)
                        .getWithAliasName("program.created_by", CREATED_BY)
                        .getWithAliasName("program.current_version", "current_version")
                        .getWithAliasName("program.major_version", "major_version")
                        .getWithAliasName("program.updated_at", "updated_at")
                        .getWithAliasName("program.updated_by", "updated_by")
                        .getWithAliasName("product.product_name", "product_name").from(PROGRAM_DETAIL, "program")
                        .leftJoin(PRODUCT_CONFIGURATION, "product",
                                ConditionBuilder.instance().eq("product.product_code", "program.product_code", true))
                        .where(ConditionBuilder.instance().eq("program.created_by", dataMap.get("userName")).and()
                                .eq("program.program_type", applicationType.get(action)).and()
                                .notEq("program.delete_flag", true).and().in("program.product_code", subQueryBuilder))
                        .orderBy("updated_at", SortType.DESC).limit(5).checkIndependentTenant(true).build(false);

                var queryBuilderObject = queryBuilder.select()
                        .getWithAliasName("subTable" + action + ".combined_version", "combined_version")
                        .getWithAliasName("subTable" + action + ".program_id", "program_id")
                        .getWithAliasName("subTable" + action + ".product_code", "product_code")
                        .getWithAliasName("subTable" + action + ".program_type", "program_type")
                        .getWithAliasName("subTable" + action + ".sub_product_code", "sub_product_code")
                        .getWithAliasName("subTable" + action + ".program_name", "program_name")
                        .getWithAliasName("subTable" + action + ".change_request_id", "change_request_id")
                        .getWithAliasName("subTable" + action + ".api_type", "api_type")
                        .getWithAliasName("subTable" + action + ".release_status", "release_status")
                        .getWithAliasName("subTable" + action + ".created_at", CREATED_AT)
                        .getWithAliasName("subTable" + action + ".created_by", CREATED_BY)
                        .getWithAliasName("subTable" + action + ".current_version", "current_version")
                        .getWithAliasName("subTable" + action + ".major_version", "major_version")
                        .getWithAliasName("subTable" + action + ".updated_at", "updated_at")
                        .getWithAliasName("subTable" + action + ".updated_by", "updated_by")
                        .getWithAliasName("subTable" + action + ".product_name", "product_name")
                        .checkIndependentTenant(true).from(selectQueryBuilder, "subTable" + action);

                if (dataMap.containsKey(SORTMAP)) {
                    Map<String, String> sortDetailsMap = (Map<String, String>) dataMap.get(SORTMAP);
                    String columnName = sortDetailsMap.get("columnName");
                    columnName = "objectName".equals(columnName) ? "program_name" : columnName;
                    SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                    queryBuilderObject.orderBy(columnName, sortType);
                } else {
                    queryBuilderObject.orderBy("updated_at", SortType.DESC);
                }

                listOfBuilders.add(queryBuilderObject);
            } catch (QueryException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        });

        SelectQueryBuilder subQueryBuilder1;
        SelectQueryBuilder subQueryBuilder;

        for (int i = listOfBuilders.size() - 1; i > 0; i--) {
            listOfBuilders.get(i).build(false);
            listOfBuilders.get(i - 1).unionAll(listOfBuilders.get(i));
        }

        try {
            listOfBuilders.get(0).build(false);

            var dataList = listOfBuilders.get(0).execute();

            QueryBuilder queryBuilder = new QueryBuilder();
            subQueryBuilder1 = getFirstSubQuery();
            subQueryBuilder = getSecondSubQuery(subQueryBuilder1);
            SelectQueryBuilder countSelectQueryBuilder = queryBuilder.select().checkIndependentTenant(true)
                    .count("1", COUNT).get("program_type").from(PROGRAM_DETAIL);
            var countList = countSelectQueryBuilder
                    .where(ConditionBuilder.instance().eq(CREATED_BY, dataMap.get("userName")).and()
                            .notEq("delete_flag", true).and().in("product_code", subQueryBuilder))
                    .groupBy("program_type").build(false).execute();

            countList.stream().forEach(action -> {
                var dataValueMap = (Map<String, Object>) resultMap.get(action.get("program_type"));
                dataValueMap.put(DATA_COUNT, action.get(COUNT));
            });
            dataList.stream().forEach(action -> {
                var dataValueMap = (Map<String, Object>) resultMap.get(action.get("program_type"));
                ((List<Map<String, Object>>) dataValueMap.get("data")).add(action);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    /**
     * Gets the select instance.
     *
     * @param mainBuilder        the main builder
     * @param selectQueryBuilder the select query builder
     * @param applicationType    the application type
     * @return the select instance
     * @throws QueryException the query exception
     */
    SelectQueryBuilder getSelectInstance(SelectQueryBuilder mainBuilder, SelectQueryBuilder selectQueryBuilder,
            String applicationType) throws QueryException {
        SelectQueryBuilder queryBuilder = new QueryBuilder().select().checkIndependentTenant(true)
                .from(selectQueryBuilder, "subTable")
                .where(ConditionBuilder.instance().eq("program_type", applicationType))
                .orderBy("subTable.updated_at", SortType.DESC);

        return queryBuilder;

    }

    /**
     * getTableObject method is to fetch product details data.
     *
     * @param dataMap the data map
     * @return the table object
     */
    @Override
    public Map<String, Object> getTableObject(Map<String, Object> dataMap) {
        Map<String, Object> objectMap = new HashMap<>();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select().checkIndependentTenant(true)
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").build(true);

            subQueryBuilder = new QueryBuilder().select().checkIndependentTenant(true).get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").build(true);

            SelectQueryBuilder selectQueryBuilder = new QueryBuilder().select()
                    .getWithAliasName("def.table_name", "table_name")
                    .getWithAliasName("def.product_code", "product_code")
                    .getWithAliasName("def.table_description", "table_description")
//					.getWithAliasName("def.sub_product_code", "sub_product_code")
                    .getWithAliasName("def.active_status", "active_status")
                    .getWithAliasName("def.delete_flag", "delete_flag").getWithAliasName("def.version_no", "version_no")
                    .getWithAliasName("def.status", "status").getWithAliasName("def.locked_flag", "locked_flag")
                    .getWithAliasName("def.created_at", CREATED_AT).getWithAliasName("def.created_by", CREATED_BY)
                    .getWithAliasName("def.updated_at", "updated_at").getWithAliasName("def.updated_by", "updated_by")
                    .getWithAliasName("true", "online").from(TABLE_DEFINITION, "def").checkIndependentTenant(true)
                    .union(new QueryBuilder().select().getWithAliasName("offline.table_name", "table_name")
                            .getWithAliasName("offline.product_code", "product_code")
                            .getWithAliasName("offline.table_description", "table_description")
//							.getWithAliasName("offline.sub_product_code", "sub_product_code")
                            .getWithAliasName("offline.active_status", "active_status")
                            .getWithAliasName("offline.delete_flag", "delete_flag")
                            .getWithAliasName("offline.version_no", "version_no")
                            .getWithAliasName("offline.status", "status")
                            .getWithAliasName("offline.locked_flag", "locked_flag")
                            .getWithAliasName("offline.created_at", CREATED_AT)
                            .getWithAliasName("offline.created_by", CREATED_BY)
                            .getWithAliasName("offline.updated_at", "updated_at")
                            .getWithAliasName("offline.updated_by", "updated_by").getWithAliasName("false", "online")
                            .from(TABLE_DEFINITION_OFFLINE, "offline").checkIndependentTenant(true).build(false));

            SelectQueryBuilder builder = new QueryBuilder().select().from(selectQueryBuilder.build(false), "subTable")
                    .getWithAliasName("subTable.table_name", "table_name")
                    .getWithAliasName("subTable.product_code", "product_code")
                    .getWithAliasName("subTable.table_description", "table_description")
//					.getWithAliasName("subTable.sub_product_code", "sub_product_code")
                    .getWithAliasName("subTable.active_status", "active_status")
                    .getWithAliasName("subTable.delete_flag", "delete_flag")
                    .getWithAliasName("subTable.version_no", "version_no").getWithAliasName("subTable.status", "status")
                    .getWithAliasName("subTable.locked_flag", "locked_flag")
                    .getWithAliasName("subTable.created_at", CREATED_AT)
                    .getWithAliasName("subTable.created_by", CREATED_BY)
                    .getWithAliasName("subTable.updated_at", "updated_at")
                    .getWithAliasName("subTable.updated_by", "updated_by").getWithAliasName("subTable.online", "online")
                    .getWithAliasName("product.product_name", "product_name")
                    .leftJoin(PRODUCT_CONFIGURATION, "product",
                            ConditionBuilder.instance().eq("product.product_code", "subTable.product_code", true))
                    .where(ConditionBuilder.instance().eq("subTable.created_by", dataMap.get("userName")).and()
                            .in("subTable.product_code", subQueryBuilder))
                    .orderBy("subTable.updated_at", SortType.DESC).limit(5).checkIndependentTenant(true);

            SelectQueryBuilder countSelectQueryBuilder = new QueryBuilder().select().checkIndependentTenant(true)
                    .count("1", COUNT).from(selectQueryBuilder.build(false), "subTable")
                    .where(ConditionBuilder.instance().eq("subTable.created_by", dataMap.get("userName")).and()
                            .in("subTable.product_code", subQueryBuilder))
                    .build(false);

            objectMap.put(DATA_COUNT, countSelectQueryBuilder.execute().get(FIRST_INDEX).get(COUNT));
            objectMap.put("data", builder.build(false).execute());
        } catch (QueryException e) {
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return objectMap;
    }

    /**
     * getViewObject method is to fetch product details data.
     *
     * @param dataMap the data map
     * @return the view object
     */
    @Override
    public Map<String, Object> getViewObject(Map<String, Object> dataMap) {
        Map<String, Object> objectMap = new HashMap<>();
        QueryBuilder queryBuilder = new QueryBuilder();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select().checkIndependentTenant(true)
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").build(true);

            subQueryBuilder = new QueryBuilder().select().checkIndependentTenant(true).get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").build(true);
            SelectQueryBuilder selectQueryBuilder = queryBuilder.select()
                    .getWithAliasName("view.view_object_name", "view_object_name")
                    .getWithAliasName("view.product_code", "product_code")
                    .getWithAliasName("view.description", "description")
                    .getWithAliasName("view.main_table", "main_table")
                    .getWithAliasName("view.change_request_id", "change_request_id")
                    .getWithAliasName("view.status_flag", "status_flag")
                    .getWithAliasName("view.delete_flag", "delete_flag").getWithAliasName("view.view_flag", "view_flag")
                    .getWithAliasName("view.source_status", "source_status")
                    .getWithAliasName("view.version_no", "version_no").getWithAliasName("view.created_at", CREATED_AT)
                    .getWithAliasName("view.created_by", CREATED_BY).getWithAliasName("view.updated_at", "updated_at")
                    .getWithAliasName("view.updated_by", "updated_by")
                    .getWithAliasName("product.product_name", "product_name").from(VIEW_OBJECT_DEFINITION, "view")
                    .checkIndependentTenant(true).leftJoin(PRODUCT_CONFIGURATION, "product",
                            ConditionBuilder.instance().eq("product.product_code", "view.product_code", true));

            SelectQueryBuilder countSelectQueryBuilder = queryBuilder.select().count("1", COUNT)
                    .checkIndependentTenant(true).from(VIEW_OBJECT_DEFINITION);
            objectMap.put(DATA_COUNT,
                    countSelectQueryBuilder
                            .where(getDeleteFlag(null).and().eq(CREATED_BY, dataMap.get("userName")).and()
                                    .in("product_code", subQueryBuilder))
                            .checkIndependentTenant(true).build(false).execute().get(FIRST_INDEX).get(COUNT));
            objectMap.put("data",
                    new QueryBuilder().select().from(selectQueryBuilder.build(false), "subTable")
                            .where(getDeleteFlag("subTable").and().eq("subTable.created_by", dataMap.get("userName"))
                                    .and().in("product_code", subQueryBuilder))
                            .limit(4).limit(5).orderBy("updated_at", SortType.DESC).checkIndependentTenant(true)
                            .build(false).execute());
        } catch (QueryException e) {
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return objectMap;
    }

    /**
     * filterApplication method is to fetch product details data.
     *
     * @param paramMap the param map
     * @param type     the type
     * @return the map
     */
    @Override
    public Map<String, Object> filterApplications(Map<String, Object> paramMap, List<String> type) {
        List<SelectQueryBuilder> listOfBuilders = new ArrayList<SelectQueryBuilder>();
        new QueryBuilder();

        var resultMap = new HashMap<String, Object>();
        List<ConditionBuilder> conditonBuilderList = new ArrayList<>();
        List<Object> objectList = new ArrayList<Object>();
        IntStream.range(0, type.size()).forEach(action -> {
            objectList.add(type.get(action));
            ConditionBuilder condition = ConditionBuilder.instance();
            ConditionBuilder aliseCondition = ConditionBuilder.instance();

            var objectMap = new HashMap<String, Object>();
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            resultMap.put(type.get(action), objectMap);

            SelectQueryBuilder subQueryBuilder;
            SelectQueryBuilder subQueryBuilder1;
            QueryBuilder queryBuilder = new QueryBuilder();
            try {
                subQueryBuilder1 = getFirstSubQuery();
                subQueryBuilder = getSecondSubQuery(subQueryBuilder1);
//                .eq("program.created_by", dataMap.get("userName")).and()

                Integer fetchLimit = FETCH_LIMIT;
                Integer currentCount = null;
                if (Objects.nonNull(paramMap.get(FETCH_LIMIT_KEY))) {
                    fetchLimit = Integer.valueOf(paramMap.get(FETCH_LIMIT_KEY).toString());
                }
                if (Objects.nonNull(paramMap.get(CURRENT_COUNT))) {
                    currentCount = Integer.valueOf(paramMap.get(CURRENT_COUNT).toString());
                }
                List<Object> columns = Arrays.asList("program_name");

                getFacetCondition(condition, paramMap, columns, type.get(0), null);
                getFacetCondition(aliseCondition, paramMap, columns, type.get(0), "program");

                if (!condition.getQuery().isEmpty()) {
                    aliseCondition.and().notEq("program.delete_flag", true);
                    condition.and().notEq("delete_flag", true);
                } else {
                    aliseCondition.notEq("program.delete_flag", true);
                    condition.notEq("delete_flag", true);
                }

				SelectQueryBuilder selectQueryBuilder = queryBuilder.select()
						.getWithAliasName("program.release_version", "combined_version")
						.getWithAliasName("program.delete_flag", "delete_flag")
						.getWithAliasName("program.program_id", "program_id")
						.getWithAliasName("program.product_code", "product_code")
						.getWithAliasName("program.program_type", "program_type")
						.getWithAliasName("program.sub_product_code", "sub_product_code")
						.getWithAliasName("program.program_name", "program_name")
						.getWithAliasName("program.change_request_id", "change_request_id")
						.getWithAliasName("program.api_type", "api_type")
						.getWithAliasName("program.release_status", "release_status")
						.getWithAliasName("program.created_at", CREATED_AT)
						.getWithAliasName("program.created_by", CREATED_BY)
						.getWithAliasName("program.current_version", "current_version")
						.getWithAliasName("program.major_version", "major_version")
						.getWithAliasName("program.program_data", "program_data")
						.getWithAliasName("program.updated_at", "updated_at")
						.getWithAliasName("program.updated_by", "updated_by")
						.getWithAliasName("product.product_name", "product_name")
						.getWithAliasName("deploymentURL.status", "deployment_status")
						.getWithAliasName("deploymentURL.deployed_url", "deployed_url").from(PROGRAM_DETAIL, "program")
						.leftJoin(PRODUCT_CONFIGURATION, "product",
								ConditionBuilder.instance().eq("product.product_code", "program.product_code", true))
						.leftJoin("program_deployment_url", "deploymentURL",
								ConditionBuilder.instance().eq("deploymentURL.program_id", "program.program_id", true))
						.distinctOn(Arrays.asList("program.program_id"))
						.orderBy("program.program_id", SortType.DESC).checkIndependentTenant(true);
//                        .where(ConditionBuilder.instance().eq("program.program_type", type.get(action)).and()
//                                .notEq("program.delete_flag", true).and().in("program.product_code", subQueryBuilder))
//                        .orderBy("updated_at", SortType.DESC).limit(5).checkIndependentTenant(true)

                String[] columnArray = columns.toArray(new String[columns.size()]);
                if (paramMap.containsKey(SORTMAP)) {
                    Map<String, String> sortDetailsMap = (Map<String, String>) paramMap.get(SORTMAP);
                    String columnName = sortDetailsMap.get("columnName");
                    columnName = "objectName".equals(columnName) ? "program_name" : columnName;
                    SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                    if ("product_name".equals(columnName)) {
                        selectQueryBuilder.orderBy(columnName, sortType);
                    } else {

                        selectQueryBuilder.orderBy("program." + columnName, sortType);
                    }
                } else {
                    selectQueryBuilder.orderBy("program.updated_at", SortType.DESC);
                }

                aliseCondition.and().in("program.product_code", subQueryBuilder);
                condition.and().in("product_code", subQueryBuilder);

                aliseCondition.and().in("program.program_type", type.get(action));

                if (Objects.nonNull(paramMap.get(SEARCH_DATA))
                        && StringUtils.isNotEmpty(paramMap.getOrDefault(SEARCH_DATA, "").toString())) {
                    condition.and().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray);
                    aliseCondition.and().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray);
//                    countSelectQueryBuilder.where(
//                            ConditionBuilder.instance().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray));
//                    selectQueryBuilder.where(ConditionBuilder.instance()
//                            .simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray));
                }
                if (!condition.getQuery().isEmpty()) {
                    selectQueryBuilder.where(aliseCondition);
//                    countSelectQueryBuilder.where(condition);
                }

//                if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
//                    selectQueryBuilder.offset(currentCount).limit(fetchLimit);
//                } else {
//                    selectQueryBuilder.limit(FETCH_LIMIT);
//                }
                selectQueryBuilder.build(false);
                var queryBuilderObject = queryBuilder.select()
                        .getWithAliasName("subTable" + action + ".combined_version", "combined_version")
                        .getWithAliasName("subTable" + action + ".program_id", "program_id")
                        .getWithAliasName("subTable" + action + ".product_code", "product_code")
                        .getWithAliasName("subTable" + action + ".program_type", "program_type")
                        .getWithAliasName("subTable" + action + ".sub_product_code", "sub_product_code")
                        .getWithAliasName("subTable" + action + ".program_name", "program_name")
                        .getWithAliasName("subTable" + action + ".change_request_id", "change_request_id")
                        .getWithAliasName("subTable" + action + ".api_type", "api_type")
                        .getWithAliasName("subTable" + action + ".release_status", "release_status")
                        .getWithAliasName("subTable" + action + ".created_at", CREATED_AT)
                        .getWithAliasName("subTable" + action + ".created_by", CREATED_BY)
                        .getWithAliasName("subTable" + action + ".current_version", "current_version")
                        .getWithAliasName("subTable" + action + ".major_version", "major_version")
                        .getWithAliasName("subTable" + action + ".updated_at", "updated_at")
                        .getWithAliasName("subTable" + action + ".updated_by", "updated_by")
                        .getWithAliasName("subTable" + action + ".product_name", "product_name")
                        .getWithAliasName("subTable" + action + ".deployment_status", "deployment_status")
                        .getWithAliasName("subTable" + action + ".deployed_url", "deployed_url")
                        .getWithAliasName("subTable" + action + ".program_data", "program_data") // fix for deploy button
                        .checkIndependentTenant(true).from(selectQueryBuilder, "subTable" + action);

                if (paramMap.containsKey(SORTMAP)) {
                    Map<String, String> sortDetailsMap = (Map<String, String>) paramMap.get(SORTMAP);
                    String columnName = sortDetailsMap.get("columnName");
                    columnName = "objectName".equals(columnName) ? "program_name" : columnName;
                    SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                    queryBuilderObject.orderBy(columnName, sortType);
                } else {
                    queryBuilderObject.orderBy("updated_at", SortType.DESC);
                }
                
                if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
                	queryBuilderObject.offset(currentCount).limit(fetchLimit);
              } else {
            	  queryBuilderObject.limit(FETCH_LIMIT);
              }

                listOfBuilders.add(queryBuilderObject);
            } catch (QueryException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            if (action == 0) {
                conditonBuilderList.add(condition);
            }
        });

        try {
        	QueryBuilder queryUnionBuilder = new QueryBuilder();
            for (int i = listOfBuilders.size() - 1; i > 0; i--) {
                listOfBuilders.get(i).build(false);
                listOfBuilders.get(i - 1).build(false);
                listOfBuilders.set(i - 1, queryUnionBuilder.select().from(listOfBuilders.get(i - 1), "subTableSelect" + (i - 1)).unionAll(listOfBuilders.get(i)));
            }

            listOfBuilders.get(0).build(false);
            System.out.println(listOfBuilders.get(0).getQuery());
            var dataList = listOfBuilders.get(0).execute();

            if (!conditonBuilderList.isEmpty()) {

                QueryBuilder queryBuilder = new QueryBuilder();
                var subQueryBuilder1 = getFirstSubQuery();
                getSecondSubQuery(subQueryBuilder1);
                SelectQueryBuilder countSelectQueryBuilder = queryBuilder.select().checkIndependentTenant(true)
                        .count("1", COUNT).get("program_type").from(PROGRAM_DETAIL);
                var countList = countSelectQueryBuilder
                        .where(conditonBuilderList.get(0).and().inWithList("program_type", objectList))
                        .groupBy("program_type").build(false).execute();
                IntStream.range(0, type.size()).forEach(action -> {

                });
                countList.stream().forEach(action -> {
                    var dataValueMap = (Map<String, Object>) resultMap.get(action.get("program_type"));
                    dataValueMap.put(DATA_COUNT, action.get(COUNT));
                });
                dataList.stream().forEach(action -> {
                    var dataValueMap = (Map<String, Object>) resultMap.get(action.get("program_type"));
                    ((List<Map<String, Object>>) dataValueMap.get("data")).add(action);
                });
            }

        } catch (Exception e) {
            // TODO: handle exception
        	System.out.println(e.getMessage());
        }
//        try {
//
//            subQueryBuilder1 = getFirstSubQuery();
//            subQueryBuilder = getSecondSubQuery(subQueryBuilder1);
//
//            SelectQueryBuilder selectInnerQueryBuilder = new QueryBuilder().select()
//                    .getWithAliasName("program.program_id", "program_id")
//                    .getWithAliasName("program.product_code", "product_code")
//                    .getWithAliasName("program.program_type", "program_type")
//                    .getWithAliasName("program.sub_product_code", "sub_product_code")
//                    .getWithAliasName("program.program_name", "program_name")
//                    .getWithAliasName("program.change_request_id", "change_request_id")
//                    .getWithAliasName("program.api_type", "api_type")
//                    .getWithAliasName("program.release_status", "release_status")
//                    .getWithAliasName("program.created_at", CREATED_AT)
//                    .getWithAliasName("program.created_by", CREATED_BY)
//                    .getWithAliasName("program.current_version", "current_version")
//                    .getWithAliasName("program.major_version", "major_version")
//                    .getWithAliasName("program.updated_at", "updated_at")
//                    .getWithAliasName("program.updated_by", "updated_by")
//                    .getWithAliasName("program.delete_flag", "delete_flag")
//                    .getWithAliasName("product.product_name", "product_name")
////                  .getWithAliasName("repo.sub_product_name", "sub_product_name")
//                    .from(PROGRAM_DETAIL, "program")
//                    .leftJoin(PRODUCT_CONFIGURATION, "product",
//                            ConditionBuilder.instance().eq("product.product_code", "program.product_code", true))
//                    .checkIndependentTenant(true);
////                  .leftJoin(REPO_CONFIG, "repo", ConditionBuilder.instance().eq("repo.product_code", "program.product_code", true)
////                          .and().eq("repo.sub_product_code", "program.sub_product_code", true)
////                          .and().eq("repo.repo_type", "screen".equals(type) ? "service" : type, false));
//
//            SelectQueryBuilder selectQueryBuilder = new QueryBuilder().select()
//                    .from(selectInnerQueryBuilder.checkIndependentTenant(true).build(false), "program");
//
//            SelectQueryBuilder countSelectQueryBuilder = QueryBuilder.select().checkIndependentTenant(true)
//                    .count("1", COUNT).from(PROGRAM_DETAIL);
//
//            Integer fetchLimit = FETCH_LIMIT;
//            Integer currentCount = null;
//            if (Objects.nonNull(paramMap.get(FETCH_LIMIT_KEY))) {
//                fetchLimit = Integer.valueOf(paramMap.get(FETCH_LIMIT_KEY).toString());
//            }
//            if (Objects.nonNull(paramMap.get(CURRENT_COUNT))) {
//                currentCount = Integer.valueOf(paramMap.get(CURRENT_COUNT).toString());
//            }
//
//            List<Object> columns = Arrays.asList("program_name");
//
//            getFacetCondition(condition, paramMap, columns, type.get(0), null);
//            getFacetCondition(aliseCondition, paramMap, columns, type.get(0), "program");
//
//            if (!condition.getQuery().isEmpty()) {
//                aliseCondition.and().notEq("delete_flag", true);
//                condition.and().notEq("delete_flag", true);
//            } else {
//                aliseCondition.notEq("delete_flag", true);
//                condition.notEq("delete_flag", true);
//            }
//            String[] columnArray = columns.toArray(new String[columns.size()]);
//            if (paramMap.containsKey(SORTMAP)) {
//                Map<String, String> sortDetailsMap = (Map<String, String>) paramMap.get(SORTMAP);
//                String columnName = sortDetailsMap.get("columnName");
//                columnName = "objectName".equals(columnName) ? "program_name" : columnName;
//                SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
//                selectQueryBuilder.orderBy(columnName, sortType);
//            } else {
//                selectQueryBuilder.orderBy("updated_at", SortType.DESC);
//            }
//            if (!condition.getQuery().isEmpty()) {
//                selectQueryBuilder.where(aliseCondition);
//                countSelectQueryBuilder.where(condition);
//            }
//            aliseCondition.and().in("program.product_code", subQueryBuilder);
//            condition.and().in("product_code", subQueryBuilder);
//
//            if (Objects.nonNull(paramMap.get(SEARCH_DATA))
//                    && StringUtils.isNotEmpty(paramMap.getOrDefault(SEARCH_DATA, "").toString())) {
//                condition.and();
//                aliseCondition.and();
//                countSelectQueryBuilder.where(
//                        ConditionBuilder.instance().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray));
//                selectQueryBuilder.where(
//                        ConditionBuilder.instance().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray));
//            }
//            if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
//                selectQueryBuilder.offset(currentCount).limit(fetchLimit);
//            } else {
//                selectQueryBuilder.limit(FETCH_LIMIT);
//            }
//            reultMap.put(DATA_COUNT,
//                    countSelectQueryBuilder.where(ConditionBuilder.instance().and().eq("program_type", type))
//                            .checkIndependentTenant(true).build(false).execute().get(0).get(COUNT));
//            reultMap.put("data",
//                    selectQueryBuilder.where(ConditionBuilder.instance().and().eq("program.program_type", type))
//                            .checkIndependentTenant(true).build(false).execute());
//        } catch (QueryException e) {
//            reultMap.put(DATA_COUNT, FIRST_INDEX);
//            reultMap.put("data", new ArrayList<>());
//            LOGGER.error("Error in Filter view " + e);
//        }
        return resultMap;
    }

    /**
     * filterApplication method is to fetch product details data.
     *
     * @param paramMap the param map
     * @param type     the type
     * @return the map
     */
    @Override
    public Map<String, Object> filterApplication(Map<String, Object> paramMap, String type) {

        QueryBuilder QueryBuilder = new QueryBuilder();
        Map<String, Object> reultMap = new HashMap<>();
        ConditionBuilder condition = ConditionBuilder.instance();
        ConditionBuilder aliseCondition = ConditionBuilder.instance();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {

            subQueryBuilder1 = getFirstSubQuery();
            subQueryBuilder = getSecondSubQuery(subQueryBuilder1);

            SelectQueryBuilder selectInnerQueryBuilder = new QueryBuilder().select()
                    .getWithAliasName("program.program_id", "program_id")
                    .getWithAliasName("program.product_code", "product_code")
                    .getWithAliasName("program.program_type", "program_type")
                    .getWithAliasName("program.sub_product_code", "sub_product_code")
                    .getWithAliasName("program.program_name", "program_name")
                    .getWithAliasName("program.change_request_id", "change_request_id")
                    .getWithAliasName("program.api_type", "api_type")
                    .getWithAliasName("program.release_status", "release_status")
                    .getWithAliasName("program.created_at", CREATED_AT)
                    .getWithAliasName("program.created_by", CREATED_BY)
                    .getWithAliasName("program.current_version", "current_version")
                    .getWithAliasName("program.major_version", "major_version")
                    .getWithAliasName("program.updated_at", "updated_at")
                    .getWithAliasName("program.updated_by", "updated_by")
                    .getWithAliasName("program.delete_flag", "delete_flag")
                    .getWithAliasName("product.product_name", "product_name")
//					.getWithAliasName("repo.sub_product_name", "sub_product_name")
                    .from(PROGRAM_DETAIL, "program")
                    .leftJoin(PRODUCT_CONFIGURATION, "product",
                            ConditionBuilder.instance().eq("product.product_code", "program.product_code", true))
                    .checkIndependentTenant(true);
//					.leftJoin(REPO_CONFIG, "repo", ConditionBuilder.instance().eq("repo.product_code", "program.product_code", true)
//							.and().eq("repo.sub_product_code", "program.sub_product_code", true)
//							.and().eq("repo.repo_type", "screen".equals(type) ? "service" : type, false));

            SelectQueryBuilder selectQueryBuilder = new QueryBuilder().select()
                    .from(selectInnerQueryBuilder.checkIndependentTenant(true).build(false), "program");

            SelectQueryBuilder countSelectQueryBuilder = QueryBuilder.select().checkIndependentTenant(true)
                    .count("1", COUNT).from(PROGRAM_DETAIL);

            Integer fetchLimit = FETCH_LIMIT;
            Integer currentCount = null;
            if (Objects.nonNull(paramMap.get(FETCH_LIMIT_KEY))) {
                fetchLimit = Integer.valueOf(paramMap.get(FETCH_LIMIT_KEY).toString());
            }
            if (Objects.nonNull(paramMap.get(CURRENT_COUNT))) {
                currentCount = Integer.valueOf(paramMap.get(CURRENT_COUNT).toString());
            }

            List<Object> columns = Arrays.asList("program_name");

            getFacetCondition(condition, paramMap, columns, type, null);
            getFacetCondition(aliseCondition, paramMap, columns, type, "program");

            if (!condition.getQuery().isEmpty()) {
                aliseCondition.and().notEq("delete_flag", true);
                condition.and().notEq("delete_flag", true);
            } else {
                aliseCondition.notEq("delete_flag", true);
                condition.notEq("delete_flag", true);
            }
            String[] columnArray = columns.toArray(new String[columns.size()]);
            if (paramMap.containsKey(SORTMAP)) {
                Map<String, String> sortDetailsMap = (Map<String, String>) paramMap.get(SORTMAP);
                String columnName = sortDetailsMap.get("columnName");
                columnName = "objectName".equals(columnName) ? "program_name" : columnName;
                SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                selectQueryBuilder.orderBy(columnName, sortType);
            } else {
                selectQueryBuilder.orderBy("updated_at", SortType.DESC);
            }
            if (!condition.getQuery().isEmpty()) {
                selectQueryBuilder.where(aliseCondition);
                countSelectQueryBuilder.where(condition);
            }
            aliseCondition.and().in("program.product_code", subQueryBuilder);
            condition.and().in("product_code", subQueryBuilder);

            if (Objects.nonNull(paramMap.get(SEARCH_DATA))
                    && StringUtils.isNotEmpty(paramMap.getOrDefault(SEARCH_DATA, "").toString())) {
                condition.and();
                aliseCondition.and();
                countSelectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray));
                selectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(paramMap.get(SEARCH_DATA).toString(), columnArray));
            }
            if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
                selectQueryBuilder.offset(currentCount).limit(fetchLimit);
            } else {
                selectQueryBuilder.limit(FETCH_LIMIT);
            }
            reultMap.put(DATA_COUNT,
                    countSelectQueryBuilder.where(ConditionBuilder.instance().and().eq("program_type", type))
                            .checkIndependentTenant(true).build(false).execute().get(0).get(COUNT));
            reultMap.put("data",
                    selectQueryBuilder.where(ConditionBuilder.instance().and().eq("program.program_type", type))
                            .checkIndependentTenant(true).build(false).execute());
        } catch (QueryException e) {
            reultMap.put(DATA_COUNT, FIRST_INDEX);
            reultMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return reultMap;
    }

    /**
     * filterTable filters tables.
     *
     * @param dataMap the data map
     * @return the map
     */
    @Override
    public Map<String, Object> filterTable(Map<String, Object> dataMap) {
        Map<String, Object> objectMap = new HashMap<>();
        new QueryBuilder();
        ConditionBuilder aliseCondition = ConditionBuilder.instance();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select()
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);

            subQueryBuilder = new QueryBuilder().select().get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").checkIndependentTenant(true).build(true);

            SelectQueryBuilder selectInnerQueryBuilder = new QueryBuilder().select()
                    .getWithAliasName("def.table_name", "table_name")
                    .getWithAliasName("def.product_code", "product_code")
                    .getWithAliasName("def.table_description", "table_description")
//					.getWithAliasName("def.sub_product_code", "sub_product_code")
                    .getWithAliasName("def.active_status", "active_status")
                    .getWithAliasName("def.delete_flag", "delete_flag").getWithAliasName("def.version_no", "version_no")
                    .getWithAliasName("def.status", "status").getWithAliasName("def.locked_flag", "locked_flag")
                    .getWithAliasName("def.created_at", CREATED_AT).getWithAliasName("def.created_by", CREATED_BY)
                    .getWithAliasName("def.updated_at", "updated_at").getWithAliasName("def.updated_by", "updated_by")
                    .getWithAliasName("true", "online").from(TABLE_DEFINITION, "def").checkIndependentTenant(true)
                    .union(new QueryBuilder().select().getWithAliasName("offline.table_name", "table_name")
                            .getWithAliasName("offline.product_code", "product_code")
                            .getWithAliasName("offline.table_description", "table_description")
//			.getWithAliasName("offline.sub_product_code", "sub_product_code")
                            .getWithAliasName("offline.active_status", "active_status")
                            .getWithAliasName("offline.delete_flag", "delete_flag")
                            .getWithAliasName("offline.version_no", "version_no")
                            .getWithAliasName("offline.status", "status")
                            .getWithAliasName("offline.locked_flag", "locked_flag")
                            .getWithAliasName("offline.created_at", CREATED_AT)
                            .getWithAliasName("offline.created_by", CREATED_BY)
                            .getWithAliasName("offline.updated_at", "updated_at")
                            .getWithAliasName("offline.updated_by", "updated_by").getWithAliasName("false", "online")
                            .from(TABLE_DEFINITION_OFFLINE, "offline").checkIndependentTenant(true).build(false));

            SelectQueryBuilder selectQueryBuilder = new QueryBuilder().select()
                    .from(selectInnerQueryBuilder.build(false), "subTable")
                    .getWithAliasName("subTable.table_name", "table_name")
                    .getWithAliasName("subTable.product_code", "product_code")
                    .getWithAliasName("subTable.table_description", "table_description")
//					.getWithAliasName("subTable.sub_product_code", "sub_product_code")
                    .getWithAliasName("subTable.active_status", "active_status")
                    .getWithAliasName("subTable.delete_flag", "delete_flag")
                    .getWithAliasName("subTable.version_no", "version_no").getWithAliasName("subTable.status", "status")
                    .getWithAliasName("subTable.locked_flag", "locked_flag")
                    .getWithAliasName("subTable.created_at", CREATED_AT)
                    .getWithAliasName("subTable.created_by", CREATED_BY)
                    .getWithAliasName("subTable.updated_at", "updated_at")
                    .getWithAliasName("subTable.updated_by", "updated_by")
                    .getWithAliasName("product.product_name", "product_name")
                    .getWithAliasName("subTable.online", "online")
                    .leftJoin(PRODUCT_CONFIGURATION, "product",
                            ConditionBuilder.instance().eq("product.product_code", "subTable.product_code", true))
                    .checkIndependentTenant(true);

            SelectQueryBuilder countSelectQueryBuilder = new QueryBuilder().select().count("1", COUNT)
                    .checkIndependentTenant(true).from(selectInnerQueryBuilder.build(false), "subTable");

            Integer fetchLimit = FETCH_LIMIT;
            Integer currentCount = null;
            if (Objects.nonNull(dataMap.get(FETCH_LIMIT_KEY))) {
                fetchLimit = Integer.valueOf(dataMap.get(FETCH_LIMIT_KEY).toString());
            }
            if (Objects.nonNull(dataMap.get(CURRENT_COUNT))) {
                currentCount = Integer.valueOf(dataMap.get(CURRENT_COUNT).toString());
            }

            List<Object> columns = Arrays.asList("table_name");
            getFacetCondition(aliseCondition, dataMap, columns, "table", "subTable");
            String[] columnArray = columns.toArray(new String[columns.size()]);
            if (dataMap.containsKey(SORTMAP)) {
                Map<String, String> sortDetailsMap = (Map<String, String>) dataMap.get(SORTMAP);
                String columnName = sortDetailsMap.get("columnName");
                columnName = "objectName".equals(columnName) ? "table_name" : columnName;
                SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                selectQueryBuilder.orderBy(("product_name".equals(columnName) ? "product." : "subTable.") + columnName,
                        sortType);
            } else {
                selectQueryBuilder.orderBy("subTable.updated_at", SortType.DESC);
            }
            if (!aliseCondition.getQuery().isEmpty()) {
                selectQueryBuilder.where(aliseCondition);
                countSelectQueryBuilder.where(aliseCondition);
            }

            aliseCondition.and().in("subTable.product_code", subQueryBuilder);

            if (Objects.nonNull(dataMap.get(SEARCH_DATA))
                    && StringUtils.isNotEmpty(dataMap.getOrDefault(SEARCH_DATA, "").toString())) {
                aliseCondition.and();
                countSelectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(dataMap.get(SEARCH_DATA).toString(), columnArray));
                selectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(dataMap.get(SEARCH_DATA).toString(), columnArray));
            }

            if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
                selectQueryBuilder.offset(currentCount).limit(fetchLimit);
            } else {
                selectQueryBuilder.limit(FETCH_LIMIT);
            }

            objectMap.put(DATA_COUNT, countSelectQueryBuilder.checkIndependentTenant(true).build(false).execute()
                    .get(FIRST_INDEX).get(COUNT));
            objectMap.put("data", selectQueryBuilder.checkIndependentTenant(true).build(false).execute());
        } catch (QueryException e) {
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return objectMap;
    }

    /**
     * returs condition build for delete flag.
     *
     * @param aliseName the alise name
     * @return the delete flag
     */
    private ConditionBuilder getDeleteFlag(String aliseName) {
        String columnName = "view_flag";
        if (StringUtils.isNotEmpty(aliseName)) {
            columnName = aliseName + "." + columnName;
        }
        ConditionBuilder conditionBuilder = ConditionBuilder.instance()
                .brackets(ConditionBuilder.instance().eq(columnName, true).or().isNull(columnName));
        return conditionBuilder;
    }

    /**
     * Filters views.
     *
     * @param dataMap the data map
     * @return the map
     */
    @Override
    public Map<String, Object> filterView(Map<String, Object> dataMap) {
        Map<String, Object> objectMap = new HashMap<>();
        QueryBuilder QueryBuilder = new QueryBuilder();
        ConditionBuilder condition = ConditionBuilder.instance();
        ConditionBuilder aliseCondition = ConditionBuilder.instance();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select()
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);

            subQueryBuilder = new QueryBuilder().select().get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").checkIndependentTenant(true).build(true);

            ConditionBuilder.instance()
                    .in("view_object_name", new QueryBuilder().select().checkIndependentTenant(true)
                            .get("view_object_name").from("view_object_active_view").build(true))
                    .and().eq("active_flag ", true);
            SelectQueryBuilder selectInnerQueryBuilder = QueryBuilder.select()
                    .getWithAliasName("view.view_object_name", "view_object_name")
                    .getWithAliasName("view.product_code", "product_code")
                    .getWithAliasName("view.description", "description")
                    .getWithAliasName("view.main_table", "main_table")
                    .getWithAliasName("view.change_request_id", "change_request_id")
                    .getWithAliasName("view.status_flag", "status_flag")
                    .getWithAliasName("view.delete_flag", "delete_flag")
                    .getWithAliasName("view.active_flag", "active_flag")
                    .getWithAliasName("view.source_status", "source_status")
                    .getWithAliasName("view.version_no", "version_no").getWithAliasName("view.view_flag", "view_flag")
                    .getWithAliasName("view.created_at", CREATED_AT).getWithAliasName("view.created_by", CREATED_BY)
                    .getWithAliasName("view.updated_at", "updated_at").getWithAliasName("view.updated_by", "updated_by")
                    .getWithAliasName("product.product_name", "product_name").from(VIEW_OBJECT_DEFINITION, "view")
//                    .where(ConditionBuilder.instance().brackets(conditions).or().not().in("view_object_name",
//                            new QueryBuilder().select().checkIndependentTenant(true).get("view_object_name")
//                                    .from("view_object_active_view").build(true)))
                    .leftJoin(PRODUCT_CONFIGURATION, "product",
                            ConditionBuilder.instance().eq("product.product_code", "view.product_code", true))
                    .checkIndependentTenant(true);

            SelectQueryBuilder selectQueryBuilder = QueryBuilder.select()
                    .from(selectInnerQueryBuilder.build(false), "subTable").checkIndependentTenant(true);

            var conditions1 = ConditionBuilder.instance()
                    .in("view_object_name", new QueryBuilder().select().checkIndependentTenant(true)
                            .get("view_object_name").from("view_object_active_view").build(true))
                    .and().eq("active_flag ", true);

            SelectQueryBuilder countSelectQueryBuilder = QueryBuilder.select().count("1", COUNT)
                    .from(VIEW_OBJECT_DEFINITION).checkIndependentTenant(true);
            Integer fetchLimit = FETCH_LIMIT;
            Integer currentCount = null;
            if (Objects.nonNull(dataMap.get(FETCH_LIMIT_KEY))) {
                fetchLimit = Integer.valueOf(dataMap.get(FETCH_LIMIT_KEY).toString());
            }
            if (Objects.nonNull(dataMap.get(CURRENT_COUNT))) {
                currentCount = Integer.valueOf(dataMap.get(CURRENT_COUNT).toString());
            }

            List<Object> columns = Arrays.asList("view_object_name");
            getFacetCondition(condition, dataMap, columns, "view", null);
            getFacetCondition(aliseCondition, dataMap, columns, "view", "subTable");

            String[] columnArray = columns.toArray(new String[columns.size()]);
            if (dataMap.containsKey(SORTMAP)) {
                Map<String, String> sortDetailsMap = (Map<String, String>) dataMap.get(SORTMAP);
                String columnName = sortDetailsMap.get("columnName");
                columnName = "objectName".equals(columnName) ? "view_object_name" : columnName;
                SortType sortType = "ASC".equals(sortDetailsMap.get("sortOrder")) ? SortType.ASC : SortType.DESC;
                selectQueryBuilder.orderBy(columnName, sortType);
            } else {
                selectQueryBuilder.orderBy("updated_at", SortType.DESC);
            }
            if (!condition.getQuery().isEmpty()) {
                condition.and();
                aliseCondition.and();
            }
            condition.brackets(ConditionBuilder.instance().brackets(conditions1).or().not().in("view_object_name",
                    new QueryBuilder().select().checkIndependentTenant(true).get("view_object_name")
                            .from("view_object_active_view").build(true)));
            aliseCondition.brackets(ConditionBuilder.instance().brackets(conditions1).or().not().in("view_object_name",
                    new QueryBuilder().select().checkIndependentTenant(true).get("view_object_name")
                            .from("view_object_active_view").build(true)));
            if (!condition.getQuery().isEmpty()) {
                selectQueryBuilder.where(aliseCondition);
                countSelectQueryBuilder.where(condition);
            }

//			subQueryBuilder
            aliseCondition.and().in("subTable.product_code", subQueryBuilder);
            condition.and().in("product_code", subQueryBuilder);

            if (Objects.nonNull(dataMap.get(SEARCH_DATA))
                    && StringUtils.isNotEmpty(dataMap.getOrDefault(SEARCH_DATA, "").toString())) {
                condition.and();
                aliseCondition.and();
                countSelectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(dataMap.get(SEARCH_DATA).toString(), columnArray));
                selectQueryBuilder.where(
                        ConditionBuilder.instance().simpleSearch(dataMap.get(SEARCH_DATA).toString(), columnArray));
            }
            if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit)) {
                selectQueryBuilder.offset(currentCount).limit(fetchLimit);
            } else {
                selectQueryBuilder.limit(FETCH_LIMIT);
            }
            objectMap.put(DATA_COUNT, countSelectQueryBuilder.build(false).execute().get(FIRST_INDEX).get(COUNT));
            objectMap.put("data", selectQueryBuilder.build(false).execute());
        } catch (QueryException e) {
            objectMap.put(DATA_COUNT, FIRST_INDEX);
            objectMap.put("data", new ArrayList<>());
            LOGGER.error("Error in Filter view " + e);
        }
        return objectMap;
    }

    /**
     * getFacetCondition method is to apply filter condition for the filter.
     *
     * @param condition the condition
     * @param paramMap  the param map
     * @param columns   the columns
     * @param type      the type
     * @param aliseName the alise name
     * @return condition
     */
    @SuppressWarnings("unchecked")
    private ConditionBuilder getFacetCondition(ConditionBuilder condition, Map<String, Object> paramMap,
            List<Object> columns, String type, String aliseName) {
        if (paramMap.containsKey("facetvalue")) {
            Map<String, Object> facetvalue = (Map<String, Object>) paramMap.get("facetvalue");
            AtomicInteger count = new AtomicInteger();
            if (Objects.nonNull(facetvalue)) {
                ConditionBuilder conditionbuilder = ConditionBuilder.instance();
                facetGroupConditionBuilder(count, conditionbuilder, facetvalue, type, aliseName);
                if (count.get() != 0) {
                    condition.brackets(conditionbuilder);
                    condition.and();
                }
                String deleteCol = "view_flag";
                String primaryCol = columns.get(0).toString();
                if (StringUtils.isNotEmpty(aliseName)) {
                    deleteCol = aliseName + "." + deleteCol;
                    primaryCol = aliseName + "." + primaryCol;
                }
                condition.isNotNull(primaryCol);
                if ("view".equals(type)) {
                    condition.and().brackets(ConditionBuilder.instance().eq(deleteCol, true).or().isNull(deleteCol));
                }
            }
        }
        return condition;
    }

    /**
     * facetGroupConditionBuilder used for Facet Group conditions.
     *
     * @param count            the count
     * @param conditionbuilder the conditionbuilder
     * @param facetvalue       the facetvalue
     * @param type             the type
     * @param aliseName        the alise name
     */
    private void facetGroupConditionBuilder(AtomicInteger count, ConditionBuilder conditionbuilder,
            Map<String, Object> facetvalue, String type, String aliseName) {
        String updateDateCol = "updated_at";
        String productCol = "product_code";
        String createdByCol = "created_by";
        if (StringUtils.isNotEmpty(aliseName)) {
            updateDateCol = aliseName + "." + updateDateCol;
            productCol = aliseName + "." + productCol;
            createdByCol = aliseName + "." + createdByCol;
        }
        if ((Objects.nonNull(facetvalue.get("nn-object-only-me-switch-input"))
                && facetvalue.get("nn-object-only-me-switch-input").equals(true))
                || (Objects.nonNull(facetvalue.get("nn-object-user-master-input"))
                        && StringUtils.isNotEmpty(facetvalue.get("nn-object-user-master-input").toString()))) {
            count.incrementAndGet();
            conditionbuilder.eq(createdByCol,
                    !(Objects.nonNull(facetvalue.get("nn-object-only-me-switch-input"))
                            && facetvalue.get("nn-object-only-me-switch-input").equals(true))
                                    ? facetvalue.get("nn-object-user-master-input")
                                    : UserContext.getInstance().getUserName());
        }
        if (Objects.nonNull(facetvalue.get("nn-object-product"))
                && CollectionUtils.isNotEmpty((List<String>) facetvalue.get("nn-object-product"))) {
            if (count.get() == 0) {
                count.incrementAndGet();
            } else {
                conditionbuilder.and();
            }
            conditionbuilder.inWithList(productCol, ((List<Object>) facetvalue.get("nn-object-product")));
        }
        if (Objects.nonNull(facetvalue.get("nn-object-from-date"))
                && StringUtils.isNotEmpty(facetvalue.get("nn-object-from-date").toString())) {
            Date startDate = null;
            try {
                startDate = getSqlDate(facetvalue.get("nn-object-from-date"));
            } catch (Exception e) {
                LOGGER.error("Error in parsing date" + e);
            }
            if (Objects.nonNull(startDate)) {
                if (count.get() == 0) {
                    count.incrementAndGet();
                } else {
                    conditionbuilder.and();
                }
                conditionbuilder.gte(updateDateCol + "::date", startDate);
            }
        }
        if (Objects.nonNull(facetvalue.get("nn-object-to-date"))
                && StringUtils.isNotEmpty(facetvalue.get("nn-object-to-date").toString())) {
            Date endDate = null;
            try {
                endDate = getSqlDate(facetvalue.get("nn-object-to-date"));
            } catch (Exception e) {
                LOGGER.error("Error in parsing date" + e);
            }
            if (Objects.nonNull(endDate)) {
                if (count.get() == 0) {
                    count.incrementAndGet();
                } else {
                    conditionbuilder.and();
                }
                conditionbuilder.lte(updateDateCol + "::date", endDate);
            }
        }

        if (Objects.nonNull(facetvalue.get("nn-object-user-major-version-input"))
                && StringUtils.isNotEmpty(facetvalue.get("nn-object-user-major-version-input").toString())) {
            if (count.get() == 0) {
                count.incrementAndGet();
            } else {
                conditionbuilder.and();
            }
            String column = "major_version";
            String value = facetvalue.get("nn-object-user-major-version-input").toString();
            if ("table".equals(type) || "view".equals(type)) {
                column = "version_no";
                if (StringUtils
                        .isNotEmpty(facetvalue.getOrDefault("nn-object-user-minor-version-input", "").toString())) {
                    value = value + "." + facetvalue.getOrDefault("nn-object-user-minor-version-input", "").toString()
                            + ".";
                }
                if (StringUtils
                        .isNotEmpty(facetvalue.getOrDefault("nn-object-user-patch-version-input", "").toString())) {
                    value = value + facetvalue.getOrDefault("nn-object-user-patch-version-input", "").toString();
                }
            }
            if ("screen".equals(type) || "batch".equals(type) || "api".equals(type) || "rule".equals(type) || "library".equals(type)) {
                column = "release_version";
                if (StringUtils
                        .isNotEmpty(facetvalue.getOrDefault("nn-object-user-minor-version-input", "").toString())) {
                    value = value + "." + facetvalue.getOrDefault("nn-object-user-minor-version-input", "").toString()
                            + ".";
                }
                if (StringUtils
                        .isNotEmpty(facetvalue.getOrDefault("nn-object-user-patch-version-input", "").toString())) {
                    value = value + facetvalue.getOrDefault("nn-object-user-patch-version-input", "").toString();
                }
            }
            conditionbuilder.ilike(column, value + "%");
            
            if ("report".equals(type)) {
                if (StringUtils
                        .isNotEmpty(facetvalue.getOrDefault("nn-object-user-minor-version-input", "").toString())) {
                	column = "minor_version";
                    value = facetvalue.getOrDefault("nn-object-user-minor-version-input", "").toString();
                    conditionbuilder.and();
                    conditionbuilder.ilike(column, value + "%");
                }
                if (StringUtils
                        .isNotEmpty(facetvalue.getOrDefault("nn-object-user-patch-version-input", "").toString())) {
                	column = "patch_version";
                	value = facetvalue.getOrDefault("nn-object-user-patch-version-input", "").toString();
                    conditionbuilder.and();
                    conditionbuilder.ilike(column, value + "%");
                }
            }
        }
    }

    /**
     * returns sql date.
     *
     * @param date the date
     * @return the sql date
     * @throws ParseException the parse exception
     */
    private Date getSqlDate(Object date) throws ParseException {
        Date parsedDate = null;
        SimpleDateFormat formatterStartDate = new SimpleDateFormat("yyyy/MM/dd");
        java.util.Date value = formatterStartDate.parse(date.toString());
        parsedDate = new Date(value.getTime());
        return parsedDate;
    }

    /**
     * selects recent data.
     *
     * @param paramMap the param map
     * @return the list
     */
    @Override
    public List<Map<String, Object>> selectRecent(Map<String, Object> paramMap) {
        QueryBuilder queryBuilder = new QueryBuilder();
        try {
            return queryBuilder.select().checkIndependentTenant(true).from(OBJECT_EXPLORER_RECENT)
                    .where(ConditionBuilder.instance().eq("user_id", paramMap.get("userId"))).limit(20)
                    .orderBy(CREATED_AT, SortType.DESC).build(false).execute();
        } catch (QueryException e) {
            LOGGER.error("Error in select recent" + e);
        }
        return new ArrayList<>();
    }

    /**
     * upserts recent data.
     *
     * @param insertList the insert list
     */
    @Override
    public void upsertRecent(List<Map<String, Object>> insertList) {
        List<String> updateColumns = new ArrayList<>(Arrays.asList("user_id", "object_type", "row_number", "object_id",
                CREATED_BY, CREATED_AT, UPDATED_BY, UPDATED_AT));
        QueryExecutor executor;
        try {
            executor = new QueryBuilder().getQueryExecutor();
            executor.queryBuilder().insert().upsertWithKeyList(OBJECT_EXPLORER_RECENT, insertList, true, updateColumns,
                    "user_id", "row_number");
        } catch (QueryException e) {
            LOGGER.error("Error in update recent" + e);
        }
    }

    /**
     * filters application by id.
     *
     * @param recentIdList the recent id list
     * @return the list
     */
    @Override
    public List<Map<String, Object>> filterApplicationById(List<String> recentIdList) {
        QueryBuilder queryBuilder = new QueryBuilder();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select()
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);

            subQueryBuilder = new QueryBuilder().select().get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").checkIndependentTenant(true).build(true);
            return queryBuilder.select().get("program_id").get("product_code").get("program_type")
                    .get("sub_product_code").get("program_name").get("change_request_id").get("api_type")
                    .get("release_status").get(CREATED_AT).get(CREATED_BY).get("current_version").get("major_version")
                    .get(UPDATED_AT).get(UPDATED_BY).from(PROGRAM_DETAIL).checkIndependentTenant(true)
                    .where(ConditionBuilder.instance().in("program_id", recentIdList.toArray()).and()
                            .in("product_code", subQueryBuilder).and().notEq("delete_flag", true))
                    .build(false).execute();
        } catch (QueryException e) {
            LOGGER.error("Error in select recent" + e);
        }
        return new ArrayList<>();
    }

    /**
     * filters table by id.
     *
     * @param recentIdList the recent id list
     * @return the list
     */
    @Override
    public List<Map<String, Object>> filterTableById(List<String> recentIdList) {
        QueryBuilder queryBuilder = new QueryBuilder();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select()
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);

            subQueryBuilder = new QueryBuilder().select().get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").checkIndependentTenant(true).build(true);
            return queryBuilder.select().get("table_name").get("product_code").get("table_description")
                    .get("sub_product_code").get("active_status").get("delete_flag").get("status").get(CREATED_AT)
                    .get(CREATED_BY).get(UPDATED_AT).get(UPDATED_BY).from(TABLE_DEFINITION).checkIndependentTenant(true)
                    .where(ConditionBuilder.instance().in("table_name", recentIdList.toArray()).and().in("product_code",
                            subQueryBuilder))
                    .build(false).execute();
        } catch (QueryException e) {
            LOGGER.error("Error in select recent" + e);
        }
        return new ArrayList<>();
    }

    /**
     * Filter view by id.
     *
     * @param recentIdList the recent id list
     * @return the list
     */
    @Override
    public List<Map<String, Object>> filterViewById(List<String> recentIdList) {
        QueryBuilder queryBuilder = new QueryBuilder();
        SelectQueryBuilder subQueryBuilder;
        SelectQueryBuilder subQueryBuilder1;
        try {
            subQueryBuilder1 = new QueryBuilder().select()
                    .get(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.roleId"))
                    .where(ConditionBuilder.instance().eq(QueryUtils.toJoinDoubleQuotedString("roleLinkSetting.userId"),
                            ContextBean.getUserId()))
                    .from("redis_tenant_role_link_setting_view").checkIndependentTenant(true).build(true);

            subQueryBuilder = new QueryBuilder().select().get("productAuthority.product_code")
                    .where(ConditionBuilder.instance().in("role_id", subQueryBuilder1))
                    .from("product_code_authority_view","productAuthority").checkIndependentTenant(true).build(true);
            return queryBuilder
                    .select().get("view_object_name").get("product_code").get("description").get("main_table")
                    .get("change_request_id").get("status_flag").get("delete_flag").get("source_status")
                    .get("version_no").get(CREATED_AT).get(CREATED_BY).get(UPDATED_AT).get(UPDATED_BY)
                    .from(VIEW_OBJECT_DEFINITION).checkIndependentTenant(true).where(ConditionBuilder.instance()
                            .in("view_object_name", recentIdList.toArray()).and().in("product_code", subQueryBuilder))
                    .build(false).execute();
        } catch (QueryException e) {
            LOGGER.error("Error in select recent" + e);
        }
        return new ArrayList<>();
    }

    /**
     * Sets the fetch limit.
     *
     * @param value the new fetch limit
     */
    @Override
    public void setFetchLimit(int value) {
        this.FETCH_LIMIT = value;

    }

}