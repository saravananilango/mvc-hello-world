package com.nn.sova.service.menu;

import java.util.Map;

/**
 * NotificationService class is used to access notification table information.
 *
 * @author Devaraj G
 */
public interface NotificationService {
	public Map<String, Object> getNotification(Map<String, Object> dataMap) throws Exception;

	public void setAllRead(Map<String, Object> dataMap) throws Exception;

	public void setReadByFeedId(Map<String, Object> dataMap) throws Exception;
}
