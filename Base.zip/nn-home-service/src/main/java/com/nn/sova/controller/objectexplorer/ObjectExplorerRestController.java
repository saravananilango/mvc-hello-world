package com.nn.sova.controller.objectexplorer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.controller.ApplicationController;
import com.nn.sova.service.controller.iniStorage.IniStorageController;
//import com.nn.sova.service.controller.iniStorage.IniStorageController;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.objectexplorer.ObjectExplorerService;
import com.nn.sova.service.objectexplorer.ObjectExplorerServiceImpl;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.service.utils.table.TableValidationUtils;
import com.nn.sova.utility.cache.CacheGetServiceImpl;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.CustomException;

/**
 * The Class ObjectExplorerRestController.
 */
@SovaMapping("/object")
/**
 * 
 * @author balajimu
 * 
 *         ObjectExplorerRestController rest controller for object Explorer
 *         screen
 *
 */
public class ObjectExplorerRestController extends ApplicationController {

    /** The ObjectExplorerService */
    private final ObjectExplorerService objectExplorerService;

    /**
     * ObjectExplorerRestController constructor.
     */
    public ObjectExplorerRestController() {
        objectExplorerService = new ObjectExplorerServiceImpl();
    }

    /**
     * Method to retreive object data..
     *
     * @param paramMap the param map
     * @param request  the request
     * @return the list
     * @throws IOException    Signals that an I/O exception has occurred.
     * @throws QueryException the query exception
     */
    @SovaMapping(value = "/explore", method = SovaRequestMethod.POST)
    public void explore(SovaHttpRequest request, SovaHttpResponse response)
            throws IOException, QueryException {
    	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        List<FrontVo> paramList = new ArrayList<>();
        paramMap.put("userName", "sova");
        FrontVo inboxData = new FrontVo();
        inboxData.setId("inboxData");
        inboxData.setParams(objectExplorerService.getObjects(paramMap));
        paramList.add(inboxData);
        response.withBody(showViewPage(request, paramList));
    }

    /**
     * Method to retreive object data..
     *
     * @param paramMap the param map
     * @return the data
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/getData", method = SovaRequestMethod.POST)
    public void getData(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
    	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, String> userMap = new HashMap<>();
        Map<String, Object> responseMap = new HashMap<>();
        userMap.put("name", UserContext.getInstance().getUserName());
        userMap.put("domain", UserContext.getInstance().getUserProfile().getName());
        responseMap.put("user", userMap);
        responseMap.put("inbox", objectExplorerService.getObjects(paramMap));

        response.withBody(responseMap);
    }

    /**
     * facetChange method is to filter the inbox on conditions.
     *
     * @param dataMap the data map
     * @return finalMap
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/facetChange", method = SovaRequestMethod.POST)
    private void facetChange(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
        new HashMap<String, Object>();
        Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        var listOfComponents = new ArrayList<Map<String, Object>>();
        var componentIdMap = new HashMap<String, Object>();
        componentIdMap.put("component_id", "nn-object-facet-navigation");
        componentIdMap.put("ini_value", JsonUtils.toJsonOrEmpty(dataMap.get("facetvalue")));
        listOfComponents.add(componentIdMap);
        var iniDataMap = new HashMap<String, Object>();
        iniDataMap.put("ini_data", listOfComponents);
        var inistorage = new IniStorageController();
        try {
            inistorage.insertServiceIniForExplorer(iniDataMap);
        } catch (QueryException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        response.withBody(objectExplorerService.filterObjects(dataMap, false));
    }

    /**
     * loadMore method is to load the data on inbox scroll.
     *
     * @param dataMap the data map
     * @return finalMap
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/loadMore", method = SovaRequestMethod.POST)
    private void loadMore(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
    	Map<String, Object> dataMap = (Map<String, Object>) request.getBody();
        List<Map<String, Object>> dataList = objectExplorerService.loadMoreData(dataMap);
        List<Map<String, Object>> returnList = new ArrayList<>();
        String screenDefId = "ObjectExplorer";

        dataList.stream().forEach(row -> {
            Map<String, Object> rowMap = new HashMap<>();
            List<Map<String, Object>> hoverList = new ArrayList<>();
            Map<String, Object> hoverMap = new HashMap<>();
            hoverMap.put("id", "view-button" + UUID.randomUUID().toString());
            hoverMap.put("icon", "visibility");
            try {
                hoverMap.put("hintLabel", CacheService.getInstance().getApplicationTextDefinitionData(
                        "nn-object-hover-view-hint", screenDefId, ContextBean.getLocale()));
            } catch (QueryException e) {

            }
            hoverList.add(hoverMap);
            if ((Objects.nonNull(row.get("program_id")) && !"automatic".equals(row.get("api_type")))
                    || (Objects.nonNull(row.get("table_name"))
                            && !Boolean.parseBoolean(row.getOrDefault("locked_flag", false).toString()))
                    || Objects.nonNull(row.get("view_object_name"))) {
                hoverMap = new HashMap<>();
                hoverMap.put("id", "edit-button" + UUID.randomUUID().toString());
                hoverMap.put("icon", "edit");
                try {
                    hoverMap.put("hintLabel", CacheService.getInstance().getApplicationTextDefinitionData(
                            "nn-object-hover-edit-hint", screenDefId, ContextBean.getLocale()));
                } catch (QueryException e) {

                }
                hoverList.add(hoverMap);
            }
            hoverMap = new HashMap<>();
            hoverMap.put("id", "copy-button" + UUID.randomUUID().toString());
            hoverMap.put("icon", "content_copy");
            try {
                hoverMap.put("hintLabel", CacheService.getInstance().getApplicationTextDefinitionData(
                        "nn-object-hover-copy-hint", screenDefId, ContextBean.getLocale()));
            } catch (QueryException e) {

            }
            hoverList.add(hoverMap);
            
			if (Objects.nonNull(row.get("deployment_status")) && row.get("deployment_status").toString().equals("SUCCESS")
					&& Objects.nonNull(row.get("program_type")) && row.get("program_type").equals("screen")) {
				hoverMap = new HashMap<>();
				hoverMap.put("id", "deploy-button" + UUID.randomUUID().toString());
				hoverMap.put("icon", "play_arrow");
				try {
					hoverMap.put("hintLabel", CacheService.getInstance().getApplicationTextDefinitionData(
							"nn-object-hover-deploy-hint", screenDefId, ContextBean.getLocale()));
				} catch (QueryException e) {

				}
				hoverList.add(hoverMap);
			}
            
            rowMap.put("objectName",
                    Objects.nonNull(row.get("program_name")) ? row.get("program_name")
                            : Objects.nonNull(row.get("table_name")) ? row.get("table_name")
                                    : row.getOrDefault("view_object_name", ""));

            Map<String, Object> objectNameMap = new HashMap<>();
            Map<String, Object> styleMap = new HashMap<>();
            styleMap.put("backgroundColor", "var(--nn-primary-soft)");
            styleMap.put("color", "var(--nn-theme-info)");
            styleMap.put("fontWeight", "bold");
            objectNameMap.put("label", row.get("product_code"));
            objectNameMap.put("tagRendererStyle", styleMap);
            rowMap.put("product_code", objectNameMap);

            rowMap.put("program_id", Objects.nonNull(row.get("program_id")) ? row.get("program_id")
                    : Objects.nonNull(row.get("table_name")) ? row.get("table_name") : row.get("view_object_name"));

            rowMap.put("updated_at", row.get("updated_at"));

            rowMap.put("product_name", row.get("product_name"));

            // rowMap.put("sub_product_name", row.get("sub_product_name"));

            rowMap.put("sub_product_code", row.getOrDefault("sub_product_code", ""));
            rowMap.put("api_type_name", row.getOrDefault("api_type_name", ""));
            rowMap.put("api_type", row.getOrDefault("api_type", ""));

            rowMap.put("type", Objects.nonNull(row.get("program_type")) ? row.get("program_type")
                    : Objects.nonNull(row.get("table_name")) ? "table" : "view");
            
            rowMap.put("deploymentStatus", Objects.nonNull(row.get("deployment_status")) ? row.get("deployment_status")
                    : StringUtils.EMPTY);
            rowMap.put("deployedURL", Objects.nonNull(row.get("deployed_url")) ? row.get("deployed_url")
                    : StringUtils.EMPTY);
            rowMap.put("programData", Objects.nonNull(row.get("program_data")) ? row.get("program_data")
                    : new HashMap<String, Object>());

            objectNameMap = new HashMap<>();
            objectNameMap.put("label", Objects.nonNull(row.get("combined_version")) ? row.get("combined_version")
                    : Objects.nonNull(row.get("major_version")) ? row.get("major_version")
                            : Objects.nonNull(row.get("version_no")) ? row.get("version_no") : StringUtils.EMPTY);
            objectNameMap.put("tagRendererStyle", Collections.singletonMap("color", "var(--nn-text-sub-color)"));
            rowMap.put("major_version", objectNameMap);

            objectNameMap = new HashMap<>();
            Map<String, Object> rendererMap = new HashMap<>();
            Boolean statusFlag = (Boolean) row.getOrDefault("active_status_flag", false);
            rendererMap.put("color", statusFlag ? "var(--nn-warning-lighter)" : "var(--nn-text-disabled)");
            rendererMap.put("fontSize", "var(--nn-icon-large)");
            objectNameMap.put("icon", statusFlag ? "nn_active" : "nn_inactive");
            objectNameMap.put("iconTitle", row.get("active_status"));
            objectNameMap.put("iconRendererStyle", rendererMap);
            rowMap.put("active_status", objectNameMap);

            rowMap.put("hoverButton", hoverList);
            rowMap.put("params", new ArrayList<>());
            returnList.add(rowMap);
        });

        response.withBody(returnList);
    }

    /**
     * Method to update recent search data.
     *
     * @param paramMap the param map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/update", method = SovaRequestMethod.POST)
    public void updateRecentSearch(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
    	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        objectExplorerService.updateRecent(paramMap);
    }

    /**
     * Method to get recent search data.
     *
     * @param paramMap the param map
     * @return the recent search
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/recent", method = SovaRequestMethod.POST)
    public void getRecentSearch(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
    	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        Map<String, Object> responseMap = new HashMap<>();
        paramMap.put("name", UserContext.getInstance().getUserName());
        responseMap.put("inbox", objectExplorerService.getRecent(paramMap));
        response.withBody(responseMap);
    }

    /**
     * index method for initial screen load.
     *
     * @param paramMap the param map
     * @param request  the request
     * @throws QueryException  the query exception
     * @throws CustomException the custom exception
     * @throws IOException     Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/index", method = SovaRequestMethod.POST)
    public void index(SovaHttpRequest request, SovaHttpResponse response)
            throws QueryException, CustomException, IOException {
    	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
        List<FrontVo> returnList = new ArrayList<>();
        Map<String, String> userMap = new HashMap<>();
        new HashMap<>();
        addData("tableAccessing",
                Objects.isNull((CacheGetServiceImpl.getInstance().getConfigurationProperty().get("save_restrict")))
                        ? false
                        : (boolean) (CacheGetServiceImpl.getInstance().getConfigurationProperty().get("save_restrict")),
                returnList);
//        userMap.put("name", ContextBean.getUserId());
//        paramMap.put("userName", userMap.get("name"));

        var iniStorage = new IniStorageController();
        var iniRequestMap = new HashMap<String, Object>();
        iniRequestMap.put("component_id", "nn-object-facet-navigation");
        var responseData = iniStorage.getIniStorageForExplorer(iniRequestMap);
        	
        var facetMap = new HashMap<String, Object>();
        String[] checkValues = {"screen","api","rule","batch","library","table","view","report"};
        var checkboxValue = Arrays.asList(checkValues);
//        checkboxValue.add("screen");
        facetMap.put("nn-object-type-checkbox-group", checkboxValue);
        Map<String, Object> iniDataMap = null;
        if (!responseData.isEmpty()) {

            iniDataMap = JsonUtils.fromJsonOrEmptyMap(String.valueOf(responseData.get(0).get("ini_value")),
                    new TypeReference<Map<String, Object>>() {
                    });
        }

		if (iniDataMap == null) {
			userMap.put("name", ContextBean.getUserId());
			facetMap.put("nn-object-user-master-input", userMap.get("name"));
			paramMap.put("facetvalue", facetMap);
		} else {
			if (iniDataMap.containsKey("nn-object-user-master-input")) {
				userMap.put("name", iniDataMap.get("nn-object-user-master-input").toString());
			} else {
				userMap.put("name", ContextBean.getUserId());
			}
			iniDataMap.put("nn-object-user-master-input", userMap.get("name"));
			paramMap.put("facetvalue", iniDataMap);
//            addAttribute("nn-object-type-checkbox-group", "value", iniDataMap.get("nn-object-type-checkbox-group"),
//                    returnList);
		}
		paramMap.put("userName", userMap.get("name"));
        addData("nn-object-facet-navigation", iniDataMap, returnList);
        addData("data", objectExplorerService.filterObjects(paramMap, true), returnList);
        addData("user", userMap, returnList);
        addData("customerCode",EnvironmentReader.getCustomerCode(), returnList);
        var paramList = new ArrayList<Object>();
        if (iniDataMap != null) {
            paramList.add(iniDataMap.get("nn-object-type-checkbox-group"));
//            addMethod("nn-object-facet-navigation", "setCheckedByValues", paramList, returnList);
        }
        addAttribute("nn-object-facet-navigation", "facetClearIcon", true, returnList);
        Map<String, Object> userInputMap = new HashMap<>();
        userInputMap.put("value", userMap.get("name"));
        userInputMap.put("keyText", userMap.get("name"));
        userInputMap.put("disabled", false);
        addMultipleAttribute("nn-object-user-master-input", userInputMap, returnList);
        userInputMap = new HashMap<>();
        userInputMap.put("value", false);
        userInputMap.put("display", false);
        addMultipleAttribute("nn-object-only-me-switch-input", userInputMap, returnList);
        response.withBody(showViewPage(request, returnList));
    }

    /**
     * returns screend defination id.
     *
     * @return the screen definition id
     */
    @Override
    public String getScreenDefinitionId() {
        return "ObjectExplorer";
    }

    /**
     * Method to update recent search data.
     *
     * @param paramMap the param map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SovaMapping(value = "/isTableEditable", method = SovaRequestMethod.POST)
    public void isTableEditable(SovaHttpRequest request, SovaHttpResponse response) throws IOException {
    	Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
    	response.withBody(TableValidationUtils.checkOwnerandInprogressValidation(paramMap));
    }
}