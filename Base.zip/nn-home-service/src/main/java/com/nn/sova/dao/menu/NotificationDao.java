package com.nn.sova.dao.menu;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * NotificationDaoImpl class is used to access notification table information.
 *
 * @author Devaraj G
 */
public interface NotificationDao {

	public List<Map<String, Object>> getNotification(Map<String, Object> dataMap) throws Exception;

	public void setAllRead(Map<String, Object> dataMap) throws Exception;

	public void setReadByFeedId(Map<String, Object> dataMap) throws Exception;
}
