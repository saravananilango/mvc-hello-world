package com.nn.sova.service.menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.nn.sova.dao.menu.NotificationDao;
import com.nn.sova.dao.menu.NotificationDaoImpl;

/**
 * NotificationService class is used to access notification table information.
 *
 * @author Devaraj G
 */
public class NotificationServiceImpl implements NotificationService {

	private static final NotificationDao notificationDao = new NotificationDaoImpl();

	@Override
	public Map<String, Object> getNotification(Map<String, Object> dataMap) throws Exception {
		// TODO Auto-generated method stub
		List<Map<String, Object>> resultList = notificationDao.getNotification(dataMap);
		List<Map<String, Object>> finalList = new ArrayList<>();
		resultList.stream().forEach(action -> {
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put("feedId", action.getOrDefault("feed_id", StringUtils.EMPTY));
			resultMap.put("imageUrl", action.getOrDefault("feed_id", StringUtils.EMPTY));
			resultMap.put("firstName", action.getOrDefault("notification_name", StringUtils.EMPTY));
			resultMap.put("notificationTitle", action.getOrDefault("data", StringUtils.EMPTY));
			resultMap.put("targetUrl", action.getOrDefault("target_url", StringUtils.EMPTY));
			finalList.add(resultMap);
		});
		dataMap.put("notificationList", finalList);
		return dataMap;

	}

	@Override
	public void setAllRead(Map<String, Object> dataMap) throws Exception {
		// TODO Auto-generated method stub
		notificationDao.setAllRead(dataMap);

	}

	@Override
	public void setReadByFeedId(Map<String, Object> dataMap) throws Exception {
		// TODO Auto-generated method stub
		notificationDao.setReadByFeedId(dataMap);

	}

}
