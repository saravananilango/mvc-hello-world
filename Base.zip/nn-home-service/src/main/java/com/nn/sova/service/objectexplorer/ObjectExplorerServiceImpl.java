package com.nn.sova.service.objectexplorer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.nn.sova.dao.objectexplorer.ObjectExplorerDao;
import com.nn.sova.dao.objectexplorer.ObjectExplorerDaoImpl;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * object Explorer service implementation.
 *
 * @author balajimu
 */
public class ObjectExplorerServiceImpl implements ObjectExplorerService {

    /** The Constant LOGGER. */
    private static ApplicationLogger LOGGER = ApplicationLogger.create(ObjectExplorerServiceImpl.class);

    private static ObjectExplorerDao objectExplorerDao;

    /**
     * Instantiates a new object explorer service impl.
     */
    public ObjectExplorerServiceImpl() {
        objectExplorerDao = new ObjectExplorerDaoImpl();
    }

    /**
     * returns Objects.
     *
     * @param paramMap the param map
     * @return the objects
     */
    @Override
    public Map<String, Object> getObjects(Map<String, Object> paramMap) {
        Map<String, Object> objectMap = new HashMap<>();
        LOGGER.info("Load Objects.");
        List<String> applicationList = Arrays.asList("screen", "api", "library", "rule", "batch");
        Map<String, Object> textMap = getText();
        try {

            objectMap = objectExplorerDao.getApplicationsData(paramMap, applicationList);

        } catch (QueryException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        for (String applicationType : applicationList) {
            Map<String, Object> dataMap = (Map<String, Object>) objectMap.get(applicationType);
            getLangData(textMap, dataMap);

        }
        Map<String, Object> dataMap = objectExplorerDao.getViewObject(paramMap);
        getLangData(textMap, dataMap);
        objectMap.put("view", dataMap);
        dataMap = objectExplorerDao.getTableObject(paramMap);
        getLangData(textMap, dataMap);
        objectMap.put("table", dataMap);
        LOGGER.info("Load Objects Finished.");

        return objectMap;
    }

    /**
     * returns language data.
     *
     * @param textMap the text map
     * @param dataMap the data map
     * @return the lang data
     */
    private void getLangData(Map<String, Object> textMap, Map<String, Object> dataMap) {
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) dataMap.get("data");
        dataList.forEach(action -> {
            if (Objects.nonNull(action.get("api_type"))) {
                String textId = "automatic".equals(action.get("api_type").toString())
                        ? "nn_object_program_api_type_automatic"
                        : "nn_object_program_api_type_manual";
                action.put("api_type_name", textMap.get(textId));
            }
            Boolean statusFlag = false;
            String status = StringUtils.EMPTY;
            if ((Objects.nonNull(action.get("table_name"))
                    && Boolean.parseBoolean(action.getOrDefault("online", false).toString()))) {
                if (Objects.nonNull(action.get("status"))) {
                    status = (String) action.get("status");
                } else {
                    status = "released";
                }

            } else if (Objects.nonNull(action.get("view_object_name")) && Objects.nonNull(action.get("status_flag"))
                    && Boolean.parseBoolean(action.getOrDefault("status_flag", false).toString())
                    && Objects.nonNull(action.get("source_status"))) {
                status = (String) action.get("source_status");
            } else if (Objects.nonNull(action.get("program_name")) && Objects.nonNull(action.get("release_status"))) {
                status = action.get("release_status").toString();
            }else if (Objects.nonNull(action.get("program_name")) && Objects.nonNull(action.get("report_active"))) {
            	statusFlag = Boolean.valueOf(action.get("report_active").toString());
            }
            switch (status.toLowerCase()) {
            case "success":
            case "released":
            case "delivered":
                statusFlag = true;
                break;
            default:
                break;
            }

            action.put("active_status",
                    statusFlag ? textMap.get("nn_object_active_status") : textMap.get("nn_object_in_active_status"));
            action.put("active_status_flag", statusFlag);

        });
        dataMap.put("data", dataList);
    }

    /**
     * filterObjects is the main method which perform facet change event, portal
     * search and sorting function.
     *
     * @param paramMap  the param map
     * @param fromIndex the from index
     * @return Map
     */
    @SuppressWarnings("unchecked")
    @Override
    public Map<String, Object> filterObjects(Map<String, Object> paramMap, boolean fromIndex) {
        Map<String, Object> returnMap;
        Map<String, Object> textMap = getText();
        Map<String, Object> factevalue = paramMap.containsKey("facetvalue")
                ? (Map<String, Object>) paramMap.get("facetvalue")
                : null;
        List<String> searchList = new ArrayList<String>();
        List<String> applicationTypeSelected = null;

        if (factevalue != null && factevalue.containsKey("nn-object-type-checkbox-group")) {
            applicationTypeSelected = (List<String>) factevalue.get("nn-object-type-checkbox-group");
        }
        
		if (fromIndex && applicationTypeSelected.size() == 1) {
			objectExplorerDao.setFetchLimit(20);
		} else if(fromIndex) {
			objectExplorerDao.setFetchLimit(4);
		}

        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("screen")) {
//            returnMap.put("screen",
//                    highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "screen")));
            searchList.add("screen");
        }
        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("api")) {
//            returnMap.put("api", highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "api")));
            searchList.add("api");
        }
        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("rule")) {
//            returnMap.put("rule", highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "rule")));
            searchList.add("rule");
        }
        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("batch")) {
//            returnMap.put("batch",
//                    highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "batch")));
            searchList.add("batch");
        }
        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("library")) {
//            returnMap.put("library",
//                    highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "library")));
            searchList.add("library");
        }

        returnMap = objectExplorerDao.filterApplications(paramMap, searchList);
        searchList.stream().forEach(action -> {
            returnMap.put(action, highlightSearchData(textMap, (Map<String, Object>) returnMap.get(action)));
        });

        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("table")) {
            returnMap.put("table", highlightSearchData(textMap, objectExplorerDao.filterTable(paramMap)));
        }
        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("view")) {
            returnMap.put("view", highlightSearchData(textMap, objectExplorerDao.filterView(paramMap)));
        }
        if (CollectionUtils.isEmpty(applicationTypeSelected) || applicationTypeSelected.contains("report")) {
            returnMap.put("report", highlightSearchData(textMap, objectExplorerDao.getReportData(paramMap)));
        }
        objectExplorerDao.setFetchLimit(20);
        return returnMap;
    }

    /**
     * To highlight search data.
     *
     * @param textMap       the text map
     * @param filterDataMap the filter data map
     * @return the map
     */
    private Map<String, Object> highlightSearchData(Map<String, Object> textMap, Map<String, Object> filterDataMap) {
//		if (Objects.nonNull(paramMap.get("searchData")) 
//				&& org.apache.commons.lang.StringUtils.isNotEmpty(paramMap.getOrDefault("searchData","").toString())) {
//			List<Map<String, Object>> highLightedList = HighLightUtils.highlightContent(paramMap.get("searchData").toString(),
//					Arrays.asList("product_name"), (List<Map<String, Object>>)filterDataMap.get("data"));
//			filterDataMap.put("data", highLightedList);

//		}
        getLangData(textMap, filterDataMap);
        return filterDataMap;
    }

    /**
     * To load more data.
     *
     * @param paramMap the param map
     * @return the list
     */
    @Override
    public List<Map<String, Object>> loadMoreData(Map<String, Object> paramMap) {
        List<Map<String, Object>> returnList = new ArrayList<>();
        final Map<String, Object> returnMap = new HashMap<>();
        String type = (String) paramMap.get("type");
        Map<String, Object> textMap = getText();
        paramMap.get("nn-object-type-checkbox-group");

        List<String> searchList = new ArrayList<String>();
        if ("screen".equals(type)) {
//            returnMap = highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "screen"));
            searchList.add("screen");
        }
        if ("api".equals(type)) {
//            returnMap = highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "api"));
            searchList.add("api");
        }
        if ("library".equals(type)) {
//            returnMap = highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "library"));
            searchList.add("library");
        }
        if ("rule".equals(type)) {
//            returnMap = highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "rule"));
            searchList.add("rule");
        }
        if ("batch".equals(type)) {
//            returnMap = highlightSearchData(textMap, objectExplorerDao.filterApplication(paramMap, "batch"));
            searchList.add("batch");
        }
//        objectExplorerDao.filterApplications(paramMap, searchList);
        returnMap.putAll(objectExplorerDao.filterApplications(paramMap, searchList));
        searchList.stream().forEach(action -> {
            returnMap.put(action, highlightSearchData(textMap, (Map<String, Object>) returnMap.get(action)));
        });

        if ("table".equals(type)) {
        	searchList.add("table");
            returnMap.put("table",highlightSearchData(textMap, objectExplorerDao.filterTable(paramMap)));
        }
        if ("view".equals(type)) {
        	searchList.add("view");
            returnMap.put("view",highlightSearchData(textMap, objectExplorerDao.filterView(paramMap)));
        }
        if ("report".equals(type)) {
        	searchList.add("report");
            returnMap.put("report",highlightSearchData(textMap, objectExplorerDao.getReportData(paramMap)));
        }
        if (searchList.size() > 0 && returnMap.containsKey(searchList.get(0))) {

            if (Objects.nonNull(((Map<String, Object>) returnMap.get(searchList.get(0))).get("data"))) {
                returnList = (List<Map<String, Object>>) ((Map<String, Object>) returnMap.get(searchList.get(0)))
                        .get("data");
            }
        }
        return returnList;
    }

    /**
     * returns recent data.
     *
     * @param paramMap the param map
     * @return the recent
     */
    @Override
    public Map<String, Object> getRecent(Map<String, Object> paramMap) {
        Map<String, Object> returnMap = new HashMap<>();
        List<Map<String, Object>> recentList = objectExplorerDao.selectRecent(paramMap);
        List<String> screenIdList = new ArrayList<>();
        List<String> tableIdList = new ArrayList<>();
        List<String> viewIdList = new ArrayList<>();
        recentList.forEach(action -> {
            if (Arrays.asList("screen", "api", "rule", "batch", "library").contains(action.get("nn-object_type"))) {
                screenIdList.add(action.get("object_id").toString());
            }
            if ("table".equals(action.get("nn-object_type"))) {
                tableIdList.add(action.get("object_id").toString());
            }
            if ("view".equals(action.get("nn-object_type"))) {
                viewIdList.add(action.get("object_id").toString());
            }
        });

        if (CollectionUtils.isNotEmpty(screenIdList)) {
            recentList.addAll(objectExplorerDao.filterApplicationById(screenIdList));
        }
        if (CollectionUtils.isNotEmpty(screenIdList)) {
            recentList.addAll(objectExplorerDao.filterTableById(tableIdList));
        }
        if (CollectionUtils.isNotEmpty(screenIdList)) {
            recentList.addAll(objectExplorerDao.filterViewById(viewIdList));
        }
        returnMap.put("recent", recentList);
        return returnMap;
    }

    /**
     * Updates recent Data.
     *
     * @param paramMap the param map
     */
    @Override
    public void updateRecent(Map<String, Object> paramMap) {
        String userId = (String) paramMap.get("userName");
        List<Map<String, Object>> recentDataList = (List<Map<String, Object>>) paramMap.get("recent");
        List<Map<String, Object>> recentList = objectExplorerDao.selectRecent(paramMap);
        if (recentList.size() == 20) {
            Arrays.copyOfRange(recentList.toArray(), 0, 20 - recentDataList.size());
        }

        AtomicInteger rowNumber = new AtomicInteger(recentList.size());
        recentDataList.forEach(action -> {
            Map<String, Object> insertMap = new HashMap<>();
            insertMap.put("objectExplorerRecentDetail.userId", userId);
            insertMap.put("objectExplorerRecentDetail.rowNumber", rowNumber.get());
            insertMap.put("objectExplorerRecentDetail.objectId", action.getOrDefault("id", ""));
            insertMap.put("objectExplorerRecentDetail.objectType", action.getOrDefault("type", ""));
            recentList.add(insertMap);
            rowNumber.getAndIncrement();
        });

        objectExplorerDao.upsertRecent(recentList);
    }

    /**
     * return application text map.
     *
     * @return the text
     */
    private Map<String, Object> getText() {
        Map<String, Object> textMap = new HashMap<>();
        try {
            textMap = CacheService.getInstance().getApplicationTextDefinitionData("ObjectExplorer");
        } catch (QueryException e) {
        }
        return textMap;
    }
}
