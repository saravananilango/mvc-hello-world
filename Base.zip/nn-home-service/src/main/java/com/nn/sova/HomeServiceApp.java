//package com.nn.sova;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Import;
//
//import com.nn.sova.config.HomeServiceCorsConfig;
//import com.nn.sova.jobmanager.lib.config.JobManagerWebAppConfig;
//import com.nn.sova.service.webapp.WebApplication;
//
//
///**
// * {@link HomeServiceApp} is the entry point of the
// * Custom Desginer service web application
// *
// */
//@Import({
//	HomeServiceCorsConfig.class,
//	JobManagerWebAppConfig.class
//})
//@ComponentScan(basePackages = { "com.nn.sova.controller", "com.nn.sova.jobmanager.lib.controller" })
//public class HomeServiceApp extends WebApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(HomeServiceApp.class, args);
//	}
//
//}
