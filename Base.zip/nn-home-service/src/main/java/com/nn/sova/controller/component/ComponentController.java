package com.nn.sova.controller.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.core.CacheManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.key.CacheKeyHelper;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.annotations.SovaMapping;
import com.nn.sova.service.controller.ApplicationController;
import com.nn.sova.service.controller.iniStorage.IniStorageController;
import com.nn.sova.service.entity.FrontVo;
import com.nn.sova.service.entity.requestresponse.request.SovaHttpRequest;
import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaRequestMethod;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.service.utils.component.ComponentUtils;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * ComponentController handles all the component screen process.
 *
 * @author Vignesh Palanisamy
 */
@SovaMapping("/componentpage")
public class ComponentController extends ApplicationController {

	/** The Constant logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(ComponentController.class);

	/** ComponentUtils componentUtils. */
	ComponentUtils componentUtils = new ComponentUtils();

	/** The Constant SOVA_COMPONENT_LIST_CACHE_KEY. */
	private static final String SOVA_COMPONENT_LIST_CACHE_KEY = "sova_component_list";

	/**
	 * getServiceDefId returns the serviceDefId of the screen.
	 *
	 * @return the screen definition id
	 */
	@Override
	public String getScreenDefinitionId() {
		return "Component";
	}

	/**
	 * component will load component data.
	 *
	 * @param request  the request
	 * @param response the response
	 * @return the object
	 * @throws Exception
	 */
	@SovaMapping(value = "/component", method = SovaRequestMethod.POST)
	public void component(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
		logger.info("Component page start");
		List<FrontVo> paramList = new ArrayList<>();
		Map<Object, List<Map<String, Object>>> returnMap = componentUtils.getComponent();
		List<String> securityObject = ContextBean.getSecurityObject();
		var iniStorage = new IniStorageController();
		var iniRequestMap = new HashMap<String, Object>();
        iniRequestMap.put("ini_key", "template_data");
        var responseData = iniStorage.getIniStorageForExplorer(iniRequestMap);
        if(responseData.isEmpty()) {
        	var iniResponseMap = new HashMap<String, Object>();
        	String[] strAr = {"default"};
            iniRequestMap.put("ini_key", "template_data");
            iniRequestMap.put("ini_object", strAr);
            responseData.add(iniResponseMap);
        }
		if (UserContext.getInstance().getUserProfile().isFullyAuthorized() || 
				(CollectionUtils.isNotEmpty(securityObject) && securityObject.contains("component_admin"))) {
			addAttribute("save-props-button", "display", true, paramList);
			addAttribute("update-db-button", "display", true, paramList);
			addAttribute("generate-css-button", "display", true, paramList);
		} else {
			addAttribute("save-props-button", "display", false, paramList);
			addAttribute("update-db-button", "display", false, paramList);
			addAttribute("generate-css-button", "display", false, paramList);
		}
		if (!returnMap.isEmpty()) {
			addData("componentDetail", returnMap, paramList);
		}
		addData("componentInlineData", componentUtils.getAllInlineDataMap(), paramList);
		addData("template_data", responseData, paramList);
		response.withBody(showViewPage(request, paramList));
	}

	/**
	 * componentInline will load inline component data.
	 *
	 * @param request  the request
	 * @param response the response
	 * @return the object
	 * @throws Exception
	 */
	@SovaMapping(value = "/componentInline", method = SovaRequestMethod.POST)
	public void componentInline(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("componentInline method start");
		response.withBody(componentUtils.getAllInlineDataMap());
	}

	/**
	 * upsertComponentInlineStyleV3 will upsert style property of the component
	 * single save operation called for inserting both styles & props, so this api request not need
	 * @param paramMap
	 * @throws Exception
	 */
	@Deprecated
	@SovaMapping(value = "/upsertComponentInlineStyle", method = SovaRequestMethod.POST)
	public void upsertComponentInlineStyleV3(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("upsertComponentInlineStyle method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("styleDataList");
		response.withBody(componentUtils.upsertComponentInlineStyleV3(updateList));
	}

	/**
	 * upsertInlineStylePropsDataV3 will upsert style props property of the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/upsertInlineStylePropsData", method = SovaRequestMethod.POST)
	public void upsertInlineStylePropsDataV3(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("upsertInlineStylePropsData method start");
		Map<String, Object> returnMap = new HashMap<>();
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> propsDataList = (List<Map<String, Object>>) paramMap.get("propsDataList");
		List<Map<String, Object>> styleDataList = (List<Map<String, Object>>) paramMap.get("styleDataList");
		response.withBody(componentUtils.upsertInlineStylePropsDataV3(propsDataList, styleDataList));
	}

	/**
	 * upsertInlineStyle will upsert style props property of the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/upsertInlineStyle", method = SovaRequestMethod.POST)
	public void upsertInlineStyle(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
		logger.info("upsertInlineStyle method start");
		Map<String, Object> returnMap = new HashMap<>();
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> styleDataList = (List<Map<String, Object>>) paramMap.get("styleDataList");
		List<Map<String, Object>> propsDataList = (List<Map<String, Object>>) paramMap.get("propsDataList");
		returnMap.put("styleStatus", componentUtils.upsertComponentInlineStyleV3(styleDataList));
		response.withBody(returnMap);
	}
	
	/**
	 * upsertTenantThemeDetails will upsert theme details of tenant and product code
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/upsertTenantThemeDetails", method = SovaRequestMethod.POST)
	public void upsertTenantThemeDetails(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("upsertTenantThemeDetails method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("tenantThemeData");
		response.withBody(componentUtils.upsertTenantThemeDetails(updateList));
	}
	
	/**
	 * insertThemeDetails will insert theme details of theme code
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/insertThemeDetails", method = SovaRequestMethod.POST)
	public void insertThemeDetails(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("insertThemeDetails method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("themeData");
		response.withBody(componentUtils.insertThemeDetails(updateList));
	}
	
	/**
	 * upsertThemeDetails will update theme details
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/upsertThemeDetails", method = SovaRequestMethod.POST)
	public void upsertThemeDetails(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("upsertThemeDetails method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("themeData");
		clearCacheForLinkedProducts(String.valueOf(updateList.get(0).get("theme_code")));
		clearTemplateCacheByProduct();
		CacheService.getInstance().removeCacheByKey(CacheKeyHelper.getTenantThemeKey(ContextBean.getTenantId(), String.valueOf(updateList.get(0).get("theme_code"))));
		response.withBody(componentUtils.upsertThemeDetails(updateList));
	}
	
	@SovaMapping(value = "/clearTemplateCacheByUser", method = SovaRequestMethod.POST)
	public void clearTemplateCacheByUser(SovaHttpRequest request, SovaHttpResponse response) {
		logger.info("clearTemplateCacheByUser method start");
		CacheService.getInstance().removeCacheByKey(CacheKeyHelper.getUserThemeKey(ContextBean.getTenantId(), ContextBean.getUserId()+":theme_key"));
	}
	
	/**
	 * insertTemplate will insert template name
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/insertTemplate", method = SovaRequestMethod.POST)
	public void insertTemplate(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("insertTemplate method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> insertList = (List<Map<String, Object>>) paramMap.get("templateData");
		response.withBody(componentUtils.insertTemplate(insertList));
	}
	
	/**
	 * copyTemplate will copy template name
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/copyTemplate", method = SovaRequestMethod.POST)
	public void copyTemplate(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("copyTemplate method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> copyList = (List<Map<String, Object>>) paramMap.get("templateData");
		String newTemplateName = (String) paramMap.get("newTemplateName");
		String existingTemplateName = (String) paramMap.get("existingTemplateName");
		String compName = (String) paramMap.get("component");
		response.withBody(componentUtils.copyTemplate(copyList, compName, newTemplateName ,existingTemplateName));
	}
	
	/**
	 * insertVariants will insert Variant for the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/insertVariants", method = SovaRequestMethod.POST)
	public void insertVariants(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("insertVariants method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> insertList = (List<Map<String, Object>>) paramMap.get("variantData");
		response.withBody(componentUtils.insertVariants(insertList));
	}
	
	/**
	 * copyVariants will copy the existing Variant for the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/copyVariants", method = SovaRequestMethod.POST)
	public void copyVariants(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("copyVariants method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> copyList = (List<Map<String, Object>>) paramMap.get("variantData");
		String compName = (String) paramMap.get("compName");
		String selectedTemplate = (String) paramMap.get("selectedTemplate");
		String existedVariantText = (String) paramMap.get("existedVariantText");
		response.withBody(componentUtils.copyVariants(copyList, compName, selectedTemplate, existedVariantText));
	}
	
	/**
	 * deleteTemplate will delete template name
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/deleteTemplate", method = SovaRequestMethod.POST)
	public void deleteTemplate(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("deleteTemplate method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		String templateName = (String) paramMap.get("templateName");
		response.withBody(componentUtils.deleteTemplate(templateName));
	}
	
	/**
	 * deleteVariant will delete Variant for the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/deleteVariant", method = SovaRequestMethod.POST)
	public void deleteVariant(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("deleteVariant method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		String styleType = (String) paramMap.get("styleType");
		String templateType = (String) paramMap.get("templateType");
		response.withBody(componentUtils.deleteVariant(styleType, templateType));
	}
	
	/**
	 * makeDefaultVariant will make Variant as default for the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/makeDefaultVariant", method = SovaRequestMethod.POST)
	public void makeDefaultVariant(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("makeDefaultVariant method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("variantData");
		response.withBody(componentUtils.makeDefaultVariant(updateList));
	}
	
	/**
	 * removeDefaultVariant will remove Variant as default for the component
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/removeDefaultVariant", method = SovaRequestMethod.POST)
	public void removeDefaultVariant(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("removeDefaultVariant method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("variantData");
		response.withBody(componentUtils.removeDefaultVariant(updateList));
	}

	/**
	 * resetCache is reset cache for component page
	 * 
	 * @throws Exception
	 */
	@SovaMapping(value = "resetCache", method = SovaRequestMethod.POST)
	public void resetCache(SovaHttpResponse response) throws Exception {
		logger.info("resetCache method start");
		Boolean result = componentUtils.clearCache();
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("status", result);
		response.withBody(returnMap);
	}
	
	/**
	 * editTemplate will edit template name
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/editTemplate", method = SovaRequestMethod.POST)
	public void editTemplate(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("editTemplate method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("templateData");
		response.withBody(componentUtils.updateTemplate(updateList));
	}
	
	/**
	 * editTemplate will edit template name
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/editVariant", method = SovaRequestMethod.POST)
	public void editVariant(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("editVariant method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		List<Map<String, Object>> updateList = (List<Map<String, Object>>) paramMap.get("variantData");
		response.withBody(componentUtils.updateVariant(updateList));
	}
	
	/**
	 * Check whether the template name already exist .
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/validateTemplateName", method = SovaRequestMethod.POST)
	public void validateTemplateName(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("validateTemplateName method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		String templateName = paramMap.get("templateName").toString();
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("isTemplateExist", componentUtils.validateIsTemplateExist(templateName));
		response.withBody(returnMap);
	}
	
	/**
	 * Check whether the theme name already exist .
	 * 
	 * @param paramMap
	 * @throws Exception
	 */
	@SovaMapping(value = "/validateThemeName", method = SovaRequestMethod.POST)
	public void validateThemeName(SovaHttpRequest request, SovaHttpResponse response)
			throws Exception {
		logger.info("validateThemeName method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		String themeName = paramMap.get("themeName").toString();
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("isThemeExist", componentUtils.validateIsThemeExist(themeName));
		response.withBody(returnMap);
	}
	
	
	
	/**
	 * clearCacheForLinkedProducts method used to clear template cache key for product 
	 */
	private void clearTemplateCacheByProduct() {
		CacheManager cacheManager = CacheManager.getInstance();
		Set<String> cacheKeyResultSet = cacheManager.findRedisKeys("theme_key");
		CacheService cacheService = CacheService.getInstance();
		cacheKeyResultSet.parallelStream().forEach(cacheService :: removeCacheByKey);
	}
	
	/**
	 * clearCacheForLinkedProducts method used to clear template cache key linked with products 
	 * 
	 * @param themeCode
	 */
	private void clearCacheForLinkedProducts(String themeCode) {
		try {
			List<Map<String, Object>> dataList = new QueryBuilder().select().get("product_code")
					.from("theme_tenant_product_link").where(ConditionBuilder.instance().eq("tenant_id", ContextBean.getTenantId()).and()
							.eq("theme_code", themeCode)).skipTenantId(true).build(false).execute();
			if (CollectionUtils.isNotEmpty(dataList)) {
				CacheService cacheService = CacheService.getInstance();
				dataList.stream().forEach(action-> 
					cacheService.removeCacheByKey(CacheKeyHelper.getUserThemeKey(ContextBean.getTenantId(), String.valueOf(action.get("product_code")))));
			}
		} catch (QueryException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * defaultThemeForTenant method used to map default theme for tenant
	 * 
	 * @param themeCode
	 * @throws Exception 
	 */
	@SovaMapping(value = "/defaultThemeForTenant", method = SovaRequestMethod.POST)
	public void defaultThemeForTenant(SovaHttpRequest request, SovaHttpResponse response) throws Exception {
		logger.info("defaultThemeForTenant method start");
		Map<String, Object> paramMap = (Map<String, Object>) request.getBody();
		String themeName = paramMap.get("default_theme").toString();
		response.withBody(componentUtils.defaultThemeForTenant(themeName));
	}
}
