package com.nn.sova.dao.menu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang.StringUtils;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * NotificationDaoImpl class is used to access notification table information.
 *
 * @author Devaraj G
 */
public class NotificationDaoImpl implements NotificationDao {

	@Override
	public List<Map<String, Object>> getNotification(Map<String, Object> dataMap) throws Exception {
		// TODO Auto-generated method stub
		QueryBuilder queryBuilder = new QueryBuilder();
		ConditionBuilder condition = ConditionBuilder.instance();
		condition.eq("user_id", dataMap.getOrDefault("userId", StringUtils.EMPTY)).and()
				.eq("service_id", dataMap.getOrDefault("serviceId", StringUtils.EMPTY)).and().eq("read", false);
		return queryBuilder.btSchema().select().from("notification").where(condition).build(false).execute();

	}

	@Override
	public void setAllRead(Map<String, Object> dataMap) throws Exception {
		// TODO Auto-generated method stub
		QueryBuilder queryBuilder = new QueryBuilder();
		ConditionBuilder condition = ConditionBuilder.instance();
		condition.eq("user_id", dataMap.getOrDefault("userId", StringUtils.EMPTY)).and().eq("service_id",
				dataMap.getOrDefault("serviceId", StringUtils.EMPTY));
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("notification.user_id", dataMap.getOrDefault("userId", StringUtils.EMPTY));
		resultMap.put("notification.service_id", dataMap.getOrDefault("serviceId", StringUtils.EMPTY));
		resultMap.put("notification.read", true);
		List<Map<String, Object>> dataList = new ArrayList();
		dataList.add(resultMap);
		// queryBuilder.btSchema().update().updateWithMap("notification",
		// dataMap,condition);
		queryBuilder.insert().isMaster(true).upsertWithKeyList("notification", dataList, true,
				Arrays.asList("user_id", "service_id", "read"), "user_id");

	}

	@Override
	public void setReadByFeedId(Map<String, Object> dataMap) throws Exception {
		// TODO Auto-generated method stub
		QueryBuilder queryBuilder = new QueryBuilder();
		ConditionBuilder condition = ConditionBuilder.instance();
		condition.eq("user_id", dataMap.getOrDefault("userId", StringUtils.EMPTY)).and().eq("service_id",
				dataMap.getOrDefault("serviceId", StringUtils.EMPTY));
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("notification.user_id", dataMap.getOrDefault("userId", StringUtils.EMPTY));
		resultMap.put("notification.service_id", dataMap.getOrDefault("serviceId", StringUtils.EMPTY));
		resultMap.put("notification.feed_id", dataMap.getOrDefault("feedId", StringUtils.EMPTY));
		resultMap.put("notification.read", true);
		List<Map<String, Object>> dataList = new ArrayList();
		dataList.add(resultMap);
		// queryBuilder.btSchema().update().updateWithMap("notification",
		// dataMap,condition);
		queryBuilder.insert().isMaster(true).upsertWithKeyList("notification", dataList, true,
				Arrays.asList("user_id", "service_id", "read", "feed_id"), "user_id");

	}

}
