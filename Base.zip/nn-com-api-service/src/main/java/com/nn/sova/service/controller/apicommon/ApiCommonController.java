package com.nn.sova.service.controller.apicommon;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.service.apicommon.ApiCommonService;
import com.nn.sova.service.service.apicommon.ApiCommonServiceImpl;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * ApiCommonController class is common extends class for all API.
 * @author Johnpeter Jesu
 *
 */
 
public class ApiCommonController {
	/** The Constant apiCommonService **/
	private ApiCommonService apiCommonService;
	/** The Constant LOGGER **/
	private static ApplicationLogger LOGGER = ApplicationLogger.create(ApiCommonController.class);
	
	/**
	 * ApiCommonController constructor
	 */
	public ApiCommonController() {
		apiCommonService = new ApiCommonServiceImpl();
	}

	/**
	 * getAccessibleVersion method is to get access version data.
	 * @param request
	 * @param url
	 * @return
	 * @throws QueryException
	 */
	public String getAccessibleVersion(HttpServletRequest request, String url) {
		Map<String, String> headerMap = getHeadersInfo(request);
		String majorVersion = headerMap.getOrDefault("X-Sova-Major", headerMap.get("x-sova-major"));
		String minorVersion = headerMap.getOrDefault("X-Sova-Minor", headerMap.get("x-sova-minor"));
		String accessibleVersion = "";
		try {
			accessibleVersion = getAccessibleVersion(majorVersion, minorVersion, url);
		} catch (QueryException queryException) {
			LOGGER.error("Error occured while fetching accessible version. " + queryException);
		}
		return accessibleVersion;
	}
	/**
	 * getAccessibleVersion method is to get version data.
	 * @param majorVersion
	 * @param minorVersion
	 * @param url
	 * @return
	 * @throws QueryException
	 */
	private String getAccessibleVersion(String majorVersion, String minorVersion, String url) throws QueryException {
		return apiCommonService.getAccessibleVersion(majorVersion, minorVersion,url);
	}

	/**
	 * getHeadersInfo method is used to get the header value 
	 * @param paramMap
	 * @return
	 */
	private Map<String, String> getHeadersInfo(HttpServletRequest request) {
        Map<String, String> map = new HashMap<String, String>();
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.put(key, value);
        }
        return map;
    }

}
