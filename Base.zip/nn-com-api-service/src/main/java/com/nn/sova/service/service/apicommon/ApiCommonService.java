package com.nn.sova.service.service.apicommon;

import com.nn.sova.exception.QueryException;

/**
 * ApiCommonService class is to do service operations of API common controller
 * @author Johnpeter Jesu
 *
 */
public interface ApiCommonService {

	
	/**
	 * getAccessibleVersion method is used to get the version 
	 * @param paramMap
	 * @return
	 */
	public String getAccessibleVersion(String majorVersion, String minorVersion, String url) throws QueryException;
}
