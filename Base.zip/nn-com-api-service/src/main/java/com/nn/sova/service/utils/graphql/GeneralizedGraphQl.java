package com.nn.sova.service.utils.graphql;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.UUID;

//import org.antlr.v4.runtime.BailErrorStrategy;
//import org.antlr.v4.runtime.CharStream;
//import org.antlr.v4.runtime.CharStreams;
//import org.antlr.v4.runtime.CommonTokenStream;
//import org.antlr.v4.runtime.Token;
//import org.antlr.v4.runtime.atn.PredictionMode;
//import org.antlr.v4.runtime.misc.ParseCancellationException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.utility.json.JsonUtils;

import graphql.GraphQL;
import graphql.Scalars;
import graphql.schema.DataFetcher;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLList;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLOutputType;
import graphql.schema.GraphQLSchema;

/**
 * The Class GeneralizedGraphQl.
 * 
 * Example Implementation
 * 
 * Better to have third parameter to maintain common standard else it will work
 * for any queries first key string
 * 
 * Object responseObject14 = GeneralizedGraphQl.executeGraphQlQuery(
 * ImmutableMap.of("id", "book-1", "name", "Harry Potter and the Philosopher's
 * Stone", "pageCount", "223"), "{testData{id,name}}", "testData");
 * 
 * Object responseObject15 = GeneralizedGraphQl.executeGraphQlQuery(
 * ImmutableMap.of("id", "book-1", "name", "Harry Potter and the Philosopher's
 * Stone", "pageCount", "223"), "{testData{id,name}}");
 */
public class GeneralizedGraphQl {

    /**
     * Execute graph ql query on given data .
     *
     * @param data  the data
     * @param query the query
     * @return the object
     */
    public static Object executeGraphQlQuery(Object data, String query) {
        String newQuery = "";
        if (query == null) {
            return data;
        } else {
            newQuery += "{mainData" + query + "}";
        }
        try {
            var dataObject = executeGraphQlQuery(data, newQuery, "mainData");
            if (((Map<String, Object>) dataObject).containsKey("data")) {
                Map<String, Object> dataMap = (Map<String, Object>) ((Map<String, Object>) dataObject).get("data");
                return dataMap.get("mainData");
            } else {
                return data;
            }
        } catch (Exception e) {
            return data;
        }
    }

    /**
     * Execute graph ql query.
     *
     * @param data    the data
     * @param query   the query
     * @param dataKey the data key
     * @return the object
     */
    public static Object executeGraphQlQuery(Object data, String query, String dataKey) {
        GraphQL graphQL1 = getGraphQlObject(data, query, dataKey);
        return graphQL1.execute(query).toSpecification();
    }

    /**
     * Gets the graph ql object.
     *
     * @param data  the data
     * @param query the query
     * @return the graph ql object
     */
    public static GraphQL getGraphQlObject(Object data, String query) {
        return getGraphQlObject(data, query, null);
    }

    /**
     * Gets the graph ql object.
     *
     * @param data    the data
     * @param query   the query
     * @param dataKey the data key
     * @return the graph ql object
     */
    public static GraphQL getGraphQlObject(Object data, String query, String dataKey) {
//        if (dataKey == null) {
//
//            var doc = parseDocuments(query, null);
//
//            try {
//
//                dataKey = ((Field) ((OperationDefinition) doc.getDefinitions().get(0)).getSelectionSet().getSelections()
//                        .get(0)).getName();
//            } catch (Exception e) {
//                dataKey = "mainData";
//            }
//
//        }
		dataKey = "mainData";
        var jsonString = JsonUtils.toJsonOrNull(data);
        Object newData = JsonUtils.fromJsonOrNull(jsonString, new TypeReference<Object>() {
        });
        GraphQLObjectType queryType = GraphQLObjectType.newObject().name("Query")
                .field(GraphQLFieldDefinition.newFieldDefinition().name(dataKey)
                        .type(getGraphQlObjectType(newData, dataKey)).dataFetcher(getMapData(newData)))
                .build();
        GraphQLSchema schema = GraphQLSchema.newSchema().query(queryType).build();

        GraphQL graphQL1 = GraphQL.newGraphQL(schema).build();
        return graphQL1;
    }

    /**
     * Gets the graph ql object type.
     *
     * @param dataObject the data object
     * @param dataKey    the data key
     * @return the graph ql object type
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static GraphQLOutputType getGraphQlObjectType(Object dataObject, String dataKey) {

        GraphQLOutputType outputType = null;

        if (dataObject instanceof List && ((List) dataObject).size() > 0) {

            GraphQLOutputType childObject = getGraphQlObjectType(((List) dataObject).get(0), dataKey);
            outputType = new GraphQLList(childObject);
        } else if (dataObject instanceof Map) {
            GraphQLObjectType.Builder objectTypeBuilder = GraphQLObjectType.newObject()
                    .name("a" + UUID.randomUUID().toString().replaceAll("-", ""));
            Map mapObject = (Map) dataObject;
            mapObject.keySet().stream().forEach(action -> {
                objectTypeBuilder.field(GraphQLFieldDefinition.newFieldDefinition().name((String) action)
                        .type(getGraphQlObjectType(mapObject.get(action), (String) action)).build());
            });

            outputType = objectTypeBuilder.build();
        } else if (dataObject instanceof Integer) {
            outputType = Scalars.GraphQLInt;
        } else if (dataObject instanceof Long) {
            outputType = Scalars.GraphQLLong;
        } else if (dataObject instanceof Boolean) {
            outputType = Scalars.GraphQLBoolean;
        } else if (dataObject instanceof Float) {
            outputType = Scalars.GraphQLFloat;
        } else if (dataObject instanceof BigDecimal) {
            outputType = Scalars.GraphQLBigDecimal;
        } else if (dataObject instanceof BigInteger) {
            outputType = Scalars.GraphQLBigInteger;
        } else if (dataObject instanceof Byte) {
            outputType = Scalars.GraphQLByte;
        } else if (dataObject instanceof Short) {
            outputType = Scalars.GraphQLShort;
        } else {
            outputType = Scalars.GraphQLString;
        }

        return outputType;
    }

    /**
     * Gets the map data.
     *
     * @param data the data
     * @return the map data
     */
    @SuppressWarnings("rawtypes")
    public static DataFetcher getMapData(Object data) {
        return dataFetchingEnvironment -> {
            return data;
        };
    }

//    /**
//     * Parses the documents.
//     *
//     * @param input      the input
//     * @param sourceName the source name
//     * @return the document
//     */
//    public static Document parseDocuments(String input, String sourceName) {
//
//        CharStream charStream;
//        if (sourceName == null) {
//            charStream = CharStreams.fromString(input);
//        } else {
//            charStream = CharStreams.fromString(input, sourceName);
//        }
//
//        GraphqlLexer lexer = new GraphqlLexer(charStream);
//
//        CommonTokenStream tokens = new CommonTokenStream(lexer);
//
//        GraphqlParser parser = new GraphqlParser(tokens);
//        parser.removeErrorListeners();
//        parser.getInterpreter().setPredictionMode(PredictionMode.SLL);
//        parser.setErrorHandler(new BailErrorStrategy());
//        GraphqlParser.DocumentContext documentContext = parser.document();
//
//        GraphqlAntlrToLanguage antlrToLanguage = new GraphqlAntlrToLanguage(tokens);
//        Document doc = antlrToLanguage.createDocument(documentContext);
//
//        Token stop = documentContext.getStop();
//        List<Token> allTokens = tokens.getTokens();
//        if (stop != null && allTokens != null && !allTokens.isEmpty()) {
//            Token last = allTokens.get(allTokens.size() - 1);
//            //
//            // do we have more tokens in the stream than we consumed in the parse?
//            // if yes then its invalid. We make sure its the same channel
//            boolean notEOF = last.getType() != Token.EOF;
//            boolean lastGreaterThanDocument = last.getTokenIndex() > stop.getTokenIndex();
//            boolean sameChannel = last.getChannel() == stop.getChannel();
//            if (notEOF && lastGreaterThanDocument && sameChannel) {
//                throw new ParseCancellationException("There are more tokens in the query that have not been consumed");
//            }
//        }
//
//        return doc;
//    }

}
