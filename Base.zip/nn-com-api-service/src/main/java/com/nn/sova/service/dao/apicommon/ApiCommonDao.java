package com.nn.sova.service.dao.apicommon;

import com.nn.sova.exception.QueryException;

/**
 * ApiCommonDao interface is to do database operations of API common controller
 * @author Johnpeter Jesu
 *
 */
public interface ApiCommonDao {
	/**
	 * getAccessibleVersion method is to get accessible version
	 * @param majorVersion
	 * @param minorVersion
	 * @param url
	 * @return
	 * @throws QueryException
	 */
	public String getAccessibleVersion(String majorVersion, String minorVersion, String url) throws QueryException;
}
