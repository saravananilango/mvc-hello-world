package com.nn.sova.service.utils.appgen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.nn.sova.service.entity.requestresponse.response.SovaHttpResponse;
import com.nn.sova.service.enums.SovaResponseStatus;
import com.nn.sova.service.utils.CommonUtils;

public class AppgenCommonUtils extends CommonUtils {
	
	/** The Constant STATUS * */
    private static final String STATUS = "status";
    
    /** The Constant MESSAGE * */
    private static final String MESSAGE = "message";

    /**
     * appgenInternalErrorResponse method is to get error response for appgen
     * method.
     *
     * @param exception the exception
     * @return the response entity
     */
	public static void appgenInternalErrorResponse(Exception exception, SovaHttpResponse response) {
        Map<String, Object> appgenResultMap = new HashMap<>();
        List<Map<String, Object>> appgenInternalErrorList = new ArrayList<>();
        Map<String, Object> appgenInternalErrorMap = new HashMap<>();
        appgenInternalErrorMap.put("errorValue", exception.getMessage());
        appgenInternalErrorList.add(appgenInternalErrorMap);
        appgenResultMap.put(STATUS, false);
        appgenResultMap.put(MESSAGE, appgenInternalErrorList);
		response.withStatusCode(SovaResponseStatus.INTERNAL_SERVER_ERROR.value()).withBody(appgenResultMap);
    }
}
