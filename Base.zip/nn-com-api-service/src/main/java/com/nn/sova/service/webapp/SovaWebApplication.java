package com.nn.sova.service.webapp;

import com.nn.sova.service.annotations.SovaComponentScan;
import com.nn.sova.service.requestresponsebase.SovaApplication;

@SovaComponentScan(basePackages = { "com.nn.sova.service.controller" })
public class SovaWebApplication extends SovaApplication {

}
