package com.nn.sova.service.dao.apicommon;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Iterables;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;

/**
 * ApiCommonDaoImpl class is to do database operations of API common.
 * 
 * @author Johnpeter Jesu
 *
 */
public class ApiCommonDaoImpl implements ApiCommonDao {

    /** The constant COMMON_PREFIX_KEY */
    private static final String COMMON_PREFIX_KEY = "appgen_api_latest_version_";

    /**
     * Gets the accessible version.
     *
     * @param majorVersion the major version
     * @param minorVersion the minor version
     * @param url the url
     * @return the accessible version
     * @throws QueryException the query exception
     */
    @Override
    public String getAccessibleVersion(String majorVersion, String minorVersion, String url) throws QueryException {
        String cacheVersionData = cacheVersionData(url, majorVersion, minorVersion, "", "get");
        if (StringUtils.isNotEmpty(cacheVersionData)) {
            return cacheVersionData;
        }
        QueryBuilder queryBuilder = new QueryBuilder().btSchema();

        ConditionBuilder condition = ConditionBuilder.instance();
        condition.eq("apiDetail.combined_url", url);
        if (StringUtils.isNotEmpty(majorVersion) && StringUtils.isNotEmpty(minorVersion)) {
            if (StringUtils.isNotEmpty(condition.getQuery())) {
                condition.and();
            }
            condition.lte("apiDetail.major_version", Integer.parseInt(majorVersion)).and()
                    .lte("apiDetail.minor_version", Integer.parseInt(minorVersion));
        }
        SelectQueryBuilder selectBuilder = queryBuilder.select().checkIndependentTenant(true)
                .getWithAliasName("apiDetail.major_version", "major_version")
                .getWithAliasName("apiDetail.minor_version", "minor_version")
                .getWithAliasName("apiDetail.patch_version", "patch_version").from("api_detail", "apiDetail")
                .orderBy("apiDetail.major_version", SortType.DESC).orderBy("apiDetail.minor_version", SortType.DESC)
                .orderBy("apiDetail.patch_version", SortType.DESC).limit(1);
        List<Map<String, Object>> programDetailsList = selectBuilder.where(condition).build(false).execute();
        Map<String, Object> apiDetailData = Iterables.getFirst(programDetailsList, new HashMap<>());
        String outputVersion = Objects.toString(apiDetailData.getOrDefault("major_version", "0")) + "."
                + Objects.toString(apiDetailData.getOrDefault("minor_version", "0"));
        cacheVersionData(url, majorVersion, minorVersion, outputVersion, "put");
        return outputVersion;
    }

    /**
     * cacheVersionData method.
     *
     * @param url the url
     * @param majorVersion the major version
     * @param minorVersion the minor version
     * @param outputVersion the output version
     * @param operation the operation
     * @return the string
     */
    private String cacheVersionData(String url, String majorVersion, String minorVersion, String outputVersion,
            String operation) {
        if (StringUtils.isEmpty(majorVersion)) {
            majorVersion = "0";
        }
        if (StringUtils.isEmpty(minorVersion)) {
            minorVersion = "0";
        }
        String cacheKey = COMMON_PREFIX_KEY + url + "_" + majorVersion + "_" + minorVersion;
        if ("put".equals(operation)) {
            CacheService.getInstance().saveToCache(cacheKey, outputVersion);
            return outputVersion;
        } else {
            String savedCacheData = Objects.toString(CacheService.getInstance().getCacheData(cacheKey), "");
            return savedCacheData;
        }
    }
}
