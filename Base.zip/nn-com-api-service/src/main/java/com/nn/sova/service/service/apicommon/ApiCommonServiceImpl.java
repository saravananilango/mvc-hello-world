package com.nn.sova.service.service.apicommon;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.dao.apicommon.ApiCommonDao;
import com.nn.sova.service.dao.apicommon.ApiCommonDaoImpl;


/**
 * ApiCommonServiceImpl class is to do service operations of API common controller.
 * @author Johnpeter Jesu
 *
 */
public class ApiCommonServiceImpl implements ApiCommonService {
	
	/** The Constant apiCommonDao **/
	private ApiCommonDao apiCommonDao;
	
	/**
	 * ApiCommonServiceImpl constructor
	 */
	public ApiCommonServiceImpl() {
		apiCommonDao=new ApiCommonDaoImpl();
	}

	@Override
	public String getAccessibleVersion(String majorVersion, String minorVersion, String url) throws QueryException {
		return apiCommonDao.getAccessibleVersion(majorVersion, minorVersion, url);
	}
	
}
