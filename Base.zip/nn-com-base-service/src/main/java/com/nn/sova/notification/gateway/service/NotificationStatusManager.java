package com.nn.sova.notification.gateway.service;

import java.util.Map;

import com.nn.sova.nts.vo.NotificationResponse;

/**
 * 
 * Service layer to categorize mail , sms and fcm.
 *
 */
public interface NotificationStatusManager {
	
	/**
	 * Update the status of notification either success or failed.
	 * @param transactionId
	 * @param response
	 */
	public String upsertTransactionStatus(Map<String,Object> userData, NotificationResponse response);

}
 