package com.nn.sova.service.utils.flowlog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.InsertQueryBuilder;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * AppGenDBFlowLoger to send logs to Database
 * 
 * @author Vignesh R
 *
 */
public class AppGenDBFlowLogger implements AppGenFlowLogger {

	private static final ApplicationLogger LOGGER = ApplicationLogger.create(AppGenDBFlowLogger.class);

	public static final String FLOW_LOG_TABLE = "appgen_flow_logs";

	static final List<String> SKIP_KEYS = Arrays.asList("request_category", "execution_time");

	private static Map<String, List<Map<String,Object>> > BufferedLogs = new HashMap<String, List<Map<String,Object>>>();

	/**
	 * SendLog method to send logs to DB
	 */
	@Override
	public void sendLog(Map<String, String> log) {
		try {
			String processId = log.get("process_id").toString();
			List<Map<String,Object>> logBuffer = getBufferedLogs(processId);
			Map<String,Object> dbMap = log.entrySet().stream()
					.filter(entry -> !SKIP_KEYS.contains(entry.getKey()))
					.collect(HashMap::new, (map,value)->{
						map.put(appender(value.getKey()), value.getValue());
					}, HashMap::putAll);
			logBuffer.add(dbMap);
			BufferedLogs.put(processId, logBuffer);
			//Not to send each log
			//insertLogToDB(dbMap);
		} catch (Exception e) {
			LOGGER.error("Log received: " + log);
			LOGGER.error("Exception while uploading log to DB", e);
		}
	}

	/**
	 * pushBufferedLog
	 */
	public void pushBufferedLog() {
		List<Map<String,Object>> logs = BufferedLogs.get(ContextBean.getProcessId());
		BufferedLogs.put(ContextBean.getProcessId(), null);
		if(Optional.ofNullable(logs).isPresent()) {
			try {
				getInsertBuilder().skipChangeRequest(true).insertWithList(FLOW_LOG_TABLE, logs);

			} catch (QueryException e) {
				LOGGER.error("Exception while uploading buffered log to DB", e);
			}
		}
	}

	String appender(String key) {
		return FLOW_LOG_TABLE + "." + key;
	}

	public static List<Map<String,Object>> getBufferedLogs(String processId){
		return Optional.ofNullable(BufferedLogs.get(processId)).orElse(new ArrayList<Map<String,Object>>());
	}

	private InsertQueryBuilder getInsertBuilder() {
		return new QueryBuilder().btSchema().insert();
	}

	boolean insertLogToDB(Map<String,Object> dbMap) throws QueryException {
		return getInsertBuilder().skipChangeRequest(true).insertWithMap(FLOW_LOG_TABLE, dbMap).getExecutorStatus();
	}


}
