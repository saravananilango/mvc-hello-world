package com.nn.sova.service.authentication;

import java.io.IOException;
import java.security.GeneralSecurityException;

import com.nn.sova.service.authorization.AuthRequestEntity;
import com.nn.sova.service.authorization.AuthResultEntity;

/**
 * The Interface AuthenticationServiceInterface.
 */
public interface AuthenticationServiceInterface {
	
	/**
	 * Token authentication.
	 *
	 * @param authRequestEntity the auth request entity
	 * @param issuer the issuer
	 * @param clientId the client id
	 * @return the auth result entity
	 * @throws GeneralSecurityException the general security exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public AuthResultEntity tokenAuthentication(AuthRequestEntity authRequestEntity,String issuer,String clientId) throws GeneralSecurityException, IOException;
}
