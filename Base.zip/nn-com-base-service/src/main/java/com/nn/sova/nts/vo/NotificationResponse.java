package com.nn.sova.nts.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor(staticName = "of")
@Data
public class NotificationResponse {
	
	private String notificationId;
	
	private NotificationStatus status;
	
	private String errorMessage;

}
