package com.nn.sova.notification.gateway.sms;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.notification.gateway.service.NotificationStatusManager;
import com.nn.sova.notification.gateway.service.NtsGatewayService;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.nts.vo.NotificationStatus;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;
/**
 * 
 * Service class for SMS service .
 *
 */
public abstract class NtsSmsGatewayService implements NotificationStatusManager {
	
	private static final ApplicationLogger logger = ApplicationLogger.create(NtsSmsGatewayService.class);
	
	private static final String SMS_TRANSACTION_TABLE = "nts_transaction_sms";
	
	/** The Constant SMS_TRANSACTION_TABLE primary keys. */
	private static final String[] SMS_TRANSACTION_PRIMARY_KEYS = { "tenant_id", "item_id" };
	
	public abstract NtsGatewayService getGatewayInstance(String gatewayId);
	
    /**
     * Update the status when start to send mail.
     * @param userData
     * @param handlerData
     * @return
     */
	@Override
	public String upsertTransactionStatus(Map<String, Object> userData, NotificationResponse response) {
		QueryBuilder queryBuilder = new QueryBuilder();
		Map<String,Object> smsTransactionMap = new HashMap<>();
		List<String> updatedColumns = new ArrayList<>();
		String itemId = userData.get("notificationId").toString();
		smsTransactionMap.put(SMS_TRANSACTION_TABLE+".item_id",itemId);
		smsTransactionMap.put(SMS_TRANSACTION_TABLE+".mobile_number",JsonUtils.toJsonOrEmpty(userData));
		smsTransactionMap.put(SMS_TRANSACTION_TABLE+".message",JsonUtils.toJsonOrEmpty(userData));
		smsTransactionMap.put(SMS_TRANSACTION_TABLE+".status", response.getStatus().toString());
		smsTransactionMap.put(SMS_TRANSACTION_TABLE+".error_message", response.getErrorMessage());
		if(NotificationStatus.COMPLETED.equals(response.getStatus())) {
			smsTransactionMap.put(SMS_TRANSACTION_TABLE+".sent_time", new Timestamp(new Date().getTime()));
			updatedColumns = Arrays.asList("item_id","mobile_number","message","sent_time","status","error_message");
		} else if(NotificationStatus.QUEUED.equals(response.getStatus())) {
			smsTransactionMap.put(SMS_TRANSACTION_TABLE+".queued_time",new Timestamp(new Date().getTime()));
			updatedColumns = Arrays.asList("item_id","mobile_number","message","queued_time","status","error_message");
		} else if(NotificationStatus.FAILED.equals(response.getStatus())) {
			updatedColumns = Arrays.asList("item_id","mobile_number","message","status", "error_message");
		} 
		try {
			queryBuilder.btSchema().insert().upsertWithKeyList(SMS_TRANSACTION_TABLE, Arrays.asList(smsTransactionMap),
					true, updatedColumns, SMS_TRANSACTION_PRIMARY_KEYS);
		} catch (QueryException e) {
			logger.error("Error Occured :: insertIntoSmsTransactionTable",e);
		}
		return itemId;
	}
}
