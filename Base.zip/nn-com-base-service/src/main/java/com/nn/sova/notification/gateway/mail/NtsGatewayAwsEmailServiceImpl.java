package com.nn.sova.notification.gateway.mail;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.nn.sova.notification.constants.NotificationConstants;
import com.nn.sova.notification.gateway.service.NtsGatewayService;
import com.nn.sova.nts.vo.MailAttachmentsVo;
import com.nn.sova.nts.vo.NotificationException;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.nts.vo.NotificationStatus;
import com.nn.sova.utility.logger.ApplicationLogger;

public class NtsGatewayAwsEmailServiceImpl implements NtsGatewayService {
	
	private static final ApplicationLogger logger = ApplicationLogger.create(NtsGatewayAwsEmailServiceImpl.class);
	
	private static final List<String> HANDLER_KEYS = Arrays.asList("host_url", "username", "password", "port", "from_address",
			"from_name", "enable_auth", "enable_tls");
	/**
	 * Used to maintain singleton instance.
	 */
	private static NtsGatewayAwsEmailServiceImpl instance = null;
	

	/**
	 * Instantiates NtsGatewayAwsEmailServiceImpl.
	 */
	private NtsGatewayAwsEmailServiceImpl() {

	}
	
	/**
	 * Gets instance of NtsGatewayAwsEmailServiceImpl class.
	 *
	 * @return the instance
	 */
	public static NtsGatewayAwsEmailServiceImpl getInstance() {
		if (instance == null) {
			instance = new NtsGatewayAwsEmailServiceImpl();
		}
		return instance;
	}
	
	/**
	 * Returns the handler keys for FCM gateway.
	 */
	@Override
	public List<String> getHandlerKeys() {
		return HANDLER_KEYS;
	}

	@Override
	public NotificationResponse send(Map<String, Object> ntsData, Map<String, Object> handlerData) {
		
		InternetAddress[] ccAddressList = null;
		InternetAddress[] bccAddressList = null;
		InternetAddress[] toList = null;
		List<String> toEmailList = new ArrayList<>();

		String notificationId = ntsData.get("notificationId").toString();
		Map<String, Object> handlerkeys = (Map<String, Object>) handlerData.get("handlerKeys");

		// AWS handler Data
		String fromAddress = handlerkeys.get("from_address").toString();
		String fromName = handlerkeys.get("from_name").toString();
		String smtpUserName = handlerkeys.get("username").toString();
		String smtpPassword = handlerkeys.get("password").toString();
		String smtphost = handlerkeys.get("host_url").toString();
		boolean enabletTls = Boolean.parseBoolean(handlerkeys.get("enable_tls").toString());
		boolean enableAuth = Boolean.parseBoolean(handlerkeys.get("enable_auth").toString());
		int port = Integer.parseInt(handlerkeys.get("port").toString());

		// Mail User Data
		// email_id - key deprecated , instead use "to". Still support backward compatability.
		if(ntsData.containsKey("email_id")) {
			toEmailList.add(ntsData.get("email_id").toString());
		}
		String subjectText = ntsData.containsKey("mail_subject") ? ntsData.get("mail_subject").toString()
				: ntsData.get("mail_template_subject").toString();
		String bodyText = ntsData.containsKey("mail_body") ? ntsData.get("mail_body").toString()
				: ntsData.get("mail_template_body").toString();

		String body = String.join(System.getProperty("line.separator"), bodyText);
		String mailTypeFromParam = ntsData.containsKey("mail_type") ? ntsData.get("mail_type").toString() : NotificationConstants.MAIL_CONTENT_TYPE_HTML_KEY;
		String mailType = getMailType(mailTypeFromParam);

		Properties props = System.getProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.port", port);
		props.put("mail.smtp.starttls.enable", enabletTls);
		props.put("mail.smtp.auth", enableAuth);

		Session session = Session.getDefaultInstance(props);
		MimeMessage msg = new MimeMessage(session);
		try {
			msg.setFrom(new InternetAddress(fromAddress, fromName));
			if (ntsData.containsKey(NotificationConstants.CC) && Objects.nonNull(ntsData.get(NotificationConstants.CC))) {
				ccAddressList = convertStringToInetAddress((List<String>) ntsData.get(NotificationConstants.CC));
				msg.addRecipients(Message.RecipientType.CC, ccAddressList);
			}
			if (ntsData.containsKey(NotificationConstants.BCC) && Objects.nonNull(ntsData.get(NotificationConstants.BCC))) {
				bccAddressList = convertStringToInetAddress((List<String>) ntsData.get(NotificationConstants.BCC));
				msg.addRecipients(Message.RecipientType.BCC, bccAddressList);
			}
			if(ntsData.containsKey("to") && Objects.nonNull(ntsData.get(NotificationConstants.TO))) {
				toEmailList.addAll((List<String>) ntsData.get(NotificationConstants.TO));
			}
			toList = convertStringToInetAddress(toEmailList);
			msg.addRecipients(Message.RecipientType.TO, toList);
			msg.setSubject(subjectText, "utf-8");
			
			Multipart multipart = new MimeMultipart();
			// creates message part
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(body, mailType + ";" + StringUtils.SPACE + NotificationConstants.MAIL_CHARSET_UTF_8);
			multipart.addBodyPart(messageBodyPart);
			
			// creates Attachment Preparation and attach.
			if(ntsData.containsKey(NotificationConstants.ATTACHMENTS) && Objects.nonNull(ntsData.get(NotificationConstants.ATTACHMENTS))) {
				if(!prepareAttachments(ntsData, multipart)) {
					logger.error("Error occurred in Attachment parameters , please check logs in detail");
					return NotificationResponse.of(notificationId, NotificationStatus.FAILED, "Error occurred in Attachment parameters");
				}
			}
			msg.setContent(multipart);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
		}
		Transport transport = null;
		try {
			transport = session.getTransport();
			logger.info("sending mail to {}", toEmailList);
			transport.connect(smtphost, smtpUserName, smtpPassword);
			transport.sendMessage(msg, msg.getAllRecipients());
			logger.info("Mail Sent to {}", toEmailList);
			return NotificationResponse.of(notificationId, NotificationStatus.COMPLETED, null);
		} catch (Exception ex) {
			logger.error("Failed sending mail to {} , error message {} ", toEmailList, ex.getMessage());
			return NotificationResponse.of(notificationId, NotificationStatus.FAILED, ex.getMessage());
		} finally {
			try {
				transport.close();
			} catch (MessagingException e) {
				e.printStackTrace();
			}
		}
	}


	/**
	 * Validate the receiver data .
	 * EmailId , subject and body.
	 * @throws NotificationException 
	 */
	@Override
	public void validateUserData(Map<String, Object> ntsData) throws NotificationException {
		String toEmailId = ntsData.containsKey("email_id") ? ntsData.get("email_id").toString() : StringUtils.EMPTY;
		List<String> toList = (List<String>) ntsData.get(NotificationConstants.TO);
		String subjectText = ntsData.containsKey("mail_subject") ? ntsData.get("mail_subject").toString()
				: ntsData.containsKey("mail_template_subject") ? ntsData.get("mail_template_subject").toString()
						: StringUtils.EMPTY;
		String bodyText = ntsData.containsKey("mail_body") ? ntsData.get("mail_body").toString()
				: ntsData.containsKey("mail_template_body") ? ntsData.get("mail_template_body").toString()
						: StringUtils.EMPTY;
	    if(StringUtils.isEmpty(toEmailId)
				&& CollectionUtils.isEmpty(toList)) {
	    	throw new NotificationException("Mandatory email parameter - to is empty");
	    }
	    if(StringUtils.isEmpty(subjectText) || StringUtils.isEmpty(bodyText)) {
	    	throw new NotificationException("Mandatory email parameter - Subject or Body is empty");
	    }
	}

    /**
     * Default type : text/html.
     * Todo : Cases increase while implementing attachments.
     * @param mailTypeFromParam
     * @return
     */
	private String getMailType(String mailTypeFromParam) {
		switch (mailTypeFromParam) {
		case NotificationConstants.MAIL_CONTENT_TYPE_HTML_KEY:
			return NotificationConstants.MAIL_CONTENT_TYPE_HTML;
		case NotificationConstants.MAIL_CONTENT_TYPE_PLAIN_KEY:
			return NotificationConstants.MAIL_CONTENT_TYPE_PLAIN;
		default:
			return NotificationConstants.MAIL_CONTENT_TYPE_HTML;
		}
	}
	
	/**
	 * Prepare attachment and add in body part.
	 * @param ntsData
	 * @param multipart
	 * @return
	 */
	private boolean prepareAttachments(Map<String,Object> ntsData, Multipart multipart) {
    	Gson gson = new Gson();
    	String json = gson.toJson(ntsData.get(NotificationConstants.ATTACHMENTS));
    	ObjectMapper mapper = new ObjectMapper();
    	List<MailAttachmentsVo> attachments = new ArrayList<>();
		try {
			attachments = mapper.readValue(json, new TypeReference<List<MailAttachmentsVo>>(){});
		} catch (JsonMappingException e1) {
			e1.printStackTrace();
			return false;
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
			return false;
		}
		for (MailAttachmentsVo attachment : attachments) {
			if (!validateAttachmentMandatoryParameters(attachment)) {
				return false;
			}
			MimeBodyPart attachPart = new MimeBodyPart();
			ByteArrayDataSource bds = new ByteArrayDataSource(attachment.getFileData(), attachment.getFileType());
			bds.setName(attachment.getFileName());
			try {
				attachPart.setDataHandler(new DataHandler(bds));
				attachPart.setFileName(bds.getName());
				attachPart.setDisposition(attachment.getDisposition());
				// only for inline attachment , need contentId
				if(Part.INLINE.equals(attachment.getDisposition())) {
					attachPart.setContentID(attachment.getContentId());
				}
				multipart.addBodyPart(attachPart);
			} catch (MessagingException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Validate the mandatory parameters for attachment.
	 * @param attachment
	 * @return
	 */
    private  boolean validateAttachmentMandatoryParameters(MailAttachmentsVo attachment) {
    	boolean isValid = true;
		if(Objects.isNull(attachment.getFileName())) {
			logger.error("Mandatory parameter fileName is missing - {}", attachment);
			isValid = false;
		}
		if(Objects.isNull(attachment.getFileData())) {
			logger.error("Mandatory parameter fileData is missing - {}", attachment);
			isValid = false;
			
		}
		return isValid;
	}
    
    /**
     * convert the given emailId to InetAddress.
     * @param addressList
     * @return
     */
	private InternetAddress[] convertStringToInetAddress(List<String> addressList) {
		InternetAddress[] addresses = new InternetAddress[addressList.size()];
        for (int i = 0; i < addressList.size(); i++) {
        	try {
				addresses[i] = new InternetAddress(addressList.get(i).toString());
			} catch (AddressException e) {
				logger.warn("Error while converting emailAddress to InetAddress {}", addressList.get(i).toString());
			}
        }
        return addresses;
		
	}
	


}
