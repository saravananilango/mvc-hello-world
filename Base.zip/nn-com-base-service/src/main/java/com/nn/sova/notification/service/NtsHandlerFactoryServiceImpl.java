package com.nn.sova.notification.service;

import com.nn.sova.notification.config.NotificationConfig;
import com.nn.sova.notification.gateway.service.NotificationStatusManager;
import com.nn.sova.utility.logger.ApplicationLogger;

public class NtsHandlerFactoryServiceImpl implements NtsHandlerFactoryService {
	
	public static ApplicationLogger logger = ApplicationLogger.create(NtsHandlerFactoryServiceImpl.class);

	@Override
	public  NotificationStatusManager getServiceInstance(String gatewayType) {
		NotificationStatusManager providerInstance = null;
		switch (gatewayType) {
		case "sms":
			return NotificationConfig.getSmsGatewayService();
		case "mail":
			return NotificationConfig.getEmailGatewayService();
//		case "fcm":
//			return NotificationConfig.getFcmNotificationService();
		}
		return providerInstance;
	}

}
