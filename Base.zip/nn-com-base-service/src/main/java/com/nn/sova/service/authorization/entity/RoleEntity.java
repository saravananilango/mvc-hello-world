package com.nn.sova.service.authorization.entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import lombok.Data;

import org.apache.commons.lang3.StringUtils;

/**
 * RoleEntity defines the structure of the RoleDao.
 *
 * @author Vellaichamy N
 */

@Data
public class RoleEntity {

	/**  The Role Id. */
	private String roleId;

	/**  The Role Name. */
	private String roleName;

	/**  The isFullyAuthorized flag. */
	private boolean isFullyAuthorized;

	/**  The comment of the Role. */
	private String comment;

	/**  The isDefault. */
	private boolean isDefault;


	/**
	 * mapValues convert entity into Map.
	 *
	 * @param roleEntity has an role information
	 * @return Role info as map
	 */
	public static Map<String, Object> mapValues(RoleEntity roleEntity) {
		Map<String, Object> roleInfoMapper = new HashMap<>();
		roleInfoMapper.put("role_id",roleEntity.getRoleId());
		roleInfoMapper.put("role_name",roleEntity.getRoleName());
		roleInfoMapper.put("is_full_authority",roleEntity.isFullyAuthorized());
		roleInfoMapper.put("comment",roleEntity.getComment());
		roleInfoMapper.put("is_default",roleEntity.isDefault());
		return roleInfoMapper;
	}



	/**
	 * mapValues convert map into entity.
	 *
	 * @param roleInfoMapper has an role info as map
	 * @return RoleEntity
	 */
	public static RoleEntity mapValues(Map<String, Object> roleInfoMapper) {
		RoleEntity roleEntity = new RoleEntity();
		roleEntity.setRoleId(Objects.isNull(roleInfoMapper.get("roleSetting.roleId"))?StringUtils.EMPTY:roleInfoMapper.get("roleSetting.roleId").toString());
		roleEntity.setRoleName(Objects.isNull(roleInfoMapper.get("roleSetting.roleName"))?StringUtils.EMPTY:roleInfoMapper.get("roleSetting.roleName").toString());
		roleEntity.setFullyAuthorized(Objects.isNull(roleInfoMapper.get("roleSetting.isFullAuthority"))?Boolean.FALSE:Boolean.valueOf(roleInfoMapper.get("roleSetting.isFullAuthority").toString()));
		roleEntity.setComment(Objects.isNull(roleInfoMapper.get("roleSetting.comment"))?StringUtils.EMPTY:roleInfoMapper.get("roleSetting.comment").toString());
		roleEntity.setDefault(Objects.isNull(roleInfoMapper.get("roleSetting.isDefault"))?Boolean.FALSE:Boolean.valueOf(roleInfoMapper.get("roleSetting.isDefault").toString()));
		return roleEntity;
	}
}
