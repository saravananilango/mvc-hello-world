package com.nn.sova.service.utils.flowlog;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;
import java.util.zip.GZIPOutputStream;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.StringUtils;

import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.context.EventsLogBean;

/**
 * AppGenFlow log class methods -> enhanced from utility Lib
 * @author Vignesh R
 *
 */
public class AppgenFlowLog {
	
	public static final AppGenFlowLoggerType LOGGER_TYPE = AppGenFlowLoggerType.DB;

	/**
	 * App log.
	 *
	 * @param blockId        the block id
	 * @param componentId    the component id
	 * @param eventName      the event name
	 * @param output         the output
	 * @param componentLabel the component label
	 * @param tagName        the tag name
	 */
	public static void appLog(String blockId, String componentId, String eventName, Object output,
			String componentLabel, String tagName) {
		printAppLog(ContextBean.getRequestId(), ContextBean.getProcessId(), componentId, eventName, blockId, compressAndEncode(output),
				tagName, componentLabel, StringUtils.EMPTY,null,null);
	}

	/**
	 * App log.
	 *
	 * @param blockId     the block id
	 * @param componentId the component id
	 * @param eventName   the event name
	 * @param output      the output
	 */
	public static void appLog(String blockId, String componentId, String eventName, Object output) {
		String componentTagName = Optional.ofNullable(EventsLogBean.getComponentTagName()).orElse(StringUtils.EMPTY);
		String componentLabel = Optional.ofNullable(EventsLogBean.getComponentLabel()).orElse(StringUtils.EMPTY);
		printAppLog(ContextBean.getRequestId(), ContextBean.getProcessId(), componentId, eventName, blockId, compressAndEncode(output),
				componentTagName, componentLabel, ContextBean.getRequesturi(),null,null);
	}

	/**
	 * App log.
	 *
	 * @param blockId     the block id
	 * @param componentId the component id
	 * @param eventName   the event name
	 * @param output      the output
	 * @param httpType    the http type
	 */
	public static void appLog(String blockId, String componentId, String eventName, Object output, String httpType) {
		String componentTagName = Optional.ofNullable(EventsLogBean.getComponentTagName()).orElse(StringUtils.EMPTY);
		String componentLabel = Optional.ofNullable(EventsLogBean.getComponentLabel()).orElse(StringUtils.EMPTY);
		printAppLog(ContextBean.getRequestId(), ContextBean.getProcessId(), componentId, eventName, blockId, compressAndEncode(output),
				componentTagName, componentLabel, httpType + ContextBean.getRequesturi(),null,null);
	}
	
	/**
	 * App log.
	 *
	 * @param blockId        the block id
	 * @param componentId    the component id
	 * @param eventName      the event name
	 * @param output         the output
	 * @param componentLabel the component label
	 * @param tagName        the tag name
	 */
	public static void log(String blockId, String componentId, String eventName, Object output,
			String componentLabel, String tagName, String parentBlock, Object appGenLoopIndex) {
		printAppLog(ContextBean.getRequestId(), ContextBean.getProcessId(), componentId, eventName, blockId, compressAndEncode(output),
				tagName, componentLabel, StringUtils.EMPTY,parentBlock,appGenLoopIndex);
	}

	/**
	 * App log.
	 *
	 * @param blockId     the block id
	 * @param componentId the component id
	 * @param eventName   the event name
	 * @param output      the output
	 */
	public static void log(String blockId, String componentId, String eventName, Object output, String parentBlock, Object appGenLoopIndex) {
		String componentTagName = Optional.ofNullable(EventsLogBean.getComponentTagName()).orElse(StringUtils.EMPTY);
		String componentLabel = Optional.ofNullable(EventsLogBean.getComponentLabel()).orElse(StringUtils.EMPTY);
		printAppLog(ContextBean.getRequestId(), ContextBean.getProcessId(), componentId, eventName, blockId, compressAndEncode(output),
				componentTagName, componentLabel, ContextBean.getRequesturi(),parentBlock,appGenLoopIndex);
	}

	/**
	 * App log.
	 *
	 * @param blockId     the block id
	 * @param componentId the component id
	 * @param eventName   the event name
	 * @param output      the output
	 * @param httpType    the http type
	 */
	public static void log(String blockId, String componentId, String eventName, Object output, String httpType, String parentBlock, Object appGenLoopIndex) {
		String componentTagName = Optional.ofNullable(EventsLogBean.getComponentTagName()).orElse(StringUtils.EMPTY);
		String componentLabel = Optional.ofNullable(EventsLogBean.getComponentLabel()).orElse(StringUtils.EMPTY);
		printAppLog(ContextBean.getRequestId(), ContextBean.getProcessId(), componentId, eventName, blockId, compressAndEncode(output),
				componentTagName, componentLabel, httpType + ContextBean.getRequesturi(),parentBlock,appGenLoopIndex);
	}

	/**
	 * printLog method is to print log of execution time.
	 *
	 * @param objects the objects
	 */
	private static void printAppLog(Object... objects) {
		if (ContextBean.getProcessId() != null && ContextBean.getRequestId() != null && ContextBean.getDebugFlag()) {
			Map<String, String> map = new TreeMap<>();
			map.put("request_id", Objects.toString(objects[0]));
			map.put("process_id", Objects.toString(objects[1]));
			map.put("component_id", nonNullString(objects[2]));
			map.put("component_event_type", nonNullString(objects[3]));
			map.put("block_id", Objects.toString(objects[4]));
			map.put("block_output", Objects.toString(objects[5]));
			map.put("component_tag_name", Objects.toString(objects[6]));
			map.put("component_label", Objects.toString(objects[7]));
			map.put("request_url", Objects.toString(objects[8]));
			map.put("request_category", "ap_access_time");
			map.put("execution_time", "0");
			map.put("parent_block", Objects.toString(objects[9],null));
			map.put("appgen_loop_index", Objects.toString(objects[10],null));
			AppGenFlowLogger.getLogger(LOGGER_TYPE).get().sendLog(map);
		}

	}
	
	/**
	 * A method for sending buffered logs to DB
	 */
	public static void pushLogs() {
		new AppGenDBFlowLogger().pushBufferedLog();
	}

	/**
     * This method used to insert default char avoiding null in component ID
     * @param object
     * @return nonNullString
     */
    private static String nonNullString(Object object) {
    	return Optional.ofNullable(object).map(Objects::toString).filter(StringUtils::isNotEmpty).orElse("-");
    }
    
	/**
	 * compressAndEncode method used to compress the object to encoded string.
	 *
	 * @param data the data
	 * @return the object
	 */
	private static Object compressAndEncode(Object data) {
		return Optional.ofNullable(data).map(AppgenFlowLog::compressAndGetByteArray)
				.map(DatatypeConverter::printBase64Binary).orElse(null);
	}

	/**
	 * compressAndGetByteArray method used to compress the given json to bytes
	 * array.
	 *
	 * @param data the data
	 * @return the byte[]
	 */
	private static byte[] compressAndGetByteArray(Object data) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			GZIPOutputStream gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream);
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(gzipOutputStream);
			objectOutputStream.writeObject(data);
			objectOutputStream.close();
			return byteArrayOutputStream.toByteArray();
		} catch (IOException e) {
			return new byte[] {};
		}
	}
}
