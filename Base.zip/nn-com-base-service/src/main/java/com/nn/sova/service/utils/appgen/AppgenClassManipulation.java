package com.nn.sova.service.utils.appgen;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;

import com.google.common.collect.Iterables;
import com.nn.sova.service.dao.UserAccountDao;
import com.nn.sova.service.dao.UserAccountDaoImpl;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.utility.date.DateTimeUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class AppgenClassManipulation.
 */
public class AppgenClassManipulation {

    /** LOGGER */
    private static final ApplicationLogger LOGGER = ApplicationLogger.create(AppgenClassManipulation.class);
    /** userAccountDao */
    private static final UserAccountDao userAccountDao = new UserAccountDaoImpl();

    private static final String[] tensNames = { "", " ten", " twenty", " thirty", " forty", " fifty", " sixty",
            " seventy", " eighty", " ninety" };

    private static final String[] numNames = { "", " one", " two", " three", " four", " five", " six", " seven",
            " eight", " nine", " ten", " eleven", " twelve", " thirteen", " fourteen", " fifteen", " sixteen",
            " seventeen", " eighteen", " nineteen" };

    /**
     * getFormattedDateString method is to format Date/Timestamp value into specific
     * format.
     * 
     * <p>
     * Optional externalFormatObjectList sample data [
     * {"differenceDays":"0","format":", HH:mm","prefixText":"Today"},
     * {"differenceDays":"-1","format":", HH:mm","prefixText":"Yesterday"} ]
     * </p>
     * 
     * <pre>
     * AppgenCommonUtils.getFormattedDateString("2021-01-20 04:50:21", "MMM dd, HH:mm", null) => Jan 20, 04:50
     * AppgenCommonUtils.getFormattedDateString("2021-01-20 04:50:21", "MMM dd, HH:mm", externalFormatList) => Today, 04:50
     * AppgenCommonUtils.getFormattedDateString("2021-01-19 04:50:21", "MMM dd, HH:mm", externalFormatList) => Yesterday, 04:50
     * </pre>
     *
     * @param value                    the value
     * @param format                   the format
     * @param externalFormatObjectList the external format object list
     * @return the formatted date string
     */
    public static String getFormattedDateString(Object value, String format, Object externalFormatObjectList) {
        String formattedDate = "";
        try {
            if (StringUtils.isEmpty(Objects.toString(value, ""))) {
                return "";
            }
            Timestamp timeValue = null;
            long time = 0l;
            try {
                timeValue = CommonUtils.getTimeStamp(value);
                time = timeValue.getTime();
            } catch (Exception exception) {
            }
            if (time < 0 || Objects.isNull(timeValue)) {
                time = CommonUtils.dateConverter(value).getTime();
            }
            SimpleDateFormat outputFormatter = new SimpleDateFormat(format);
            formattedDate = outputFormatter.format(time);
            List<Map<String, Object>> externalFormatList = CommonUtils.getNonNullList(externalFormatObjectList);
            if (CollectionUtils.isNotEmpty(externalFormatList)) {
                Date todayDate = CommonUtils.dateConverter(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                Date givenDate = CommonUtils.dateConverter(new SimpleDateFormat("yyyy-MM-dd").format(new Date(time)));
                Days days = Days.daysBetween(new DateTime(todayDate), new DateTime(givenDate));
                String comparision = Objects.toString(days.getDays(), "");
                Map<String, Object> externalFormatMap = externalFormatList.stream()
                        .filter(predicate -> comparision.equals(Objects.toString(predicate.get("differenceDays"))))
                        .findFirst().orElse(new HashMap<>());
                String externalFormat = Objects.toString(externalFormatMap.get("format"), "");
                String prefixText = Objects.toString(externalFormatMap.get("prefixText"), "");
                if (StringUtils.isNotEmpty(externalFormat)) {
                    SimpleDateFormat externalFormatter = new SimpleDateFormat(externalFormat);
                    String externalDateString = prefixText + externalFormatter.format(time);
                    formattedDate = externalDateString;
                }
            }
        } catch (Exception exception) {
            LOGGER.error("getFormattedDateString method error: ", exception);
        }
        return formattedDate;
    }

    /**
     * getJustifiedString method is to check given input value length, if length is
     * less than outputStringLength value, prefix/suffix given value (addValue)
     * 
     * <pre>
     * AppgenCommonUtils.getJustifiedString("123", 12, "prefix", "0") => "000000000123"
     * AppgenCommonUtils.getJustifiedString("123", 12, "suffix", "0") => "123000000000"
     * AppgenCommonUtils.getJustifiedString("123", 12, "prefix", " ") => "         123"
     * </pre>
     *
     * @param inputValue         the input value
     * @param outputStringLength the output string length
     * @param addPosition        the add position
     * @param addValue           the add value
     * @return the justified string
     */
    public static String getJustifiedString(Object inputValue, int outputStringLength, String addPosition,
            Object addValue) {
        String value = Objects.toString(inputValue, "");
        addPosition = Objects.toString(addPosition, "").toLowerCase();
        while (value.length() < outputStringLength) {
            if (addPosition.equals("prefix")) {
                value = addValue + value;
            } else {
                value += addValue;
            }
        }
        return value;
    }

    /**
     * getUserAccountDetails method is to get user account details for given user
     * id.
     *
     * @param userId the user id
     * @return the user account details
     */
    public static Map<String, Object> getUserAccountDetails(String userId) {
        return Iterables.getFirst(getUserAccountDetails(Arrays.asList(userId)), new HashMap<>());
    }

    /**
     * getUserAccountDetails method is to get user details for given user ids.
     *
     * @param userIds the user ids
     * @return the user account details
     */
    public static List<Map<String, Object>> getUserAccountDetails(List<String> userIds) {
        return userAccountDao.getUserAccountDetails(userIds);
    }

    /**
     * getStringEndIndex method is to get end index of a string for given regex.
     *
     * @param matcherString the matcher string
     * @param regex         the regex
     * @return the string end index
     */
    public static Integer getStringEndIndex(String matcherString, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(matcherString);
        while (matcher.find()) {
            return matcher.end();
        }
        return 0;
    }

    /**
     * Gets the first date of the month.
     *
     * @param dateValueObject the date value object
     * @param returnFormat    the return format
     * @return the first date of the month
     */
    public static String getFirstDateOfTheMonth(Object dateValueObject, String returnFormat) {
        if (returnFormat.equals("userFormat")) {
            return CommonUtils.getFirstDateOfTheMonth(dateValueObject, returnFormat);
        } else {
            if (StringUtils.isEmpty(returnFormat.trim())) {
                returnFormat = "yyyy/MM/dd";
            }
            return getCustomDateFormat(CommonUtils.getFirstDateOfTheMonth(dateValueObject, returnFormat), returnFormat);
        }
    }

    /**
     * Gets the last date of the month.
     *
     * @param dateValueObject the date value object
     * @param returnFormat    the return format
     * @return the last date of the month
     */
    public static String getLastDateOfTheMonth(Object dateValueObject, String returnFormat) {
        if (returnFormat.equals("userFormat")) {
            return CommonUtils.getLastDateOfTheMonth(dateValueObject, returnFormat);
        } else {
            if (StringUtils.isEmpty(returnFormat.trim())) {
                returnFormat = "yyyy/MM/dd";
            }
            return getCustomDateFormat(CommonUtils.getLastDateOfTheMonth(dateValueObject, returnFormat), returnFormat);
        }
    }

    /**
     * Gets the custom date format.
     *
     * @param dateValueObject the date value object
     * @param dateFormat      the date format
     * @return the custom date format
     */
    public static String getCustomDateFormat(Object dateValueObject, String dateFormat) {
        try {
            Date dateValue = dateConverter(dateValueObject);
            if (dateFormat.equals("userFormat")) {
                return DateTimeUtils.formatWithDate(dateValue);
            } else {
                return DateTimeUtils.formatDateToString(dateValue, dateFormat);
            }
        } catch (Exception exception) {
            LOGGER.error("Exception in date conversion: ", exception);
            return StringUtils.EMPTY;
        }
    }

    /**
     * Date converter.
     *
     * @param dateObject the date object
     * @return the date
     * @throws Exception the exception
     */
    public static Date dateConverter(Object dateObject) throws Exception {
        return CommonUtils.dateConverter(dateObject);
    }
}
