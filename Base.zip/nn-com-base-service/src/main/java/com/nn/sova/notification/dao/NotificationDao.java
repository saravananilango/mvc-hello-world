package com.nn.sova.notification.dao;

import java.util.List;
import java.util.Map;


public interface NotificationDao {
	
    /**
     * 
     * @param userList
     * @return
     */
	List<Map<String, Object>> getUserAccount(List<Object> users);

    /**
     * 
     * @return
     */
	Map<String, Object> getDefaultHandlerConfig();
    /**
     * 
     * @param userList
     * @param sid
     * @return
     */
	List<Map<String, Object>> getNotificationPreferenceByUsers(List<Object> userList, String sid);
    /**
     * 
     * @param notificationObject
     */
	void insertIntoNotificationTable(Map<String, Object> notificationObject);
    /**
     * 
     * @param handlerIds
     * @return
     */
	List<Map<String, Object>> getHandlerKeys(List<Object> handlerIds);
    /**
     * 
     * @param alertId
     * @return
     */
	Map<String, Object> getAlertDef(String alertId);
    /**
     * 
     * @param alertId
     * @return
     */
	Map<String, Object> getHandlerConfigByAlertId(String alertId);
    /**
     * 
     * @param screenDefId
     * @return
     */
	Map<String, Object> getHandlerByScreenDefId(String screenDefId);
    /**
     * 
     * @param customHandlerId
     * @return
     */
	Map<String, Object> getHandlerByCustomHandlerId(String customHandlerId);
    /**
     * 
     * @param screenDefId
     * @return
     */
	Map<String, Object> getNotificationAlertByScreenDefId(String screenDefId);
    /**
     * 
     * @param handlerIds
     * @return
     */
	List<Map<String, Object>> getGatwayHandlerLinkList(List<Object> handlerIds);
    /**
     * 
     * @param screenDefId
     * @return
     */
	Map<String, Object> getNotificationSettingByScreendefid(String screenDefId);
    /**
     * 
     * @param userId
     * @param limit
     * @return
     */
	List<Map<String, Object>> getUnreadNotificationData(String userId, int limit);
    /**
     * 
     * @param userId
     * @param limit
     * @return
     */
	List<Map<String, Object>> getRecentUnreadNotifications(String userId, int limit);
    /**
     * mark the notification as read.
     * @param userId
     * @param notificationID
     */
	void setRead(String userId, String notificationID);
    /**
     * 
     * @param userId
     */
	void setReadAll(String userId);

	/**
	 * setUnRead is to mark a notification as unread.
	 * @param notificationData
	 */
	void setUnRead(String userId, String notificationID);

	/**
	 * getUnreadNotificationsCount is to retrieve unread notifications count by userId.
	 * @param notificationData
	 * @return
	 */
	int getUnreadNotificationsCount(String userId);

	/**
	 * getNotificationIds based on targetUrl and userId . (For workflow - to clear notifications)
	 * @param url
	 * @param userIds
	 * @return
	 */
	List<Map<String, Object>> getNotificationIdsByUserAndTargetUrl(String url, List<Object> userIds);

}
