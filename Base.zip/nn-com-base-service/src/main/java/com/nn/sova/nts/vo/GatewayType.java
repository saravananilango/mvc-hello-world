package com.nn.sova.nts.vo;

public enum GatewayType {
	SMS,
	MAIL,
	FCM
}
