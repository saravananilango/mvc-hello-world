package com.nn.sova.service.user;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.entity.useraccount.UserProfileEntity;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * UserContext is used to set the context details of the User
 * 
 * @author Mohammed Sheriff
 *
 */

public class UserContext {

	// UserContext instance
	private static UserContext instance = null;

	private static ApplicationLogger logger = ApplicationLogger.create(UserContext.class);

	/**
	 * getInstance method is used to get the singleton class of UserContext
	 * 
	 * @return instance of UserContext
	 */
	public static UserContext getInstance() {
		if (Objects.isNull(instance)) {
			instance = new UserContext();
		}
		return instance;
	}

	/**
	 * getUserName gives the userName
	 * 
	 * @return userName
	 */
	public String getUserName() {
		return ContextBean.getUserId();
	}

	/**
	 * getUserName gives the userToken
	 * 
	 * @return userToken
	 */
	public String getUserToken() {
		return ContextBean.getUserToken();
	}

	/**
	 * locale return the current locale
	 * 
	 * @return locale
	 */
	public String locale() {
		return ContextBean.getLocale();
	}

	/**
	 * tenantId return the user tenant id
	 * 
	 * @return tenantId
	 */
	public String getTenantId() {
		return ContextBean.getTenantId();
	}

	/**
	 * getSecurityObject return the priority security object
	 * 
	 * @return SecurityObject
	 */
	public String getSecurityObject() {
		if (CollectionUtils.isNotEmpty(ContextBean.getSecurityOrderedObject())) {
			return ContextBean.getSecurityOrderedObject().stream().findFirst().get();
		}
		return StringUtils.EMPTY;

	}

	/**
	 * getUserProfile used to return the userProfile
	 * 
	 * @return data of User Profile
	 */
	@SuppressWarnings("unchecked")
	public UserProfileEntity getUserProfile() {
		if (StringUtils.isNotEmpty(ContextBean.getUserId())) {
			// Based on Tenant ID user cache data need to retrieved from Cache
			// by passing Tenant Id
			Map<String, Object> cacheMap = new HashMap();
			try {
				cacheMap = (Map<String, Object>) CacheService.getInstance().getUserDataByTenantId(ContextBean.getUserId(), ContextBean.getTenantId());
			} catch (QueryException exception) {
				logger.error(exception);
			}
			if(Objects.nonNull(cacheMap))
				return UserProfileEntity.setUserdataProfile(cacheMap);
		}
		return null;
	}
}
