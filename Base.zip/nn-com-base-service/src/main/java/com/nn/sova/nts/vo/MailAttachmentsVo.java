package com.nn.sova.nts.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
public class MailAttachmentsVo {
	private String fileName;
	private String fileType = "application/octet-stream";
	private byte[] fileData;
	private String fileLink;
	private String disposition = "attachment";
	private String contentId;
}
