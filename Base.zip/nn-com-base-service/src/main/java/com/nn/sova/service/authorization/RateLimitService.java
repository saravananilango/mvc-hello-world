package com.nn.sova.service.authorization;

import java.sql.Timestamp;
import java.time.Duration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

import javax.cache.Cache;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.google.common.base.Strings;
import com.nn.sova.entity.ClientDetailsEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.utils.TokenIdentifier;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bucket4j;
import io.github.bucket4j.BucketConfiguration;
import io.github.bucket4j.ConsumptionProbe;
import io.github.bucket4j.Refill;
import io.github.bucket4j.grid.GridBucketState;
import io.github.bucket4j.grid.ProxyManager;
import io.github.bucket4j.grid.jcache.JCache;

public class RateLimitService {

	private static final ApplicationLogger LOGGER = ApplicationLogger.create(RateLimitService.class);

	private final Cache<String, GridBucketState> cache;

	private ProxyManager<String> buckets;

	private static final int START_INDEX = 0;

	private static final int FIRST_INDEX = 1;

	public RateLimitService(Cache<String, GridBucketState> cache) {
		this.cache = cache;
		// init bucket registry
		buckets = Bucket4j.extension(JCache.class).proxyManagerForCache(this.cache);
	}

	public boolean validateRateLimit(AuthRequestEntity authRequestEntity,Authentication authentication,AuthResultEntity authResultEntity) throws QueryException {
		Bucket requestBucket = null;
		LOGGER.info("validateRateLimit inside starts");
		OAuth2Authentication auth = (OAuth2Authentication) authentication;
			if (!Objects.isNull(auth)) {
			String grantType = auth.getOAuth2Request().getGrantType();
			if (StringUtils.isNotEmpty(grantType) && grantType.equals("client_credentials")) {
				String clientId = auth.getOAuth2Request().getClientId();
				if (StringUtils.isNotEmpty(clientId)) {
					CacheService cacheService = CacheService.getInstance();
					Map<String, Object> clientDetailMap = cacheService.getClientInfoDetails(clientId);
					Map<String, Object> clientMap = (Map<String, Object>) clientDetailMap.get(clientId);
					ClientDetailsEntity clientDetailsEntity = (ClientDetailsEntity) clientMap.get(clientId);

					Supplier<BucketConfiguration> configurationLazySupplier = clientBucket(clientDetailsEntity);

					if (validateIpLimit(authRequestEntity, clientId, authResultEntity)) {
						LOGGER.info("validateIpLimit success");
						if (validateUrlLimit(authRequestEntity, clientId, authResultEntity)) {
							LOGGER.info("validateUrlLimit success");
							requestBucket = buckets.getProxy(clientId, configurationLazySupplier);
						} else {
							LOGGER.error("validateUrlLimit Limit Exceed");
							return false;
						}
					} else {
						LOGGER.error("validateIpLimit Limit Exceed");
						return false;
					}
				}
			} else if (StringUtils.isNotEmpty(grantType) && grantType.equals("password")) {
				if (validateAuthorizedUrl(authRequestEntity)) {
					LOGGER.info("Authorized URL Success");
					return true;
				}
				if(Objects.nonNull(authRequestEntity.getMethodSecurityMethodName())) {
					LOGGER.info("Method Name has MethodSecurity Mapping in Rate Limit class");
					return true;
				}
				
					String controllerMappingName = StringUtils.EMPTY;
					if (authRequestEntity.getControllerPath().endsWith(TokenIdentifier.FORWARD_SLASH.value())) {
						controllerMappingName = authRequestEntity.getControllerPath().substring(0, authRequestEntity.getControllerPath().length() - 1);
					}
					if (authRequestEntity.getControllerPath().startsWith(TokenIdentifier.FORWARD_SLASH.value())) {
						controllerMappingName = authRequestEntity.getControllerPath().substring(1, authRequestEntity.getControllerPath().length());
					}

					if(validateControllerMapping(authRequestEntity, controllerMappingName)) {
						return true;
					}else {
						LOGGER.error("URL Mapping failed");
						authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_controller_mapping_failed"));
						authResultEntity.setStatusCode(403);
						return false;
					}

			} else if (StringUtils.isNotEmpty(grantType) && grantType.equals("authorization_code")){
				return true;
			}

			ConsumptionProbe probe = requestBucket.tryConsumeAndReturnRemaining(1);
			Map<String, Object> headerDataMap = new HashMap<>();
			if (probe.isConsumed()) {
				headerDataMap.put("X-Sova-RL-Left", Long.toString(probe.getRemainingTokens()));
				authResultEntity.getHeaderData().putAll(headerDataMap);
				return true;
			}
			headerDataMap.put("X-Sova-RL-Reset",
					Long.toString(TimeUnit.NANOSECONDS.toMillis(probe.getNanosToWaitForRefill())));
			authResultEntity.getHeaderData().putAll(headerDataMap);
			return false;
		} else {
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_rate_limit_authentication_failed"));
			return false;
		}
	}

/**
 * Client bucket.
 *
 * @param clientDetailsEntity the individual client map
 * @return the bucket
 */
private Supplier<BucketConfiguration> clientBucket(ClientDetailsEntity clientDetailsEntity) {
	return () -> Bucket4j.configurationBuilder()
			.addLimit(Bandwidth.classic(clientDetailsEntity.getMaxLimitPerDay(),
					Refill.intervally(clientDetailsEntity.getMaxLimitPerDay(), Duration.ofDays((1)))))
			.addLimit(Bandwidth.classic(clientDetailsEntity.getMaxLimitPerHour(),
					Refill.intervally(clientDetailsEntity.getMaxLimitPerHour(), Duration.ofHours(1))))
			.addLimit(Bandwidth.classic(clientDetailsEntity.getMaxLimitPerMin(),
					Refill.intervally(clientDetailsEntity.getMaxLimitPerMin(), Duration.ofMinutes(1))))
			.addLimit(Bandwidth.classic(clientDetailsEntity.getMaxLimitPerSec(),
					Refill.intervally(clientDetailsEntity.getMaxLimitPerSec(), Duration.ofSeconds(1))))

			.buildConfiguration();
}

/**
 * User bucket.
 *
 * @return the bucket
 */
private static Bucket userBucket() {
	long maxLimitPerDay = 100;
	long maxLimitPerHour = 100;
	long maxLimitPerMin = 20;
	long maxLimitPerSec = 10;
	return Bucket4j.builder()
			.addLimit(Bandwidth.classic(maxLimitPerDay, Refill.intervally(maxLimitPerDay, Duration.ofDays((1)))))
			.addLimit(Bandwidth.classic(maxLimitPerHour, Refill.intervally(maxLimitPerHour, Duration.ofHours(1))))
			.addLimit(Bandwidth.classic(maxLimitPerMin, Refill.intervally(maxLimitPerMin, Duration.ofMinutes(1))))
			.addLimit(Bandwidth.classic(maxLimitPerDay, Refill.intervally(maxLimitPerSec, Duration.ofSeconds(1))))
			.build();
}

/**
 * Default bucket.
 *
 * @return the supplier
 */
private Supplier<BucketConfiguration> defaultBucket() {
	long maxLimitPerDay = 1;
	long maxLimitPerHour = 1;
	long maxLimitPerMin = 1;
	long maxLimitPerSec = 1;
	return () -> Bucket4j.configurationBuilder()
			.addLimit(Bandwidth.classic(maxLimitPerDay, Refill.intervally(maxLimitPerDay, Duration.ofDays((1)))))
			.addLimit(Bandwidth.classic(maxLimitPerHour, Refill.intervally(maxLimitPerHour, Duration.ofHours(1))))
			.addLimit(Bandwidth.classic(maxLimitPerMin, Refill.intervally(maxLimitPerMin, Duration.ofMinutes(1))))
			.addLimit(Bandwidth.classic(maxLimitPerDay, Refill.intervally(maxLimitPerSec, Duration.ofSeconds(1))))
			.buildConfiguration();
}

/**
 * Validate client ip access limit.
 *
 * @param authRequestEntity  the request
 * @param clientId the client id
 * @return true, if successful
 * @throws QueryException the query exception
 */
private boolean validateClientIpAccessLimit(AuthRequestEntity authRequestEntity, String clientId) throws QueryException {
	String requestIpAddress = authRequestEntity.getRemoteAddress();
	CacheService cacheService = CacheService.getInstance();
	Map<String, Object> clientIpAccessLimit = cacheService.getClientIpAccessLimit(clientId);
	Map<String, Object> individualIpLimit = (Map<String, Object>) clientIpAccessLimit.get(requestIpAddress);
	if (MapUtils.isEmpty(individualIpLimit)) {
		return true;
	}
	return false;
}

/**
 * Client ip limit bucket.
 *
 * @param individualIpLimit the individual ip limit
 * @return the supplier
 */
private Supplier<BucketConfiguration> clientIpLimitBucket(Map<String, Object> individualIpLimit) {
	long maxLimitPerDay = Long.parseLong(String.valueOf(individualIpLimit.get("max_limit_per_day")));
	long maxLimitPerHour = Long.parseLong(String.valueOf(individualIpLimit.get("max_limit_per_hour")));
	long maxLimitPerMin = Long.parseLong(String.valueOf(individualIpLimit.get("max_limit_per_min")));
	long maxLimitPerSec = Long.parseLong(String.valueOf(individualIpLimit.get("max_limit_per_sec")));
	return () -> Bucket4j.configurationBuilder()
			.addLimit(Bandwidth.classic(maxLimitPerDay, Refill.intervally(maxLimitPerDay, Duration.ofDays((1)))))
			.addLimit(Bandwidth.classic(maxLimitPerHour, Refill.intervally(maxLimitPerHour, Duration.ofHours(1))))
			.addLimit(Bandwidth.classic(maxLimitPerMin, Refill.intervally(maxLimitPerMin, Duration.ofMinutes(1))))
			.addLimit(Bandwidth.classic(maxLimitPerSec, Refill.intervally(maxLimitPerSec, Duration.ofSeconds(1))))
			.buildConfiguration();
}

/**
 * Client url limit bucket.
 *
 * @param methodData the method data
 * @return the supplier
 */
private Supplier<BucketConfiguration> clientUrlLimitBucket(Map<String, Object> methodData) {
	long maxLimitPerDay = Long.parseLong(String.valueOf(methodData.get("max_limit_per_day")));
	long maxLimitPerHour = Long.parseLong(String.valueOf(methodData.get("max_limit_per_hour")));
	long maxLimitPerMin = Long.parseLong(String.valueOf(methodData.get("max_limit_per_min")));
	long maxLimitPerSec = Long.parseLong(String.valueOf(methodData.get("max_limit_per_sec")));
	return () -> Bucket4j.configurationBuilder()
			.addLimit(Bandwidth.classic(maxLimitPerDay, Refill.intervally(maxLimitPerDay, Duration.ofDays((1)))))
			.addLimit(Bandwidth.classic(maxLimitPerHour, Refill.intervally(maxLimitPerHour, Duration.ofHours(1))))
			.addLimit(Bandwidth.classic(maxLimitPerMin, Refill.intervally(maxLimitPerMin, Duration.ofMinutes(1))))
			.addLimit(Bandwidth.classic(maxLimitPerSec, Refill.intervally(maxLimitPerSec, Duration.ofSeconds(1))))
			.buildConfiguration();
}

/**
 * Validate limit.
 *
 * @param request          the request
 * @param response         the response
 * @param clientId         the client id
 * @param authResultEntity
 * @return true, if successful
 * @throws QueryException the query exception
 */
private boolean validateIpLimit(AuthRequestEntity request, String clientId, AuthResultEntity authResultEntity)
		throws QueryException {
	String requestIpAddress = request.getRemoteAddress();
	LOGGER.info("requestIpAddress :" + requestIpAddress);
	CacheService cacheService = CacheService.getInstance();
	Map<String, Object> clientIpAccessLimit = cacheService.getClientIpAccessLimit(clientId);
	LOGGER.info("clientIpAccessLimit :" + clientIpAccessLimit);
	Map<String, Object> individualIpLimit = (Map<String, Object>) clientIpAccessLimit.get(requestIpAddress);
	LOGGER.info("individualIpLimit :" + individualIpLimit);
	if (MapUtils.isEmpty(individualIpLimit)) {
		return true;
	}

	Supplier<BucketConfiguration> configurationLazySupplier = clientIpLimitBucket(individualIpLimit);
	Bucket requestIpBucket = buckets.getProxy(requestIpAddress, configurationLazySupplier);
	ConsumptionProbe probe = requestIpBucket.tryConsumeAndReturnRemaining(1);
	Map<String, Object> headerDataMap = new HashMap<>();
	if (probe.isConsumed()) {
		headerDataMap.put("X-Sova-IP-RL-Left", Long.toString(probe.getRemainingTokens()));
		authResultEntity.getHeaderData().putAll(headerDataMap);
		return true;
	}
	headerDataMap.put("X-Sova-IP-RL-Reset",
			Long.toString(TimeUnit.NANOSECONDS.toMillis(probe.getNanosToWaitForRefill())));
	authResultEntity.getHeaderData().putAll(headerDataMap);
	return false;
}

/**
 * Validate url limit.
 *
 * @param request          the request
 * @param response         the response
 * @param clientId         the client id
 * @param authResultEntity the auth result entity
 * @return true, if successful
 * @throws QueryException the query exception
 */
private boolean validateUrlLimit(AuthRequestEntity request, String clientId, AuthResultEntity authResultEntity)
		throws QueryException {
	String requestUrl = request.getContextPath().concat(request.getRequestPath());
	LOGGER.info("requestUrl :" + requestUrl);
	String methodUrl = requestUrl.substring(request.getContextPath().length() + 1);
	LOGGER.info("methodUrl before :" + methodUrl);
	if (methodUrl.endsWith("/")) {
		methodUrl = methodUrl.substring(0, methodUrl.length() - 1);
	}
	if (methodUrl.startsWith("/")) {
		methodUrl = methodUrl.substring(1, methodUrl.length());
	}
	LOGGER.info("methodUrl after :" + methodUrl);
	String method = request.getMethodType();
	CacheService cacheService = CacheService.getInstance();
	Map<String, Object> clientUrlAccessLimit = cacheService.getClientURLAccessLimit(clientId);
	LOGGER.info("clientUrlAccessLimit:" + clientUrlAccessLimit);
	Map<String, Object> individualUrlLimit = (Map<String, Object>) clientUrlAccessLimit.get(methodUrl);
	LOGGER.info("individualUrlLimit:" + individualUrlLimit);
	if (MapUtils.isEmpty(individualUrlLimit)) {
		return true;
	} else {
		Map<String, Object> methodData = (Map<String, Object>) individualUrlLimit.get(method.toUpperCase());
		LOGGER.info("methodData:" + methodData);
		if (MapUtils.isEmpty(methodData)) {
			return true;
		}
		String key = String.valueOf(methodData.get("request_url"))
				.concat(String.valueOf(methodData.get("method_type")));
		Supplier<BucketConfiguration> configurationLazySupplier = clientUrlLimitBucket(methodData);
		Bucket requestUrlBucket = buckets.getProxy(key, configurationLazySupplier);
		ConsumptionProbe probe = requestUrlBucket.tryConsumeAndReturnRemaining(1);
		Map<String, Object> headerDataMap = new HashMap<>();
		if (probe.isConsumed()) {
			headerDataMap.put("X-Sova-URL-RL-Left", Long.toString(probe.getRemainingTokens()));
			authResultEntity.getHeaderData().putAll(headerDataMap);
			return true;
		}
		headerDataMap.put("X-Sova-URL-RL-Reset",
				Long.toString(TimeUnit.NANOSECONDS.toMillis(probe.getNanosToWaitForRefill())));
		authResultEntity.getHeaderData().putAll(headerDataMap);
		return false;
	}
}

/**
 * Validate controller mapping.
 *
 * @param request the request
 * @param response the response
 * @param methodName the method name
 * @return true, if successful
 * @throws QueryException the query exception
 */
private boolean validateControllerMapping(AuthRequestEntity request,String controllerMappingName) throws QueryException {
	CacheService cacheService = CacheService.getInstance();
	com.nn.sova.entity.ScreenDefinitionEntity definitionEntity = cacheService.getScreenDefinitionDataByLocale(request.getSid(), ContextBean.getLocale());
	String screenUrl = definitionEntity.getScreenURL();
	LOGGER.info("screen url :" + screenUrl);
	String metaControllerUrl = getControllerPath(request, screenUrl);
	LOGGER.info("metaControllerUrl :" + metaControllerUrl);
	LOGGER.info("controllerMappingName :" + controllerMappingName);

	if(metaControllerUrl.equals(controllerMappingName)) {
		LOGGER.info("screen definition mapping success");
		return true;
	}
	if(validateScreenToScreenAuthority(controllerMappingName,request)) {
		LOGGER.info("screen to screen authority success");
		return true;
	}
	LOGGER.error("Screen to screen authority failed");
	return false;
}

/**
 * Validate authorized url.
 *
 * @param request the request
 * @return true, if successful
 */
private boolean validateAuthorizedUrl(AuthRequestEntity request) {
	CacheService cacheService = CacheService.getInstance();
	AtomicReference<Boolean> status = new AtomicReference<>();
	status.set(false);
	List<String> authorizedUrlList = (List<String>) cacheService.getCacheData("authorized_url_list");
	if (CollectionUtils.isNotEmpty(authorizedUrlList)) {
		authorizedUrlList.stream().forEach(action -> {
			if (request.getRequestPath().contains(action)) {
				status.set(true);
				return;
			}
		});
	} else {
		return status.get();
	}
	return status.get();
}



/**
 * Validate screen to screen authority.
 * @param controllerUrlFromReq 
 * @param request 
 *
 * @param requestparamentity the requestparamentity
 * @return true, if successful
 * @throws QueryException the query exception
 */
private boolean validateScreenToScreenAuthority(String controllerUrlFromReq, AuthRequestEntity request) throws QueryException {
	LOGGER.info("validateScreenToScreenAuthority");
	CacheService cacheService = CacheService.getInstance();
	com.nn.sova.entity.ScreenDefinitionEntity definitionEntity = cacheService.getScreenDefinitionDataByLocale(request.getSid(), ContextBean.getLocale());
	LOGGER.info("Screen Definition entity : "+definitionEntity);
	String screenDefId = definitionEntity.getScreenDefinitionId();
	Set<String> accessibleServiceDefId = cacheService.getServiceAccessList(screenDefId);
	LOGGER.info("Cache Screen Restriction Data :" + accessibleServiceDefId);
	Set<String> controllerUrlList = new HashSet<>();
	if(CollectionUtils.isNotEmpty(accessibleServiceDefId)) {
		accessibleServiceDefId.stream().forEach(action->{
			if(action.endsWith(TokenIdentifier.FORWARD_SLASH.value())) {
				action = action.substring(START_INDEX, action.length()-FIRST_INDEX);
			}
			if(action.startsWith(TokenIdentifier.FORWARD_SLASH.value())){
				action = action.substring(FIRST_INDEX, action.length());
			}
			controllerUrlList.add(action);
		});
	}
	LOGGER.info("Screen Request Mapping List : "+controllerUrlList);
	LOGGER.info("Controller URL : "+controllerUrlFromReq);
	if(controllerUrlList.contains(controllerUrlFromReq)) {
		return true;
	}else {
		LOGGER.error("Screen to screen access Controller list does not have requested sid data");
		return false;
	}
}

/** 
 * getControllerPath is to validate the screen url.
 * 
 * @param url a screen URL
 * @return Controlle path
 */
public String getControllerPath(AuthRequestEntity request, String url){
	LOGGER.info("Screen URL From Meta :" + url);
	String controllerString = url;
	if(!Strings.isNullOrEmpty(controllerString) && !controllerString.equals(TokenIdentifier.FORWARD_SLASH.value())){
		if(controllerString.contains(TokenIdentifier.FORWARD_SLASH.value())){
			if(controllerString.endsWith(TokenIdentifier.FORWARD_SLASH.value())){
				controllerString=controllerString.substring(START_INDEX, controllerString.length()-FIRST_INDEX);
			}
			String result=controllerString.substring(START_INDEX, controllerString.lastIndexOf(TokenIdentifier.FORWARD_SLASH.value()));
			if(result.endsWith(TokenIdentifier.FORWARD_SLASH.value())){
				result=result.substring(START_INDEX, result.length()-FIRST_INDEX);
			}
			if(result.startsWith(TokenIdentifier.FORWARD_SLASH.value())){
				result=result.substring(FIRST_INDEX, result.length());
			}
			return result;
		}
		return StringUtils.EMPTY;
	}
	return StringUtils.EMPTY;
}

}
