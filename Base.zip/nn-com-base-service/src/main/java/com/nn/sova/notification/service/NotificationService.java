package com.nn.sova.notification.service;

import java.util.List;
import java.util.Map;

import com.nn.sova.nts.vo.NotificationResponse;

public interface NotificationService {

	/**
	 * 
	 * @param serviceId
	 * @param requestData
	 * @return
	 */
	List<NotificationResponse> notify(List<Map<String, Object>> notificationRequestData) throws Exception;

	/**
	 * Send SMS to the target mobile numbers.
	 * @param requestData
	 * @return
	 */
	List<NotificationResponse> notifyBySms(List<Map<String, Object>> notificationRequestData) throws Exception;

	/**
	 * Send mail to the target mailIds.
	 * @param requestData
	 * @return 
	 */
	List<NotificationResponse> notifyByMail(List<Map<String, Object>> requestData) throws Exception;
	

}
