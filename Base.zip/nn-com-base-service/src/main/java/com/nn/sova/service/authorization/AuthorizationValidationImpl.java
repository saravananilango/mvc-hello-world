package com.nn.sova.service.authorization;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.core.CacheManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.entity.RequestParamEntity;
import com.nn.sova.service.authorization.utils.AuthorizedUrl;
import com.nn.sova.service.authorization.utils.CacheMaintenance;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * AuthorizationValidationImpl performs the implementation of the various Authorization process.
 *
 * @author Vellaichamy N
 */
public class AuthorizationValidationImpl {

	/** The Constant STATUS. */
	private static final String STATUS = "status";

	/** The Constant REASON. */
	private static final String REASON = "reason";

	/** The Constant SCREEN_DEF_ID. */
	private static final String SCREEN_DEF_ID = "screenDefId";

	/** The Constant SCREEN_NAME. */
	private static final String SCREEN_NAME = "screenName";

	/** The Constant ROLE_ID. */
	private static final String ROLE_ID="roleLinkSetting.roleId";

	private static final String GROUP_ID = "roleGroupLink.groupId";

	/** The Constant SID. */
	private static final String SID = "sid";

	/** The Constant NO_AUTHORITY. */
	private static final String NO_AUTHORITY = "nn_framework_common_no_authority";

	/** The Constant SCREEN_ID. */
	private static final String SCREEN_ID = "screenConfiguration.screenId";

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(AuthorizationValidationImpl.class);

	/** The instance. */
	private static AuthorizationValidationImpl instance = null;

	/**
	 * Return the instance of the AuthorizationValidationImpl.
	 *
	 * @return instance of the AuthorizationValidationImpl
	 */
	public static AuthorizationValidationImpl getInstance(){
		if(Objects.isNull(instance)){
			instance = new AuthorizationValidationImpl();
		}
		return instance;
	}

	/**
	 * authorizeRequest verifies the AuthorizationLogic.
	 *
	 * @param requestparamentity the requestparamentity
	 * @return Map<String,Object>
	 * @throws QueryException the query exception
	 * @throws CustomException 
	 */
	public Map<String,Object> authorizeRequest(RequestParamEntity requestparamentity) throws QueryException, CustomException {
		try {
			setContextBeanData(requestparamentity);
			Map<String,Object> resultMap = new HashMap<>();
			// This is used to perform the user restriction for other screen
			Map<String, Object> screenData = new HashMap<>();
			List<String> roleList = fetchRolesByUserId(requestparamentity);
			logger.info("authorizeRequest roleList == " + roleList.size());
			CacheMaintenance cacheMaintenance = CacheMaintenance.getInstance();
			logger.info("URL : "+ requestparamentity.getUrl());
			if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getUrl())){
				resultMap.put(STATUS, true);
				String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getUrl());
				resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
				resultMap.put(SID, screenId);
				return resultMap;
			}

			if(StringUtils.isNotEmpty(requestparamentity.getUserId()) && StringUtils.isNotEmpty(requestparamentity.getTenantId())
					&& StringUtils.isNotEmpty(requestparamentity.getSid())){

				// Get the service data based on screen id
				screenData = cacheMaintenance.getScreenInfoFromCache(requestparamentity.getSid(), requestparamentity.getLocale());
				logger.info("Screen Data :" + screenData);

				// Check the screen id matches from request param and cache 
				if(MapUtils.isNotEmpty(screenData)){
					if(Objects.nonNull(screenData.get("screenConfiguration.productCode"))) {
						String subProductCode = String.valueOf(screenData.get("screenConfiguration.productCode"));
						List<String> tenantList = cacheMaintenance.getProductTenantConfigDetails(subProductCode);
						// Check the tenant id availed in cache or not
						if(CollectionUtils.isNotEmpty(tenantList) && !tenantList.contains(requestparamentity.getTenantId())){
							resultMap.put(STATUS, false);
							resultMap.put(REASON, MessageImplementation.getInstance().getMessageData("nn_authorized_tenant_list_empty"));
							return resultMap;
						}
					}
				}else {
					resultMap.put(STATUS, false);
					if(MapUtils.isEmpty(screenData)) {
						resultMap.put(REASON, MessageImplementation.getInstance().getMessageData("nn_screen_information_missing"));
					}else {
						resultMap.put(REASON, MessageImplementation.getInstance().getMessageData("invalid_servlet_and_screen_url_path"));
					}
					return resultMap;
				}
			}
			else {
				resultMap.put(STATUS, false);
				resultMap.put(REASON, MessageImplementation.getInstance().getMessageData("nn_locale_tenant_missing"));
				logger.error("authorizeRequest locale_tenant_missing");
			}
			// Validate the user role list and gives the permission as full authority and partial authority 
			if(CollectionUtils.isNotEmpty(roleList)){
				validateAuthority(requestparamentity, resultMap, screenData, roleList);
			}else{
				setScreenIdForAuthorizedUrl(requestparamentity, resultMap, screenData);
			}
			return resultMap;
		}catch(Exception exception) {
			logger.error(exception);
			throw new CustomException(exception);
		}
	}

	/**
	 * Sets the context bean data.
	 *
	 * @param requestParamEntity the new context bean data
	 */
	private void setContextBeanData(RequestParamEntity requestparamentity){
		ContextBean.remove();
		ContextBean.setTenantId(requestparamentity.getTenantId());
		ContextBean.setLocale(requestparamentity.getLocale());
	}

	/**
	 * This method used to get the roles list of the user from cache.
	 *
	 * @param requestparamentity has info about sid,url and servlet path info etc
	 * @return Roles List for the user
	 * @throws QueryException the query exception
	 */
	public  List<String> fetchRolesByUserId(RequestParamEntity requestparamentity) throws QueryException{
		CacheMaintenance cacheMaintenance=CacheMaintenance.getInstance();
		List<Map<String, Object>> roleLinkData;
		// Getting the roles linked by user
		roleLinkData = cacheMaintenance.getRoleLinkInfoFromCache(requestparamentity.getUserId(),requestparamentity.getTenantId());
		if(Objects.nonNull(roleLinkData) && CollectionUtils.isNotEmpty(roleLinkData)){
			return roleLinkData.stream().filter(predicate->Objects.nonNull(predicate.get(ROLE_ID)))
					.filter(predicate-> {
						try {
							// Getting the role information from role definition view
							return Objects.nonNull(cacheMaintenance.getRoleInfoFromCache(predicate.get(ROLE_ID).toString(),requestparamentity.getTenantId()));
						} catch (QueryException queryException) {
							logger.error(queryException);
						}
						return false;
					}
							).map(mapper->mapper.get(ROLE_ID).toString()).collect(Collectors.toList());
		}else{
			return new ArrayList<>();
		}
	}

	/**
	 * This method is used to get the Role details map.
	 *
	 * @param roleList the role list
	 * @param tenantId the tenant id
	 * @return Role Details returned as map
	 * @throws Exception 
	 */
	public Map<String,Object> getRoleDetails(List<String> roleList,String tenantId) throws Exception{
		Map<String, Object> roleDetailsMap=new HashMap<>();
		CacheMaintenance cacheMaintenance=CacheMaintenance.getInstance();
		List<String> groupId=new ArrayList<>();
		try {
			AtomicReference<Boolean> fullAuthority = new AtomicReference<>();
			fullAuthority.set(false);
			roleList.stream().forEach(role->{
				List<Map<String, Object>> roleDataList;
				try {
					roleDataList = cacheMaintenance.getRoleInfoFromCache(role,tenantId);
					logger.info("Role Data List Size: "+ roleDataList.size());
				} catch (QueryException exception) {
					logger.error(exception);
					throw new RuntimeException(exception);
				}

				if(CollectionUtils.isNotEmpty(roleDataList)) {
					roleDataList.stream().forEach(roleDataMap->{
						logger.info(roleDataMap);
						if(Objects.nonNull(String.valueOf(roleDataMap.get("roleSetting.isFullAuthority"))) && 
								BooleanUtils.isTrue(Boolean.parseBoolean(String.valueOf(roleDataMap.get("roleSetting.isFullAuthority"))))){
							logger.info("Full Authority Set : "+ fullAuthority.get());
							fullAuthority.set(true);
						}
						logger.info("Group Id :"+ roleDataMap.get(GROUP_ID));
						groupId.add(String.valueOf(roleDataMap.get(GROUP_ID)));
					});
				}
			});
			logger.info("Full Authority : "+ fullAuthority.get());
			roleDetailsMap.put("fullAuthorityStatus", fullAuthority.get());
			roleDetailsMap.put("groupIdList", groupId);
			logger.info("Role Details Map : "+ roleDetailsMap);
			return roleDetailsMap;
		}catch(Exception exception) {
			logger.error(exception);
			throw new Exception();
		}
	}

	/**
	 * Getting the screen data based on screen id and locale.
	 *
	 * @param screenId the screen id
	 * @param locale the locale
	 * @return Screen data returned as map
	 * @throws QueryException the query exception
	 */
	public Map<String,Object> getScreenData(String screenId,String locale) throws QueryException{
		CacheMaintenance cacheMaintenance=CacheMaintenance.getInstance();
		Map<String, Object> screenDataMap;
		screenDataMap = cacheMaintenance.getScreenInfoFromCache(screenId, locale);
		if(MapUtils.isNotEmpty(screenDataMap)){
			return screenDataMap;
		}
		return new HashMap<>();
	}



	/**
	 * This method is used to get the screen name from screen configuration .
	 *
	 * @param screenId the screen id
	 * @param locale the locale
	 * @param screenData has info about screen id,screen name etc
	 * @return ScreenName
	 * @throws QueryException the query exception
	 */
	public String getScreenNameFromCfg(String screenId,String locale, Map<String, Object> screenData) throws QueryException{
		if(MapUtils.isNotEmpty(screenData) && Objects.toString(screenData.get(SCREEN_ID), "").equals(screenId)){
			return Objects.toString(screenData.get(SCREEN_NAME), "");
		}else{
			Map<String,Object> screenDataMap=getScreenData(screenId, locale);
			if(MapUtils.isNotEmpty(screenDataMap)){
				return Objects.nonNull(screenDataMap.get(SCREEN_NAME))?String.valueOf(screenDataMap.get(SCREEN_NAME)):StringUtils.EMPTY;
			}else{
				return StringUtils.EMPTY;
			}
		}
	}

	//	/**
	//	 * checkScreenUrlWithMetaData method is used to validate the servlet URL with screen configuration URL.
	//	 *
	//	 * @param screenDataMap has screen info about scren id,screen name etc
	//	 * @param requestparamentity has info about sid,url and servlet path info etc
	//	 * @return status returned as boolen
	//	 * @throws QueryException 
	//	 */
	//	public boolean checkScreenUrlWithMetaData(Map<String,Object> screenDataMap,RequestParamEntity requestparamentity) throws QueryException{
	//		if(MapUtils.isNotEmpty(screenDataMap)){
	//			if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getServletPath())) {
	//				return true;
	//			}
	//		}
	//		return false;
	//	}

	/**
	 * This method is used to validate the screen id.
	 *
	 * @param requestparamentity has info about sid,url and servlet path info etc
	 * @param screenData the screen data
	 * @return Screen Name and Status returned as map
	 * @throws QueryException the query exception
	 */
	public Map<String,Object> isScreenIdValid(RequestParamEntity requestparamentity, Map<String, Object> screenData) throws QueryException{
		Map<String,Object> resultMap=new HashMap<>();
		if(StringUtils.isNotEmpty(requestparamentity.getSid())){
			Map<String,Object> screenDataMap;
			if(MapUtils.isNotEmpty(screenData) && Objects.toString(screenData.get(SCREEN_ID), "").equals(requestparamentity.getSid())){
				screenDataMap=new HashMap<>(screenData);
			}else{
				screenDataMap=getScreenData(requestparamentity.getSid(), requestparamentity.getLocale());
			}
			if(MapUtils.isNotEmpty(screenDataMap)){
				Boolean screenAdminFlag = Boolean.parseBoolean(String.valueOf(screenDataMap.get("screenConfiguration.isAdmin")));
				logger.info("screenAdminFlag :" + screenAdminFlag);
				if(screenAdminFlag) {
					Map<String, Object> userCacheMap = 
							CacheService.getInstance().getUserDataByTenantId(requestparamentity.getUserId(), 
									requestparamentity.getTenantId());
					Boolean adminUserFalg = Boolean.parseBoolean(String.valueOf(userCacheMap.get("admin_user_flag")));
					
					logger.info("adminUserFalg :" + adminUserFalg);
					
					if(adminUserFalg) {
						resultMap.put(STATUS,true);
						resultMap.put(SCREEN_DEF_ID, screenDataMap.get("screenConfiguration.screenDefId"));
						resultMap.put(SCREEN_NAME,  screenDataMap.get("screenConfigurationText.screenName"));
						return resultMap;
					}else {
						resultMap.put(STATUS,false);
						resultMap.put(SCREEN_DEF_ID, screenDataMap.get("screenConfiguration.screenDefId"));
						resultMap.put(SCREEN_NAME,  screenDataMap.get("screenConfigurationText.screenName"));
						return resultMap;
					}
				}
				resultMap.put(STATUS,true);
				resultMap.put(SCREEN_DEF_ID, screenDataMap.get("screenConfiguration.screenDefId"));
				resultMap.put(SCREEN_NAME,  screenDataMap.get("screenConfigurationText.screenName"));
			}else{
				resultMap.put(STATUS, false);
			}
		}else{
			resultMap.put(STATUS, false);
		}
		return resultMap;
	}

	/**
	 * Validate the screen role is used to validate the screen access role list.
	 *
	 * @param groupIdList an user role list
	 * @param sid an screen id
	 * @param tenantId the tenant id
	 * @return Status returned as boolean
	 */
	public  boolean validScreenRole(List<String> groupIdList,String sid,String tenantId) {
		CacheMaintenance cacheMaintenance=CacheMaintenance.getInstance();
		return groupIdList.stream().anyMatch(predicate->{
			List<Map<String, Object>> roleLinkMap = null;
			try {
				roleLinkMap = cacheMaintenance.getScreenRoleLinkInfoFromCache(predicate,tenantId);
				logger.info("Screen Role Link Data :" + roleLinkMap);
			} catch (QueryException queryException) {
				logger.error(queryException);
			}
			if(CollectionUtils.isNotEmpty(roleLinkMap)){
				return roleLinkMap.stream().anyMatch(match->match.get("screenRoleSetting.screenId").toString().equals(sid));
			}
			return false;
		});
	}





	/**
	 * setScreenIdForAuthorizedUrl will set the Screen Id for the authorized URL.
	 *
	 * @param requestparamentity has info about sid,url and servlet path info etc
	 * @param resultMap the result map
	 * @param screenData getting from cache it has screen info
	 * @throws QueryException the query exception
	 */
	private void setScreenIdForAuthorizedUrl(RequestParamEntity requestparamentity, Map<String, Object> resultMap,
			Map<String, Object> screenData) throws QueryException {
		if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getUrl())){

			resultMap.put(STATUS, true);
			String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getUrl());
			resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
			resultMap.put(SID, screenId);
		}else if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getRefferelUrl())){
			resultMap.put(STATUS, true);
			String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getRefferelUrl());
			resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
			resultMap.put(SID, screenId);
		}else{
			resultMap.put(STATUS, false);
			resultMap.put(REASON, MessageImplementation.getInstance().getMessageData(NO_AUTHORITY));
		}
	}


	/**
	 * Validate the user role list and gives the permission as full authority and partial authority .
	 *
	 * @param requestparamentity has info about sid,url and servlet path info etc
	 * @param resultMap the result map
	 * @param screenData getting from cache it has screen info
	 * @param roleList has list of role info about user
	 * @throws Exception 
	 */
	private void validateAuthority(RequestParamEntity requestparamentity, Map<String, Object> resultMap,
			Map<String, Object> screenData, List<String> roleList) throws Exception {
		logger.info("Validate Authority Role List Size: "+ roleList.size());
		Map<String,Object> roleDetailsMap = getRoleDetails(roleList,requestparamentity.getTenantId());
		logger.info("Role Info : "+ roleDetailsMap);
		if(Boolean.parseBoolean(String.valueOf(roleDetailsMap.get("fullAuthorityStatus")))){
			fullAuthoritySessionAuthorization( requestparamentity, resultMap,screenData);
			resultMap.put("fullAuthority", true);
		}else{
			String productCode = String.valueOf(screenData.get("screenConfiguration.productCode"));
			List<String> roleListForProductCode = getRolesForProductCode(productCode, requestparamentity);
			logger.info("Roles List for product code :" + roleListForProductCode);
			if(CollectionUtils.isNotEmpty(roleListForProductCode)) {
				if(CollectionUtils.containsAny(roleList, roleListForProductCode)) {
					logger.info("Roles inside product code");
					resultMap.put(STATUS, true);
					resultMap.put(SID, requestparamentity.getSid());
					resultMap.put("fullAuthority", false);
				}else {
					logger.info("group id check starts for partial authority");
					List<String> groupIdList=(List<String>) roleDetailsMap.get("groupIdList");
					partialAuthoritySessionAuthorization(requestparamentity, resultMap,groupIdList,screenData);
					resultMap.put("fullAuthority", false);	
				}
			}else {
				logger.info("group id check starts");
				List<String> groupIdList=(List<String>) roleDetailsMap.get("groupIdList");
				partialAuthoritySessionAuthorization(requestparamentity, resultMap,groupIdList,screenData);
				resultMap.put("fullAuthority", false);	
			}
		}
	}

	/**
	 * Gets the roles for product code.
	 *
	 * @param productCode the product code
	 * @param requestParamEntity the request param entity
	 * @return the roles for product code
	 * @throws QueryException 
	 */
	public List<String> getRolesForProductCode(String productCode,RequestParamEntity requestParamEntity) throws QueryException {
		String cacheKey = String.valueOf(requestParamEntity.getTenantId()).concat("_").concat(productCode).concat("_authority_role_list");
		Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.isNull(cacheKeyExistData)) {
			updateRolesForProductCode(productCode,requestParamEntity,cacheKey);
		}
		cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		return (List<String>) cacheKeyExistData;
	}

	/**
	 * Update roles for product code.
	 *
	 * @param productCode the product code
	 * @param requestParamEntity the request param entity
	 * @param cacheKey the cache key
	 * @throws QueryException the query exception
	 */
	private void updateRolesForProductCode(String productCode, RequestParamEntity requestParamEntity, String cacheKey) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		com.nn.sova.querybuilder.SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String, Object>> productCodeAuthorityData = selectQueryBuilder.distinct().get("role_id").from("product_code_authority_view").
				where(ConditionBuilder.instance().eq("product_code", productCode)).build(false).execute();
		List<String> roleList = new ArrayList<String>();
		roleList = productCodeAuthorityData.stream().map(map->String.valueOf(map.get("role_id"))).collect(Collectors.toList());
		if(CollectionUtils.isNotEmpty(roleList)) {
			CacheService.getInstance().saveToCache(cacheKey, roleList);
		}else {
			CacheService.getInstance().saveToCache(cacheKey, new ArrayList<String>());
		}
	}

	/**
	 * Gives the full authority.
	 *
	 * @param requestparamentity has info about sid,url and servlet path info etc
	 * @param resultMap the result map
	 * @param screenData getting from cache it has screen info
	 * @throws QueryException the query exception
	 */
	private void fullAuthoritySessionAuthorization(RequestParamEntity requestparamentity,Map<String,Object> resultMap, Map<String, Object> screenData) throws QueryException{
		logger.info("fullAuthoritySessionAuthorization inside");
		if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getServletPath())){
			logger.info("servelet path inside");
			resultMap.put(STATUS, true);
			String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getServletPath());
			resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
			resultMap.put(SID, screenId);

		}else if( AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getRefferelUrl())){
			logger.info("referrel url inside");
			resultMap.put(STATUS, true);
			if(StringUtils.isNotEmpty(requestparamentity.getSid())){
				resultMap.put(SCREEN_NAME, getScreenNameFromCfg(requestparamentity.getSid(),requestparamentity.getLocale(),screenData));
				resultMap.put(SID, requestparamentity.getSid());
			}else{
				// get the screen id for the authorized URL 
				logger.error("invalid screen id");
				String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getRefferelUrl());
				resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
				resultMap.put(SID, screenId);
			}
		}else{
			Map<String,Object> sidStatusMap = isScreenIdValid(requestparamentity,screenData);
			if(Boolean.parseBoolean(sidStatusMap.get(STATUS).toString())){
				resultMap.put(STATUS, true);
				resultMap.put(SCREEN_NAME, sidStatusMap.get(SCREEN_NAME).toString());
				resultMap.put(SID, requestparamentity.getSid());
			}else{
				logger.error("invalid screen id data");
				resultMap.put(STATUS, false);
				resultMap.put(REASON, MessageImplementation.getInstance().getMessageData(NO_AUTHORITY));
			}
		}

	}

	/**
	 * Gives the partial authority.
	 *
	 * @param requestparamentity has info about sid,url and servlet path info etc
	 * @param resultMap the result map
	 * @param groupIdList the group id list
	 * @param screenData getting from cache it has screen info
	 * @throws QueryException the query exception
	 */
	private void partialAuthoritySessionAuthorization(RequestParamEntity requestparamentity,Map<String,Object> resultMap,
			List<String> groupIdList, Map<String, Object> screenData) throws QueryException{
		logger.info("partialAuthoritySessionAuthorization inside");
		if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getServletPath())){
			logger.info("servelet path inside");
			String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getServletPath());
			resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
			resultMap.put(SID, screenId);
			resultMap.put(STATUS, true);
		}else if(AuthorizedUrl.getInstance().isAuthorizedUrl(requestparamentity.getRefferelUrl())){
			logger.info("referrel url inside");
			if(StringUtils.isNotEmpty(requestparamentity.getSid())){
				resultMap.put(SCREEN_NAME, getScreenNameFromCfg(requestparamentity.getSid(),requestparamentity.getLocale(),screenData));
				resultMap.put(SID, requestparamentity.getSid());
			}else{
				String screenId = AuthorizedUrl.getInstance().getScreenId(requestparamentity.getRefferelUrl());
				resultMap.put(SCREEN_NAME, getScreenNameFromCfg(screenId,requestparamentity.getLocale(),screenData));
				resultMap.put(SID, screenId);
			}
			resultMap.put(STATUS, true);
		}else{
			Map<String,Object> sidStatusMap=isScreenIdValid(requestparamentity,screenData);
			if(Boolean.parseBoolean(sidStatusMap.get(STATUS).toString())){
				// Check whether requested user role has access for Screen 
				if(validScreenRole(groupIdList, requestparamentity.getSid(),requestparamentity.getTenantId())){
					resultMap.put(STATUS, true);
					resultMap.put(SCREEN_NAME, sidStatusMap.get(SCREEN_NAME).toString());
					resultMap.put(SID, requestparamentity.getSid());
				}else{
					logger.error("screen id not mapped with group id");
					resultMap.put(STATUS, false);
					resultMap.put(REASON, MessageImplementation.getInstance().getMessageData(NO_AUTHORITY));
				}
			}else{
				logger.error("invalid screen id in request");
				resultMap.put(STATUS, false);
				resultMap.put(REASON, MessageImplementation.getInstance().getMessageData(NO_AUTHORITY));
			}
		}

	}
}
