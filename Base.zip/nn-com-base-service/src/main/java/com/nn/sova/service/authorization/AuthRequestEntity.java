package com.nn.sova.service.authorization;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

/**
 * Instantiates a new auth request entity.
 * 
 * @author Vellaichamy N
 */
@Data
public class AuthRequestEntity {
	
	/** The query params. */
	private Map<String, String> queryParams;
	
	/** The headers. */
	private Map<String, String> headers = new HashMap<>();
	
	/** The request path. */
	private String requestPath;
	
	/** The server name. */
	private String serverName;
	
	/** The remote address. */
	private String remoteAddress;
	
	/** The context path. */
	private String contextPath;
	
	/** The method type. */
	private String methodType;
	
	/** The sid. */
	private String sid;
	
	/** The controller path. */
	private String controllerPath;
	
	/** The method security method name. */
	private String methodSecurityMethodName;
	
	/** The method security entity obj. */
	private String methodSecurityEntityObj;
	
	private String defaultTenantId;
}
