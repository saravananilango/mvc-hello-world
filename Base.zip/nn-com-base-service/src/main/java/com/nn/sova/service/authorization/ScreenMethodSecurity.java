package com.nn.sova.service.authorization;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.utils.CacheMaintenance;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class ScreenMethodSecurity.
 * 
 * @author vellaichamy
 */
public class ScreenMethodSecurity {

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(AuthorizationValidationImpl.class);

	
	/**
	 * Gets the service data.
	 *
	 * @param screenId the screen id
	 * @param requestUrl the request url
	 * @return the service data
	 * @throws QueryException the query exception
	 */
	public boolean validateDisabledMethod(String screenId,String requestUrl) throws QueryException {
		String locale;
		if(StringUtils.isEmpty(screenId)) {
			return false;
		}

		if(Objects.isNull(ContextBean.getLocale())) {
			locale = "en";
		}else {
			locale = ContextBean.getLocale();
		}

		Map<String,Object> screenDataMap = CacheMaintenance.getInstance().getScreenInfoFromCache(screenId, locale);
		logger.info("Screen Data Map for screen method security :" + screenDataMap);
		String screenDefId = String.valueOf(screenDataMap.get("screenConfiguration.screenDefId"));

		if(StringUtils.isEmpty(screenDefId)) {
			return false;
		}

		List<Map<String,Object>> screenComponentList = 
		CacheService.getInstance().getDataElementByScreenInfo(screenDefId, screenId, locale);

		List<Map<String,Object>> requestUrlComponent = screenComponentList.stream().filter(predicate-> 
		String.valueOf(predicate.get("method_name")).equals(requestUrl)).collect(Collectors.toList());

		logger.info("requestUrlComponent :" + requestUrlComponent);
		
		if(CollectionUtils.isNotEmpty(requestUrlComponent)) {
			boolean disabledFlag = Boolean.parseBoolean(String.valueOf(requestUrlComponent.get(0).get("disabled")));
			if(disabledFlag) {
				return false;
			}
		}else
		{
			return true;
		}
		return false;
	}
}
