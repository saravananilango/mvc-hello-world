package com.nn.sova.notification.factory.sms;

import org.apache.commons.lang.StringUtils;

import com.nn.sova.notification.gateway.service.NtsGatewayService;
import com.nn.sova.notification.gateway.sms.NtsGatewayQikBerryServiceImpl;
import com.nn.sova.notification.gateway.sms.NtsSmsGatewayService;


public class NtsSmsGatewayFactory extends NtsSmsGatewayService {

	@Override
	public NtsGatewayService getGatewayInstance(String gatewayId) {
		if (StringUtils.isEmpty(gatewayId)) {
			return null;
		}
		switch (gatewayId) {
		case "GTW_01":
			return NtsGatewayQikBerryServiceImpl.getInstance();
		default:
			return null;
		}
	}

}
