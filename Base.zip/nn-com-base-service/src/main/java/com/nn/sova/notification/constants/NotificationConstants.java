package com.nn.sova.notification.constants;

import java.util.Arrays;
import java.util.List;

public class NotificationConstants {
	
	public static final String NN_NOTFICATION_TABLE_NAME = "nts_transaction_web_notification";
	
	public static final String NN_NOTFICATION_MST_TABLE_NAME = "notification_mst";
	
	public static final String NN_NOTFICATION_MST_TEXT_TABLE_NAME = "notification_mst_text";
	
	public static final String NN_NOTFICATION_USER_TABLE_NAME = "notification_user";
	
	public static final String MAIL_DOMAIN_SETTINGS_TBL = "mail_domain_settings";
	
	public static final String MAIL_SETTINGS_TBL = "mail_settings";
	
	public static final String MAIL_DETAILS_TBL = "mail_details";
	
	public static final String MAIL_LIMIT_TBL = "mail_limit";
	
	public static final String MAIL_SERIVCE_DEF_ID_COLUMN = "mail_service_def_id";
	
	public static final String MAIL_NAME_COLUMN = "mail_name";
	
	public static final String MAIL_SUCCESS_STATUS = "success";
	
	public static final String MAIL_FAILURE_STATUS = "failed";
	
	public static final String MAIL_FAILURE_MESSAGE_SUBJECT = "Mail failed to send. Subject or body is not available";
	
	public static final String MAIL_FAILURE_MESSAGE_SERVICE_DEF_ID = "Mail failed to send. Service Def id or mail name not available";
	
	public static final String MAIL_FAILURE_MESSAGE_LIMIT_EXCEED = "Mail failed to send. User daily mail limit exceeded";
	
	public static final List<String> NOTIFICATION_TEMPLATE_IDS = Arrays.asList("default_template_title","default_template_text","mail_template_subject","mail_template_body");
	
	public static final List<String> NOTIFICATION_DIRECT_TEMPLATE_IDS = Arrays.asList("title","text","mail_subject","mail_body","message");
	
	public static final List<String> IMAGE_SUPPORTED_PATH_TYPES = Arrays.asList("static","uploads","complete");
	
	// table Name
	public static final String NTS_HANDLER_MST_TABLE = "nts_handler_mst";
	public static final String NTS_HANDLER_DEF_TABLE = "nts_handler_def";
	public static final String NTS_GATEWAY_HANDLER_LINK_TABLE = "nts_gateway_handler_link";
	public static final String NTS_ALERT_DEF_TABLE = "nts_alert_def";
	public static final String NTS_ALERT_SERVICE_DEF_TABLE = "nts_alert_service_def";
	public static final String NTS_USER_DEF_TABLE = "nts_user_def";
	public static final String USER_ACCOUNT_TABLE = "user_account";
	public static final String NTS_TRASNACTION_WEB_NOTIFICATION_TABLE = "nts_transaction_web_notification";
	
	//column name
	public static final String USER_ID_COLUMN = "user_id";
	public static final String SERVICE_ID_COLUMN = "service_id";
	public static final String NOTIFICATION_ID_COLUMN = "notification_id";
	public static final String READ_COLUMN = "read";
	public static final String SCREEN_DEF_ID_COLUMN = "screen_def_id";
	public static final String HANDLER_FETCH_TYPE_COLUMN = "fetch_type";
	public static final String HANDLER_LABEL_COLUMN = "handler_label";	
	public static final String HANDLER_ID_COLUMN = "handler_id";
	public static final String ALERT_ID_COLUMN = "alert_id";
	public static final String EMAIL_ID = "email_id";
	public static final String PHONE_NUMBER = "phone_number";
	
	
	//keys
	public static final String HANDLER_FETCH_DEFAULT = "Default";
	public static final String SCREEN_DEF_ID_KEY = "screen_def_id";
	public static final String HANDLER_ID_KEY = "handler_id";
	
	//Gateway HTTP  Constants
	public static final String HTTP_HEADER_NAME = "accept";
	public static final String HTTP_HEADER_APPLICATION_JSON = "application/json";
	public static final String FAILED_CODE_MESSAGE = "Failed : HTTP error code : ";
	
	public static final int NOTIFICATION_DEFAULT_FETCH_LIMIT = 50;
	public static final String IMAGE_PATH_TYPE_KEY = "image_path_type";
	public static final String IMAGE_URL_KEY = "image_url";
	
	public static final String NN_IMAGE_FRONT_CONTEXT_PATH = "nn-fw-images-front";
	public static final String BACK_SLASH = "/";
	public static final String IMAGE_STATIC_PATH_TYPE = "static";
	public static final String IMAGE_UPLOADS_PATH_TYPE = "uploads";
	public static final String IMAGE_COMPLETE_PATH_TYPE = "complete";
	
	public static final String MAIL_CONTENT_TYPE_PLAIN_KEY = "plain";
	public static final String MAIL_CONTENT_TYPE_HTML_KEY = "html";
	public static final String MAIL_CONTENT_TYPE_PLAIN = "text/plain";
	public static final String MAIL_CONTENT_TYPE_HTML = "text/html";
	public static final String MAIL_CHARSET_UTF_8 = "charset=utf-8";
	
	public static final String NOTIFICATION_SMS_QUEUE_NAME = "sova_nts_sms_queue";
	public static final String NOTIFICATION_MAIL_QUEUE_NAME = "sova_nts_mail_queue";
	public static final String NOTIFICATION_FCM_QUEUE_NAME = "sova_nts_fcm_queue";
	public static final String NOTIFICATION_RABBIT_MQ_EXCHANGE = "sova_nts_exchange";
	public static final String ROUTING_KEY_SMS = "sms";
	public static final String ROUTING_KEY_MAIL = "mail";
	public static final String ROUTING_KEY_FCM = "fcm";
	
	public static final String FCM_IDS_KEY = "fcm_ids";
	public static final String USER_ID_KEY = "user_id";
	public static final String ALERT_ID_KEY = "alert_id";
	
	public static final String ATTACHMENTS = "attachments";
	public static final String CC = "cc";
	public static final String BCC = "bcc";
	public static final String TO = "to";
}
