package com.nn.sova.service.authorization.entity;

import lombok.Data;

/**
 * RequestParamEntity class defines the param Object.
 *
 * @author Vellaichamy N
 */

@Data
public class RequestParamEntity {

	/**  The userId. */
	private String userId;

	/**  The screen Id. */
	private String sid;

	/**  The url. */
	private String url;

	/**  The servlet path. */
	private String servletPath;

	/**  The Context path. */
	private String contextPath;

	/**  The Refferer Url. */
	private String refferelUrl;

	/**  The locale. */
	private String locale;

	/**  The tenantId. */
	private String tenantId;

	/**  The isRedirectScreen. */
	private boolean isRedirectScreen;

	/**  The isAjaxRequest. */
	private boolean isAjaxRequest;
	
	/**  The queryString. */
	private String queryString;

	/**  The processId. */
	private String processId;
	

	/**  The requestId. */
	private String requestId;
	

	/**  The ipAddress. */
	private String ipAddress;
	

	/**  The browser. */
	private String browser;
	

	/**  The operatingSystem. */
	private String operatingSystem;
	


}
