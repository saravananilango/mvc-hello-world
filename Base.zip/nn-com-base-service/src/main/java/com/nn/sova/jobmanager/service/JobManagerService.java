package com.nn.sova.jobmanager.service;

import static com.nn.sova.utility.jobmanager.utils.JobManagerUtils.isEmptyList;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.jobmanager.entity.JobHistory;
import com.nn.sova.utility.jobmanager.exception.JobRuntimeException;
import com.nn.sova.utility.logger.ApplicationLogger;

public class JobManagerService {
	
	private static JobManagerService instance = null;
	
	private JobManagerService() {
		
	}
	
	private static final String JOB_HISTORY_ID = "job_history_id";
	private static final String JOB_HISTORY = "job_history";
	
	public static JobManagerService getInstance() {
		if(instance == null) {
			instance =  new JobManagerService();
		}
		return instance;
	}
	
	private static final ApplicationLogger LOGGER = ApplicationLogger.create(JobManagerService.class);
	
	/**
	 * Returns the status of the job.
	 * @param jobHistoryId
	 * @return
	 */
	public JobHistory getJobHistory(UUID jobHistoryId) {
		Objects.requireNonNull(jobHistoryId, "jobHistoryId is Required");
		try {
			List<Map<String, Object>> resultList = new QueryBuilder().btSchema()
				.select().from(JOB_HISTORY)
				.where(ConditionBuilder
						.instance().eq(JOB_HISTORY_ID, jobHistoryId))
				.build(false)
				.execute();
			if (isEmptyList(resultList)) {
				return null;
			}
			return resultList.stream()
				.map(JobHistory::fromMap)
				.collect(Collectors.toList()).stream().findFirst().get();
			
		} catch (QueryException exception) {
			LOGGER.error("Failed to select from {} table, error = {}",
					JOB_HISTORY,
					exception.getMessage());
			throw new JobRuntimeException(exception);
		}
	}

}
