package com.nn.sova.service.utils.flowlog;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.message.ObjectMessage;

/**
 * Send the logs to AWS cloudwatch logs (default logger)
 * 
 * @author Vignesh R
 *
 */
public class AppGenAWSFlowLogger implements AppGenFlowLogger {

	private static final Logger FLOW_LOGGER = LogManager.getLogger("flowlog");

	@Override
	public void sendLog(Map<String, String> logMap) {
		FLOW_LOGGER.info(new ObjectMessage(logMap));
	}

}
