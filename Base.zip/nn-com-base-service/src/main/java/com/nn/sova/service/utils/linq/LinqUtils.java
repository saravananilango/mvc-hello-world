package com.nn.sova.service.utils.linq;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import org.apache.calcite.jdbc.CalciteConnection;
import org.apache.calcite.jdbc.Driver;
import org.apache.calcite.schema.SchemaPlus;
import org.apache.calcite.util.Source;
import org.apache.commons.io.input.ReaderInputStream;
import org.checkerframework.checker.nullness.qual.Nullable;

import com.google.common.io.CharSource;
import com.nn.sova.service.utils.linq.*;
import com.nn.sova.utility.json.JsonUtils;

public class LinqUtils {

	/**
	 * Result set to array list.
	 *
	 * @param rs the rs
	 * @return the list
	 * @throws SQLException the SQL exception
	 */
	public static List<Map<String, Object>> resultSetToArrayList(ResultSet rs) throws SQLException {
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>(50);
		list.toArray();
		while (rs.next()) {
			Map<String, Object> row = new HashMap<String, Object>(columns);
			for (int i = 1; i <= columns; ++i) {
				row.put(md.getColumnName(i), rs.getObject(i));
			}
			list.add(row);
		}

		return list;
	}

	/**
	 * The Class GuavaCharSource.
	 */
	static class GuavaCharSource implements Source {
		private final CharSource charSource;

		private GuavaCharSource(CharSource charSource) {
			this.charSource = Objects.requireNonNull(charSource, "charSource");
		}

		private UnsupportedOperationException unsupported() {
			return new UnsupportedOperationException(
					String.format(Locale.ROOT, "Invalid operation for '%s' protocol", protocol()));
		}

		@Override
		public URL url() {
			throw unsupported();
		}

		@Override
		public File file() {
			throw unsupported();
		}

		@Override
		public String path() {
			throw unsupported();
		}

		@Override
		public Reader reader() throws IOException {
			return charSource.openStream();
		}

		@Override
		public InputStream openStream() throws IOException {
			return new ReaderInputStream(reader(), StandardCharsets.UTF_8);
		}

		@Override
		public String protocol() {
			return "memory";
		}

		@Override
		public Source trim(final String suffix) {
			throw unsupported();
		}

		@Override
		public @Nullable Source trimOrNull(final String suffix) {
			throw unsupported();
		}

		@Override
		public Source append(final Source child) {
			throw unsupported();
		}

		@Override
		public Source relative(final Source source) {
			throw unsupported();
		}

		@Override
		public String toString() {
			return getClass().getSimpleName() + "{" + protocol() + "}";
		}
	}
	public static List<Map<String, Object>> getLinqResult(List<List> list,List<String> tableName,String query) {
		final Driver driver = new Driver();
		CalciteConnection connection;
		final ResultSet resultSet;
		try {
		Properties info = new Properties();
		info.setProperty("lex", "JAVA");
		connection = (CalciteConnection) driver.connect("jdbc:calcite:", info);
		SchemaPlus rootSchema = connection.getRootSchema();
		int count=list.size();
        String StringValue[]=new String[count];
        Source charSource[]=new GuavaCharSource[count];
        JsonScannableTable JsonTable[] = new JsonScannableTable[count];
		if(list.size()==tableName.size()) {
			for(int i=0;i<count;i++) {
				StringValue[i]=JsonUtils.toJsonOrEmpty(list.get(i));
				charSource[i]=  new GuavaCharSource(CharSource.wrap(StringValue[i]));
				JsonTable[i] = new JsonScannableTable(charSource[i]);
				rootSchema.add(tableName.get(i), JsonTable[i]);
			}
			Statement statement = connection.createStatement();
		      resultSet = statement
					.executeQuery(query);
			return resultSetToArrayList(resultSet);
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}

