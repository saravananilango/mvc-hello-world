package com.nn.sova.notification.service;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.notification.config.NotificationConfig;
import com.nn.sova.notification.constants.NotificationConstants;
import com.nn.sova.notification.gateway.service.NotificationStatusManager;
import com.nn.sova.notification.gateway.service.NtsGatewayService;
import com.nn.sova.nts.vo.GatewayType;
import com.nn.sova.nts.vo.NotificationException;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.nts.vo.NotificationStatus;
import com.nn.sova.utility.logger.ApplicationLogger;


public class NotificationGatewayServiceImpl implements NotificationGatewayService {
	
	private static final ApplicationLogger logger = ApplicationLogger.create(NotificationGatewayServiceImpl.class);
	
	@Override
	public Map<String,Object> getHandlerConfig(Map<String, Object> notificationRequestData, String gatewayType) throws NotificationException {
		Map<String, Object> defaultHandlerConfig = getHandlerConfig(notificationRequestData);
		return getHandlerKeys(defaultHandlerConfig, gatewayType);
	}
	
	/**
	 * getHandler Config based on alertID or tenantID
	 * 
	 * @param requestData
	 * @return
	 * @throws NotificationException 
	 */
	private Map<String, Object> getHandlerConfig(Map<String, Object> requestData) throws NotificationException {
		// TODO custom_handler_id -> alert_id -> tenant
		// TODO screen_def_id -> tenant
		// TODO product_code -> tenant (analyze).
		Map<String, Object> gatewayAndHandlerMap = new HashMap<>();
		Map<String, Object> handlerConfig = new HashMap<>();
		if (requestData.containsKey(NotificationConstants.ALERT_ID_KEY)) {
			handlerConfig = NotificationConfig.getNotificationDao().getHandlerConfigByAlertId(requestData.get(NotificationConstants.ALERT_ID_KEY).toString());
			if (Objects.isNull(handlerConfig) || handlerConfig.isEmpty()) {
				logger.info("No Handler Config found for alert id : {} ", requestData.get(NotificationConstants.ALERT_ID_KEY).toString());
				logger.info("Default handler for tenant will be taken");
				handlerConfig = NotificationConfig.getNotificationDao().getDefaultHandlerConfig();
			}
		} else {
			handlerConfig = NotificationConfig.getNotificationDao().getDefaultHandlerConfig();
		}
		if(Objects.isNull(handlerConfig) || handlerConfig.isEmpty()) {
			throw new NotificationException("Default Handler for tenant is empty in database");
		}
		for (GatewayType gateway : GatewayType.values()) {
			String gatewayType = gateway.toString().toLowerCase();
			if (handlerConfig.containsKey(gatewayType)) {
				gatewayAndHandlerMap.put(gatewayType, handlerConfig.get(gatewayType));
			}
		}
		return gatewayAndHandlerMap;
	}
	
	/**
	 * fetch Handler Keys for all the Handlers.
	 * 
	 * @param gatwayHandlerMap
	 * @param gatewayType      Optional can be used for individual notification api.
	 *                         Example :notifyBySms - gatewayType is SMS.
	 * @return
	 */
	private Map<String, Object> getHandlerKeys(Map<String, Object> handlerConfigMap, String optionalGatewayType) {
		Map<String, Object> gatewayHandlerKeysMap = new HashMap<>();
		List<Object> handlerIds = handlerConfigMap.values().stream().collect(Collectors.toList());
		List<Map<String, Object>> handlerKeysList = NotificationConfig.getNotificationDao().getHandlerKeys(handlerIds);
		List<Map<String, Object>> handlerGatewayLinkList = NotificationConfig.getNotificationDao().getGatwayHandlerLinkList(handlerIds);
		Map<Object, List<Map<String, Object>>> handlerGatewayLinkMap = handlerGatewayLinkList.stream()
				.collect(Collectors.groupingBy(map -> map.get("handler_id"), LinkedHashMap::new, Collectors.toList()));
		Map<Object, List<Map<String, Object>>> handlerKeysByGroup = handlerKeysList.stream()
				.collect(Collectors.groupingBy(map -> map.get("handler_id"), LinkedHashMap::new, Collectors.toList()));
		if (StringUtils.isNotEmpty(optionalGatewayType)) {
			Map<String, Object> handlerIdAndKey = groupHandlerKeysByGatewayType(handlerConfigMap, handlerGatewayLinkMap,
					handlerKeysByGroup, optionalGatewayType);
			gatewayHandlerKeysMap.put(optionalGatewayType, handlerIdAndKey);
			return gatewayHandlerKeysMap;
		}
			for (GatewayType gateway : GatewayType.values()) {
				String gatewayType = gateway.toString().toLowerCase();
				if (handlerConfigMap.containsKey(gatewayType)) {
					if (Objects.isNull(handlerConfigMap.get(gatewayType))) {
						gatewayHandlerKeysMap.put(gatewayType, null);
						logger.error("Handler is not configured for gateway type : {}", gatewayType);
					} else {
						Map<String, Object> handlerIdAndKey = groupHandlerKeysByGatewayType(handlerConfigMap,
								handlerGatewayLinkMap, handlerKeysByGroup, gatewayType);
						gatewayHandlerKeysMap.put(gatewayType, handlerIdAndKey);
					}
				}
			}
			return gatewayHandlerKeysMap;
		}
	
	/**
	 * 
	 * @param gatwayHandlerMap
	 * @param handlerGatewayLinkMap 
	 * @param handlerKeysByGroup
	 * @param gatewayType
	 * Group the handlerKeys with GatewayType.
	 * @return
	 */
	private Map<String, Object> groupHandlerKeysByGatewayType(Map<String, Object> gatwayHandlerMap,
			Map<Object, List<Map<String, Object>>> handlerGatewayLinkMap, Map<Object, List<Map<String, Object>>> handlerKeysByGroup, String gatewayType) {
		Map<String, Object> handlerIdAndKey = new HashMap<>();
		List<Map<String, Object>> handlerDeflist = (List<Map<String, Object>>) handlerKeysByGroup
				.get(gatwayHandlerMap.get(gatewayType));
		Map<Object, Object> handlerKeysMap = handlerDeflist.stream()
				.collect(Collectors.toMap(map -> map.get("key_name"), map -> map.get("value")));
		handlerIdAndKey.put("handlerId",
				gatwayHandlerMap.get(gatewayType).toString());
		handlerIdAndKey.put("gatewayId", handlerGatewayLinkMap.get(gatwayHandlerMap.get(gatewayType)).stream().findFirst().get().get("gateway_id"));
		handlerIdAndKey.put("handlerKeys", handlerKeysMap);
		return handlerIdAndKey;
	}
	
	/**
	 * get the default text template based on alertId.
	 * 
	 * @param requestData
	 * @throws NotificationException 
	 */
	@Override
	public boolean getNotificationTemplateByAlertId(Map<String, Object> notificationRequestData) throws NotificationException {
		if (notificationRequestData.containsKey(NotificationConstants.ALERT_ID_KEY)) {
			 if(StringUtils.isEmpty(notificationRequestData.get(NotificationConstants.ALERT_ID_KEY).toString())) {
				 throw new NotificationException("AlertId is Empty"); 
			 }
				Map<String, Object> ntsAlertDef = NotificationConfig.getNotificationDao()
						.getAlertDef(notificationRequestData.get(NotificationConstants.ALERT_ID_KEY).toString());
				if (Objects.isNull(ntsAlertDef) || ntsAlertDef.isEmpty()) {
					logger.error("Notification template not found for alertId - {} , so notification process aborted.",
							notificationRequestData.get(NotificationConstants.ALERT_ID_KEY).toString());
					throw new NotificationException("Notification template not found for alertId - "
							+ notificationRequestData.get(NotificationConstants.ALERT_ID_KEY).toString());
				}
				for (String templateId : NotificationConstants.NOTIFICATION_TEMPLATE_IDS) {
					notificationRequestData.put(templateId,
							Objects.nonNull(ntsAlertDef.get(templateId)) ? ntsAlertDef.get(templateId).toString()
									: StringUtils.EMPTY);
				}
		}
		replaceNotificationTextWithParams(notificationRequestData);
		return true;
	}
	
	/**
	 * Substitute the user given params in the notification message .<br>
	 * Eg : OTP is {otp}.<br>
	 * {"otp":"123456"}
	 * 
	 * @param requestData
	 */
	private void replaceNotificationTextWithParams(Map<String, Object> requestData) {
		if (requestData.containsKey("replaceParams")) {
			List<String> notificationTemplateIds = requestData.containsKey(NotificationConstants.ALERT_ID_KEY)
					? NotificationConstants.NOTIFICATION_TEMPLATE_IDS
					: NotificationConstants.NOTIFICATION_DIRECT_TEMPLATE_IDS;
			for (String templateId : notificationTemplateIds) {
				requestData.computeIfPresent(templateId,
						(key, value) -> replaceTextWithItemValues(value.toString(), requestData));
			}
		}
	}
	
	/**
	 * Replace the parameter's value in the notification message .
	 * 
	 * @param tergetString
	 * @param ntsData
	 * @return
	 */
	private String replaceTextWithItemValues(String tergetString, Map<String, Object> ntsData) {
		if(StringUtils.isEmpty(tergetString)) {
			return StringUtils.EMPTY;
		}
		Map<String, String> replaceParamters = (Map<String, String>) ntsData.get("replaceParams");
		for (Entry<String, String> itemValues : replaceParamters.entrySet()) {
			int newIndex = 0;
			String appendedKey = "{" + itemValues.getKey() + "}";
			while ((newIndex = StringUtils.indexOf(tergetString, appendedKey, newIndex)) != -1) {
				String stringBeforeItem = tergetString.substring(0, newIndex);
				newIndex += appendedKey.length();
				String stringAfterItem = tergetString.substring(newIndex);
				tergetString = StringUtils.join(stringBeforeItem, itemValues.getValue(), stringAfterItem);
			}
		}
		return tergetString;
	}
}
