package com.nn.sova.service.authentication;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.oauth2.common.OAuth2AccessToken;

import com.nn.sova.core.CacheManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.AuthRequestEntity;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class CommonUtils.
 * 
 * @author vellaichamy
 */
public class CommonUtils {

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(CommonUtils.class);
	
	/** The instance. */
	private static CommonUtils instance = null;

	/**
	 * Gets the single instance of CommonUtils.
	 *
	 * @return single instance of CommonUtils
	 */
	public static CommonUtils getInstance() {
		if(instance == null) {
			instance = new CommonUtils();
		}
		return instance;
	}
	
	
	/**
	 * Gets the header value.
	 *
	 * @param authRequestEntity the sova request
	 * @return the header value
	 */
	public String getHeaderValue(AuthRequestEntity authRequestEntity) {
		Map<String, String> headers = authRequestEntity.getHeaders();
		String value = headers.getOrDefault("Authorization", headers.getOrDefault("authorization", ""));
		if ((value.toLowerCase().startsWith(OAuth2AccessToken.BEARER_TYPE.toLowerCase()))) {
			String authHeaderValue = value.substring(OAuth2AccessToken.BEARER_TYPE.length()).trim();
			int commaIndex = authHeaderValue.indexOf(',');
			if (commaIndex > 0) {
				authHeaderValue = authHeaderValue.substring(0, commaIndex);
			}
			logger.info("Valid Header Token Format");
			return authHeaderValue;
		}
		logger.error("Invalid Header Token Format");
		return null;
	}
	
	
	/**
	 * Gets the user details.
	 *
	 * @param apiToken the api token
	 * @param tenantId the tenant id
	 * @return the user details
	 * @throws Exception the exception
	 */
	public Map<String,Object> getUserDetails(String apiToken, String tenantId) throws Exception{
			String cacheKey = apiToken.concat("_").concat(tenantId);
			Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
			if(Objects.isNull(cacheKeyExistData)) {
				updateUserDetails(apiToken,tenantId);
				cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);	
			}
			Map<String,Object> apiTokenCacheData = (Map<String, Object>) cacheKeyExistData;

			if(MapUtils.isNotEmpty(apiTokenCacheData)) {
				return apiTokenCacheData;
			}
			return Collections.emptyMap();
	}

	/**
	 * Update user details.
	 *
	 * @param apiToken the api token
	 * @param tenantId the tenant id
	 * @throws Exception the exception
	 */
	private void updateUserDetails(String apiToken, String tenantId) throws Exception{
			logger.info("User Details Param");
			QueryBuilder queryBuilder = new QueryBuilder();
			SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
			List<Map<String,Object>> userAccountData = selectQueryBuilder.get("tenant_id","user_id").skipTenantId(true).from("user_account")
					.where(ConditionBuilder.instance().eq("api_token", UUID.fromString(apiToken))
							.and().eq("tenant_id", tenantId)).build(false).execute();

			if(CollectionUtils.isNotEmpty(userAccountData)) {
				userAccountData.stream().forEach(action->{
					Map<String,Object> userAccountDataMap = new HashMap<>();
					userAccountDataMap.put("tenant_id", String.valueOf(action.get("tenant_id")));
					userAccountDataMap.put("user_id", String.valueOf(action.get("user_id")));
					CacheService.getInstance().saveToCache(apiToken.concat("_").concat(tenantId), userAccountDataMap);
				});
			}else {
				CacheService.getInstance().saveToCache(apiToken.concat("_").concat(tenantId), Collections.emptyMap());
			}
	}
	
	
	 /**
 	 * Gets the tenant server details.
 	 *
 	 * @param serverName the server name
 	 * @return the tenant server details
 	 * @throws Exception the exception
 	 */
    public Map<String, Object> getTenantServerDetails(String serverName) throws Exception {
    	String tenantId = System.getenv("DEFAULT_TENANT_ID");
        logger.info("default_tenant_id :" + tenantId);
        String cacheKey = serverName.concat("_tenant_data");
        Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
        if (Objects.isNull(cacheKeyExistData)) {
            updateTenantServerDetails(serverName);
            cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
        }
        Map<String, Object> tenantData = (Map<String, Object>) cacheKeyExistData;
        
        if (MapUtils.isNotEmpty(tenantData)) {
            return tenantData;
        } else if (Objects.nonNull(tenantId) && !StringUtils.isEmpty(tenantId)) {
            Map<String, Object> defaultTenantDataMap = new HashMap<>();
            defaultTenantDataMap.put("tenant_id", tenantId);
            return defaultTenantDataMap;
        }
        return Collections.emptyMap();
    }

    /**
     * Update tenant server details.
     *
     * @param serverName the server name
     * @throws Exception the exception
     */
    public void updateTenantServerDetails(String serverName) throws Exception {
        List<Map<String, Object>> tenantList;
            tenantList = new QueryBuilder().btSchema().select()
                    .get("tenant_definition.tenant_id", "tenant_definition.template_code",
                            "tenant_definition.domain_name", "login_template_details.design_template",
                            "login_template_details.bg_image")
                    .from("tenant_definition", "tenant_definition")
                    .leftJoin("login_template_details", "login_template_details",
                            ConditionBuilder.instance().eq("login_template_details.template_code",
                                    "tenant_definition.template_code", true))
                    .where(ConditionBuilder.instance().eq("tenant_definition.domain_name", serverName)).build(false)
                    .execute();

            if (CollectionUtils.isNotEmpty(tenantList)) {
                tenantList.stream().forEach(action -> {
                    Map<String, Object> dataMap = new HashMap<>();
                    dataMap.put("tenant_id", String.valueOf(action.get("tenant_id")));
                    dataMap.put("domain_name", String.valueOf(action.get("domain_name")));
                    CacheService.getInstance().saveToCache(serverName.concat("_tenant_data"), dataMap);
                });
            } else {
                CacheService.getInstance().saveToCache(serverName.concat("_tenant_data"), Collections.emptyMap());
            }
    }
    
    
    /**
     * Gets the lms data.
     *
     * @param serverName the server name
     * @param path the path
     * @return the lms data
     * @throws QueryException the query exception
     */
    public boolean getLmsData(String serverName, String path) throws QueryException {
    	logger.info("lms server name :" + serverName);
    	logger.info("lms path :" + path);
        String cacheKey = EnvironmentReader.getSystemId().concat("_").concat(serverName);
        logger.info("lms cache key :" + cacheKey);
        
        Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
        
        if (Objects.isNull(cacheKeyExistData)) {
            updateLmsData(serverName);
            cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
        }
        
        Map<String, Object> lmsData = (Map<String, Object>) cacheKeyExistData;
        if (MapUtils.isNotEmpty(lmsData) || path.contains("job/publish")
                || path.contains("job/tenant")) {
        	 logger.info("lms cacheKeyExistData true");
            return true;
        }
        logger.info("lms cacheKeyExistData false");
        return false;
    }
    
    
    /**
     * Update lms data.
     *
     * @param serverName the server name
     * @throws QueryException the query exception
     */
    public void updateLmsData(String serverName) throws QueryException {
        QueryBuilder queryBuilder = new QueryBuilder();
        SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
        List<Map<String, Object>> dataList = selectQueryBuilder.get("lms_system_id", "lms_lb_url")
                .from("lms_system_definition")
                .where(ConditionBuilder.instance().eq("lms_system_id", EnvironmentReader.getSystemId()).and()
                        .eq("lms_lb_url", serverName))
                .build(false).execute();

        if (CollectionUtils.isNotEmpty(dataList)) {
            dataList.stream().forEach(action -> {
                Map<String, Object> dataMap = new HashMap<>();
                dataMap.put("lms_system_id", String.valueOf(action.get("lms_system_id")));
                dataMap.put("lms_lb_url", String.valueOf(action.get("lms_lb_url")));
                CacheService.getInstance().saveToCache(
                        EnvironmentReader.getSystemId().concat("_").concat(serverName), dataMap);
            });
        }
    }
    
    /**
	 * Gets the user details by api.
	 *
	 * @param apiToken the api token
	 * @return the user details by api
	 * @throws QueryException the query exception
	 */
	public Map<String,Object> getUserDetailsByApi(String apiToken) throws QueryException{
		String cacheKey = String.valueOf(apiToken).concat("_user_lms_data");
		Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		if(Objects.isNull(cacheKeyExistData)) {
			updateUserDataByLmsApi(apiToken);
			cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		}
		
		Map<String,Object> lmsUserData = (Map<String, Object>) cacheKeyExistData;
		if(MapUtils.isNotEmpty(lmsUserData)) {
			logger.info("lms user data not empty");
			return lmsUserData;
		}
		return Collections.emptyMap();
	}
	
	/**
	 * Update user data by lms api.
	 *
	 * @param apiToken the api token
	 * @throws QueryException the query exception
	 */
	private void updateUserDataByLmsApi(String apiToken) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String,Object>> userAccountData = selectQueryBuilder.get("tenant_id","user_id").skipTenantId(true).from("user_account")
				.where(ConditionBuilder.instance().eq("api_token", UUID.fromString(apiToken))
						).build(false).execute();
		if(CollectionUtils.isNotEmpty(userAccountData)) {
			userAccountData.stream().forEach(action->{
				Map<String,Object> userAccountDataMap = new HashMap<>();
				userAccountDataMap.put("tenant_id", String.valueOf(action.get("tenant_id")));
				userAccountDataMap.put("user_id", String.valueOf(action.get("user_id")));
				CacheService.getInstance().saveToCache(apiToken.concat("_user_lms_data"), userAccountDataMap);
			});
		}else {
			CacheService.getInstance().saveToCache(apiToken.concat("_user_lms_data"), Collections.emptyMap());
		}
	}

	/**
	 * verify the oauth token timeout.
	 *
	 * @param userToken the user token
	 * @return status
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public Map<String, Object> parseAccessToken(String userToken) throws IOException {
	    Jwt jwt = JwtHelper.decode(userToken);
	    String claims = jwt.getClaims();
	    JsonParser jsonParser = JsonParserFactory.getJsonParser();
	    return jsonParser.parseMap(claims);
	}
	
}
