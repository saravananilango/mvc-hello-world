package com.nn.sova.service.authorization.utils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.exception.QueryException;

/**
 * AuthorizedUrl Class is used to defined the Framework Authorized URLS
 * 
 * @author Vellaichamy N
 *
 */
public class AuthorizedUrl {

	/** The instance. */
	private static AuthorizedUrl instance = null;

	/**
	 * Gets the single instance of AuthorizedUrlDao.
	 *
	 * @return single instance of AuthorizedUrlDao
	 */
	public static AuthorizedUrl getInstance() {
		if (Objects.isNull(instance)) {
			instance = new AuthorizedUrl();
		}
		return instance;
	}
	
	/**
	 * Check the URL availed in authorized URL list.
	 *
	 * @param url the url
	 * @return status {@link Boolean}
	 * @throws QueryException 
	 */
	public boolean isAuthorizedUrl(String url) throws QueryException{
		CacheMaintenance cacheMaintenance = CacheMaintenance.getInstance();
		List<String> authorizedUrlList = cacheMaintenance.getAllAuthorizedUrlFromCache();
		return authorizedUrlList.contains(url);
	}

	/**
	 * Return the screen id for authorized URL.
	 *
	 * @param url the url
	 * @return Screen ID {@link String}
	 * @throws QueryException 
	 */
	public String getScreenId(String url) throws QueryException{
		CacheMaintenance cacheMaintenance = CacheMaintenance.getInstance();
		Map<String, String> screenIdUrl = cacheMaintenance.getScreenIdForAuthUrl();
		return screenIdUrl.get(url);
	}
}
