package com.nn.sova.flowlogger.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.flowlogger.dao.FlowLoggerDaoImpl;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;


/**
 * The Class FlowLogServiceImpl.
 */
public class FlowLoggerServiceImpl implements FlowLoggerService {

	
	private FlowLoggerDaoImpl flowLoggerDao;

	/**
     * ProgramDesignerRestController is a constructor used to initialize the value
     * for service.
     */
    public FlowLoggerServiceImpl() {
        flowLoggerDao = new FlowLoggerDaoImpl();
    }
    /**
     * Gets the log group name.
     *
     * @param paramMap the param map
     * @return the log group name
     */
    @Override
    public String getLogGroupName(Map<String, Object> paramMap) {
        return flowLoggerDao.getLogGroupName(paramMap);
    }

    /**
     * Gets the program id.
     *
     * @param paramMap the param map
     * @return the program id
     */
    @Override
    public String getProgramId(Map<String, Object> paramMap) {
        return flowLoggerDao.getProgramId(paramMap);
    }

    private ConditionBuilder applyCommonFilter(Map<String,Object> paramMap) {
    	ConditionBuilder condition = ConditionBuilder.instance();
    	if(paramMap.containsKey("parentId")) {
    		condition.eq("parent_block", paramMap.get("parentId").toString()).and();
		}
    	if(paramMap.containsKey("loopIndex")) {
    		condition.eq("appgen_loop_index", paramMap.get("loopIndex").toString()).and();
		}
    	condition.eq("process_id", paramMap.get("processId").toString());
    	return condition;
    }
    
	@Override
	public List<Map<String, Object>> getFlowLogs(Map<String, Object> paramMap) {
		ConditionBuilder condition = applyCommonFilter(paramMap);
		String componentEvent = Objects.toString(paramMap.get("componentEvent"), StringUtils.EMPTY);
		String componentId = Objects.toString(paramMap.get("componentId"), StringUtils.EMPTY);
		boolean isApi = (boolean) paramMap.getOrDefault("isApi", false);
		boolean isLogScreen = (boolean) paramMap.getOrDefault("isLogScreen", false);
		if(!isApi) {
			boolean isException = (boolean) paramMap.getOrDefault("isException", false);
			if (!isLogScreen) {
				condition.and().eq("request_id", paramMap.get("requestId").toString());
				//add time
			}
			if (!isLogScreen && StringUtils.isNotEmpty(componentEvent) && !isException) {
				condition.and().eq("component_event_type", nonNullString(paramMap.get("componentEvent")));
			}
			if (!isLogScreen && StringUtils.isNotEmpty(componentId) && !isException) {
				condition.and().eq("component_id", nonNullString(paramMap.get("componentId")));
			}
			if (isException) {
				condition.and().brackets(ConditionBuilder.instance().brackets(
						ConditionBuilder.instance().eq("component_event_type", nonNullString(paramMap.get("componentEvent")))
						.and().eq("component_id", nonNullString(paramMap.get("componentId")))
						).or().eq("block_id", "exception"));
			}
			
		}
		else {
			condition.and().eq("request_id", paramMap.get("requestId").toString());
			//add time
		}
		return flowLoggerDao.getFlowLogs(condition,isLogScreen);
	}

	/**
     * This method used to insert default char avoiding null in component ID
     * @param object
     * @return nonNullString
     */
    private static String nonNullString(Object object) {
    	return Optional.ofNullable(object).map(Objects::toString).filter(StringUtils::isNotEmpty).orElse("-");
    }

}
