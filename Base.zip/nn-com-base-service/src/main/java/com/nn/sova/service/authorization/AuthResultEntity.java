package com.nn.sova.service.authorization;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.Authentication;

import lombok.Data;


/**
 * Instantiates a new auth result entity.
 * 
 * @author Vellaichamy N
 */

@Data
public class AuthResultEntity {
	
	/** The status code. */
	private int statusCode;
	
	/** The response msg. */
	private String responseMsg;
	
	/** The header data. */
	private Map<String, Object> headerData = new HashMap<>();
	
	/** The reason. */
	private String reason;
	
	/** The full authority. */
	private boolean fullAuthority;
	
	private boolean refreshTokenFlag;
	
	/** The pricipal id. */
	private String pricipalId;
	
	private Authentication authentication;

}
