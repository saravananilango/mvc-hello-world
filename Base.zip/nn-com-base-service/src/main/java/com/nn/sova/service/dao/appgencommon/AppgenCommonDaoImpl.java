package com.nn.sova.service.dao.appgencommon;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nn.sova.cache.CacheGetManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.exception.ServerSideValidationException;
import com.nn.sova.querybuilder.InsertQueryBuilder;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.UpdateQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.service.utils.CommonUtils;
import com.nn.sova.util.foreignValidation.SoftDeleteValidation;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.validation.QueryValidation;

/**
 * AppgenCommonDaoImpl dao impl file is for generated source database access.
 *
 * @author Johnpeter Jesu.
 */
public class AppgenCommonDaoImpl implements AppgenCommonDao,Serializable{

    /** The Constant queryBuilder. */
    private final QueryBuilder queryBuilder;

    /** The Constant TABLE_NAME. */
    private final String TABLE_NAME;

    /** The Constant PRODUCT_CODE. */
    private final String PRODUCT_CODE;

    /** The Constant viewExtraLocaleColumns. */
    private final Set<String> viewExtraLocaleColumns;

    /** The Constant queryValidation. */
    QueryValidation queryValidation = new QueryValidation();

    /**
     * AppgenCommonDaoImpl constructor.
     *
     * @param tableName   the table name
     * @param productCode the product code
     */
    public AppgenCommonDaoImpl(String tableName, String productCode) {
        TABLE_NAME = tableName;
        PRODUCT_CODE = productCode;
        queryBuilder = new QueryBuilder();
        viewExtraLocaleColumns = new HashSet<>();
        Map<String, Object> viewConfig = CommonUtils
                .getNonNullMap(CacheGetManager.getInstance().getViewConfig(tableName, productCode));
        Map<String, List<Map<String, Object>>> tableConfigData = new HashMap<>();
        viewConfig.entrySet().forEach(action -> {
            String ViewConfigTableName = action.getKey();
            if (!tableConfigData.containsKey(ViewConfigTableName)) {
                tableConfigData
                        .put(ViewConfigTableName,
                                CommonUtils
                                        .getNonNullList(CommonUtils
                                                .getNonNullMap(queryValidation.getTableDetails(action.getKey(),
                                                        productCode, UserContext.getInstance().locale()))
                                                .get("tableDetailList")));
            }
            CommonUtils.getNonNullList(action.getValue()).stream().forEach(viewData -> {
                String columnName = Objects.toString(viewData.get("column_name"), "");
                Map<String, Object> columnMap = tableConfigData.get(ViewConfigTableName).stream()
                        .filter(predicate -> predicate.get("column_name").equals(columnName)).findFirst()
                        .orElse(new HashMap<>());
                boolean isLangDependant = CommonUtils.getNonNullBoolean(columnMap.get("lang_dependent"));
                if (isLangDependant) {
                    viewExtraLocaleColumns.add(viewData.get("table_alias_name") + "_locale");
                }
            });
        });
    }

    /** The Constant STATUS. */
    private static final String STATUS = "status";

    /** The Constant MESSAGE. */
    private static final String MESSAGE = "message";

    /** The Constant COUNT. */
    private static final String COUNT = "count";

    /** The Constant DATA_COUNT. */
    private static final String DATA_COUNT = "dataCount";

    /** The Constant FIRST_INDEX. */
    private static final int FIRST_INDEX = 0;

    private static ApplicationLogger logger = ApplicationLogger.create(AppgenCommonDaoImpl.class);

    /**
     * deleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList the condition list
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> deleteSelectedDataForPortal(List<ConditionBuilder> conditionList) {
        Map<String, Object> statusMap = new HashMap<>();
        try {
            SoftDeleteValidation.checkSoftDeleteConstraint(TABLE_NAME, queryBuilder, conditionList, PRODUCT_CODE);
            QueryExecutor executor = queryBuilder.delete().batchDelete(TABLE_NAME, conditionList, true);
            statusMap.put(STATUS, true);
            statusMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            statusMap.put(STATUS, false);
            statusMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            logger.error(exception);
        }
        return statusMap;
    }

    /**
     * insert method is insert data with Map.
     *
     * @param insertMap data to be inserted into the table
     * @param idMap     the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryBuilder.insert()
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0]).checkSoftDelete(true)
                    .insertWithMap(TABLE_NAME, insertMap);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryBuilder.update()
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0]).checkSoftDelete(true)
                    .updateWithMap(TABLE_NAME, updateMap, conditionBuilder);
            resultMap.put(STATUS, true);
            resultMap.put("data", updateMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param idMap                the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryBuilder.update()
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0]).checkSoftDelete(true)
                    .batchUpdate(TABLE_NAME, updateList, conditionBuilderList);
            resultMap.put(STATUS, true);
            resultMap.put("data", updateList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception.getMessage());
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * insert method is insert data with List.
     *
     * @param insertList data to be inserted into the table
     * @param idMap      the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryBuilder.insert().checkSoftDelete(true).insertWithList(TABLE_NAME, insertList);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * delete method is insert data table.
     *
     * @param conditionBuilder the condition builder
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> delete(ConditionBuilder conditionBuilder) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            SoftDeleteValidation.checkSoftDeleteConstraint(TABLE_NAME, queryBuilder, conditionBuilder, PRODUCT_CODE);
            QueryExecutor executor = queryBuilder.delete().from(TABLE_NAME).where(conditionBuilder).build().execute();
            resultMap.put(STATUS, true);
            resultMap.put("data", executor.getUpdatedCount());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * get method is insert data table.
     *
     * @param conditionBuilder the condition builder
     * @return resultMap data to be viewed on detail screen
     */
    @Override
    public Map<String, Object> get(ConditionBuilder conditionBuilder) {
        List<Map<String, Object>> resultList = new ArrayList<>();
        Map<String, Object> resultMap = new HashMap<>();
        SelectQueryBuilder selectQueryBuilder = queryBuilder.select().from(TABLE_NAME);
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            selectQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(selectQueryBuilder);
        try {
            resultList = selectQueryBuilder.build(false).execute();
            resultMap.put("data", resultList);
            resultMap.put(STATUS, false);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * getAll method is insert data table.
     *
     * @return resultMap list of data for inbox on initial screen load
     */
    @Override
    public Map<String, Object> getAll() {
        Map<String, Object> resultMap = new HashMap<>();
        List<Map<String, Object>> resultList = new ArrayList<>();
        try {
            resultList = queryBuilder.select().from(TABLE_NAME).build(false).execute();
            resultMap.put(STATUS, true);
            resultMap.put("data", resultList);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * getCount is used to get the count.
     *
     * @param conditionBuilder the condition builder
     * @return count of the data in resultMap
     */
    @Override
    public Map<String, Object> getCount(ConditionBuilder conditionBuilder) {
        Map<String, Object> resultMap = new HashMap<>();
        SelectQueryBuilder countQueryBuilder = queryBuilder.select().checkSoftDelete(true).count("1", COUNT)
                .from(TABLE_NAME);
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            countQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(countQueryBuilder);
        try {
            resultMap.put(STATUS, true);
            resultMap.put("data", countQueryBuilder.build(false).execute().get(FIRST_INDEX).get(COUNT));
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * insert method is insert data with Map.
     *
     * @param insertMap     data to be inserted into the table
     * @param queryExecutor the query executor
     * @param idMap         the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, QueryExecutor queryExecutor,
            Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryExecutor.queryBuilder().insert().checkSoftDelete(true)
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .insertWithMap(TABLE_NAME, insertMap);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * insert method is insert data with List.
     *
     * @param insertList    data to be inserted into the table
     * @param queryExecutor the query executor
     * @param idMap         the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, QueryExecutor queryExecutor,
            Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryExecutor.queryBuilder().insert().checkSoftDelete(true)
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .insertWithList(TABLE_NAME, insertList);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            QueryExecutor queryExecutor, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryExecutor.queryBuilder().update()
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0]).checkSoftDelete(true)
                    .updateWithMap(TABLE_NAME, updateMap, conditionBuilder);
            resultMap.put(STATUS, true);
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
            resultMap.put("data", updateMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param queryExecutor        the query executor
     * @param idMap                the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, QueryExecutor queryExecutor, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            QueryExecutor executor = queryExecutor.queryBuilder().update()
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0]).checkSoftDelete(true)
                    .batchUpdate(TABLE_NAME, updateList, conditionBuilderList);
            resultMap.put(STATUS, true);
            resultMap.put("data", updateList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception.getMessage());
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * delete method is insert data table.
     *
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> delete(ConditionBuilder conditionBuilder, QueryExecutor queryExecutor) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            SoftDeleteValidation.checkSoftDeleteConstraint(TABLE_NAME, queryBuilder, conditionBuilder, PRODUCT_CODE);
            QueryExecutor executor = queryExecutor.queryBuilder().delete().from(TABLE_NAME).where(conditionBuilder)
                    .build().execute();
            resultMap.put(STATUS, true);
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * deleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList the condition list
     * @param queryExecutor the query executor
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> deleteSelectedDataForPortal(List<ConditionBuilder> conditionList,
            QueryExecutor queryExecutor) {
        Map<String, Object> statusMap = new HashMap<>();
        try {
            SoftDeleteValidation.checkSoftDeleteConstraint(TABLE_NAME, queryExecutor.queryBuilder(), conditionList,
                    PRODUCT_CODE);
            QueryExecutor executor = queryExecutor.queryBuilder().delete().batchDelete(TABLE_NAME, conditionList, true);
            statusMap.put(STATUS, true);
            statusMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            statusMap.put(STATUS, false);
            statusMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            logger.error(exception);
        }
        return statusMap;
    }

    /**
     * get method is insert data in the _appgen_mar table.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return resultMap data to be viewed on detail screen
     */
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> get(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap) {
        Map<String, Object> resultMap = new HashMap<>();
        optionsMap = Optional.ofNullable(optionsMap).orElse(new HashMap<>());
        QueryExecutor queryExecutor = Optional.ofNullable(optionsMap.get("queryExecutor"))
                .map(mapper -> (QueryExecutor) mapper).orElse(null);
        SelectQueryBuilder selectQueryBuilder = Objects.isNull(queryExecutor) ? queryBuilder.select()
                : queryExecutor.queryBuilder().select();
        SelectQueryBuilder countQueryBuilder = Objects.isNull(queryExecutor) ? queryBuilder.select().count("1", COUNT)
                : queryExecutor.queryBuilder().select().count("1", COUNT);
        String tableAliasName = Optional.ofNullable(optionsMap.get("tableAliasName")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        SortType sortType = Optional.ofNullable(optionsMap.get("sortType")).map(Objects::toString)
                .map(SortType::valueOf).orElse(null);
        String sortColumn = Optional.ofNullable(optionsMap.get("sortColumn")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        List<String> selectColumnList = Optional.ofNullable(optionsMap.get("selectColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupList = Optional.ofNullable(optionsMap.get("groupList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> orderByList = Optional.ofNullable(optionsMap.get("orderByList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        Integer currentCount = Optional.ofNullable(optionsMap.get("currentCount"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        Integer fetchLimit = Optional.ofNullable(optionsMap.get("fetchLimit"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        Optional.ofNullable(optionsMap.get("downloadFlag")).filter(predicate -> predicate instanceof Boolean)
                .map(Objects::toString).map(Boolean::valueOf).orElse(false);
        ConditionBuilder groupConditionBuilder = Optional.ofNullable(optionsMap.get("groupConditionBuilder"))
                .filter(predicate -> predicate instanceof ConditionBuilder).map(mapper -> (ConditionBuilder) mapper)
                .orElse(null);
        boolean dataOnly = Optional.ofNullable(optionsMap.get("dataOnly"))
                .filter(predicate -> predicate instanceof Boolean).map(Objects::toString).map(Boolean::valueOf)
                .orElse(true);
        Map<String, String> selectColumnMap = Optional.ofNullable(optionsMap.get("selectColumnMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, String>) mapper)
                .orElse(new HashMap<>());
        Map<String, Object> subQueryMap = Optional.ofNullable(optionsMap.get("subQueryMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, Object>) mapper)
                .orElse(new HashMap<>());
        List<String> distinctColumnList = Optional.ofNullable(optionsMap.get("distinctColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        Boolean forUpdateFlag = Optional.ofNullable(optionsMap.get("isTransactionLock"))
                .map(predicate -> Boolean.valueOf(Objects.toString(predicate, "false"))).orElse(false);
        List<Map<String, String>> functionColumnList = Optional.ofNullable(optionsMap.get("functionColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<Map<String, String>>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupByColumns = Optional.ofNullable(optionsMap.get("groupByColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        boolean includeDeleted = CommonUtils.getNonNullBoolean(optionsMap.get("includeDeleted"));
        if (StringUtils.isNotEmpty(tableAliasName)) {
            selectQueryBuilder.from(TABLE_NAME, tableAliasName);
            countQueryBuilder.from(TABLE_NAME, tableAliasName);
        } else {
            selectQueryBuilder.from(TABLE_NAME);
            countQueryBuilder.from(TABLE_NAME);
        }
        if (CollectionUtils.isNotEmpty(functionColumnList)) {
            addFunctionColumnsData(selectQueryBuilder, functionColumnList);
        }
        selectColumnMap.entrySet().stream()
                .filter(predicate -> CollectionUtils.isEmpty(groupList) || groupList.contains(predicate.getKey()))
                .forEach(action -> selectQueryBuilder.getWithAliasName(action.getKey(), action.getValue()));
        if (CollectionUtils.isNotEmpty(selectColumnList)) {
            selectQueryBuilder.getWithList(selectColumnList);
        }
        if (CollectionUtils.isNotEmpty(distinctColumnList)) {
            selectQueryBuilder.distinctOn(distinctColumnList);
        }
        if (CollectionUtils.isNotEmpty(groupByColumns)) {
            selectQueryBuilder.count("1", "appgen_grouped_count")
                    .groupBy(groupByColumns.toArray(new String[groupByColumns.size()]));
        }
        if (CollectionUtils.isNotEmpty(groupList)) {
            selectQueryBuilder.getWithList(groupList).count("1", "appgen_group_count");
            selectQueryBuilder.groupBy(groupList.toArray(new String[groupList.size()]));
        }
        subQueryMap.entrySet().stream().forEach(action -> {
            Map<String, Object> queryDataMap = (Map<String, Object>) action.getValue();
            String type = (String) queryDataMap.get("type");
            ConditionBuilder innerConditionBuilder = (ConditionBuilder) queryDataMap.get("condition");
            SelectQueryBuilder subQuery = (SelectQueryBuilder) queryDataMap.get("query");
            try {
                switch (type) {
                case "join":
                    selectQueryBuilder.join(subQuery.build(false), action.getKey(), innerConditionBuilder);
                    break;
                case "left-join":
                    selectQueryBuilder.leftJoin(subQuery.build(false), action.getKey(), innerConditionBuilder);
                    break;
                }
            } catch (QueryException exception) {
                logger.error(exception);
            }
        });
        if (Objects.nonNull(groupConditionBuilder) && StringUtils.isNotEmpty(groupConditionBuilder.getQuery().trim())) {
            selectQueryBuilder.where(groupConditionBuilder);
            countQueryBuilder.where(groupConditionBuilder);
        }
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            if (StringUtils.isNotBlank(selectQueryBuilder.getWhereConditionString())) {
                selectQueryBuilder.where(ConditionBuilder.instance().and());
            }
            if (StringUtils.isNotBlank(countQueryBuilder.getWhereConditionString())) {
                countQueryBuilder.where(ConditionBuilder.instance().and());
            }
            selectQueryBuilder.where(conditionBuilder);
            countQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(selectQueryBuilder);
        addLocaleCondition(countQueryBuilder);
        if (Objects.nonNull(sortType) && StringUtils.isNotEmpty(sortColumn)
                && (CollectionUtils.isEmpty(groupList) || groupList.contains(sortColumn))) {
            selectQueryBuilder.orderBy(sortColumn, sortType);
        }
        if (CollectionUtils.isNotEmpty(orderByList)) {
            orderByList.removeIf(predicate -> StringUtils.isBlank(predicate));
            orderByList.removeIf(mapper -> CollectionUtils.isNotEmpty(groupList)
                    && !groupList.contains(Arrays.asList(mapper.split("\\s+")).get(0)));
            selectQueryBuilder.orderBy(orderByList);
        }
        if (Objects.nonNull(currentCount))
            selectQueryBuilder.offset(currentCount);
        if (Objects.nonNull(fetchLimit))
            selectQueryBuilder.limit(fetchLimit);
        List<Map<String, Object>> resultList = new ArrayList<>();
        try {
            selectQueryBuilder.skipLanguage(
                    optionsMap.containsKey("skipLangDependent") && (boolean) optionsMap.get("skipLangDependent"));
            if (!includeDeleted) {
                selectQueryBuilder.checkSoftDelete(true);
                countQueryBuilder.checkSoftDelete(true);
            }
            if (Objects.nonNull(optionsMap.get("baseHistoryValue"))) {
                if (optionsMap.get("baseHistoryValue") instanceof Timestamp) {
                    selectQueryBuilder.setHistoryBaseDate((Timestamp) optionsMap.get("baseHistoryValue"));
                } else if (optionsMap.get("baseHistoryValue") instanceof Date) {
                    selectQueryBuilder.setHistoryBaseDate((Date) optionsMap.get("baseHistoryValue"));
                }
            }
            if (optionsMap.containsKey("isUtc")) {
                countQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
                selectQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
            }
            resultList = Optional.ofNullable(selectQueryBuilder.selectForUpdate(forUpdateFlag).build(false).execute())
                    .filter(CollectionUtils::isNotEmpty).orElseGet(Collections::emptyList);
            if (!dataOnly) {
                countQueryBuilder.skipLanguage(
                        optionsMap.containsKey("skipLangDependent") && (boolean) optionsMap.get("skipLangDependent"))
                        .checkSoftDelete(true);
                String count = countQueryBuilder.build(false).execute().stream().findFirst()
                        .map(mapper -> Objects.toString(mapper.get(COUNT), StringUtils.EMPTY))
                        .orElse(StringUtils.EMPTY);
                resultMap.put(DATA_COUNT, count);
            }
            resultMap.put("data", resultList);
            resultMap.put(STATUS, true);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * upsertWithKeyList method is to update and insert value list.
     *
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param constraintKey     the constraint key
     * @return the map
     */
    @Override
    public Map<String, Object> upsertWithKeyList(List<Map<String, Object>> valuesList, List<String> updateColumnsList,
            Map<String, String> idMap, String... constraintKey) {
        return upsertWithKeyList(queryBuilder, valuesList, updateColumnsList, idMap, constraintKey);
    }

    /**
     * upsertWithKeyList method is to do update and insert operation.
     *
     * @param queryExecutor     the query executor
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param constraintKey     the constraint key
     * @return the map
     */
    @Override
    public Map<String, Object> upsertWithKeyList(QueryExecutor queryExecutor, List<Map<String, Object>> valuesList,
            List<String> updateColumnsList, Map<String, String> idMap, String... constraintKey) {
        return upsertWithKeyList(queryExecutor.queryBuilder(), valuesList, updateColumnsList, idMap, constraintKey);
    }

    /**
     * upsertWithKeyList method is to do update and insert operation.
     *
     * @param queryBuilder      the query builder
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param constraintKey     the constraint key
     * @return the map
     */
    private Map<String, Object> upsertWithKeyList(QueryBuilder queryBuilder, List<Map<String, Object>> valuesList,
            List<String> updateColumnsList, Map<String, String> idMap, String... constraintKey) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            boolean doUpdate = true;
            if (CollectionUtils.isEmpty(updateColumnsList)) {
                doUpdate = false;
            }
            QueryExecutor executor = queryBuilder.insert()
                    .setParameterMap(Objects.isNull(idMap) ? new HashMap<>() : idMap)
                    .upsertWithKeyList(TABLE_NAME, valuesList, doUpdate, updateColumnsList, constraintKey);
            resultMap.put(STATUS, true);
            resultMap.put("data", valuesList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(STATUS, false);
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * getDistinctCount method is to get count for distinct values.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return the distinct count
     */
    @Override
    public Map<String, Object> getDistinctCount(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap) {
        Map<String, Object> resultMap = new HashMap<>();
        String distinctColumnName = Optional.ofNullable(optionsMap.get("distinctColumnName")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        SelectQueryBuilder countQueryBuilder = queryBuilder.select().count("DISTINCT " + distinctColumnName, COUNT)
                .from(TABLE_NAME);
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            countQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(countQueryBuilder);
        try {
            if (optionsMap.containsKey("isUtc")) {
                countQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
            }
            resultMap.put("data", countQueryBuilder.build(false).execute().get(FIRST_INDEX).get(COUNT));
            resultMap.put(STATUS, true);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * getWithColumns gets the data.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return the with columns
     */
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getWithColumns(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap) {
        Map<String, Object> resultMap = new HashMap<>();
        optionsMap = Optional.ofNullable(optionsMap).orElse(new HashMap<>());
        SelectQueryBuilder selectQueryBuilder = queryBuilder.select().from(TABLE_NAME);
        SelectQueryBuilder countQueryBuilder = queryBuilder.select();
        String tableAliasName = Optional.ofNullable(optionsMap.get("tableAliasName")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        SortType sortType = Optional.ofNullable(optionsMap.get("sortType")).map(Objects::toString)
                .map(SortType::valueOf).orElse(null);
        String sortColumn = Optional.ofNullable(optionsMap.get("sortColumn")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        List<String> selectColumnList = Optional.ofNullable(optionsMap.get("selectColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupList = Optional.ofNullable(optionsMap.get("groupList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupByColumns = Optional.ofNullable(optionsMap.get("groupByColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<Map<String, String>> functionColumnList = Optional.ofNullable(optionsMap.get("functionColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<Map<String, String>>) mapper)
                .orElse(new ArrayList<>());
        List<String> orderByList = Optional.ofNullable(optionsMap.get("orderByList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        Integer currentCount = Optional.ofNullable(optionsMap.get("currentCount"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        Integer fetchLimit = Optional.ofNullable(optionsMap.get("fetchLimit"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        List<String> distinctColumnList = Optional.ofNullable(optionsMap.get("distinctColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        boolean downloadFlag = Optional.ofNullable(optionsMap.get("downloadFlag"))
                .filter(predicate -> predicate instanceof Boolean).map(Objects::toString).map(Boolean::valueOf)
                .orElse(false);
        ConditionBuilder groupConditionBuilder = Optional.ofNullable(optionsMap.get("groupConditionBuilder"))
                .filter(predicate -> predicate instanceof ConditionBuilder).map(mapper -> (ConditionBuilder) mapper)
                .orElse(null);
        boolean dataOnly = Optional.ofNullable(optionsMap.get("dataOnly"))
                .filter(predicate -> predicate instanceof Boolean).map(Objects::toString).map(Boolean::valueOf)
                .orElse(false);
        Map<String, String> selectColumnMap = Optional.ofNullable(optionsMap.get("selectColumnMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, String>) mapper)
                .orElse(new HashMap<>());
        Map<String, Object> subQueryMap = Optional.ofNullable(optionsMap.get("subQueryMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, Object>) mapper)
                .orElse(new HashMap<>());
        if (StringUtils.isNotEmpty(tableAliasName)) {
            selectQueryBuilder.from(TABLE_NAME, tableAliasName);
        }
        if (CollectionUtils.isNotEmpty(functionColumnList)) {
            addFunctionColumnsData(selectQueryBuilder, functionColumnList);
        }
        selectColumnMap.entrySet().stream().forEach(action -> {
            selectQueryBuilder.getWithAliasName(action.getKey(), action.getValue());
        });
        if (CollectionUtils.isNotEmpty(selectColumnList) && CollectionUtils.isEmpty(groupList)) {
            selectQueryBuilder.getWithList(selectColumnList);
        }
        if (CollectionUtils.isNotEmpty(distinctColumnList)) {
            selectQueryBuilder.distinctOn(distinctColumnList);
        }
        if (CollectionUtils.isNotEmpty(groupByColumns)) {
            selectQueryBuilder.count("1", "sub_count");
            selectQueryBuilder.groupBy(groupByColumns.toArray(new String[groupByColumns.size()]));
        } else if (CollectionUtils.isNotEmpty(groupList)) {
            selectQueryBuilder.getWithList(groupList).count("1", "count");
            selectQueryBuilder.groupBy(groupList.toArray(new String[groupList.size()]));
        }
        subQueryMap.entrySet().stream().forEach(action -> {
            Map<String, Object> queryDataMap = (Map<String, Object>) action.getValue();
            String type = (String) queryDataMap.get("type");
            ConditionBuilder innerConditionBuilder = (ConditionBuilder) queryDataMap.get("condition");
            SelectQueryBuilder subQuery = (SelectQueryBuilder) queryDataMap.get("query");
            try {
                switch (type) {
                case "join":
                    selectQueryBuilder.join(subQuery.build(false), action.getKey(), innerConditionBuilder);
                    break;
                case "left-join":
                    selectQueryBuilder.leftJoin(subQuery.build(false), action.getKey(), innerConditionBuilder);
                    break;
                }
            } catch (QueryException exception) {
                logger.error(exception);
            }
        });
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            selectQueryBuilder.where(conditionBuilder);
        }
        if (Objects.nonNull(groupConditionBuilder) && StringUtils.isNotEmpty(groupConditionBuilder.getQuery().trim())) {
            selectQueryBuilder.where(groupConditionBuilder);
        }
        addLocaleCondition(selectQueryBuilder);
        SelectQueryBuilder countSubQuery = selectQueryBuilder;
        try {
            countQueryBuilder.from(countSubQuery.build(false), "count_query");
        } catch (QueryException exception) {
            logger.error(exception);
        }
        if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit) && !downloadFlag) {
            selectQueryBuilder.offset(currentCount).limit(fetchLimit);
        }
        if (Objects.nonNull(sortType) && StringUtils.isNotEmpty(sortColumn)
                && (CollectionUtils.isEmpty(groupList) || groupList.contains(sortColumn))) {
            selectQueryBuilder.orderBy(sortColumn, sortType);
            if (CollectionUtils.isNotEmpty(orderByList)) {
                orderByList.remove(sortColumn);
                selectQueryBuilder.orderBy(orderByList);
            }
        } else if (CollectionUtils.isNotEmpty(orderByList)) {
            selectQueryBuilder.orderBy(orderByList);
        }
        List<Map<String, Object>> resultList = new ArrayList<>();
        try {
            if (optionsMap.containsKey("isUtc")) {
                selectQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
                countQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
            }
            resultList = Optional.ofNullable(selectQueryBuilder.build(false).execute())
                    .filter(CollectionUtils::isNotEmpty).orElseGet(Collections::emptyList);
            if (!dataOnly) {
                String count = countQueryBuilder.count("1", COUNT).build(false).execute().stream().findFirst()
                        .map(mapper -> Objects.toString(mapper.get(COUNT), StringUtils.EMPTY))
                        .orElse(StringUtils.EMPTY);
                resultMap.put(DATA_COUNT, count);
            }
            resultMap.put("data", resultList);
            resultMap.put(STATUS, true);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * getExpandedGroupData gets the data.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return the expanded group data
     */
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getExpandedGroupData(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap) {
        Map<String, Object> resultMap = new HashMap<>();
        optionsMap = Optional.ofNullable(optionsMap).orElse(new HashMap<>());
        SelectQueryBuilder selectQueryBuilder = queryBuilder.select().from(TABLE_NAME);
        SortType sortType = Optional.ofNullable(optionsMap.get("sortType")).map(Objects::toString)
                .map(SortType::valueOf).orElse(null);
        String sortColumn = Optional.ofNullable(optionsMap.get("sortColumn")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        List<String> selectColumnList = Optional.ofNullable(optionsMap.get("selectColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupExpandColumnList = Optional.ofNullable(optionsMap.get("groupExpandColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupList = Optional.ofNullable(optionsMap.get("groupList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupByColumns = Optional.ofNullable(optionsMap.get("groupByColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<Map<String, String>> functionColumnList = Optional.ofNullable(optionsMap.get("functionColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<Map<String, String>>) mapper)
                .orElse(new ArrayList<>());
        List<String> orderByList = Optional.ofNullable(optionsMap.get("orderByList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        Integer currentCount = Optional.ofNullable(optionsMap.get("currentCount"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        Integer fetchLimit = Optional.ofNullable(optionsMap.get("fetchLimit"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        List<String> distinctColumnList = Optional.ofNullable(optionsMap.get("distinctColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        ConditionBuilder groupConditionBuilder = Optional.ofNullable(optionsMap.get("groupConditionBuilder"))
                .filter(predicate -> predicate instanceof ConditionBuilder).map(mapper -> (ConditionBuilder) mapper)
                .orElse(null);
        Optional.ofNullable(optionsMap.get("downloadFlag")).filter(predicate -> predicate instanceof Boolean)
                .map(Objects::toString).map(Boolean::valueOf).orElse(false);
        ConditionBuilder facetAndSearchConditionBuilder = Optional
                .ofNullable(optionsMap.get("facetAndSearchConditionBuilder"))
                .filter(predicate -> predicate instanceof ConditionBuilder).map(mapper -> (ConditionBuilder) mapper)
                .orElse(null);
        boolean dataOnly = Optional.ofNullable(optionsMap.get("dataOnly"))
                .filter(predicate -> predicate instanceof Boolean).map(Objects::toString).map(Boolean::valueOf)
                .orElse(false);
        Map<String, String> selectColumnMap = Optional.ofNullable(optionsMap.get("selectColumnMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, String>) mapper)
                .orElse(new HashMap<>());
        if (CollectionUtils.isNotEmpty(functionColumnList)) {
            addFunctionColumnsData(selectQueryBuilder, functionColumnList);
        }
        selectColumnMap.entrySet().stream().forEach(action -> {
            selectQueryBuilder.getWithAliasName(action.getKey(), action.getValue());
        });
        if (CollectionUtils.isNotEmpty(selectColumnList)) {
            selectQueryBuilder.getWithList(selectColumnList);
        }
        if (CollectionUtils.isNotEmpty(distinctColumnList)) {
            selectQueryBuilder.distinctOn(distinctColumnList);
        }
        if (CollectionUtils.isNotEmpty(groupByColumns)) {
            selectQueryBuilder.count("1", "sub_count");
            selectQueryBuilder.groupBy(groupByColumns.toArray(new String[groupByColumns.size()]));
        }
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            selectQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(selectQueryBuilder);
        List<Map<String, Object>> resultList = new ArrayList<>();
        SelectQueryBuilder selectQueryBuilderForGroup = queryBuilder.select();
        SelectQueryBuilder countQueryBuilderForGroup = queryBuilder.select();
        try {
            if (optionsMap.containsKey("isUtc")) {
                selectQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
            }
            selectQueryBuilderForGroup = queryBuilder.select().from(selectQueryBuilder.build(false), "sub_query_data");
            countQueryBuilderForGroup = queryBuilder.select().from(selectQueryBuilder.build(false), "sub_query_data");
        } catch (QueryException e) {
            e.printStackTrace();
        }
        if (Objects.nonNull(facetAndSearchConditionBuilder)) {
            if (StringUtils.isNotEmpty(selectQueryBuilderForGroup.getWhereConditionString().trim())) {
                selectQueryBuilderForGroup.where(ConditionBuilder.instance().and());
                countQueryBuilderForGroup.where(ConditionBuilder.instance().and());
            }
            selectQueryBuilderForGroup.where(facetAndSearchConditionBuilder);
            countQueryBuilderForGroup.where(facetAndSearchConditionBuilder);
        }
        if (Objects.nonNull(groupConditionBuilder) && StringUtils.isNotEmpty(groupConditionBuilder.getQuery().trim())) {
            if (StringUtils.isNotEmpty(selectQueryBuilderForGroup.getWhereConditionString().trim())) {
                selectQueryBuilderForGroup.where(ConditionBuilder.instance().and());
            }
            selectQueryBuilderForGroup.where(groupConditionBuilder);
            selectQueryBuilderForGroup.getWithList(groupExpandColumnList);
        } else if (CollectionUtils.isNotEmpty(groupList)) {
            selectQueryBuilderForGroup.getWithList(groupList).count("1", "count")
                    .groupBy(groupList.toArray(new String[groupList.size()]));
        }
        if (Objects.nonNull(currentCount))
            selectQueryBuilderForGroup.offset(currentCount);
        if (Objects.nonNull(fetchLimit))
            selectQueryBuilderForGroup.limit(fetchLimit);
        if (Objects.nonNull(sortType) && StringUtils.isNotEmpty(sortColumn)
                && (CollectionUtils.isEmpty(groupList) || groupList.contains(sortColumn))) {
            selectQueryBuilderForGroup.orderBy(sortColumn, sortType);
            if (CollectionUtils.isNotEmpty(orderByList)) {
                orderByList.remove(sortColumn);
                selectQueryBuilderForGroup.orderBy(orderByList);
            }
        } else if (CollectionUtils.isNotEmpty(orderByList)) {
            selectQueryBuilderForGroup.orderBy(orderByList);
        }
        if (optionsMap.containsKey("isUtc")) {
            countQueryBuilderForGroup.getUTCDate((boolean) optionsMap.get("isUtc"));
            selectQueryBuilderForGroup.getUTCDate((boolean) optionsMap.get("isUtc"));
        }
        try {
            resultList = Optional.ofNullable(selectQueryBuilderForGroup.build(false).execute())
                    .filter(CollectionUtils::isNotEmpty).orElseGet(Collections::emptyList);
            if (!dataOnly) {
                String count = countQueryBuilderForGroup.count("1", COUNT).build(false).execute().stream().findFirst()
                        .map(mapper -> Objects.toString(mapper.get(COUNT), StringUtils.EMPTY))
                        .orElse(StringUtils.EMPTY);
                resultMap.put(DATA_COUNT, count);
            }
            resultMap.put("data", resultList);
            resultMap.put(STATUS, true);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * addFunctionColumnsData is used to add aggregate function.
     *
     * @param selectQueryBuilder the select query builder
     * @param functionColumnList the function column list
     */
    private void addFunctionColumnsData(SelectQueryBuilder selectQueryBuilder,
            List<Map<String, String>> functionColumnList) {
        functionColumnList.stream().forEach(action -> {
            switch (action.get("functionType").toLowerCase()) {
            case "sum":
                selectQueryBuilder.sum(action.get("columnName"), action.get("aliseName"));
                break;
            case "count":
                selectQueryBuilder.count(action.get("columnName"), action.get("aliseName"));
                break;
            case "avg":
                selectQueryBuilder.average(action.get("columnName"), action.get("aliseName"));
                break;
            case "max":
                selectQueryBuilder.max(action.get("columnName"), action.get("aliseName"));
                break;
            case "min":
                selectQueryBuilder.min(action.get("columnName"), action.get("aliseName"));
                break;
            default:
                break;
            }
        });
    }

    /**
     * getNonNullMap method is to cast and get not null map. It'll return empty map
     * if value is null.
     *
     * @param value the value
     * @return the non null map
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> getNonNullMap(Object value) {
        return Optional.ofNullable(value).filter(predicate -> predicate instanceof Map)
                .map(mapper -> (Map<String, Object>) mapper).orElse(new HashMap<>());
    }

    /**
     * getNonNullList method is to get list value. It will return empty list if data
     * not present.
     *
     * @param <T>   the generic type
     * @param value the value
     * @param type  the type
     * @return the non null list
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> getNonNullList(Object value, TypeReference<T> type) {
        return Optional.ofNullable(value).filter(predicate -> predicate instanceof List).map(mapper -> (List<T>) mapper)
                .orElse(new ArrayList<>());
    }

    /**
     * getErrorMessages is used to get the error messages list.
     *
     * @param tableName the table name
     * @param exception the exception
     * @return List<String>
     */
    private List<String> getErrorMessages(String tableName, Exception exception) {
        String message = exception.getMessage();
        if (Objects.nonNull(exception.getCause()) && exception.getCause() instanceof ServerSideValidationException) {
            message = exception.getCause().getMessage();
        }
        return JsonUtils.fromJsonOrElse(Objects.toString(message), new TypeReference<Map<String, List<String>>>() {
        }, new HashMap<>()).getOrDefault(tableName, Arrays.asList(Objects.toString(message)));
    }

    /**
     * softDeleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList  the condition list
     * @param softDeleteFlag the soft delete flag
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> softDeleteSelectedDataForPortal(List<ConditionBuilder> conditionList,
            boolean softDeleteFlag) {
        if (!softDeleteFlag) {
            return deleteSelectedDataForPortal(conditionList);
        } else {
            Object data = CacheGetManager.getInstance().getServerSideValidation(TABLE_NAME, ContextBean.getLocale(),
                    PRODUCT_CODE);
            if (Objects.nonNull(data) && !((Map<String, List<Map<String, Object>>>) data).isEmpty()) {
                Map<String, List<Map<String, Object>>> dataMap = (Map<String, List<Map<String, Object>>>) data;
                List<Map<String, Object>> dataList = new ArrayList<>();
                if (dataMap.containsKey(ContextBean.getLocale())) {
                    dataList.addAll(dataMap.get(ContextBean.getLocale()));
                }
                List<Map<String, Object>> returnList = dataList.stream()
                        .filter(filterMap -> Objects.nonNull(filterMap.get("soft_delete_flag"))
                                && (boolean) (filterMap.get("soft_delete_flag"))
                                && Objects.nonNull(filterMap.get("soft_delete_value")))
                        .map(mapper -> mapper).collect(Collectors.toList());
                if (returnList.isEmpty()) {
                    return deleteSelectedDataForPortal(conditionList);
                } else {

                    List<Map<String, Object>> updateList = new ArrayList<>();
                    Map<String, Object> updateMap = new HashMap<>();
                    updateMap.put(TABLE_NAME + "." + returnList.get(0).get("column_name"),
                            returnList.get(0).get("soft_delete_value"));
                    conditionList.forEach(action -> {
                        updateList.add(updateMap);
                    });
                    return updateWithList(updateList, conditionList);
                }
            } else {
                return deleteSelectedDataForPortal(conditionList);
            }
        }
    }

    /**
     * softDelete method is insert data in the testsoftdelete table.
     *
     * @param ConditionBuilder the condition builder
     * @param softDeleteFlag   the soft delete flag
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> softDelete(ConditionBuilder ConditionBuilder, boolean softDeleteFlag) {
        if (!softDeleteFlag) {
            return delete(ConditionBuilder);
        } else {
            try {
                SoftDeleteValidation.checkSoftDeleteConstraint(TABLE_NAME, queryBuilder, ConditionBuilder,
                        PRODUCT_CODE);
            } catch (QueryException exception) {
                Map<String, Object> resultMap = new HashMap<>();
                resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
                resultMap.put(STATUS, false);
                logger.error(exception);
                return resultMap;
            }
            Object data = CacheGetManager.getInstance().getServerSideValidation(TABLE_NAME, ContextBean.getLocale(),
                    PRODUCT_CODE);
            if (Objects.nonNull(data) && !((Map<String, List<Map<String, Object>>>) data).isEmpty()) {
                Map<String, List<Map<String, Object>>> dataMap = (Map<String, List<Map<String, Object>>>) data;
                List<Map<String, Object>> dataList = new ArrayList<>();
                if (dataMap.containsKey(ContextBean.getLocale())) {
                    dataList.addAll(dataMap.get(ContextBean.getLocale()));
                }
                List<Map<String, Object>> returnList = dataList.stream()
                        .filter(filterMap -> Objects.nonNull(filterMap.get("soft_delete_flag"))
                                && (boolean) (filterMap.get("soft_delete_flag"))
                                && Objects.nonNull(filterMap.get("soft_delete_value")))
                        .map(mapper -> mapper).collect(Collectors.toList());
                if (returnList.isEmpty()) {
                    return delete(ConditionBuilder);
                } else {

                    Map<String, Object> updateMap = new HashMap<>();
                    updateMap.put(TABLE_NAME + "." + returnList.get(0).get("column_name"),
                            returnList.get(0).get("soft_delete_value"));
                    return updateWithMap(updateMap, ConditionBuilder);
                }
            } else {
                return delete(ConditionBuilder);
            }
        }
    }

    /**
     * softDeleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList  the condition list
     * @param queryExecutor  the query executor
     * @param softDeleteFlag the soft delete flag
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> softDeleteSelectedDataForPortal(List<ConditionBuilder> conditionList,
            QueryExecutor queryExecutor, boolean softDeleteFlag) {
        if (!softDeleteFlag) {
            return deleteSelectedDataForPortal(conditionList, queryExecutor);
        } else {
            Object data = CacheGetManager.getInstance().getServerSideValidation(TABLE_NAME, ContextBean.getLocale(),
                    PRODUCT_CODE);
            if (Objects.nonNull(data) && !((Map<String, List<Map<String, Object>>>) data).isEmpty()) {
                Map<String, List<Map<String, Object>>> dataMap = (Map<String, List<Map<String, Object>>>) data;
                List<Map<String, Object>> dataList = new ArrayList<>();
                if (dataMap.containsKey(ContextBean.getLocale())) {
                    dataList.addAll(dataMap.get(ContextBean.getLocale()));
                }
                List<Map<String, Object>> returnList = dataList.stream()
                        .filter(filterMap -> Objects.nonNull(filterMap.get("soft_delete_flag"))
                                && (boolean) (filterMap.get("soft_delete_flag"))
                                && Objects.nonNull(filterMap.get("soft_delete_value")))
                        .map(mapper -> mapper).collect(Collectors.toList());
                if (returnList.isEmpty()) {
                    return deleteSelectedDataForPortal(conditionList, queryExecutor);
                } else {

                    List<Map<String, Object>> updateList = new ArrayList<>();
                    Map<String, Object> updateMap = new HashMap<>();
                    updateMap.put(TABLE_NAME + "." + returnList.get(0).get("column_name"),
                            returnList.get(0).get("soft_delete_value"));
                    conditionList.forEach(action -> {
                        updateList.add(updateMap);
                    });
                    return updateWithList(updateList, conditionList, queryExecutor);
                }
            } else {
                return deleteSelectedDataForPortal(conditionList, queryExecutor);
            }
        }
    }

    /**
     * softDelete method is delete data in the testsoftdelete table.
     *
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @param softDeleteFlag   the soft delete flag
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> softDelete(ConditionBuilder conditionBuilder, QueryExecutor queryExecutor,
            boolean softDeleteFlag) {
        if (!softDeleteFlag) {
            return delete(conditionBuilder, queryExecutor);
        } else {
            try {
                SoftDeleteValidation.checkSoftDeleteConstraint(TABLE_NAME, queryBuilder, conditionBuilder,
                        PRODUCT_CODE);
            } catch (QueryException exception) {
                Map<String, Object> resultMap = new HashMap<>();
                resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
                resultMap.put(STATUS, false);
                logger.error(exception);
                return resultMap;
            }
            Object data = CacheGetManager.getInstance().getServerSideValidation(TABLE_NAME, ContextBean.getLocale(),
                    PRODUCT_CODE);
            if (Objects.nonNull(data) && !((Map<String, List<Map<String, Object>>>) data).isEmpty()) {
                Map<String, List<Map<String, Object>>> dataMap = (Map<String, List<Map<String, Object>>>) data;
                List<Map<String, Object>> dataList = new ArrayList<>();
                if (dataMap.containsKey(ContextBean.getLocale())) {
                    dataList.addAll(dataMap.get(ContextBean.getLocale()));
                }
                List<Map<String, Object>> returnList = dataList.stream()
                        .filter(filterMap -> Objects.nonNull(filterMap.get("soft_delete_flag"))
                                && (boolean) (filterMap.get("soft_delete_flag"))
                                && Objects.nonNull(filterMap.get("soft_delete_value")))
                        .map(mapper -> mapper).collect(Collectors.toList());
                if (returnList.isEmpty()) {
                    return delete(conditionBuilder, queryExecutor);
                } else {

                    Map<String, Object> updateMap = new HashMap<>();
                    updateMap.put(TABLE_NAME + "." + returnList.get(0).get("column_name"),
                            returnList.get(0).get("soft_delete_value"));
                    return updateWithMap(updateMap, conditionBuilder, queryExecutor);
                }
            } else {
                return delete(conditionBuilder, queryExecutor);
            }
        }
    }

    /**
     * get method is insert data in the _appgen_mar table.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return resultMap data to be viewed on detail screen
     */
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getAll(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap) {
        Map<String, Object> resultMap = new HashMap<>();
        optionsMap = Optional.ofNullable(optionsMap).orElse(new HashMap<>());
        QueryExecutor queryExecutor = Optional.ofNullable(optionsMap.get("queryExecutor"))
                .map(mapper -> (QueryExecutor) mapper).orElse(null);
        SelectQueryBuilder selectQueryBuilder = Objects.isNull(queryExecutor) ? queryBuilder.select()
                : queryExecutor.queryBuilder().select();
        SelectQueryBuilder countQueryBuilder = Objects.isNull(queryExecutor) ? queryBuilder.select().count("1", COUNT)
                : queryExecutor.queryBuilder().select().count("1", COUNT);
        String tableAliasName = Optional.ofNullable(optionsMap.get("tableAliasName")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        SortType sortType = Optional.ofNullable(optionsMap.get("sortType")).map(Objects::toString)
                .map(SortType::valueOf).orElse(null);
        String sortColumn = Optional.ofNullable(optionsMap.get("sortColumn")).map(Objects::toString)
                .orElse(StringUtils.EMPTY);
        List<String> selectColumnList = Optional.ofNullable(optionsMap.get("selectColumnList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> groupList = Optional.ofNullable(optionsMap.get("groupList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        List<String> orderByList = Optional.ofNullable(optionsMap.get("orderByList"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        Integer currentCount = Optional.ofNullable(optionsMap.get("currentCount"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        Integer fetchLimit = Optional.ofNullable(optionsMap.get("fetchLimit"))
                .filter(predicate -> predicate instanceof Integer).map(Objects::toString).map(Integer::valueOf)
                .orElse(null);
        boolean downloadFlag = Optional.ofNullable(optionsMap.get("downloadFlag"))
                .filter(predicate -> predicate instanceof Boolean).map(Objects::toString).map(Boolean::valueOf)
                .orElse(false);
        ConditionBuilder groupConditionBuilder = Optional.ofNullable(optionsMap.get("groupConditionBuilder"))
                .filter(predicate -> predicate instanceof ConditionBuilder).map(mapper -> (ConditionBuilder) mapper)
                .orElse(null);
        boolean dataOnly = Optional.ofNullable(optionsMap.get("dataOnly"))
                .filter(predicate -> predicate instanceof Boolean).map(Objects::toString).map(Boolean::valueOf)
                .orElse(true);
        Map<String, String> selectColumnMap = Optional.ofNullable(optionsMap.get("selectColumnMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, String>) mapper)
                .orElse(new HashMap<>());
        Map<String, Object> subQueryMap = Optional.ofNullable(optionsMap.get("subQueryMap"))
                .filter(predicate -> predicate instanceof Map).map(mapper -> (Map<String, Object>) mapper)
                .orElse(new HashMap<>());
        List<String> distinctColumnList = Optional.ofNullable(optionsMap.get("distinctColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        if (StringUtils.isNotEmpty(tableAliasName)) {
            selectQueryBuilder.from(TABLE_NAME, tableAliasName);
            countQueryBuilder.from(TABLE_NAME, tableAliasName);
        } else {
            selectQueryBuilder.from(TABLE_NAME);
            countQueryBuilder.from(TABLE_NAME);
        }
        selectColumnMap.entrySet().stream()
                .filter(predicate -> CollectionUtils.isEmpty(groupList) || groupList.contains(predicate.getKey()))
                .forEach(action -> selectQueryBuilder.getWithAliasName(action.getKey(), action.getValue()));
        if (CollectionUtils.isNotEmpty(selectColumnList)) {
            selectQueryBuilder.getWithList(selectColumnList);
        }
        if (CollectionUtils.isNotEmpty(distinctColumnList)) {
            selectQueryBuilder.distinctOn(distinctColumnList);
        }
        if (CollectionUtils.isNotEmpty(groupList)) {
            selectQueryBuilder.getWithList(groupList).count("1", "appgen_group_count");
            selectQueryBuilder.groupBy(groupList.toArray(new String[groupList.size()]));
        }
        subQueryMap.entrySet().stream().forEach(action -> {
            Map<String, Object> queryDataMap = (Map<String, Object>) action.getValue();
            String type = (String) queryDataMap.get("type");
            ConditionBuilder innerConditionBuilder = (ConditionBuilder) queryDataMap.get("condition");
            SelectQueryBuilder subQuery = (SelectQueryBuilder) queryDataMap.get("query");
            try {
                switch (type) {
                case "join":
                    selectQueryBuilder.join(subQuery.build(false), action.getKey(), innerConditionBuilder);
                    break;
                case "left-join":
                    selectQueryBuilder.leftJoin(subQuery.build(false), action.getKey(), innerConditionBuilder);
                    break;
                }
            } catch (QueryException exception) {
                logger.error(exception);
            }
        });
        if (Objects.nonNull(groupConditionBuilder) && StringUtils.isNotEmpty(groupConditionBuilder.getQuery().trim())) {
            selectQueryBuilder.where(groupConditionBuilder);
            countQueryBuilder.where(groupConditionBuilder);
        }
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            if (StringUtils.isNotBlank(selectQueryBuilder.getWhereConditionString())) {
                selectQueryBuilder.where(ConditionBuilder.instance().and());
            }
            if (StringUtils.isNotBlank(countQueryBuilder.getWhereConditionString())) {
                countQueryBuilder.where(ConditionBuilder.instance().and());
            }
            selectQueryBuilder.where(conditionBuilder);
            countQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(selectQueryBuilder);
        addLocaleCondition(countQueryBuilder);
        if (Objects.nonNull(sortType) && StringUtils.isNotEmpty(sortColumn)
                && (CollectionUtils.isEmpty(groupList) || groupList.contains(sortColumn))) {
            selectQueryBuilder.orderBy(sortColumn, sortType);
        }
        if (CollectionUtils.isNotEmpty(orderByList)) {
            orderByList.removeIf(predicate -> StringUtils.isBlank(predicate));
            orderByList.removeIf(mapper -> CollectionUtils.isNotEmpty(groupList)
                    && !groupList.contains(Arrays.asList(mapper.split("\\s+")).get(0)));
            selectQueryBuilder.orderBy(orderByList);
        }
        if (Objects.nonNull(currentCount) && Objects.nonNull(fetchLimit) && !downloadFlag) {
            selectQueryBuilder.offset(currentCount).limit(fetchLimit);
        }
        if (optionsMap.containsKey("isUtc")) {
            countQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
            selectQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
        }
        List<Map<String, Object>> resultList = new ArrayList<>();
        try {
            resultList = Optional.ofNullable(selectQueryBuilder.build(false).execute())
                    .filter(CollectionUtils::isNotEmpty).orElseGet(Collections::emptyList);
            if (!dataOnly) {
                String count = countQueryBuilder.build(false).execute().stream().findFirst()
                        .map(mapper -> Objects.toString(mapper.get(COUNT), StringUtils.EMPTY))
                        .orElse(StringUtils.EMPTY);
                resultMap.put(DATA_COUNT, count);
            }
            resultMap.put("data", resultList);
            resultMap.put(STATUS, true);
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * getCount is used to get the count.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return count of the data in resultMap
     */
    @Override
    public Map<String, Object> getCount(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap) {
        QueryBuilder queryBuild = null;
        boolean includeDeleted = CommonUtils.getNonNullBoolean(optionsMap.get("includeDeleted"));
        if (optionsMap.containsKey("queryExecutor") && Objects.nonNull(optionsMap.get("queryExecutor"))) {
            queryBuild = ((QueryExecutor) (optionsMap.get("queryExecutor"))).queryBuilder();
        } else {
            queryBuild = new QueryBuilder();
        }
        Map<String, Object> resultMap = new HashMap<>();
        SelectQueryBuilder countQueryBuilder = null;
        List<String> distinctColumnList = Optional.ofNullable(optionsMap.get("distinctColumns"))
                .filter(predicate -> predicate instanceof List).map(mapper -> (List<String>) mapper)
                .orElse(new ArrayList<>());
        if (CollectionUtils.isNotEmpty(distinctColumnList)) {
            countQueryBuilder = queryBuild.select()
                    .skipLanguage(optionsMap.containsKey("skipLangDependent")
                            && (boolean) optionsMap.get("skipLangDependent"))
                    .distinctOn(distinctColumnList).from(TABLE_NAME);
        } else {
            countQueryBuilder = queryBuild.select().skipLanguage(
                    optionsMap.containsKey("skipLangDependent") && (boolean) optionsMap.get("skipLangDependent"))
                    .count("1", COUNT).from(TABLE_NAME);
        }
        if (optionsMap.containsKey("isUtc")) {
            countQueryBuilder.getUTCDate((boolean) optionsMap.get("isUtc"));
        }
        if (Objects.nonNull(conditionBuilder) && StringUtils.isNotEmpty(conditionBuilder.getQuery().trim())) {
            countQueryBuilder.where(conditionBuilder);
        }
        addLocaleCondition(countQueryBuilder);
        try {
            if (!includeDeleted) {
                countQueryBuilder.checkSoftDelete(true);
            }
            resultMap.put(STATUS, true);
            if (CollectionUtils.isNotEmpty(distinctColumnList)) {
                resultMap.put("data", countQueryBuilder.build(false).execute().size());
            } else {
                resultMap.put("data", countQueryBuilder.build(false).execute().get(FIRST_INDEX).get(COUNT));
            }
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * Adds the locale condition.
     *
     * @param selectQueryBuilder the select query builder
     */
    private void addLocaleCondition(SelectQueryBuilder selectQueryBuilder) {
        for (String columnName : viewExtraLocaleColumns) {
            ConditionBuilder condition = ConditionBuilder.instance().eq(columnName, ContextBean.getLocale()).or()
                    .eq(columnName, "").or().isNull(columnName);
            if (StringUtils.isNotEmpty(selectQueryBuilder.getWhereConditionString().trim())) {
                selectQueryBuilder.where(ConditionBuilder.instance().and().brackets(condition));
            } else {
                selectQueryBuilder.where(ConditionBuilder.instance().brackets(condition));
            }
        }
    }

    /**
     * insert method is insert data with Map.
     *
     * @param insertMap data to be inserted into the table
     * @param insertOptionMap the insert option map
     * @param idMap     the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, Map<String, Object> insertOptionMap,
            Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            InsertQueryBuilder insertBuilder = queryBuilder.insert();
            if (insertOptionMap.containsKey("isUtc")) {
                insertBuilder.isUtc((boolean) insertOptionMap.get("isUtc"));
            }
            QueryExecutor executor = insertBuilder.setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .checkSoftDelete(true).insertWithMap(TABLE_NAME, insertMap);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * insert method is insert data with Map.
     *
     * @param insertMap     data to be inserted into the table
     * @param queryExecutor the query executor
     * @param insertOptionMap the insert option map
     * @param idMap         the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, QueryExecutor queryExecutor,
            Map<String, Object> insertOptionMap, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            InsertQueryBuilder insertBuilder = queryExecutor.queryBuilder().insert();
            if (insertOptionMap.containsKey("isUtc")) {
                insertBuilder.isUtc((boolean) insertOptionMap.get("isUtc"));
            }
            QueryExecutor executor = insertBuilder.checkSoftDelete(true)
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .insertWithMap(TABLE_NAME, insertMap);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * insert method is insert data with List.
     *
     * @param insertList    data to be inserted into the table
     * @param queryExecutor the query executor
     * @param insertOptionMap the insert option map
     * @param idMap         the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, QueryExecutor queryExecutor,
            Map<String, Object> insertOptionMap, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            InsertQueryBuilder insertBuilder = queryExecutor.queryBuilder().insert();
            if (insertOptionMap.containsKey("isUtc")) {
                insertBuilder.isUtc((boolean) insertOptionMap.get("isUtc"));
            }
            QueryExecutor executor = insertBuilder.checkSoftDelete(true)
                    .setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .insertWithList(TABLE_NAME, insertList);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * insert method is insert data with List.
     *
     * @param insertList data to be inserted into the table
     * @param insertOptionMap the insert option map
     * @param idMap      the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, Map<String, Object> insertOptionMap,
            Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            InsertQueryBuilder insertBuilder = queryBuilder.insert();
            if (insertOptionMap.containsKey("isUtc")) {
                insertBuilder.isUtc((boolean) insertOptionMap.get("isUtc"));
            }
            QueryExecutor executor = insertBuilder.checkSoftDelete(true).insertWithList(TABLE_NAME, insertList);
            resultMap.put(STATUS, true);
            resultMap.put("data", insertList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @param updateOptionMap the update option map
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            QueryExecutor queryExecutor, Map<String, Object> updateOptionMap, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            UpdateQueryBuilder updateBuilder = queryExecutor.queryBuilder().update();
            if (updateOptionMap.containsKey("isUtc")) {
                updateBuilder.isUtc((boolean) updateOptionMap.get("isUtc"));
            }
            QueryExecutor executor = updateBuilder.setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .checkSoftDelete(true).updateWithMap(TABLE_NAME, updateMap, conditionBuilder);
            resultMap.put(STATUS, true);
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
            resultMap.put("data", updateMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param updateOptionMap the update option map
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            Map<String, Object> updateOptionMap, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            UpdateQueryBuilder updateBuilder = queryBuilder.update();
            if (updateOptionMap.containsKey("isUtc")) {
                updateBuilder.isUtc((boolean) updateOptionMap.get("isUtc"));
            }
            QueryExecutor executor = updateBuilder.setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .checkSoftDelete(true).updateWithMap(TABLE_NAME, updateMap, conditionBuilder);
            resultMap.put(STATUS, true);
            resultMap.put("data", updateMap);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param queryExecutor        the query executor
     * @param updateOptionMap the update option map
     * @param idMap                the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, QueryExecutor queryExecutor,
            Map<String, Object> updateOptionMap, Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            UpdateQueryBuilder updateBuilder = queryExecutor.queryBuilder().update();
            if (updateOptionMap.containsKey("isUtc")) {
                updateBuilder.isUtc((boolean) updateOptionMap.get("isUtc"));
            }
            QueryExecutor executor = updateBuilder.setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .checkSoftDelete(true).batchUpdate(TABLE_NAME, updateList, conditionBuilderList);
            resultMap.put(STATUS, true);
            resultMap.put("data", updateList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception.getMessage());
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * update method is to update data with Map.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param updateOptionMap the update option map
     * @param idMap                the id map
     * @return resultMap status and error message on failure case
     */
    @Override
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, Map<String, Object> updateOptionMap,
            Map<String, String>... idMap) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            UpdateQueryBuilder updateBuilder = queryBuilder.update();
            if (updateOptionMap.containsKey("isUtc")) {
                updateBuilder.isUtc((boolean) updateOptionMap.get("isUtc"));
            }
            QueryExecutor executor = updateBuilder.setParameterMap(idMap.length == 0 ? new HashMap<>() : idMap[0])
                    .checkSoftDelete(true).batchUpdate(TABLE_NAME, updateList, conditionBuilderList);
            resultMap.put(STATUS, true);
            resultMap.put("data", updateList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            resultMap.put(STATUS, false);
            logger.error(exception.getMessage());
            logger.error(exception);
        }
        return resultMap;
    }

    /**
     * upsertWithKeyList method is to update and insert value list.
     *
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param upsertOptionMap the upsert option map
     * @param constraintKey     the constraint key
     * @return the map
     */
    @Override
    public Map<String, Object> upsertWithKeyList(List<Map<String, Object>> valuesList, List<String> updateColumnsList,
            Map<String, String> idMap, Map<String, Object> upsertOptionMap, String... constraintKey) {
        return upsertWithKeyList(queryBuilder, valuesList, updateColumnsList, idMap, upsertOptionMap, constraintKey);
    }

    /**
     * upsertWithKeyList method is to do update and insert operation.
     *
     * @param queryExecutor     the query executor
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param upsertOptionMap the upsert option map
     * @param constraintKey     the constraint key
     * @return the map
     */
    @Override
    public Map<String, Object> upsertWithKeyList(QueryExecutor queryExecutor, List<Map<String, Object>> valuesList,
            List<String> updateColumnsList, Map<String, String> idMap, Map<String, Object> upsertOptionMap,
            String... constraintKey) {
        return upsertWithKeyList(queryExecutor.queryBuilder(), valuesList, updateColumnsList, idMap, upsertOptionMap,
                constraintKey);
    }

    /**
     * upsertWithKeyList method is to do update and insert operation.
     *
     * @param queryBuilder      the query builder
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param upsertOptionMap the upsert option map
     * @param constraintKey     the constraint key
     * @return the map
     */
    private Map<String, Object> upsertWithKeyList(QueryBuilder queryBuilder, List<Map<String, Object>> valuesList,
            List<String> updateColumnsList, Map<String, String> idMap, Map<String, Object> upsertOptionMap,
            String... constraintKey) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            boolean doUpdate = true;
            if (CollectionUtils.isEmpty(updateColumnsList)) {
                doUpdate = false;
            }
            InsertQueryBuilder upsertBuilder = queryBuilder.insert();
            if (upsertOptionMap.containsKey("isUtc")) {
                upsertBuilder.isUtc((boolean) upsertOptionMap.get("isUtc"));
            }
            QueryExecutor executor = upsertBuilder.setParameterMap(Objects.isNull(idMap) ? new HashMap<>() : idMap)
                    .upsertWithKeyList(TABLE_NAME, valuesList, doUpdate, updateColumnsList, constraintKey);
            resultMap.put(STATUS, true);
            resultMap.put("data", valuesList);
            resultMap.put("result", executor.getPrimaryKeyValue());
            resultMap.put("affectedCount", executor.getCurrentUpdatedCount());
        } catch (Exception exception) {
            resultMap.put(STATUS, false);
            resultMap.put(MESSAGE, getErrorMessages(TABLE_NAME, exception));
            logger.error(exception);
        }
        return resultMap;
    }
}
