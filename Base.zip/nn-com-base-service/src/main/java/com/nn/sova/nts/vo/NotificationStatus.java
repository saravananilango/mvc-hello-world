package com.nn.sova.nts.vo;

import lombok.Getter;

@Getter
public enum NotificationStatus {

	NOT_QUEUED("NOT_QUEUED"),	
	QUEUED("QUEUED"),
	IN_PROGRESS("IN_PROGRESS"),
	COMPLETED("COMPLETED"),
	FAILED("FAILED");
	
	private String value;
	
	/**
	 * Instantiates a new notification execution status.
	 *
	 * @param value the value.
	 * @param level the level.
	 */
	private NotificationStatus(String value) {
		this.value = value;
	}
}
