package com.nn.sova.notification.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.exception.QueryException;
import com.nn.sova.notification.constants.NotificationConstants;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

public class NotificationDaoImpl implements NotificationDao {
	
	private static final ApplicationLogger logger = ApplicationLogger.create(NotificationDaoImpl.class);

	
	@Override
	public List<Map<String, Object>> getNotificationPreferenceByUsers(List<Object> userList, String sid) {
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			List<Map<String, Object>> result = queryBuilder.select().from(NotificationConstants.NTS_USER_DEF_TABLE)
					.where(ConditionBuilder.instance().inWithList(NotificationConstants.USER_ID_COLUMN, userList).and().eq(NotificationConstants.SCREEN_DEF_ID_COLUMN, sid)).build(false).execute();
			if (Objects.nonNull(result)) {
				return result;
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getNotificationPreferenceByUsers", e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public Map<String, Object> getNotificationSettingByScreendefid(String screenDefId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			List<Map<String, Object>> result = queryBuilder.select().from(NotificationConstants.NTS_ALERT_SERVICE_DEF_TABLE)
					.where(ConditionBuilder.instance().eq(NotificationConstants.SCREEN_DEF_ID_COLUMN, screenDefId)).build(false).execute();
			if (Objects.nonNull(result) && !result.isEmpty()) {
				return result.get(0);
			}
			logger.error("no settings found for screenDefId - {}", screenDefId);
		} catch (QueryException e) {
			logger.error("Error Occured :: getNotificationPreferenceByUsers", e);
		}
		return Collections.emptyMap();
	}
	
	@Override
	public Map<String, Object> getDefaultHandlerConfig() {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_HANDLER_MST_TABLE).where(ConditionBuilder
					.instance()
					.eq(NotificationConstants.HANDLER_FETCH_TYPE_COLUMN, NotificationConstants.HANDLER_FETCH_DEFAULT)
					.and().eq(NotificationConstants.HANDLER_LABEL_COLUMN, NotificationConstants.HANDLER_FETCH_DEFAULT))
					.build(false).execute();
			if (!result.isEmpty()) {
				return result.get(0);
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getDefaultHandlerConfig", e);
			e.printStackTrace();
		}
		return Collections.emptyMap();
	}
	
	/**
	 * get the link between Handler and Gateway .
	 */
	@Override
	public List<Map<String, Object>> getGatwayHandlerLinkList(List<Object> handlerIds) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_GATEWAY_HANDLER_LINK_TABLE)
					.where(ConditionBuilder.instance().inWithList(NotificationConstants.HANDLER_ID_COLUMN, handlerIds))
					.build(false).execute();
			if (Objects.nonNull(result)) {
				return result;
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getGatwayHandlerLinkList", e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public Map<String, Object> getHandlerConfigByAlertId(String alertId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_HANDLER_MST_TABLE)
					.where(ConditionBuilder.instance()
							.eq(NotificationConstants.HANDLER_FETCH_TYPE_COLUMN, NotificationConstants.ALERT_ID_KEY)
							.and().eq(NotificationConstants.HANDLER_LABEL_COLUMN, alertId))
					.build(false).execute();
			if (!result.isEmpty()) {
				return result.get(0);
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getHandlerConfigByAlertId", e);
			e.printStackTrace();
		}
		return Collections.emptyMap();
	}
	
	@Override
	public Map<String, Object> getHandlerByScreenDefId(String screenDefId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_HANDLER_MST_TABLE)
					.where(ConditionBuilder.instance()
							.eq(NotificationConstants.HANDLER_FETCH_TYPE_COLUMN,
									NotificationConstants.SCREEN_DEF_ID_KEY)
							.and().eq(NotificationConstants.HANDLER_LABEL_COLUMN, screenDefId))
					.build(false).execute();
			if (!result.isEmpty()) {
				return result.get(0);
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getHandlerByScreenDefId", e);
		}
		return Collections.emptyMap();
	}
	
	@Override
	public Map<String, Object> getHandlerByCustomHandlerId(String customHandlerId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_HANDLER_MST_TABLE)
					.where(ConditionBuilder.instance()
							.eq(NotificationConstants.HANDLER_FETCH_TYPE_COLUMN, NotificationConstants.HANDLER_ID_KEY)
							.and().eq(NotificationConstants.HANDLER_LABEL_COLUMN, customHandlerId))
					.build(false).execute();
			if (!result.isEmpty()) {
				return result.get(0);
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getHandlerByCustomHandlerId", e);
		}
		return Collections.emptyMap();
	}
	
	@Override
	public List<Map<String, Object>> getHandlerKeys(List<Object> handlerIds) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_HANDLER_DEF_TABLE)
					.where(ConditionBuilder.instance().inWithList(NotificationConstants.HANDLER_ID_COLUMN, handlerIds)).build(false).execute();
			if (Objects.nonNull(result)) {
				return result;
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getHandlerKeys", e);
			e.printStackTrace();
		}
		return Collections.emptyList();
	}
	
	@Override
	public Map<String,Object> getAlertDef(String alertId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_ALERT_DEF_TABLE).lang(true).setLanguage(ContextBean.getLocale())
			  .where(ConditionBuilder.instance().eq(NotificationConstants.ALERT_ID_COLUMN, alertId)).build(false).execute();
			if(!result.isEmpty()) {
				return result.get(0);
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getAlertDef", e);
		}
		return Collections.emptyMap();
	}
	
	@Override
	public Map<String,Object> getNotificationAlertByScreenDefId(String screenDefId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.select().from(NotificationConstants.NTS_ALERT_SERVICE_DEF_TABLE).lang(true).setLanguage(ContextBean.getLocale())
			  .where(ConditionBuilder.instance().eq(NotificationConstants.SCREEN_DEF_ID_COLUMN, screenDefId)).build(false).execute();
			if(!result.isEmpty()) {
				 String alertId = result.get(0).get(NotificationConstants.ALERT_ID_KEY).toString();
				 return getAlertDef(alertId);
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getNotificationAlertByScreenDefId", e);
		}
		return Collections.emptyMap();
	}
	
	

	@Override
	public List<Map<String, Object>> getUserAccount(List<Object> users) {
		QueryBuilder queryBuilder = new  QueryBuilder();
		try {
			 List<Map<String, Object>> result = queryBuilder.btSchema().select().get(NotificationConstants.USER_ID_COLUMN,NotificationConstants.EMAIL_ID, NotificationConstants.PHONE_NUMBER).
					 from(NotificationConstants.USER_ACCOUNT_TABLE)
			.where(ConditionBuilder.instance().inWithList(NotificationConstants.USER_ID_COLUMN, users)).build(false).execute();
			 if(Objects.nonNull(result)) {
				 return result;
			 }
		} catch (QueryException e) {
			logger.error("Error Occured :: getMobileAndEmailFromUser",e);
		}
		return Collections.emptyList();
	}

	
	@Override
	public void insertIntoNotificationTable(Map<String,Object> notificationObject) {
		QueryBuilder queryBuilder = new  QueryBuilder();
		try {
			queryBuilder.btSchema().insert().insertWithList(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE, Arrays.asList(notificationObject));
		} catch (QueryException e) {
			logger.error("Error Occured :: insertIntoNotificationTable",e);
		}
	}
	
	@Override
	public List<Map<String,Object>> getUnreadNotificationData(String userId, int limit) {
		QueryBuilder queryBuilder = new  QueryBuilder();
		try {
			 List<Map<String, Object>> result = queryBuilder.btSchema().select().from(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE)
			.where(ConditionBuilder.instance().eq(NotificationConstants.USER_ID_COLUMN, userId)).limit(limit).build(false).execute();
			 if(Objects.nonNull(result)) {
				 return result;
			 }
		} catch (QueryException e) {
			logger.error("Error Occured :: getUnreadNotificationData",e);
		}
		return Collections.emptyList();
	}
	
	/**
	 * getUnreadNotificationsCount is to retrieve unread notifications count
	 * @param notificationData
	 * @return
	 */
	@Override
	public int getUnreadNotificationsCount(String userId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			List<Map<String, Object>> result = queryBuilder.select().count(NotificationConstants.NOTIFICATION_ID_COLUMN, "count").from(NotificationConstants.NN_NOTFICATION_TABLE_NAME)
			.where(ConditionBuilder.instance().eq(NotificationConstants.USER_ID_COLUMN, userId)
					.and().eq(NotificationConstants.READ_COLUMN, false)).build(false).execute();
			if(!result.isEmpty()) {
				return Integer.valueOf(result.get(0).get("count").toString());
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getUnreadNotificationsCount",e);
		}
		return 0;
	}

	@Override
	public List<Map<String, Object>> getRecentUnreadNotifications(String userId, int limit) {
		QueryBuilder queryBuilder = new  QueryBuilder();
		try {
			 List<Map<String, Object>> result = queryBuilder.btSchema().select().from(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE)
			.where(ConditionBuilder.instance().eq(NotificationConstants.USER_ID_COLUMN, userId))
			.orderBy("created_at", SortType.DESC)
			.limit(limit).build(false).execute();
			 if(Objects.nonNull(result)) {
				 return result;
			 }
		} catch (QueryException e) {
			logger.error("Error Occured :: getRecentNotifications",e);
		}
		return Collections.emptyList();
	}

	@Override
	public void setRead(String userId, String notificationID) {
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			queryBuilder.update()
					.into(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE, NotificationConstants.READ_COLUMN)
					.where(ConditionBuilder.instance()
							.eq(NotificationConstants.USER_ID_COLUMN, userId).and()
							.eq(NotificationConstants.NOTIFICATION_ID_COLUMN,
									notificationID)).build().execute(true);
		} catch (QueryException e) {
			logger.error("Error Occured :: setRead", e);
		}
	}
	
	@Override
	public void setReadAll(String userId) {
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			queryBuilder.update().into(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE, NotificationConstants.READ_COLUMN)
			.where(ConditionBuilder.instance().eq(NotificationConstants.USER_ID_COLUMN, userId))
			.build().execute(true);
		} catch (QueryException e) {
			logger.error("Error Occured :: setReadAll",e);
		}
	}
	
	/**
	 * setUnRead is to mark a notification as unread
	 * @param notificationData
	 */
	@Override
	public void setUnRead(String userId, String notificationID) {
		QueryBuilder queryBuilder = new QueryBuilder();
		try {
			queryBuilder.btSchema().update().isMaster(true).into(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE, NotificationConstants.READ_COLUMN)
			.where(ConditionBuilder.instance().eq(NotificationConstants.USER_ID_COLUMN, userId)
					.and().eq(NotificationConstants.NOTIFICATION_ID_COLUMN, notificationID))
			.build().execute(false);
		} catch (QueryException e) {
			logger.error("Error Occured :: setUnRead",e);
		}
	}
	
	/**
	 * getNotificationIds based on targetUrl and userId . (For workflow - to clear notifications)
	 * @param url
	 * @param userIds
	 * @return
	 */
	@Override
	public List<Map<String, Object>> getNotificationIdsByUserAndTargetUrl(String url, List<Object> userIds) {
		QueryBuilder queryBuilder = new QueryBuilder();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			result = queryBuilder.btSchema().select().from(NotificationConstants.NTS_TRASNACTION_WEB_NOTIFICATION_TABLE)
					.where(ConditionBuilder.instance().eq("target_url", url).and().
							inWithList(NotificationConstants.USER_ID_COLUMN, userIds)).build(false).execute();
			if (Objects.nonNull(result)) {
				return result;
			}
		} catch (QueryException e) {
			logger.error("Error Occured :: getNotificationIdsByUserAndTargetUrl", e);
			e.printStackTrace();
		}
		return result;
	}
}
