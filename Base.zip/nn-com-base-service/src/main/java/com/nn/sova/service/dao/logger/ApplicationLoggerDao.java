package com.nn.sova.service.dao.logger;


import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.context.ApplicationThread;
import com.nn.sova.utility.logger.ApplicationLogger;
 
/**
 * ApplicationLoggerDao class is DAO for application logger
 *
 * @author Anand Kumar Ramdass
 */
public class ApplicationLoggerDao {
	
	private static final String APP_LOG_STATS = "application_log_statistics";
	private static final String APP_LOG_STATS_PROCESS_ID = "application_log_statistics.process_id";
	private static final String APP_LOG_STATS_USER_ID = "application_log_statistics.user_id";
	private static final String APP_LOG_STATS_SCREEN_ID  = "application_log_statistics.screen_id";
	
	public static final List<String> API_DETAILS_OBJECT_COLUMNS = Arrays.asList(
            "CONCAT_WS(' ',sova_core_program_detail.mapping_url,sova_core_api_detail.method_url) as combined_url",
            "sova_core_program_detail.program_name");
	
	private static ApplicationLogger logger = ApplicationLogger.create(ApplicationLoggerDao.class);

	private ApplicationLoggerDao() {
    }
	/**
	 * insertUserLog is used to insert/update into application_log_statistics table
	 * @param logMap
	 */
	public static void insertUserLog(Map<String, Object> logMap) {
		new ApplicationThread(() -> {
			try {
				System.out.println("app log insertion log inside thread");
				List<String> keyList = Arrays.asList("tenant_id", "process_id");
				new QueryBuilder().btSchema().insert().upsertWithKeyList(APP_LOG_STATS, Arrays.asList(logMap), false, 
						new ArrayList<>(), keyList.toArray(new String[keyList.size()]));
			} catch (QueryException exception) {
				logger.error(exception);
			} finally {
				Thread.currentThread().interrupt();
			}
			return;
		}).start();
	}

	/**
	 * updateLog is used to update into application_log_statistics table
	 * @param logMap
	 * @throws QueryException
	 */
	public static void updateLog(Map<String, Object> logMap) throws QueryException {
		new QueryBuilder().btSchema().update().skipAuditLog(true)
		.updateWithMap(APP_LOG_STATS, logMap, ConditionBuilder.instance().eq("process_id", logMap.get(APP_LOG_STATS_PROCESS_ID).toString())
				.and().eq("user_id", logMap.get(APP_LOG_STATS_USER_ID).toString()).and().eq("screen_id", logMap.get(APP_LOG_STATS_SCREEN_ID).toString()));
	}

	/**
	 * updateLogBasedonWindowId is used to update into application_log_statistics table based on window Id
	 * @param logMap
	 * @throws QueryException
	 */
	public static void updateLogBasedonWindowId(List<Object> windowList,Map<String,Object> logMap) {
		try {
			new QueryBuilder().btSchema().update().skipAuditLog(true).updateWithMap(APP_LOG_STATS, logMap,
					ConditionBuilder.instance().inWithList("process_id", windowList));
		} catch (QueryException exception) {
			logger.error(exception);
		}
	}

	public static String getProgramNameByApiUrl(String apiUrl, String productCode, String subProductCode) {
		try {
			if(StringUtils.isNotEmpty(apiUrl) && StringUtils.isNotEmpty(productCode) && StringUtils.isNotEmpty(subProductCode)) {
			List<Map<String, Object>> dataList = new QueryBuilder().btSchema().select().getWithList(API_DETAILS_OBJECT_COLUMNS)
					.from("sova_core_program_detail", "sova_core_program_detail")
					.leftJoin("sova_core_api_detail", "sova_core_api_detail", 
					ConditionBuilder.instance().eq("sova_core_program_detail.program_id", "sova_core_api_detail.program_id", true))
					.where(ConditionBuilder.instance().isNotNull("sova_core_program_detail.mapping_url")
							.and()
							.eq("CONCAT_WS(' ',sova_core_program_detail.mapping_url,sova_core_api_detail.method_url)", apiUrl)
							.and()
							.eq("sova_core_program_detail.product_code", productCode)
							.and()
							.eq("sova_core_program_detail.sub_product_code", subProductCode)
					).build(false).execute();
				if(!dataList.isEmpty()) {
					return dataList.get(0).get("program_name").toString();
				}
			}
		} catch (QueryException exception) {
			logger.error(exception);
		}
		return null;
	}
	
	public static void updateLastAccessTime(String processId) throws QueryException {
		new QueryBuilder().btSchema()
				.update()
				.into(APP_LOG_STATS, "access_out")
				.where(ConditionBuilder.instance().eq("process_id", processId))
				.build().execute(Timestamp.valueOf(LocalDateTime.now()));
	}
	
	public static void updateDebugModeByUserId(String userId, boolean mode) throws QueryException {
		new QueryBuilder().btSchema()
				.update()
				.into(APP_LOG_STATS, "debug_mode")
				.where(ConditionBuilder.instance().eq("user_id", userId).and().isNull("access_out"))
				.build().execute(mode);
	}
	
}
