package com.nn.sova.service.utils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Months;
import org.joda.time.Weeks;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.postgresql.util.PGobject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.CaseFormat;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Multimap;
import com.nn.sova.changerequest.ChangeRequest;
import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.user.UserContext;
import com.nn.sova.util.ServerSideValidationUtil;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.date.DateStyle;
import com.nn.sova.utility.date.DateTimeUtils;
import com.nn.sova.utility.date.TimeStyle;
import com.nn.sova.utility.helper.UserSettingsHelper;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class CommonUtils.
 */
public class CommonUtils {

	/** The Constant DATA */
	private static final String DATA = "data";
	/** The Constant AFFECTED_COUNT */
	private static final String AFFECTED_COUNT = "affectedCount";
	/** The Constant AFFECTED_ROWS */
	private static final String AFFECTED_ROWS = "affectedRows";
	/** The Constant MESSAGE * */
	private static final String MESSAGE = "message";
	/** The Constant RESULT */
	private static final String RESULT = "result";
	/** LOGGER */
	private static final ApplicationLogger LOGGER = ApplicationLogger.create(CommonUtils.class);

	/**
	 * validateValueWithDataFormat method is to get validation Result.
	 *
	 * @param dataFormat the data format
	 * @param value      the value
	 * @return the map
	 */
	public static Map<String, Object> validateValueWithDataFormat(String dataFormat, Object value) {
		Map<String, Object> outputMap = new HashMap<>();
		try {
			ServerSideValidationUtil.checkServerSideValidation(dataFormat, "sdf", value);
			outputMap.put("status", true);
		} catch (QueryException e) {
			e.printStackTrace();
			outputMap.put("status", false);
			outputMap.put("message", e.getMessage());
		}
		return outputMap;
	}

	/**
	 * getSortFieldList is to get the sort fields list.
	 *
	 * @param sortField the sort field
	 * @return List<String>
	 */
	public static List<String> getSortFieldList(Object sortField) {
		return Arrays.asList(Objects.toString(sortField, "").split(",")).stream().map(mapper -> {
			mapper = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, mapper);
			if (mapper.startsWith("+")) {
				mapper = mapper.replaceFirst("\\+", "").trim() + " DESC";
			} else if (mapper.startsWith("-")) {
				mapper = mapper.replaceFirst("\\-", "").trim() + " ASC";
			}
			return mapper;
		}).collect(Collectors.toList());
	}

	/**
	 * parseJson method is to parse value into json value.
	 *
	 * @param objectValue the object value
	 * @return the string
	 */
	public static String parseJson(Object objectValue) {
		return JsonUtils.toJsonOrNull(objectValue);
	}

	/**
	 * getNonNullList is used to get non null list.
	 *
	 * @param object the object
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> getNonNullList(Object object) {
		return Optional.ofNullable(object).filter(predicate -> predicate instanceof List)
				.map(mapper -> (List<Map<String, Object>>) mapper).orElse(new ArrayList<>());
	}

	/**
	 * getNonNullMap method is to get map from object value.
	 *
	 * @param value the value
	 * @return map
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getNonNullMap(Object value) {
		return Optional.ofNullable(value).filter(predicate -> predicate instanceof Map)
				.map(mapper -> (Map<String, Object>) mapper).orElse(new HashMap<>());
	}

	/**
	 * getNonNullMapWithConversion method is to get map from object value.
	 *
	 * @param value the value
	 * @return map
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getNonNullMapWithConversion(Object value) {
		return Optional.ofNullable(value).filter(predicate -> predicate instanceof Map || predicate instanceof List)
				.map(mapper -> {
					if (mapper instanceof List) {
						Map<String, Object> tempMap = new HashMap<>();
						List<Object> data = (List<Object>) mapper;
						AtomicInteger index = new AtomicInteger(0);
						data.forEach(element -> tempMap.put(Objects.toString(index.getAndIncrement()), element));
						return tempMap;
					}
					return (Map<String, Object>) mapper;
				}).orElse(new HashMap<>());
	}

	/**
	 * getListForReference method is to get non null list for reference type.
	 *
	 * @param <T>   the generic type
	 * @param value the value
	 * @param type  the type
	 * @return the list for reference
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> getListForReference(Object value, TypeReference<T> type) {
		return Optional.ofNullable(value).filter(predicate -> predicate instanceof List
				|| predicate.getClass().isArray() || predicate instanceof Collection).map(mapper -> {
					if (mapper.getClass().isArray()) {
						mapper = new ArrayList<>(Arrays.stream((T[]) mapper).collect(Collectors.toList()));
					} else if (mapper instanceof Collection && !(mapper instanceof List)) {
						mapper = new ArrayList<>((Collection<?>) value);
					}
					return (List<T>) mapper;
				}).orElse(new ArrayList<>());
	}

	/**
	 * getMapForReference method is to get non null map for reference type.
	 *
	 * @param <K>     the key type
	 * @param <T>     the generic type
	 * @param value   the value
	 * @param mapType the map type
	 * @return Map<K, T>
	 */
	@SuppressWarnings("unchecked")
	public static <K, T> Map<K, T> getMapForReference(Object value, TypeReference<Map<K, T>> mapType) {
		return Optional.ofNullable(value).filter(predicate -> predicate instanceof Map || predicate instanceof List)
				.map(mapper -> {
					if (mapper instanceof List) {
						Map tempMap = new HashMap<>();
						List data = (List) mapper;
						for (int index = 0; index < data.size(); index++) {
							tempMap.put(index, data.get(index));
						}
						return tempMap;
					}
					return (Map<K, T>) mapper;
				}).orElse(new HashMap<>());
	}

	/**
	 * getNonNullSet method is to get set value. It'll return empty list if object
	 * is null.
	 *
	 * @param <T>   the generic type
	 * @param value the value
	 * @param type  the type
	 * @return the non null set
	 */
	@SuppressWarnings("unchecked")
	public static <T> Set<T> getNonNullSet(Object value, TypeReference<T> type) {
		return Optional.ofNullable(value).filter(predicate -> predicate instanceof Set || predicate instanceof List)
				.map(mapper -> {
					if (mapper instanceof List) {
						return (Set<T>) ((List) mapper).stream().collect(Collectors.toSet());
					}
					return (Set<T>) mapper;
				}).orElse(new HashSet<>());
	}

	/**
	 * getNonNullBoolean method is to get non null boolean value.
	 *
	 * @param value the value
	 * @return the non null boolean
	 */
	public static boolean getNonNullBoolean(Object value) {
		return Optional.ofNullable(value).map(Objects::toString).map(mapper -> Boolean.valueOf(mapper)).orElse(false);
	}

	/**
	 * getInArray method is to get array from list value.
	 *
	 * @param value the value
	 * @return the in array
	 */
	public static Object[] getInArray(Object value) {
		return Optional.ofNullable(value).map(mapper -> getListForReference(mapper, new TypeReference<Object>() {
		})).orElse(new ArrayList<>()).toArray();
	}

	/**
	 * getArrayFromObject is to convert object value into array.
	 *
	 * @param value the value
	 * @return the array from object
	 */
	public static Object[] getArrayFromObject(Object value) {
		return Arrays.asList(value).toArray();
	}

	/**
	 * getInList method is to get list value.
	 *
	 * @param value the value
	 * @return the in list
	 */
	public static List<Object> getInList(Object value) {
		return Optional.ofNullable(value).map(mapper -> getListForReference(mapper, new TypeReference<Object>() {
		})).orElse(new ArrayList<>());
	}

	/**
	 * getInListFromObject is to convert object value into array.
	 *
	 * @param value the value
	 * @return the in list from object
	 */
	public static List<Object> getInListFromObject(Object value) {
		return Arrays.asList(value);
	}

	/**
	 * getListFromDataAccess method to collect specific column value as list.
	 *
	 * @param valueList  the value list
	 * @param columnName the column name
	 * @return Object
	 */

	public static List<Object> getListFromDataAccess(List<Map<String, Object>> valueList, String columnName) {
		return valueList.stream().map(mapper -> mapper.get(columnName)).collect(Collectors.toList());
	}

	/**
	 * dateConverter method is to convert object into date.
	 *
	 * @param dateObject the date object
	 * @return the date
	 * @throws Exception the exception
	 */
	public static Date dateConverter(Object dateObject) throws Exception {
		String dateString = Objects.toString(dateObject, "");
		String tempDateString = dateString;
		if (StringUtils.isEmpty(dateString)) {
			throw new Exception("Invalid date value : " + dateObject);
		} else if (dateObject instanceof Date) {
			return (Date) dateObject;
		}
		SimpleDateFormat formatter;
		Date resultDate = null;
		try {
			DateTime dateTime = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSSZ")
					.parseDateTime(tempDateString.replace("/", "-"));
			resultDate = dateTime.toDate();
		} catch (Exception newFormatException) {
			try {
				resultDate = userSettingFormater(dateString);
			} catch (Exception parseException) {
				try {
					DateTime dateTime = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
							.parseDateTime(tempDateString.replaceAll("/", "-"));
					resultDate = dateTime.toDate();
				} catch (Exception localDateException) {
					try {
						tempDateString = tempDateString.replaceAll("/", "-");
						String[] splitedData = tempDateString.split("-");
						if (splitedData.length == 3) {
							if (splitedData[0].length() == 4) {
								formatter = new SimpleDateFormat("yyyy-MM-dd");
								formatter.setLenient(false);
								resultDate = formatter.parse(tempDateString);
							} else {
								formatter = new SimpleDateFormat("dd-MM-yyyy");
								formatter.setLenient(false);
								resultDate = formatter.parse(tempDateString);
							}
						} else if (splitedData.length == 2) {
							if (splitedData[0].length() == 4) {
								formatter = new SimpleDateFormat("yyyy-MM");
								formatter.setLenient(false);
								resultDate = formatter.parse(tempDateString);
							} else {
								formatter = new SimpleDateFormat("MM-yyyy");
								formatter.setLenient(false);
								resultDate = formatter.parse(tempDateString);
							}
						} else {
							formatter = new SimpleDateFormat("MMM dd, yyyy");
							formatter.setLenient(false);
							resultDate = formatter.parse(dateString);
						}
					} catch (Exception exceptions) {
						try {
							formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
							formatter.setLenient(false);
							resultDate = formatter.parse(dateString);
						} catch (Exception exception) {
							try {
								formatter = new SimpleDateFormat("E, MMM dd, yyyy");
								formatter.setLenient(false);
								resultDate = formatter.parse(dateString);
							} catch (Exception e) {
								try {
									if (dateString.length() == 4) {
										formatter = new SimpleDateFormat("yyyy");
										formatter.setLenient(false);
										resultDate = formatter.parse(dateString);
									} else {
										Date startDate = new Date(Long.valueOf(Objects.toString(dateObject)));
										resultDate = startDate;
									}
								} catch (Exception e2) {
									LOGGER.warn("Invalid date value : " + dateObject, e2);
									throw new Exception("Invalid date value : " + dateObject);
								}
							}
						}
					}
				}
			}

		}
		return resultDate;
	}

	/**
	 * Format user setting formatter
	 *
	 * @param dateString
	 * @return
	 * @throws ParseException
	 */
	private static Date userSettingFormater(String dateString) throws ParseException {
		SimpleDateFormat formatter;
		Date resultDate;
		String format;
		try {
			format = DateStyle.getPattern(ContextBean.getLocaleHolder(), DateStyle.valueOf(ContextBean.getDateFormat()))
					+ ' ';
			format += TimeStyle.getPatternWithSeccond(ContextBean.getLocaleHolder(),
					TimeStyle.valueOf(ContextBean.getTimeFormat()));
			formatter = new SimpleDateFormat(format);
			formatter.setLenient(false);
			resultDate = formatter.parse(dateString);
		} catch (Exception ex) {
			format = DateStyle.getPattern(ContextBean.getLocaleHolder(),
					DateStyle.valueOf(ContextBean.getDateFormat()));
			formatter = new SimpleDateFormat(format);
			formatter.setLenient(false);
			resultDate = formatter.parse(dateString);
		}
		return resultDate;
	}

	/**
	 * dateConverter method is to convert date object into date and if exception
	 * occurs add that into error set.
	 *
	 * @param dateObject              the date object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the date
	 */
	public static Date dateConverter(Object dateObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return dateConverter(dateObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * getTimeStamp method is to parse object into Timestamp.
	 *
	 * @param object the object
	 * @return the time stamp
	 * @throws Exception the exception
	 */
	public static Timestamp getTimeStamp(Object object) throws Exception {
		Timestamp timestamp = null;
		if (StringUtils.isEmpty(Objects.toString(object, ""))) {
			throw new Exception("Invalid timestamp value : " + object);
		}
		if (object instanceof Map) {
			Map<String, Object> timestampMap = getNonNullMap(object);
			if (Objects.isNull(timestampMap.get("0"))) {
				throw new Exception("Invalid timestamp value : " + object);
			} else if (StringUtils.isEmpty(Objects.toString(timestampMap.get("1"), StringUtils.EMPTY))) {
				return DateTimeUtils.makeTimestampForComponent(timestampMap.get("0").toString());
			}
			String timeStampString = timestampMap.get("0").toString().replaceAll("/", "-") + " "
					+ timestampMap.get("1");
			try {
				timestamp = Timestamp.valueOf(timeStampString);
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				simpleDateFormat.setTimeZone(TimeZone.getTimeZone(UserSettingsHelper.getSystemSettingTimeZone()));
				String format = simpleDateFormat.format(timestamp);
				timestamp = Timestamp.valueOf(format);
			} catch (IllegalArgumentException exception) {
				LOGGER.warn("Invalid timestamp value : " + object, exception);
				throw new Exception("Invalid timestamp value : " + object);
			}
		} else if (object instanceof LocalDateTime) {
			return Timestamp.valueOf((LocalDateTime) object);
		} else if (object instanceof Date) {
			Date date = (Date) object;
			return new Timestamp(date.getTime());
		} else {
			try {
				String timeStampString = Objects.toString(object).replaceAll("/", "-");
				timestamp = Timestamp.valueOf(timeStampString);
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				simpleDateFormat.setTimeZone(TimeZone.getTimeZone(UserSettingsHelper.getSystemSettingTimeZone()));
				String format = simpleDateFormat.format(timestamp);
				timestamp = Timestamp.valueOf(format);
			} catch (IllegalArgumentException illegalArgumentException) {
				Date date = new Date();
				String dateFormat = UserSettingsHelper.getSystemSettingDateFormat();
				String timeFormat = UserSettingsHelper.getSystemSettingTimeFormat();
				String pattern = DateStyle.getPattern(ContextBean.getLocaleHolder(), DateStyle.valueOf(dateFormat))
						+ " ";
				pattern += TimeStyle.getPatternWithSeccond(ContextBean.getLocaleHolder(),
						TimeStyle.valueOf(timeFormat));
				SimpleDateFormat formatter = new SimpleDateFormat(pattern, ContextBean.getLocaleHolder());
				formatter.setTimeZone(TimeZone.getTimeZone(UserSettingsHelper.getSystemSettingTimeZone()));
				formatter.setLenient(false);
				try {
					date = formatter.parse(Objects.toString(object));
					timestamp = new Timestamp(date.getTime());
				} catch (ParseException e) {
					formatter = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss.SSS");
					formatter.setTimeZone(TimeZone.getTimeZone(UserSettingsHelper.getSystemSettingTimeZone()));
					formatter.setLenient(false);
					try {
						date = formatter.parse(Objects.toString(object));
						timestamp = new Timestamp(date.getTime());
					} catch (ParseException e1) {
						try {
							timestamp = DateTimeUtils.makeTimestampForComponent(Objects.toString(object));
						} catch (IllegalArgumentException illegalException) {
							try {
								Date dateValue = dateConverter(object);
								timestamp = new Timestamp(dateValue.getTime());
							} catch (Exception dateException) {
								timestamp = null;
							}
						}
					}
				}
			}
		}
		if (Objects.isNull(timestamp)) {
			LOGGER.warn("Invalid timestamp value : " + object);
			throw new Exception("Invalid timestamp value : " + object);
		}
		return timestamp;
	}

	/**
	 * getTimeStamp method is to convert object into timestamp and add error if any.
	 *
	 * @param timestampObject         the timestamp object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the time stamp
	 */
	public static Timestamp getTimeStamp(Object timestampObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return getTimeStamp(timestampObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * isValidUUID method is to check given object is valid uuid value or not.
	 *
	 * @param uuidObject the uuid object
	 * @return true, if is valid UUID
	 */
	public static boolean isValidUUID(Object uuidObject) {
		try {
			parseUuid(uuidObject);
			return true;
		} catch (Exception exception) {
			return false;
		}
	}

	/**
	 * parseUuid method is to parse object into UUID and throws exception if object
	 * is invalid uuid.
	 *
	 * @param uuidObject the uuid object
	 * @return the uuid
	 * @throws Exception the exception
	 */
	public static UUID parseUuid(Object uuidObject) throws Exception {
		try {
			if (Objects.toString(uuidObject).length() == 36) {
				Pattern pattern = Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$");
				boolean isMatches = pattern.matcher(uuidObject.toString()).matches();
				if (isMatches) {
					return UUID.fromString(Objects.toString(uuidObject));
				} else {
					throw new Exception("Invalid UUID string: " + uuidObject);
				}
			} else {
				throw new Exception("Invalid UUID string : " + uuidObject);
			}
		} catch (Exception exception) {
			LOGGER.warn("Invalid UUID string : " + uuidObject);
			throw new Exception("Invalid UUID string : " + uuidObject);
		}
	}

	/**
	 * parseUuid method is to parse object into UUID and add error message if it is
	 * not a valid UUID.
	 *
	 * @param uuidObject              the uuid object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the uuid
	 */
	public static UUID parseUuid(Object uuidObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseUuid(uuidObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * addErrorMessageIntoList method is to add error message into set.
	 *
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param message                 the message
	 * @param appgenErrorVariableList the appgen error variable list
	 */
	public static void addErrorMessageIntoSet(Set<String> errorSet, String keyName, String message,
			Set<String> appgenErrorVariableList) {
		if (Objects.isNull(errorSet)) {
			errorSet = new LinkedHashSet<>();
		}
		if (Objects.isNull(appgenErrorVariableList)) {
			appgenErrorVariableList = new LinkedHashSet<>();
		}
		String actualMessage = "";
		if (StringUtils.isNotEmpty(keyName)) {
			actualMessage = keyName + " : ";
		}
		actualMessage += message;
		errorSet.add(actualMessage);
		appgenErrorVariableList.add(keyName);
	}

	/**
	 * getErrorMessageFromSet method is to get error message from error set.
	 *
	 * @param errorSet the error set
	 * @param keyName  the key name
	 * @return the error message from set
	 */
	public static String getErrorMessageFromSet(Set<String> errorSet, String keyName) {
		List<String> list = errorSet.stream().filter(predicate -> predicate.startsWith(keyName + " : "))
				.collect(Collectors.toList());
		Collections.reverse(list);
		return list.stream().findFirst().orElse("");
	}

	/**
	 * Parses the boolean.
	 *
	 * @param booleanObject the boolean object
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public static boolean parseBoolean(Object booleanObject) throws Exception {
		List<String> acceptedBoolean = Arrays.asList("true", "false", "TRUE", "FALSE");
		String value = Objects.toString(booleanObject);
		if (acceptedBoolean.contains(value)) {
			return Boolean.valueOf(value);
		} else {
			throw new Exception("Invalid boolean value : " + booleanObject);
		}
	}

	/**
	 * parseBoolean method is to parse object into boolean value and add error
	 * message if any exception occured.
	 *
	 * @param booleanObject           the boolean object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the boolean
	 */
	public static Boolean parseBoolean(Object booleanObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseBoolean(booleanObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * parseBooleanForDataAccess method is to parse data access key value object for
	 * boolean.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseBooleanForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().map(mapper -> {
				try {
					return parseBoolean(mapper);
				} catch (Exception e) {
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			Map<String, Object> returnMap = swapMap.keySet().stream()
					.collect(Collectors.toMap(Function.identity(), key -> {
						return getListForReference(swapMap.get(key), new TypeReference<Object>() {
						}).stream().map(mapper -> {
							try {
								return parseBoolean(mapper);
							} catch (Exception e) {
								return mapper;
							}
						}).collect(Collectors.toList());
					}));
			dataMap.put(columnKey, returnMap);
		} else {
			try {
				boolean value = parseBoolean(dataMap.get(columnKey));
				dataMap.put(columnKey, value);
			} catch (Exception e) {
				LOGGER.warn("Invalid boolean value : " + dataMap.get(columnKey));
			}
		}
	}

	/**
	 * parseDateForDataAccess method is to parse data access object into date.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseDateForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().filter(Objects::nonNull).map(Objects::toString).map(mapper -> {
				try {
					return dateConverter(mapper);
				} catch (Exception e) {
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			Map<String, Object> returnMap = swapMap.keySet().stream()
					.collect(Collectors.toMap(Function.identity(), key -> {
						if (swapMap.get(key) instanceof List || swapMap.get(key) instanceof Collection
								|| swapMap.get(key).getClass().isArray()) {
							return getListForReference(swapMap.get(key), new TypeReference<Object>() {
							}).stream().filter(Objects::nonNull).map(Objects::toString).map(mapper -> {
								try {
									return dateConverter(mapper);
								} catch (Exception e) {
									return mapper;
								}
							}).collect(Collectors.toList());
						} else {
							try {
								return dateConverter(swapMap.get(key));
							} catch (Exception e) {
								return swapMap.get(key);
							}
						}
					}));
			dataMap.put(columnKey, returnMap);
		} else {
			try {
				Date dateValue = dateConverter(dataMap.get(columnKey));
				dataMap.put(columnKey, dateValue);
			} catch (Exception exception) {
				return;
			}
		}
	}

	/**
	 * parseIntForDataAccess method is to parse data for data access key map value.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseIntForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().map(mapper -> {
				try {
					return parseInt(mapper);
				} catch (Exception e) {
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			Map<String, Object> returnMap = swapMap.keySet().stream()
					.collect(Collectors.toMap(Function.identity(), key -> {
						if (swapMap.get(key) instanceof List || swapMap.get(key) instanceof Collection
								|| swapMap.get(key).getClass().isArray()) {
							return getListForReference(swapMap.get(key), new TypeReference<Object>() {
							}).stream().map(mapper -> {
								try {
									return parseInt(mapper);
								} catch (Exception e) {
									return mapper;
								}
							}).collect(Collectors.toList());
						} else {
							try {
								return parseInt(swapMap.get(key));
							} catch (Exception e) {
								return swapMap.get(key);
							}
						}
					}));
			dataMap.put(columnKey, returnMap);
		} else {
			try {
				int value = parseInt(dataMap.get(columnKey));
				dataMap.put(columnKey, value);
			} catch (Exception e) {
				LOGGER.warn("Invalid int value : " + dataMap.get(columnKey), e);
			}
		}
	}

	/**
	 * parseTimestampForDataAccess method is to parse data access value object into
	 * Timestamp value.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseTimestampForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().filter(Objects::nonNull).map(mapper -> {
				try {
					return getTimeStamp(mapper);
				} catch (Exception e) {
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			if (swapMap.containsKey("0") && swapMap.containsKey("1")) {
				try {
					Timestamp timestamp = getTimeStamp(dataMap.get(columnKey));
					dataMap.put(columnKey, timestamp);
				} catch (Exception e) {
					LOGGER.warn("Invalid timestamp value : " + dataMap.get(columnKey), e);
				}
			} else {
				Map<String, Object> returnMap = swapMap.keySet().stream()
						.collect(Collectors.toMap(Function.identity(), key -> {
							if (swapMap.get(key) instanceof List || swapMap.get(key) instanceof Collection
									|| swapMap.get(key).getClass().isArray()) {
								return getListForReference(swapMap.get(key), new TypeReference<Object>() {
								}).stream().filter(Objects::nonNull).map(mapper -> {
									try {
										return getTimeStamp(mapper);
									} catch (Exception e) {
										return mapper;
									}
								}).collect(Collectors.toList());
							} else {
								try {
									return getTimeStamp(swapMap.get(key));
								} catch (Exception e) {
									return swapMap.get(key);
								}
							}
						}));
				dataMap.put(columnKey, returnMap);
			}
		} else {
			try {
				Timestamp timestamp = getTimeStamp(dataMap.get(columnKey));
				dataMap.put(columnKey, timestamp);
			} catch (Exception e) {
				LOGGER.warn("Invalid timestamp value : " + dataMap.get(columnKey), e);
			}
		}
	}

	/**
	 * parseUuidForDataAccess method is to parse data access object value into uuid
	 * object.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseUuidForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().filter(Objects::nonNull).map(mapper -> {
				try {
					return parseUuid(mapper);
				} catch (Exception e) {
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			Map<String, Object> returnMap = swapMap.keySet().stream()
					.collect(Collectors.toMap(Function.identity(), key -> {
						return getListForReference(swapMap.get(key), new TypeReference<Object>() {
						}).stream().filter(Objects::nonNull).map(mapper -> {
							try {
								return parseUuid(mapper);
							} catch (Exception e) {
								return mapper;
							}
						}).collect(Collectors.toList());
					}));
			dataMap.put(columnKey, returnMap);
		} else if (isValidUUID(dataMap.get(columnKey))) {
			try {
				UUID uuid = parseUuid(dataMap.get(columnKey));
				dataMap.put(columnKey, uuid);
			} catch (Exception e) {
				LOGGER.warn("Invalid UUID string : " + dataMap.get(columnKey));
			}
		}
	}

	/**
	 * parseNumberForDataAccess method is to parse number for data access keyword
	 * key map value.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseNumberForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().filter(Objects::nonNull).map(Objects::toString).map(mapper -> {
				try {
					return parseNumber(mapper);
				} catch (Exception e) {
					LOGGER.warn("Number format exception for: " + mapper, e);
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			Map<String, Object> returnMap = swapMap.keySet().stream()
					.collect(Collectors.toMap(Function.identity(), key -> {
						if (swapMap.get(key) instanceof List || swapMap.get(key) instanceof Collection
								|| swapMap.get(key).getClass().isArray()) {
							return getListForReference(swapMap.get(key), new TypeReference<Object>() {
							}).stream().filter(Objects::nonNull).map(Objects::toString).map(mapper -> {
								try {
									return parseNumber(mapper);
								} catch (Exception e) {
									LOGGER.warn("Number format exception for: " + mapper, e);
									return mapper;
								}
							}).collect(Collectors.toList());
						} else {
							try {
								return parseNumber(swapMap.get(key));
							} catch (Exception e) {
								return swapMap.get(key);
							}
						}
					}));
			dataMap.put(columnKey, returnMap);
		} else {
			try {
				Number number = parseNumber(dataMap.get(columnKey));
				dataMap.put(columnKey, number);
			} catch (Exception e) {
				LOGGER.warn("Invalid number value : " + dataMap.get(columnKey), e);
			}
		}
	}

	/**
	 * parseNumber method is to parse object value into Number type.
	 *
	 * @param numberObject the number object
	 * @return the number
	 * @throws Exception the exception
	 */
	public static Number parseNumber(Object numberObject) throws Exception {
		if (Objects.isNull(numberObject)) {
			return null;
		}
		try {
			if (Objects.toString(numberObject).contains(".")) {
				return new BigDecimal(numberObject.toString());
			} else {
				return new BigInteger(numberObject.toString());
			}
		} catch (Exception exception) {
			LOGGER.warn("Invalid number value : " + numberObject, exception);
			//throw new Exception("Invalid number value : " + numberObject);
			return null;
		}
	}

	/**
	 * parseNumber method is to parse object into number and add error message into
	 * set if any occurs.
	 *
	 * @param numberObject            the number object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the number
	 */
	public static Number parseNumber(Object numberObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseNumber(numberObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * parseNumberWithDefault method is to parse object into number.
	 *
	 * @param numberObject the number object
	 * @return the number
	 */
	public static Number parseNumberWithDefault(Object numberObject) {
		if (Objects.isNull(numberObject)) {
			return 0;
		}
		try {
			return parseNumber(numberObject);
		} catch (Exception exception) {
			LOGGER.warn("Invalid number value : " + numberObject, exception);
			return 0;
		}
	}

	/**
	 * parseBigDecimal method is to parse object value into big decimal value.
	 *
	 * @param numberObject the number object
	 * @return the big decimal
	 * @throws Exception the exception
	 */
	public static BigDecimal parseBigDecimal(Object numberObject) throws Exception {
		if (Objects.isNull(numberObject)) {
			return null;
		}
		try {
			return new BigDecimal(numberObject.toString());
		} catch (Exception exception) {
			LOGGER.warn("Invalid BigDecimal value : " + numberObject, exception);
			throw new Exception("Invalid BigDecimal value : " + numberObject);
		}
	}

	/**
	 * parseBigDecimal method is to parse object value into big decimal value.
	 *
	 * @param numberObject            the number object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the big decimal
	 */
	public static BigDecimal parseBigDecimal(Object numberObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseBigDecimal(numberObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * parseBigDecimalWithDefault method is to parse object value into big decimal
	 * value.
	 *
	 * @param numberObject the number object
	 * @return the big decimal
	 */
	public static BigDecimal parseBigDecimalWithDefault(Object numberObject) {
		if (Objects.isNull(numberObject)) {
			return BigDecimal.ZERO;
		}
		try {
			return parseBigDecimal(numberObject);
		} catch (Exception exception) {
			return BigDecimal.ZERO;
		}
	}

	/**
	 * parseBigInteger method is to parse object value into big integer value.
	 *
	 * @param numberObject the number object
	 * @return the big integer
	 * @throws Exception the exception
	 */
	public static BigInteger parseBigInteger(Object numberObject) throws Exception {
		if (Objects.isNull(numberObject)) {
			return null;
		}
		try {
			if (Objects.toString(numberObject).contains(".")) {
				return new BigDecimal(numberObject.toString()).toBigInteger();
			} else {
				return new BigInteger(numberObject.toString());
			}
		} catch (Exception exception) {
			LOGGER.warn("Invalid BigInteger value : " + numberObject, exception);
			throw new Exception("Invalid BigInteger value : " + numberObject);
		}
	}

	/**
	 * parseBigInteger method is to parse object value into big integer value.
	 *
	 * @param numberObject            the number object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the big integer
	 */
	public static BigInteger parseBigInteger(Object numberObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseBigInteger(numberObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * parseBigIntegerWithDefault method is to parse object value into big integer
	 * value.
	 *
	 * @param numberObject the number object
	 * @return the big integer
	 */
	public static BigInteger parseBigIntegerWithDefault(Object numberObject) {
		if (Objects.isNull(numberObject)) {
			return BigInteger.ZERO;
		}
		try {
			return parseBigInteger(numberObject);
		} catch (Exception exception) {
			return BigInteger.ZERO;
		}
	}

	/**
	 * parseInt method is to parse object value into integer value.
	 *
	 * @param value the value
	 * @return the integer
	 * @throws Exception the exception
	 */
	public static Integer parseInt(Object value) throws Exception {
		try {
			return Integer.valueOf(value.toString());
		} catch (Exception exception) {
			String message = "Invalid integer value : " + value;
			throw new Exception(message);
		}
	}

	/**
	 * parseIntWithDefault method is to parse object value into integer and returns
	 * default value 0 if any error occurs.
	 *
	 * @param value the value
	 * @return the integer
	 */
	public static Integer parseIntWithDefault(Object value) {
		try {
			return parseInt(value);
		} catch (Exception e) {
			return 0;
		}
	}

	/**
	 * parseInt method is to parse object into integer and add error message into
	 * set if any occurs.
	 *
	 * @param numberObject            the number object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the integer
	 */
	public static Integer parseInt(Object numberObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseInt(numberObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * parseLong method is to parse object into long value.
	 *
	 * @param value the value
	 * @return the long
	 * @throws Exception the exception
	 */
	public static Long parseLong(Object value) throws Exception {
		try {
			return Long.valueOf(value.toString());
		} catch (Exception exception) {
			String message = "Invalid long value : " + value;
			throw new Exception(message);
		}
	}

	/**
	 * parseLongWithDefault method is to parse value into long and returns default
	 * value if any error occurs.
	 *
	 * @param value the value
	 * @return the long
	 */
	public static Long parseLongWithDefault(Object value) {
		try {
			return Long.valueOf(value.toString());
		} catch (Exception exception) {
			return 0l;
		}
	}

	/**
	 * parseLong method is to parse object into long and add error message into set
	 * if any occurs.
	 *
	 * @param numberObject            the number object
	 * @param errorSet                the error set
	 * @param keyName                 the key name
	 * @param appgenErrorVariableList the appgen error variable list
	 * @return the long
	 */
	public static Long parseLong(Object numberObject, Set<String> errorSet, String keyName,
			Set<String> appgenErrorVariableList) {
		try {
			return parseLong(numberObject);
		} catch (Exception exception) {
			addErrorMessageIntoSet(errorSet, keyName, exception.getMessage(), appgenErrorVariableList);
		}
		return null;
	}

	/**
	 * getFrameworkText method is to get framework text data.
	 *
	 * @param textId the text id
	 * @return the framework text
	 */
	public static String getFrameworkText(String textId) {
		String text = "";
		try {
			text = CacheService.getInstance().getFrameworkTextDefinitionData(textId,
					UserContext.getInstance().getUserProfile().getLocale());
		} catch (QueryException exception) {
			LOGGER.warn("Error on fetching framework text: ", exception);
		}
		return text;
	}

	/**
	 * getApplicationText method is to get application text.
	 *
	 * @param textId      the text id
	 * @param screenDefId the screen def id
	 * @return the application text
	 */
	public static String getApplicationText(String textId, String screenDefId) {
		String text = "";
		try {
			text = CacheService.getInstance().getApplicationTextDefinitionData(textId, screenDefId,
					UserContext.getInstance().getUserProfile().getLocale());
		} catch (QueryException exception) {
			LOGGER.warn("Error on fetching application data: ", exception);
		}
		return text;
	}

	/**
	 * getErrorMessages is used to get the error messages list.
	 *
	 * @param tableName the table name
	 * @param resultMap the result map
	 * @return List<String>
	 */
	public static List<String> getErrorMessages(String tableName, Map<String, Object> resultMap) {
		return JsonUtils.fromJsonOrElse(Objects.toString(resultMap.get("message")),
				new TypeReference<Map<String, List<String>>>() {
				}, new HashMap<>()).getOrDefault(tableName, Arrays.asList(Objects.toString(resultMap.get("message"))));
	}

	/**
	 * isDataTypeEqual method is to check value data type is equal to the given
	 * type.
	 *
	 * @param <T>   the generic type
	 * @param value the value
	 * @param type  the type
	 * @return true, if is data type equal
	 */
	public static <T> boolean isDataTypeEqual(Object value, TypeReference<T> type) {
		return value.getClass().equals(type.getType());
	}

	/**
	 * To get Program details.
	 *
	 * @param dataMap the data map
	 * @return map
	 */
	public Map<String, Object> getProgramDetails(Map<String, Object> dataMap) {
		String apiName = Objects.toString(dataMap.get("apiName"));
		String programId = "";
		if (StringUtils.isNotEmpty(apiName) && !apiName.equals("null")) {
			QueryBuilder builder = new QueryBuilder();
			try {
				List<Map<String, Object>> programDetails = builder.select().from("program_detail").get("program_id")
						.where(ConditionBuilder.instance().eq("program_name", apiName).and().eq("api_type",
								"automatic"))
						.build(false).execute();
				programId = Optional.ofNullable(programDetails).filter(CollectionUtils::isNotEmpty)
						.map(mapper -> mapper.get(0)).filter(MapUtils::isNotEmpty)
						.map(mapper -> mapper.get("program_id")).map(Objects::toString).orElse(StringUtils.EMPTY);
			} catch (QueryException e) {
			}
		}
		return ImmutableMap.<String, Object>builder().put("programId", programId).build();
	}

	/**
	 * To get date List Data.
	 *
	 * @param startDate the start date
	 * @param endDate   the end date
	 * @param format    the format
	 * @return List<String>
	 */
	public static List<String> getDateMonthYearList(Date startDate, Date endDate, String format) {
		List<String> dateList = new ArrayList<String>();
		List<Date> resultDatesList = getDateMonthYearDataList(startDate, endDate, format);
		dateList = resultDatesList.stream().map(mapper -> getDateMonthYearData(mapper, format))
				.collect(Collectors.toList());
		return dateList;
	}

	/**
	 * To get getDateMonthYear List Data.
	 *
	 * @param startDate the start date
	 * @param endDate   the end date
	 * @param format    the format
	 * @return List<String>
	 */
	private static List<Date> getDateMonthYearDataList(Date startDate, Date endDate, String format) {
		List<Date> dates = new ArrayList<Date>();
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(startDate);
		while (calendar.getTime().before(endDate)) {
			Date result = calendar.getTime();
			dates.add(result);
			if (format.equals("date")) {
				calendar.add(Calendar.DATE, 1);
			}
			if (format.equals("month")) {
				calendar.add(Calendar.MONTH, 1);
			}
			if (format.equals("year")) {
				calendar.add(Calendar.YEAR, 1);
			}
		}
		return dates;
	}

	/**
	 * To get DateMonthYear Data.
	 *
	 * @param date         the date
	 * @param returnFormat the return format
	 * @return String
	 */
	// date,month,year,time this method is used to get date month year time with
	// return type will be MMM
	public static String getDateMonthYearData(Object date, String returnFormat) {
		Date convertedDate = null;
		try {
			convertedDate = dateConverter(date);
		} catch (Exception e) {
			LOGGER.warn("Invalid date value : " + date, e);
			return null;
		}
		if (Arrays.asList("MMM").contains(returnFormat)) {
			String dateFormat = Objects.toString(returnFormat).toUpperCase();
			String pattern = DateStyle.getPattern(ContextBean.getLocaleHolder(), DateStyle.valueOf(dateFormat));
			SimpleDateFormat dateFormatter = new SimpleDateFormat(pattern, ContextBean.getLocaleHolder());
			return dateFormatter.format(convertedDate);
		} else {
			OffsetDateTime dateValue = getOffsetDateTime(convertedDate.getTime());
			String returnData = null;
			switch (returnFormat) {
			case "month":
				returnData = Objects.toString(dateValue.getMonthValue());
				break;
			case "year":
				returnData = Objects.toString(dateValue.getYear());
				break;
			case "time":
				returnData = Objects.toString(dateValue.toEpochSecond());
				break;
			case "date":
				returnData = Objects.toString(dateValue.getDayOfMonth());
				break;
			case "completeDate":
			default:
				returnData = Objects.toString(dateValue.toLocalDate());
				break;
			}
			return returnData;
		}
	}

	/**
	 * parseTimeForDataAccess method is to parse time access object into time.
	 *
	 * @param dataMap   the data map
	 * @param columnKey the column key
	 */
	public static void parseTimeForDataAccess(Map<String, Object> dataMap, String columnKey) {
		if (Objects.isNull(dataMap.get(columnKey))) {
			return;
		}
		if (dataMap.get(columnKey) instanceof List) {
			List<Object> swapList = getListForReference(dataMap.get(columnKey), new TypeReference<Object>() {
			});
			dataMap.put(columnKey, swapList.stream().filter(Objects::nonNull).map(Objects::toString).map(mapper -> {
				try {
					return getTimestampFromTime(mapper);
				} catch (Exception e) {
					return mapper;
				}
			}).collect(Collectors.toList()));
		} else if (dataMap.get(columnKey) instanceof Map) {
			Map<String, Object> swapMap = getNonNullMap(dataMap.get(columnKey));
			Map<String, Object> returnMap = swapMap.keySet().stream()
					.collect(Collectors.toMap(Function.identity(), key -> {
						if (swapMap.get(key) instanceof List || swapMap.get(key) instanceof Collection
								|| swapMap.get(key).getClass().isArray()) {
							return getListForReference(swapMap.get(key), new TypeReference<Object>() {
							}).stream().filter(Objects::nonNull).map(Objects::toString).map(mapper -> {
								try {
									return getTimestampFromTime(mapper);
								} catch (Exception e) {
									return mapper;
								}
							}).collect(Collectors.toList());
						} else {
							try {
								return getTimestampFromTime(swapMap.get(key));
							} catch (Exception e) {
								return swapMap.get(key);
							}
						}
					}));
			dataMap.put(columnKey, returnMap);
		} else {
			try {
				dataMap.put(columnKey, getTimestampFromTime(dataMap.get(columnKey)));
			} catch (Exception exception) {
				return;
			}
		}
	}

	/**
	 * getTimestampFromTime method is to get Timestamp value from time.
	 *
	 * @param value the value
	 * @return the timestamp from time
	 * @throws Exception the exception
	 */
	private static Timestamp getTimestampFromTime(Object value) throws Exception {
		String[] splitted = Objects.toString(value, "").split(":");
		if (splitted.length == 3 && splitted[0].length() == 2) {
			value = "1970-01-01 " + value;
		}

		return getTimeStamp(value);
	}

	/**
	 * To get individual time element Data.
	 *
	 * @param date         the date
	 * @param returnFormat the return format
	 * @return String
	 */
	public static String getTimeElemetFromTimestamp(Object date, String returnFormat) {
		Timestamp convertedDate = null;
		try {
			convertedDate = getTimeStamp(date);
		} catch (Exception e) {
			LOGGER.warn("Invalid date value : " + date);
		}
		if (Arrays.asList("MMM").contains(returnFormat)) {
			String dateFormat = Objects.toString(returnFormat).toUpperCase();
			String pattern = DateStyle.getPattern(ContextBean.getLocaleHolder(), DateStyle.valueOf(dateFormat));
			SimpleDateFormat dateFormatter = new SimpleDateFormat(pattern, ContextBean.getLocaleHolder());
			return dateFormatter.format(convertedDate);
		} else {
			OffsetDateTime dateValue = null;
			String hour = "";
			String minute = "";
			String second = "";
			try {
				dateValue = getOffsetDateTime(convertedDate.getTime());
				hour = Objects.toString(dateValue.getHour());
				minute = Objects.toString(dateValue.getMinute());
				second = Objects.toString(dateValue.getSecond());
			} catch (Exception e) {
				LOGGER.warn("getOffsetDateTime error.");
				if (Objects.toString(date).split(":").length == 3) {
					String[] splittedData = Objects.toString(date).split(":");
					hour = splittedData[0];
					minute = splittedData[1];
					second = splittedData[2];
				}
			}
			String returnData = null;
			switch (returnFormat) {
			case "hour":
				returnData = hour;
				break;
			case "minute":
				returnData = minute;
				break;
			case "second":
				returnData = second;
				break;
			case "time":
				returnData = hour + ":" + minute + ":" + second;
				break;
			default:
				break;
			}
			return returnData;
		}
	}

	/**
	 * To get individual time element Data.
	 *
	 * @param date         the date
	 * @param returnFormat the return format
	 * @return String
	 */
	public static String getTimeElemetFromDate(Object date, String returnFormat) {
		Date convertedDate = null;
		try {
			convertedDate = getTimeStamp(date);
		} catch (Exception e) {
			LOGGER.warn("Invalid date value : " + date, e);
		}
		if (Arrays.asList("MMM").contains(returnFormat)) {
			String dateFormat = Objects.toString(returnFormat).toUpperCase();
			String pattern = DateStyle.getPattern(ContextBean.getLocaleHolder(), DateStyle.valueOf(dateFormat));
			SimpleDateFormat dateFormatter = new SimpleDateFormat(pattern, ContextBean.getLocaleHolder());
			return dateFormatter.format(convertedDate);
		} else {
			OffsetDateTime dateValue = getOffsetDateTime(convertedDate.getTime());
			String returnData = null;
			switch (returnFormat) {
			case "hour":
				returnData = Objects.toString(dateValue.getHour());
				break;
			case "minute":
				returnData = Objects.toString(dateValue.getMinute());
				break;
			case "second":
				returnData = Objects.toString(dateValue.getSecond());
				break;
			case "time":
				returnData = Objects.toString(dateValue.getHour()) + ":" + Objects.toString(dateValue.getMinute()) + ":"
						+ Objects.toString(dateValue.getSecond());
				break;
			default:
				break;
			}
			return returnData;
		}
	}

	/**
	 * getTimeDifference method is used to get the difference between two time
	 * values.
	 *
	 * @param startTime the start time
	 * @param endTime   the end time
	 * @return String
	 */
	public static String getTimeDifference(String startTime, String endTime) {
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		Date startDate = null;
		Date endDate = null;
		if (StringUtils.isEmpty(startTime) || StringUtils.isEmpty(endTime)) {
			return StringUtils.EMPTY;
		}
		try {
			startDate = format.parse(startTime);
			endDate = format.parse(endTime);
		} catch (ParseException exception) {
			LOGGER.warn("Parser Exception in getTimeDifference: ", exception);
			return StringUtils.EMPTY;
		}
		long differenceTime = (endDate.getTime() - startDate.getTime()) / 1000;
		int seconds = (int) differenceTime % 60;
		int minutes = (int) (differenceTime / 60) % 60;
		int hours = (int) (differenceTime / (60 * 60)) % 24;
		return String.format("%02d:%02d:%02d", hours, minutes, seconds);
	}

	/**
	 * incrementDate method is used to increase date,month and year.
	 *
	 * @param dateValueObject the date value object
	 * @param incrementCount  the increment count
	 * @param returnFormat    the return format
	 * @param incrementFor    the increment for
	 * @return incrementCount
	 */
	public static String incrementDate(Object dateValueObject, String incrementCount, String returnFormat,
			String incrementFor) {
		try {
			if (Objects.isNull(parseNumber(incrementCount))) {
				LOGGER.info("Not a Number for incrementDate method: " + incrementCount);
				return StringUtils.EMPTY;
			}
			Date dateValue = dateConverter(dateValueObject);
			DateTime dateTimeValue = new DateTime(dateValue);
			int addValue = Integer.valueOf(incrementCount);
			DateTime changedDateTime = new DateTime();
			switch (incrementFor) {
			case "Months":
				changedDateTime = dateTimeValue.plusMonths(addValue);
				break;

			case "Years":
				changedDateTime = dateTimeValue.plusYears(addValue);
				break;
			case "Hours":
				changedDateTime = dateTimeValue.plusHours(addValue);
				break;
			case "Minutes":
				changedDateTime = dateTimeValue.plusMinutes(addValue);
				break;
			case "Seconds":
				changedDateTime = dateTimeValue.plusSeconds(addValue);
				break;
			case "Millis":
				changedDateTime = dateTimeValue.plusMillis(addValue);
				break;
			case "Days":
			default:
				changedDateTime = dateTimeValue.plusDays(addValue);
				break;

			}
			return DateTimeUtils.formatWithTime(new Timestamp(changedDateTime.getMillis()));
		} catch (Exception exception) {
			LOGGER.warn("Exception in incrementDate: ", exception);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * decrementDate method is used to decrease date,month and year.
	 *
	 * @param dateValueObject the date value object
	 * @param decrementCount  the decrement count
	 * @param returnFormat    the return format
	 * @param decrementFor    the decrement for
	 * @return decrementCount
	 */
	public static String decrementDate(Object dateValueObject, String decrementCount, String returnFormat,
			String decrementFor) {
		try {
			if (Objects.isNull(parseNumber(decrementCount))) {
				LOGGER.info("Not a Number for decrementDate method: " + decrementCount);
				return StringUtils.EMPTY;
			}
			Date dateValue = dateConverter(dateValueObject);
			DateTime dateTimeValue = new DateTime(dateValue);
			int addValue = Integer.valueOf(decrementCount);
			DateTime changedDateTime = new DateTime();
			switch (decrementFor) {
			case "Months":
				changedDateTime = dateTimeValue.minusMonths(addValue);
				break;

			case "Years":
				changedDateTime = dateTimeValue.minusYears(addValue);
				break;

			case "Days":
			default:
				changedDateTime = dateTimeValue.minusDays(addValue);
				break;

			}
			if ("userFormat".equals(returnFormat)) {
				return DateTimeUtils.formatWithDate(changedDateTime.toDate());
			} else {
				return DateTimeUtils.formatDateToString(changedDateTime.toDate(), "yyyy/MM/dd");
			}
		} catch (Exception exception) {
			return StringUtils.EMPTY;
		}

	}

	/**
	 * getDayOfWeek method is used to get day of the week.
	 *
	 * @param dateValueObject the date value object
	 * @return int
	 */
	public static int getDayOfWeek(Object dateValueObject) {
		int dayOfWeekValue = 0;
		Date dateValue = null;
		try {
			dateValue = dateConverter(dateValueObject);
		} catch (Exception e) {
			LOGGER.warn("Invalid date value : " + dateValueObject, e);
		}
		if (Objects.nonNull(dateValue)) {
			Calendar calendarDateValue = Calendar.getInstance();
			calendarDateValue.setTime(dateValue);
			dayOfWeekValue = calendarDateValue.get(Calendar.DAY_OF_WEEK);
		} else {
			LOGGER.warn("Not a proper date for getDayOfWeek method: " + dateValueObject);
		}
		return dayOfWeekValue;
	}

	/**
	 * To get Date Difference.
	 *
	 * @param startDateObject  the start date object
	 * @param endDateObject    the end date object
	 * @param getDifferenceFor the get difference for
	 * @param isIncludeEndDate the is include end date
	 * @return difference
	 */
	public static int getDateDifference(Object startDateObject, Object endDateObject, String getDifferenceFor,
			Boolean isIncludeEndDate) {
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = dateConverter(startDateObject);
			endDate = dateConverter(endDateObject);
		} catch (Exception e) {
			LOGGER.warn("Invalid date value : " + startDateObject, e);
		}
		int returnValue = 0;
		if (Objects.isNull(startDate) || Objects.isNull(endDate)) {
			LOGGER.info("Null value present for getDateDifference method: " + startDate + " " + endDate);
			return returnValue;
		}
		if (isIncludeEndDate) {
			endDate = new Date(endDate.getTime() + (1000 * 60 * 60 * 24));
		}
		DateTime startDateTime = new DateTime(startDate);
		DateTime endDateTime = new DateTime(endDate);
		Years years = Years.yearsBetween(startDateTime, endDateTime);
		Months months = Months.monthsBetween(startDateTime, endDateTime);
		Weeks weeks = Weeks.weeksBetween(startDateTime, endDateTime);
		Days days = Days.daysBetween(startDateTime, endDateTime);
		switch (getDifferenceFor) {
		case "Years":
			return years.getYears();
		case "Months":
			return months.getMonths();
		case "Weeks":
			return weeks.getWeeks();
		case "Days":
		default:
			return days.getDays();
		}
	}

	/**
	 * getModifiedDate is to modify the value of given date.
	 *
	 * @param dateValueObject the date value object
	 * @param modifyCount     the modify count
	 * @param returnFormat    the return format
	 * @param modifingFor     the modifing for
	 * @return String
	 */
	public static String getModifiedDate(Object dateValueObject, Object modifyCount, String returnFormat,
			String modifingFor) {
		Integer modifingValue = parseIntWithDefault(Objects.toString(modifyCount));
		if (modifingValue != 0) {
			return incrementDate(dateValueObject, Objects.toString(modifyCount), returnFormat, modifingFor);
		}
		try {
			return DateTimeUtils.formatWithTime(Timestamp.from(dateConverter(dateValueObject).toInstant()));
		} catch (Exception exception) {
			return StringUtils.EMPTY;
		}
	}

	/**
	 * getDateTimeDifference method is used to get the difference between two date
	 * values.
	 *
	 * @param startDateObject  the start date object
	 * @param endDateObject    the end date object
	 * @param differenceType   the difference type
	 * @param timeType         the time type
	 * @param isIncludeEndDate the is include end date
	 * @param isText           the is text
	 * @return String
	 */
	public static String getDateTimeDifference(Object startDateObject, Object endDateObject, String differenceType,
			String timeType, boolean isIncludeEndDate, boolean isText) {
		if (Objects.isNull(startDateObject) || Objects.isNull(endDateObject)) {
			return StringUtils.EMPTY;
		}
		String dateDifferenceText = StringUtils.EMPTY;
		Timestamp startTimestamp = null;
		try {
			startTimestamp = getTimeStamp(startDateObject);
		} catch (Exception e) {
			LOGGER.warn("Invalid timestamp value : " + startDateObject, e);
		}
		Timestamp endTimestamp = null;
		try {
			endTimestamp = getTimeStamp(endDateObject);
		} catch (Exception e) {
			LOGGER.warn("Invalid timestamp value : " + endTimestamp, e);
		}
		if (Objects.isNull(startTimestamp) || Objects.isNull(endTimestamp)) {
			LOGGER.warn(
					"Null Timestamp value present for getDateTimeDifference: " + startDateObject + " " + endDateObject);
			return StringUtils.EMPTY;
		}
		if (isText) {
			dateDifferenceText = getDateDifferenceText(new Date(startTimestamp.getTime()),
					new Date(endTimestamp.getTime()), differenceType, isIncludeEndDate);
		} else {
			int dateDifference = getDateDifference(new Date(startTimestamp.getTime()), new Date(endTimestamp.getTime()),
					differenceType, isIncludeEndDate);
			dateDifferenceText = Objects.toString(dateDifference) + " " + differenceType;
		}
		if (StringUtils.isNotEmpty(timeType)) {
			SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
			String startTime = format.format(startTimestamp);
			String endTime = format.format(endTimestamp);
			String resultTime = getTimeDifference(startTime, endTime);
			String[] resultArray = resultTime.split(":");
			String hoursText = getFrameworkText("nn_appgen_common_hours_text");
			String minutesText = getFrameworkText("nn_appgen_common_minutes_text");
			String secondText = getFrameworkText("nn_appgen_common_second_text");
			switch (timeType) {
			case "HMS":
				return String.join(" ", dateDifferenceText, resultArray[0], hoursText, resultArray[1], minutesText,
						resultArray[2], secondText);
			case "HM":
				return String.join(" ", dateDifferenceText, resultArray[0], hoursText, resultArray[1], minutesText);
			case "HS":
				return String.join(" ", dateDifferenceText, resultArray[0], hoursText, resultArray[2], secondText);
			case "MS":
				return String.join(" ", dateDifferenceText, resultArray[1], minutesText, resultArray[2], secondText);
			case "S":
				return String.join(" ", dateDifferenceText, resultArray[2], secondText);
			case "M":
				return String.join(" ", dateDifferenceText, resultArray[1], minutesText);
			case "H":
				return String.join(" ", dateDifferenceText, resultArray[0], hoursText);
			}
		}

		return dateDifferenceText;

	}

	/**
	 * getOffsetDateTime method is to get offset date time.
	 *
	 * @param timestamp the timestamp
	 * @return the offset date time
	 */
	public static OffsetDateTime getOffsetDateTime(Long timestamp) {
		Instant instant = Instant.ofEpochMilli(timestamp);
		if (Objects.nonNull(ContextBean.getTimeZone())) {
			return OffsetDateTime.ofInstant(instant, ZoneId.of(ContextBean.getTimeZone()));
		}
		return OffsetDateTime.ofInstant(instant, ZoneId.systemDefault());
	}

	/**
	 * convertTimeToMs method is used to convert the time to Milli Seconds.
	 *
	 * @param timeValue the time value
	 * @return String
	 */
	public static String convertTimeToMs(String timeValue) {
		if (StringUtils.isEmpty(timeValue)) {
			LOGGER.info("Empty value present in convertTimeToMs method: " + timeValue);
			return StringUtils.EMPTY;
		}
		try {
			LocalTime localTimeValue = LocalTime.parse(timeValue);
			return Objects.toString(Duration.between(LocalTime.MIN, localTimeValue).toMillis(), StringUtils.EMPTY);
		} catch (Exception exception) {
			LOGGER.warn("Error in convertTimeToMs: ", exception);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * convertTimeToMinutes method is used to convert the time to Minutes.
	 *
	 * @param timeValue the time value
	 * @return String
	 */
	public static String convertTimeToMinutes(String timeValue) {
		if (StringUtils.isEmpty(timeValue)) {
			LOGGER.info("Empty value present in convertTimeToMinutes method: " + timeValue);
			return StringUtils.EMPTY;
		}
		try {
			LocalTime localTimeValue = LocalTime.parse(timeValue);
			return Objects.toString(Duration.between(LocalTime.MIN, localTimeValue).toMinutes(), StringUtils.EMPTY);
		} catch (Exception exception) {
			LOGGER.warn("Error in convertTimeToMinutes: ", exception);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * convertMsToTime method is used to convert the milliseconds to time.
	 *
	 * @param millisecondValue the millisecond value
	 * @return String
	 */
	public static String convertMsToTime(String millisecondValue) {
		if (StringUtils.isEmpty(millisecondValue)) {
			LOGGER.info("Empty value present in convertMsToTime method: " + millisecondValue);
			return StringUtils.EMPTY;
		}
		try {
			long milliSeconds = Integer.parseInt(millisecondValue) / 1000;
			int seconds = (int) milliSeconds % 60;
			int minutes = (int) (milliSeconds / 60) % 60;
			int hours = (int) (milliSeconds / (60 * 60)) % 24;
			return String.format("%02d:%02d:%02d", hours, minutes, seconds);
		} catch (Exception exception) {
			LOGGER.warn("Error in convertMsToTime: ", exception);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * convertMinutesToTime method is used to convert the minutes to time.
	 *
	 * @param minutesParam the minutes param
	 * @return String
	 */
	public static String convertMinutesToTime(String minutesParam) {
		if (StringUtils.isEmpty(minutesParam)) {
			LOGGER.info("Empty value present in convertMinutesToTime method: " + minutesParam);
			return StringUtils.EMPTY;
		}
		try {
			long minutesValue = Integer.parseInt(minutesParam);
			int minutes = (int) (minutesValue % 60);
			int hours = (int) (minutesValue / 60);
			return String.format("%02d:%02d", hours, minutes);
		} catch (Exception exception) {
			LOGGER.warn("Error in convertMinutesToTime: ", exception);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * getFirstDateOfTheMonth method is used to get First date of month.
	 *
	 * @param dateValueObject the date value object
	 * @param returnFormat    the return format
	 * @return String
	 */
	public static String getFirstDateOfTheMonth(Object dateValueObject, String returnFormat) {
		try {
			Date dateValue = dateConverter(dateValueObject);
			Calendar calendarInstance = Calendar.getInstance();
			calendarInstance.setTime(dateValue);
			calendarInstance.set(Calendar.DAY_OF_MONTH, calendarInstance.getActualMinimum(Calendar.DAY_OF_MONTH));
			if (returnFormat.equals("userFormat")) {
				return DateTimeUtils.formatWithDate(calendarInstance.getTime());
			} else {
				return DateTimeUtils.formatDateToString(calendarInstance.getTime(), "yyyy/MM/dd");
			}
		} catch (Exception exception) {
			LOGGER.warn("Error in getFirstDateOfTheMonth: ", exception);
			return StringUtils.EMPTY;
		}

	}

	/**
	 * getLastDateOfTheMonth method is used to get last date of month.
	 *
	 * @param dateValueObject the date value object
	 * @param returnFormat    the return format
	 * @return String
	 */
	public static String getLastDateOfTheMonth(Object dateValueObject, String returnFormat) {
		try {
			Date dateValue = dateConverter(dateValueObject);
			Calendar calendarInstance = Calendar.getInstance();
			calendarInstance.setTime(dateValue);
			calendarInstance.set(Calendar.DAY_OF_MONTH, calendarInstance.getActualMaximum(Calendar.DAY_OF_MONTH));
			if (returnFormat.equals("userFormat")) {
				return DateTimeUtils.formatWithDate(calendarInstance.getTime());
			} else {
				return DateTimeUtils.formatDateToString(calendarInstance.getTime(), "yyyy/MM/dd");
			}
		} catch (Exception exception) {
			LOGGER.warn("Error in getLastDateOfTheMonth: ", exception);
			return StringUtils.EMPTY;
		}

	}

	/**
	 * getNumberOfDaysInMonth method is used to get number of days in a month.
	 *
	 * @param dateValueObject the date value object
	 * @param returnFormat    the return format
	 * @return Integer
	 */
	public static Integer getNumberOfDaysInMonth(Object dateValueObject, String returnFormat) {
		try {
			Date dateValue = dateConverter(dateValueObject);
			Calendar calendarInstance = Calendar.getInstance();
			calendarInstance.setTime(dateValue);
			return calendarInstance.getActualMaximum(Calendar.DAY_OF_MONTH);
		} catch (Exception exception) {
			LOGGER.warn("Error in getNumberOfDaysInMonth: ", exception);
			return null;
		}

	}

	/**
	 * getCustomFormat is used to format date with custom style.
	 *
	 * @param dateValueObject the date value object
	 * @param dateFormat      the date format
	 * @return String
	 */
	public static String getCustomFormat(Object dateValueObject, String dateFormat) {
		try {
			Date dateValue = dateConverter(dateValueObject);
			DateTime dateTimeValue = new DateTime(dateValue);
			return DateTimeUtils.format(dateTimeValue.toDate(), dateFormat);
		} catch (Exception exception) {
			LOGGER.warn("Exception in incrementDate: ", exception);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * getDateDifference method is used to get the difference between two date
	 * values.
	 *
	 * @param startDateObject the start date object
	 * @param endDateObject   the end date object
	 * @param condition       the condition
	 * @return boolean
	 */
	public static boolean getDateComparision(Object startDateObject, Object endDateObject, String condition) {
		Date startDate = null;
		try {
			startDate = dateConverter(startDateObject);
		} catch (Exception exception) {
			LOGGER.warn("Invalid date value : " + startDateObject, exception);
		}
		Date endDate = null;
		try {
			endDate = dateConverter(endDateObject);
		} catch (Exception exception) {
			LOGGER.warn("Invalid date value : " + endDateObject, exception);
		}
		if (Objects.isNull(startDate) && Objects.isNull(endDate)) {
			return true;
		} else if (Objects.isNull(startDate) || Objects.isNull(endDate)) {
			return false;
		}
		switch (condition) {
		case "=":
		case "==":
		case "===":
			return startDate.equals(endDate);

		case "!=":
		case "!==":
			return !startDate.equals(endDate);

		case "<":
			return startDate.before(endDate);

		case ">":
			return startDate.after(endDate);

		case "<=":
			return startDate.before(endDate) || startDate.equals(endDate);

		case ">=":
			return startDate.after(endDate) || startDate.equals(endDate);

		}
		return false;

	}

	/**
	 * calculateDateDifference method is used to get the difference between two date
	 * values.
	 *
	 * @param startDate        the start date
	 * @param endDate          the end date
	 * @param isIncludeEndDate the is include end date
	 * @return boolean
	 */
	public static Map<String, Integer> calculateDateDifference(Date startDate, Date endDate, boolean isIncludeEndDate) {
		Map<String, Integer> dateDiffMap = new HashMap<String, Integer>();
		if (isIncludeEndDate) {
			endDate = new Date(endDate.getTime() + (1000 * 60 * 60 * 24));
		}
		Period period = Period.between(startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
				endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		dateDiffMap.put("yearDiff", period.getYears());
		dateDiffMap.put("monthDiff", period.getMonths());
		dateDiffMap.put("daysDiff", period.getDays());
		return dateDiffMap;
	}

	/**
	 * getDateDifference method is used to get the difference between two date
	 * values.
	 *
	 * @param startDateObject  the start date object
	 * @param endDateObject    the end date object
	 * @param differenceType   the difference type
	 * @param isIncludeEndDate the is include end date
	 * @return String
	 */
	public static String getDateDifferenceText(Object startDateObject, Object endDateObject, String differenceType,
			boolean isIncludeEndDate) {
		Date startDate = null;
		try {
			startDate = dateConverter(startDateObject);
		} catch (Exception exception) {
			LOGGER.warn("Invalid date value : " + startDateObject, exception);
		}
		Date endDate = null;
		try {
			endDate = dateConverter(endDateObject);
		} catch (Exception exception) {
			LOGGER.warn("Invalid date value : " + endDateObject, exception);
		}
		if (Objects.isNull(startDate) || Objects.isNull(endDate)) {
			return StringUtils.EMPTY;
		}
		Map<String, Integer> dateDiffMap = new HashMap<String, Integer>();
		dateDiffMap = calculateDateDifference(startDate, endDate, isIncludeEndDate);
		String yearsText = getApplicationText("nn_appgen_year_text", "ProgramDesigner");
		String monthsText = getApplicationText("nn_appgen_month_text", "ProgramDesigner");
		String weeksText = getApplicationText("nn_appgen_week_text", "ProgramDesigner");
		String daysText = getApplicationText("nn_appgen_day_text", "ProgramDesigner");
		switch (differenceType) {
		case "YearMonthWeekDay":
			return Objects.toString(dateDiffMap.get("yearDiff") + " " + yearsText + " " + dateDiffMap.get("monthDiff")
					+ " " + monthsText + " " + Integer.parseInt(Objects.toString(dateDiffMap.get("daysDiff") / 7)) + " "
					+ weeksText + " " + (dateDiffMap.get("daysDiff") % 7) + " " + daysText);

		case "YearMonthWeek":
			return Objects.toString(dateDiffMap.get("yearDiff") + " " + yearsText + " " + dateDiffMap.get("monthDiff")
					+ " " + monthsText + " " + Integer.parseInt(Objects.toString(dateDiffMap.get("daysDiff") / 7)) + " "
					+ weeksText);

		case "YearMonthDay":
			return Objects.toString(dateDiffMap.get("yearDiff") + " " + yearsText + " " + dateDiffMap.get("monthDiff")
					+ " " + monthsText + " " + dateDiffMap.get("daysDiff") + " " + daysText);

		case "YearMonth":
			return Objects.toString(dateDiffMap.get("yearDiff") + " " + yearsText + " " + dateDiffMap.get("monthDiff")
					+ " " + monthsText);

		case "YearWeekDay":
		case "YearWeek":
		case "YearDay":
			return StringUtils.EMPTY;

		case "MonthWeekDay":
			return Objects.toString(((dateDiffMap.get("yearDiff") * 12) + dateDiffMap.get("monthDiff")) + " "
					+ monthsText + " " + Integer.parseInt(Objects.toString(dateDiffMap.get("daysDiff") / 7)) + " "
					+ weeksText + " " + (dateDiffMap.get("daysDiff") % 7) + " " + daysText);

		case "MonthWeek":
			return Objects.toString(
					((dateDiffMap.get("yearDiff") * 12) + dateDiffMap.get("monthDiff")) + " " + monthsText + " "
							+ Integer.parseInt(Objects.toString(dateDiffMap.get("daysDiff") / 7)) + " " + weeksText);

		case "MonthDay":
			return Objects.toString(((dateDiffMap.get("yearDiff") * 12) + dateDiffMap.get("monthDiff")) + " "
					+ monthsText + " " + dateDiffMap.get("daysDiff") + " " + daysText);

		case "WeekDay":
			DateTime startDateTime = new DateTime(startDate);
			DateTime endDateTime = new DateTime(endDate);
			Days days = Days.daysBetween(startDateTime, endDateTime);
			int totalDiffDays = days.getDays() + (isIncludeEndDate ? 1 : 0);
			return Objects.toString(Integer.parseInt(Objects.toString(totalDiffDays / 7)) + " " + weeksText + " "
					+ (totalDiffDays % 7) + " " + daysText);

		}
		return StringUtils.EMPTY;

	}

	/**
	 * convertPrimaryDataToCamel method is to convert primary underscore data to
	 * camel case data.
	 *
	 * @param data the data
	 * @return the list
	 */
	public static List<Map<String, Object>> convertPrimaryDataToCamel(Collection<List<Map<String, Object>>> data) {
		if (CollectionUtils.isEmpty(data)) {
			return new ArrayList<>();
		}
		List<Map<String, Object>> returnList = new ArrayList<>();
		data.stream().forEach(action -> {
			returnList.addAll(action);
		});
		return convertUnderScoreToCamelCase(returnList);
	}

	/**
	 * convertUnderScoreToCamelCase method is to convert underscore data list into
	 * without table name camel case data list.
	 *
	 * @param dataList the data list
	 * @return the list
	 */
	public static List<Map<String, Object>> convertUnderScoreToCamelCase(List<Map<String, Object>> dataList) {
		List<Map<String, Object>> modifiedList = dataList.stream().map(action -> {
			return convertUnderScoreToCamelCaseData(action);
		}).collect(Collectors.toList());

		return modifiedList;
	}

	/**
	 * convertUnderScoreToCamelCaseData method is to convert underscore data to
	 * without table name camel case data map.
	 *
	 * @param dataMap the data map
	 * @return the map
	 */
	public static Map<String, Object> convertUnderScoreToCamelCaseData(Map<String, Object> dataMap) {
		Map<String, Object> returnMap = new HashMap<>();
		dataMap.entrySet().stream().forEach(mapAction -> {
			String key = mapAction.getKey();
			if (key.contains(".")) {
				key = key.split("\\.")[1];
			}
			String newKey = key;
			if (!key.contains("___")) {
				newKey = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, key);
			}
			returnMap.put(newKey, mapAction.getValue());
		});
		return returnMap;
	}

	/**
	 * processResultMap method is to process data access resultMap.
	 *
	 * @param resultMap the result map
	 */
	public static void processResultMap(Map<String, Object> resultMap) {
		if ("select".equals(resultMap.get("queryOperation"))) {
			List<Map<String, Object>> dataList = getListForReference(resultMap.get(DATA),
					new TypeReference<Map<String, Object>>() {
					});
			if (!Boolean.valueOf(Objects.toString(resultMap.get("status")))) {
				resultMap.remove(DATA);
			} else if (CollectionUtils.isEmpty(dataList)) {
				resultMap.put(MESSAGE, getFrameworkText("data_does_not_exist"));
				resultMap.remove(DATA);
			} else {
				updateJsonColumnData(dataList,
						getListForReference(resultMap.get("jsonColumnList"), new TypeReference<String>() {
						}));
				resultMap.remove("jsonColumnList");
			}
			resultMap.remove("queryOperation");
			resultMap.remove("tableName");
			return;
		}
		if (resultMap.get(DATA) instanceof List) {
			List<Map<String, Object>> dataList = getListForReference(resultMap.get(DATA),
					new TypeReference<Map<String, Object>>() {
					});
			dataList = convertUnderScoreToCamelCase(dataList);
			resultMap.put(DATA, dataList);
		} else if (resultMap.get(DATA) instanceof Map) {
			Map<String, Object> dataMap = getNonNullMap(resultMap.get(DATA));
			dataMap = convertUnderScoreToCamelCaseData(dataMap);
			resultMap.put(DATA, dataMap);
		}
		int[] affectedCount = (int[]) resultMap.get(AFFECTED_COUNT);
		if (Objects.nonNull(affectedCount)) {
			int affectedRows = Arrays.stream(affectedCount).sum();
			resultMap.put(AFFECTED_ROWS, affectedRows);

			boolean status = getNonNullBoolean(resultMap.get("status"));
			if (status && affectedRows == 0) {
				if ("update".equals(resultMap.get("queryOperation"))) {
					resultMap.put(MESSAGE, getFrameworkText("data_does_not_exist_to_update"));
				} else if ("delete".equals(resultMap.get("queryOperation"))) {
					resultMap.put(MESSAGE, getFrameworkText("data_does_not_exist_to_delete"));
				}
			}
		}
		Multimap<String, List<Map<String, Object>>> result = (Multimap<String, List<Map<String, Object>>>) resultMap
				.get(RESULT);
		String tableName = Objects.toString(resultMap.get("tableName"), "");
		if (Objects.nonNull(result) && StringUtils.isNotEmpty(tableName)) {
			List<Map<String, Object>> updatedResultList = new ArrayList<>();
			result.get(tableName).stream().forEach(action -> {
				updatedResultList.addAll(action);
			});
			resultMap.put(RESULT, updatedResultList);
		} else {
			resultMap.remove(RESULT);
		}
		resultMap.remove("queryOperation");
		resultMap.remove("tableName");
	}

	/**
	 * updateJsonColumnData is to update json column data.
	 *
	 * @param dataList   the data list
	 * @param columnList the column list
	 */
	public static void updateJsonColumnData(List<Map<String, Object>> dataList, List<String> columnList) {
		if (CollectionUtils.isEmpty(columnList))
			return;
		dataList.stream().forEach(data -> columnList.stream().filter(predicate -> Objects.nonNull(data.get(predicate)))
				.forEach(column -> {
					try {
						String pgObjectValue = ((PGobject) data.get(column)).getValue();
						data.put(column, JsonUtils.fromJsonOrThrow(Objects.toString(pgObjectValue), List.class));
					} catch (Exception exception) {
						try {
							String pgObjectValue = ((PGobject) data.get(column)).getValue();
							data.put(column, JsonUtils.fromJsonOrThrow(Objects.toString(pgObjectValue), Map.class));
						} catch (Exception exception1) {
							String pgObjectValue = ((PGobject) data.get(column)).getValue();
							data.put(column, pgObjectValue);
						}
					}
				}));
	}

	/**
	 * To check API name duplicate.
	 *
	 * @param dataMap the data map
	 * @return true, if successful
	 * @throws QueryException the query exception
	 */
	public boolean checkApiNameDuplicate(Map<String, Object> dataMap) throws QueryException {
		String apiName = Objects.toString(dataMap.getOrDefault("apiName", ""));
		String tableName = Objects.toString(dataMap.getOrDefault("tableName", ""));
		String product = Objects.toString(dataMap.getOrDefault("product", ""));
		String camelCasedProgramName = lowerCamelToUpperCamelCase(apiName);
		String lowerCasedProgramName = upperCamelToLowerCamelCase(apiName);
		if (StringUtils.isNotEmpty(apiName)) {
			QueryBuilder builder = new QueryBuilder();
			List<Map<String, Object>> programDetails = builder
					.select().from("program_detail", "prog").where(
							ConditionBuilder.instance()
									.brackets(ConditionBuilder.instance().eq("program_name", camelCasedProgramName).or()
											.eq("program_name", lowerCasedProgramName))
									.and().eq("program_type", "api").and()
									.brackets(ConditionBuilder.instance().not()
											.brackets(ConditionBuilder.instance().eq("prog.table_detail", tableName)
													.and().eq("prog.product_code", product))
											.or().brackets(ConditionBuilder.instance().isNull("prog.table_detail").and()
													.eq("prog.product_code", product))))
					.build(false).execute();
			return programDetails.size() > 0;
		}
		return false;
	}

	/**
	 * To check API mapping URL duplicate.
	 *
	 * @param dataMap the data map
	 * @return true, if successful
	 * @throws QueryException the query exception
	 */
	public boolean checkMappingUrlDuplicate(Map<String, Object> dataMap) throws QueryException {
		String mappingUrl = Objects.toString(dataMap.getOrDefault("mappingUrl", ""));
		String tableName = Objects.toString(dataMap.getOrDefault("tableName", ""));
		String product = Objects.toString(dataMap.getOrDefault("product", ""));
		if (StringUtils.isNotEmpty(mappingUrl)) {
			mappingUrl = mappingUrl.replace("/", "_");
			ConditionBuilder condition = ConditionBuilder.instance()
					.brackets(ConditionBuilder.instance().eq("combined_url", mappingUrl + "__GET").or()
							.eq("api.combined_url", mappingUrl + "__PUT").or()
							.eq("api.combined_url", mappingUrl + "__POST").or()
							.eq("api.combined_url", mappingUrl + "__DELETE").or()
							.eq("api.combined_url", mappingUrl + "_list_GET"))
					.and().eq("prog.program_type", "api").and()
					.brackets(ConditionBuilder.instance().not()
							.brackets(ConditionBuilder.instance().eq("prog.table_detail", tableName).and()
									.eq("prog.product_code", product))
							.or().brackets(ConditionBuilder.instance().isNull("prog.table_detail").and()
									.eq("prog.product_code", product)));
			QueryBuilder builder = new QueryBuilder();
			List<Map<String, Object>> apiDetails = builder.select().from("program_detail", "prog")
					.join("api_detail", "api",
							ConditionBuilder.instance().eq("prog.program_id", "api.program_id", true))
					.where(condition).build(false).execute();
			return apiDetails.size() > 0;
		}
		return false;
	}

	/**
	 * getMessageData method is to get message data.
	 *
	 * @param messageId the message id
	 * @return the message data
	 */
	public static MessageDefinitionEntity getMessageData(String messageId) {
		try {
			return CacheService.getInstance().getMessageDefinitionData(messageId,
					UserContext.getInstance().getUserProfile().getLocale());
		} catch (QueryException exception) {
			LOGGER.warn("Error on get message definition data.", exception);
		}
		return null;
	}

	/**
	 * getMessageText method is to get message text.
	 *
	 * @param messageId the message id
	 * @return the message text
	 */
	public static String getMessageText(String messageId) {
		MessageDefinitionEntity messageData = getMessageData(messageId);
		if (Objects.isNull(messageData)) {
			return "";
		}
		return messageData.getTextContent();
	}

	/**
	 * getMessageText method is used to get message content with dynamic replacer.
	 *
	 * @param messageId     the message id
	 * @param dynamicParams the dynamic params
	 * @return the message text
	 */
	public static String getMessageText(String messageId, Object... dynamicParams) {
		String messageText = getMessageText(messageId);
		List<Object> dynamicList = Arrays.asList(dynamicParams);
		try {
			if (CollectionUtils.isNotEmpty(dynamicList)) {
				messageText = String.format(messageText, dynamicParams);
			}
		} catch (Exception exception) {
			LOGGER.warn("Error on get message with param :", exception);
		}
		return messageText;
	}

	/**
	 * getApplicationMessageData method is to get application message data.
	 *
	 * @param messageId   the message id
	 * @param screenDefId the screen def id
	 * @return the application message data
	 */
	public static MessageDefinitionEntity getApplicationMessageData(String messageId, String screenDefId) {
		try {
			return CacheService.getInstance().getApplicationMessageData(screenDefId, messageId,
					UserContext.getInstance().getUserProfile().getLocale());
		} catch (QueryException exception) {
			LOGGER.warn("Error on get message definition data.", exception);
		}
		return null;
	}

	/**
	 * getApplicationMessageText method is to get application message text.
	 *
	 * @param messageId   the message id
	 * @param screenDefId the screen def id
	 * @return the application message text
	 */
	public static String getApplicationMessageText(String messageId, String screenDefId) {
		MessageDefinitionEntity messageData = getApplicationMessageData(messageId, screenDefId);
		if (Objects.isNull(messageData)) {
			return "";
		}
		return messageData.getTextContent();
	}

	/**
	 * getMessageText method is to get message text.
	 *
	 * @param textId      the text id
	 * @param screenDefId the screen def id
	 * @return the text message
	 */
	public static String getTextMessage(String textId, String screenDefId) {
		try {
			return CacheService.getInstance().getApplicationTextDefinitionData(textId, screenDefId,
					UserContext.getInstance().getUserProfile().getLocale());
		} catch (QueryException exception) {
			LOGGER.warn("Error on get text definition data.", exception);
		}
		return "";
	}

	/**
	 * getTextMessage method is used to get text message content with dynamic
	 * replacers.
	 *
	 * @param textId        the text id
	 * @param screenDefId   the screen def id
	 * @param dynamicParams the dynamic params
	 * @return the text message
	 */
	public static String getTextMessage(String textId, String screenDefId, Object... dynamicParams) {
		String textMessage = getTextMessage(textId, screenDefId);
		List<Object> dynamicList = Arrays.asList(dynamicParams);
		try {
			if (CollectionUtils.isNotEmpty(dynamicList)) {
				textMessage = String.format(textMessage, dynamicParams);
			}
		} catch (Exception exception) {
			LOGGER.warn("Error on get text message with param :", exception);
		}
		return textMessage;
	}

	/**
	 * isKeyExistInRequestMap method is to check map key is present or not in
	 * request map.
	 *
	 * @param requestMap the request map
	 * @param mapName    the map name
	 * @param mapKeys    the map keys
	 * @return true, if is key exist in request map
	 */
	public static boolean isKeyExistInRequestMap(Map<String, Object> requestMap, String mapName, String... mapKeys) {
		List<String> keyList = Arrays.asList(mapKeys);
		Map<String, Object> actualMap = getNonNullMap(requestMap.get(mapName));
		boolean isKeyExist = false;
		for (int index = 0; index < keyList.size(); index++) {
			String key = keyList.get(index);
			if (index + 1 != keyList.size()) {
				actualMap = getNonNullMap(actualMap.get(key));
			}
			isKeyExist = actualMap.containsKey(key);
		}
		return isKeyExist;
	}

	/**
	 * checkResultStatus method is to check result status of database operation.
	 *
	 * @param status the status
	 * @return true, if successful
	 */
	public static boolean checkResultStatus(Object status) {
		return Optional.ofNullable(status).map(Objects::toString).map(Boolean::valueOf).orElse(true);
	}

	/**
	 * isNotEmptyValue method is to check given object value is empty or not.
	 *
	 * @param value the value
	 * @return true, if is not empty value
	 */
	public static boolean isNotEmptyValue(Object value) {
		if (Objects.isNull(value)) {
			return false;
		}
		if (value.getClass().isArray() || value instanceof List) {
			return ArrayUtils.isNotEmpty(getInArray(value));
		} else {
			return StringUtils.isNotEmpty(Objects.toString(value, ""));
		}
	}

	/**
	 * lowerCamelToUpperCamelCase method is used to convert lower camel case string
	 * to upper camel string.
	 *
	 * @param value the value
	 * @return the string
	 */
	public static String lowerCamelToUpperCamelCase(Object value) {
		return convertCase(value, CaseFormat.LOWER_CAMEL, CaseFormat.UPPER_CAMEL);
	}

	/**
	 * upperCamelToLowerCamelCase method is used to convert upper camel case string
	 * to lower camel string.
	 *
	 * @param value the value
	 * @return the string
	 */
	public static String upperCamelToLowerCamelCase(Object value) {
		return convertCase(value, CaseFormat.UPPER_CAMEL, CaseFormat.LOWER_CAMEL);
	}

	/**
	 * convertCase method is to convert case to another case format.
	 *
	 * @param value    the value
	 * @param fromCase the from case
	 * @param toCase   the to case
	 * @return the string
	 */
	public static String convertCase(Object value, CaseFormat fromCase, CaseFormat toCase) {
		return Optional.ofNullable(value).map(Objects::toString).map(string -> fromCase.to(toCase, string))
				.orElse(StringUtils.EMPTY);
	}

	/**
	 * isNullOrCompletedExecutor method is to check whether executor object is null
	 * or already completed.
	 *
	 * @param executor the executor
	 * @return true, if is null or completed executor
	 */
	public static boolean isNullOrCompletedExecutor(QueryExecutor executor) {
		if (Objects.isNull(executor)) {
			return true;
		} else {
			return executor.getExecutorStatus();
		}
	}

	/**
	 * commitExecutor method is to commit executor.
	 *
	 * @param executor the executor
	 * @param logger   the logger
	 * @return true, if successful
	 */
	public static boolean commitExecutor(QueryExecutor executor, ApplicationLogger logger) {
		try {
			executor.commit();
			return true;
		} catch (Exception exception) {
			if (Objects.nonNull(logger)) {
				logger.error("error while data commit " + exception);
			}
			try {
				executor.rollBack();
			} catch (QueryException rollBackException) {
				if (Objects.nonNull(logger)) {
					logger.error("error while executor roll back " + rollBackException);
				}
			}
			return false;
		}
	}

	/**
	 * commitExecutor method is to commit executor object.
	 *
	 * @param executor the executor
	 */
	public static void commitExecutor(QueryExecutor executor) {
		if (Objects.nonNull(executor)) {
			try {
				executor.commit();
			} catch (Exception commitException) {
				LOGGER.warn("commitExecutor error: ", commitException);
			}
		}
	}

	/**
	 * rollBackExecutor method is to roll back query executor.
	 *
	 * @param executor the executor
	 */
	public static void rollBackExecutor(QueryExecutor executor) {
		if (Objects.nonNull(executor)) {
			try {
				executor.rollBack();
			} catch (Exception rollBackException) {
				LOGGER.warn("Error on executor roll back:", rollBackException);
			}
		}
	}

	/**
	 * removeDataInCr method is to remove data from change request.
	 *
	 * @param changeRequestId the change request id
	 * @param tableNames      the table names
	 */
	public static void removeDataInCr(String changeRequestId, List<Object> tableNames) {
		if (StringUtils.isNotEmpty(changeRequestId)) {
			ChangeRequest.deleteChangeData(changeRequestId, tableNames);
		}
	}

}