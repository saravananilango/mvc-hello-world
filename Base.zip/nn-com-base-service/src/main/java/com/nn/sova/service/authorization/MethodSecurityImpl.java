package com.nn.sova.service.authorization;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.nn.sova.service.CacheService;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

public class MethodSecurityImpl {
	
	private static final ApplicationLogger logger = ApplicationLogger.create(MethodSecurityImpl.class);
	
	public boolean hasPrivilege(Authentication authentication,String methodName, Object entityObj, AuthResultEntity authResultEntity, Map<String, Object> userTokenCacheData) {
		try {
			String clientId = null;
			OAuth2Authentication auth = (OAuth2Authentication) authentication;
			String grantType = auth.getOAuth2Request().getGrantType();
			if(StringUtils.isNotEmpty(grantType) && grantType.equals("client_credentials")) {
				clientId = (String) auth.getPrincipal();
			}
			else if(StringUtils.isNotEmpty(grantType) && grantType.equals("password")) {
				logger.info("Method Security Password Flow Started");
				clientId = auth.getOAuth2Request().getClientId();
				
				UserApiRoleAuthorization userApiRoleAuthorization = new UserApiRoleAuthorization();
				String userId = String.valueOf(userTokenCacheData.get("userId"));
				String tenantId = String.valueOf(userTokenCacheData.get("tenantId"));
				return userApiRoleAuthorization.userApiRoleAuthorize(userId, tenantId, methodName, entityObj);
				
			}
			String methodUrl = String.valueOf(entityObj);
				if(StringUtils.isNotEmpty(clientId) && !clientId.equals("anonymousUser")) {
					CacheService cacheService = CacheService.getInstance();
					Map<String, Object> clientDetailMap = cacheService.getClientInfoDetails(clientId);
					Map<String,Object> individualClientMap = (Map<String, Object>) clientDetailMap.get(clientId);
					Map<String,Set<String>> accessEntityMap = (Map<String, Set<String>>) individualClientMap.get("entity_access_list");
					
					if(Objects.nonNull(accessEntityMap) && MapUtils.isNotEmpty(accessEntityMap)) {
						logger.info("Method URL :" + methodUrl);
						Set<String> accessEntityList = accessEntityMap.get(methodUrl.trim().toLowerCase());
						logger.info("Entity List :" + accessEntityList);
						if(accessEntityList.contains(methodName)) {
							logger.info("Method Access Success");
							return true;
						}else {
							return false;
						}	
					}
				}else {
					authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_empty_client_id"));
					return false;
				}
		} catch (Exception exception) {
			logger.error(exception);
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_exception_method_security_failed"));
			return false;
		}
		return false;
	} 
}
