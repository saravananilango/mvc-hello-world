package com.nn.sova.service.utils;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.nn.sova.service.entity.SessionHolder;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

/**
 * ContextUtils has the redirection logic.
 * @author Logchand
 *
 */
public class ContextUtils {

	/** The logger. */
	private ApplicationLogger logger = ApplicationLogger.create(getClass());

	/** The Constant CONST_BCK_SLASH. */
	private static final  String CONST_BCK_SLASH="/";

	/** The instance. */
	private static ContextUtils instance = null;

	/**
	 * Gets the single instance of ContextUtils.
	 *
	 * @return single instance of ContextUtils
	 */
	public static ContextUtils getInstance(){
		if(Objects.isNull(instance)){
			instance = new ContextUtils();
		}
		return instance;
	}


	/**
	 * getHomeUrl is used to read the home url from the property.
	 *
	 * @return String
	 */
	public String getHomeUrl(){
		String url=EnvironmentReader.getHomeUrl();
		if(!url.endsWith(CONST_BCK_SLASH)){
			url=url.concat(CONST_BCK_SLASH);
		}
		return url;
	}

	/**
	 * getContext is used to get the context path.
	 *
	 * @return String
	 */
	public String getContext(){
		URI uri;
		try {
			uri = new URI(EnvironmentReader.getHomeUrl());
			return uri.getRawPath().split(CONST_BCK_SLASH)[1];
		} catch (URISyntaxException exception) {
			logger.debug(exception);
			return "";
		}
	}

	/**
	 * getRedirectedUrl get the default url.
	 *
	 * @param url the url
	 * @return String
	 */
	public String getRedirectedUrl(String url){
		if("login".equals(url) || url.startsWith("login?tenant=") || "home".equals(url) || "error".equals(url)){
			return getHomeUrl().concat(url);
		}else if("alreadyAuthenticated".equals(url)){
			if (EnvironmentReader.getDevMode()) {
				return getHomeUrl().concat(url);
			}else{
				return "alreadyAuthenticated";
			}
		}else{
			return url;
		}
	}

	/**
	 * Checks if is custom exception URL.
	 *
	 * @param url the url
	 * @return true, if is custom exception URL
	 */
	public boolean isCustomExceptionURL(String url){
		String homeContext=getContext();
		if(homeContext.concat(CONST_BCK_SLASH.concat("showException")).equals(homeContext.concat(url))){
			return true;
		}
		return false;

	}

	/**
	 * Check service filtered urls.
	 *
	 * @param url the url
	 * @return true, if successful
	 */
	public boolean checkServiceFilteredUrls(String url){
		String staticSetting="/staticsetting/";
		String homeContext=getContext();
		if(!StringUtils.isEmpty(homeContext)){
			List<String> urlList=new ArrayList<>();
			urlList.add(CONST_BCK_SLASH.concat("alreadyAuthenticated"));
			urlList.add(CONST_BCK_SLASH.concat("error"));
			urlList.add(CONST_BCK_SLASH.concat("showException"));
			urlList.add(CONST_BCK_SLASH.concat("health").concat(CONST_BCK_SLASH).concat("ping"));
			return !urlList.contains(url) && !url.contains(staticSetting);
		}else{
			return false;
		}
	}

	/**
	 * checkFilteredUrls check the default url.
	 *
	 * @param url the url
	 * @return boolean
	 */
	public boolean checkFilteredUrls(String url){
		String staticSetting="/staticsetting/";
		String homeContext=getContext();
		if(!StringUtils.isEmpty(homeContext)){
			List<String> urlList=new ArrayList<>();
			urlList.add(CONST_BCK_SLASH.concat("alreadyAuthenticated"));
			urlList.add(CONST_BCK_SLASH.concat("error"));
			urlList.add(CONST_BCK_SLASH.concat("showException"));
			urlList.add(CONST_BCK_SLASH.concat("health").concat(CONST_BCK_SLASH).concat("ping"));
			return !urlList.contains(url) && !url.contains(staticSetting);
		}else{
			return false;
		}
	}

	/**
	 * performRedirectionOnVerify get the default url.
	 *
	 * @param request the request
	 * @param response the response
	 * @param sessionHolder the session holder
	 * @param additionParam the addition param
	 * @return String
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws CustomException the custom exception
	 */
	public void performRedirectionOnVerify(HttpServletRequest request,HttpServletResponse response,
			SessionHolder sessionHolder,String additionParam) throws IOException, CustomException{
		String url=sessionHolder.getRedirectedUrl();
		if("login".equals(url) || "home".equals(url)){
			response.sendRedirect(getHomeUrl().concat(url).concat(additionParam));
		}else if("error".equals(url)){
			if (com.nn.sova.utility.config.EnvironmentReader.getDevMode()) {
				response.sendRedirect(getHomeUrl().concat(url));
			}else{
				//HandleException.getInstannce().handleException(request, response, UUID.randomUUID().toString(),sessionHolder.getMessage());
			}
		}else if("alreadyAuthenticated".equals(url)){
			if (EnvironmentReader.getDevMode()) {
				response.sendRedirect(getHomeUrl().concat(url));
			}else{
				//HandleException.getInstannce().handleException(request, response, UUID.randomUUID().toString(),sessionHolder.getMessage());
			}
		}else{
			response.sendRedirect(url);
		}
	}

	/**
	 * Perform redirection on verify.
	 *
	 * @param request the request
	 * @param response the response
	 * @param url the url
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws CustomException the custom exception
	 */
	public void performRedirectionOnVerify(HttpServletRequest request,HttpServletResponse response,
			String url) throws IOException, CustomException{
		response.sendRedirect(getHomeUrl().concat(url));
	}
}
