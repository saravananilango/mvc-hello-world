package com.nn.sova.service.authorization;

import java.util.Objects;

import com.nn.sova.entity.MessageDefinitionEntity;
import com.nn.sova.service.CacheService;
import com.nn.sova.utility.context.ContextBean;

/**
 * The Class MessageImplementation.
 * 
 * @author vellaichamy
 */
public class MessageImplementation {
	
	/** The message implementation. */
	private static MessageImplementation messageImplementation;
	
	/**
	 * Gets the single instance of MessageImplementation.
	 *
	 * @return single instance of MessageImplementation
	 */
	public static MessageImplementation getInstance() {
		if(messageImplementation == null) {
			messageImplementation = new MessageImplementation();
		}
		return messageImplementation;
	}
	
	/**
	 * Gets the message data.
	 *
	 * @param messageId the message id
	 * @return the message data
	 */
	public String getMessageData(String messageId){
		MessageDefinitionEntity messageDefinitionEntity;
		String text = messageId;
		try {
			String locale = ContextBean.getLocale();
			if(Objects.isNull(locale)) {
				locale= "en";
			}
			messageDefinitionEntity = CacheService.getInstance().getMessageDefinitionData(messageId,
					locale);
			if (Objects.nonNull(messageDefinitionEntity)) {
				text = messageDefinitionEntity.getTextContent();
			}
		} catch (Exception exception) {
			return text;
		}
		return text;
	}
}
