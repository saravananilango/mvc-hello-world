package com.nn.sova.nts.vo;

/**
 * {@code NotificationException} will be used to throw custom checked exceptions during
 * notification execution.
 *
 * @author saravana
 */
public class NotificationException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Instantiates a new notification runtime exception.
	 *
	 * @param message the message
	 * @param cause   the cause
	 */
	public NotificationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new notification runtime exception.
	 *
	 * @param message the message
	 */
	public NotificationException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new notification runtime exception.
	 *
	 * @param cause the cause
	 */
	public NotificationException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
