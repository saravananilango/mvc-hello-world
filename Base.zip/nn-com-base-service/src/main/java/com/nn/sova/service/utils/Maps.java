package com.nn.sova.service.utils;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Maps Utility - A simple wrapper for avoiding null issue
 * @author Vignesh Rajasekar
 *
 * @param <K>
 * @param <V>
 */
public class Maps<K,V> {
	
	
	Map<K,V> map = null;
	/**
	 * Create an instance Object of Maps
	 * @param <K>
	 * @param <V>
	 * @return Maps
	 */
	public static <K,V> Maps<K,V> builder(){
		Maps<K,V> instance = new Maps<K,V>();
		instance.map =  new LinkedHashMap<K,V>();
		return instance;
	}
	
	/**
	 * A wrapper put class works like builder
	 * @param key
	 * @param value
	 * @return Maps
	 */
	public Maps<K, V> put(K key, V value){
		this.map.put(key, value);
		return this;
	}
	
	/**
	 * Of Method to create a map using key value pair
	 * @param pairs
	 * @return
	 */
	public static <K, V> Map<K, V> of(Object ...pairs){
		Maps<K,V> instance = builder();
		return Optional.ofNullable(pairs).map(values -> {
			for(int i=0;i<values.length;i+=2) {
				instance.map.put((K)values[i], i+1 < values.length ? (V)values[i+1] : null);
			}
			return instance.map;
		}).orElse(instance.map);
	}
	
	/**
	 * Get the wrapped map
	 * @return
	 */
	public Map<K,V> build(){
		return this.map;
	}
}
