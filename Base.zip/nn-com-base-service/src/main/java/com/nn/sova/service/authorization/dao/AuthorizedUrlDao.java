package com.nn.sova.service.authorization.dao;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;

/**
 * The Class AuthorizedUrlDao.
 * 
 * @author Vellaichamy N
 */
public class AuthorizedUrlDao {

	/** The instance. */
	private static AuthorizedUrlDao instance = null;

	/**
	 * Gets the single instance of AuthorizedUrlDao.
	 *
	 * @return single instance of AuthorizedUrlDao
	 */
	public static AuthorizedUrlDao getInstance() {
		if (Objects.isNull(instance)) {
			instance = new AuthorizedUrlDao();
		}
		return instance;
	}

	/**
	 * Gets the all authorized url.
	 *
	 * @return the all authorized url
	 * @throws QueryException the query exception
	 */
	public List<Map<String,Object>> getAllAuthorizedUrl() throws QueryException {
		QueryBuilder queryBuilder=new QueryBuilder();
		SelectQueryBuilder selectBuilder = queryBuilder.btSchema().select();
		return selectBuilder.get("authorized_url").from("authorized_url_definition").build(false).execute();
	}

	/**
	 * Gets the auth url screen id.
	 *
	 * @return the auth url screen id
	 * @throws QueryException the query exception
	 */
	public List<Map<String, Object>> getAuthUrlScreenId() throws QueryException {
		QueryBuilder queryBuilder=new QueryBuilder();
		SelectQueryBuilder selectBuilder = queryBuilder.btSchema().select();
		return selectBuilder.from("authorized_url_definition").build(false).execute();
	}
}
