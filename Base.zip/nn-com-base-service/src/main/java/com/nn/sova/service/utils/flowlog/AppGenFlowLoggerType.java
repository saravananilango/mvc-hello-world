package com.nn.sova.service.utils.flowlog;

public enum AppGenFlowLoggerType {
	DB,AWS;
}
