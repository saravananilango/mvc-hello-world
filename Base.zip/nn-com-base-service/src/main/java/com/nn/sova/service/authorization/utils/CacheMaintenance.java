package com.nn.sova.service.authorization.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nn.sova.core.CacheManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.dao.AuthorizedUrlDao;

/**
 * CacheMaintenance handles all the Cache Operation.
 *
 * @author Vellaichamy N
 */
public class CacheMaintenance {

	/** The Constant AUTHORIZED_URL_SCREEN_ID. */
	private static final String AUTHORIZED_URL_SCREEN_ID = "authorized_url_screen_id";
	
	/** The Constant AUTHORIZED_URL_LIST. */
	private static final String AUTHORIZED_URL_LIST = "authorized_url_list";

	/**
	 * Return the instance of the CacheMaintenance.
	 *
	 * @return instance of the CacheMaintenance
	 */
	public static CacheMaintenance getInstance(){
		return new CacheMaintenance();
	}

	/**
	 * Get the Role details based on the role.
	 *
	 * @param roleId the role id
	 * @param tenantId the tenant id
	 * @return Role Info as map for the role id
	 * @throws QueryException the query exception
	 */
	public List<Map<String, Object>> getRoleInfoFromCache(String roleId,String tenantId) throws QueryException{
		CacheService cacheService = CacheService.getInstance();
		return cacheService.getRoleDataByTenantId(roleId, tenantId);
	}

	/**
	 * This method is used to get the RoleLinkList for user id.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @return Role link info as list data
	 * @throws QueryException the query exception
	 */
	public List<Map<String, Object>> getRoleLinkInfoFromCache(String userId,String tenantId) throws QueryException{
		CacheService cacheService = CacheService.getInstance();
		return cacheService.getTenantRolesLinkedWithUserId(userId,tenantId);
	}

	/**
	 * Returns Screen Role link infor from cache.
	 *
	 * @param roleId the role id
	 * @param tenantId the tenant id
	 * @return screen role link as list
	 * @throws QueryException the query exception
	 */
	public List<Map<String, Object>> getScreenRoleLinkInfoFromCache(String roleId,String tenantId) throws QueryException{
		CacheService cacheService = CacheService.getInstance();
		return cacheService.getTenantScreenRoleLinkData(roleId,tenantId);
	}

	/**
	 * Returns the screen information from cache based on screen id
	 *  
	 *
	 * @param screenId the screen id
	 * @param locale the locale
	 * @return screen info
	 * @throws QueryException the query exception
	 */
	public Map<String,Object> getScreenInfoFromCache(String screenId,String locale) throws QueryException{
		CacheService cacheService = CacheService.getInstance();
		return cacheService.getScreenConfigurationDataByLocale( screenId, locale);
	}


	/**
	 * Get the tenant info from cache for product code.
	 *
	 * @param productCode the product code
	 * @return List of tenant info
	 * @throws QueryException the query exception
	 */
	public List<String> getProductTenantConfigDetails(String productCode) throws QueryException{
		CacheService cacheService = CacheService.getInstance();
		return cacheService.getProductTenantConfigurationDetails(productCode);
	}


	/**
	 * Gets the all authorized url from cache.
	 *
	 * @return the all authorized url from cache
	 * @throws QueryException the query exception
	 */
	public List<String> getAllAuthorizedUrlFromCache() throws QueryException {
		CacheService cacheService = CacheService.getInstance();
		 if(!CacheManager.getInstance().isKeyExists(AUTHORIZED_URL_LIST)) {
				List<String> allUrlList = new ArrayList<>();
				List<Map<String,Object>> urlList = AuthorizedUrlDao.getInstance().getAllAuthorizedUrl();
				urlList.stream().forEach(action->
					allUrlList.add(String.valueOf(action.get("authorized_url")))
				);
				cacheService.saveToCache(AUTHORIZED_URL_LIST, allUrlList);
	        }
		return (List<String>) cacheService.getCacheData(AUTHORIZED_URL_LIST);
	}

	
	/**
	 * Gets the screen id for auth url.
	 *
	 * @return the screen id for auth url
	 * @throws QueryException the query exception
	 */
	public Map<String, String> getScreenIdForAuthUrl() throws QueryException {
		CacheService cacheService = CacheService.getInstance();
		if(!CacheManager.getInstance().isKeyExists(AUTHORIZED_URL_SCREEN_ID)) {
			List<Map<String,Object>> urlData = AuthorizedUrlDao.getInstance().getAuthUrlScreenId();
			Map<String,String> cacheDataMap = new HashMap<>();
			urlData.stream().forEach(action->
				cacheDataMap.put(String.valueOf(action.get("authorized_url")), String.valueOf(action.get("screen_id")))
			);
			cacheService.saveToCache(AUTHORIZED_URL_SCREEN_ID, cacheDataMap);
		 }
		return (Map<String, String>) cacheService.getCacheData(AUTHORIZED_URL_SCREEN_ID);
	}
}
