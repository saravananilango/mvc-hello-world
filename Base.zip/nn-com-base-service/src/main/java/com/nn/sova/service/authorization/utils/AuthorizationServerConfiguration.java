package com.nn.sova.service.authorization.utils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.cache.Cache;
import javax.cache.CacheManager;
import javax.cache.Caching;
import javax.cache.configuration.MutableConfiguration;

import org.redisson.config.Config;
import org.redisson.jcache.configuration.RedissonConfiguration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenEnhancerChain;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

import com.nn.sova.utility.config.EnvironmentReader;

/**
 * AuthorizationServerConfiguration class is used to configure the oauth2.0
 * Authorization server configuration
 * 
 * @author Vellaichamy N
 * 
 */

public class AuthorizationServerConfiguration extends AuthorizationServerConfigurerAdapter {

	CustomRedisTokenStore redisTokenStore = null;
	
	public static RedisConnectionFactory redisConnectionFactory = null;
	
	private static ResourceServerTokenServices tokenServiceInstance = null;

	private static JedisConnectionFactory redisConnectionInstance = null;
	
	private static AuthorizationServerConfiguration instance = null;
	
	/**
	 * Gets the single instance of AuthorizationServerConfiguration.
	 *
	 * @return single instance of AuthorizationServerConfiguration
	 */
	public static AuthorizationServerConfiguration getInstance(){
		if(instance == null) {
			instance = new AuthorizationServerConfiguration();
		}
		return instance;
	}
	
	
	/**
	 * Jwt access token converter.
	 *
	 * @return the jwt access token converter
	 */
	public JwtAccessTokenConverter jwtAccessTokenConverter() {
		return new JwtAccessTokenConverter();
	}
	
	
	/**
	 * This Bean creation is used to store the access token and refresh token in
	 * redis token store.
	 *
	 * @return Token Store instance
	 */
	public TokenStore tokenStore() {
		if (redisTokenStore == null) {
			redisTokenStore = new CustomRedisTokenStore(connectionFactoryBean());
		}
		return redisTokenStore;
	}
	
	/**
	 * Connection factory bean.
	 * 
	 * @return the redis connection factory
	 * 
	 */
	public static JedisConnectionFactory connectionFactoryBean() {
		if(redisConnectionInstance == null) {
			String isClusterModeEnabled = EnvironmentReader.isClusterModeEnabled();
			JedisClientConfiguration.JedisClientConfigurationBuilder jedisClientConfiguration = JedisClientConfiguration
					.builder();
			jedisClientConfiguration.usePooling();
			if (Objects.nonNull(isClusterModeEnabled) && !isClusterModeEnabled.isEmpty()
					&& isClusterModeEnabled.equalsIgnoreCase("true")) {
				List<String> clusterNodes = Arrays
						.asList(EnvironmentReader.getRedisURL() + ":" + EnvironmentReader.getRedisPort());
				JedisConnectionFactory connection = new JedisConnectionFactory(new RedisClusterConfiguration(clusterNodes));
				connection.afterPropertiesSet();
				redisConnectionInstance = connection;
			} else {
				RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
				redisStandaloneConfiguration.setHostName(EnvironmentReader.getRedisURL());
				redisStandaloneConfiguration.setPort(Integer.parseInt(EnvironmentReader.getRedisPort()));
				JedisConnectionFactory connection = new JedisConnectionFactory(redisStandaloneConfiguration, jedisClientConfiguration.build());
				connection.afterPropertiesSet();
				redisConnectionInstance = connection;
			}
		}
		return redisConnectionInstance;
	}
	
	/**
	 * Cache.
	 *
	 * @return the cache
	 */
	public Cache cache() {
		CacheManager manager = Caching.getCachingProvider().getCacheManager();
		Cache cache = manager.getCache("sova-rate-limit");
		if(Objects.isNull(cache)) {
			MutableConfiguration<String, String> jcacheConfig = new MutableConfiguration<>();
			Config redissonCfg = new Config();
			String redisAddress = new StringBuilder().append("redis://").append(EnvironmentReader.getRedisURL()).append(":")
					.append(EnvironmentReader.getRedisPort()).toString();
			String isClusterModeEnabled = EnvironmentReader.isClusterModeEnabled();
			if (Objects.nonNull(isClusterModeEnabled) && !isClusterModeEnabled.isEmpty() && isClusterModeEnabled.equalsIgnoreCase("true")) {
				redissonCfg.useClusterServers().addNodeAddress(redisAddress);
				redissonCfg.useClusterServers().setMasterConnectionPoolSize(EnvironmentReader.getRedisMaxTotal());
				redissonCfg.useClusterServers().setSlaveConnectionPoolSize(EnvironmentReader.getRedisMaxTotal());
			} else {
				redissonCfg.useSingleServer().setAddress(redisAddress);
				redissonCfg.useSingleServer().setConnectionPoolSize(EnvironmentReader.getRedisMaxTotal());
				redissonCfg.useSingleServer().setConnectionMinimumIdleSize(0);
				redissonCfg.useSingleServer().setDnsMonitoringInterval(-1);
				redissonCfg.useSingleServer().setSubscriptionConnectionMinimumIdleSize(0);
			}

			javax.cache.configuration.Configuration<String, String> config = RedissonConfiguration.fromConfig(redissonCfg, jcacheConfig);
			return manager.createCache("sova-rate-limit", config);
		}
		return cache;
	}
	
	/**
	 * Token services.
	 *
	 * @return the resource server token services
	 */
	public ResourceServerTokenServices tokenServices() {
		if(tokenServiceInstance == null) {
			DefaultTokenServices tokenServices = new DefaultTokenServices();
			AuthorizationServerConfiguration authorizationServerConfiguration = AuthorizationServerConfiguration.getInstance();
			tokenServices.setTokenEnhancer(authorizationServerConfiguration.jwtAccessTokenConverter());
			TokenEnhancerChain tokenEnhancerChains = new TokenEnhancerChain();
			tokenEnhancerChains.setTokenEnhancers(Arrays.asList(authorizationServerConfiguration.jwtAccessTokenConverter()));
			tokenServices.setTokenEnhancer(tokenEnhancerChains);
			tokenServices.setTokenStore(authorizationServerConfiguration.tokenStore());
			tokenServiceInstance = tokenServices;
		}
		return tokenServiceInstance;
	}
}
