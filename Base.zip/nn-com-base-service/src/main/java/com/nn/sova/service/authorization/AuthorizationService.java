package com.nn.sova.service.authorization;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.nn.sova.core.CacheManager;
import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.entity.RequestParamEntity;
import com.nn.sova.service.authorization.utils.CacheMaintenance;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.helper.TokenTypeIdentifier;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class AuthorizationService.
 */
public class AuthorizationService {

	private static final ApplicationLogger LOGGER = ApplicationLogger.create(AuthorizationService.class);
	private static final String SID = "sid";
	/**
	 * Authorization validation.
	 *
	 * @param authRequestEntity the sova request
	 * @param authentication the authentication
	 * @return true, if successful
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws RequestExecutedException 
	 */
	public boolean authorizationValidation(AuthRequestEntity authRequestEntity, Authentication authentication,AuthResultEntity authResultEntity,
			Map<String, Object> userTokenCacheData) throws IOException{
		OAuth2Authentication auth = (OAuth2Authentication) authentication;
		LOGGER.info("authorizationValidation starts");
		String grantType = auth.getOAuth2Request().getGrantType();
		boolean apiTokenFlag = true;
		if (StringUtils.isNotEmpty(grantType) && grantType.equals("client_credentials")) {
			String apiToken = Objects.toString(getHeaderData("apiToken", authRequestEntity), null);
			Map<String,String> queryParamMap = authRequestEntity.getQueryParams();
			if(Objects.isNull(queryParamMap)) {
				authRequestEntity.setQueryParams(new HashMap<>());
			}
			String queryParamApiToken = authRequestEntity.getQueryParams().get("apiToken");
			if (StringUtils.isNotEmpty(apiToken)) {
				ContextBean.setApiToken(apiToken);
				LOGGER.info("SovaServiceFilter header api token");
				apiTokenFlag = false;
			} else if (StringUtils.isNotEmpty(queryParamApiToken)) {
				ContextBean.setApiToken(queryParamApiToken);
				LOGGER.info("SovaServiceFilter query param api token");
				apiTokenFlag = false;
			}
			if (!validateClientIp(authRequestEntity, auth)) {
				LOGGER.error("Client's IP validation failed");
				authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_client_ip_restriction_failed"));
				LOGGER.info("validateClientIp ends :" + new Timestamp(System.currentTimeMillis()));
				return false;
			}
			LOGGER.info("validateClientIp ends");
			return true;
		} else {
			if(Objects.nonNull(authRequestEntity.getMethodSecurityMethodName())){
				LOGGER.info("Method Name has MethodSecurity Mapping");
				return true;
			}
			if (validateUserIp(authRequestEntity, userTokenCacheData,authResultEntity)) {
				LOGGER.info("authorizeRequest starts :" + new Timestamp(System.currentTimeMillis()));
				return authorizeRequest(userTokenCacheData, authRequestEntity,authResultEntity);
			} else {
				LOGGER.error("User Ip Validation failed");
				authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_user_ip_restriction_failed"));
				return false;
			}
		}

	}

	/**
	 * Validate user ip.
	 *
	 * @param authRequestEntity the request
	 * @param userTokenCacheData the user token cache data
	 * @param authResultEntity 
	 * @return true, if successful
	 */
	private boolean validateUserIp(AuthRequestEntity authRequestEntity, Map<String, Object> userTokenCacheData, AuthResultEntity authResultEntity) {
		try {
			Collection<String> roleInfo = (Collection<String>) userTokenCacheData.get("rolesData");
			LOGGER.info("Roles Data from context bean " + roleInfo);
			List<List<Map<String, Object>>> allRolesData = new ArrayList<>();

			for (String role : roleInfo) {
				List<Map<String, Object>> ipRangeDetils = CacheService.getInstance().getUserIpRangeDetails(role);
				if (CollectionUtils.isNotEmpty(ipRangeDetils)) {
					allRolesData.add(ipRangeDetils);
				}
			}
			LOGGER.info("All Roles Data " + allRolesData);
			List<Map<String, Object>> userBasedList = new ArrayList<>();
			List<Map<String, Object>> allUserList = new ArrayList<>();
			if (CollectionUtils.isNotEmpty(allRolesData)) {
				for (List<Map<String, Object>> individualRoleData : allRolesData) {

					List<Map<String, Object>> allUser = individualRoleData.stream()
							.filter(data -> (String.valueOf(data.get("allowed_user")).equals("*")))
							.collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(allUser)) {
						allUserList.addAll(allUser);
					}

					List<Map<String, Object>> userBased = individualRoleData.stream()
							.filter(data -> (String.valueOf(data.get("allowed_user")).equals(ContextBean.getUserId())))
							.collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(userBased)) {
						userBasedList.addAll(userBased);
					}

				}


				if (CollectionUtils.isNotEmpty(userBasedList)) {
					for (Map<String, Object> data : userBasedList) {
						if (!validateIpRange(authRequestEntity, data,authResultEntity)) {
							return false;
						}
					}
				}

				else if (CollectionUtils.isNotEmpty(allUserList)) {
					for (Map<String, Object> data : allUserList) {
						if (!validateIpRange(authRequestEntity, data,authResultEntity)) {
							return false;
						}
					}
				}
			} else {
				return true;
			}

		} catch (Exception exception) {
			LOGGER.error("exception occurs in user ip validation " + exception.getMessage());
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("exception occurs in user ip validation"));
			return false;
		}
		return true;
	}

	/**
	 * Validate ip range.
	 *
	 * @param authRequestEntity the request
	 * @param userRoleIpDetails the user role ip details
	 * @param authResultEntity 
	 * @return true, if successful
	 */
	private boolean validateIpRange(AuthRequestEntity authRequestEntity, Map<String, Object> userRoleIpDetails, AuthResultEntity authResultEntity) {
		String ipAddress = authRequestEntity.getRemoteAddress();
		LOGGER.info("Remote Address :" + ipAddress);
		String ipPrefixRequest = ipAddress.substring(0, ipAddress.lastIndexOf(TokenTypeIdentifier.DOT.value()) + 1);
		String ipLastValueRequest = ipAddress.substring(ipAddress.lastIndexOf(TokenTypeIdentifier.DOT.value()) + 1);

		String ipPrefixData = String.valueOf(userRoleIpDetails.get("ip_range_prefix"));
		String ipStartData = String.valueOf(userRoleIpDetails.get("ip_range_start"));
		String ipEndData = String.valueOf(userRoleIpDetails.get("ip_range_end"));
		String ipExcludeData = String.valueOf(userRoleIpDetails.get("ip_exclude"));

		if (ipPrefixData.contains(ipPrefixRequest)) {

			if (ipStartData.equals("null") && ipEndData.equals("null") && ipExcludeData.equals("null")) {
				LOGGER.info("Validation Data all null");
				return true;
			} else if (ipStartData.equals("*") && ipEndData.equals("*") && ipExcludeData.equals("*")) {
				LOGGER.info("Validation Data all *");
				return true;
			} else if (Integer.parseInt(ipLastValueRequest) >= Integer.parseInt(ipStartData)
					&& (ipEndData.equals("null") || ipEndData.equals("*"))
					&& !ipLastValueRequest.equals(ipExcludeData)) {
				LOGGER.info("Validation Ip Start Only");
				return true;
			} else if (!ipEndData.equals("null") && Integer.parseInt(ipLastValueRequest) <= Integer.parseInt(ipEndData)
					&& (ipStartData.equals("null") || ipStartData.equals("*"))
					&& !ipLastValueRequest.equals(ipExcludeData)) {
				LOGGER.info("Validation Ip End Only");
				return true;
			} else if (!ipStartData.equals("null") && !ipEndData.equals("null")
					&& Integer.parseInt(ipLastValueRequest) >= Integer.parseInt(ipStartData)
					&& Integer.parseInt(ipLastValueRequest) <= Integer.parseInt(ipEndData)
					&& !ipLastValueRequest.equals(ipExcludeData)) {
				LOGGER.info("Validation Ip Both");
				return true;
			} else if ((ipStartData.equals("*") && ipEndData.equals("*") && !ipExcludeData.equals("*"))
					|| ipStartData.equals("null") && ipEndData.equals("null") && !ipExcludeData.equals("null")) {
				LOGGER.info("Validation Ip Exclude");
				if (ipLastValueRequest.equals(ipExcludeData)) {
					LOGGER.info("Validation Ip Exclude Failed");
					authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_validation_ip_exclude_failed"));
					return false;
				} else {
					return true;
				}
			} else {
				LOGGER.info("Validation Ip Exclude Failed All");
				authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_validation_ip_exclude_failed_all"));
				return false;
			}
		} else if (ipPrefixData.equals("null") || ipPrefixData.equals("*")) {
			LOGGER.info("Validation Ip * ");
			return true;
		} else {
			LOGGER.info("Validation Ip Failed nothing ");
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_validation_ip_failed_nothing"));
			return false;
		}
	}

	/**
	 * Validate client ip.
	 *
	 * @param authRequestEntity the request
	 * @param auth the auth
	 * @return true, if successful
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private boolean validateClientIp(AuthRequestEntity authRequestEntity, OAuth2Authentication auth) throws IOException {
		try {
			LOGGER.info("validateClientIp starts :" + new Timestamp(System.currentTimeMillis()));
			String clientId = auth.getOAuth2Request().getClientId();
			LOGGER.info("Client's ID == " + clientId);
			if (StringUtils.isNotEmpty(clientId)) {
				CacheService cacheService = CacheService.getInstance();
				Map<String, Map<String, Object>> clientIpInfoData = cacheService
						.getClientIpDetails(ContextBean.getTenantId() + "_client_ip_info");
				if (MapUtils.isNotEmpty(clientIpInfoData)) {
					Map<String, Object> clientData = clientIpInfoData.get(clientId);
					if (MapUtils.isNotEmpty(clientData)) {
						List<String> whiteListIp = (List<String>) clientData.get("ip_address");
						if (whiteListIp.contains(authRequestEntity.getRemoteAddress())) {
							return true;
						} else if (whiteListIp.contains("*")) {
							return true;
						} else {
							LOGGER.error("Client's IP is not registered");
							// response 403
							return false;
						}
					}else {
						return true;
					}
				} else {
					return true;
				}
			}
		} catch (QueryException e) {

			return false;
		}
		return false;
	}

	/**
	 * Validate user tenant.
	 *
	 * @param userTokenCacheData the user token cache data
	 * @param authRequestEntity the request
	 * @return true, if successful
	 */
	public boolean validateUserTenant(Map<String, Object> userTokenCacheData, AuthRequestEntity authRequestEntity) {
		try {
			LOGGER.info("validateUserTenant daat starts");
			Map<String, Object> tenantDataMap = getTenantServerDetails(authRequestEntity.getServerName(),authRequestEntity);
			String loginTenant = String.valueOf(tenantDataMap.get("tenant_id"));
			String accessTokenTenant = String.valueOf(userTokenCacheData.get("tenantId"));

			if (getLmsData(authRequestEntity)) {
				LOGGER.info("Lms inside true");
				return true;
			}

			LOGGER.info("login tenant :" + loginTenant);
			LOGGER.info("accessTokenTenant tenant : " + accessTokenTenant);

			if (StringUtils.isEmpty(loginTenant) || StringUtils.isEmpty(accessTokenTenant) || loginTenant.equals("null")
					|| accessTokenTenant.equals("null")) {
				LOGGER.error("tenant data is null or empty");
				return false;
			}
			if (loginTenant.equals(accessTokenTenant)) {
				LOGGER.info("validateUserTenant1 ends :" + new Timestamp(System.currentTimeMillis()));
				return true;
			}

			LOGGER.error("tenant data mismatched");
			return false;
		} catch (Exception exception) {
			LOGGER.error("tenant data validation method exception", exception);
			return false;
		}
	}

	/**
	 * Gets the lms data.
	 *
	 * @param sovaRequest the sova request
	 * @return the lms data
	 * @throws QueryException the query exception
	 */
	public boolean getLmsData(AuthRequestEntity authRequestEntity) throws QueryException {
		String cacheKey = EnvironmentReader.getSystemId().concat("_").concat(authRequestEntity.getServerName());
		Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.isNull(cacheKeyExistData)) {
			updateLmsData(authRequestEntity);
			cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		}
		Map<String, Object> lmsData = (Map<String, Object>) cacheKeyExistData;
		if (MapUtils.isNotEmpty(lmsData) || authRequestEntity.getRequestPath().contains("job/publish")
				|| authRequestEntity.getRequestPath().contains("job/tenant")) {
			return true;
		}
		return false;
	}

	/**
	 * Update lms data.
	 *
	 * @param sovaRequest the sova request
	 * @throws QueryException the query exception
	 */
	public void updateLmsData(AuthRequestEntity authRequestEntity) throws QueryException {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select();
		List<Map<String, Object>> dataList = selectQueryBuilder.get("lms_system_id", "lms_lb_url")
				.from("lms_system_definition")
				.where(ConditionBuilder.instance().eq("lms_system_id", EnvironmentReader.getSystemId()).and()
						.eq("lms_lb_url", authRequestEntity.getServerName()))
				.build(false).execute();

		if (CollectionUtils.isNotEmpty(dataList)) {
			dataList.stream().forEach(action -> {
				Map<String, Object> dataMap = new HashMap<>();
				dataMap.put("lms_system_id", String.valueOf(action.get("lms_system_id")));
				dataMap.put("lms_lb_url", String.valueOf(action.get("lms_lb_url")));
				CacheService.getInstance().saveToCache(
						EnvironmentReader.getSystemId().concat("_").concat(authRequestEntity.getServerName()), dataMap);
			});
		}
	}

	/**
	 * Gets the tenant server details.
	 *
	 * @param serverName the server name
	 * @param authRequestEntity 
	 * @return the tenant server details
	 * @throws QueryException the query exception
	 */
	public Map<String, Object> getTenantServerDetails(String serverName, AuthRequestEntity authRequestEntity) throws QueryException {
		String tenantId = authRequestEntity.getDefaultTenantId();
		LOGGER.info("default_tenant_id :" + tenantId);
		String cacheKey = serverName.concat("_tenant_data");
		Object cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		if (Objects.isNull(cacheKeyExistData)) {
			updateTenantServerDetails(serverName);
			cacheKeyExistData = CacheManager.getInstance().getWithObject(cacheKey);
		}
		Map<String, Object> tenantData = (Map<String, Object>) cacheKeyExistData;

		if (MapUtils.isNotEmpty(tenantData)) {
			return tenantData;
		} else if (Objects.nonNull(tenantId) && !StringUtils.isEmpty(tenantId)) {
			Map<String, Object> defaultTenantDataMap = new HashMap<>();
			defaultTenantDataMap.put("tenant_id", tenantId);
			return defaultTenantDataMap;
		}
		return Collections.emptyMap();
	}

	/**
	 * Update tenant server details.
	 *
	 * @param serverName the server name
	 */
	public void updateTenantServerDetails(String serverName) {
		List<Map<String, Object>> tenantList;
		try {
			tenantList = new QueryBuilder().btSchema().select()
					.get("tenant_definition.tenant_id", "tenant_definition.template_code","tenant_definition.maintenance_flag",
							"tenant_definition.domain_name", "login_template_details.design_template",
							"login_template_details.bg_image")
					.from("tenant_definition", "tenant_definition")
					.leftJoin("login_template_details", "login_template_details",
							ConditionBuilder.instance().eq("login_template_details.template_code",
									"tenant_definition.template_code", true))
					.where(ConditionBuilder.instance().eq("tenant_definition.domain_name", serverName)).build(false)
					.execute();

			if (CollectionUtils.isNotEmpty(tenantList)) {
				tenantList.stream().forEach(action -> {
					Map<String, Object> dataMap = new HashMap<>();
					dataMap.put("tenant_id", String.valueOf(action.get("tenant_id")));
					dataMap.put("domain_name", String.valueOf(action.get("domain_name")));
					dataMap.put("maintenance_flag", String.valueOf(action.get("maintenance_flag")));
					CacheService.getInstance().saveToCache(serverName.concat("_tenant_data"), dataMap);
				});
			} else {
				CacheService.getInstance().saveToCache(serverName.concat("_tenant_data"), Collections.emptyMap());
			}
		} catch (Exception exception) {
			LOGGER.error("update tenant data failure", exception);
		}
	}

	/**
	 * Gets the header data.
	 *
	 * @param headerKey the header key
	 * @param sovaRequest the sova request
	 * @return the header data
	 */
	public Object getHeaderData(String headerKey, AuthRequestEntity authRequestEntity) {
		return authRequestEntity.getHeaders().get(headerKey);
	}

	/**
	 * Authorize request.
	 *
	 * @param userTokenCacheData the user token cache data
	 * @param authResultEntity 
	 * @param request the request
	 * @return true, if successful
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public boolean authorizeRequest(Map<String, Object> userTokenCacheData, AuthRequestEntity authRequestEntity, AuthResultEntity authResultEntity) throws IOException {
		try {

			AuthorizationValidationImpl authorizationValidationImpl = new AuthorizationValidationImpl();

			RequestParamEntity requestParamEntity = new RequestParamEntity();
			requestParamEntity.setUserId(String.valueOf(userTokenCacheData.get("userId")));
			requestParamEntity.setSid(authRequestEntity.getSid());
			requestParamEntity.setUrl(authRequestEntity.getContextPath().concat(authRequestEntity.getRequestPath()));
			requestParamEntity.setServletPath(authRequestEntity.getRequestPath());
			requestParamEntity.setContextPath(authRequestEntity.getContextPath());
			requestParamEntity.setTenantId(String.valueOf(userTokenCacheData.get("tenantId")));
			requestParamEntity.setLocale(String.valueOf(userTokenCacheData.get("locale")));

			List<String> roleList = authorizationValidationImpl.fetchRolesByUserId(requestParamEntity);
			LOGGER.info("Roles List for user :" + roleList);
			if(CollectionUtils.isEmpty(roleList)) {
				LOGGER.error("Role List is empty");
				authResultEntity.setReason(String.valueOf(MessageImplementation.getInstance().getMessageData("nn_role_list_empty_for_user")));
				return false;
			}

			if (validateAuthorizedUrl(authRequestEntity)) {
				LOGGER.info("Roles List for user :" + roleList);
				return true;
			} else {
				Map<String,Object> authorityStatusMap =  authorizationValidationImpl.authorizeRequest(requestParamEntity);
				if (BooleanUtils.isTrue(Boolean.parseBoolean(String.valueOf(authorityStatusMap.get("status"))))) {
					authResultEntity.setFullAuthority(Boolean.parseBoolean(String.valueOf(authorityStatusMap.get("fullAuthority"))));
					return true;
				} else {
					LOGGER.error("AuthorizeRequest failed");
					authResultEntity.setReason(String.valueOf(authorityStatusMap.get("reason")));
					return false;
				}
			}
		} catch (Exception exception) {
			LOGGER.error(exception);
			authResultEntity.setReason("Unexpected Exception during authorizeRequest");
			return false;
		}
	}

	/**
	 * Validate authorized url.
	 *
	 * @param request the request
	 * @return true, if successful
	 * @throws QueryException 
	 */
	public boolean validateAuthorizedUrl(AuthRequestEntity authRequestEntity){
		try {
			AtomicReference<Boolean> status = new AtomicReference<>();
			status.set(false);
			List<String> authorizedUrlList = CacheMaintenance.getInstance().getAllAuthorizedUrlFromCache();
			if (CollectionUtils.isNotEmpty(authorizedUrlList)) {
				authorizedUrlList.stream().forEach(action -> {
					if (authRequestEntity.getRequestPath().contains(action)) {
						status.set(true);
						return;
					}
				});
			} else {
				return status.get();
			}
			return status.get();
		}
		catch(Exception exception) {
			LOGGER.info(exception);
			return false;
		}
	}

}
