package com.nn.sova.notification.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nn.sova.notification.config.NotificationConfig;
import com.nn.sova.notification.constants.NotificationConstants;
import com.nn.sova.notification.gateway.service.NotificationStatusManager;
import com.nn.sova.notification.queue.service.SQSNotificationServiceImpl;
import com.nn.sova.nts.vo.GatewayType;
import com.nn.sova.nts.vo.NotificationException;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.nts.vo.NotificationStatus;
import com.nn.sova.nts.vo.NotificationType;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

public class NotificationServiceImpl implements NotificationService {

	private static final ApplicationLogger logger = ApplicationLogger.create(NotificationServiceImpl.class);
	private static final ObjectMapper mapper = new ObjectMapper();
	
	private static final String USER_IDS = "userIds";
	private static final String SID = "sid";
	private static final String ERROR_USER_IDS_REQUIRED = "UserIds parameter is required";
	private static final String ERROR_FCM_IDS_REQUIRED = "FCM IDS parameter is required";
	private static final String ERROR_SID_REQUIRED = "Sid parameter is required";
	private static final String ERROR_ALERTID_REQUIRED = "Alert ID parameter is required";
	private static final String ERROR_PHONE_NUMBER_REQUIRED = "Phone number parameter is required";
	private static final String ERROR_TO_MAIL_LIST_REQUIRED = "to email parameter is required";
	private static final String ERROR_USERIDS_IS_EMPTY = "UserId is empty.";
	private static final String ERROR_TO_EMAIL_IS_EMPTY = "to email parameter is empty.";
	private static final String NOTIFICATION_ID = "notificationId";
	private static final String USER_ID = "user_id";
	private static final String EMAIL_ID = "email_id";
	private static final String TO_EMAIL_LIST = "to";
	private static final String ALERT_ID = "alert_id";
	private static final String PHONE_NUMBER = "phone_number";
	private static final String FCM_IDS = "fcm_ids";
	

	@Override
	public List<NotificationResponse> notify(List<Map<String, Object>> notificationRequestData) throws Exception {
		List<NotificationResponse> response = new ArrayList<>();
			for (Map<String, Object> requestData : notificationRequestData) {
				try {
				Objects.requireNonNull(requestData.containsKey(USER_IDS) ? (List) requestData.get(USER_IDS) : null , ERROR_USER_IDS_REQUIRED);
				Objects.requireNonNull(requestData.containsKey(SID) && Objects.nonNull(requestData.get(SID)) && !requestData.get(SID).toString().isBlank() 
						? requestData.get(SID).toString() : null, ERROR_SID_REQUIRED);
				Objects.requireNonNull(requestData.containsKey(ALERT_ID) && Objects.nonNull(requestData.get(ALERT_ID)) && !requestData.get(ALERT_ID).toString().isBlank() 
						? requestData.get(ALERT_ID).toString() : null, ERROR_ALERTID_REQUIRED);
				Map<String, Object> handlerDataMap = NotificationConfig.getNtsGatewayService().getHandlerConfig(requestData,
						StringUtils.EMPTY);
				NotificationConfig.getNtsGatewayService().getNotificationTemplateByAlertId(requestData);
				String sid = requestData.get(SID).toString();
				List<Object> userList = (List) requestData.get(USER_IDS);
				if(userList.isEmpty()) {
					throw new NotificationException(ERROR_USERIDS_IS_EMPTY);
				}
				requestData.remove(USER_IDS);
				Map<String, Map<String, Object>> userDetails = getUserDetails(userList);
				Map<String, Map<String, Object>> notificationUserDefmap = getNotificationPreferenceByUsers(userList, sid);
				for (Object user : userList) {
					try {
						Map<String, Object> userData = userDetails.get(user);
						if (Objects.isNull(userData) || userData.isEmpty()) {
							throw new NotificationException("User Data is not found in DB for the user - " + user);
						}
						userData.putAll(requestData);
						Map<String, Object> ntsUserDef = notificationUserDefmap.get(user);
						if (Objects.isNull(ntsUserDef) || ntsUserDef.isEmpty()) {
							throw new NotificationException("Notification preference is not found in DB for the user - " + user);
						}
						for (NotificationType notificationType : NotificationType.values()) {
							if ((Boolean.parseBoolean(ntsUserDef.containsKey(notificationType.toString().toLowerCase())
									&& Objects.nonNull(ntsUserDef.get(notificationType.toString().toLowerCase()))
									? ntsUserDef.get(notificationType.toString().toLowerCase()).toString()
									: StringUtils.EMPTY))) {
								String notificationId = UUID.randomUUID().toString();
								userData.put(NOTIFICATION_ID, notificationId);
								response.add(sendNtsDataToQueue(userData,
										(Map<String, Object>) handlerDataMap.get(notificationType.getValue()),
										notificationType.getValue(), notificationType.getValue()));
							}
						}
					} catch(Exception exception) {
						response.add(NotificationResponse.of(null, NotificationStatus.FAILED, exception.getMessage()));
					}
				}
			} catch(Exception exception) {
				response.add(NotificationResponse.of(null, NotificationStatus.FAILED, exception.getMessage()));
			}
		} 
		logger.info("Finished executing notify");
		return response;
	}

	/**
	 * Notify the user through SMS.
	 * 
	 * @param requestData
	 * @throws Exception 
	 */
	@Override
	public List<NotificationResponse> notifyBySms(List<Map<String, Object>> notificationRequestData) throws Exception {
		List<NotificationResponse> response = new ArrayList<>();
		for(Map<String,Object> requestData: notificationRequestData) {
			String notificationId = UUID.randomUUID().toString();
			requestData.put(NOTIFICATION_ID, notificationId);
			NotificationStatusManager provider = NotificationConfig.getNtsHandlerFactoryService().getServiceInstance(GatewayType.SMS.toString().toLowerCase());
			try {
				Objects.requireNonNull(requestData.containsKey(PHONE_NUMBER)  && Objects.nonNull(requestData.get(PHONE_NUMBER)) && !requestData.get(PHONE_NUMBER).toString().isBlank() 
						? requestData.get(PHONE_NUMBER) : null , ERROR_PHONE_NUMBER_REQUIRED);
				provider.upsertTransactionStatus(requestData, NotificationResponse.of(notificationId, NotificationStatus.NOT_QUEUED, ""));
				Map<String, Object> handlerDataMap = NotificationConfig.getNtsGatewayService().getHandlerConfig(requestData, GatewayType.SMS.toString().toLowerCase());
				NotificationConfig.getNtsGatewayService().getNotificationTemplateByAlertId(requestData);
				Map<String, Object> smsHandlerData = (Map<String, Object>) handlerDataMap
					.get(GatewayType.SMS.toString().toLowerCase());
				response.add(sendNtsDataToQueue(requestData, smsHandlerData, GatewayType.SMS.toString().toLowerCase(), NotificationConstants.ROUTING_KEY_SMS));
				} catch(Exception exception) {
				provider.upsertTransactionStatus(requestData, NotificationResponse.of(notificationId, NotificationStatus.FAILED, exception.getMessage()));
				response.add(NotificationResponse.of(notificationId, NotificationStatus.FAILED, exception.getMessage()));
				}			
		}
		return response;
	}

	/**
	 * Notify the user through mail.
	 * 
	 * @param requestData
	 * @return
	 * @throws Exception 
	 */
	@Override
	public List<NotificationResponse> notifyByMail(List<Map<String, Object>> notificationRequestData) throws Exception {
		List<NotificationResponse> response = new ArrayList<>();
		for(Map<String,Object> requestData: notificationRequestData) {
			String notificationId = UUID.randomUUID().toString();
			List<Object> toList = new ArrayList<>();
			requestData.put(NOTIFICATION_ID, notificationId);
			if(requestData.containsKey(EMAIL_ID) && Objects.nonNull(requestData.get(EMAIL_ID)) &&
					!requestData.get(EMAIL_ID).toString().isBlank()) {
				requestData.put(TO_EMAIL_LIST, Arrays.asList(requestData.get(EMAIL_ID).toString()));
			}
			NotificationStatusManager provider = NotificationConfig.getNtsHandlerFactoryService().getServiceInstance(GatewayType.MAIL.toString().toLowerCase());
			try {
				Objects.requireNonNull(requestData.containsKey(TO_EMAIL_LIST) ? (List) requestData.get(TO_EMAIL_LIST) : null , ERROR_TO_MAIL_LIST_REQUIRED);
				toList = (List) requestData.get(TO_EMAIL_LIST);
				if(toList.isEmpty()) {
					throw new NotificationException(ERROR_TO_EMAIL_IS_EMPTY);
				}
				provider.upsertTransactionStatus(requestData, NotificationResponse.of(notificationId, NotificationStatus.NOT_QUEUED, ""));
				Map<String, Object> handlerDataMap = NotificationConfig.getNtsGatewayService().getHandlerConfig(requestData, GatewayType.MAIL.toString().toLowerCase());
                NotificationConfig.getNtsGatewayService().getNotificationTemplateByAlertId(requestData);
				Map<String, Object> mailHandlerData = (Map<String, Object>) handlerDataMap
							.get(GatewayType.MAIL.toString().toLowerCase());
				response.add(sendNtsDataToQueue(requestData, mailHandlerData, GatewayType.MAIL.toString().toLowerCase(), NotificationConstants.ROUTING_KEY_MAIL));	
				} catch(Exception exception) {
					provider.upsertTransactionStatus(requestData, NotificationResponse.of(notificationId, NotificationStatus.FAILED, exception.getMessage()));
					response.add(NotificationResponse.of(notificationId, NotificationStatus.FAILED, exception.getMessage()));
				}
			}
			return response;
	}
	

	/**
	 * get the notification preference from DB .
	 * 
	 * @param userList
	 * @return
	 */
	private Map<String, Map<String, Object>> getNotificationPreferenceByUsers(List<Object> userList, String sid) {
		List<Map<String, Object>> userNtsDefList = NotificationConfig.getNotificationDao().getNotificationPreferenceByUsers(userList, sid);
		return userNtsDefList.stream()
				.collect(Collectors.toMap(user -> (String) user.get(NotificationConstants.USER_ID_KEY), user -> user));
	}
    
	/**
	 * get user details from nts_user_account.
	 * @param userList
	 * @return
	 */
	private Map<String, Map<String, Object>> getUserDetails(List<Object> userList) {
		List<Map<String, Object>> userDetails = NotificationConfig.getNotificationDao().getUserAccount(userList);
		return userDetails.stream()
				.collect(Collectors.toMap(user -> (String) user.get(NotificationConstants.USER_ID_KEY), user -> user));
	}

	
	private NotificationResponse sendNtsDataToQueue(Map<String, Object> notificationRequestData, Map<String, Object> handlerData,
			String gatewayType, String routingKey) throws Exception {
		Map<String,Object> message = new HashMap<>();
		String notificationId = notificationRequestData.get(NOTIFICATION_ID).toString();
		message.put("userData", notificationRequestData);
		message.put("handlerData", handlerData);
		message.put("gatewayType", gatewayType);
		message.put("tenantId", ContextBean.getTenantId());
		message.put("messageId", notificationId);
		String messageObj = mapper.writeValueAsString(message);
		NotificationStatusManager provider = NotificationConfig.getNtsHandlerFactoryService().getServiceInstance(gatewayType);
		try {
			SQSNotificationServiceImpl.getInstance().publishMessage(messageObj, routingKey);
//			rabbitTemplate.convertAndSend(NotificationConstants.NOTIFICATION_RABBIT_MQ_EXCHANGE, routingKey, message);
			provider.upsertTransactionStatus(notificationRequestData, NotificationResponse.of(notificationId, NotificationStatus.QUEUED, ""));
			logger.info("Message sent to Queue");
			return NotificationResponse.of(notificationId, NotificationStatus.QUEUED, null);
		} catch(Exception exception) {
			logger.error(exception.toString());
			provider.upsertTransactionStatus(notificationRequestData, NotificationResponse.of(notificationId, NotificationStatus.FAILED, exception.toString()));
			return NotificationResponse.of(notificationId, NotificationStatus.FAILED, exception.toString());
		}
	}

}
