package com.nn.sova.nts.vo;

public enum NotificationType {
	SMS("sms"),
	MAIL("mail"),
	MOBILE_PUSH("fcm");
	
	private String value;

	NotificationType (String notificationType) {
		this.value = notificationType;
	}

	public String getValue() {
		return value;
	}
	
}
