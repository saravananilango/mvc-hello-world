package com.nn.sova.notification.factory.mail;

import org.apache.commons.lang.StringUtils;

import com.nn.sova.notification.gateway.mail.NtsEmailGatewayService;
import com.nn.sova.notification.gateway.mail.NtsGatewayAwsEmailServiceImpl;
import com.nn.sova.notification.gateway.service.NtsGatewayService;

public class NtsEmailGatewayFactory extends NtsEmailGatewayService {

	@Override
	public NtsGatewayService getGatewayInstance(String gatewayId) {
		if(StringUtils.isEmpty(gatewayId)) {
			 return null;
		}
		switch(gatewayId) {
		 case "GTW_02":
			 return NtsGatewayAwsEmailServiceImpl.getInstance();
		 default:
			 return null;
		}
	}

}
