package com.nn.sova.service.authorization.utils;


/**
 * TokenIdentifier represents the types of symbols.
 *
 * @author Vellaichamy N
 */


public enum TokenIdentifier {

	/** The percent. */
	PERCENT("%"),

	/** The ampercent. */
	AMPERCENT("&"),

	/** The backward slash. */
	BACKWARD_SLASH("\\"),

	/** The forward slash. */
	FORWARD_SLASH("/"),

	/** The semicolon. */
	SEMICOLON(";"),

	/** The colon. */
	COLON(":"),

	/** The open bracket. */
	OPEN_BRACKET("("),

	/** The closed bracket. */
	CLOSED_BRACKET(")"),

	/** The open curly bracket. */
	OPEN_CURLY_BRACKET("{"),

	/** The closed curly bracket. */
	CLOSED_CURLY_BRACKET("}"),

	/** The open sq bracket. */
	OPEN_SQ_BRACKET("["),

	/** The closed sq bracket. */
	CLOSED_SQ_BRACKET("]"),

	/** The question mark. */
	QUESTION_MARK("?"),

	/** The dot. */
	DOT("."),

	/** The comma. */
	COMMA(","),

	/** The double quotes. */
	DOUBLE_QUOTES("\""),

	/** The apostrophe. */
	APOSTROPHE("'"),

	/** The asterisk. */
	ASTERISK("*"),

	/** The hyphen. */
	HYPHEN("-"),

	/** The underscore. */
	UNDERSCORE("_"),

	/** The equal. */
	EQUAL("="),

	/** The plus. */
	PLUS("+"),

	/** The minus. */
	MINUS("-"),

	/** The greater than. */
	GREATER_THAN(">"),

	/** The lesser than. */
	LESSER_THAN("<");

	/** value of the enum. */
	private final String value;

	/**
	 * Set the value.
	 *
	 * @param value the value
	 */
	TokenIdentifier(String value){
		this.value=value;
	}

	/**
	 * value returns the value of the enum.
	 *
	 * @return Value
	 */
	public String value(){
		return this.value;
	}

}
