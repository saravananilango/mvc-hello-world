package com.nn.sova.flowlogger.service;

import java.util.List;
import java.util.Map;

import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * The Interface FlowLogService.
 */
public interface FlowLoggerService {

    /**
     * Gets the log group name.
     *
     * @param paramMap the param map
     * @return the log group name
     */
    public String getLogGroupName(Map<String, Object> paramMap);

    /**
     * Gets the program id.
     *
     * @param paramMap the param map
     * @return the program id
     */
    public String getProgramId(Map<String, Object> paramMap);
    
    /**
     * Gets the flowLog data
     * @param paramMap
     * @return the flow log data list
     */
    public List<Map<String,Object>> getFlowLogs(Map<String,Object> paramMap);
    

}
