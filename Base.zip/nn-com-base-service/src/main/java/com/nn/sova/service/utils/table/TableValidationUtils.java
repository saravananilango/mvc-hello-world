package com.nn.sova.service.utils.table;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nn.sova.changerequest.ChangeRequestStatusEnum;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * TableValidationUtils used for table validation based from object explorer
 * 
 * @author Mohan Ram M
 *
 */
public class TableValidationUtils {
	
	/** The logger. */
	private static  ApplicationLogger logger = ApplicationLogger.create(TableValidationUtils.class);

	public static Map<String,Object> checkOwnerandInprogressValidation(Map<String,Object> paramMap){
		logger.info("checkOwnerandInprogressValidation method execution starts " + paramMap);
		Map<String,Object> returnMap = new HashMap<>();
		returnMap.put("status",true);
		try {
			String tableName = String.valueOf(paramMap.get("tableName"));
			String productCode = String.valueOf(paramMap.get("productCode"));
			List<Map<String,Object>> inprogressList =new QueryBuilder().btSchema().select()
			.from("table_definition", "tableDefinition").where(ConditionBuilder.instance().eq("tableDefinition.table_name",
					tableName).and().eq("tableDefinition.product_code", productCode).and().eq("status", "INPROGRESS")).build(false).execute();
			if(!inprogressList.isEmpty() ) {
				returnMap.put("status", false);
				returnMap.put("inprogress", true);
			}else {
			List<Map<String, Object>> changeRequestList = new QueryBuilder().btSchema().select()
					.from("table_definition", "tableDefinition")
					.join("change_request", "changeRequest",
							ConditionBuilder.instance().eq("change_request_id", "previous_request_id", true))
					.where(ConditionBuilder.instance().isNotNull("previous_request_id").and().eq("tableDefinition.table_name",
							tableName).and().eq("tableDefinition.product_code", productCode))
					.build(false).execute();
			if (changeRequestList.isEmpty()) {
				returnMap.put("status", true);
			} else {
				if (changeRequestList.get(0).get("parent_status").equals(ChangeRequestStatusEnum.DELIVERED.name())
						|| changeRequestList.get(0).get("parent_status")
								.equals(ChangeRequestStatusEnum.DELETED.name())
						|| changeRequestList.get(0).get("parent_status")
								.equals(ChangeRequestStatusEnum.REVERTED.name())) {
					returnMap.put("status", true);
				} else if (ContextBean.getUserId().equals(changeRequestList.get(0).get("owner"))) {
					returnMap.put("status", true);
				} else {
					returnMap.put("status", false);
					returnMap.put("owner", changeRequestList.get(0).get("owner"));
				}
			}
			}
		}catch(Exception exception) {
			returnMap.put("status", false);
			logger.error(exception);
		}
		return returnMap;
	}
}