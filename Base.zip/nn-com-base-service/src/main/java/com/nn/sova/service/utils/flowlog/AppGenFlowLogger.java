package com.nn.sova.service.utils.flowlog;

import java.util.Map;
import java.util.function.Supplier;

/**
 * AppGenFlowLogger Functional interface to determine the type of logger
 * 
 * @author Vignesh R
 *
 */
@FunctionalInterface
public interface AppGenFlowLogger {

	public void sendLog(Map<String,String> log);
	
	public static Supplier<AppGenFlowLogger> getLogger(AppGenFlowLoggerType type){
		return () -> {
			switch (type) {
			case AWS:
				return new AppGenAWSFlowLogger();
			default:
				return new AppGenDBFlowLogger();
			}
		};
	}
	
}
