package com.nn.sova.notification.gateway.mail;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;
import com.nn.sova.notification.gateway.service.NotificationStatusManager;
import com.nn.sova.notification.gateway.service.NtsGatewayService;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.nts.vo.NotificationStatus;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.utility.json.JsonUtils;
import com.nn.sova.utility.logger.ApplicationLogger;
/**
 * 
 * Service class for Email service.
 *
 */
public abstract class NtsEmailGatewayService  implements NotificationStatusManager {
	private static final ApplicationLogger logger = ApplicationLogger.create(NtsEmailGatewayService.class);
	
	private static final String MAIL_TRANSACTION_TABLE = "nts_transaction_mail";
	
	/** The Constant MAIL_TRANSACTION_TABLE primary keys. */
	private static final String[] MAIL_TRANSACTION_PRIMARY_KEYS = { "tenant_id", "item_id" };
	
	public abstract NtsGatewayService getGatewayInstance(String gatewayId);
	
	@Override
	public String upsertTransactionStatus(Map<String,Object> userData, NotificationResponse response) {
		List<String> updatedColumns = new ArrayList<>();
		QueryBuilder queryBuilder = new QueryBuilder();
		Map<String,Object> mailTransactionMap = new HashMap<>();
		String itemId = userData.get("notificationId").toString();
		mailTransactionMap.put(MAIL_TRANSACTION_TABLE+".item_id",itemId);
		mailTransactionMap.put(MAIL_TRANSACTION_TABLE+".mail_content_json",JsonUtils.toJsonOrEmpty(userData).toString());
		mailTransactionMap.put(MAIL_TRANSACTION_TABLE+".status", response.getStatus().toString());
		mailTransactionMap.put(MAIL_TRANSACTION_TABLE+".error_message", response.getErrorMessage());
		if(NotificationStatus.COMPLETED.equals(response.getStatus())) {
			mailTransactionMap.put(MAIL_TRANSACTION_TABLE+".sent_time", new Timestamp(new Date().getTime()));
			updatedColumns = Arrays.asList("item_id","mail_content_json","sent_time","status","error_message");
		} else if(NotificationStatus.QUEUED.equals(response.getStatus())) {
			mailTransactionMap.put(MAIL_TRANSACTION_TABLE+".queued_time",new Timestamp(new Date().getTime()));
			updatedColumns = Arrays.asList("item_id","mail_content_json","queued_time","status","error_message");
		} else if(NotificationStatus.FAILED.equals(response.getStatus())) {
			updatedColumns = Arrays.asList("item_id","mail_content_json","status","error_message");
		}  
		try {
			queryBuilder.btSchema().insert().upsertWithKeyList(MAIL_TRANSACTION_TABLE, Arrays.asList(mailTransactionMap),
					true, updatedColumns, MAIL_TRANSACTION_PRIMARY_KEYS);
		} catch (QueryException e) {
			logger.error("Error Occured :: insertIntoMailTransactionTable",e);
		}
		return itemId;
	}
}
