package com.nn.sova.service.authorization.entity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import lombok.Data;

import org.apache.commons.lang3.StringUtils;

/**
 * ScreenConfigurationEntity defines the screen Cfg Def data.
 *
 * @author Vellaichamy N
 */

@Data
public class ScreenConfigurationEntity {

	/**  The screen ID. */
	private String screenId;

	/**  The screen Def Id. */
	private String screenDefId;

	/**  The screen Name. */
	private String screenName;

	/**  The created User. */
	private String createUser;

	/**  The Created Date. */
	private LocalDate createDate;

	/**  The Updated User. */
	private String updateUser;

	/**  The Updated Date. */
	private LocalDate updateDate;

	/**
	 * mapValues convert screenConfigEntity into screen Config Mapper.
	 *
	 * @param screenConfigEntity has an Screen Info like screen id , screen name etc
	 * @return Screen Configuration as map values
	 */
	public static Map<String, Object> mapValues(ScreenConfigurationEntity screenConfigEntity) {
		Map<String, Object> screenConfigMapper=new HashMap<>();
		screenConfigMapper.put("screen_id",screenConfigEntity.getScreenId());
		screenConfigMapper.put("screen_def_id",screenConfigEntity.getScreenDefId());
		screenConfigMapper.put("screen_name",screenConfigEntity.getScreenName());
		screenConfigMapper.put("create_user",screenConfigEntity.getCreateUser());
		screenConfigMapper.put("create_date",screenConfigEntity.getCreateDate());
		screenConfigMapper.put("update_user",screenConfigEntity.getUpdateUser());
		screenConfigMapper.put("update_date",screenConfigEntity.getUpdateDate());
		return screenConfigMapper;
	}


	/**
	 * mapValues convert map into entity.
	 *
	 * @param screenConfigMapper has an screen info like screen id, screen name etc
	 * @return screenCfgEntity has values as entity
	 */
	public static ScreenConfigurationEntity mapValues(Map<String, Object> screenConfigMapper) {
		ScreenConfigurationEntity screenConfigEntity=new ScreenConfigurationEntity();
		screenConfigEntity.setScreenId(Objects.isNull(screenConfigMapper.get("screenConfiguration.screenId"))?StringUtils.EMPTY:screenConfigMapper.get("screenConfiguration.screenId").toString());
		screenConfigEntity.setScreenDefId(Objects.isNull(screenConfigMapper.get("screenConfiguration.screenDefId"))?StringUtils.EMPTY:screenConfigMapper.get("screenConfiguration.screenDefId").toString());
		screenConfigEntity.setScreenName(Objects.isNull(screenConfigMapper.get("screenConfiguration.screenName"))?StringUtils.EMPTY:screenConfigMapper.get("screenConfiguration.screenName").toString());
		screenConfigEntity.setCreateUser(Objects.isNull(screenConfigMapper.get("screenConfiguration.createUser"))?StringUtils.EMPTY:screenConfigMapper.get("screenConfiguration.createUser").toString());
		screenConfigEntity.setCreateDate(Objects.isNull(screenConfigMapper.get("screenConfiguration.createDate"))?null:LocalDate.parse(screenConfigMapper.get("screenConfiguration.createDate").toString(),DateTimeFormatter.ofPattern("yyyy-MM-d")));
		screenConfigEntity.setUpdateUser(Objects.isNull(screenConfigMapper.get("screenConfiguration.updateUser"))?StringUtils.EMPTY:screenConfigMapper.get("screenConfiguration.updateUser").toString());
		screenConfigEntity.setUpdateDate(Objects.isNull(screenConfigMapper.get("screenConfiguration.updateDate"))?null:LocalDate.parse(screenConfigMapper.get("screenConfiguration.updateDate").toString(),DateTimeFormatter.ofPattern("yyyy-MM-d")));
		return screenConfigEntity;
	}
}
