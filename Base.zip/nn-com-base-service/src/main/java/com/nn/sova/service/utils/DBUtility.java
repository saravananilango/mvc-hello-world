package com.nn.sova.service.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * DBUtility class contains common methods to fetch common logics
 * @author Vignesh R
 *
 */
public class DBUtility {
	
	public static final String COUNT = "count";
	
	/**
	 * getCount method to fetch number of records in the given table
	 * @param tableName
	 * @param columnName
	 * @param condition
	 * @return Count
	 * @throws QueryException 
	 */
	public static Long getCount(String tableName, String columnName, ConditionBuilder condition) throws QueryException {
		SelectQueryBuilder builder = new QueryBuilder().select()
				.checkIndependentTenant(true).count(columnName, COUNT).from(tableName);
		return getCount(builder, condition);
	}
	
	/**
	 * Takes count query result as input param and generates the count
	 * @param countQueryResult
	 * @return Count
	 */
	public static Long getCount(List<Map<String,Object>> countQueryResult) {
		return Optional.ofNullable(countQueryResult).filter(CollectionUtils::isNotEmpty)
                .map(list -> list.get(0))
                .filter(row -> row.containsKey(COUNT))
                .map(row -> (Long)row.get(COUNT))
                .orElse(0l);
	}

	/**
	 * getCount method to fetch number of records in the given table
	 * @param tableName
	 * @param columnName
	 * @param condition
	 * @return Count
	 * @throws QueryException 
	 */
	public static Long getCount(SelectQueryBuilder builder, ConditionBuilder condition) throws QueryException {
		if(Optional.ofNullable(condition).isPresent()) {			
			builder = builder.where(condition);
		}
		return getCount(builder.build(false).execute());
	}
	
	/**
	 * Build a condition with Equal appended by AND condition
	 * @param conditionMap
	 * @return conditionBuilder
	 */
	public static ConditionBuilder buildConditionEqWithAnd(Map<String,String> conditionMap) {
		return buildCondition(conditionMap, true, true);
	}
	
	/**
	 * Build a condition with Equal appended by OR condition
	 * @param conditionMap
	 * @return conditionBuilder
	 */
	public static ConditionBuilder buildConditionEqWithOr(Map<String,String> conditionMap) {
		return buildCondition(conditionMap, true, false);
	}
	
	/**
	 * Build a condition with Not Equal appended by AND condition
	 * @param conditionMap
	 * @return conditionBuilder
	 */
	public static ConditionBuilder buildConditionNEqWithAnd(Map<String,String> conditionMap) {
		return buildCondition(conditionMap, false, true);
	}
	
	/**
	 * Build a condition with Not Equal appended by OR condition
	 * @param conditionMap
	 * @return conditionBuilder
	 */
	public static ConditionBuilder buildConditionNEqWithOr(Map<String,String> conditionMap) {
		return buildCondition(conditionMap, false, false);
	}
	
	/**
	 * Build a basic condition builder with conditionMap and connect with EQ or NOT_EQ flag with AND or OR appender
	 * @param conditionMap
	 * @param isEquals
	 * @param and
	 * @return conditionBuilder
	 */
	public static ConditionBuilder buildCondition(Map<String,String> conditionMap, boolean isEquals, boolean and) {
		ConditionBuilder conditionBuilder = ConditionBuilder.instance();
		Iterator<Entry<String, String>> iterator = conditionMap.entrySet().iterator();
		while(iterator.hasNext()) {
			Entry<String,String> entry = iterator.next();
			if(isEquals)
				conditionBuilder.eq(entry.getKey(), entry.getValue());
			else
				conditionBuilder.notEq(entry.getKey(), entry.getValue());
			if(iterator.hasNext())
				if(and)
					conditionBuilder.and();
				else
					conditionBuilder.or();
		}
		return conditionBuilder;
	}
}
