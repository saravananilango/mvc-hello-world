package com.nn.sova.service.authorization.entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import lombok.Data;

/**
 * RoleLinkEntity defines the Role Link Data.
 *
 * @author Vellaichamy N
 */

@Data
public class RoleLinkEntity {

	/** The Constant USERID_CONST. */
	private static final String USERID_CONST = "user_id";

	/** The Constant ROLE_ID. */
	private static final String ROLE_ID = "role_id";

	/**  The User ID. */
	private String userId;

	/**  The Role Id. */
	private String roleId;

	/**
	 * mapValues convert map into entity.
	 *
	 * @param roleLinkMapper has an role link info as map
	 * @return RoleLinkEntity
	 */
	public static RoleLinkEntity mapValues(Map<String, Object> roleLinkMapper) {
		RoleLinkEntity roleLinkEntity=new RoleLinkEntity();
		roleLinkEntity.setUserId(Objects.isNull(roleLinkMapper.get(USERID_CONST))?StringUtils.EMPTY:roleLinkMapper.get(USERID_CONST).toString());
		roleLinkEntity.setRoleId(Objects.isNull(roleLinkMapper.get(ROLE_ID))?StringUtils.EMPTY:roleLinkMapper.get(ROLE_ID).toString());
		return roleLinkEntity;
	}

	/**
	 * mapValues convert entity into Map.
	 *
	 * @param roleLinkEntity has an role link info as entity
	 * @return role link info as map
	 */
	public static Map<String, Object> mapValues(RoleLinkEntity roleLinkEntity) {
		Map<String, Object> roleLinkMapper = new HashMap<>();
		roleLinkMapper.put(USERID_CONST, roleLinkEntity.getUserId());
		roleLinkMapper.put(ROLE_ID,roleLinkEntity.getRoleId());
		return roleLinkMapper;
	}

	/**
	 * mapValues convert map into entity for the DUMMY_ROLE.
	 *
	 * @param roleLinkMapper has an role link info as map
	 * @return RoleLinkEntity
	 */
	public RoleLinkEntity getDummyRoleLinkEntity(Map<String, Object> roleLinkMapper) {
		RoleLinkEntity roleLinkEntity=new RoleLinkEntity();
		roleLinkEntity.setUserId(Objects.isNull(roleLinkMapper.get("user_id"))?StringUtils.EMPTY:roleLinkMapper.get("user_id").toString());
		roleLinkEntity.setRoleId(Objects.isNull(roleLinkMapper.get("default_role_name"))?StringUtils.EMPTY:roleLinkMapper.get("default_role_name").toString());
		return roleLinkEntity;
	}
}
