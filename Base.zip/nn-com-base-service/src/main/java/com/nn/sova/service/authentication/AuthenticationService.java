package com.nn.sova.service.authentication;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationManager;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenEnhancerChain;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import com.nn.sova.service.authorization.AuthRequestEntity;
import com.nn.sova.service.authorization.AuthResultEntity;
import com.nn.sova.service.authorization.utils.AuthorizationServerConfiguration;
import com.nn.sova.utility.api.WebServiceUtils;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class AuthenticationService.
 */
public class AuthenticationService implements AuthenticationServiceInterface{

	private static JedisConnectionFactory redisConnectionInstance = null;

	/** The Constant AUTHENTICATION_FAILED. */
	private static final String AUTHENTICATION_FAILED = "Authentication Failed";

	/** The Constant INVALID_TOKEN. */
	private static final String INVALID_TOKEN = "Invalid Token";

	private static AuthenticationService instance = null;
	
	private static TokenStore tokenStore = null;
	
	private static ApplicationLogger logger = ApplicationLogger.create(AuthenticationService.class);
			

	/**
	 * Gets the single instance of AuthenticationService.
	 *
	 * @return single instance of AuthenticationService
	 */
	public static AuthenticationService getInstance() {
		if(instance == null) {
			instance = new AuthenticationService();
		}
		return instance;
	}

	/**
	 * Token authentication.
	 *
	 * @param authRequestEntity the sova request
	 * @return the auth result entity
	 */
	@Override
	public AuthResultEntity tokenAuthentication(AuthRequestEntity authRequestEntity,String issuer,String clientId) {
		AuthResultEntity authResultEntity = new AuthResultEntity();
		String token = CommonUtils.getInstance().getHeaderValue(authRequestEntity);
		if (StringUtils.isBlank(token)) {
			logger.error("Authorization token is empty");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(INVALID_TOKEN);
			authResultEntity.setReason(INVALID_TOKEN);
			authResultEntity.setAuthentication(null);
			return authResultEntity;
		}

		Authentication authentication = oauthAuthenticate(token,authRequestEntity,authResultEntity);

		if (Objects.isNull(authentication) || !authentication.isAuthenticated()) {
			logger.error("Authentication is null or false");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(AUTHENTICATION_FAILED);
			authResultEntity.setAuthentication(null);
			return authResultEntity;
		}else {
			logger.info("Authentication is success");
			authResultEntity.setPricipalId(authentication.getName());
			authResultEntity.setStatusCode(200);
			authResultEntity.setAuthentication(authentication);
			return authResultEntity;
		}
	}



	/**
	 * Oauth authenticate.
	 *
	 * @param token the token
	 * @param authResultEntity 
	 * @param refreshToken2 
	 * @return the authentication
	 */
	private Authentication oauthAuthenticate(String token, AuthRequestEntity authRequestEntity, AuthResultEntity authResultEntity) {
		try {
			OAuth2AuthenticationManager authManager = new OAuth2AuthenticationManager();
			authManager.setTokenServices(tokenServices());
			PreAuthenticatedAuthenticationToken authentication = new PreAuthenticatedAuthenticationToken(token, "");
			Authentication authResult = authManager.authenticate(authentication);
			return authResult;
		}
		catch(InvalidTokenException invalidTokenException) {
			logger.error(invalidTokenException);
			logger.info("refresh token starts");
			Map<String, String> headers = authRequestEntity.getHeaders();
			String refreshToken = String.valueOf(headers.get("refresh_token"));
			if(Objects.isNull(refreshToken) || refreshToken.equals("null") || refreshToken.equals("Null")) {
				return null;
			}
			TokenStore redisTokenStore = AuthorizationServerConfiguration.getInstance().tokenStore();
			OAuth2RefreshToken refreshTokenData = redisTokenStore.readRefreshToken(refreshToken);
			OAuth2Authentication refreshAuthentication = redisTokenStore.readAuthenticationForRefreshToken(refreshTokenData);
			if(refreshAuthentication.isAuthenticated()) {
				
				String authRequstUrl = "/auth/authentication/validateRefreshToken";
				Map<String,Object> refreshTokenMap = new HashMap<>();
				refreshTokenMap.put("refresh_token", refreshToken);
				WebServiceUtils webServiceUtils = WebServiceUtils.getInstance();
				Map<String, Object> refreshTokenDataMap = (Map<String, Object>) webServiceUtils.callAuth(
						authRequstUrl, HttpMethod.POST, Object.class, refreshTokenMap,
						MediaType.APPLICATION_JSON);
				
				logger.info("refreshTokenMap passed");
				
				if(MapUtils.isNotEmpty(refreshTokenDataMap)) {
					Map<String,String> headerMap = new HashMap<String, String>();
					headerMap.put("Authorization", "Bearer "+refreshTokenDataMap.get("userToken"));
					authRequestEntity.getHeaders().putAll(headerMap);
					authResultEntity.setRefreshTokenFlag(true);
					return refreshAuthentication;
				}
			}
		}
		catch(Exception exception) {
			logger.error(exception);
		}
		return null;
	}

	/**
	 * Token services.
	 *
	 * @return the resource server token services
	 */
	public ResourceServerTokenServices tokenServices() {
		DefaultTokenServices tokenServices = new DefaultTokenServices();
		tokenServices.setTokenEnhancer(jwtAccessTokenConverter());
		TokenEnhancerChain tokenEnhancerChains = new TokenEnhancerChain();
		tokenEnhancerChains.setTokenEnhancers(Arrays.asList(jwtAccessTokenConverter()));
		tokenServices.setTokenEnhancer(tokenEnhancerChains);
		tokenServices.setTokenStore(redisTokenStore(connectionFactoryBean()));
		return tokenServices;
	}

	/**
	 * Redis token store.
	 *
	 * @param connectionFactory the connection factory
	 * @return the token store
	 */
	public static TokenStore redisTokenStore(RedisConnectionFactory connectionFactory) {
		if(tokenStore == null) {
			tokenStore = new RedisTokenStore(connectionFactory); 
		}
		return tokenStore;
	}

	/**
	 * Connection factory bean.
	 *
	 * @return the redis connection factory
	 */
	public static JedisConnectionFactory connectionFactoryBean() {
		if(redisConnectionInstance == null) {
			String isClusterModeEnabled = EnvironmentReader.isClusterModeEnabled();
			JedisClientConfiguration.JedisClientConfigurationBuilder jedisClientConfiguration = JedisClientConfiguration
					.builder();
			jedisClientConfiguration.usePooling();
			if (Objects.nonNull(isClusterModeEnabled) && !isClusterModeEnabled.isEmpty()
					&& isClusterModeEnabled.equalsIgnoreCase("true")) {
				List<String> clusterNodes = Arrays
						.asList(EnvironmentReader.getRedisURL() + ":" + EnvironmentReader.getRedisPort());
				JedisConnectionFactory connection = new JedisConnectionFactory(new RedisClusterConfiguration(clusterNodes));
				connection.afterPropertiesSet();
				redisConnectionInstance = connection;
			} else {
				RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
				redisStandaloneConfiguration.setHostName(EnvironmentReader.getRedisURL());
				redisStandaloneConfiguration.setPort(Integer.parseInt(EnvironmentReader.getRedisPort()));
				JedisConnectionFactory connection = new JedisConnectionFactory(redisStandaloneConfiguration, jedisClientConfiguration.build());
				connection.afterPropertiesSet();
				redisConnectionInstance = connection;
			}
		}
		return redisConnectionInstance;
	}

	/**
	 * Jwt access token converter.
	 *
	 * @return the jwt access token converter
	 */
	public JwtAccessTokenConverter jwtAccessTokenConverter() {
		JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
		converter.setSigningKey("sova");
		converter.setVerifierKey("sova");
		return converter;
	}



}
