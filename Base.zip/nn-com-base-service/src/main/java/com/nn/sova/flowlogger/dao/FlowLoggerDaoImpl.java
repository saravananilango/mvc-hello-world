package com.nn.sova.flowlogger.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.nn.sova.exception.QueryException;
import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.common.SortType;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.utils.DBUtility;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class FlowLogServiceImpl.
 */
public class FlowLoggerDaoImpl implements FlowLoggerDao {

    private static final String SCREEN_ID = "screen_id";

    private static final String SCREEN_DEFINITION_ID = "screenDefinitionId";

    private static final String LOG_GROUP_NAME = "logGroupName";
    
    public static final String FLOW_LOG_TABLE = "appgen_flow_logs";

    private static ApplicationLogger logger = ApplicationLogger.create(FlowLoggerDaoImpl.class);

    /**
     * Gets the log group name.
     *
     * @param paramMap the param map
     * @return the log group name
     */
    @Override
    public String getLogGroupName(Map<String, Object> paramMap) {
        String programId = Objects.toString(paramMap.get("programId"));
        try {
            List<Map<String, Object>> logGroup = new QueryBuilder().select()
                    .getWithAliasName("lambdaTable.log_group_name", LOG_GROUP_NAME)
                    .from("lambda_function_details", "lambdaTable")
                    .join("program_detail", "programDetail",
                            ConditionBuilder.instance().eq("programDetail.program_id", programId).and()
                                    .eq("programDetail.program_name", "lambdaTable.function_name", true))
                    .orderBy("lambdaTable.updated_at", SortType.DESC).build(true).execute();
            if (CollectionUtils.isNotEmpty(logGroup) && StringUtils
                    .isNotEmpty(Objects.toString(logGroup.get(0).get(LOG_GROUP_NAME), StringUtils.EMPTY))) {
                return Objects.toString(logGroup.get(0).get(LOG_GROUP_NAME));
            }
        } catch (Exception e) {
            logger.error("Lambda Function Detail Error: " + e);
        }
        return StringUtils.EMPTY;
    }

    /**
     * Gets the program id.
     *
     * @param paramMap the param map
     * @return the program id
     */
    @Override
    public String getProgramId(Map<String, Object> paramMap) {
        QueryBuilder builder = new QueryBuilder();
        List<Map<String, Object>> resultData = new ArrayList<>();
        try {
            ConditionBuilder conditionBuilder = ConditionBuilder.instance();
            String screenDefinitionIdString = "screen_definition_id";
            if (StringUtils.isNotEmpty(Objects.toString(paramMap.get(SCREEN_DEFINITION_ID), StringUtils.EMPTY))) {
                conditionBuilder.eq(screenDefinitionIdString, paramMap.get(SCREEN_DEFINITION_ID));
            } else {
                Map<String, Object> applicationLogData = this.getProcessId(paramMap);
                if (StringUtils
                        .isEmpty(Objects.toString(applicationLogData.getOrDefault(SCREEN_ID, StringUtils.EMPTY)))) {
                    return StringUtils.EMPTY;
                }
                if (StringUtils.isNotEmpty(Objects.toString(applicationLogData.get(SCREEN_ID), StringUtils.EMPTY))) {
                    conditionBuilder.eq(screenDefinitionIdString, applicationLogData.get(SCREEN_ID));
                    paramMap.put("isFromScreen", true);
                    String processIdString = "processId";
                    paramMap.put(processIdString,
                            Objects.toString(
                                    paramMap.getOrDefault(processIdString, applicationLogData.get(processIdString)),
                                    StringUtils.EMPTY));
                    paramMap.put("startTime", applicationLogData.get("access_in"));
                    paramMap.put("endTime", applicationLogData.get("access_out"));
                }
            }
            resultData = builder.select().checkIndependentTenant(true).from("program_logic_detail")
                    .where(conditionBuilder).build(true).execute();
            if (CollectionUtils.isNotEmpty(resultData)) {
                return Objects.toString(resultData.get(0).get("program_id"), StringUtils.EMPTY);
            }
            return StringUtils.EMPTY;
        } catch (QueryException e) {
            logger.error("Program Detail Error: " + e);
            return StringUtils.EMPTY;
        }
    }

    /**
     * Gets the process id.
     *
     * @param paramMap the param map
     * @return the process id
     */
    public Map<String, Object> getProcessId(Map<String, Object> paramMap) {
        SelectQueryBuilder selectQuery = new QueryBuilder().select();
        ConditionBuilder conditionBuilder = ConditionBuilder.instance();
        if (StringUtils.isNotEmpty(Objects.toString(paramMap.get(SCREEN_DEFINITION_ID), StringUtils.EMPTY))) {
            conditionBuilder.eq("screen_definition_id", paramMap.get(SCREEN_DEFINITION_ID));
        } else {
            conditionBuilder.eq("user_id", ContextBean.getUserId());
        }
        try {
            String accessInString = "access_in";
            List<Map<String, Object>> resultList = selectQuery.from("application_log_statistics")
                    .get("process_id", accessInString, "access_out", SCREEN_ID).where(conditionBuilder)
                    .orderBy(accessInString, SortType.DESC).build(false).limit(1).execute();
            if (!resultList.isEmpty()) {
                return resultList.get(0);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return new HashMap<>();
    }
    
    
    /**
	 * GetFlowLog details from the table
	 */
	@Override
	public List<Map<String, Object>> getFlowLogs(Map<String, String> paramMap, boolean isLogScreen) {
		return getFlowLogs(DBUtility.buildConditionEqWithAnd(paramMap),isLogScreen);
	}

	@Override
	public List<Map<String, Object>> getFlowLogs(ConditionBuilder condition, boolean isLogScreen) {
		try {
			SelectQueryBuilder toRun = null;
			SelectQueryBuilder selector = new QueryBuilder().btSchema().select();
			if(isLogScreen) {
				selector.distinctOn(Arrays.asList("component_id","request_id","component_event_type"));
			}
			selector.checkIndependentTenant(true)
					.from(FLOW_LOG_TABLE)
					.where(condition);
			
			if(isLogScreen) {
				selector.orderBy(Arrays.asList("component_id","request_id","component_event_type"));
				SelectQueryBuilder wrapper = new QueryBuilder().btSchema().select().from(selector.build(false), "test").orderBy("created_at", SortType.ASC);
				toRun = wrapper.build(isLogScreen);
			}
			else {				
				selector.build(false);
				toRun = selector;
			}
			return toRun.execute();
		} catch (QueryException e) {
			logger.error("Error while Fetching request ID", e);
			return null;
		}
	}
}
