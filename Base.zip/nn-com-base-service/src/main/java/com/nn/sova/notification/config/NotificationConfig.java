package com.nn.sova.notification.config;

import com.nn.sova.notification.dao.NotificationDao;
import com.nn.sova.notification.dao.NotificationDaoImpl;
import com.nn.sova.notification.factory.mail.NtsEmailGatewayFactory;
import com.nn.sova.notification.factory.sms.NtsSmsGatewayFactory;
import com.nn.sova.notification.gateway.mail.NtsEmailGatewayService;
import com.nn.sova.notification.gateway.sms.NtsSmsGatewayService;
import com.nn.sova.notification.queue.service.NotificationQueingFactory;
import com.nn.sova.notification.service.NotificationGatewayService;
import com.nn.sova.notification.service.NotificationGatewayServiceImpl;
import com.nn.sova.notification.service.NotificationService;
import com.nn.sova.notification.service.NotificationServiceImpl;
import com.nn.sova.notification.service.NtsHandlerFactoryService;
import com.nn.sova.notification.service.NtsHandlerFactoryServiceImpl;

/**
 * NotificationConfig creates and maintain the singleton instance.
 * @author saravana
 *
 */
public class NotificationConfig {
	
	/**
	 * Instantiates a new Notification Config.
	 */
	private NotificationConfig() {
		// use static methods only
	}
	
	private static class NotficationQueueServiceFactory {
		
		 private NotficationQueueServiceFactory() {}
		 private static final NotificationQueingFactory NOTIFICATION_QUEUE_FACTORY = new NotificationQueingFactory();
	}
	
	/**
	 * A factory for creating various GatewayService objects.
	 */
	private static class NtsGatewayServiceFactory {

		/**
		 * Instantiates a new job manager dao factory.
		 */
		private NtsGatewayServiceFactory() {

		}

		private static final NtsEmailGatewayService NTS_EMAIL_GATEWAY_SERVICE = new NtsEmailGatewayFactory();
		private static final NtsSmsGatewayService NTS_SMS_GATEWAY_SERVICE = new NtsSmsGatewayFactory();

	}
	
	/**
	 * A factory for creating NotificationDao objects.
	 */
	private static class NotificationDaoFactory {

		/**
		 * Instantiates a new notification Dao factory.
		 */
		private NotificationDaoFactory() {

		}

		private static final NotificationDao NOTIFICATION_DAO = new NotificationDaoImpl();

	}
	
	/**
	 * A factory for creating various GatewayService objects.
	 */
	private static class ServiceLayerFactory {

		/**
		 * Instantiates a new service layer factory.
		 */
		private ServiceLayerFactory() {

		}

		private static final NtsHandlerFactoryService NTS_HANDLER_FACTORY_SERVICE = new NtsHandlerFactoryServiceImpl();
		private static final NotificationGatewayService NOTIFICATION_GATEWAY_SERVICE = new NotificationGatewayServiceImpl();
		private static final NotificationService NOTIFICATION_SERVICE = new NotificationServiceImpl();

	}
	
	public static NtsEmailGatewayService getEmailGatewayService() {
		return NtsGatewayServiceFactory.NTS_EMAIL_GATEWAY_SERVICE;
	}

	public static NtsSmsGatewayService getSmsGatewayService() {
		return NtsGatewayServiceFactory.NTS_SMS_GATEWAY_SERVICE;
	}

	public static NotificationDao getNotificationDao() {
		return NotificationDaoFactory.NOTIFICATION_DAO;
	}


	public static NtsHandlerFactoryService getNtsHandlerFactoryService() {
		return ServiceLayerFactory.NTS_HANDLER_FACTORY_SERVICE;
	}

	public static NotificationGatewayService getNtsGatewayService() {
		return ServiceLayerFactory.NOTIFICATION_GATEWAY_SERVICE;
	}


	public static NotificationService getNotificationService() {
		return ServiceLayerFactory.NOTIFICATION_SERVICE;
	}
	
	public static NotificationQueingFactory getNotificationQueingFactory() {
		return NotficationQueueServiceFactory.NOTIFICATION_QUEUE_FACTORY;
	}

}
