package com.nn.sova.notification.gateway.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.nn.sova.nts.vo.NotificationException;
import com.nn.sova.nts.vo.NotificationResponse;

public interface NtsGatewayService {

	/**
	 *
	 * @param ntsData
	 * @param handlerData
	 */
	NotificationResponse send(Map<String, Object> ntsData, Map<String, Object> handlerData);

	/**
	 * Validate the user data .
	 * @param ntsData
	 * @throws NotificationException
	 */
	void validateUserData(Map<String, Object> ntsData) throws NotificationException;
	
	/**
	 * Retunrs the handler keys mentioned in each service.
	 * @return
	 */
	List<String> getHandlerKeys();
	
	/**
	 * Validate the handler keys.
	 * @param handlerKeysMap
	 * @param handlerKeys
	 * @throws NotificationException
	 */
	default void validateHandlerData(Map<String, Object> handlerKeysMap, List<String> handlerKeys) throws NotificationException {
		List<String> missedKeys = new ArrayList<>();
		if(Objects.nonNull(handlerKeysMap)) {
			for(String key: handlerKeys) {
				if(!(handlerKeysMap.containsKey(key) && Objects.nonNull(handlerKeysMap.get(key)))) {
					missedKeys.add(key);
				}
			}
			if(!missedKeys.isEmpty()) {
				throw new NotificationException("Handler Key value not found in NtsHandlerDef for keys - "+ String.join(",", missedKeys));
			}
		} else {
			throw new NotificationException("No Handler Key value found in NtsHandlerDef table");
		}
	}
	
}
