package com.nn.sova.notification.service;

import java.util.Map;

import com.nn.sova.nts.vo.NotificationException;

public interface NotificationGatewayService {
    /**
     * 
     * @param notificationRequestData
     * @param gatewayType
     * @return
     * @throws NotificationException 
     */
	Map<String, Object> getHandlerConfig(Map<String, Object> notificationRequestData, String gatewayType) throws NotificationException;

	/**
	 * get the default text template based on alertId.
	 * 
	 * @param requestData
	 * @throws NotificationException 
	 */
	boolean getNotificationTemplateByAlertId(Map<String, Object> notificationRequestData) throws NotificationException;

}
