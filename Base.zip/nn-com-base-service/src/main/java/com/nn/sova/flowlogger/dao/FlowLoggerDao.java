package com.nn.sova.flowlogger.dao;

import java.util.List;
import java.util.Map;

import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * The Interface FlowLogService.
 */
public interface FlowLoggerDao {

    /**
     * Gets the log group name.
     *
     * @param paramMap the param map
     * @return the log group name
     */
    public String getLogGroupName(Map<String, Object> paramMap);

    /**
     * Gets the program id.
     *
     * @param paramMap the param map
     * @return the program id
     */
    public String getProgramId(Map<String, Object> paramMap);
    
    /**
     * GetFlowLogs from DB
     * @param paramMap
     * @return List of FlowLogs
     */
    public List<Map<String,Object>> getFlowLogs(Map<String,String> paramMap, boolean isLogScreen);
    
    /**
     * Gets the flowLog data
     * @param paramMap
     * @return the flow log data list
     */
    public List<Map<String,Object>> getFlowLogs(ConditionBuilder condition, boolean isLogScreen);
}
