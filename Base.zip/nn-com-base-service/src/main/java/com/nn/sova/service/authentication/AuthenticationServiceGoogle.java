package com.nn.sova.service.authentication;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.nn.sova.service.authorization.AuthRequestEntity;
import com.nn.sova.service.authorization.AuthResultEntity;
import com.nn.sova.utility.api.WebServiceUtils;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class AuthenticationServiceGoogle.
 * 
 * @author vellaichamy 
 */
public class AuthenticationServiceGoogle implements AuthenticationServiceInterface{

	/** The Constant AUTHENTICATION_FAILED. */
	private static final String AUTHENTICATION_FAILED = "Authentication Failed";

	/** The Constant INVALID_TOKEN. */
	private static final String INVALID_TOKEN = "Invalid Token";

	/** The instance. */
	private static AuthenticationServiceGoogle instance = null;

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(AuthenticationServiceGoogle.class);

	/**
	 * Gets the single instance of AuthenticationServiceGoogle.
	 *
	 * @return single instance of AuthenticationServiceGoogle
	 */
	public static AuthenticationServiceGoogle getInstance() {
		if(instance == null) {
			instance = new AuthenticationServiceGoogle();
		}
		return instance;
	}


	/**
	 * Token authentication.
	 *
	 * @param authRequestEntity the auth request entity
	 * @param issuer the issuer
	 * @param clientId the client id
	 * @return the auth result entity
	 * @throws GeneralSecurityException the general security exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public AuthResultEntity tokenAuthentication(AuthRequestEntity authRequestEntity,String issuer,String clientId) throws GeneralSecurityException, IOException {
		AuthResultEntity authResultEntity = new AuthResultEntity();
		String token = CommonUtils.getInstance().getHeaderValue(authRequestEntity);
		Map<String, String> headers = authRequestEntity.getHeaders();
		String refreshToken = String.valueOf(headers.get("refresh_token"));
		if (StringUtils.isBlank(token)) {
			logger.error("token auth is empty google");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(INVALID_TOKEN);
			authResultEntity.setReason(INVALID_TOKEN);
			return authResultEntity;
		}

		String userId = googleVerifyToken(token,refreshToken,clientId,authResultEntity,authRequestEntity);

		if (Objects.isNull(userId) || StringUtils.isBlank(userId)) {
			logger.error("Google idtoken empty , reason : issuer,client id or token expired");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(AUTHENTICATION_FAILED);
			return authResultEntity;
		}else {
			logger.info("Google idtoken has data :" + userId);
			authResultEntity.setPricipalId(userId);
			authResultEntity.setStatusCode(200);
			Set<GrantedAuthority> mappedAuthorities = new HashSet<>();
			String roleName = "ROLE_USER";
			mappedAuthorities.add(new SimpleGrantedAuthority(roleName));
			Map<String,String> requestParameters = new HashMap<>();
			requestParameters.put("grant_type", "authorization_code");
			OAuth2Request oauth2Request = new OAuth2Request(requestParameters, clientId,
					mappedAuthorities, true, null,
					null,  null, null,
					null);
			Authentication auth = new PreAuthenticatedAuthenticationToken(authResultEntity.getPricipalId(),
					authResultEntity.getPricipalId(),mappedAuthorities);
			Authentication authenticationData = new OAuth2Authentication(oauth2Request,auth);
			authenticationData.setAuthenticated(true);
			authResultEntity.setAuthentication(authenticationData);
			return authResultEntity;
		}
	}

	/**
	 * Google verify token.
	 *
	 * @param userToken the user token
	 * @param refreshToken the refresh token
	 * @param clientId the client id
	 * @param authResultEntity 
	 * @param authRequestEntity 
	 * @return the google id token
	 * @throws GeneralSecurityException the general security exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private String googleVerifyToken(String userToken, String refreshToken,String clientId, 
			AuthResultEntity authResultEntity, AuthRequestEntity authRequestEntity) throws GeneralSecurityException, IOException {
		try {
			GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(),
					GsonFactory.getDefaultInstance())
					// Specify the CLIENT_ID of the app that accesses the backend:
					.setAudience(Collections.singletonList(clientId))
					.setIssuer("https://accounts.google.com")
					// Or, if multiple clients access the backend:
					//.setAudience(Arrays.asList(CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3))
					.build();
			// (Receive idTokenString by HTTPS POST)
			GoogleIdToken googleIdToken =  verifier.verify(userToken);

			if(Objects.isNull(googleIdToken)) {

				logger.info("google refresh token starts");
				if(Objects.isNull(refreshToken) || refreshToken.equals("null") || refreshToken.equals("Null")) {
					return null;
				}
					String authRequstUrl = "/auth/authentication/validateRefreshTokenOIDC";
					Map<String,Object> refreshTokenMap = new HashMap<>();
					refreshTokenMap.put("refresh_token", refreshToken);
					refreshTokenMap.put("issuer", "google");
					WebServiceUtils webServiceUtils = WebServiceUtils.getInstance();
					Map<String, Object> refreshTokenDataMap = (Map<String, Object>) webServiceUtils.callAuth(
							authRequstUrl, HttpMethod.POST, Object.class, refreshTokenMap,
							MediaType.APPLICATION_JSON);

					logger.info("refreshTokenMap passed");
					logger.info("google refreshTokenMap for google");
					
					if(MapUtils.isNotEmpty(refreshTokenDataMap)) {
						logger.info("google refreshTokenMap for google is success");
						Map<String,String> headerMap = new HashMap<>();
						Map<String,Object> sessionInfoMap = (Map<String, Object>) refreshTokenDataMap.get("sessionInfo");
						headerMap.put("Authorization", "Bearer "+sessionInfoMap.get("userToken"));
						authRequestEntity.getHeaders().putAll(headerMap);
						authResultEntity.setRefreshTokenFlag(true);
						String emailIdFromAuth =  String.valueOf(refreshTokenDataMap.get("googleIdToken"));
						return emailIdFromAuth;
					}
			}else {
				logger.info("Google verify success , user id :" + googleIdToken.getPayload().getEmail());
				return googleIdToken.getPayload().getEmail();
			}
		}catch(Exception exception) {
			logger.error("error in googleVerifyToken");
			logger.error(exception);
			logger.error(exception.getMessage());
			return null;
		}
		return null;
	}
}


