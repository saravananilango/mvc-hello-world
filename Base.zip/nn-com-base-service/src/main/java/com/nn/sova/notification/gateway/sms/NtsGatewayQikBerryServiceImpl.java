package com.nn.sova.notification.gateway.sms;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.HttpClientBuilder;

import com.nn.sova.notification.constants.NotificationConstants;
import com.nn.sova.notification.gateway.service.NtsGatewayService;
import com.nn.sova.nts.vo.NotificationException;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.nts.vo.NotificationStatus;
import com.nn.sova.utility.logger.ApplicationLogger;


public class NtsGatewayQikBerryServiceImpl implements NtsGatewayService {

	private static final ApplicationLogger logger = ApplicationLogger.create(NtsGatewayQikBerryServiceImpl.class);

	private static final String QIKBERRY_GATEWAY_URL = "https://alerts.qikberry.com/api/v2/sms/send?";

	private static final List<String> HANDLER_KEYS = Arrays.asList("access_token", "sender_name", "service_type");
	/**
	 * Used to maintain singleton instance.
	 */
	private static NtsGatewayQikBerryServiceImpl instance = null;
	

	/**
	 * Instantiates NtsGatewayQikBerryServiceImpl.
	 */
	private NtsGatewayQikBerryServiceImpl() {

	}
	
	/**
	 * Gets instance of NtsGatewayQikBerryServiceImpl class.
	 *
	 * @return the instance
	 */
	public static NtsGatewayQikBerryServiceImpl getInstance() {
		if (instance == null) {
			instance = new NtsGatewayQikBerryServiceImpl();
		}
		return instance;
	}
	
	/**
	 * Returns the handler keys for FCM gateway.
	 */
	@Override
	public List<String> getHandlerKeys() {
		return HANDLER_KEYS;
	}

	
	/**
	 * send SMS to specified mobile number.
	 * 
	 * @param phoneNumber
	 * @param text
	 */
	public NotificationResponse send(Map<String, Object> ntsData, Map<String, Object> handlerData) {
		HttpClient httpClient = HttpClientBuilder.create().build();
		String notificationId = ntsData.get("notificationId").toString();
		try {
			Map<String, Object> handlerkeys = (Map<String, Object>) handlerData.get("handlerKeys");
			String smsMessage = ntsData.containsKey("message") ? ntsData.get("message").toString()
					: ntsData.get("default_template_text").toString();
			String apiKey = "access_token=" + URLEncoder.encode((String) handlerkeys.get("access_token"), "UTF-8");
			String targetNumber = "&to=" + URLEncoder.encode((String) ntsData.get("phone_number"), "UTF-8");
			String message = "&message=" + URLEncoder.encode(smsMessage, "UTF-8");
			String sender = "&sender=" + URLEncoder.encode((String) handlerkeys.get("sender_name"), "UTF-8");
			String service = "&service=" + URLEncoder.encode((String) handlerkeys.get("service_type"), "UTF-8");

			String apiUrl = QIKBERRY_GATEWAY_URL + apiKey + targetNumber + message + sender + service;
			HttpGet getRequest = new HttpGet(apiUrl);
			getRequest.addHeader(NotificationConstants.HTTP_HEADER_NAME,
					NotificationConstants.HTTP_HEADER_APPLICATION_JSON);
			HttpResponse response = null;
			logger.info("Sending sms to - {}", targetNumber);
			response = httpClient.execute(getRequest);
			HttpEntity entity = response.getEntity();
			int reponseCode = response.getStatusLine().getStatusCode();
			logger.info("Request: apiUrl --->" + apiUrl + " reponseCode: " + reponseCode);
			if (reponseCode == 404 || reponseCode == 401) {
				logger.error((NotificationConstants.FAILED_CODE_MESSAGE + response.getStatusLine().getStatusCode()));
				return NotificationResponse.of(notificationId, NotificationStatus.FAILED, String.valueOf(reponseCode));
			} else if (!((reponseCode >= 200) && (reponseCode <= 299))) {
				logger.error((NotificationConstants.FAILED_CODE_MESSAGE + response.getStatusLine().getStatusCode()));
				return NotificationResponse.of(notificationId, NotificationStatus.FAILED, String.valueOf(reponseCode));
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line;
			String sResult = "";
			while ((line = reader.readLine()) != null) {
				sResult = sResult + line + " ";
			}
			logger.info("successfully sms sent to - {}", targetNumber);
			reader.close();
			return NotificationResponse.of(notificationId, NotificationStatus.COMPLETED, "");
		} catch (Exception e) {
			logger.error("Failed Sending sms to - {}, error message {}", ntsData.get("phone_number").toString(),
					e.toString());
			return NotificationResponse.of(notificationId, NotificationStatus.FAILED, e.toString());
		} finally {
			HttpClientUtils.closeQuietly(httpClient);
		}
	}

	/**
	 * Validate the receiver data .
	 * Mobile Number and message.
	 * @throws NotificationException 
	 */
	@Override
	public void validateUserData(Map<String, Object> ntsData) throws NotificationException {
		String targetPhoneNumber = ntsData.containsKey("phone_number") ? ntsData.get("phone_number").toString() : StringUtils.EMPTY;
		String message = ntsData.containsKey("message") ? ntsData.get("message").toString()
				: ntsData.containsKey("default_template_text") ? ntsData.get("default_template_text").toString() : StringUtils.EMPTY;
		if(StringUtils.isEmpty(targetPhoneNumber)) {
		    	throw new NotificationException("Mandatory sms parameter - Phone number is empty");
		}
		if(StringUtils.isEmpty(message)) {
		    	throw new NotificationException("Mandatory sms parameter - Message is empty");
		 }		
	}

}
