package com.nn.sova.notification.queue.service;

import javax.jms.Connection;
import javax.jms.JMSException;

import com.amazonaws.services.sqs.model.CreateQueueResult;

public interface NotificationQueueService {
    /**
     * Gets the messaging connection.
     *
     * @return the messaging connection
     * @throws JMSException the JMS exception
     */
    Connection getMessagingConnection() throws JMSException;
    
    /**
     * Creates the queue.
     *
     * @param queueName
     * @return 
     * @throws Exception the exception
     */
    CreateQueueResult createQueue(String queueName) throws Exception;
    
    /**
     * Creates the queue.
     *
     * @param queueName
     * @throws Exception the exception
     */
    boolean publishMessage(String message, String queueName) throws Exception;
}
