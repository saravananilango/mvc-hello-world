package com.nn.sova.notification.queue.service;

/**
 * NotificationQueingFactory holds the various Queing Service instance .
 * Eg: RabbitMq , AWS SNS , GCP.
 * @author saravana
 *
 */
public class NotificationQueingFactory {
	
	private NotificationQueueService notificationQueueService;
	
    public NotificationQueingFactory() {
        try {
        	notificationQueueService = SQSNotificationServiceImpl.getInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public NotificationQueueService getServices(){
        return notificationQueueService;
    }

}
