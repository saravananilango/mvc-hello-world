package com.nn.sova.service.authorization;

import java.sql.Timestamp;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.nn.sova.service.CacheService;
import com.nn.sova.service.authentication.AuthenticationServiceImpl;
import com.nn.sova.service.authentication.AuthenticationServiceInterface;
import com.nn.sova.service.authentication.CommonUtils;
import com.nn.sova.service.authorization.utils.AuthorizationServerConfiguration;
import com.nn.sova.utility.context.ContextBean;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class AuthorizationValidationService.
 */
public class AuthorizationValidationService {

	private static final String AUTHENTICATION_FAILED = "nn_authentication_failed";
	private static final String AUTHORIZATION_FAILED = "nn_authorization_failed";
	private static final String INVALID_TOKEN = "nn_invalid_token";
	private static final String RATE_LIMIT_EXCEEDED = "nn_rate_limit_exceeded";
	private static final String METHOD_SECURITY_FAILED = "nn_method_security_failed";

	/** The logger. */
	private static ApplicationLogger logger = ApplicationLogger.create(AuthorizationValidationService.class);

	/**
	 * Token authentication.
	 *
	 * @param authRequestEntity the sova request
	 * @return the auth result entity
	 */
	public AuthResultEntity authorizeRequest(AuthRequestEntity authRequestEntity) {
		logger.info("authorizeRequest starts");
		AuthResultEntity authResultEntity = new AuthResultEntity();
		String token = getHeaderValue(authRequestEntity);
		Authentication authentication = null;
		logger.info("loadAuthentication starts");
		try {
			Map<String,Object> claimData = CommonUtils.getInstance().parseAccessToken(token);
			String issuer = String.valueOf(claimData.get("iss"));
			logger.info("token issuer :" + issuer);
			String clientId = String.valueOf(claimData.get("aud"));
			logger.info("token clientId :" + clientId);
			// Added for OIDC
			AuthenticationServiceInterface authenticationService = 
					new AuthenticationServiceImpl().getAuthenticationServiceClass(String.valueOf(claimData.get("iss")));
			authResultEntity = authenticationService.tokenAuthentication(authRequestEntity, issuer, clientId);
			if(authResultEntity.isRefreshTokenFlag()) {
				token = getHeaderValue(authRequestEntity);
			}
			authentication = authResultEntity.getAuthentication();
			logger.info("Authentication is :" + authentication);
			logger.info("loadAuthentication ends");
		}
		catch (Exception exception) {
			logger.error(exception);
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(exception.getMessage());
			return authResultEntity;
		}
		if((Objects.isNull(authentication)) || (!authentication.isAuthenticated()))  {
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_authentication_failed"));
			return authResultEntity;
		}

		Map<String, Object> userTokenCacheData = (Map<String, Object>) CacheService.getInstance()
				.getCacheData(token);

		if(MapUtils.isEmpty(userTokenCacheData)) {
			logger.error("userTokenCacheData empty");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_user_token_not_available"));
			return authResultEntity;
		}

		String userId = String.valueOf(userTokenCacheData.get("userId"));
		String tenantId = String.valueOf(userTokenCacheData.get("tenantId"));

		try {
			Map<String, Object> userDataByCache = CacheService.getInstance().getUserDataByTenantId(userId, tenantId);
			if(Objects.isNull(userDataByCache) || !Boolean.parseBoolean(String.valueOf(userDataByCache.get("status_flag")))) {
				logger.error("User Active Flag False");
				authResultEntity.setStatusCode(401);
				authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
				authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_user_active_flag_failure"));
				return authResultEntity;
			}
		}catch(Exception exception) {
			logger.error("Exception  in User Active Flag check");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_user_active_flag_failure"));
			return authResultEntity;
		}

		ContextBean.setTenantId(Objects.toString(userTokenCacheData.get("tenantId")));
		AuthorizationService authorizationService = new AuthorizationService();
		logger.info("validateUserTenant starts :" + new Timestamp(System.currentTimeMillis()));
		boolean tenantValidationStatus = authorizationService.validateUserTenant(userTokenCacheData, authRequestEntity);
		if(!tenantValidationStatus) {
			logger.error("Tenant Validation Failed");
			authResultEntity.setStatusCode(401);
			authResultEntity.setResponseMsg(AUTHENTICATION_FAILED);
			authResultEntity.setReason(MessageImplementation.getInstance().getMessageData("nn_tenant_validation_failed"));
			return authResultEntity;
		}

		boolean authorizationStatus  = validateRequest(authRequestEntity,authentication,authResultEntity,userTokenCacheData);
		if (!authorizationStatus) {
			logger.error("Validate Request Failed");
			authResultEntity.setStatusCode(403);
			authResultEntity.setResponseMsg(AUTHORIZATION_FAILED);
			return authResultEntity;
		}

		logger.info("validateRateLimit starts");
		boolean rateLimitStatus = validateRateLimit(authRequestEntity, authentication,authResultEntity);
		if(!rateLimitStatus) {
			logger.error("Rate Limit Validation Failed");
			if(authResultEntity.getStatusCode() == 403) {
				authResultEntity.setStatusCode(403);
				authResultEntity.setResponseMsg(AUTHORIZATION_FAILED);
				return authResultEntity;
			}else {
				logger.error("Rate Limit Exceeded");
				authResultEntity.setStatusCode(429);
				authResultEntity.setResponseMsg(RATE_LIMIT_EXCEEDED);
				return authResultEntity;
			}
		}

		logger.info("validateMethodSecurity starts");
		boolean methodSecurityStatus = validateMethodSecurity(userTokenCacheData,authRequestEntity, authentication,authResultEntity);
		if(!methodSecurityStatus) {
			logger.error("Method Security Failed");
			authResultEntity.setStatusCode(403);
			authResultEntity.setResponseMsg(METHOD_SECURITY_FAILED);
			return authResultEntity;
		}
		authResultEntity.setStatusCode(200);
		logger.info("authorizeRequest total ends");
		return authResultEntity;
	}


	/**
	 * Validate method security.
	 * @param userTokenCacheData 
	 *
	 * @param authRequestEntity the auth request entity
	 * @param authentication the authentication
	 * @param authResultEntity the auth result entity
	 * @return true, if successful
	 */
	private boolean validateMethodSecurity(Map<String, Object> userTokenCacheData, AuthRequestEntity authRequestEntity, Authentication authentication,
			AuthResultEntity authResultEntity) {
		try {
			AuthorizationService authorizationService = new AuthorizationService();
			if(Objects.nonNull(authRequestEntity.getMethodSecurityMethodName())) {
				logger.info("Method Security Method Name Inside");
				MethodSecurityImpl methodSecurityImpl = new MethodSecurityImpl();
				return methodSecurityImpl.hasPrivilege(authentication, authRequestEntity.getMethodSecurityMethodName(), authRequestEntity.getMethodSecurityEntityObj(),authResultEntity,userTokenCacheData);
			}else {
				logger.info("Method Security Method Name Null");
				logger.info("Screen id from request : " + authRequestEntity.getSid());

				OAuth2Authentication auth = (OAuth2Authentication) authentication;
				String grantType = auth.getOAuth2Request().getGrantType();
				if (StringUtils.isNotEmpty(grantType) && grantType.equals("client_credentials")) {
					if(StringUtils.isNotEmpty(authRequestEntity.getSid())){
						if(authorizationService.authorizeRequest(userTokenCacheData, authRequestEntity, authResultEntity)) {
							logger.info("Authorization passed for sid with client credential flow");
							return true;
						}else {
							logger.info("Authorization failed for sid with client credential flow");
							return false;
						}
					}else {
						if(authorizationService.validateAuthorizedUrl(authRequestEntity)) {
							logger.info("Authorization passed for client credential flow without sid");
							return true;
						}else {
							logger.info("Authorization failed for client credential flow without sid");
							return false;
						}
					}
				}else {
					logger.info("Authorization passed for password flow in method security");
					return true;
				}
			}
			}catch(Exception exception) {
				logger.error(exception);
				return false;
			}
		}


		/**
		 * Authorize request.
		 *
		 * @param authRequestEntity the auth request entity
		 * @param authentication the authentication
		 * @param authResultEntity the auth result entity
		 * @param userTokenCacheData the user token cache data
		 * @return true, if successful
		 */
		private boolean validateRequest(AuthRequestEntity authRequestEntity, Authentication authentication, 
				AuthResultEntity authResultEntity, Map<String, Object> userTokenCacheData) {
			try {		
				logger.info("validateRequest starts");
				AuthorizationService authorizationService = new AuthorizationService();
				boolean authorizationStatus = authorizationService.authorizationValidation(authRequestEntity, authentication,authResultEntity,userTokenCacheData);
				if(!authorizationStatus) {
					logger.error("Authorize Request Failed");
					return false;
				}
			}catch (Exception exception) {
				logger.error(exception);
				return false;
			}
			return true;
		}

		/**
		 * Validate rate limit.
		 *
		 * @param authRequestEntity the auth request entity
		 * @param authentication the authentication
		 * @param authResultEntity the auth result entity
		 * @return true, if successful
		 */
		private boolean validateRateLimit(AuthRequestEntity authRequestEntity, Authentication authentication, AuthResultEntity authResultEntity) {

			logger.info("validateRateLimit instance starts");
			RateLimitService rateLimitService = new RateLimitService(AuthorizationServerConfiguration.getInstance().cache());
			boolean rateLimitStatus;
			try {
				rateLimitStatus = rateLimitService.validateRateLimit(authRequestEntity, authentication,authResultEntity);
				logger.info("validateRateLimit inside ends ");
				if (!rateLimitStatus) {
					logger.error("Rate Limit Status Failed");
					return false;
				}else {
					return rateLimitStatus;
				}
			} catch (Exception exception) {
				logger.error(exception);
				return false;
			}
		}

		/**
		 * Gets the header value.
		 *
		 * @param authRequestEntity the sova request
		 * @return the header value
		 */
		public String getHeaderValue(AuthRequestEntity authRequestEntity) {
			Map<String, String> headers = authRequestEntity.getHeaders();
			String value = headers.getOrDefault("Authorization", headers.getOrDefault("authorization", ""));
			if ((value.toLowerCase().startsWith(OAuth2AccessToken.BEARER_TYPE.toLowerCase()))) {
				String authHeaderValue = value.substring(OAuth2AccessToken.BEARER_TYPE.length()).trim();
				int commaIndex = authHeaderValue.indexOf(',');
				if (commaIndex > 0) {
					authHeaderValue = authHeaderValue.substring(0, commaIndex);
				}
				logger.info("Valid Header Token Format");
				return authHeaderValue;
			}
			logger.error("Invalid Header Token Format");
			return null;
		}
	}
