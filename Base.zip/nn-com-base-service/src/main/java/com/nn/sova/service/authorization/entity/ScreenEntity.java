package com.nn.sova.service.authorization.entity;

import lombok.Data;

/**
 * Instantiates a new screen entity.
 * 
 * @author Vellaichamy N
 */
@Data
public class ScreenEntity {
	/** The Screen ID*/
	String screenId;

	/** The Screen Definition ID*/
	String screenDefId;
}
