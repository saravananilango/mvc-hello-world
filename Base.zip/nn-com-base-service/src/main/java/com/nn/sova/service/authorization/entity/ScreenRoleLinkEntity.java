package com.nn.sova.service.authorization.entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import lombok.Data;

/**
 * ScreenRoleLinkEntity defines the screen role data.
 *
 * @author Vellaichamy N
 */

@Data
public class ScreenRoleLinkEntity {

	/** The Constant ROLE_ID. */
	private static final String ROLE_ID = "role_id";

	/** The Constant SCREEN_ID. */
	private static final String SCREEN_ID = "screen_id";

	/**  The screen ID. */
	private String screenId;

	/**  The Role ID. */
	private String roleId;

	/**
	 * mapValues convert map into entity.
	 *
	 * @param screenRoleLinkMapper has an info about screen role link
	 * @return screenRoleLinkEntity has an info about screen role link as entity values
	 */
	public static ScreenRoleLinkEntity mapValues(Map<String, Object> screenRoleLinkMapper) {
		ScreenRoleLinkEntity screenRoleLinkEntity=new ScreenRoleLinkEntity();
		screenRoleLinkEntity.setRoleId(Objects.isNull(screenRoleLinkMapper.get(ROLE_ID))?StringUtils.EMPTY:screenRoleLinkMapper.get(ROLE_ID).toString());
		screenRoleLinkEntity.setScreenId(Objects.isNull(screenRoleLinkMapper.get(SCREEN_ID))?StringUtils.EMPTY:screenRoleLinkMapper.get(SCREEN_ID).toString());
		return screenRoleLinkEntity;
	}

	/**
	 * mapValues convert entity into Map.
	 *
	 * @param screenRoleLinkEntity has an info about screen role link
	 * @return screenRoleLinkMapper has an info about screen role link as map values
	 */
	public static Map<String, Object> mapValues(ScreenRoleLinkEntity screenRoleLinkEntity) {
		Map<String, Object> screenRoleLinkMapper = new HashMap<>();
		screenRoleLinkMapper.put(ROLE_ID, screenRoleLinkEntity.getRoleId());
		screenRoleLinkMapper.put(SCREEN_ID, screenRoleLinkEntity.getScreenId());
		return screenRoleLinkMapper;
	}
}
