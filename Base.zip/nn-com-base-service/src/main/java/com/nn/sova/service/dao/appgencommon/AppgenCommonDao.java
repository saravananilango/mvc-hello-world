package com.nn.sova.service.dao.appgencommon;

import java.util.List;
import java.util.Map;

import com.nn.sova.querybuilder.QueryExecutor;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;

/**
 * AppgenCommonDao interface.
 *
 * @author AUTOMATED FILE
 */
public interface AppgenCommonDao {

    /**
     * deleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList the condition list
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> deleteSelectedDataForPortal(List<ConditionBuilder> conditionList);

    /**
     * insert method is insert data with Map.
     *
     * @param insertMap data to be inserted into the table
     * @param idMap     the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, Map<String, String>... idMap);

    /**
     * update method is to update data with Map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            Map<String, String>... idMap);

    /**
     * update method is to update data with Map.
     *
     * @param updateList       the update list
     * @param conditionBuilder the condition builder
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilder, Map<String, String>... idMap);

    /**
     * insert method is insert data with List.
     *
     * @param insertList data to be inserted into the table
     * @param idMap      the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, Map<String, String>... idMap);

    /**
     * delete method is insert data table.
     *
     * @param ConditionBuilder the condition builder
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> delete(ConditionBuilder ConditionBuilder);

    /**
     * get method is insert data table.
     *
     * @param conditionBuilder the condition builder
     * @return resultMap data to be viewed on detail screen
     */
    public Map<String, Object> get(ConditionBuilder conditionBuilder);

    /**
     * getAll method is insert table.
     *
     * @return resultMap list of data for inbox on initial screen load
     */
    public Map<String, Object> getAll();

    /**
     * getCount is used to get the count.
     *
     * @param conditionBuilder the condition builder
     * @return count of the data in resultMap
     */
    public Map<String, Object> getCount(ConditionBuilder conditionBuilder);

    /**
     * insert method is insert data with Map.
     *
     * @param insertMap     data to be inserted into the table
     * @param queryExecutor the query executor
     * @param idMap         the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, QueryExecutor queryExecutor,
            Map<String, String>... idMap);

    /**
     * insert method is insert with List.
     *
     * @param insertList    data to be inserted into the table
     * @param queryExecutor the query executor
     * @param idMap         the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, QueryExecutor queryExecutor,
            Map<String, String>... idMap);

    /**
     * update method is to update with Map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @param idMap            the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            QueryExecutor queryExecutor, Map<String, String>... idMap);

    /**
     * update method is to update data with Map.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param queryExecutor        the query executor
     * @param idMap                the id map
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, QueryExecutor queryExecutor, Map<String, String>... idMap);

    /**
     * delete method is insert data table.
     *
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> delete(ConditionBuilder conditionBuilder, QueryExecutor queryExecutor);

    /**
     * deleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList the condition list
     * @param queryExecutor the query executor
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> deleteSelectedDataForPortal(List<ConditionBuilder> conditionList,
            QueryExecutor queryExecutor);

    /**
     * get method is insert data in the _appgen_mar table.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return resultMap data to be viewed on detail screen
     */
    public Map<String, Object> get(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap);

    /**
     * upsertWithKeyList method is to update and insert value list.
     *
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param constraintKey     the constraint key
     * @return the map
     */
    public Map<String, Object> upsertWithKeyList(List<Map<String, Object>> valuesList, List<String> updateColumnsList,
            Map<String, String> idMap, String... constraintKey);

    /**
     * upsertWithKeyList method is to do update and insert operation.
     *
     * @param queryExecutor     the query executor
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param constraintKey     the constraint key
     * @return the map
     */
    public Map<String, Object> upsertWithKeyList(QueryExecutor queryExecutor, List<Map<String, Object>> valuesList,
            List<String> updateColumnsList, Map<String, String> idMap, String... constraintKey);

    /**
     * getDistinctCount method is to get count for distinct values.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return the distinct count
     */
    public Map<String, Object> getDistinctCount(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap);

    /**
     * getWithColumns gets the data.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return the with columns
     */
    public Map<String, Object> getWithColumns(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap);

    /**
     * getExpandedGroupData gets the data.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return the expanded group data
     */
    public Map<String, Object> getExpandedGroupData(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap);

    /**
     * softDeleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList  the condition list
     * @param softDeleteFlag the soft delete flag
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> softDeleteSelectedDataForPortal(List<ConditionBuilder> conditionList,
            boolean softDeleteFlag);

    /**
     * softDelete method is insert data in the testsoftdelete table.
     *
     * @param ConditionBuilder the condition builder
     * @param softDeleteFlag   the soft delete flag
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> softDelete(ConditionBuilder ConditionBuilder, boolean softDeleteFlag);

    /**
     * softDeleteSelectedDataForPortal is a method for delete the selected record.
     *
     * @param conditionList  the condition list
     * @param queryExecutor  the query executor
     * @param softDeleteFlag the soft delete flag
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> softDeleteSelectedDataForPortal(List<ConditionBuilder> conditionList,
            QueryExecutor queryExecutor, boolean softDeleteFlag);

    /**
     * softDelete method is delete data in the testsoftdelete table.
     *
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @param softDeleteFlag   the soft delete flag
     * @return resultMap status and error message on failure case
     */
    public Map<String, Object> softDelete(ConditionBuilder conditionBuilder, QueryExecutor queryExecutor,
            boolean softDeleteFlag);

    /**
     * get method is insert data in the _appgen_mar table.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return resultMap data to be viewed on detail screen
     */
    public Map<String, Object> getAll(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap);

    /**
     * getCount is used to get the count.
     *
     * @param conditionBuilder the condition builder
     * @param optionsMap       the options map
     * @return count of the data in resultMap
     */
    public Map<String, Object> getCount(ConditionBuilder conditionBuilder, Map<String, Object> optionsMap);

    /**
     * Upsert with key list.
     *
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param upsertOptionMap   the upsert option map
     * @param constraintKey     the constraint key
     * @return the map
     */
    public Map<String, Object> upsertWithKeyList(List<Map<String, Object>> valuesList, List<String> updateColumnsList,
            Map<String, String> idMap, Map<String, Object> upsertOptionMap, String... constraintKey);

    /**
     * Upsert with key list.
     *
     * @param queryExecutor     the query executor
     * @param valuesList        the values list
     * @param updateColumnsList the update columns list
     * @param idMap             the id map
     * @param upsertOptionMap   the upsert option map
     * @param constraintKey     the constraint key
     * @return the map
     */
    public Map<String, Object> upsertWithKeyList(QueryExecutor queryExecutor, List<Map<String, Object>> valuesList,
            List<String> updateColumnsList, Map<String, String> idMap, Map<String, Object> upsertOptionMap,
            String... constraintKey);

    /**
     * Update with list.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param queryExecutor        the query executor
     * @param updateOptionMap      the update option map
     * @param idMap                the id map
     * @return the map
     */
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, QueryExecutor queryExecutor,
            Map<String, Object> updateOptionMap, Map<String, String>... idMap);

    /**
     * Update with list.
     *
     * @param updateList           the update list
     * @param conditionBuilderList the condition builder list
     * @param updateOptionMap      the update option map
     * @param idMap                the id map
     * @return the map
     */
    public Map<String, Object> updateWithList(List<Map<String, Object>> updateList,
            List<ConditionBuilder> conditionBuilderList, Map<String, Object> updateOptionMap,
            Map<String, String>... idMap);

    /**
     * Update with map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param updateOptionMap  the update option map
     * @param idMap            the id map
     * @return the map
     */
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            Map<String, Object> updateOptionMap, Map<String, String>... idMap);

    /**
     * Update with map.
     *
     * @param updateMap        the update map
     * @param conditionBuilder the condition builder
     * @param queryExecutor    the query executor
     * @param updateOptionMap  the update option map
     * @param idMap            the id map
     * @return the map
     */
    public Map<String, Object> updateWithMap(Map<String, Object> updateMap, ConditionBuilder conditionBuilder,
            QueryExecutor queryExecutor, Map<String, Object> updateOptionMap, Map<String, String>... idMap);

    /**
     * Insert with list.
     *
     * @param insertList      the insert list
     * @param insertOptionMap the insert option map
     * @param idMap           the id map
     * @return the map
     */
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, Map<String, Object> insertOptionMap,
            Map<String, String>... idMap);

    /**
     * Insert with list.
     *
     * @param insertList      the insert list
     * @param queryExecutor   the query executor
     * @param insertOptionMap the insert option map
     * @param idMap           the id map
     * @return the map
     */
    public Map<String, Object> insertWithList(List<Map<String, Object>> insertList, QueryExecutor queryExecutor,
            Map<String, Object> insertOptionMap, Map<String, String>... idMap);

    /**
     * Insert with map.
     *
     * @param insertMap the insert map
     * @param queryExecutor the query executor
     * @param insertOptionMap the insert option map
     * @param idMap the id map
     * @return the map
     */
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, QueryExecutor queryExecutor,
            Map<String, Object> insertOptionMap, Map<String, String>... idMap);

    /**
     * Insert with map.
     *
     * @param insertMap the insert map
     * @param insertOptionMap the insert option map
     * @param idMap the id map
     * @return the map
     */
    public Map<String, Object> insertWithMap(Map<String, Object> insertMap, Map<String, Object> insertOptionMap,
            Map<String, String>... idMap);

}
