package com.nn.sova.service.authorization.entity;

import lombok.Data;

/**
 * The Class UserApiRoleConfigurationEntity.
 * 
 * @author vellaichamy
 * 
 */
@Data
public class UserApiRoleConfigurationEntity {

	/** The tenant id. */
	private String tenantId;
	
	/** The api role name. */
	private String apiRoleName;
	
	/** The product code. */
	private String productCode;
	
	/** The sub product name. */
	private String subProductName;
	
	/** The api entity name. */
	private String apiEntityName;
	
	/** The method url. */
	private String methodUrl;
	
	/** The get method access. */
	private boolean getMethodAccess;
	
	/** The nn post method access. */
	private boolean postMethodAccess;
	
	/** The nn put method access. */
	private boolean	putMethodAccess;
	
	/** The nn delete method access. */
	private boolean deleteMethodAccess;
	
	/** The nn batch method access. */
	private boolean patchMethodAccess;
	
	/** The user id. */
	private String userId;
	
	/** The user api role name. */
	private String userApiRoleName;
	
}
