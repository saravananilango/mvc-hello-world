package com.nn.sova.service.authorization;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import com.nn.sova.querybuilder.QueryBuilder;
import com.nn.sova.querybuilder.SelectQueryBuilder;
import com.nn.sova.querybuilder.conditions.ConditionBuilder;
import com.nn.sova.service.CacheService;
import com.nn.sova.service.authorization.entity.UserApiRoleConfigurationEntity;
import com.nn.sova.utility.logger.ApplicationLogger;

/**
 * The Class UserApiRoleAuthorization.
 * 
 * @author vellaichamy
 */
public class UserApiRoleAuthorization {

	/** The Constant logger. */
	private static final ApplicationLogger logger = ApplicationLogger.create(UserApiRoleAuthorization.class);


	/**
	 * User api role authorize.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @param entityName the entity name
	 * @param methodUrl the method url
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public boolean userApiRoleAuthorize(String userId,String tenantId,String entityName, Object methodUrl) throws Exception {

		return getUserApiRoleConfigData(userId,tenantId,entityName, methodUrl);
	}

	/**
	 * Gets the user api role config data.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @param entityName the entity name
	 * @param methodUrlData the method url data
	 * @return the user api role config data
	 * @throws Exception the exception
	 */
	boolean getUserApiRoleConfigData(String userId,String tenantId,String entityName, Object methodUrlData) throws Exception{

		List<String> rolesList = getUserApiRoleConfigList(userId,tenantId);
		logger.info("User Api Roles List : " + rolesList);
		String methodUrl = String.valueOf(methodUrlData);
		for(String role : rolesList) {
			logger.info("Fetching data for method security: " + role);
			String cacheKey = String.valueOf(tenantId).concat("_user_api_role_config_").concat(userId).concat("_").concat(role);
			logger.info("Fetching data for method security cache key: " + cacheKey);
			Object roleConfigCacheData = CacheService.getInstance().getCacheData(cacheKey);
			logger.info("Role config cache data: " + roleConfigCacheData);
			if(Objects.isNull(roleConfigCacheData)) {
				updateRoleConfigCacheData(userId,tenantId,role,cacheKey);
				roleConfigCacheData = CacheService.getInstance().getCacheData(cacheKey);
			}
			Map<String,Object> accessDataByRole = (Map<String, Object>) roleConfigCacheData;
			logger.info("accessDataByRole: " + accessDataByRole);
			Map<String,Set<String>> accessEntityMap = (Map<String, Set<String>>) accessDataByRole.get("entity_access_list");
			logger.info("accessEntityMap: " + accessEntityMap);
			if(Objects.nonNull(accessEntityMap) && MapUtils.isNotEmpty(accessEntityMap)) {
				logger.info("Method URL Password Flow:" + methodUrl);
				Set<String> accessEntityList = accessEntityMap.get(methodUrl.trim().toLowerCase());
				logger.info("Entity List Password Flow:" + accessEntityList);
				if(Objects.nonNull(accessEntityList) && accessEntityList.contains(entityName)) {
					logger.info("Method Access Success");
					return true;
				}
			}
		}
		logger.info("Method Access False");
		return false;
	}


	/**
	 * Update role config cache data.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @param role the role
	 * @param cacheKey the cache key
	 * @throws Exception the exception
	 */
	private void updateRoleConfigCacheData(String userId,String tenantId,String role,String cacheKey) throws Exception {
		logger.info("updateRoleConfigCacheData inside");
		List<UserApiRoleConfigurationEntity> userApiRoleList = getUserApiRoleList(userId,tenantId,role);

		if(CollectionUtils.isNotEmpty(userApiRoleList)) {
			logger.info("userApiRoleList not empty");
			Map<String,List<UserApiRoleConfigurationEntity>> methodUrlMap = 
					userApiRoleList.stream().collect(Collectors.groupingBy(UserApiRoleConfigurationEntity::getMethodUrl));

			Map<String,Object> individualRoleDataMap = new HashMap<>();

			logger.info("Method URL Map :"+ methodUrlMap);
			Map<String,Set<String>> methodUrlMapData = new HashMap<>();
			methodUrlMap.entrySet().forEach(action->{
				Map<String,List<UserApiRoleConfigurationEntity>> entityGroup = action.getValue().stream().collect(Collectors.groupingBy(UserApiRoleConfigurationEntity::getApiEntityName));
				logger.info("Entity group :" + entityGroup);
				Set<String> accessGroupList =  new HashSet<>();
				entityGroup.entrySet().forEach(entity->{
					entity.getValue().stream().forEach(data->{
						if(data.isGetMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_READ");
						}
						if(data.isPostMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_POST");
						}
						if(data.isPutMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_PUT");
						}
						if(data.isDeleteMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_DELETE");
						}
						if(data.isPatchMethodAccess()) {
							accessGroupList.add(data.getApiEntityName().toUpperCase()+"_PATCH");
						}
					});
				});
				methodUrlMapData.put(action.getKey().toLowerCase().trim(), accessGroupList);	
			});
			individualRoleDataMap.put("entity_access_list", methodUrlMapData);
			logger.info("userApiRoleList is stored for :" + cacheKey);
			CacheService.getInstance().saveToCache(cacheKey, individualRoleDataMap);
		}else {
			logger.info("userApiRoleList is empty for :" + cacheKey);
			CacheService.getInstance().saveToCache(cacheKey, new HashMap<>());
		}
	}

	/**
	 * Gets the user api role config list.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @return the user api role config list
	 * @throws Exception the exception
	 */
	private List<String> getUserApiRoleConfigList(String userId, String tenantId) throws Exception {

		String cacheKey = String.valueOf(tenantId).concat("_user_api_role_info_").concat(userId);

		Object cacheData = CacheService.getInstance().getCacheData(cacheKey);
		if(Objects.isNull(cacheData)) {
			updateUserApiRoleConfig(userId, tenantId, cacheKey);
			cacheData = CacheService.getInstance().getCacheData(cacheKey);
		}
		return (List<String>) cacheData;
	}

	/**
	 * Update user api role config.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @param cacheKey the cache key
	 * @throws Exception the exception
	 */
	private void updateUserApiRoleConfig(String userId, String tenantId,String cacheKey) throws Exception {
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select().skipTenantId(true);
		List<Map<String,Object>> userApiRoleList = selectQueryBuilder.from("user_api_role_configuration").
				where(ConditionBuilder.instance().eq("user_id", userId).
						and().eq("tenant_id", tenantId)).build(true).execute();

		if(CollectionUtils.isNotEmpty(userApiRoleList)) {
			Set<String> rolesName = new HashSet<String>();
			userApiRoleList.stream().forEach(action->{
				rolesName.add(String.valueOf(action.get("api_role_name")));
			});

			List<String> rolesList = new ArrayList<>(rolesName);
			CacheService.getInstance().saveToCache(cacheKey, rolesList);
		}else {
			CacheService.getInstance().saveToCache(cacheKey, new ArrayList<>());
		}
	}

	/**
	 * Gets the user api role list.
	 *
	 * @param userId the user id
	 * @param tenantId the tenant id
	 * @param role the role
	 * @return the user api role list
	 * @throws Exception the exception
	 */
	public List<UserApiRoleConfigurationEntity> getUserApiRoleList(String userId,String tenantId, String role) throws Exception{
		QueryBuilder queryBuilder = new QueryBuilder();
		SelectQueryBuilder selectQueryBuilder = queryBuilder.btSchema().select().skipTenantId(true);
		List<Map<String,Object>> userApiRoleList = selectQueryBuilder.from("user_api_role_configuration_view").
				where(ConditionBuilder.instance().eq("user_id", userId).
						and().eq("api_role_name", role).
						and().eq("tenant_id", tenantId)).build(true).execute();
		List<UserApiRoleConfigurationEntity> userApiRoleConfigurationEntityList =  new ArrayList<>();
		if(CollectionUtils.isNotEmpty(userApiRoleList)) {
			userApiRoleList.stream().forEach(action->{
				UserApiRoleConfigurationEntity userApiRoleConfigurationEntity = new UserApiRoleConfigurationEntity();
				userApiRoleConfigurationEntity.setUserId(String.valueOf(action.get("user_id")));
				userApiRoleConfigurationEntity.setApiEntityName(String.valueOf(action.get("client_id")));
				userApiRoleConfigurationEntity.setApiRoleName(String.valueOf(action.get("api_role_name")));
				userApiRoleConfigurationEntity.setPatchMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("batch_method_access"))));
				userApiRoleConfigurationEntity.setDeleteMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("delete_method_access"))));
				userApiRoleConfigurationEntity.setGetMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("get_method_access"))));
				userApiRoleConfigurationEntity.setPostMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("post_method_access"))));
				userApiRoleConfigurationEntity.setPutMethodAccess(Boolean.parseBoolean(String.valueOf(action.get("put_method_access"))));
				userApiRoleConfigurationEntity.setApiEntityName(String.valueOf(action.get("api_entity_name")).trim());
				userApiRoleConfigurationEntity.setMethodUrl(String.valueOf(action.get("method_url")).trim());
				userApiRoleConfigurationEntity.setProductCode(String.valueOf(action.get("product_code")));
				userApiRoleConfigurationEntity.setSubProductName(String.valueOf(action.get("sub_product_name")));
				userApiRoleConfigurationEntity.setTenantId(String.valueOf(action.get("tenant_id")));
				userApiRoleConfigurationEntityList.add(userApiRoleConfigurationEntity);
			});
		}
		return userApiRoleConfigurationEntityList;
	}
}
