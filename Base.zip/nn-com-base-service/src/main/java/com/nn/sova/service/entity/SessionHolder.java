package com.nn.sova.service.entity;

import java.util.List;

import lombok.Data;

/**
 * SessionHolder provide the Session Information.
 *
 * @author Logchand
 */

@Data
public class SessionHolder {

	/**  The User Token. */
	private String userToken;

	/**  The User ID. */
	private String userId;

	/**  The Service Id. */
	private String sid;

	/**  The Service Name. */
	private String serviceName;

	/**  The Session Token. */
	private String sessionToken;

	/**  The locale. */
	private String locale;

	/**  The isError Flag. */
	private boolean isError;

	/**  The message. */
	private String message;

	/**  The isRedirected Flag. */
	private boolean isRedirected;

	/**  The Redirected Url. */
	private String redirectedUrl;

	/**  The isAuthenticated Flag. */
	private boolean isAuthenticated;

	/**  The isAlreadyAuthenticated Flag. */
	private boolean isAlreadyAuthenticated;

	/**  The isAuthenticated Flag. */
	private boolean isAuthorized;

	/**  The Client IP Address. */
	private String ipAddress;

	/**  The Client browser. */
	private String browser;

	/**  The Client Operating System. */
	private String operatingSystem;

	/**  The contextPath. */
	private String contextPath;

	/**  The security object of service. */
	private List<String> securityObject;

	/**  The security ordered object of service. */
	private List<String> securityOrderedObject;

	/**  The tenantId. */
	private String tenantId;

	/** The restricted redirection. */
	private boolean restrictedRedirection;

	/** The invalid user. */
	private boolean invalidUser;


}
