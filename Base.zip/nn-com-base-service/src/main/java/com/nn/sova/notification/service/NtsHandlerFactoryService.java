package com.nn.sova.notification.service;

import com.nn.sova.notification.gateway.service.NotificationStatusManager;

public interface NtsHandlerFactoryService {

	
	NotificationStatusManager getServiceInstance(String gatewayType);

}
 