package com.nn.sova.service.authorization.entity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import lombok.Data;

import org.apache.commons.lang3.StringUtils;

/**
 * ScreenDefinitionEntity defines the screen Def data.
 *
 * @author Vellaichamy N
 */

@Data
public class ScreenDefinitionEntity {

	/**  The screen Def ID. */
	private String screenDefId;

	/**  The Application Code. */
	private String applicationCode;

	/**  The jsp path. */
	private String jspPath;

	/**  The screen Name. */
	private String screenName;

	/**  The screen Url. */
	private String screenUrl;

	/**  The Created User. */
	private String createUser;

	/**  The Created Date. */
	private LocalDate createDate;

	/**  The updated User. */
	private String updateUser;

	/**  The update Date. */
	private LocalDate updateDate;


	/**
	 * mapValues convert map into entity.
	 *
	 * @param screenDefinitionMapper has an screen definition info like screen def,screen path etc
	 * @return Screen Definition entity has an screen definition info like screen def,screen path etc
	 */
	public static ScreenDefinitionEntity mapValues(Map<String, Object> screenDefinitionMapper) {
		ScreenDefinitionEntity screenDefinitionEntity=new ScreenDefinitionEntity();
		screenDefinitionEntity.setScreenDefId(Objects.isNull(screenDefinitionMapper.get("screenDefinition.screenDefId"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.screenDefId").toString());
		screenDefinitionEntity.setApplicationCode(Objects.isNull(screenDefinitionMapper.get("screenDefinition.applicationCode"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.applicationCode").toString());
		screenDefinitionEntity.setJspPath(Objects.isNull(screenDefinitionMapper.get("screenDefinition.jspPath"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.jspPath").toString());
		screenDefinitionEntity.setScreenName(Objects.isNull(screenDefinitionMapper.get("screenDefinition.screenName"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.screenName").toString());
		screenDefinitionEntity.setScreenUrl(Objects.isNull(screenDefinitionMapper.get("screenDefinition.screenUrl"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.screenUrl").toString());
		screenDefinitionEntity.setCreateUser(Objects.isNull(screenDefinitionMapper.get("screenDefinition.createUser"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.createUser").toString());
		screenDefinitionEntity.setCreateDate(Objects.isNull(screenDefinitionMapper.get("screenDefinition.createDate"))?null:LocalDate.parse(screenDefinitionMapper.get("screenDefinition.createDate").toString(),DateTimeFormatter.ofPattern("yyyy-MM-d")));
		screenDefinitionEntity.setUpdateUser(Objects.isNull(screenDefinitionMapper.get("screenDefinition.updateUser"))?StringUtils.EMPTY:screenDefinitionMapper.get("screenDefinition.updateUser").toString());
		screenDefinitionEntity.setUpdateDate(Objects.isNull(screenDefinitionMapper.get("screenDefinition.updateDate"))?null:LocalDate.parse(screenDefinitionMapper.get("screenDefinition.updateDate").toString(),DateTimeFormatter.ofPattern("yyyy-MM-d")));
		return screenDefinitionEntity;
	}

	/**
	 * mapValues convert entity into Map.
	 *
	 * @param screenDefinitionEntity the screen definition entity
	 * @return screenDefinitionMapper has an screen definition info like screen def,screen path etc
	 */
	public static Map<String, Object> mapValues(ScreenDefinitionEntity screenDefinitionEntity) {
		Map<String, Object> screenDefinitionMapper=new HashMap<>();
		screenDefinitionMapper.put("screen_def_id",screenDefinitionEntity.getScreenDefId());
		screenDefinitionMapper.put("application_code",screenDefinitionEntity.getApplicationCode());
		screenDefinitionMapper.put("jsp_path",screenDefinitionEntity.getJspPath());
		screenDefinitionMapper.put("screen_name",screenDefinitionEntity.getScreenName());
		screenDefinitionMapper.put("screen_url",screenDefinitionEntity.getScreenUrl());
		screenDefinitionMapper.put("create_user",screenDefinitionEntity.getCreateUser());
		screenDefinitionMapper.put("create_date",screenDefinitionEntity.getCreateDate());
		screenDefinitionMapper.put("update_user",screenDefinitionEntity.getUpdateUser());
		screenDefinitionMapper.put("update_date",screenDefinitionEntity.getUpdateDate());
		return screenDefinitionMapper;
	}
}
