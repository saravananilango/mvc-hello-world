package com.nn.sova.notification.service;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor(access= AccessLevel.PRIVATE)
public enum NotificationSendResultCode {
	FAILURE("FAILURE_DEFAULT"),
	SUCCESS("SUCCESS"),
	NO_PARAMETER("NO_PARAMETER"),
	ISSUE_IN_FETCH_SCREEN_DEF_ID_IN_CACHE("ISSUE_IN_FETCH_SCREEN_DEF_ID_IN_CACHE"),
	NO_ALERT_FOUND("NO_ALERT_ID_FOUND"),
	HANDLER_ERROR("ERROR HAPPENED WHILE FETCHING HANDLER CONFIG");
	
	@Getter
	private String value;

}
