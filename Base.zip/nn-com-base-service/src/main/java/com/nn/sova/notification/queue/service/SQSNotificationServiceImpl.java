package com.nn.sova.notification.queue.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.JMSException;

import org.apache.commons.lang.StringUtils;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambdaClient;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.CreateEventSourceMappingRequest;
import com.amazonaws.services.lambda.model.GetFunctionRequest;
import com.amazonaws.services.lambda.model.ListEventSourceMappingsRequest;
import com.amazonaws.services.lambda.model.ListEventSourceMappingsResult;
import com.amazonaws.services.lambda.model.ResourceConflictException;
import com.amazonaws.services.sqs.AmazonSQSAsyncClient;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SetQueueAttributesRequest;
import com.nn.sova.nts.vo.NotificationResponse;
import com.nn.sova.utility.config.EnvironmentReader;
import com.nn.sova.utility.logger.ApplicationLogger;
import com.nn.sova.utility.logger.CustomException;

public class SQSNotificationServiceImpl implements NotificationQueueService {
	
    private static final ApplicationLogger LOGGER = ApplicationLogger.create(SQSNotificationServiceImpl.class);
	
    private static final String BUCKET_NAME = "extended-client-bucket1";

    private static final String QUEUE_SUFFIX = ".fifo";

    private static final int EXTENDED_STORAGE_MESSAGE_SIZE_THRESHOLD = 2056;
    
    private static final String DEAD_QUEUE_SUFFIX = "-DQ.fifo";
    
    private static final String MESSAGE_GROUP_ID = "notification_producer";
    
    private static final String CONSUMER_LAMBDA_NAME = "nn-notification-consumer-service";
    
    private static final String QUEUE_ARN = "QueueArn";
    
	
    private final AmazonSQSClient amazonSQSClient;
    
//    private final AmazonSQSExtendedClient amazonSQSExtendedClient;
    
    private final AWSLambdaClient awsLambdaClient;
    
//    private final MessageConnection connection;
    
	/**
	 * Used to maintain singleton instance.
	 */
	private static SQSNotificationServiceImpl instance = null;
	
	
	/**
	 * Gets instance of SQSNotificationServiceImpl class.
	 *
	 * @return the instance
	 */
	public static SQSNotificationServiceImpl getInstance() {
		if (instance == null) {
			instance = new SQSNotificationServiceImpl();
		}
		return instance;
	}
	
	/**
	 * Instantiates SQSNotificationServiceImpl.
	 */
	private SQSNotificationServiceImpl() {
		awsLambdaClient = (AWSLambdaClient) AWSLambdaClientBuilder.standard().withRegion(EnvironmentReader.getAWSRegion())
	                 .withCredentials(new AWSStaticCredentialsProvider(
	                         new BasicAWSCredentials(EnvironmentReader.getAWSAccessKeyId(), 
	                         		EnvironmentReader.getAWSSecretAccessKey())))
	                 .build();
		amazonSQSClient = (AmazonSQSAsyncClient) AmazonSQSAsyncClientBuilder
                .standard()
                .withRegion(Regions.fromName(EnvironmentReader.getAWSRegion()))
                .withCredentials(new AWSStaticCredentialsProvider(
                        new BasicAWSCredentials(EnvironmentReader.getAWSAccessKeyId(), 
                        		EnvironmentReader.getAWSSecretAccessKey())))
                .build();
	}

	@Override
	public Connection getMessagingConnection() throws JMSException {
        SQSConnectionFactory connectionFactory = new SQSConnectionFactory(new ProviderConfiguration(), amazonSQSClient);
        return connectionFactory.createConnection();
	}

	@Override
	public CreateQueueResult createQueue(String queueName) {
		 Map<String, String> queueAttributes = new HashMap<>();
	     queueAttributes.put("FifoQueue", "true");
	     queueAttributes.put("ContentBasedDeduplication", "true");
	     return amazonSQSClient.createQueue(new CreateQueueRequest()
	                .withQueueName(queueName).withAttributes(queueAttributes));
	}

	@Override
	public boolean publishMessage(String message, String queueName) throws CustomException {
		try {
			queueName = String.join("-", EnvironmentReader.getCustomerCode(), EnvironmentReader.getSystemId(), queueName);
			CreateQueueResult createQueueResult = createProducer(queueName);
			if (createQueueResult.getSdkHttpMetadata().getHttpStatusCode() == 200
					&& StringUtils.isNotEmpty(createQueueResult.getQueueUrl())) {
				SendMessageRequest request = new SendMessageRequest(createQueueResult.getQueueUrl(), message);
				request.withMessageGroupId(MESSAGE_GROUP_ID);
				request.withMessageDeduplicationId(UUID.randomUUID().toString());
				amazonSQSClient.sendMessage(request);
				return true;
			} else {
				throw new CustomException("Exception occurred while sending message to queue:" + queueName);
			}
		}catch(Exception exception) {
        	 throw new CustomException(exception);
        }
        
	}
	
	/**
	 * createProducer will create queue if not exist before publish message to queue.
	 * @param queueName
	 * @return
	 * @throws JMSException
	 */
	private CreateQueueResult createProducer(String queueName) {
        CreateQueueResult createQueueResult = createQueue(getQueueName(queueName));
        String queueArn = amazonSQSClient.getQueueAttributes(createQueueResult.getQueueUrl(),
                Collections.singletonList(QUEUE_ARN)).getAttributes().get(QUEUE_ARN);
        
        // Get lambda function timeout .
        GetFunctionRequest lambdaRequest = new GetFunctionRequest();
        String lambdaFunctionName = String.join("-", EnvironmentReader.getCustomerCode(), EnvironmentReader.getSystemId(), CONSUMER_LAMBDA_NAME);
		lambdaRequest.setFunctionName(lambdaFunctionName );
        int timeout = awsLambdaClient.getFunction(lambdaRequest).getConfiguration().getTimeout();

        Map<String, String> attribute = new HashMap<>();
        // Visibility timeout should always be greater than or equal to lambda timeout.
        attribute.put("VisibilityTimeout", String.valueOf(timeout));

        SetQueueAttributesRequest request = new SetQueueAttributesRequest()
                .withQueueUrl(createQueueResult.getQueueUrl())
                .withAttributes(attribute);
        amazonSQSClient.setQueueAttributes(request);
        configureLambdaTrigger(queueArn);
        return createQueueResult;
    }

	/**
	 * Configure lambda to queue.
	 * @param consumerQueueArn
	 * @throws JMSException
	 */
    private void configureLambdaTrigger(String queue) {
    	try {
    		String lambdaFunctionName = String.join("-", EnvironmentReader.getCustomerCode(), EnvironmentReader.getSystemId(), CONSUMER_LAMBDA_NAME);
            ListEventSourceMappingsRequest eventSourceMaps = new ListEventSourceMappingsRequest().withEventSourceArn(queue).withFunctionName(lambdaFunctionName).withMaxItems(100);
            ListEventSourceMappingsResult data = awsLambdaClient.listEventSourceMappings(eventSourceMaps);
            String uuid = data.getEventSourceMappings().get(0).getUUID();
            if (uuid == null || uuid.isEmpty()) {
              CreateEventSourceMappingRequest createEventSourceMappingRequest = new CreateEventSourceMappingRequest();
              createEventSourceMappingRequest.setEventSourceArn(queue);
              createEventSourceMappingRequest.setFunctionName(lambdaFunctionName);
              awsLambdaClient.createEventSourceMapping(createEventSourceMappingRequest);
            }
            else { 
            	LOGGER.info("Lambda Function already exists");
            }
                        
    	} catch(ResourceConflictException exception) {
    		/* Lambda trigger already exist.
			 * Case : If lambda trigger already configured to the queue , it throws ResourceConflictException .
    		 */
    		LOGGER.warn(exception.toString());
    	}
        
    }
	
    /**
     * Gets the queue name.
     *
     * @param consumerName the consumer name
     * @return the queue name
     */
    private String getQueueName(String queueName) {
        return queueName + QUEUE_SUFFIX;
    }
    
    /**
     * Gets the dead letter queue name.
     *
     * @param consumerName the consumer name
     * @return the queue name
     */
    private String getDeadLetterQueueName(String queueName) {
        return queueName + DEAD_QUEUE_SUFFIX;
    }
	

}
