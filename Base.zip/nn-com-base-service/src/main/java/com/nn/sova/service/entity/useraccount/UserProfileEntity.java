package com.nn.sova.service.entity.useraccount;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import lombok.Data;

/**
 * UserProfileEntity return the profile of the User details
 * 
 * @author Mohammed Sheriff
 *
 */
@Data
public class UserProfileEntity {
	/** The UserName */
	private String userName;

	/** The employee Number */
	private String empNo;

	private String empReferenceNo;

	/** The Name of the User */
	private String name;

	/** The email Id of the User */
	private String email;
	
	/** The picture path of the user */
	private String userImage;

	/** The image file id of the user */
	private String userImageFileId;

	/** The country of the users */
	private String country;

	/** The current locale */
	private String locale;

	/** The current timezone */
	private String timeZone;

	/** The blood group */
	private String bloodGroup;

	/** The extension Number */
	private String extensionNumber;

	/** The phone Number */
	private String phoneNumber;

	/** The address */
	private String address;

	/** The Date Format */
	private String dateFormat;

	/** The Time Format */
	private String timeFormat;

	/** The Currency Format */
	private String currencyFormat;

	/** isFullyAuthorized flag */
	private boolean isFullyAuthorized;

	/** The apiToken */
	private String apiToken;

	private boolean adminUser;
	
	private boolean debugFlag;
	
	private String themeCode;

	/** list of roles */
	private List<String> roleList = new ArrayList<>();

	/**
	 * setUserdataProfile method is used to set the user data to the UserProfile
	 * entity
	 * 
	 * @param userDataMap
	 * @return entity of UserProfile
	 */
	@SuppressWarnings("unchecked")
	public static UserProfileEntity setUserdataProfile(Map<String, Object> userDataMap) {
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		userProfileEntity.setUserName(
				Objects.isNull(userDataMap.get("user_id")) ? StringUtils.EMPTY : userDataMap.get("user_id").toString());
		userProfileEntity.setEmpNo(
				Objects.isNull(userDataMap.get("emp_no")) ? StringUtils.EMPTY : userDataMap.get("emp_no").toString());
		userProfileEntity.setEmpReferenceNo(Objects.isNull(userDataMap.get("emp_auto_number")) ? StringUtils.EMPTY
				: userDataMap.get("emp_auto_number").toString());
		userProfileEntity.setTimeZone(Objects.isNull(userDataMap.get("time_zone")) ? StringUtils.EMPTY
				: userDataMap.get("time_zone").toString());
		String firstName = Objects.isNull(userDataMap.get("first_name")) ? StringUtils.EMPTY
				: userDataMap.get("first_name").toString();
		String lastName = Objects.isNull(userDataMap.get("last_name")) ? StringUtils.EMPTY
				: userDataMap.get("last_name").toString();
		userProfileEntity.setName(firstName.concat(" ").concat(lastName));
		userProfileEntity.setEmail(
				Objects.isNull(userDataMap.get("email_id")) ? StringUtils.EMPTY : userDataMap.get("email_id").toString());
		userProfileEntity.setUserImage(Objects.isNull(userDataMap.get("user_image_path")) ? StringUtils.EMPTY
				: userDataMap.get("user_image_path").toString());
		userProfileEntity.setUserImageFileId(Objects.isNull(userDataMap.get("user_image_file_id")) ? StringUtils.EMPTY
				: userDataMap.get("user_image_file_id").toString());
		userProfileEntity.setCountry(
				Objects.isNull(userDataMap.get("country")) ? StringUtils.EMPTY : userDataMap.get("country").toString());
		userProfileEntity.setLocale(Objects.isNull(userDataMap.get("user_locale")) ? StringUtils.EMPTY
				: userDataMap.get("user_locale").toString());
		userProfileEntity.setAddress(
				Objects.isNull(userDataMap.get("address")) ? StringUtils.EMPTY : userDataMap.get("address").toString());
		userProfileEntity.setBloodGroup(Objects.isNull(userDataMap.get("blood_group")) ? StringUtils.EMPTY
				: userDataMap.get("blood_group").toString());
		userProfileEntity.setExtensionNumber(Objects.isNull(userDataMap.get("extension_number")) ? StringUtils.EMPTY
				: userDataMap.get("extension_number").toString());
		userProfileEntity.setPhoneNumber(Objects.isNull(userDataMap.get("phone_number")) ? StringUtils.EMPTY
				: userDataMap.get("phone_number").toString());
		userProfileEntity.setDateFormat(Objects.isNull(userDataMap.get("date_format")) ? StringUtils.EMPTY
				: userDataMap.get("date_format").toString());
		userProfileEntity.setTimeFormat(Objects.isNull(userDataMap.get("time_format")) ? StringUtils.EMPTY
				: userDataMap.get("time_format").toString());
		userProfileEntity.setCurrencyFormat(Objects.isNull(userDataMap.get("currency_format")) ? StringUtils.EMPTY
				: userDataMap.get("currency_format").toString());
		userProfileEntity.setFullyAuthorized(Objects.isNull(userDataMap.get("is_full_authority")) ? Boolean.FALSE
				: Boolean.parseBoolean(userDataMap.get("is_full_authority").toString()));
		userProfileEntity.setRoleList(Objects.isNull(userDataMap.get("role_id")) ? new ArrayList<String>()
				: (List<String>) userDataMap.get("role_id"));
		userProfileEntity.setApiToken(Objects.isNull(userDataMap.get("api_token")) ? StringUtils.EMPTY
				: userDataMap.get("api_token").toString());
		userProfileEntity.setAdminUser(Objects.isNull(userDataMap.get("admin_user_flag")) ? false
				: Boolean.valueOf(userDataMap.get("admin_user_flag").toString()));
		userProfileEntity.setDebugFlag(Objects.isNull(userDataMap.get("is_debug")) ? false
				: Boolean.valueOf(userDataMap.get("is_debug").toString()));
		userProfileEntity.setThemeCode(
				Objects.isNull(userDataMap.get("theme_code")) ? StringUtils.EMPTY : userDataMap.get("theme_code").toString());
		
		return userProfileEntity;
	}

}
