package com.nn.sova.service.dao;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * UserAccountDao interface is to do database operations of Useraccount data.
 * 
 * @author Mohammed Shameer...
 *
 */
public interface UserAccountDao {

    /**
     * changeUserImageis used to change the user image of the user.
     *
     * @param fileId the file id
     * @param referenceId the reference id
     * @throws QueryException the query exception
     */
    void changeUserImage(String fileId, String referenceId) throws QueryException;

    /**
     * getUserAccountDetails method is to get user account details.
     *
     * @param userIds the user ids
     * @return the user account details
     */
    List<Map<String, Object>> getUserAccountDetails(List<String> userIds);

}