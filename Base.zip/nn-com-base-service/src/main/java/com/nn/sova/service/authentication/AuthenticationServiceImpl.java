package com.nn.sova.service.authentication;

/**
 * The Class AuthenticationServiceImpl.
 * 
 * @author vellaichamy
 */
public class AuthenticationServiceImpl {

	/**
	 * Gets the authentication service class.
	 *
	 * @param clientRegId the client reg id
	 * @return the authentication service class
	 */
	public AuthenticationServiceInterface getAuthenticationServiceClass(String clientRegId){

		AuthenticationServiceInterface authenticationService = null;
		if(clientRegId.equals("sova")) {
			authenticationService = AuthenticationService.getInstance();
		}
		else if(clientRegId.equals("https://accounts.google.com") || clientRegId.equals("google")) {
			authenticationService = AuthenticationServiceGoogle.getInstance();
		}
		else if(clientRegId.equals("github")) {
			// need to implement
		}else {
			authenticationService = AuthenticationService.getInstance();
		}
		
		return authenticationService;
	}
}
