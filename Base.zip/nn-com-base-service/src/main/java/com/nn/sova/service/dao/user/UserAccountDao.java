package com.nn.sova.service.dao.user;

import java.util.List;
import java.util.Map;

import com.nn.sova.exception.QueryException;

/**
 * UserAccountDao interface is to do database operations of Useraccount data.
 * 
 * @author Mohammed Shameer
 *
 */
public interface UserAccountDao {

	/**
	 * changeUserImageis used to change the user image of the user.
	 * 
	 * @param fileId
	 * @throws QueryException
	 */
	void changeUserImage(String fileId, String referenceId) throws QueryException;

	/**
	 * getUserAccountDetails method is to get user account details.
	 * @param userIds
	 * @return
	 */
	List<Map<String, Object>> getUserAccountDetails(List<String> userIds);

}